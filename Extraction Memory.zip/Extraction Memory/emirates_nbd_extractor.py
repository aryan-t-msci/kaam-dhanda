"""
Emirates NBD Bank (P.J.S.C.) - Multi-Source Location Extractor

Platform Pattern: Emirates NBD custom REST API (/enbdapi/v1/branchatm/getbranchandatms)
                  with Sitecore backend. Pattern resembles Section 3.9 Sitecore BranchInfo API.

Sources:
  1. UAE Branches & ATMs  - https://www.emiratesnbd.com/en/branches-and-atms
  2. Egypt Branches        - https://www.emiratesnbd.com.eg/en/branches-and-atms
  3. KSA Branches          - https://www.emiratesnbd.com.sa/en/branches-and-atms
  4. UK London Branch      - https://www.emiratesnbd.co.uk/en/contact-us
  5. India (Mumbai Office) - https://www.emiratesnbd.bank.in/en/contact-us
  6. Asset Management (DIFC) - https://www.emiratesnbd.com/en/asset-management/contact-us
  7. Denizbank HQ (Turkey) - https://www.denizbank.com/en/legal-warnings

CONFIGURATION:
  - ISSUER_ID, ISSUER_NAME defined below
  - SETTINGS IDs discovered via page HTML data-settingsid attribute
  - POST to /enbdapi/v1/branchatm/getbranchandatms with form data

Author: AI Extraction Agent | Date: 2026-04-07
"""

# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
ISSUER_ID    = "IID000000002147467"
ISSUER_NAME  = "EMIRATES NBD BANK (P.J.S.C)"

OUTPUT_DIR   = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output"
TEMP_DIR     = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp"

# Branch API settings - discovered from page HTML data-settingsid
API_SOURCES = [
    {
        'country': 'United Arab Emirates',
        'country_iso3': 'ARE',
        'base_url': 'https://www.emiratesnbd.com',
        'settings_id': 'ad094bdd-58c0-423d-9758-4d769d0777a8',
        'source_url': 'https://www.emiratesnbd.com/en/branches-and-atms',
        'source_type': 'COMPANY WEBSITE',
        'include_categories': ['Branches', 'ITMs'],  # Exclude ATMs for branch-focused extraction
        'state_field': 'emirate',  # EmirateId maps to UAE emirate
    },
    {
        'country': 'Egypt',
        'country_iso3': 'EGY',
        'base_url': 'https://www.emiratesnbd.com.eg',
        'settings_id': '7c6025fa-3773-4e3c-9f76-454a202a2e79',
        'source_url': 'https://www.emiratesnbd.com.eg/en/branches-and-atms',
        'source_type': 'COMPANY WEBSITE',
        'include_categories': ['Branches'],
        'state_field': None,
    },
    {
        'country': 'Saudi Arabia',
        'country_iso3': 'SAU',
        'base_url': 'https://www.emiratesnbd.com.sa',
        'settings_id': '96b6ecea-e024-44df-a579-d647152559f2',
        'source_url': 'https://www.emiratesnbd.com.sa/en/branches-and-atms',
        'source_type': 'COMPANY WEBSITE',
        'include_categories': ['Branches'],
        'state_field': None,
    },
]

# Manual/static records for contact pages and offices
MANUAL_RECORDS = [
    {
        'LOCATION_NAME': 'Emirates NBD London Branch',
        'LOCATION_ADDRESS': '1 Knightsbridge, London SW1X 7LX',
        'CITY': 'London',
        'STATE': 'England',
        'COUNTRY': 'United Kingdom of Great Britain and Northern Ireland (the)',
        'COUNTRY_ISO3': 'GBR',
        'POSTCODE': 'SW1X 7LX',
        'LATITUDE': '',
        'LONGITUDE': '',
        'SOURCE_URL': 'https://www.emiratesnbd.co.uk/en/contact-us',
        'SOURCE_TYPE': 'COMPANY WEBSITE',
        'ACTIVITY_AT_ASSET': 'Private Banking / Corporate Banking Branch',
        'LOCATION_NAME_NATIVE': '',
        'LOCATION_ADDRESS_NATIVE': '',
    },
    {
        'LOCATION_NAME': 'Emirates NBD India - Mumbai Office',
        'LOCATION_ADDRESS': 'Gr. & 1st Floor, 5 North Avenue, Maker Maxity, Bandra Kurla Complex, Bandra (E), Mumbai 400051',
        'CITY': 'Mumbai',
        'STATE': 'Maharashtra',
        'COUNTRY': 'India',
        'COUNTRY_ISO3': 'IND',
        'POSTCODE': '400051',
        'LATITUDE': '',
        'LONGITUDE': '',
        'SOURCE_URL': 'https://www.emiratesnbd.bank.in/en/contact-us',
        'SOURCE_TYPE': 'COMPANY WEBSITE',
        'ACTIVITY_AT_ASSET': 'Banking Office / Nodal Office',
        'LOCATION_NAME_NATIVE': '',
        'LOCATION_ADDRESS_NATIVE': '',
    },
    {
        'LOCATION_NAME': 'Emirates NBD Asset Management - Dubai DIFC Office',
        'LOCATION_ADDRESS': '8th Floor, East Wing, The Gate Building, Dubai International Financial Centre, P.O. Box 506578, Dubai',
        'CITY': 'Dubai',
        'STATE': 'Dubai',
        'COUNTRY': 'United Arab Emirates',
        'COUNTRY_ISO3': 'ARE',
        'POSTCODE': '',
        'LATITUDE': '',
        'LONGITUDE': '',
        'SOURCE_URL': 'https://www.emiratesnbd.com/en/asset-management/contact-us',
        'SOURCE_TYPE': 'COMPANY WEBSITE',
        'ACTIVITY_AT_ASSET': 'Asset Management Office',
        'LOCATION_NAME_NATIVE': '',
        'LOCATION_ADDRESS_NATIVE': '',
    },
    {
        'LOCATION_NAME': 'DenizBank Headquarters',
        'LOCATION_ADDRESS': 'Buyukdere Cad. No:141, Esentepe, Sisli, Istanbul',
        'CITY': 'Istanbul',
        'STATE': 'Istanbul',
        'COUNTRY': 'Turkiye',
        'COUNTRY_ISO3': 'TUR',
        'POSTCODE': '34394',
        'LATITUDE': '',
        'LONGITUDE': '',
        'SOURCE_URL': 'https://www.denizbank.com/en/legal-warnings',
        'SOURCE_TYPE': 'COMPANY WEBSITE',
        'ACTIVITY_AT_ASSET': 'Bank Headquarters',
        'LOCATION_NAME_NATIVE': 'DenizBank Genel Mudurlugu',
        'LOCATION_ADDRESS_NATIVE': 'Buyukdere Cad. No:141, Esentepe, Sisli, Istanbul',
    },
]

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC
# ═══════════════════════════════════════════════════════════
import urllib.request, ssl, re, json, csv, os, unicodedata, urllib.parse
from pathlib import Path
from datetime import datetime

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

# Emirates ID to name map (from page HTML)
EMIRATE_MAP = {
    'd2abdab6-9f59-4710-a564-8a2acf431ddc': 'Abu Dhabi',
    '80557be2-d4bd-4466-a225-13df19faf1b4': 'Ajman',
    '427cfb3c-d003-46a4-b02b-b4041e2024a4': 'Dubai',
    'e520f341-c8e2-441c-ad85-c4b2596bc422': 'Fujairah',
    'fcded32f-c226-4eaf-87ab-796dd3c0f4a7': 'Ras Al Khaimah',
    'a4fd98c9-51d7-43eb-a4e3-ad2eea09e69d': 'Sharjah',
    'b4f4d399-e730-482a-9d0e-f7253e0bd6fa': 'Umm Al Quwain',
}

# Known Egyptian cities for city extraction
EGYPT_CITY_KEYWORDS = [
    'Cairo', 'Alexandria', 'Giza', 'Shubra', 'Heliopolis', 'Maadi', 'Zamalek',
    'Nasr City', 'Dokki', 'Mohandessin', 'Mansoura', 'Tanta', 'Luxor', 'Aswan',
    'Port Said', 'Suez', 'Ismailia', 'Damietta', 'Zagazig', 'Minya', 'Asyut',
    'Sohag', 'Qena', 'Hurghada', 'Sharm El Sheikh', 'October', 'Sheikh Zayed',
    '6th of October', 'New Cairo', 'East Cairo', 'Obour', 'Badr', '10th of Ramadan',
    'Beni Suef', 'Fayoum', 'Ras Sudr', 'Borg El Arab', 'Sidi Gaber', 'Smouha',
    'Agami', 'Sporting', 'Rehab', 'Madinaty', 'Shorouk', 'Sheraton',
    'Ain Shams', 'Mataria', 'Shubra El Kheima', 'El Mosky', 'El Sayeda', 'Fustat',
    'Downtown', 'Garden City', 'El Agouza', 'Imbaba', 'Bulaq', 'Ataba',
    'Talkha', 'Mit Ghamr', 'Kafr El Sheikh', 'Damanhour', 'Shibin El Kom',
    'Banha', 'El Arish'
]

# Saudi Arabia cities for extraction
KSA_CITY_KEYWORDS = [
    'Riyadh', 'Jeddah', 'Mecca', 'Makkah', 'Medina', 'Madinah', 'Khobar', 'Al Khobar',
    'Dammam', 'AlHassa', 'Al Hassa', 'Hofuf', 'AlQassim', 'Al Qassim', 'Buraydah', 'Unaizah',
    'AlJubail', 'Al Jubail', 'AlTaif', 'Al Taif', 'Taif', 'Abha', 'Tabuk', 'Hail',
    'Yanbu', 'Najran', 'Jizan', 'Arar', 'Sakaka', 'Qatif', 'Dhahran', 'Ras Tanura',
    'Mohammadiya', 'Hittin', 'King Fahad Road'
]


def transliterate(text):
    """Convert text to ASCII/UTF-8 safe characters, preserving meaning."""
    if not text:
        return ''
    # Replace common Arabic/special chars
    replacements = {
        '\u00e4': 'ae', '\u00f6': 'oe', '\u00fc': 'ue',
        '\u00df': 'ss',  # German
        '\u015f': 's', '\u015e': 'S',  # Turkish s cedilla
        '\u011f': 'g', '\u011e': 'G',  # Turkish g breve
        '\u0131': 'i', '\u0130': 'I',  # Turkish dotless i
        '\u00e7': 'c', '\u00c7': 'C',  # c cedilla
        '\u00f1': 'n', '\u00d1': 'N',  # n tilde
        '\u2013': '-', '\u2014': '-',  # em/en dash
        '\u2018': "'", '\u2019': "'",  # smart quotes
        '\u201c': '"', '\u201d': '"',
        '\u00e9': 'e', '\u00e8': 'e', '\u00ea': 'e',
        '\u00e0': 'a', '\u00e1': 'a', '\u00e2': 'a',
        '\u00f3': 'o', '\u00f2': 'o', '\u00f4': 'o',
        '\u00fa': 'u', '\u00f9': 'u', '\u00fb': 'u',
        '\u00ed': 'i', '\u00ec': 'i', '\u00ee': 'i',
    }
    for orig, repl in replacements.items():
        text = text.replace(orig, repl)
    # NFKD normalization to ASCII
    try:
        normalized = unicodedata.normalize('NFKD', text)
        ascii_text = normalized.encode('ascii', 'ignore').decode('ascii')
        return ascii_text.strip()
    except:
        return text.strip()

def clean_address(address):
    """Remove # characters and other geocoding-unfriendly chars."""
    if not address:
        return ''
    addr = address.replace('#', '').replace('  ', ' ').strip()
    # Remove multiple spaces
    addr = re.sub(r'\s+', ' ', addr)
    # Remove trailing/leading commas
    addr = addr.strip(',').strip()
    return addr

def extract_city_uae(address, emirate_name):
    """Extract city from UAE address."""
    if emirate_name:
        return emirate_name  # In UAE, emirate = city for our purposes
    # Fallback - try known cities
    known = ['Dubai', 'Abu Dhabi', 'Sharjah', 'Ajman', 'Fujairah', 'Ras Al Khaimah', 'Umm Al Quwain']
    for city in known:
        if city.lower() in address.lower():
            return city
    return emirate_name or ''

def extract_city_egypt(address):
    """Extract city from Egyptian address."""
    addr_lower = address.lower()
    for city in EGYPT_CITY_KEYWORDS:
        if city.lower() in addr_lower:
            return city
    # Try to extract last significant word group
    parts = [p.strip() for p in address.split(',')]
    # Usually city is in the last non-empty part
    for part in reversed(parts):
        part = part.strip()
        if len(part) > 3 and not re.match(r'^\d', part):
            return part
    return 'Cairo'  # Default for Egypt

def extract_city_ksa(address):
    """Extract city from KSA address."""
    addr_lower = address.lower()
    for city in KSA_CITY_KEYWORDS:
        if city.lower() in addr_lower:
            return city
    # Try address parts
    parts = [p.strip() for p in address.split(',')]
    for part in parts:
        if any(kw.lower() in part.lower() for kw in ['riyadh', 'jeddah', 'makkah', 'madinah', 'khobar', 'dammam']):
            return part.strip()
    return ''

def extract_postcode(address, country):
    """Extract postal code from address based on country."""
    if country == 'SAU':
        # Saudi 5-digit
        match = re.search(r'\b\d{5}\b', address)
        return match.group() if match else ''
    elif country == 'EGY':
        # Egypt 5-digit
        match = re.search(r'\b\d{5}\b', address)
        return match.group() if match else ''
    elif country == 'GBR':
        match = re.search(r'\b[A-Z]{1,2}\d{1,2}[A-Z]?\s*\d[A-Z]{2}\b', address)
        return match.group() if match else ''
    elif country == 'IND':
        match = re.search(r'\b\d{6}\b', address)
        return match.group() if match else ''
    elif country == 'TUR':
        match = re.search(r'\b\d{5}\b', address)
        return match.group() if match else ''
    return ''


def call_branch_api(base_url, settings_id, referer):
    """Call Emirates NBD branch API."""
    data = urllib.parse.urlencode({
        'SettingsId': settings_id,
        'Language': 'en'
    }).encode('utf-8')
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': referer,
        'X-Requested-With': 'XMLHttpRequest',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
    }
    req = urllib.request.Request(
        f'{base_url}/enbdapi/v1/branchatm/getbranchandatms',
        data=data, headers=headers, method='POST'
    )
    with urllib.request.urlopen(req, context=ctx, timeout=30) as r:
        return json.loads(r.read().decode('utf-8', errors='replace'))


def map_category_to_activity(category_name, facilities=None):
    """Map branch category to standardized activity."""
    cat = (category_name or '').lower()
    if 'branch' in cat:
        return 'Banking Branch'
    elif 'itm' in cat or 'interactive teller' in cat:
        return 'Interactive Teller Machine (ITM)'
    elif 'atm' in cat:
        return 'ATM'
    elif 'business banking' in cat:
        return 'Business Banking Centre'
    elif 'private banking' in cat:
        return 'Private Banking Centre'
    return 'Banking Branch'


def process_api_record(branch, source_config):
    """Convert API branch record to output row."""
    country = source_config['country']
    country_iso3 = source_config['country_iso3']
    source_url = source_config['source_url']
    source_type = source_config['source_type']
    
    title = branch.get('Title', '') or ''
    raw_address = branch.get('Address', '') or ''
    lat = branch.get('Latitude', '') or ''
    lon = branch.get('Longitude', '') or ''
    category = branch.get('CategoryName', '') or ''
    emirate_id = branch.get('EmirateId', '') or ''
    
    # Clean address
    address = clean_address(raw_address)
    address_en = transliterate(address)
    
    # Determine city
    emirate_name = EMIRATE_MAP.get(emirate_id, '')
    if country_iso3 == 'ARE':
        city = extract_city_uae(address, emirate_name)
        state = emirate_name
    elif country_iso3 == 'EGY':
        city = extract_city_egypt(address)
        state = ''
    elif country_iso3 == 'SAU':
        city = extract_city_ksa(address)
        state = city  # In Saudi Arabia, city is also state context
    else:
        city = ''
        state = ''
    
    city_en = transliterate(city)
    state_en = transliterate(state)
    
    # Extract postcode
    postcode = extract_postcode(address_en, country_iso3)
    
    # Lat/lon handling
    lat_clean = ''
    lon_clean = ''
    coord_source = ''
    
    if lat and lon:
        try:
            lat_f = float(lat)
            lon_f = float(lon)
            if lat_f != 0 and lon_f != 0:
                lat_clean = str(lat_f)
                lon_clean = str(lon_f)
                coord_source = 'website'
        except:
            pass
    
    activity = map_category_to_activity(category)
    
    # Location name
    loc_name = transliterate(title)
    loc_name_native = title if title != loc_name else ''
    
    # Full address with country for geocoding
    full_address = address_en
    if city_en and city_en.lower() not in full_address.lower():
        full_address = f"{full_address}, {city_en}"
    if country not in full_address:
        full_address = f"{full_address}, {country}"
    
    return {
        'ISSUER_ID': ISSUER_ID,
        'ISSUER_NAME': ISSUER_NAME,
        'LOCATION_NAME': loc_name,
        'LOCATION_ADDRESS': full_address,
        'LATITUDE': lat_clean,
        'LONGITUDE': lon_clean,
        'COUNTRY': country,
        'COUNTRY_ISO3': country_iso3,
        'POSTCODE': postcode,
        'STATE': state_en,
        'CITY': city_en,
        'SOURCE_URL': source_url,
        'SOURCE_TYPE': source_type,
        'ACTIVITY_AT_ASSET': activity,
        'coord_source': coord_source,
        'LOCATION_NAME_NATIVE': loc_name_native,
        'LOCATION_ADDRESS_NATIVE': raw_address if raw_address != address_en else '',
    }


def main():
    print(f"Starting Emirates NBD extraction at {datetime.now()}")
    all_records = []
    
    # === STEP 1: API-based extractions ===
    for source in API_SOURCES:
        print(f"\n--- Extracting {source['country']} ({source['base_url']}) ---")
        try:
            api_data = call_branch_api(
                source['base_url'],
                source['settings_id'],
                source['source_url']
            )
            branches = api_data.get('BranchAtms', [])
            print(f"  Total from API: {len(branches)}")
            
            include_cats = source.get('include_categories', ['Branches'])
            filtered = [b for b in branches if b.get('CategoryName') in include_cats]
            print(f"  After category filter ({include_cats}): {len(filtered)}")
            
            for branch in filtered:
                row = process_api_record(branch, source)
                all_records.append(row)
            
            print(f"  Records added: {len(filtered)}")
        except Exception as e:
            print(f"  ERROR: {e}")
            import traceback
            traceback.print_exc()
    
    # === STEP 2: Manual/static records ===
    print(f"\n--- Adding manual/static records ---")
    for rec in MANUAL_RECORDS:
        row = {
            'ISSUER_ID': ISSUER_ID,
            'ISSUER_NAME': ISSUER_NAME,
            **rec,
            'coord_source': 'not_from_website' if not rec.get('LATITUDE') else 'website',
        }
        # Make sure address is transliterated
        row['LOCATION_ADDRESS'] = transliterate(clean_address(rec['LOCATION_ADDRESS']))
        row['LOCATION_NAME'] = transliterate(rec['LOCATION_NAME'])
        # Ensure city, state
        if not row.get('CITY'):
            row['CITY'] = ''
        all_records.append(row)
        print(f"  Added: {rec['LOCATION_NAME']}")
    
    print(f"\nTotal records collected: {len(all_records)}")
    
    # === STEP 3: Validation ===
    issues = []
    for i, row in enumerate(all_records):
        if not row.get('CITY'):
            issues.append(f"Row {i+1} ({row.get('LOCATION_NAME', '?')}): CITY is blank")
        if not row.get('LOCATION_ADDRESS'):
            issues.append(f"Row {i+1} ({row.get('LOCATION_NAME', '?')}): LOCATION_ADDRESS is blank")
    
    if issues:
        print(f"\nValidation issues ({len(issues)}):")
        for issue in issues[:20]:
            print(f"  {issue}")
    else:
        print("\nValidation: All records have CITY and LOCATION_ADDRESS")
    
    # === STEP 4: Save checkpoint ===
    checkpoint_path = os.path.join(TEMP_DIR, f"emirates_nbd_checkpoint_{datetime.now().strftime('%H%M%S')}.csv")
    
    fieldnames = [
        'ISSUER_ID', 'ISSUER_NAME', 'LOCATION_NAME', 'LOCATION_ADDRESS',
        'LATITUDE', 'LONGITUDE', 'COUNTRY', 'COUNTRY_ISO3', 'POSTCODE',
        'STATE', 'CITY', 'SOURCE_URL', 'SOURCE_TYPE', 'ACTIVITY_AT_ASSET',
        'coord_source', 'LOCATION_NAME_NATIVE', 'LOCATION_ADDRESS_NATIVE'
    ]
    
    with open(checkpoint_path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(all_records)
    
    print(f"\nCheckpoint saved to: {checkpoint_path}")
    print(f"Records at checkpoint: {len(all_records)}")
    
    # === STEP 5: Threshold check ===
    THRESHOLD = 97
    if len(all_records) >= THRESHOLD:
        print(f"\n✓ Threshold of {THRESHOLD} records passed ({len(all_records)} records)")
    else:
        print(f"\n✗ Only {len(all_records)} records — below threshold of {THRESHOLD}")
    
    return all_records, checkpoint_path


if __name__ == '__main__':
    records, checkpoint = main()
