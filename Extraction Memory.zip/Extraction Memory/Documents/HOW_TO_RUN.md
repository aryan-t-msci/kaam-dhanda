# How to run the Extraction Memory batch orchestrator

`run_batch.ps1` **is** the batch orchestrator. You point it at an input `.xlsx`, and it
parses the issuers + their URLs and runs the entire extraction workflow autonomously,
writing one CSV per issuer plus a combined, schema-aligned output set.

---

## What it does (one run, end to end)

For each issuer in your file the orchestrator:

1. **Parses** the issuer ID, name, expected count, and one or more URLs from the workbook.
2. **Spawns a fresh Codex worker** (clean context per issuer), parallelised across a worker pool.
3. **Works the full approach ladder** — store/branch/facility locators first (with hardened
   discovery: XHR endpoint sniffing, per-region/brand sub-locators, sitemap crawl, structured
   data), then official filings / PDFs (annual-report property schedules, 10-K Item 2, etc.) —
   escalating while a result is implausibly thin and **accumulating rows across tiers** (it
   never discards what it already found).
4. **Applies the yield gate** — a suspiciously thin result is retried once with an aggressive
   deep pass; if it is still thin, both attempts are unioned and the issuer is flagged for review.
5. **Applies the quality floor** — rows with no name, no address, and no coordinates are dropped
   (no placeholder/city-centroid padding).
6. **Promotes** the result, then **canonicalises** every output CSV to one shared 19-column
   schema and removes exact-duplicate rows.
7. **Flags for review** any issuer that came back as a gap or a low-yield union.

Geocoding is intentionally out of scope — coordinates are captured only when the source
provides them; the canonical output is handed off to your separate geocoding service.

---

## 1. Prerequisites

- **Windows** with **Windows PowerShell 5.1** (or PowerShell 7).
- **Python 3.13** at `C:\Program Files\Python313\python.exe` with **openpyxl**
  (`py -m pip install openpyxl`). Used to parse the workbook and canonicalise output.
- **Codex CLI** installed (Node + `@openai/codex`) and **authenticated** (`codex login`) —
  each worker runs `codex exec`.
- The **`Extraction Memory` folder** present and intact. The workers read `prompt.md`,
  `WORKER_PROMPT.md`, and the `KB_*.md` files from this folder, so keep them here.
- **Paths set**: open `run_batch.ps1`, find the `CONFIG` block near the top, and confirm
  `MEMORY_FOLDER`, `TEMP_ROOT`, and `OUTPUT_ROOT` point to your folders.

---

## 2. Input file format (Format A or B)

The orchestrator **auto-detects columns by header name**, scans **every sheet**, and finds the
header row automatically (it does **not** need to be the first row). Column order does not matter,
and extra columns (e.g. `URL_Purpose`) are ignored.

Your workbook needs:

| Field | Required? | Accepted header names (case/spacing/punctuation ignored) |
|-------|-----------|----------------------------------------------------------|
| **Issuer ID** | **Required** | `Issuer ID`, `IID`, `MSCI Issuer ID` — values **must start with `IID`** |
| **URL(s)** | Recommended | `Relevant URL(s)`, `Source URL(s)`, `Company URL`, `Company Website`, `Website(s)`, `Web URL`, `Homepage`, `Webpage`, `URL(s)`, `Link(s)` — may be **numbered** (`URL_1`, `URL_2`, …) |
| **Company Name** | Optional | `Company Name`, `Issuer Name`, `Company`, `Issuer`, `Entity Name`, `Name` |
| **Expected Count** | Optional | `Expected Count`, `Total Assets`, `Asset Count`, `Expected Assets`, `Count` (used only to prioritise heaviest-first and as a soft yield reference) |

It accepts **either layout**:

- **Format A — long (one row per URL).** An issuer repeats across several rows, one URL per
  row, in a single URL column. URLs are aggregated per issuer.
- **Format B — wide (one row per issuer).** Each issuer is a single row with several URL
  columns (`URL_1`, `URL_2`, …) **or** one cell holding several URLs separated by newlines,
  commas, semicolons, or pipes. All URLs are captured.

Minimal valid file:

| Issuer ID | Company Name | Expected Count | Relevant URL |
|-----------|--------------|----------------|--------------|
| IID000000002244210 | GS Retail | 18893 | https://www.gsretail.com/... |

> If your headers differ from the accepted names above, just rename them — or ask, and the
> alias list can be extended.

---

## 3. How to run

Open a Command Prompt or PowerShell window. In every example below, replace the script path and
the `-InputFile` path with yours.

### 3a. Run the WHOLE file

```bat
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\<you>\OneDrive - MSCI Office 365\Extraction Memory\run_batch.ps1" -InputFile "C:\path\to\your_file.xlsx" -Limit 100000 -Fresh
```

- `-Limit 100000` (any number at or above the issuer count) processes **every** issuer in the file.
- `-Fresh` starts clean. **Omit it to resume** (see 3d).
- Worker parallelism auto-sizes to your machine; override with `-WorkerCap N`.

### 3b. Run specific issuers (targeted / validation)

```bat
powershell -NoProfile -ExecutionPolicy Bypass -File "...\Extraction Memory\run_batch.ps1" -InputFile "C:\path\to\your_file.xlsx" -IssuerIds "IID000000002244210","IID000000005538588" -RunTag "_check" -Fresh
```

- `-IssuerIds` runs exactly those IDs and **bypasses sampling**.
- `-RunTag "_check"` isolates this run in its own temp/output folder, so it won't touch your other runs.

### 3c. Run a sampled subset (quick test)

```bat
powershell -NoProfile -ExecutionPolicy Bypass -File "...\Extraction Memory\run_batch.ps1" -InputFile "C:\path\to\your_file.xlsx" -Limit 50 -Fresh
```

- Selects `ceil(25%)` of the heaviest issuers + the remainder at random (50 total). Each `-Fresh`
  draws a **new** random sample; reproduce a specific draw with `-Seed 12345`.

### 3d. Resume an interrupted or halted run

Re-run the **exact same command without `-Fresh`**. Completed issuers are skipped; only the
unfinished ones run.

```bat
powershell -NoProfile -ExecutionPolicy Bypass -File "...\Extraction Memory\run_batch.ps1" -InputFile "C:\path\to\your_file.xlsx" -Limit 100000
```

### 3e. Options reference

| Option | Default | Purpose |
|--------|---------|---------|
| `-InputFile <path>` | (sample path) | The input `.xlsx`. |
| `-Limit <n>` | `50` | Max issuers to process. Use a large number to run the whole file. |
| `-Fresh` | off | Wipe this run's prior progress, staging, status, and output, and start over. **Required for a clean re-run** of the same file. |
| `-WorkerCap <n>` | `0` (auto) | Parallel workers. `0` auto-sizes to RAM/cores; a positive value forces a fixed cap. |
| `-MaxWorkerMinutes <n>` | `90` | Active-minute timeout before a stuck worker is killed. Raise it for very large issuers (deep filing/PDF work). |
| `-IssuerIds "IID..","IID.."` | (none) | Run exactly these issuers; bypasses sampling. |
| `-ScopeDoc "<path/URL>"` | (bundled) | Override the scope/ownership methodology. Blank uses `SCOPE_METHODOLOGY.md` in the memory folder. |
| `-RunTag "_x"` | (empty) | Isolate the run in its own temp/output folder (`Run_<file>_x`). |
| `-Seed <n>` | `0` (random) | Reproduce a specific random sample. |
| `-MinYieldFloor <n>` | `3` | Always retry a result with fewer than this many rows. |
| `-MinYieldFraction <f>` | `0.30` | Also retry a small result below this fraction of the expected count... |
| `-YieldOkAbs <n>` | `25` | ...but never retry a result with at least this many rows (guards against unreliable counts). |
| `-Model <name>` | `gpt-5.4` | Worker model. |
| `-Reasoning <level>` | `high` | Worker reasoning effort. |

---

## 4. What you'll see while it runs

- One `queued: IID... | name | target=N | urls=K` line per issuer, then `spawned worker ...`.
- A `[MONITOR] promoted=.. | failed=.. | active=X/cap` line about every 20 seconds.
  **`active` should stay above 0 for a while** — real extraction takes minutes to a couple of
  hours per issuer. (A run that finishes in under a minute means nothing actually ran — see
  Troubleshooting.)
- `promoted IID... -> output (N rows)` on success.
- `LOW YIELD ... re-queuing ONE retry`, or `... UNION of 2 attempts ... FLAGGED FOR REVIEW`,
  for thin results; `... worker declared a GAP, flagged for review` when sources don't cover the
  full universe.
- At the end, a **canonicalise report** (files, columns, exact dups removed, empty rows dropped,
  address collisions kept) and the output-folder path.

---

## 5. Where the output goes

Inside `OUTPUT_ROOT\Run_<inputname>[<RunTag>]\`:

- **`IID..._<name>.csv`** — one per issuer, all sharing the same 19-column schema (ready to
  concatenate and hand to geocoding).
- **`_canonicalize_report.txt`** — row counts, dedupe summary, empties dropped, collisions kept.

Inside `TEMP_ROOT\Run_<inputname>[<RunTag>]\`:

- **`review_iids.txt`** — issuers flagged for a human look (gap or low-yield union), each with a
  reason. Start your QA here.
- `logs\`, `staging\`, `status\`, `workers\`, `gap\`, `reject\`, `exhaustion_proof\` — run internals.

---

## 6. Tuning & troubleshooting

- **A worker gets killed while still working** (big REIT / large locator): raise
  `-MaxWorkerMinutes` (e.g. `180`).
- **Machine sleep:** the run suppresses sleep automatically, and any sleep that still occurs is
  excluded from worker timeouts — so a long run survives the laptop dozing.
- **The run finished in under a minute:** nothing actually extracted. Confirm Codex is
  authenticated (`codex login`) and that you passed `-Fresh` (a fresh run clears prior staging /
  DONE flags so it re-extracts instead of promoting old files).
- **"no IID issuers found":** the ID column wasn't recognised, or the IDs don't start with `IID`.
  Check your header names against the table in section 2.
- **Cost** scales with the number and difficulty of issuers (roughly a few dollars each for hard
  ones); locator-friendly issuers are cheap.
- **Resuming after a halt:** just re-run the same command without `-Fresh`.
