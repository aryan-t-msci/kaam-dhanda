"""
SABIC location extractor.

Enumerates official SABIC location pages from the public sitemap and exports
address-bearing location records. This revision scopes extraction to the SABIC
contact and functions blocks instead of scraping flattened page text.
"""

from __future__ import annotations

import csv
import json
import re
from pathlib import Path
from typing import Iterable
from urllib.parse import unquote, urlparse
from xml.etree import ElementTree

import requests
import urllib3
from bs4 import BeautifulSoup


# CONFIGURATION
ISSUER_ID = "IID000000002182781"
ISSUER_NAME = "Saudi Basic Industries Corporation SJSC"
SITEMAP_URL = "https://www.sabic.com/en/sitemap.xml"
OUTPUT_DIR = Path(".")
OUTPUT_CSV = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
PROGRESS_JSON = OUTPUT_DIR / "progress.json"

VERIFY_SSL = False
TIMEOUT_SECONDS = 45
MAX_RETRIES = 3


HEADERS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
]


COUNTRY_TO_ISO3 = {
    "Argentina": "ARG",
    "Australia": "AUS",
    "Austria": "AUT",
    "Belgium": "BEL",
    "Brazil": "BRA",
    "Canada": "CAN",
    "China": "CHN",
    "Czech Republic": "CZE",
    "Denmark": "DNK",
    "Finland": "FIN",
    "France": "FRA",
    "Georgia": "GEO",
    "Germany": "DEU",
    "Greece": "GRC",
    "Hong Kong": "HKG",
    "Hungary": "HUN",
    "India": "IND",
    "Indonesia": "IDN",
    "Iraq": "IRQ",
    "Italy": "ITA",
    "Japan": "JPN",
    "Jordan": "JOR",
    "Kenya": "KEN",
    "Mexico": "MEX",
    "Morocco": "MAR",
    "Netherlands": "NLD",
    "Pakistan": "PAK",
    "Poland": "POL",
    "Portugal": "PRT",
    "Russia": "RUS",
    "Saudi Arabia": "SAU",
    "Singapore": "SGP",
    "South Africa": "ZAF",
    "South Korea": "KOR",
    "Spain": "ESP",
    "Sweden": "SWE",
    "Taiwan": "TWN",
    "Thailand": "THA",
    "Tunisia": "TUN",
    "Turkey": "TUR",
    "United Arab Emirates": "ARE",
    "United Kingdom": "GBR",
    "United States of America": "USA",
    "Vietnam": "VNM",
}


COUNTRY_ALIASES = {
    "argentina": "Argentina",
    "australia": "Australia",
    "austria": "Austria",
    "belgium": "Belgium",
    "brazil": "Brazil",
    "canada": "Canada",
    "china": "China",
    "czech republic": "Czech Republic",
    "denmark": "Denmark",
    "finland": "Finland",
    "france": "France",
    "georgia": "Georgia",
    "germany": "Germany",
    "greece": "Greece",
    "hong kong": "Hong Kong",
    "hungary": "Hungary",
    "india": "India",
    "indonesia": "Indonesia",
    "iraq": "Iraq",
    "italy": "Italy",
    "japan": "Japan",
    "jordan": "Jordan",
    "kenya": "Kenya",
    "mexico": "Mexico",
    "morocco": "Morocco",
    "netherlands": "Netherlands",
    "pakistan": "Pakistan",
    "poland": "Poland",
    "portugal": "Portugal",
    "russia": "Russia",
    "saudi arabia": "Saudi Arabia",
    "singapore": "Singapore",
    "south africa": "South Africa",
    "south korea": "South Korea",
    "spain": "Spain",
    "sweden": "Sweden",
    "taiwan": "Taiwan",
    "thailand": "Thailand",
    "tunisia": "Tunisia",
    "turkey": "Turkey",
    "uae": "United Arab Emirates",
    "united arab emirates": "United Arab Emirates",
    "uk": "United Kingdom",
    "united kingdom": "United Kingdom",
    "united kingdom and northern ireland": "United Kingdom",
    "usa": "United States of America",
    "united states of america": "United States of America",
    "vietnam": "Vietnam",
}


SLUG_COUNTRY_ALIASES = {
    "argentina": "Argentina",
    "australia": "Australia",
    "austria": "Austria",
    "belgium": "Belgium",
    "brazil": "Brazil",
    "canada": "Canada",
    "china": "China",
    "czech-republic": "Czech Republic",
    "denmark": "Denmark",
    "finland": "Finland",
    "france": "France",
    "georgia": "Georgia",
    "germany": "Germany",
    "greece": "Greece",
    "hong-kong": "Hong Kong",
    "hungary": "Hungary",
    "india": "India",
    "indonesia": "Indonesia",
    "iraq": "Iraq",
    "italy": "Italy",
    "japan": "Japan",
    "jordan": "Jordan",
    "kenya": "Kenya",
    "mexico": "Mexico",
    "morocco": "Morocco",
    "pakistan": "Pakistan",
    "poland": "Poland",
    "portugal": "Portugal",
    "russia": "Russia",
    "saudi-arabia": "Saudi Arabia",
    "singapore": "Singapore",
    "south-africa": "South Africa",
    "south-korea": "South Korea",
    "spain": "Spain",
    "sweden": "Sweden",
    "taiwan": "Taiwan",
    "thailand": "Thailand",
    "the-netherlands": "Netherlands",
    "tunisia": "Tunisia",
    "turkey": "Turkey",
    "united-arab-emirates": "United Arab Emirates",
    "united-kingdom-and-northern-ireland": "United Kingdom",
    "united-states-of-america": "United States of America",
    "vietnam": "Vietnam",
}


POSTCODE_PATTERNS = {
    "Brazil": re.compile(r"\b\d{5}-\d{3}\b"),
    "Canada": re.compile(r"\b[ABCEGHJ-NPRSTVXY]\d[ABCEGHJ-NPRSTV-Z][ -]?\d[ABCEGHJ-NPRSTV-Z]\d\b", re.I),
    "Czech Republic": re.compile(r"\b\d{3}\s?\d{2}\b"),
    "Denmark": re.compile(r"\b\d{4}\b"),
    "Finland": re.compile(r"\b\d{5}\b"),
    "Germany": re.compile(r"\b\d{5}\b"),
    "Hungary": re.compile(r"\b\d{4}\b"),
    "India": re.compile(r"\b\d{6}\b"),
    "Indonesia": re.compile(r"\b\d{5}\b"),
    "Italy": re.compile(r"\b\d{5}\b"),
    "Japan": re.compile(r"\b\d{3}-?\d{4}\b"),
    "Morocco": re.compile(r"\b\d{5}\b"),
    "Netherlands": re.compile(r"\b\d{4}\s?[A-Z]{2}\b", re.I),
    "Poland": re.compile(r"\b\d{2}-\d{3}\b"),
    "Russia": re.compile(r"\b\d{6}\b"),
    "Saudi Arabia": re.compile(r"\b\d{5}\b"),
    "South Africa": re.compile(r"\b\d{4}\b"),
    "South Korea": re.compile(r"\b\d{5}\b"),
    "Sweden": re.compile(r"\b\d{3}\s?\d{2}\b"),
    "Thailand": re.compile(r"\b\d{5}\b"),
    "United Kingdom": re.compile(r"\b[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}\b", re.I),
    "United States of America": re.compile(r"\b\d{5}(?:-\d{4})?\b"),
}


NON_PHYSICAL_PREFIXES = ("available ",)
STREET_TOKEN_HINTS = (
    " street",
    " st ",
    " road",
    " rd ",
    " avenue",
    " ave",
    " boulevard",
    " blvd",
    " drive",
    " dr ",
    " lane",
    " ln ",
    " way",
    " straat",
    " laan",
    " naberezhnaya",
)


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "Mozilla/5.0"})


def load_progress() -> set[str]:
    if PROGRESS_JSON.exists():
        return set(json.loads(PROGRESS_JSON.read_text(encoding="utf-8")))
    return set()


def save_progress(seen: set[str]) -> None:
    PROGRESS_JSON.write_text(json.dumps(sorted(seen), indent=2), encoding="utf-8")


def normalize_space(text: str) -> str:
    text = text.replace("\u2013", "-").replace("\u2014", "-").replace("\xa0", " ")
    return re.sub(r"\s+", " ", text).strip()


def canonical_url(url: str) -> str:
    return url.replace("http://", "https://", 1)


def fetch(url: str) -> requests.Response:
    last_error: Exception | None = None
    for _ in range(MAX_RETRIES):
        try:
            response = SESSION.get(url, timeout=TIMEOUT_SECONDS, verify=VERIFY_SSL)
            response.raise_for_status()
            return response
        except requests.RequestException as exc:
            last_error = exc
    assert last_error is not None
    raise last_error


def fetch_location_urls() -> list[str]:
    root = ElementTree.fromstring(fetch(SITEMAP_URL).content)
    urls: list[str] = []
    for loc in root.findall(".//{*}loc"):
        text = normalize_space(loc.text or "")
        if "/en/locations/" in text:
            urls.append(canonical_url(text))
    return sorted(set(urls))


def extract_name(soup: BeautifulSoup) -> str:
    heading = soup.find("h1")
    if heading:
        return normalize_space(heading.get_text(" ", strip=True))
    if soup.title:
        title = normalize_space(soup.title.get_text(" ", strip=True))
        title = re.sub(r"^SABIC\s*-\s*", "", title, flags=re.I)
        return title
    return ""


def extract_address(contact_block: BeautifulSoup | None) -> str:
    if not contact_block:
        return ""
    for paragraph in contact_block.select("p"):
        text = normalize_space(paragraph.get_text(" ", strip=True))
        if text.lower().startswith("address:"):
            return normalize_space(text.split(":", 1)[1])
    return ""


def extract_functions(soup: BeautifulSoup) -> list[str]:
    values: list[str] = []
    for item in soup.select("div.block.location.functions li"):
        text = normalize_space(item.get_text(" ", strip=True))
        if text and text not in values:
            values.append(text)
    return values


def infer_activity(name: str, url: str, functions: list[str]) -> str:
    if functions:
        return "; ".join(functions)

    combined = normalize_space(f"{name} {urlparse(url).path}").lower()
    if "technical answer center" in combined:
        return "Technical support"
    if "head office" in combined or "headquarters" in combined or "(hq)" in combined:
        return "Headquarters"
    if "technology center" in combined or "research" in combined or "innovation" in combined:
        return "Technology & Innovation"
    if "manufacturing" in combined or "site" in combined or "plant" in combined:
        return "Manufacturing"
    if "sales" in combined:
        return "Sales"
    if "office" in combined or "branch" in combined:
        return "Office"
    return "Office"


def slug_text(url: str) -> str:
    return unquote(urlparse(url).path.rstrip("/").split("/")[-1]).lower()


def infer_country(address: str, name: str, url: str) -> str:
    haystack = normalize_space(f"{address} {name}").casefold()
    for alias, country in sorted(COUNTRY_ALIASES.items(), key=lambda item: len(item[0]), reverse=True):
        if alias in haystack:
            return country

    slug = slug_text(url)
    for alias, country in sorted(SLUG_COUNTRY_ALIASES.items(), key=lambda item: len(item[0]), reverse=True):
        if alias in slug:
            return country
    return ""


def extract_postcode(address: str, country: str) -> str:
    pattern = POSTCODE_PATTERNS.get(country)
    if pattern:
        matches = pattern.findall(address)
        if matches:
            return normalize_space(matches[-1])
    generic = re.findall(r"\b[A-Z0-9]{3,10}\b", address)
    return generic[-1] if generic else ""


def strip_country_aliases(text: str) -> str:
    result = text
    for alias in sorted(COUNTRY_ALIASES, key=len, reverse=True):
        result = re.sub(rf"\b{re.escape(alias)}\b", "", result, flags=re.I)
    return normalize_space(result)


def strip_postcode(token: str, country: str) -> str:
    pattern = POSTCODE_PATTERNS.get(country)
    if pattern:
        token = pattern.sub("", token)
    return normalize_space(token)


def trailing_city_phrase(token: str) -> str:
    token = normalize_space(token)
    if not token:
        return ""
    match = re.search(r"([A-Za-zÀ-ÿ][A-Za-zÀ-ÿ'./&-]*(?:[ -][A-Za-zÀ-ÿ][A-Za-zÀ-ÿ'./&-]*){0,5})$", token)
    return normalize_space(match.group(1)) if match else ""


def city_from_name(name: str, country: str) -> str:
    parts = [normalize_space(part) for part in name.split(" - ") if normalize_space(part)]
    if len(parts) >= 3 and parts[0].casefold() == country.casefold():
        return parts[1]
    if len(parts) < 2:
        return ""
    tail = parts[1]
    if country == "United Arab Emirates":
        match = re.search(r"\b([A-Za-zÀ-ÿ-]+)\s+office\b", tail, re.I)
        if match:
            return normalize_space(match.group(1))
    if "," in tail:
        return normalize_space(tail.split(",", 1)[0])
    return ""


def extract_city(address: str, country: str, name: str) -> str:
    address_lower = address.casefold()
    tokens = [normalize_space(part) for part in address.replace(";", ",").split(",") if normalize_space(part)]

    if country == "United States of America" and len(tokens) >= 2:
        tail = tokens[-1]
        if re.search(r"\b(?:[A-Z]{2}|[A-Za-z][A-Za-z .'-]+)\s+\d{5}(?:-\d{4})?\b", tail):
            candidate = trailing_city_phrase(tokens[-2])
            if candidate:
                return candidate
    if country == "Canada" and "cobourg" in address_lower:
        return "Cobourg"
    if country == "Brazil":
        if "são paulo" in address_lower or "sao paulo" in address_lower:
            return "Sao Paulo"
        if "campinas" in address_lower:
            return "Campinas"
    if country == "Mexico" and len(tokens) >= 2 and len(normalize_space(tokens[-1])) <= 4:
        candidate = trailing_city_phrase(tokens[-2])
        if candidate:
            return candidate
    if country == "United Arab Emirates" and "dubai" in address_lower:
        return "Dubai"
    if country == "Saudi Arabia":
        for known_city in ("Al-Jubail", "Riyadh", "Jeddah", "Thuwal"):
            if known_city.casefold() in address_lower:
                return known_city
    if country == "Kenya" and "nairobi" in address_lower:
        return "Nairobi"
    if country == "Singapore":
        return "Singapore"

    for token in reversed(tokens):
        candidate = strip_country_aliases(token)
        candidate = strip_postcode(candidate, country)
        candidate = re.sub(r"(?i)^zip code:\s*", "", candidate)
        candidate = re.sub(r"(?i)^dist\.?\s*", "", candidate)
        candidate = re.sub(r"(?i)^suite\s*[\w/-]+\s*", "", candidate)
        candidate = re.sub(r"(?i)^floor\s*[\w/-]+\s*", "", candidate)
        candidate = re.sub(r"(?i)^office\s*no\.?\s*[\w/-]+\s*", "", candidate)
        candidate = re.sub(r"(?i)^unit\s*[\w/-]+\s*", "", candidate)
        candidate = re.sub(r"(?i)^room\s*[\w/-]+\s*", "", candidate)
        candidate = normalize_space(candidate)
        lower = candidate.casefold()
        if not candidate:
            continue
        if len(candidate) <= 3:
            continue
        if lower.startswith("po box") or lower.startswith("p.o. box"):
            continue
        if country == "United States of America" and re.fullmatch(r"[A-Z]{2}", candidate):
            continue
        phrase = trailing_city_phrase(candidate)
        phrase_lower = phrase.casefold()
        if not phrase:
            continue
        if phrase_lower in {"the", "and", "office", "site", "plant"}:
            continue
        if any(hint in phrase_lower for hint in STREET_TOKEN_HINTS) and re.search(r"\d", phrase):
            continue
        if country == "China" and "district" in phrase_lower:
            fallback = city_from_name(name, country)
            if fallback:
                return fallback
        return phrase

    fallback = city_from_name(name, country)
    return normalize_space(fallback)


def extract_state(address: str, country: str) -> str:
    if country == "United States of America":
        match = re.search(r",\s*([A-Z]{2})\s+\d{5}(?:-\d{4})?", address)
        if match:
            return match.group(1)
        match = re.search(r",\s*([A-Za-z][A-Za-z .'-]+)\s+\d{5}(?:-\d{4})?", address)
        return normalize_space(match.group(1)) if match else ""
    if country == "Canada":
        match = re.search(r"-\s*([A-Za-z ]+)\s*,?\s*Canada$", address, re.I)
        if match:
            return normalize_space(match.group(1))
        provinces = {
            "Ontario",
            "Quebec",
            "British Columbia",
            "Alberta",
            "Manitoba",
            "Saskatchewan",
            "Nova Scotia",
            "New Brunswick",
            "Newfoundland and Labrador",
            "Prince Edward Island",
        }
        for province in provinces:
            if province.casefold() in address.casefold():
                return province
    if country == "Brazil":
        match = re.search(r"(?:-\s*|,\s*)([A-Z]{2})\s*,?\s*Brazil", address)
        return match.group(1) if match else ""
    if country == "Mexico":
        tokens = [normalize_space(part) for part in address.replace(";", ",").split(",") if normalize_space(part)]
        if tokens and len(tokens[-1]) <= 4:
            return tokens[-1]
    if country == "Australia":
        for code in ("NSW", "VIC", "QLD", "WA", "SA", "TAS"):
            if re.search(rf"\b{code}\b", address):
                return code
    return ""


def looks_physical(address: str) -> bool:
    lower = address.casefold()
    return not any(lower.startswith(prefix) for prefix in NON_PHYSICAL_PREFIXES)


def parse_location_page(url: str) -> dict | None:
    soup = BeautifulSoup(fetch(url).text, "html.parser")
    name = extract_name(soup)
    contact_block = soup.select_one("div.block.location.contact_details")
    address = extract_address(contact_block)
    if not address or not looks_physical(address):
        return None

    functions = extract_functions(soup)
    country = infer_country(address, name, url)
    city = extract_city(address, country, name)
    postcode = extract_postcode(address, country)
    state = extract_state(address, country)
    activity = infer_activity(name, url, functions)

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": name,
        "LOCATION_ADDRESS": address,
        "LATITUDE": "",
        "LONGITUDE": "",
        "COUNTRY": country,
        "COUNTRY_ISO3": COUNTRY_TO_ISO3.get(country, ""),
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": url,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": activity,
        "coord_source": "Not from website",
    }


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    seen = load_progress()
    rows: list[dict[str, str]] = []
    for idx, url in enumerate(fetch_location_urls(), 1):
        if url in seen:
            continue
        row = parse_location_page(url)
        if row:
            rows.append(row)
        seen.add(url)
        if idx % 20 == 0:
            save_progress(seen)
    save_progress(seen)
    rows.sort(key=lambda row: row["SOURCE_URL"])
    with OUTPUT_CSV.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=HEADERS)
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()
