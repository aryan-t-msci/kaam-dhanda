# Extraction Memory — Operator Runbook

A complete, from-zero guide to running the facility-location extraction workflow on your own
machine. No prior familiarity assumed. If you just want the command reference, jump to section 5;
if you want to run from Codex Desktop, jump to section 6.

---

## 0. What this is

Given a spreadsheet of issuers (a company id, a name, an expected facility count, and some URLs),
the system visits each company's web sources and extracts a clean list of their physical
facilities (name, address, coordinates if present) into a CSV — one CSV per issuer, all
conformed to a single 19-column schema. It is autonomous: you start it, it works through the
list, and it flags anything it couldn't fully resolve.

## 1. How it works (the mental model)

- An **orchestrator** reads your input file, builds a queue, and spawns **one isolated worker per
  issuer** in a rolling pool (several at once). Each worker is a fresh `codex exec` conversation
  with a clean context — so one issuer can't contaminate another.
- Each worker runs a fixed pipeline: **recon → extract → validate → QA → update the knowledge
  base**. It tries cheap approaches first (static fetch, then APIs) and escalates (browser
  rendering, filings) only if needed.
- A shared **knowledge base** (`KB_INDEX.md` + per-record files in `KB/`) lets a worker reuse what
  past runs learned about a site or platform, and append new lessons. This is what keeps cost
  down and quality up over time.
- There are **two ways to run it**: a PowerShell loop (`run_batch.ps1`, section 5 — best for large
  batches and full control) and Codex Desktop (an orchestrator prompt, section 6 — agent-native,
  convenient, fewer parallel workers).

## 2. Prerequisites

This is a **Windows + PowerShell** workflow (PowerShell 5.1+). On macOS/Linux the `.ps1` would need
adapting; the Codex Desktop path (section 6) is OS-independent.

Install these once:

1. **Python 3.x** (tested on 3.13). Add to PATH. Then install the packages the run uses:
   ```bat
   pip install openpyxl httpx requests playwright
   playwright install chromium
   ```
   `openpyxl` is required for the input parser. `httpx`/`requests`/`playwright` are used by
   workers (workers run with shell access and can install more on the fly, but installing these
   up front avoids first-run stalls). Workers prefer the Edge browser channel, which Windows
   already has; `playwright install chromium` covers the rest.

2. **Node.js (LTS)** with the **Codex CLI** installed globally:
   ```bat
   npm install -g @openai/codex
   ```
   `run_batch.ps1` auto-discovers `codex.js` from your global npm folder, so no path editing is
   needed. (If discovery ever fails, pass `-CodexCli "C:\path\to\@openai\codex\bin\codex.js"`.)

3. **Authenticate the Codex CLI** so it can call the model — e.g. run `codex login` (or configure
   your API key per the Codex CLI docs). Verify it works:
   ```bat
   codex exec "say hello"
   ```
   If that returns a reply, you're ready.

A machine with more cores/RAM runs more workers in parallel (the cap auto-sizes).

## 3. One-time setup

1. Unzip the **Extraction Memory** folder anywhere you like (it can live on OneDrive). Everything
   the system needs — `run_batch.ps1`, the prompts, the `KB/` knowledge base, `Tools/`,
   `canonicalize_output.py` — lives inside it. This folder is the **MEMORY_FOLDER**.
2. That's it. The knowledge base shards build themselves on the first run (you'll see a one-time
   `[shard]` line), and `run_batch.ps1` always uses the prompts/KB sitting next to it — so just run
   the copy inside the folder you unzipped.

## 4. The input file

A single `.xlsx`. The parser auto-detects the header row and columns by name, and accepts two
common layouts:

- **Format A (one sheet, one row per URL):** columns like `ISSUER_ID`, `ISSUER_NAME`,
  `COUNT` (expected facilities), `URL`, and optionally `URL_Type`. Multiple rows per issuer are
  aggregated.
- **Format B (two sheets):** Sheet 1 has `Issuer ID`, `Issuer Name`, `Expected Count`; Sheet 2 has
  `ISSUER_ID`, `COMPANY_NAME`, `relevant_url`. Multiple URL columns (`url_1`, `url_2`, …) and
  multi-URL cells are handled; non-URL lookalike columns (e.g. `url_purpose`) are ignored.

Accepted header names (any one per concept): id = `issuerid` / `iid` / `msciissuerid`;
name = `issuername` / `companyname` / `name`; count = `count` / `expectedcount` / `target`;
url = `url` / `relevanturl` / `weburl` (with optional numeric suffixes).

## 5. Running it — Path A: PowerShell (`run_batch.ps1`)

This is the recommended path for anything beyond a handful of issuers: more parallelism, full
control, and it won't drop turns on long runs.

### The command

Open PowerShell, then run the copy of the script **inside your unzipped folder**:

```powershell
cd "C:\path\to\Extraction Memory"

powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch.ps1" `
  -InputFile  "C:\path\to\your_issuers.xlsx" `
  -OutputRoot "C:\path\to\output" `
  -TempRoot   "C:\path\to\temp" `
  -Model      "gpt-5.4" `
  -Reasoning  "high" `
  -Limit      100000 `
  -Fresh
```

That processes the **whole file** (`-Limit 100000` is just a number bigger than any issuer count)
on gpt-5.4 / high, writing output and logs where you pointed. Drop or change any line to use its
default.

### Every knob

| You want to set      | Flag             | Default                              |
|----------------------|------------------|--------------------------------------|
| Model                | `-Model`         | `gpt-5.4`                            |
| Reasoning level      | `-Reasoning`     | `high` (also `medium`, `low`)        |
| Input workbook       | `-InputFile`     | a sample path — set your own         |
| Output folder        | `-OutputRoot`    | a sample path — set your own         |
| Temp / logs folder   | `-TempRoot`      | a sample path — set your own         |
| Prompts + KB folder  | `-MemoryFolder`  | the folder the script lives in       |
| Codex CLI path       | `-CodexCli`      | auto-discovered from global npm      |
| Scope methodology    | `-ScopeDoc`      | blank = bundled SCOPE_METHODOLOGY.md |
| How many issuers     | `-Limit`         | `50` (sampled)                       |
| Exact issuers        | `-IssuerIds`     | none — `IID...,IID...` to target     |
| Parallel workers     | `-WorkerCap`     | `0` = auto-size to the machine       |
| Reproducible sample  | `-Seed`          | `0` = new random draw each time      |
| Isolate this run     | `-RunTag`        | none — a suffix to keep runs apart   |
| Start clean          | `-Fresh`         | off — omit to resume instead         |

### Choosing scope

- **Whole file:** `-Limit 100000`.
- **A sample:** `-Limit 50` (picks ≥25% heaviest + the rest random). Add `-Seed 12345` to reproduce
  the same sample later.
- **Specific issuers:** `-IssuerIds IID000000002244210,IID000000005538588` (sampling bypassed).

### Fresh vs resume

- **Fresh:** add `-Fresh` to wipe that run key's prior progress and start over.
- **Resume:** re-run the *exact same command without `-Fresh`* — it picks up where it left off and
  only does issuers not yet finished.

## 6. Running it — Path B: Codex Desktop (orchestrator trigger)

Agent-native and convenient. Open a Codex Desktop conversation with your Extraction Memory folder
accessible, and **paste the trigger below** with your four paths filled in. That conversation
becomes the orchestrator and runs everything itself.

```
From MEMORY_FOLDER, read and execute these files in order:
1. prompt.md
2. ORCHESTRATOR_PROMPT.md

MEMORY_FOLDER : C:\path\to\Extraction Memory
INPUT_FILE    : C:\path\to\your_issuers.xlsx
TEMP_FOLDER   : C:\path\to\temp
OUTPUT_FOLDER : C:\path\to\output
SCOPE_METHODOLOGY : (optional — blank uses SCOPE_METHODOLOGY.md in MEMORY_FOLDER)
```

Notes specific to this path:

- **Model and reasoning are chosen by the Desktop conversation's selected tier** — there is no
  `-Model`/`-Reasoning` flag here. The orchestrator makes every worker match the conversation's
  model, so pick the tier you want before sending. Use a current tier (Codex 5.4+); older ones can
  mis-handle the orchestrator role and stall after setup.
- The orchestrator must **not** spawn a separate agent "to run the orchestrator" — the conversation
  you pasted into *is* the orchestrator. The prompt enforces this; just don't intervene.
- Parallelism is lower than the CLI (~5 workers, the agent cap). Great for a test or a small set;
  for the full universe, use Path A.
- The KB shards bootstrap automatically as the orchestrator's first setup step.

For a single company instead of a batch, use the single-issuer block in `Documents/PROMPTS.md`.

## 7. What happens during a run

Each worker, per issuer:
1. **Recon** — fetch raw HTML/JSON with `httpx`/`requests`; identify the site type and any
   store/branch/plant locator or data API.
2. **Extract** — pull facilities, escalating only as needed: static → API sniffing → browser
   rendering (Playwright) → company filings/reports → secondary sources.
3. **Validate & QA** — clean addresses, keep going past the expected COUNT, drop unusable rows.
4. **Knowledge base** — if the result is solid and meets the count, append what it learned as a new
   `KB/` record (+ an index row) for future reuse; thin/gap results don't auto-write.

If a worker can't reach the expected count from the supplied sources, it **declares a GAP** and is
flagged for review — that's the system being honest, not failing. After the main pass, gap issuers
automatically enter a rework pass.

## 8. Monitoring while it runs

The console prints a heartbeat every ~20 seconds:

```
[MONITOR] promoted=1 | failed=0 | active=2/21 (cap=21 auto) | queued=0
```

`active` = workers running now · `promoted` = finished and written to output · `queued` = waiting
for a free slot. When `promoted` reaches the target and `active=0`, the pass is complete. The
startup log also prints `MemoryFolder=…`, `Output=…`, `Temp=…` so you can confirm what's active.

## 9. Outputs and how to read them

After the pass, the script conforms every per-issuer CSV to the current 23-column schema and prints
a canonicalize report. The schema includes the scope/provenance columns: `SCOPE`, `SCOPE_REASON`,
`RELEVANT_URL` (official 1P/2P source), `SOURCE_TYPE` (1P/2P only), `VALIDATION_URL` +
`VALIDATION_SOURCE_TYPE` (third-party enrichment), and `FACILITY_CONTACT_NUMBER`. Older CSVs written
under the previous column names are auto-renamed to the current schema on canonicalize. Look under:

- **Output:** `<OutputRoot>\Run_<inputname><tag>\` — one CSV per issuer, plus
  `_canonicalize_report.txt` (rows in/out, empty rows dropped as unusable, address collisions
  intentionally kept).
- **Review:** issuers whose worker declared a GAP are flagged for review (see the run folder's
  review list and the `… worker declared a GAP, flagged for review` log lines).
- **Logs / staging / per-worker logs:** `<TempRoot>\Run_<inputname><tag>\` (worker logs live under
  `workers\`).

## 10. Troubleshooting

| Symptom | Cause / fix |
|---------|-------------|
| `codex.js not found` | Codex CLI not installed globally. Run `npm install -g @openai/codex`, or pass `-CodexCli "...\@openai\codex\bin\codex.js"`. |
| `No Python interpreter found` | Python not on PATH. Install it, then `pip install openpyxl`. |
| `openpyxl not available` / parser produced no output | `pip install openpyxl` for the same Python the script found. |
| `Parser returned 0 issuers` | Header/column names not recognized, or wrong sheet. Check against section 4's accepted names. |
| Run "finished in under a minute" | It resumed (nothing left to do). Add `-Fresh` to start over. |
| OneDrive download popups / sync contention on big runs | Point `-TempRoot` and `-OutputRoot` at a **local** (non-OneDrive) folder. MEMORY_FOLDER can stay on OneDrive. |
| Desktop run stalls right after setup | Older model tier mis-delegated the orchestrator role. Use Codex 5.4+ for the Desktop path. |
| Wrong prompts/KB used | Confirm the startup `MemoryFolder=…` line points at the folder you intend; run the `run_batch.ps1` inside that folder. |

## 11. A safety note worth reading

Workers fetch untrusted web content and (by design) run unsandboxed with shell and network access,
and they write to a knowledge base that future runs read back. That is a real prompt-injection
surface: a malicious or compromised page in the fetch path, or an untrusted URL in your input list,
could in principle steer a worker. Treat the **input URL list as a trust boundary**, prefer
official company domains, and review new KB records before relying on them. See the security
assessment notes for the full picture and recommended hardening before running this against large,
externally-sourced URL lists.

## 12. Where to look next

- `Documents/FRESH_RUN_WALKTHROUGH.md` — the run command and every knob, in depth.
- `Documents/PROMPTS.md` — all the paste-ready trigger prompts (batch, single-issuer, fallback).
- `Documents/TOKEN_OPTIMIZATION.md` + `kb_access_pattern.svg` — how/why the system is token-efficient.
- `Documents/KB_SHARDING.md` — the knowledge-base sharding (migrate / validate / retire).
