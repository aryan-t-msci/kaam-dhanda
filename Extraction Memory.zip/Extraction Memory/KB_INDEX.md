# Extraction Knowledge Base â€” INDEX
**Version:** 5.1 | **Last Updated:** 2026-10-02
**Companion file:** `KB/` folder (one small file per record: KB/P-XX.md, KB/R-XX.md, KB/U-XX.md, KB/D-XX.md)

> **How to use this file:**
> Read this index FIRST on every task. It gives you the decision tree, the full
> platform pattern list, and the complete script inventory â€” everything you need
> to pick the right approach in under 2 minutes. Only open the specific `KB/<id>.md` record for the
> detailed implementation of a specific pattern or company record.

---

## TABLE OF CONTENTS

| # | Section | What it answers |
|---|---------|-----------------|
| 1 | [Decision Tree](#1-decision-tree) | What approach should I start with? |
| 2 | [Platform Pattern Catalogue](#2-platform-pattern-catalogue) | What pattern matches this site? |
| 3 | [Site Record Lookup](#3-site-record-lookup) | Has this company/platform been done before? |
| 4 | [Script Inventory](#4-script-inventory) | Which script should I reuse? |
| 5 | [Quick-Reference Rules](#5-quick-reference-rules) | What are the top priority rules? |

---

## 1. DECISION TREE

Use this flowchart when starting any new extraction task.

```
START: Fetch raw HTML with httpx/requests
â”‚
â”œâ”€ Page > 50 KB?
â”‚   â”œâ”€ YES â†’ Look for embedded JSON in <script> tags
â”‚   â”‚         â”œâ”€ Found `var info = [...]` or `var data = [...]`?
â”‚   â”‚         â”‚   â””â”€ â†’ PATTERN P-04: Embedded JSON
â”‚   â”‚         â””â”€ Found `div.country_card`, cards, accordion sections?
â”‚   â”‚             â””â”€ â†’ PATTERN P-05: Static HTML Cards
â”‚   â””â”€ NO (< 5 KB shell) â†’ JavaScript-rendered site â†’ hunt for API
â”‚
â”œâ”€ API endpoint hunt (check JS files, <script> tags, network tab):
â”‚   â”œâ”€ `etc.clientlibs/` or `_jcr_content` in URLs?     â†’ PATTERN P-01: AEM
â”‚   â”œâ”€ `nearme.*` subdomain or `.php` city/state APIs?   â†’ PATTERN P-02: SingleInterface
â”‚   â”œâ”€ `experience.arcgis.com` URL?                      â†’ PATTERN P-03: ArcGIS
â”‚   â”œâ”€ `api/sitecore/BranchInfo/` POST endpoint?         â†’ PATTERN P-09: Sitecore
â”‚   â”œâ”€ `/bin/ocp?apiName=` endpoint?                     â†’ PATTERN P-10: AEM /bin/ocp
â”‚   â”œâ”€ `cdn.sanity.io` image URLs?                       â†’ PATTERN P-11: Sanity GROQ
â”‚   â”œâ”€ `/graphql` on CMS subdomain?                      â†’ PATTERN P-14: Strapi GraphQL
â”‚   â”œâ”€ `$.post(location.pathname)` + Mustache templates? â†’ PATTERN P-12: ASP.NET POST-self
â”‚   â”œâ”€ `/json.smart?v=` POST endpoint?                   â†’ PATTERN P-19: AngularJS json.smart
â”‚   â”œâ”€ `restapi.<brand>.com` preconnect?                 â†’ PATTERN P-17: REST+AEM Hybrid
â”‚   â”œâ”€ VTEX `store.storelocator` route?                  â†’ PATTERN P-15: VTEX GraphQL
â”‚   â”œâ”€ JSP servlets with action params?                  â†’ PATTERN P-16: JSP Servlet
â”‚   â”œâ”€ Closeby `window.closeby` embed?                   â†’ PATTERN P-18: Closeby Embed
â”‚   â”œâ”€ Drupal `/callajax` POST?                          â†’ PATTERN P-13: Drupal callajax
â”‚   â”œâ”€ Drupal 9 `div.cardslist` data-category?           â†’ PATTERN P-22: Drupal 9 Cards
â”‚   â””â”€ Generic REST/GraphQL endpoint?                    â†’ httpx direct call
â”‚
â”œâ”€ Structured data on page?
â”‚   â”œâ”€ `application/ld+json` with LocalBusiness?         â†’ PATTERN P-06: Sitemap + LD+JSON
â”‚   â”œâ”€ Sitemap.xml with branch URLs?                     â†’ PATTERN P-06: Sitemap + LD+JSON
â”‚   â””â”€ Static JSON file linked from page?                â†’ Direct httpx fetch
â”‚
â”œâ”€ PDF source?
â”‚   â”œâ”€ Tabular PDF with structured table rows?           â†’ PATTERN P-08: Tabular PDF
â”‚   â””â”€ Annual report with asset tables?                  â†’ PATTERN P-20: Annual Report
â”‚
â”œâ”€ Static HTML with identifiable address blocks?
â”‚   â”œâ”€ `<h2>` headings + `<ul><li>` bullets?             â†’ PATTERN P-23: Heading+Bullet
â”‚   â”œâ”€ Grouped table with rowspan city/activity?         â†’ PATTERN P-24: Rowspan Table
â”‚   â”œâ”€ Map-navi `<button data-lat data-lng>`?            â†’ PATTERN P-25: Map-Navi Directory
â”‚   â”œâ”€ Portfolio pages â†’ detail pages with map iframes?  â†’ PATTERN P-21: GMap iframe Portfolio
â”‚   â”œâ”€ `Add.:` blocks in JSP/HTML detail pages?          â†’ PATTERN P-16: JSP Servlet
â”‚   â””â”€ Generic contact/table page?                       â†’ PATTERN P-07: Direct Contact Page
â”‚
â””â”€ Last resort: Playwright browser automation            â†’ PATTERN P-26: Playwright
    â”œâ”€ Cookie consent blocking? â†’ page.evaluate() to remove banner
    â”œâ”€ CORS-blocked API? â†’ execute fetch() inside browser context
    â””â”€ CSRF-protected POST? â†’ click-based interception (not page.evaluate)
```

---

## 2. PLATFORM PATTERN CATALOGUE

Quick reference â€” Pattern ID, name, detection signal, script to use, and detail section.
For full implementation details, see `the KB/ record files Â§ PATTERNS`.

| ID | Pattern Name | Detection Signal | Script | Detail |
|----|-------------|-----------------|--------|--------|
| P-01 | AEM Sling API | `etc.clientlibs/`, `_jcr_content`, `.map.reachus.` | `kotak_mahindra_bank_extract.py` | â†’ P-01 |
| P-02 | SingleInterface | `nearme.*` subdomain, `.php` city APIs, `master_outlet_id` | `bfs_nearme_full_extract.py` / `singleinterface_extractor_v2.py` | â†’ P-02 |
| P-03 | ArcGIS Experience | `experience.arcgis.com`, FeatureServer queries | `arcgis_extraction_script.py` | â†’ P-03 |
| P-04 | Embedded JSON | `var info = [...]` in large script tags (>1 KB) | `esun_financial_extract.py` | â†’ P-04 |
| P-05 | Static HTML Cards | `div.country_card`, `div[class*="card"]`, accordion sections | `chroma_ate_extract.py` | â†’ P-05 |
| P-06 | Sitemap + LD+JSON | `sitemap.xml` with branch URLs, `application/ld+json` | `sitemap_ldjson_extractor.py` / `extract.py` | â†’ P-06 |
| P-07 | Direct Contact Page | `/contactus/`, `/contact-us/` with HTML tables or lists | `direct_contact_table_extractor.py` / `static_html_table_contact_extractor.py` | â†’ P-07 |
| P-08 | Tabular PDF | Downloadable PDF with structured table rows | `tabular_pdf_facility_extractor.py` | â†’ P-08 |
| P-09 | Sitecore POST API | `api/sitecore/BranchInfo/getlocationinfo` POST `{}` | `sitecore_api_extractor.py` | â†’ P-09 |
| P-10 | AEM /bin/ocp | `/bin/ocp?apiName=getContentByCategory` GET | `aem_ocp_api_extractor.py` | â†’ P-10 |
| P-11 | Sanity GROQ | `cdn.sanity.io` image URLs, `_type` / `_ref` in JSON | `sanity_api_extractor.py` | â†’ P-11 |
| P-12 | ASP.NET POST-self | Mustache `{{EDept}}` templates, `$.post(location.pathname)` | `aspnet_post_json_locator_extractor.py` | â†’ P-12 |
| P-13 | Drupal callajax | Drupal 10, `$.post("/callajax")`, action-based HTML fragments | `drupal_callajax_branch_extractor.py` | â†’ P-13 |
| P-14 | Strapi GraphQL | Next.js + CMS subdomain, `branchLists_connection` in JS chunk | `kotak_securities_gql_extractor.py` | â†’ P-14 |
| P-15 | VTEX GraphQL | VTEX `store.storelocator`, `getStores(latitude, longitude)` | `vtex_store_locator_grid_extractor.py` | â†’ P-15 |
| P-16 | JSP Servlet | JSP country pages, servlet `action=` params, companion map JSON | `jsp_office_agent_api_extractor.py` | â†’ P-16 |
| P-17 | REST + AEM Hybrid | `restapi.<brand>.com` preconnect + AEM `/sitemap.xml` brand pages | `restapi_aem_hybrid_locator_extractor.py` | â†’ P-17 |
| P-18 | Closeby Embed | `window.closeby = { mapKey: ... }`, Closeby iframe | `closeby_embed_locator_extractor.py` | â†’ P-18 |
| P-19 | AngularJS json.smart | `mz.init(cfg, bc)` AngularJS, `/json.smart?v=<ts>` POST | *(inline Playwright script)* | â†’ P-19 |
| P-20 | Annual Report PDF | Annual report with `Company | Address` tables or asset schedules | `annual_report_asset_exporter.py` / `annual_report_distribution_center_exporter.py` | â†’ P-20 |
| P-21 | GMap iframe Portfolio | Static listing â†’ detail pages with `iframe#gmap_canvas` coords | `static_html_gmap_iframe_portfolio_extractor.py` | â†’ P-21 |
| P-22 | Drupal 9 Cards | Drupal 9, `div.cardslist`, `data-category` attributes | `drupal_static_card_tm_extractor.py` | â†’ P-22 |
| P-23 | Heading + Bullet | `<h2>` headings + `<ul><li>` bullets, blank `<li>` separators | `ongc_heading_bullet_extractor.py` | â†’ P-23 |
| P-24 | Rowspan Table | Grouped HTML table, `rowspan` city/activity inheritance | `static_html_rowspan_table_extractor.py` | â†’ P-24 |
| P-25 | Map-Navi Directory | `div.map-navi_contents`, `<button data-lat data-lng>` | `static_html_map_navi_directory_extractor.py` | â†’ P-25 |
| P-26 | Playwright Browser | JS-rendered page, no other API discoverable | `bfs_nearme_full_extract.py` (example) | â†’ P-26 |
| P-27 | JSONP Locator API | Static locator page references external JSONP `Request.aspx?callback=...&canal_id=` endpoint; linked JS maps channel IDs client-side | `jsonp_locator_network_extractor.py` | â†’ P-27 |
| P-28 | CSRF Dependent Dropdown HTML Fragment | `_csrf` meta tags, dependent nation/location AJAX, HTML fragment result rows | `csrf_dropdown_terminal_directory_extractor.py` | -> P-28 |
| P-29 | Radware-Protected Branch Detail Enumerator | `Controller?nav=locators.BranchLocatorSearch`, detail links with `costCentreCode=...&details=true`, raw `requests` hit `validate.perfdrive.com` / Radware | `radware_branch_detail_enumerator.py` | -> P-29 |
| P-30 | JS-Discovered JSON API | Small HTML shell, JS exposes open JSON endpoint like `/open/api/.../stores`, browser-like headers needed | `js_discovered_json_api_extractor.py` | -> P-30 |

---

## 3. SITE RECORD LOOKUP

Has this company or platform been extracted before? Check here first.
For full details (approaches tried, learnings, config), see `the KB/ record files Â§ COMPANY RECORDS`.

| Company | IID | Platform Pattern | Script Used | Record |
|---------|-----|-----------------|-------------|--------|
| AL RAJHI BANKING | IID000000002153141 | P-09 Sitecore | `alrajhi_final_clean.py` | â†’ R-09 |
| ALPHA BANK S.A. | IID000000005041428 | P-08 PDF | `alpha_bank_pdf_extractor.py` | â†’ R-18 |
| ANTA SPORTS PRODUCTS | IID000000002132728 | P-18 Closeby | `closeby_embed_locator_extractor.py` | â†’ R-37 |
| AU SMALL FINANCE BANK | IID000000002617767 | P-02 SingleInterface | `singleinterface_extractor_v2.py` | â†’ R-06 |
| AYALA LAND INC. | IID000000002727794 | P-11 Sanity | `sanity_api_extractor.py` | â†’ R-11 |
| B3 S.A. (Brasil Bolsa) | IID000000002390061 | Manual Research | *(hardcoded)* | â†’ R-32 |
| BAJAJ FINANCE | IID000000002158574 | Multi-source | `bfs_nearme_full_extract.py` | â†’ R-01 |
| BAJAJ HOLDINGS | IID000000002158899 | P-07 Contact | *(hardcoded)* | â†’ R-40 |
| BEIJING TIANTAN BIOLOGICAL | IID000000002159383 | Static Text+Detail | `static_html_detail_page_extractor.py` | â†’ R-51 |
| B3 S.A. | IID000000002390061 | Manual Research | *(hardcoded)* | â†’ R-32 |
| CAIXA SEGURIDADE | IID000000005040475 | Manual Research | *(hardcoded)* | â†’ R-45 |
| CATL (initial) | IID000000002841129 | P-07 Contact | `catl_build_csv.py` | â†’ R-05 |
| CATL (refresh) | IID000000002841129 | P-07 + Image | `catl_master_extractor.py` | â†’ R-14 |
| CHINA RUYI HOLDINGS | IID000000002148856 | Manual/PDF/Registry | *(hardcoded)* | â†’ R-33 |
| CHINA STATE CONSTRUCTION INTL | IID000000002161882 | Manual/PDF | `csci_gap_builder.py` | â†’ R-44 |
| CHINA STATE CONSTRUCTION ENGR | IID000000002403401 | Static HTML Multi | `static_html_multisource_asset_extractor.py` | â†’ R-55 |
| CHROMA ATE INC. | IID000000002150057 | P-05 Static Cards | `chroma_ate_extract.py` | â†’ R-04 |
| CHROMA ATE (gap fill) | IID000000002150057 | Manual | *(hardcoded)* | â†’ R-25 |
| CONTINENTAL AG | â€” | P-05 Static Cards | `comprehensive_extract.py` | â†’ R-06b |
| E.SUN FINANCIAL HOLDING | IID000000002164615 | P-04 Embedded JSON | `esun_financial_extract.py` | â†’ R-03 |
| E.SUN FHC (gap fill Ph1) | IID000000002164615 | Multi-source PDF | `esun_gap_build.py` | â†’ R-24 |
| E.SUN FHC (gap fill Ph2) | IID000000002164615 | P-12 ASP.NET | `aspnet_post_json_locator_extractor.py` | â†’ R-24b |
| ENGIE BRASIL ENERGIA S.A. | IID000000002129944 | P-07 Multi-source static HTML + Playwright fallback | *(temp browser script)* | -> R-71 |
| ETERNAL LTD | IID000000005041473 | P-07 Static Table | `static_html_table_contact_extractor.py` | â†’ R-57 |
| EVA AIRWAYS | IID000000002165810 | Dynamic Dropdown | *(inline Playwright)* | â†’ R-36 |
| EVERGREEN MARINE CORP | IID000000002165840 | P-16 JSP Servlet | `jsp_office_agent_api_extractor.py` | â†’ R-35 |
| FALABELLA S.A. | IID000000002181919 | WordPress+Contentstack | `falabella_store_extraction.py` | â†’ R-56 |
| FIBRA UNO (FUNO) | IID000000002615109 | P-21 GMap Portfolio | `static_html_gmap_iframe_portfolio_extractor.py` | â†’ R-53 |
| FOSUN INTERNATIONAL LIMITED | IID000000002142739 | P-07 Multi-source static listings + linked official-site HQ crawl | `linked_company_hq_extractor.py` | -> R-70 |
| GREE ELECTRIC APPLIANCES | IID000000002168285 | P-05+P-07 Static | `static_html_country_panel_contact_extractor.py` | â†’ R-50 |
| GRUPO COMERCIAL CHEDRAUI | IID000000002240529 | P-15 VTEX | `vtex_store_locator_grid_extractor.py` | â†’ R-30 |
| GUANGDONG INVESTMENT | IID000000002143002 | P-20 Annual Report | `annual_report_asset_exporter.py` | â†’ R-39 |
| HAIDILAO INTERNATIONAL | â€” | Single POST API | `single_post_api_global_extractor.py` | â†’ R-08 |
| HINDUSTAN PETROLEUM (HPCL) | IID000000002124711 | P-07 HTML Table | `direct_contact_table_extractor.py` | â†’ R-12 |
| HYDRO ONE | â€” | P-03 ArcGIS | `arcgis_extraction_script.py` | â†’ R-08b |
| KAKAOBANK CORP | IID000000005048139 | Manual/DART | *(hardcoded)* | â†’ R-34 |
| KOREAN AIR LINES | IID000000002173014 | P-05 Accordion | `static_html_branch_accordion_extractor.py` | â†’ R-54 |
| KOTAK MAHINDRA BANK | IID000000002173037 | P-01 AEM | `kotak_mahindra_bank_extract.py` | â†’ R-02 |
| KOTAK MAHINDRA (gap â€” Neo/Securities) | IID000000002173037 | P-14 Strapi GQL | `kotak_securities_gql_extractor.py` | â†’ R-23 |
| KOTAK AMC (gap â€” CAMS) | IID000000002173037 | Playwright Angular | `kotak_amc_cams_extractor.py` | â†’ R-23b |
| KRUNG THAI BANK (KTB) | IID000000002143738 | P-09 POST+Session | `ktb_scraper.py` | â†’ R-07 |
| KTB (gap fill) | IID000000002143738 | Multi-source | *(hardcoded)* | â†’ R-20 |
| KTB Exchange Booths | IID000000002143738 | Click Intercept | `ktb_click_scrape.py` | â†’ R-21 |
| LUZHOU LAOJIAO | IID000000002174178 | Multi-source | *(inline)* | â†’ R-52 |
| MERITZ FINANCIAL GROUP | IID000000002619055 | P-19 AngularJS | *(inline Playwright)* | â†’ R-41 |
| MTN GROUP | IID000000002174506 | Manual Research | *(hardcoded)* | â†’ R-31 |
| MUTHOOT FINANCE | IID000000002618636 | P-13 Drupal + React | `muthoot_finance_ajax_extractor.py` | â†’ R-07b |
| MUTHOOT (gap fill) | IID000000002618636 | P-13 + React bundle | *(inline)* | â†’ R-26 |
| OIL & NATURAL GAS CORP (ONGC) | IID000000002178040 | P-23 Heading+Bullet | `ongc_heading_bullet_extractor.py` | â†’ R-49 |
| PB FINTECH | IID000000005045393 | Manual/Contact | *(hardcoded)* | â†’ R-46 |
| PDD HOLDINGS | IID000000002863606 | Manual Research | *(hardcoded)* | â†’ R-43 |
| PETRONAS DAGANGAN | IID000000002179442 | Static+Directory | *(inline)* | â†’ R-48 |
| POWER FINANCE CORP (PFC) | IID000000002128610 | Manual/Registry | *(hardcoded)* | â†’ R-29 |
| PT TELKOM INDONESIA | IID000000002186457 | P-20 Annual Report | `annual_report_asset_exporter.py` | â†’ R-58 |
| SAMSUNG SDS | IID000000002244054 | P-25 Map-Navi | `static_html_map_navi_directory_extractor.py` | â†’ R-59 |
| SAUDI ARAMCO | IID000000002285741 | Interactive Map API | *(inline)* | â†’ R-60 |
| SAUDI TELECOM (STC) | IID000000002153141 | P-10 AEM /bin/ocp | `aem_ocp_api_extractor.py` | â†’ R-10 |
| SAUDI TADAWUL GROUP | IID000000005073089 | Gatsby page-data | *(hardcoded)* | â†’ R-47 |
| SBI CARDS | IID000000002266796 | Manual Stubs | *(hardcoded)* | â†’ R-28 |
| SD GUTHRIE BERHAD | IID000000002727794 | P-?? Mapplic | `mapplic_map_extractor.py` | â†’ R-13 |
| SHRIRAM FINANCE (gap fill) | IID000000002129317 | P-02 SingleInterface | `shriram_gap_extractor.py` | â†’ R-27 |
| SPRING AIRLINES | IID000000002718252 | P-24 Rowspan Table | `static_html_rowspan_table_extractor.py` | â†’ R-54b |
| TAWUNIYA (Cooperative Insurance) | IID000000002136380 | CF-blocked Recovery | *(hardcoded)* | â†’ R-38 |
| TELEKOM MALAYSIA | IID000000002186454 | P-22 Drupal 9 | `drupal_static_card_tm_extractor.py` | â†’ R-42 |
| TURKCELL | IID000000002135566 | P-08 Tabular PDF | `tabular_pdf_facility_extractor.py` | â†’ R-16 |
| UPS | IID000000002188125 | P-06 Sitemap+LD+JSON | `sitemap_ldjson_extractor.py` | â†’ R-15 |
| VEDANTA LIMITED | IID000000002145952 | P-05 + P-07 Static Hybrid | *(manual multi-source build)* | â†’ R-63 |
| VODACOM GROUP | IID000000002590838 | Manual Stubs | *(hardcoded)* | â†’ R-46b |
| WAL-MART DE MEXICO (WALMEX) | IID000000002147475 | P-20 Annual Report | `annual_report_distribution_center_exporter.py` | â†’ R-61 |
| WHITBREAD PLC | IID000000002129162 | P-17 REST+AEM | `restapi_aem_hybrid_locator_extractor.py` | â†’ R-17 |
| YTL GROUP | IID000000002190023 | Hybrid Portfolio | *(inline)* | â†’ R-62 |
| LARSEN AND TOUBRO LIMITED | IID000000002173528 | P-07 Static + embedded Google My Maps KML + static office pages | *(inline task run)* | â†’ R-64 |
| BANCO BRADESCO S.A. | IID000000002158979 | P-27 JSONP Locator | `jsonp_locator_network_extractor.py` | â†’ R-65 |
| PUBLIC POWER CORPORATION S.A. | IID000000002180448 | P-07 Multi-source static portfolio pages | *(inline task run)* | -> R-66 |
| BID CORPORATION LIMITED | IID000000002281148 | P-07 Direct Contact Page + multi-source static enrichment | *(inline task run)* | -> R-67 |
| TINGYI (CAYMAN ISLANDS) HOLDING CORP. | IID000000002137182 | P-20 Annual Report + P-07 Contact | *(inline task run)* | -> R-68 |
| HMM CO.,LTD | IID000000002169832 | P-28 CSRF Dropdown | `csrf_dropdown_terminal_directory_extractor.py` | -> R-69 |
| CHINA NATIONAL CHEMICAL ENGINEERING CO., LTD | IID000000002573869 | P-07 Direct Contact Page + P-26 browser recovery | `cncec_affiliate_contact_extractor.py` (Temp) | -> R-72 |
| COMPANHIA DE SANEAMENTO BASICO DO ESTADO DE SAO PAULO - SABESP | IID000000002162589 | P-12 ASP.NET (blocked) + manual official PDF fallback | *(inline task run)* | -> R-73 |
| CHINA NATIONAL BUILDING MATERIAL COMPANY LIMITED | IID000000002124595 | P-07 Static selector directory | `static_country_selector_directory_extractor.py` | -> R-74 |
| EMPRESAS CMPC S.A. | IID000000002148052 | P-20 Annual Report PDF + official static contact enrichment | `cmpc_report_asset_exporter.py` (Temp) | -> R-75 |
| JSW ENERGY LIMITED | IID000000002235355 | P-07 Multi-source static HTML + official report supplement | `jsw_energy_asset_extractor.py` (Temp) | -> R-76 |
| Ooredoo Q.P.S.C. | IID000000002136554 | P-07 Multi-source official web + report | `ooredoo_qpsc_build_output.py` (Temp) | -> R-77 |
| ZHEJIANG SANHUA INTELLIGENT CONTROLS CO.,LTD. | IID000000002190433 | P-07 Direct Contact Page | `sanhua_official_network_builder.py` (Temp) | -> R-78 |
| TOTVS S.A. | IID000000002187135 | P-05 Static HTML Cards | `totvs_wordpress_unit_archive_extractor.py` (Temp) | -> R-79 |
| CP AXTRA PUBLIC COMPANY LIMITED | IID000000005624272 | P-05 + Public JSON Feed | `cpaxtra_store_extractor.py` (Temp) | -> R-80 |
| HYUNDAI ROTEM COMPANY | IID000000002244912 | P-05 Static HTML Cards + official report supplement | `hyundai_rotem_extract.py` (Temp) | -> R-81 |
| FIRSTRAND LIMITED | IID000000002134538 | P-29 Branch Detail Enumerator + static contact supplements | `radware_branch_detail_enumerator.py` | -> R-82 |
| SAUDI BASIC INDUSTRIES CORPORATION SJSC | IID000000002182781 | P-06 Sitemap-driven location pages | `sabic_location_extractor.py` | -> R-83 |
| CHUNGHWA TELECOM CO., LTD. | IID000000002162015 | P-07 Contact Page + overseas office pages | `chunghwa_global_office_extractor.py` | -> R-84 |
| HENGTONG OPTIC-ELECTRIC CO.,LTD | IID000000002171890 | P-07 Static business-layout page | `hengtong_business_layout_extractor.py` | -> R-85 |
| THE SAUDI NATIONAL BANK SJSC | IID000000002255105 | P-07 Direct Contact Page | *(inline task run)* | -> R-86 |
| ECLAT TEXTILE CO LTD | IID000000002130667 | P-07 Contact Page + P-20 Annual Report | *(inline task run)* | -> R-87 |
| INNOLUX CORPORATION | IID000000002151318 | P-07 JS-backed contact endpoint | `innolux_global_operations_extractor.py` | -> R-88 |
| QL RESOURCES BERHAD | IID000000002180550 | P-20 Annual Report / property list | `ql_property_extractor.py` (Temp) | -> R-89 |
| XCMG CONSTRUCTION MACHINERY CO., LTD. | IID000000002189970 | P-16 JSP Servlet / AJAX directory | `xcmg_service_outlet_extractor.py` | -> R-90 |
| NINGBO SANXING MEDICAL ELECTRIC CO.,LTD. | IID000000002620187 | P-07 Innovation/contact pages + linked official subsidiary page | `sanxing_innovation_partial_extractor.py` | -> R-91 |
| ADES HOLDING COMPANY LISTED JOINT STOCK COMPANY | IID000000005119265 | P-07 Contact page + official fleet page recovery | `ades_contact_extractor.py` | -> R-92 |
| SHANDONG GOLD MINING CO., LTD. | IID000000002183294 | P-20 Official disclosure wrapper pages + attachment PDFs | `shandong_disclosure_extractor.py` | -> R-93 |
| COAL INDIA LTD | IID000000002235890 | P-07 Official roster pages + government register enrichment | `coal_washery_controller_extractor.py` | -> R-94 |
| VANGUARD INTERNATIONAL SEMICONDUCTOR CORPORATION | IID000000002137849 | P-20 Annual report mirror recovery | *(inline task run)* | -> R-95 |
| CHONGQING CHANGAN AUTOMOBILE COMPANY LIMITED | IID000000002142017 | P-20 Annual report + official plant PDF supplement | *(inline task run)* | -> R-96 |
| CEMEX, S.A.B. DE C.V. | IID000000002160496 | P-20 Official report PDF directory | *(inline task run)* | -> R-97 |
| LI AUTO INC. | IID000000005022804 | P-30 JS-discovered JSON API | `js_discovered_json_api_extractor.py` / *(inline task run)* | -> R-98 |
| CHINA OILFIELD SERVICES LIMITED | IID000000002124563 | P-07 Regional official contact pages | *(inline task run)* | -> R-99 |
| JIANGSU ZHONGTIAN TECHNOLOGY CO., LTD. | IID000000002126626 | P-07 Contact page + official facility news posts | *(inline task run)* | -> R-100 |
| WEG S.A. | IID000000002129985 | P-07 Global contact page | *(inline task run)* | -> R-101 |
| SANY HEAVY INDUSTRY CO., LTD | IID000000002130092 | P-07 Corporate about page | *(inline task run)* | -> R-102 |
| BRITANNIA INDUSTRIES LTD | IID000000002132407 | P-07 Contact page | *(inline task run)* | -> R-103 |
| SINOTRUK (HONG KONG) LIMITED | IID000000002132893 | P-07 Official group-company page | *(inline task run)* | -> R-104 |
| MPHASIS LIMITED | IID000000002135810 | P-07 Contact page | *(inline task run)* | -> R-105 |
| INDUSTRIAS PENOLES, S.A.B. DE C.V. | IID000000002143481 | P-20 Annual report + official sustainability pages | *(inline task run)* | -> R-106 |
| TITAN COMPANY LIMITED | IID000000002146121 | P-07 Contact page | *(inline task run)* | -> R-107 |
| YTL POWER INTERNATIONAL BERHAD | IID000000002146856 | P-07 Multi-source official group/subsidiary pages | *(inline task run)* | -> R-108 |
| BARWA REAL ESTATE COMPANY Q.P.S.C. | IID000000002147865 | P-05 Investment-property card layout | *(inline task run)* | -> R-109 |
| COCA-COLA FEMSA, S.A.B. DE C.V. | IID000000002150568 | P-07 Corporate about page + official plant news | *(inline task run)* | -> R-110 |
| SHANGHAI PHARMACEUTICALS HOLDING CO., LTD. | IID000000002151735 | P-07 Logistics network page | *(inline task run)* | -> R-111 |
| RUMO S.A. | IID000000002154574 | P-07 Investor contact + business-model pages | *(inline task run)* | -> R-112 |
| AMOREPACIFIC CORP. | IID000000002157343 | P-07 Global network page | *(inline task run)* | -> R-113 |
| CITIC LIMITED | IID000000002160572 | P-07 Annual-report HTML manufacturing pages | *(inline task run)* | -> R-114 |
| ENEL AMERICAS S.A.COMPANHIA ENERGETICA DE MINAS GERAIS - CEMIG | IID000000002162574 | P-07 Linked official subsidiary contact page | *(inline task run)* | -> R-115 |
| THE INDIAN HOTELS COMPANY LIMITED | IID000000002170420 | P-07 Corporate and brand contact pages | *(inline task run)* | -> R-116 |
| INDIAN OIL CORPORATION LIMITED | IID000000002170424 | P-07 Locations page | *(inline task run)* | -> R-117 |
| JOLLIBEE FOODS CORP. | IID000000002171994 | P-07 Contact page | *(inline task run)* | -> R-118 |
| OTP BANK NYRT. | IID000000002178416 | P-07 Group-members page + subsidiary contacts | *(inline task run)* | -> R-119 |
| TURKIYE PETROL RAFINERILERI ANONIM SIRKETI | IID000000002187583 | P-07 Corporate page + media contact page | *(inline task run)* | -> R-120 |
| WEICHAI POWER CO., LTD. | IID000000002189390 | P-07 Multi-page official contact directory | *(inline task run)* | -> R-121 |
| ZTE CORPORATION | IID000000002190270 | P-07 Global sales office page | *(inline task run)* | -> R-122 |
| REDE D'OR SAO LUIZ S.A. | IID000000002616817 | P-07 Sustainability overview + hospital pages | *(inline task run)* | -> R-123 |
| LINGYI ITECH (GUANGDONG) COMPANY | IID000000002623039 | P-07 Official global operations page | *(inline task run)* | -> R-124 |
| JIANGSU HENGLI HYDRAULIC CO LTD | IID000000002629930 | P-07 Official operations page | *(inline task run)* | -> R-125 |
| ACWA POWER COMPANY SJSC | IID000000002691739 | P-07 Contact page | *(inline task run)* | -> R-126 |

---

| CHINA RESOURCES MIXC LIFESTYLE SERVICES LIMITED | IID000000005031083 | P-20 Annual Report PDF | `*(hardcoded batch)*` | -> R-127 |

| GOLD FIELDS LIMITED | IID000000002142962 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-128 |

| EMPRESAS COPEC S.A. | IID000000002267088 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-129 |

| J&T GLOBAL EXPRESS LIMITED | IID000000005120552 | P-20 Annual Report PDF | `*(hardcoded batch)*` | -> R-130 |

| QATAR NATIONAL BANK (Q.P.S.C.) | IID000000002139420 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-131 |

| PRESTIGE ESTATES PROJECTS LIMITED | IID000000002603126 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-132 |

| PT INDOFOOD SUKSES MAKMUR TBK | IID000000002125558 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-133 |

| HON HAI PRECISION INDUSTRY CO., LTD. | IID000000002169533 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-134 |

| TRUE CORPORATION PUBLIC COMPANY LIMITED | IID000000005105724 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-135 |

| TELEFONICA BRASIL S.A | IID000000002186431 | P-05 Static HTML Cards | `*(hardcoded batch)*` | -> R-136 |

| TECH MAHINDRA LIMITED | IID000000002146050 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-137 |

| ANHUI GUJING DISTILLERY COMPANY LIMITED | IID000000002157468 | P-20 Annual Report PDF | `*(hardcoded batch)*` | -> R-138 |

| SHENZHEN SALUBRIS PHARMACEUTICALS CO., LTD. | IID000000002451437 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-139 |

| SHENNAN CIRCUITS CO., LTD. | IID000000002629119 | P-20 Annual Report PDF | `*(hardcoded batch)*` | -> R-140 |

| THE PHOENIX MILLS LIMITED | IID000000002179525 | P-20 Annual Report PDF | `*(hardcoded batch)*` | -> R-141 |

| SAMSUNG ELECTRONICS CO., LTD. | IID000000002138664 | P-05 Static HTML Cards | `*(hardcoded batch)*` | -> R-142 |

| JUBILANT FOODWORKS LIMITED | IID000000002576845 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-143 |

| CHINA MERCHANTS ENERGY SHIPPING CO., LTD. | IID000000002125581 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-144 |

| XPENG INC. | IID000000005024112 | P-05 Static HTML Cards | `*(hardcoded batch)*` | -> R-145 |

| RAIA DROGASIL S/A | IID000000002164438 | P-20 Annual Report PDF | `*(hardcoded batch)*` | -> R-146 |

| GRUPO AEROPORTUARIO DEL SURESTE, S.A.B. DE C.V. | IID000000002168390 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-147 |

| SANLAM LIMITED | IID000000002152696 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-148 |

| ENERGISA S.A. | IID000000002154689 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-149 |

| INTERGLOBE AVIATION LIMITED | IID000000002706961 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-150 |

| FOCUS MEDIA INFORMATION TECHNOLOGY CO., LTD. | IID000000002168676 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-151 |

| UPL LIMITED | IID000000002188126 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-152 |

| SHANGHAI INTERNATIONAL AIRPORT CO., LTD. | IID000000002130083 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-153 |

| GODREJ PROPERTIES LIMITED | IID000000002574461 | P-07 Direct Contact Page | `*(hardcoded batch)*` | -> R-154 |

| J. K. CEMENT LIMITED. | IID000000002171562 | P-30 JS-Discovered JSON API + P-07 Static Contact Page | `*(issuer-local Category C batch script)*` | -> R-155 |
| AL AHLI BANK OF KUWAIT K.S.C.P | IID000000002139993 | P-30 JS-Discovered JSON API + P-07 Direct Contact Page | `abk_office_api_build.py` (Category C, issuer-local) | -> R-156 |

| SOUTHSTATE CORPORATION | IID000000002182020 | P-30 JS-Discovered JSON API + P-08 PDF cross-check | `southstate_js_location_api_extractor.py` (Category C, issuer-local) | -> R-157 |

| THE FEDERAL BANK LTD | IID000000002166269 | P-07 Liferay JSP Fragment Locator + Static Branch Cards | `*(issuer-local Category C batch script)*` | -> R-158 |

| OLLIE'S BARGAIN OUTLET HOLDINGS, INC. | IID000000002733151 | P-30 Bullseye Locations JSON API + P-20 SEC 10-K supplement | `bullseye_location_list_extractor.py` | -> R-159 |

| JAMMU AND KASHMIR BANK LIMITED | IID000000002150209 | P-30 JS-Discovered JSON API + P-02 SingleInterface | `*(issuer-local Category C batch script)*` | -> R-160 |

| AFFIN BANK BERHAD | IID000000002351790 | P-30 JS-Discovered JSON API + P-07 Direct Contact Page | `affin_official_locator_extractor.py` (Category C, issuer-local) | -> R-161 |

| FIRST INTERNATIONAL BANK OF ISRAEL LTD. | IID000000002166562 | P-07 Direct Contact Page + official Bank of Israel XML registry | `bank_of_israel_registry_worker.py` (issuer-local Category C) | -> R-162 |

| THE TIMKEN COMPANY | IID000000002145518 | P-30 WP Google Maps REST API + official India contact page | `wp_google_maps_rest_extractor.py` | -> R-163 |

| SERIA CO., LTD. | IID000000002129711 | P-30 JS-Discovered JSON API - AreaMarker OpenSearch variant | `areamarker_opensearch_extractor.py` | -> R-164 |

| MEG ENERGY CORP. | IID000000002273851 | P-20 Annual Report PDF / official filing portfolio | `*(manual official-source synthesis)*` | -> R-165 |

| SMN POWER HOLDING SAOG | IID000000002630189 | P-07 Direct Contact Page + P-20 Annual Report PDF | `*(issuer-local Category C browser/PDF synthesis)*` | -> R-166 |

## 4. SCRIPT INVENTORY

## 4. SCRIPT INVENTORY

Complete list of all scripts in the Memory Folder. When a matching pattern is found,
**use the existing script** (adjust the config block) rather than writing from scratch.

### 4a. Generalized Platform Scripts
*(Reusable across multiple issuers â€” prefer these)*

| Script | Pattern | Key Capability |
|--------|---------|---------------|
| `kotak_mahindra_bank_extract.py` | P-01 AEM Sling | Base64 URL params, state/city iteration, httpx async |
| `bfs_nearme_full_extract.py` | P-02 SingleInterface | Playwright + URL params + infinite scroll + progress saving |
| `singleinterface_extractor_v2.py` | P-02 SingleInterface | Server-rendered `/location/{state}/{city}` path format |
| `arcgis_extraction_script.py` | P-03 ArcGIS | Browser console fetch + Bing reverse geocoding |
| `esun_financial_extract.py` | P-04 Embedded JSON | Bracket-depth parser, bilingual address handling |
| `chroma_ate_extract.py` | P-05 Static HTML Cards | 30+ country address parsers, CJK stripping |
| `sitemap_ldjson_extractor.py` | P-06 Sitemap+LD+JSON | High-concurrency sitemap crawl + LocalBusiness schema |
| `extract.py` | P-06 Sitemap+LD+JSON | Static JSON + sitemap XML.gz + LD+JSON (Bajaj pattern) |
| `direct_contact_table_extractor.py` | P-07 Contact Page | HTML table parsing, Indian pincodeâ†’state mapping |
| `static_html_table_contact_extractor.py` | P-07 Contact Page | `pandas.read_html` + contact block parsing |
| `static_html_country_panel_contact_extractor.py` | P-07 Contact Page | Country panel `<p>` block grouping, malformed label handling |
| `static_html_multisource_asset_extractor.py` | P-07 Multi-source | Multi-URL static HTML, linked detail pages, `Add.:` blocks |
| `linked_company_hq_extractor.py` | P-07 Linked-company HQ crawl | Multi-source office/member/portfolio pages, linked official-site follow-through, optional manual curation, checkpoint export |
| `tabular_pdf_facility_extractor.py` | P-08 PDF | `pdfplumber` multi-layout, Turkish transliteration, checkpoint CSV |
| `alpha_bank_pdf_extractor.py` | P-08 PDF | Greek PDF text extraction, prefectureâ†’region mapping |
| `sitecore_api_extractor.py` | P-09 Sitecore | Empty `{}` POST, JSON extraction |
| `aem_ocp_api_extractor.py` | P-10 AEM /bin/ocp | Header manipulation, dual-language Accept-Language |
| `sanity_api_extractor.py` | P-11 Sanity GROQ | `->` reference expansion, GROQ query |
| `aspnet_post_json_locator_extractor.py` | P-12 ASP.NET | Empty-body POST, Taiwan CJK address parser, Type filtering |
| `drupal_callajax_branch_extractor.py` | P-13 Drupal callajax | POST action-based HTML fragments, offset pagination |
| `kotak_securities_gql_extractor.py` | P-14 Strapi GraphQL | Next.js webpack chunk scan, `branchLists_connection` |
| `vtex_store_locator_grid_extractor.py` | P-15 VTEX GraphQL | Grid sweep, store ID dedupe, checkpoint CSV |
| `jsp_office_agent_api_extractor.py` | P-16 JSP Servlet | Servlet action sweep, map JSON join, contact-card supplement |
| `restapi_aem_hybrid_locator_extractor.py` | P-17 REST+AEM | Live reconciliation, targeted repair, staged checkpoint |
| `restapi_aem_hotel_restaurant_extractor.py` | P-17 REST+AEM | Async httpx semaphore, AEM sitemap+HTML, German umlaut fix |
| `closeby_embed_locator_extractor.py` | P-18 Closeby | Source-map endpoint discovery, transliteration-safe export |
| `annual_report_asset_exporter.py` | P-20 Annual Report | Mixed explicit + locality-level assets, PDF table parse |
| `annual_report_distribution_center_exporter.py` | P-20 Annual Report | Grouped-count expansion, cross-page PDF table reconstruction |
| `static_html_gmap_iframe_portfolio_extractor.py` | P-21 GMap Portfolio | Anchor discovery, iframe coord parsing, Nominatim enrichment |
| `drupal_static_card_tm_extractor.py` | P-22 Drupal 9 | `div.cardslist` parse, `data-category` filter, Malaysian postal |
| `ongc_heading_bullet_extractor.py` | P-23 Heading+Bullet | Direct sibling parse, blank-li splitting, checkpoint export |
| `static_html_rowspan_table_extractor.py` | P-24 Rowspan Table | `rowspan` city/activity inheritance, `b.address` extraction |
| `static_html_map_navi_directory_extractor.py` | P-25 Map-Navi | UTF-8 force-decode, cross-page union, campus block splitting |
| `static_html_branch_accordion_extractor.py` | P-05/Accordion | Sequential retry, exact country alias, postcode parsing |
| `static_html_detail_page_extractor.py` | P-07 Detail Pages | Static discovery + hidden-ID enrichment, progress saving |
| `mapplic_map_extractor.py` | Mapplic jQuery | HTML-in-JSON parsing, multi-file fetch by country/index |
| `vtex_store_locator_grid_extractor.py` | P-15 VTEX | Grid sweep, dedupe by store ID |
| `jsonp_locator_network_extractor.py` | P-27 JSONP Locator | External JSONP arrays, per-channel merge, static office supplements, report HQ add-on |
| `csrf_dropdown_terminal_directory_extractor.py` | P-28 CSRF Dropdown | CSRF-token replay, dependent nation/location sweep, HTML fragment terminal parsing, checkpoint export |
| `static_country_selector_directory_extractor.py` | P-07 Contact Page | Country-selector directory crawl, raw `<h3>` block splitting, official-source address supplements, checkpoint CSV |
| `radware_branch_detail_enumerator.py` | P-29 Radware-Protected Branch Detail Enumerator | Headed Edge anti-bot bootstrap, live `uzlc` capture, concurrent `costCentreCode` sweep, checkpoint CSV, coordinate-backed city/state cleanup |
| `sabic_location_extractor.py` | P-06 Sitemap-driven location pages | Sitemap XML enumeration, static location-page parsing, activity extraction, progress saving |
| `chunghwa_global_office_extractor.py` | P-07 Contact Page | Multi-page overseas office extraction from official country and Europe contact pages |
| `hengtong_business_layout_extractor.py` | P-07 Contact Page | Splits bundled `Add:` blocks from the business-layout page into one row per facility |
| `innolux_global_operations_extractor.py` | P-07 Contact Page | Official JSON endpoint behind JS-driven contacts page, global operations export |
| `xcmg_service_outlet_extractor.py` | P-16 JSP Servlet | Official AJAX dealer/service outlet extraction across area filters with country-aware parsing |
| `js_discovered_json_api_extractor.py` | P-30 JS-Discovered JSON API | Front-end bundle API discovery, browser-like header replay, generic JSON-to-CSV mapping |
| `bullseye_location_list_extractor.py` | P-30 Bullseye Locations API | Discovers Bullseye InterfaceConfiguration client/API values, replays RestSearch.svc/GetLocationList, exports website coordinates, and allows official filing supplements. |
| `wp_google_maps_rest_extractor.py` | P-30 WP Google Maps REST API | Replays public `/wp-json/wpgmza/v1/markers`, filters map IDs, exports website coordinates, country-normalized rows, and optional official page supplements. |

| `areamarker_opensearch_extractor.py` | P-30 JS-Discovered JSON API - AreaMarker OpenSearch variant | Reads Angular AreaMarker `config.json`/`clusters.json`, replays public `search-by-condition` API by prefecture to avoid response-size limits, exports Japanese native fields and website coordinates. |

### 4b. Geocoding & Translation Utilities

| Script | Purpose |
|--------|---------|
| `chinese_address_transliterator.py` | Chinese address romanization |
| `chinese_bank_ebank_api_extractor.py` | Chinese bank e-banking API patterns |
| `chinese_corporate_annual_report_extractor.py` | Chinese annual report extraction |

### 4c. Issuer-Specific Scripts (Reference Only)

| Script | Issuer | Notes |
|--------|--------|-------|
| `alrajhi_final_clean.py` / `alrajhi_postprocess.py` | Al Rajhi Bank | Sitecore + reverse geocoding |
| `alpha_bank_postprocess.py` | Alpha Bank | City cleaning, Attica neighborhood lookup |
| `catl_build_csv.py` / `catl_master_extractor.py` | CATL | Multi-source + image recon |
| `cmsk_build_csv.py` / `cmsk_fast_extract.py` | China Merchants Shekou | â€” |
| `comprehensive_extract.py` / `final_build.py` | Continental AG | Country-specific CJK handlers |
| `drupal_table_card_asset_extractor.py` | Generic Drupal tables | â€” |
| `emirates_nbd_extractor.py` / `enbd_post_process_export.py` | Emirates NBD | â€” |
| `esun_gap_build.py` | E.SUN FHC gap fill | PDF + static HTML + web research |
| `feedback_sites_api_extractor.py` | â€” | Feedback/ratings API patterns |
| `infosys_global_extractor.py` | Infosys | Global office extractor |
| `kotak_amc_cams_extractor.py` | Kotak AMC (CAMS) | Angular SPA, table extraction |
| `kotak_amc_isc_extractor.py` | Kotak AMC ISC | â€” |
| `kotak_gap_extractor.py` | Kotak gap fill | Multi-subsidiary gap |
| `ktb_click_scrape.py` / `ktb_exchange_booths.py` | KTB Exchange Booths | Click-based intercept |
| `ktb_scraper.py` / `ktb_export.py` | KTB domestic | POST API + province iteration |
| `merge_final.py` | Bajaj Finance | Multi-source merge + dedupe |
| `muthoot_finance_ajax_extractor.py` | Muthoot Finance | Drupal /callajax |
| `muthoot_finance_consolidator.py` | Muthoot Finance | Consolidation |
| `muthoot_homefin_ssr_extractor.py` | Muthoot Homefin | SSR GET params |
| `sharepoint_oocl_directory_extractor.py` | OOCL | SharePoint directory |
| `shriram_gap_extractor.py` | Shriram Finance | SingleInterface gap fill |
| `single_post_api_global_extractor.py` | Haidilao | Global Vue SPA POST API |
| `text_mirror_market_card_extractor.py` | â€” | Text-mirror market card patterns |
| `text_mirror_property_sitemap_extractor.py` | â€” | Text-mirror property sitemap |
| `browser_session_rest_locator_extractor.py` | â€” | REST with browser session |
| `aem_hidden_json_map_extractor.py` | â€” | AEM hidden JSON map |
| `sanxing_innovation_partial_extractor.py` | NINGBO SANXING MEDICAL ELECTRIC Co.,Ltd. | Innovation-page base extract plus linked Nansen/Brazil/Mexico recovery and Kenya supplement |
| `ades_contact_extractor.py` | ADES Holding Company Listed Joint Stock Company | Contact-page office extractor plus fleet-row recovery with preserved official fleet URL |
| `shandong_disclosure_extractor.py` | Shandong Gold Mining Co., Ltd. | Official `sd-gold.com` wrapper-page PDF extractor across selected 2022/2023/2025 disclosures |
| `coal_washery_controller_extractor.py` | COAL INDIA LTD | Coal India/BCCL URL-preserving washery build backed by Coal Controller address enrichment |
| *(ASUS scripts Ã—9)* | ASUS | Grid proximity search, math sweep |

---

## 5. QUICK-REFERENCE RULES

These are the highest-priority rules. Violating them wastes the most time.

### Do This First (in order)
1. **Read the KB** before writing any code â€” check Sections 2 and 3 of this index.
2. **Verify URLs** â€” user-provided URLs may be outdated. Test with httpx; if 404, check navigation.
3. **Check raw HTML first** â€” many sites embed all data in static HTML even when they appear dynamic.
4. **Look for hidden DOM content** â€” run `document.querySelectorAll('[style*="display:none"]')`.
5. **Prefer API over scraping** â€” JSON/REST/GraphQL APIs are always preferred over HTML parsing.
6. **URL params over form interaction** â€” try `?state=X&city=Y` before clicking dropdowns.

7. **For WAF-blocked public-utility locators** — if the live locator and its API both fail from the same environment, check for an official PDF directory via indexed official documents before abandoning the issuer.
8. **For selector-driven directories** - if a page uses `<option url="...">` country links, crawl every option page because the "All" page may show only a subset and some selector labels may be mismatched with the actual address content.

### Do Not Waste Time On
- AEM pages rendered via Playwright clicking "See more" â€” cookie consent blocks all clicks.
- `page.click()` or `select_option()` on hidden elements â€” timeout guaranteed.
- Paid APIs without checking credits (Firecrawl, Azure OpenAI, Google Gemini).
- Single regex for international postal codes â€” always use country-specific parsers.
- Truncating addresses to "street only" â€” keep full address, extract city/state/postal separately.
- Trusting field names blindly (`EDeptAddressEnglish` may be empty; `EDeptAddress` has English).
- Default 8s timeouts for empty pages â€” use 3â€“4s.
- Trusting CSS class names in source HTML â€” companies have typos in their own HTML (e.g., `countyr_name` not `country_name`). Always copy selectors from live page source.
- Using `^\d{4,6}$` postal regex universally â€” Japan=7 digits, Netherlands=alphanumeric, Taiwan=3 digits (old). See KB/U-06.md.
- Leaving phone numbers, opening hours, or directions text in geocoding queries â€” strip all non-address tokens before geocoding.
- When user-supplied Chinese corporate SPA `col/colNNNN/index.html` routes bounce to `/404`, inspect the live JS router and API base before treating the host as dead; the current site may still expose the real inventory endpoint.

### Mandatory Patterns
- **Progress saving**: required for >50 iterations. Save every 20 items.
- **CJK text**: use `strip_cjk()` to keep English from mixed text. Never drop the whole node. After stripping, always clean residual `()` with `re.sub(r'\(\s*\)', '', result)`.
- **Country-aware validation**: postal codes vary wildly. See `the KB/ record files Â§ UTILITIES` U-06.
- **Deduplication**: always dedupe by outlet ID first, then lat/lng, then name+address.
- **No-city-stub policy**: if no facility-level city address found after exhaustive research, drop the row.
- **MapMyIndia token pattern**: for Indian sites using MapMyIndia SDK, the token endpoint requires a live browser session. See KB/U-13.md.
- **CSRF dropdown directories**: GET the landing page first, then replay its `_csrf` / `_csrf_header` meta values with the same session cookie before calling dependent AJAX endpoints.

### Utility Quick-Reference (open the KB/U-XX.md files)
| Need | Utility |
|------|---------|
| Remove CJK from mixed text | U-01 |
| Filter contact persons | U-02 |
| Extract `var info = [...]` from JS | U-03 |
| Progress saving for long runs | U-04 |
| Playwright anti-bot setup | U-05 |
| Country-specific address parsers (30+ countries) | U-06 |
| Indian pincode â†’ state mapping | U-07 |
| Geocoding â€” Bing, Nominatim, Gatsby GPS | U-08 |
| Deduplication strategies | U-09 |
| Country name standardization | U-10 |
| Business activity mapping | U-11 |
| External data sources (DART, PeeringDB, CNPJâ€¦) | U-12 |
| MapMyIndia token-gated locator (Playwright) | U-13 |
| URL classification (URL_Type + URL_Purpose — for Format B inputs) | U-14 |

---

*For full implementation details on any pattern, company record, or utility function → open the matching `KB/<id>.md` file*

---

## 6. CORRECTION NOTES

- **2026-04-11 - SABIC location-page correction:** For SABIC `P-06` location pages, extract from the scoped `div.block.location.contact_details` and `div.block.location.functions` blocks. Do not scrape flattened page text with `soup.get_text()` + broad regex. That approach pulls compare-panel UI text into `ACTIVITY_AT_ASSET`, can misclassify support-hours text as an address, and corrupts country/city parsing on hyphenated or postal-heavy addresses.
- **2026-04-11 - SABIC country/city repair rule:** On issuer location pages where the address omits a normalized country token, fall back to case-insensitive country aliases plus the location-page URL slug before leaving `COUNTRY` / `COUNTRY_ISO3` blank.
- **2026-04-11 - JSON API coord_source normalization:** When website-provided coordinates come from an official JSON API, normalize `coord_source` to `website`. Do not emit ad hoc values like `From website API`.
- **2026-05-29 - FIBI registry refresh:** R-162 re-extraction found Bank of Israel XML registry still reachable and now listing 188 open FIBI/Massad branch-code rows; keep excluding legacy Otsar Ha-Hayal id 14 unless deduped.

*For full implementation details on any pattern, company record, or utility function â†’ open the matching `KB/<id>.md` file*


---

## 7. BATCH 20260414 — ACWI STRAIVE COLLECTION (4 issuers)

### Records
| IID | Issuer | Records | Target | Status |
|-----|--------|---------|--------|--------|
| IID000000005029266 | SUPCON Technology Co Ltd | 16 | 13 | EXCEEDED |
| IID000000002626415 | SUNWAY BERHAD | 14 | 10 | EXCEEDED |
| IID000000002126512 | GERDAU S.A. | 22 | 14 | EXCEEDED |
| IID000000002146188 | CPFL ENERGIA S.A. | 15 | 15 | EXACT |

### Patterns Used
| Issuer | Pattern | Key Source |
|--------|---------|------------|
| SUPCON | Static HTML multi-page + supconvalve.com | supcon.com/global |
| SUNWAY | Multi-subsidiary contact pages | sunway.com.my + subsidiary domains |
| GERDAU | RI site profile page + gsn.gerdau.com/locations | ri.gerdau.com |
| CPFL | RI site Informacoes Cadastrais + PDF FRE 2025 | ri.cpfl.com.br |

### Key Learnings
- gerdau.com.br blocked by Azure WAF 403; use ri.gerdau.com instead
- cpfl.com.br blocked by Cloudflare 403; use ri.cpfl.com.br instead
- CPFL FRE PDF: section 1.4 (pages 18-27) has generation plants; section 1.3 (pages 27-28) has distribution areas
- Gerdau: gsn.gerdau.com/locations has full street addresses for 5 NA special steel mills
- SUPCON: skip "Latin America" entry (dupe of Mexico); strip +86-400+887-XXXX phone from addresses

*Full detail: KB/D-24.md through KB/D-27.md*

---

## 8. KNOWLEDGE APPEND — 2026-07-28

### Site Record Lookup Addition

| Company | IID | Platform Pattern | Script Used | Record |
|---------|-----|------------------|-------------|--------|
| FIRSTCASH, INC. | IID000000002149182 | P-30 JS-Discovered JSON API + official Azure store API | `readthrough_paginated_locator_api_extractor.py` + issuer-local union | -> R-167 |

### Generalized Script Inventory Addition

| Script | Pattern | Key Capability |
|--------|---------|----------------|
| `readthrough_paginated_locator_api_extractor.py` | P-30 JS-Discovered JSON API — read-through variant | Paginates an unreachable public locator through a configurable text-fetch relay, preserves official `SOURCE_URL` values, checkpoints raw pages, dedupes by outlet ID, captures rejects, and performs deterministic QA sampling. |

## KNOWLEDGE APPEND - 2026-08-25

### Site Record Lookup Addition

| Company | IID | Platform Pattern | Script Used | Record |
|---------|-----|------------------|-------------|--------|
| FIDEICOMISO IRREVOCABLE 1721 BANCO ACTINVER / FIBRA PROLOGIS | IID000000002820967 | P-20 official PDF maps + P-07 contact page | `fibraprologis_worker_build.py` (Category C, issuer-local) | -> R-168 |

| VERSIGENT PLC | IID000000006392232 | P-07 Contact + P-20 Filing + official careers API city supplement | `versigent_worker_build.py` (issuer-local Category C) | -> R-169 |

## KNOWLEDGE APPEND - 2026-09-07

### Site Record Lookup Addition

| Company | IID | Platform Pattern | Script Used | Record |
|---------|-----|------------------|-------------|--------|
| UltraTech Cement Ltd | IID000000002187904 | P-07 Direct Contact / Address Directory | xtract_ultratech_offices.py (Category C, issuer-local) | -> R-170 |


## KNOWLEDGE APPEND — 2026-09-07

### Site Record Lookup Addition

| Company | IID | Platform Pattern | Script Used | Record |
|---------|-----|------------------|-------------|--------|
| CRH PLC | IID000000002125650 | P-07 Direct Contact Page + static HTML cards | IID000000002125650_CRH_static_source_builder.py (Category C) | -> R-171 |



## KNOWLEDGE APPEND - 2026-09-07

### Site Record Lookup Addition

| Company | IID | Platform Pattern | Script Used | Record |
|---------|-----|------------------|-------------|--------|
| CF Industries Holdings Inc | IID000000002140932 | P-07 Contact Page + SEC annual-report facility inventory | None (Category C; direct source inspection) | -> R-172 |


## KNOWLEDGE APPEND - 2026-10-02

### Platform Pattern Catalogue Addition

| ID | Pattern | Detection | Script | Record |
|----|---------|-----------|--------|--------|
| P-32 | Brokerage Office Roster (Cloudflare-gated) | `/roster/offices` embedded `offices = [...]` JSON, DataFloat `data-office-id`, kvCORE `div.card > address`, BHHS `office-list`; one headed undetected-chromedriver session | `brokerage_office_roster_extractor.py` | -> P-32 |

### Site Record Lookup Addition

| Company | IID | Platform Pattern | Script Used | Record |
|---------|-----|------------------|-------------|--------|
| BERKSHIRE HATHAWAY ENERGY COMPANY (HomeServices offices) | IID000000002201718 | P-32 Brokerage Office Roster | `brokerage_office_roster_extractor.py` | -> R-173 |

### Script Inventory Addition

| Script | Pattern | Key Features |
|--------|---------|--------------|
| `brokerage_office_roster_extractor.py` | P-32 Brokerage Office Roster | curl_cffi first, headed undetected-chromedriver fallback, challenge/error-page guard, roster pagination, multi-parser (RNG JSON, DataFloat, Reliance, kvCORE, dataLayer), one-row-per-building merge with COMMENTS, URL checkpoint |
