"""
SD Guthrie Berhad - Worldwide Facilities Extraction (v2)
=========================================================
Platform: Mapplic jQuery Map Plugin (Section 3.11)
Source URL: https://www.sdguthrie.com/who-we-are/worldwide

Extracts all worldwide plantation/facility assets for SD Guthrie Berhad.
Data lives in per-country JSON files at:
  {BASE_URL}/themes/custom/sdguthrie_theme/assets/mapplic/data/data-{country}-{idx}.json

Produces final output CSV with all required columns:
  ISSUER_ID, LOCATION_NAME, LOCATION_ADDRESS, LATITUDE, LONGITUDE,
  COUNTRY, COUNTRY_ISO3, POSTCODE, STATE, CITY, SOURCE_URL, SOURCE_TYPE,
  ACTIVITY_AT_ASSET, coord_source,
  LOCATION_NAME_NATIVE, LOCATION_ADDRESS_NATIVE  (populated if non-English)

Usage:
  python sdguthrie_extract_v2.py
"""

import requests
import json
import csv
import sys
import os
import re
import time
import warnings
warnings.filterwarnings('ignore')

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
ISSUER_NAME = "SD GUTHRIE BERHAD"
ISSUER_ID   = "IID000000002727794"
BASE_URL    = "https://www.sdguthrie.com"
THEME_PATH  = "/themes/custom/sdguthrie_theme/assets/mapplic/data"
SOURCE_URL  = "https://www.sdguthrie.com/who-we-are/worldwide"
SOURCE_TYPE = "COMPANY WEBSITE"

OUTPUT_DIR  = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output"
TEMP_DIR    = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp"

# Country slug -> max index (discovered by iterating until 404)
COUNTRY_SLUGS = {
    "malaysia":    13,
    "indonesia":    9,
    "singapore":    2,
    "thailand":     2,
    "uk":           1,
    "netherland":   3,
    "south-africa": 2,
    "papua":       11,
    "usa":          1,
    "solomon":      4,
}

COUNTRY_NAME_MAP = {
    "malaysia":    "Malaysia",
    "indonesia":   "Indonesia",
    "singapore":   "Singapore",
    "thailand":    "Thailand",
    "uk":          "United Kingdom",
    "netherland":  "Netherlands",
    "south-africa":"South Africa",
    "papua":       "Papua New Guinea",
    "usa":         "United States",
    "solomon":     "Solomon Islands",
}

COUNTRY_ISO3_MAP = {
    "Malaysia":        "MYS",
    "Indonesia":       "IDN",
    "Singapore":       "SGP",
    "Thailand":        "THA",
    "United Kingdom":  "GBR",
    "Netherlands":     "NLD",
    "South Africa":    "ZAF",
    "Papua New Guinea":"PNG",
    "United States":   "USA",
    "Solomon Islands": "SLB",
}

# ═══════════════════════════════════════════════════════════
# CITY MAPPING: State/Region → Default City
# For plantation/agricultural assets in remote areas,
# the nearest administrative centre is used as CITY.
# ═══════════════════════════════════════════════════════════
STATE_TO_CITY_MAP = {
    # Malaysia
    "Sabah":             "Kota Kinabalu",
    "Sarawak":           "Kuching",
    "Johor":             "Johor Bahru",
    "Melaka":            "Melaka",
    "Selangor":          "Shah Alam",
    "Negeri Sembilan":   "Seremban",
    "Perak":             "Ipoh",
    "Kedah":             "Alor Setar",
    "Pahang":            "Kuantan",
    "Kelantan":          "Kota Bharu",
    "Terengganu":        "Kuala Terengganu",
    "Penang":            "George Town",
    "Perlis":            "Kangar",
    "Putrajaya":         "Putrajaya",
    "Kuala Lumpur":      "Kuala Lumpur",
    # Indonesia
    "West Kalimantan":   "Pontianak",
    "South Kalimantan":  "Banjarmasin",
    "Central Kalimantan":"Palangka Raya",
    "East Kalimantan":   "Samarinda",
    "Riau":              "Pekanbaru",
    "South Sumatera":    "Palembang",
    "Jambi":             "Jambi",
    "Aceh":              "Banda Aceh",
    "Jakarta":           "Jakarta",
    "Sulawesi":          "Makassar",
    "North Sulawesi":    "Manado",
    "Papua":             "Jayapura",
    "West Papua":        "Manokwari",
    # Singapore
    "South East":        "Singapore",
    "Central":           "Singapore",
    # Thailand
    "Nonthaburi":        "Nonthaburi",
    "Bangkok":           "Bangkok",
    # United Kingdom
    "England":           "London",
    "Scotland":          "Edinburgh",
    "Wales":             "Cardiff",
    # Netherlands
    "South Holland":     "Rotterdam",
    "North Holland":     "Amsterdam",
    "Utrecht":           "Utrecht",
    # South Africa
    "Boksburg":          "Boksburg",
    "Gauteng":           "Johannesburg",
    # Papua New Guinea
    "Madang":            "Madang",
    "West New Britain":  "Kimbe",
    "Milne Bay":         "Alotau",
    "Morobe":            "Lae",
    "Oro":               "Popondetta",
    "New Ireland":       "Kavieng",
    "Manus":             "Lorengau",
    "Gulf":              "Kerema",
    "Central":           "Port Moresby",
    "National Capital":  "Port Moresby",
    # Solomon Islands
    "Guadalcanal":       "Honiara",
    "Western Province":  "Gizo",
    "Malaita":           "Auki",
    "Isabel":            "Buala",
    # United States
    "California":        "Los Angeles",
}

# Specific facility-name to city overrides for known locations
FACILITY_CITY_OVERRIDES = {
    # SD Guthrie Malaysia HQ
    "Sime Darby Plantation Berhad Headquarters": "Petaling Jaya",
    "SD Guthrie Berhad":                         "Petaling Jaya",
    # Singapore
    "Sime Darby Singapore":                      "Singapore",
    # Netherlands - Rotterdam area
    "Sime Darby Unimills":                       "Rotterdam",
}

# ═══════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════

def fetch_json(url, headers):
    """Fetch JSON with retry on failure."""
    try:
        resp = requests.get(url, headers=headers, timeout=12, verify=False)
        if resp.status_code == 200:
            try:
                return resp.json()
            except Exception:
                return None
        return None
    except Exception as e:
        print(f"  [WARN] {url}: {e}")
        return None


def clean_text(text):
    """Remove HTML tags, # characters, normalize whitespace."""
    if not text:
        return ""
    # Remove HTML tags
    text = re.sub(r'<[^>]+>', ' ', text)
    # Remove hash
    text = text.replace('#', '')
    # Normalize whitespace
    text = re.sub(r'\s+', ' ', text).strip(' ,')
    return text


def detect_activity(name):
    """Classify facility activity from its name."""
    name_lower = name.lower()

    keywords = [
        ("biogas",             "Biogas Plant"),
        ("biodiesel",          "Biodiesel Plant"),
        ("kernel crushing",    "Kernel Crushing Plant"),
        ("copra crushing",     "Copra Crushing Plant"),
        ("copra",              "Copra Processing"),
        ("refinery",           "Refinery"),
        ("refining",           "Refinery"),
        ("oleochemical",       "Oleochemical Plant"),
        ("downstream",         "Downstream Manufacturing"),
        ("abattoir",           "Livestock Processing"),
        ("oil mill",           "Palm Oil Mill"),
        ("palm oil mill",      "Palm Oil Mill"),
        ("kernel mill",        "Palm Oil Mill"),
        ("sugar mill",         "Sugar Mill"),
        ("mill",               "Palm Oil Mill"),
        ("factory",            "Palm Oil Mill / Factory"),
        ("estate",             "Oil Palm Estate / Plantation"),
        ("plantation",         "Oil Palm Estate / Plantation"),
        ("research",           "Research and Development"),
        ("r&d",                "Research and Development"),
        ("tech center",        "Research and Development"),
        ("tech centre",        "Research and Development"),
        ("technology",         "Research and Development"),
        ("laboratory",         "Research and Development"),
        ("lab",                "Research and Development"),
        ("seeds",              "Seed Production"),
        ("nursery",            "Nursery"),
        ("headquarters",       "Corporate Headquarters"),
        ("head office",        "Corporate Headquarters"),
        ("registered office",  "Corporate Headquarters"),
        ("office",             "Office"),
        ("sales",              "Sales Office"),
        ("bulking",            "Bulking Terminal"),
        ("terminal",           "Bulking Terminal"),
        ("rubber",             "Rubber Processing"),
        ("cocoa",              "Cocoa Processing"),
        ("sugar",              "Sugar Processing"),
        ("cattle",             "Cattle Ranch"),
    ]

    for keyword, activity in keywords:
        if keyword in name_lower:
            return activity

    # Grouped estate names (e.g. "Kerdau + Jentar") = plantation complex
    if "+" in name and len(name) < 100:
        return "Oil Palm Estate / Plantation"

    return "Facility"


def get_city(facility_name, state, country):
    """Derive city for the facility."""
    # Check specific overrides first
    for k, v in FACILITY_CITY_OVERRIDES.items():
        if k.lower() in facility_name.lower():
            return v

    # Use state → city map
    city = STATE_TO_CITY_MAP.get(state, "")
    if city:
        return city

    # Country-level fallbacks
    country_city = {
        "Singapore":     "Singapore",
        "United States": "Los Angeles",
    }
    return country_city.get(country, state)


def build_address(name, state, country):
    """Build a geocoding-friendly address string."""
    parts = []
    if name:
        parts.append(name)
    if state and state != name:
        parts.append(state)
    if country:
        parts.append(country)
    addr = ", ".join(parts)
    # Ensure no # characters
    addr = addr.replace('#', '')
    return addr


def parse_mapplic_json(data, country_slug):
    """Extract individual facilities from one Mapplic JSON file."""
    records = []
    country_name = COUNTRY_NAME_MAP.get(country_slug, country_slug.title())
    country_iso3 = COUNTRY_ISO3_MAP.get(country_name, "")
    locations = data.get("locations", [])

    for loc in locations:
        state = clean_text(loc.get("title", ""))
        description = loc.get("description", "").strip()

        # Extract facility names from <p> tags inside description
        facility_names = re.findall(r'<p>(.*?)</p>', description, re.DOTALL)
        if not facility_names and description:
            # Fallback: treat description itself as the name
            facility_names = [description]

        # Coordinates at region level (shared for all facilities in region)
        lat = loc.get("lat", "") or ""
        lng = loc.get("lng", "") or ""

        for name_html in facility_names:
            name = clean_text(name_html)
            if not name:
                continue

            activity = detect_activity(name)
            city = get_city(name, state, country_name)
            address = build_address(name, state, country_name)

            records.append({
                "ISSUER_ID":               ISSUER_ID,
                "LOCATION_NAME":           name,
                "LOCATION_ADDRESS":        address,
                "LATITUDE":                str(lat) if lat else "",
                "LONGITUDE":               str(lng) if lng else "",
                "COUNTRY":                 country_name,
                "COUNTRY_ISO3":            country_iso3,
                "POSTCODE":                "",
                "STATE":                   state,
                "CITY":                    city,
                "SOURCE_URL":              SOURCE_URL,
                "SOURCE_TYPE":             SOURCE_TYPE,
                "ACTIVITY_AT_ASSET":       activity,
                "coord_source":            "website" if lat and lng else "",
                # Native language columns: all data is in English on this site
                "LOCATION_NAME_NATIVE":    "",
                "LOCATION_ADDRESS_NATIVE": "",
            })

    return records


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(TEMP_DIR, exist_ok=True)

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Accept":   "application/json, text/plain, */*",
        "Referer":  SOURCE_URL,
    }

    all_facilities = []
    print(f"Starting extraction for {ISSUER_NAME}...")

    for slug, max_idx in COUNTRY_SLUGS.items():
        print(f"\nProcessing: {slug} (indices 1–{max_idx})")
        for i in range(1, max_idx + 1):
            url = f"{BASE_URL}{THEME_PATH}/data-{slug}-{i}.json"
            data = fetch_json(url, headers)
            if data:
                recs = parse_mapplic_json(data, slug)
                all_facilities.extend(recs)
                print(f"  [{slug}-{i}] -> {len(recs)} facilities")
            else:
                print(f"  [{slug}-{i}] -> (no data / 404)")
            time.sleep(0.15)

    # Deduplicate by (name, state, country)
    seen = {}
    for f in all_facilities:
        key = (f["LOCATION_NAME"].lower().strip(),
               f["STATE"].lower().strip(),
               f["COUNTRY"].lower().strip())
        if key not in seen:
            seen[key] = f
    final_list = list(seen.values())

    print(f"\n{'='*50}")
    print(f"Total raw records:   {len(all_facilities)}")
    print(f"Unique records:      {len(final_list)}")

    # Save intermediate JSON to Temp
    temp_json = os.path.join(TEMP_DIR, f"{ISSUER_ID}_sdguthrie_intermediate.json")
    with open(temp_json, "w", encoding="utf-8") as f:
        json.dump(final_list, f, ensure_ascii=False, indent=2)
    print(f"Intermediate JSON:   {temp_json}")

    # ── Write final CSV ─────────────────────────────────────
    fieldnames = [
        "ISSUER_ID",
        "LOCATION_NAME",
        "LOCATION_ADDRESS",
        "LATITUDE",
        "LONGITUDE",
        "COUNTRY",
        "COUNTRY_ISO3",
        "POSTCODE",
        "STATE",
        "CITY",
        "SOURCE_URL",
        "SOURCE_TYPE",
        "ACTIVITY_AT_ASSET",
        "coord_source",
        "LOCATION_NAME_NATIVE",
        "LOCATION_ADDRESS_NATIVE",
    ]

    output_file = os.path.join(
        OUTPUT_DIR,
        f"{ISSUER_ID}_{ISSUER_NAME}.csv"
    )
    with open(output_file, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(final_list)

    print(f"Final CSV saved to:  {output_file}")
    print(f"\nCountry breakdown:")
    from collections import Counter
    ctr = Counter(r["COUNTRY"] for r in final_list)
    for country, cnt in ctr.most_common():
        print(f"  {country}: {cnt}")

    # Validation checks
    blank_city = [r for r in final_list if not r["CITY"]]
    blank_addr = [r for r in final_list if not r["LOCATION_ADDRESS"]]
    print(f"\nValidation:")
    print(f"  Blank CITY:    {len(blank_city)}")
    print(f"  Blank ADDRESS: {len(blank_addr)}")
    if blank_city:
        print("  Sample blank cities:")
        for r in blank_city[:5]:
            print(f"    {r['LOCATION_NAME']} | {r['STATE']} | {r['COUNTRY']}")


if __name__ == "__main__":
    main()
