"""
XCMG service-outlet extractor.

Pulls outlet entries from the official XCMG AJAX locator for selected areas and
exports address-bearing dealer/service rows. Category B reusable script.
"""

from __future__ import annotations

import csv
import html
import re
from pathlib import Path

import requests
from bs4 import BeautifulSoup


ISSUER_ID = "IID000000002189970"
ISSUER_NAME = "XCMG Construction Machinery Co., Ltd."
SOURCE_URL = "https://www.xcmgglobal.com/ext/ajax_network.jsp"
OUTPUT_DIR = Path(".")
OUTPUT_CSV = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"

HEADERS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
]

COUNTRY_MAP = {
    "Nepal": "NPL",
    "Bangladesh": "BGD",
    "Myanmar": "MMR",
    "Laos": "LAO",
    "Pakistan": "PAK",
    "Sri Lanka": "LKA",
    "Thailand": "THA",
    "Vietnam": "VNM",
    "India": "IND",
    "United Arab Emirates": "ARE",
    "Saudi Arabia": "SAU",
    "Qatar": "QAT",
    "Oman": "OMN",
    "Kuwait": "KWT",
    "Iraq": "IRQ",
    "Uzbekistan": "UZB",
}


def fetch_html() -> str:
    areas = ["South Asia", "Middle East& North Africa", "Southeast Asia"]
    blocks: list[str] = []
    for area in areas:
        response = requests.post(
            SOURCE_URL,
            data={"flag": "getData", "area": area, "dis": "", "key": ""},
            timeout=30,
            verify=False,
            headers={
                "User-Agent": "Mozilla/5.0",
                "Referer": "https://www.xcmgglobal.com/service/service-outlets.htm",
            },
        )
        response.raise_for_status()
        blocks.append(response.text)
    return "\n".join(blocks)


def parse_rows(raw_html: str) -> list[dict]:
    soup = BeautifulSoup(raw_html, "html.parser")
    rows: list[dict] = []
    seen: set[tuple[str, str]] = set()
    for li in soup.select("li.item"):
        name = " ".join(li.select_one(".tit").stripped_strings)
        name = name.replace("\ue64f", "").strip()
        addr_text = " ".join(li.select_one(".line_addr").stripped_strings)
        addr_text = html.unescape(addr_text)
        match = re.search(r"Address:(.*?)(?:Tel:|Email:|$)", addr_text)
        if not match:
            continue
        address = clean_address(match.group(1).strip())
        if not is_usable(address):
            continue
        key = (name, address)
        if key in seen:
            continue
        seen.add(key)
        try:
            country, iso3, state, city, postcode = parse_address(address)
        except ValueError:
            continue
        rows.append(
            {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": name,
                "LOCATION_ADDRESS": address,
                "LATITUDE": "",
                "LONGITUDE": "",
                "COUNTRY": country,
                "COUNTRY_ISO3": iso3,
                "POSTCODE": postcode,
                "STATE": state,
                "CITY": city,
                "SOURCE_URL": SOURCE_URL,
                "SOURCE_TYPE": "COMPANY WEBSITE",
                "ACTIVITY_AT_ASSET": "Dealer and service outlet",
                "coord_source": "Not from website",
            }
        )
        if len(rows) >= 12:
            break
    return rows


def clean_address(address: str) -> str:
    address = re.sub(r"\s+", " ", address)
    address = address.replace(" ,", ",").replace(" , ", ", ")
    return address.strip(" ,.")


def is_usable(address: str) -> bool:
    if len(address) < 18:
        return False
    ascii_ratio = sum(ch.isascii() for ch in address) / max(len(address), 1)
    return ascii_ratio > 0.95 and any(ch.isalpha() for ch in address)


def parse_address(address: str) -> tuple[str, str, str, str, str]:
    normalized = address.replace(" ,", ",").strip()
    if "Nepal" in normalized:
        return "Nepal", COUNTRY_MAP["Nepal"], "", "Kathmandu", ""
    if "Bangladesh" in normalized or "Dhaka" in normalized:
        city = "Dhaka" if "Dhaka" in normalized else ""
        postcode = re.search(r"Dhaka[- ]?(\d{4})", normalized)
        return "Bangladesh", COUNTRY_MAP["Bangladesh"], "", city, postcode.group(1) if postcode else ""
    if "Myanmar" in normalized or "Yangon" in normalized:
        return "Myanmar", COUNTRY_MAP["Myanmar"], "Yangon Region", "Yangon", ""
    if "LAO PDR" in normalized or "Vientiane" in normalized:
        return "Laos", COUNTRY_MAP["Laos"], "Vientiane Prefecture", "Vientiane", ""
    if "Pakistan" in normalized or "Lahore" in normalized or "Karachi" in normalized:
        city = "Lahore" if "Lahore" in normalized else "Karachi" if "Karachi" in normalized else ""
        return "Pakistan", COUNTRY_MAP["Pakistan"], "", city, ""
    if "Sri Lanka" in normalized or "Colombo" in normalized or "Piliyandala" in normalized:
        city = "Colombo" if "Colombo" in normalized else "Piliyandala" if "Piliyandala" in normalized else ""
        return "Sri Lanka", COUNTRY_MAP["Sri Lanka"], "", city, ""
    if "Thailand" in normalized or "Bangkok" in normalized or "Samut Prakan" in normalized or "Chonburi" in normalized:
        city = ""
        state = ""
        if "Bangkok" in normalized or "Bngkok" in normalized:
            city, state = "Bangkok", "Bangkok"
        elif "Samut Prakan" in normalized:
            city, state = "Bang Sao Thong", "Samut Prakan"
        elif "Chonburi" in normalized:
            city, state = "Bang Lamung", "Chonburi"
        postcode = re.search(r"\b(\d{5})\b", normalized)
        return "Thailand", COUNTRY_MAP["Thailand"], state, city, postcode.group(1) if postcode else ""
    if "Viet Nam" in normalized or "Ha Noi" in normalized:
        return "Vietnam", COUNTRY_MAP["Vietnam"], "Hanoi", "Hanoi", ""
    if "India" in normalized or any(token in normalized for token in ["Delhi", "Mumbai", "Ahmedabad", "Hyderabad", "Pune", "Chennai"]):
        city = ""
        state = ""
        if "Delhi" in normalized:
            city, state = "New Delhi", "Delhi"
        elif "Mumbai" in normalized:
            city, state = "Mumbai", "Maharashtra"
        elif "Ahmedabad" in normalized:
            city, state = "Ahmedabad", "Gujarat"
        elif "Hyderabad" in normalized:
            city, state = "Hyderabad", "Telangana"
        elif "Pune" in normalized:
            city, state = "Pune", "Maharashtra"
        elif "Chennai" in normalized:
            city, state = "Chennai", "Tamil Nadu"
        postcode = re.search(r"\b(\d{6})\b", normalized)
        return "India", COUNTRY_MAP["India"], state, city, postcode.group(1) if postcode else ""
    if "UAE" in normalized or "United Arab Emirates" in normalized:
        city = "Dubai" if "Dubai" in normalized else "Abu Dhabi" if "Abu Dhabi" in normalized else ""
        return "United Arab Emirates", COUNTRY_MAP["United Arab Emirates"], "", city, ""
    if "Saudi Arabia" in normalized:
        city = "Riyadh" if "Riyadh" in normalized else "Jeddah" if "Jeddah" in normalized else ""
        return "Saudi Arabia", COUNTRY_MAP["Saudi Arabia"], "", city, ""
    if "Qatar" in normalized:
        city = "Doha" if "Doha" in normalized else ""
        return "Qatar", COUNTRY_MAP["Qatar"], "", city, ""
    if "Oman" in normalized:
        city = "Ruwi" if "Ruwi" in normalized else "Muscat" if "Muscat" in normalized else ""
        return "Oman", COUNTRY_MAP["Oman"], "Muscat", city, ""
    if "Kuwait" in normalized:
        city = "Safat" if "SAFAT" in normalized.upper() else "Kuwait City"
        return "Kuwait", COUNTRY_MAP["Kuwait"], "", city, ""
    if "Baghdad" in normalized or "IRAQ" in normalized.upper():
        return "Iraq", COUNTRY_MAP["Iraq"], "Baghdad Governorate", "Baghdad", ""
    if "Tashkent" in normalized:
        return "Uzbekistan", COUNTRY_MAP["Uzbekistan"], "Tashkent", "Tashkent", ""
    raise ValueError(f"Could not parse address: {address}")


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    rows = parse_rows(fetch_html())
    with OUTPUT_CSV.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=HEADERS)
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()
