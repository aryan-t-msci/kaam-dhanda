"""WordPress brand-location Leaflet JSON extractor.

Platform: a WordPress page (theme block ``brand-location``) that renders a
Leaflet map and embeds the full marker dataset in the HTML as:

    <script type="application/json" class="brand-location__data">
        {"locations": [ ... ]}
    </script>

Each location has title, address, country, lat/lng, category, and contact
type. The on-page legend is a mix of those two fields. Production sites are
``category`` ``Malt_House`` / ``categoryText`` ``Production``, shown in the
legend as "Production / Commercial". They are not the contact-type values
(E-Shop, Reseller, Salesperson).

No geocoding is performed. Coordinates are taken only from the embedded JSON.

Configure the block below for a new issuer.

Usage:
    python wordpress_brand_location_leaflet_extractor.py
"""

from __future__ import annotations

import csv
import json
import re
import unicodedata
from pathlib import Path

import requests

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Edit this block for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_ID = "IID000000005120684"
ISSUER_NAME = "SOUFFLET MALT SAS"
COMPANY_NAME = "SOUFFLET MALT SAS"
PAGE_URL = "https://www.souffletmalt.com/where-to-buy/"
# Legend labels to keep. "Production / Commercial" is the visible legend
# text for categoryText "Production" (raw category "Malt_House").
KEEP_LEGEND_TAGS = ["Production / Commercial"]
ACTIVITY_AT_ASSET = "Malt production"
OUTPUT_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Barclays2 CQ\Assets to Add"
)
TEMP_DIR = OUTPUT_DIR / "_temp"
# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════

COLUMNS = [
    "ISSUER_ID",
    "COMPANY_NAME",
    "FACILITY_NAME",
    "FACILITY_ADDRESS",
    "CITY",
    "STATE",
    "POSTAL_CODE",
    "FACILITY_REGION",
    "COUNTRY_ISO3",
    "LATITUDE",
    "LONGITUDE",
    "coord_source",
    "ACTIVITY_AT_ASSET",
    "FACILITY_CONTACT_NUMBER",
    "SCOPE",
    "SCOPE_REASON",
    "RELEVANT_URL",
    "SOURCE_TYPE",
    "VALIDATION_URL",
    "VALIDATION_SOURCE_TYPE",
    "QA_flag",
    "FACILITY_NAME_NATIVE",
    "FACILITY_ADDRESS_NATIVE",
    "LEGEND_CATEGORY",
]

# Source country label -> (ISO 3166 English short name, ISO3).
# "(the)" forms follow U-10 for countries whose official short name uses it.
COUNTRY_MAP = {
    "australia": ("Australia", "AUS"),
    "belgium": ("Belgium", "BEL"),
    "brazil": ("Brazil", "BRA"),
    "bulgaria": ("Bulgaria", "BGR"),
    "canada": ("Canada", "CAN"),
    "czech republic": ("Czechia", "CZE"),
    "czechia": ("Czechia", "CZE"),
    "ethiopia": ("Ethiopia", "ETH"),
    "france": ("France", "FRA"),
    "india": ("India", "IND"),
    "kazakhstan": ("Kazakhstan", "KAZ"),
    "poland": ("Poland", "POL"),
    "romania": ("Romania", "ROU"),
    "russia": ("Russian Federation (the)", "RUS"),
    "russian federation": ("Russian Federation (the)", "RUS"),
    "serbia": ("Serbia", "SRB"),
    "ukraine": ("Ukraine", "UKR"),
    "united kingdom": (
        "United Kingdom of Great Britain and Northern Ireland (the)",
        "GBR",
    ),
    "uk": ("United Kingdom of Great Britain and Northern Ireland (the)", "GBR"),
    "united states of america": ("United States of America (the)", "USA"),
    "united states": ("United States of America (the)", "USA"),
    "usa": ("United States of America (the)", "USA"),
}

AU_STATES = {
    "VIC": "Victoria",
    "QLD": "Queensland",
    "NSW": "New South Wales",
    "WA": "Western Australia",
    "SA": "South Australia",
    "TAS": "Tasmania",
    "NT": "Northern Territory",
    "ACT": "Australian Capital Territory",
}
US_STATES = {
    "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas",
    "CA": "California", "CO": "Colorado", "CT": "Connecticut", "DE": "Delaware",
    "FL": "Florida", "GA": "Georgia", "HI": "Hawaii", "ID": "Idaho",
    "IL": "Illinois", "IN": "Indiana", "IA": "Iowa", "KS": "Kansas",
    "KY": "Kentucky", "LA": "Louisiana", "ME": "Maine", "MD": "Maryland",
    "MA": "Massachusetts", "MI": "Michigan", "MN": "Minnesota", "MS": "Mississippi",
    "MO": "Missouri", "MT": "Montana", "NE": "Nebraska", "NV": "Nevada",
    "NH": "New Hampshire", "NJ": "New Jersey", "NM": "New Mexico", "NY": "New York",
    "NC": "North Carolina", "ND": "North Dakota", "OH": "Ohio", "OK": "Oklahoma",
    "OR": "Oregon", "PA": "Pennsylvania", "RI": "Rhode Island", "SC": "South Carolina",
    "SD": "South Dakota", "TN": "Tennessee", "TX": "Texas", "UT": "Utah",
    "VT": "Vermont", "VA": "Virginia", "WA": "Washington", "WV": "West Virginia",
    "WI": "Wisconsin", "WY": "Wyoming", "DC": "District of Columbia",
}

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    )
}


def to_ascii(value: str) -> str:
    text = value or ""
    for src, dst in (("ß", "ss"), ("ä", "ae"), ("ö", "oe"), ("ü", "ue"),
                     ("Ä", "Ae"), ("Ö", "Oe"), ("Ü", "Ue")):
        text = text.replace(src, dst)
    decomposed = unicodedata.normalize("NFKD", text)
    return "".join(ch for ch in decomposed if not unicodedata.combining(ch))


def clean_space(value: str) -> str:
    return re.sub(r"\s+", " ", (value or "").replace("#", "")).strip(" ,")


def clean_phone(value: str) -> str:
    text = clean_space(value)
    text = re.sub(r"^Tel:\s*", "", text, flags=re.I)
    text = re.sub(r"\+\s+", "+", text)
    return text


def legend_tag(loc: dict) -> str:
    """Map a marker onto the five legend labels, using the site's markerType().

    Order matches brand-location-init.js: Heritage_Brand, then Malt_House,
    then contact type. Salesperson is colored with the production dot; the
    script comment labels that case "Commercial". Those rows are contacts,
    not plants, and are rejected later when they have no address.
    """
    category = (loc.get("category") or "").strip()
    contact = (loc.get("contactType") or "").strip()
    if category == "Heritage_Brand":
        return "Heritage Brand"
    if category == "Malt_House":
        return "Production / Commercial"
    if contact == "E-Shop":
        return "E-Shop"
    if contact == "Reseller":
        return "Reseller"
    if contact == "Salesperson":
        return "Production / Commercial"
    return "Other"


def fetch_locations(url: str) -> list[dict]:
    response = requests.get(url, headers=HEADERS, timeout=40)
    response.raise_for_status()
    html = response.text
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    (TEMP_DIR / "soufflet_wheretobuy_live.html").write_text(html, encoding="utf-8")
    match = re.search(
        r'<script[^>]*class="brand-location__data"[^>]*>\s*(\{.*?\})\s*</script>',
        html,
        flags=re.S,
    )
    if not match:
        raise RuntimeError("brand-location JSON block not found")
    payload = json.loads(match.group(1))
    return payload["locations"]


def country_of(raw: str) -> tuple[str, str]:
    key = clean_space(raw).lower()
    if key not in COUNTRY_MAP:
        raise KeyError(f"Unmapped country: {raw}")
    return COUNTRY_MAP[key]


def parse_local(local: str, iso3: str) -> tuple[str, str, str]:
    """Return city, state, postal from the address with the country removed."""
    text = clean_space(local)
    if iso3 == "AUS":
        matched = re.match(r"^(?P<city>.+?) (?P<st>[A-Z]{2,3}) (?P<pc>\d{4})$", text)
        if matched:
            return (
                matched.group("city"),
                AU_STATES.get(matched.group("st"), matched.group("st")),
                matched.group("pc"),
            )
    if iso3 == "USA":
        matched = re.match(r"^(?P<city>.+?) (?P<st>[A-Z]{2}) (?P<pc>\d{5})$", text)
        if matched:
            return (
                matched.group("city"),
                US_STATES.get(matched.group("st"), matched.group("st")),
                matched.group("pc"),
            )
    if iso3 == "CAN":
        matched = re.match(
            r"^(?P<city>.+?) (?P<pc>[A-Z]\d[A-Z] \d[A-Z]\d)$", text
        )
        if matched:
            return matched.group("city"), "", matched.group("pc")
    if iso3 == "BEL":
        matched = re.match(r"^(?P<pc>\d{4}) (?P<city>.+)$", text)
        if matched:
            return matched.group("city"), "", matched.group("pc")
    if iso3 == "BRA":
        matched = re.match(r"^(?P<city>.+?)\s+CEP\s+(?P<pc>[\d.]+-\d+)$", text, re.I)
        if matched:
            postal = matched.group("pc").replace(".", "")
            return matched.group("city"), "", postal
    if iso3 == "GBR":
        matched = re.match(
            r"^(?P<city>.+?) (?P<pc>[A-Z]{1,2}\d[A-Z\d]? \d[A-Z]{2})$", text
        )
        if matched:
            return matched.group("city"), "", matched.group("pc")
    if iso3 == "CZE":
        matched = re.match(r"^(?P<city>.+?) (?P<pc>\d{3} \d{2})$", text)
        if matched:
            return matched.group("city"), "", matched.group("pc")
    if iso3 == "POL":
        matched = re.match(r"^(?P<city>.+?) (?P<pc>\d{2}-\d{3})$", text)
        if matched:
            return matched.group("city"), "", matched.group("pc")
    if iso3 == "IND":
        matched = re.match(r"^(?P<city>.+?) (?P<pc>\d{3}\s?\d{3})$", text)
        if matched:
            return matched.group("city"), "", matched.group("pc").replace(" ", "")
    if iso3 == "ETH":
        matched = re.match(r"^(?P<city>.+?) (?P<pc>\d{2,4})$", text)
        if matched:
            return matched.group("city"), "", matched.group("pc")
    matched = re.match(r"^(?P<city>.+?) (?P<pc>\d{4,6})$", text)
    if matched:
        return matched.group("city"), "", matched.group("pc")
    return text, "", ""


def build_address(city: str, state: str, postal: str, region: str) -> str:
    parts = [p for p in (city, state, postal, region) if p]
    return ", ".join(parts)


def semantic_flags(row: dict) -> list[str]:
    flags = []
    city = row["CITY"]
    activity = row["ACTIVITY_AT_ASSET"]
    if re.match(r"^\d", city) or any(
        token in city for token in ("Floor", "Suite", "Level", "Unit", "#")
    ):
        flags.append("CITY_SUSPICIOUS")
    if city in {row["FACILITY_REGION"], row["COUNTRY_ISO3"]} or len(city) < 2 or len(city) > 60:
        flags.append("CITY_IS_COUNTRY" if city == row["FACILITY_REGION"] else "CITY_SUSPICIOUS")
    junk = ("Compare", "Add to", "Shop Now", "Click here", "Menu", "Search")
    if any(token.lower() in activity.lower() for token in junk):
        flags.append("ACTIVITY_JUNK")
    return flags


def row_from_location(loc: dict) -> tuple[dict | None, dict | None]:
    tag = legend_tag(loc)
    title_native = clean_space(loc.get("title") or "")
    address_native = clean_space(loc.get("address") or "")
    if not title_native or not address_native:
        return None, {
            "title": title_native,
            "address": address_native,
            "legend": tag,
            "rejection_reason": "Missing facility name or published address",
        }
    region, iso3 = country_of(loc.get("country") or "")
    local = address_native
    if "," in address_native:
        head, tail = address_native.rsplit(",", 1)
        if tail.strip().lower() in {
            (loc.get("country") or "").strip().lower(),
            "usa",
            "uk",
            "czechia",
        }:
            local = head
    city_raw, state, postal = parse_local(local, iso3)
    city = to_ascii(city_raw)
    if city in {"St Petersburg", "St. Petersburg"}:
        city = "Saint Petersburg"
    name = to_ascii(title_native)
    address_ascii_source = to_ascii(address_native)
    facility_address = build_address(city, state, postal, region)
    lat = loc.get("lat")
    lng = loc.get("lng")
    has_coords = lat not in (None, "") and lng not in (None, "")
    qa = []
    # Title place and published city disagree on two known markers.
    name_l = name.lower()
    if "alwar" in name_l and city.lower() == "new delhi":
        qa.append("FACILITY_ADDRESS")
    if "polisy" in name_l and city.lower() == "polisot":
        qa.append("CITY")
    if iso3 == "ETH" and postal and len(postal) < 4:
        qa.append("FACILITY_ADDRESS")
    row = {
        "ISSUER_ID": ISSUER_ID,
        "COMPANY_NAME": COMPANY_NAME,
        "FACILITY_NAME": name,
        "FACILITY_ADDRESS": facility_address,
        "CITY": city,
        "STATE": state,
        "POSTAL_CODE": postal,
        "FACILITY_REGION": region,
        "COUNTRY_ISO3": iso3,
        "LATITUDE": lat if has_coords else "",
        "LONGITUDE": lng if has_coords else "",
        "coord_source": "website" if has_coords else "Not from website",
        "ACTIVITY_AT_ASSET": ACTIVITY_AT_ASSET,
        "FACILITY_CONTACT_NUMBER": clean_phone(loc.get("phone") or ""),
        "SCOPE": "In-Scope",
        "SCOPE_REASON": (
            "In-scope: operational site: where-to-buy legend tags "
            f"{name} as Production / Commercial, category Malt_House"
        ),
        "RELEVANT_URL": PAGE_URL,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "VALIDATION_URL": "",
        "VALIDATION_SOURCE_TYPE": "",
        "QA_flag": "|".join(qa),
        "FACILITY_NAME_NATIVE": title_native if title_native != name else "",
        "FACILITY_ADDRESS_NATIVE": (
            address_ascii_source if address_ascii_source != address_native else ""
        ),
        "LEGEND_CATEGORY": tag,
    }
    # Keep the original address string when it still contains non-ASCII,
    # even if the rebuilt address is ASCII.
    if address_native != to_ascii(address_native):
        row["FACILITY_ADDRESS_NATIVE"] = address_native
    extra = semantic_flags(row)
    if extra:
        current = [part for part in row["QA_flag"].split("|") if part]
        row["QA_flag"] = "|".join(current + [flag for flag in extra if flag not in current])
    return row, None


def main() -> None:
    locations = fetch_locations(PAGE_URL)
    kept = []
    rejected = []
    seen = set()
    tag_counts: dict[str, int] = {}
    for loc in locations:
        tag = legend_tag(loc)
        tag_counts[tag] = tag_counts.get(tag, 0) + 1
        if tag not in KEEP_LEGEND_TAGS:
            continue
        if not clean_space(loc.get("address") or ""):
            rejected.append({
                "title": clean_space(loc.get("title") or ""),
                "address": "",
                "legend": tag,
                "rejection_reason": (
                    "No published address; Production/Commercial legend color is a "
                    "salesperson or customer-service contact, not a facility"
                ),
            })
            continue
        row, reject = row_from_location(loc)
        if reject:
            rejected.append(reject)
            continue
        key = (
            row["FACILITY_NAME"].lower(),
            row["FACILITY_ADDRESS"].lower(),
            row["COUNTRY_ISO3"],
        )
        if key in seen:
            rejected.append({
                "title": row["FACILITY_NAME"],
                "address": row["FACILITY_ADDRESS"],
                "legend": tag,
                "rejection_reason": "Duplicate facility",
            })
            continue
        seen.add(key)
        kept.append(row)

    kept.sort(key=lambda r: (r["FACILITY_REGION"], r["FACILITY_NAME"]))
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    out_csv = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
    with out_csv.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerows(kept)

    reject_path = TEMP_DIR / f"{ISSUER_ID}_rejected.csv"
    if rejected:
        with reject_path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(
                handle,
                fieldnames=["title", "address", "legend", "rejection_reason"],
            )
            writer.writeheader()
            writer.writerows(rejected)
    elif reject_path.exists():
        reject_path.unlink()

    qa = {
        "issuer": ISSUER_NAME,
        "source_locations": len(locations),
        "legend_counts": tag_counts,
        "kept": len(kept),
        "rejected": len(rejected),
        "tier_b": [r["FACILITY_NAME"] for r in kept if r["QA_flag"]],
        "rows": kept,
    }
    (TEMP_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_qa.json").write_text(
        json.dumps(qa, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"locations={len(locations)} kept={len(kept)} rejected={len(rejected)}")
    print("legend", tag_counts)
    print("wrote", out_csv)


if __name__ == "__main__":
    main()
