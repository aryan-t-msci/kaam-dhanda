"""
Alpha Bank S.A. — PDF Branch Extractor
=======================================
Platform Pattern: Tabular PDF Directory (Section 3.12)
Source: https://www.alpha.gr/-/media/alphagr/pdf-files/thirides_thisavrofilakiou_katastimata_alpha_bank_en.pdf
Issuer: ALPHA BANK S.A. (IID000000005041428)

This script extracts branch data from the Alpha Bank "Network Branches with Safe Deposit Boxes" PDF.
The PDF contains 3 pages of Greek-language region data (all in English transliteration already).

Columns in PDF: COUNTRY (Greek region) | BRANCH NAME | CATEGORY | ADDRESS | PHONE | E-MAIL

Usage:
    python alpha_bank_pdf_extractor.py

Output:
    - CSV to Output folder: IID000000005041428_ALPHA BANK S.A..csv
    - Intermediate files to Temp folder
"""

import pdfplumber
import pandas as pd
import re
import unicodedata
import sys
import os
from pathlib import Path

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
ISSUER_ID   = "IID000000005041428"
ISSUER_NAME = "ALPHA BANK S.A."
COUNTRY     = "Greece"
COUNTRY_ISO3 = "GRC"

PDF_PATH    = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp\alpha_bank_branches_en.pdf"
OUTPUT_DIR  = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output"
TEMP_DIR    = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp"
SOURCE_URL  = "https://www.alpha.gr/-/media/alphagr/pdf-files/thirides_thisavrofilakiou_katastimata_alpha_bank_en.pdf"
SOURCE_TYPE = "COMPANY WEBSITE"
ACTIVITY    = "Banking Branch / Safe Deposit Box"

# Greek prefecture (nomos) to region/state mapping
# These are the administrative regions of Greece
PREFECTURE_TO_REGION = {
    "ACHAIA": "Peloponnese, Western Greece and the Ionian",
    "AITOLOAKARNANIA": "Peloponnese, Western Greece and the Ionian",
    "ARGOLIDA": "Peloponnese, Western Greece and the Ionian",
    "ARKADIA": "Peloponnese, Western Greece and the Ionian",
    "ARTA": "Epirus",
    "ATTICA": "Attica",
    "CHALKIDIKI": "Central Macedonia",
    "CHANIA": "Crete",
    "CHIOS": "North Aegean",
    "CORFU": "Peloponnese, Western Greece and the Ionian",
    "CORINTHIA": "Peloponnese, Western Greece and the Ionian",
    "CYCLADES": "South Aegean",
    "DODECANESE": "South Aegean",
    "DRAMA": "Eastern Macedonia and Thrace",
    "EVIA": "Central Greece",
    "EVROS": "Eastern Macedonia and Thrace",
    "FTHIOTIDA": "Central Greece",
    "FLORINA": "Western Macedonia",
    "FOKIDA": "Central Greece",
    "GREVENA": "Western Macedonia",
    "HERAKLION": "Crete",
    "ILIA": "Peloponnese, Western Greece and the Ionian",
    "IMATHIA": "Central Macedonia",
    "IOANNINA": "Epirus",
    "KARDITSA": "Thessaly",
    "KASTORIA": "Western Macedonia",
    "KAVALA": "Eastern Macedonia and Thrace",
    "KEFALONIA": "Peloponnese, Western Greece and the Ionian",
    "KILKIS": "Central Macedonia",
    "KOZANI": "Western Macedonia",
    "LACONIA": "Peloponnese, Western Greece and the Ionian",
    "LARISSA": "Thessaly",
    "LASITHI": "Crete",
    "LEFKADA": "Peloponnese, Western Greece and the Ionian",
    "LESVOS": "North Aegean",
    "MAGNESIA": "Thessaly",
    "MESSENIA": "Peloponnese, Western Greece and the Ionian",
    "PELLA": "Central Macedonia",
    "PHOCIS": "Central Greece",
    "PIERIA": "Central Macedonia",
    "PREVEZA": "Epirus",
    "RETHYMNO": "Crete",
    "RHODOPE": "Eastern Macedonia and Thrace",
    "SAMOS": "North Aegean",
    "SERRES": "Central Macedonia",
    "THESPROTIA": "Epirus",
    "THESSALONIKI": "Central Macedonia",
    "TRIKALA": "Thessaly",
    "VIOTIA": "Central Greece",
    "XANTHI": "Eastern Macedonia and Thrace",
    "ZAKYNTHOS": "Peloponnese, Western Greece and the Ionian",
}

# ═══════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════

def transliterate_to_ascii(text: str) -> str:
    """Transliterate text to ASCII, preserving meaning."""
    if not text:
        return text
    # NFKD normalization to decompose accented characters
    text_norm = unicodedata.normalize('NFKD', text)
    # Encode to ASCII ignoring non-ASCII, then decode
    text_ascii = text_norm.encode('ascii', 'ignore').decode('ascii')
    # Clean up extra whitespace
    text_ascii = re.sub(r'\s+', ' ', text_ascii).strip()
    return text_ascii

def clean_address(address: str) -> str:
    """Remove # and other geocoding-unfriendly characters."""
    if not address:
        return address
    address = address.replace('#', '')
    address = re.sub(r'\s+', ' ', address).strip()
    return address

def parse_city_from_address(address: str, branch_name: str) -> str:
    """
    Extract city from the branch address or branch name.
    Greek addresses often don't explicitly state the city in the address field;
    the city is embedded in the branch name.
    """
    if not address:
        return ""
    
    # Try to extract city from address - often the last comma-separated part
    # or the part before/after the street number
    # Greek addresses format: "Number, Street Name" or "Street Name, Number"
    # City is often in branch name
    
    # Extract city from branch name (common pattern: "CityName" or "Name - CityName")
    city = ""
    if ' - ' in branch_name:
        parts = branch_name.split(' - ')
        city = parts[-1].strip()  # e.g., "Psila Alonia - Patrai" → "Patrai"
    else:
        # Branch name IS the city name typically
        # Strip trailing category/qualifier words
        city = branch_name.strip()
        # Remove trailing letters that look like branch codes
        city = re.sub(r'\s+[A-Z]$', '', city).strip()
    
    return city

def get_state_from_prefecture(prefecture: str) -> str:
    """Map Greek prefecture to administrative region."""
    return PREFECTURE_TO_REGION.get(prefecture.upper(), prefecture)


# ═══════════════════════════════════════════════════════════
# MAIN EXTRACTION
# ═══════════════════════════════════════════════════════════

def extract_pdf_data():
    """Extract all branch data from the Alpha Bank PDF."""
    records = []
    
    # Lines that are headers or artifacts to skip
    SKIP_PATTERNS = [
        r'^LIMITED DISTRIBUTION',
        r'^#\s*$',
        r'^COUNTRY\s+BRANCH',
        r'^NETWORK BRANCHES',
        r'^\s*$',
    ]
    
    # Email pattern to identify email column
    EMAIL_RE = re.compile(r'^branch\d+@alpha\.gr$|^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$')
    # Phone pattern: 10-digit Greek number
    PHONE_RE = re.compile(r'^\d{3}\s+\d{3}\s+\d{4}$|\d{10,}')
    
    current_prefecture = None
    
    with pdfplumber.open(PDF_PATH) as pdf:
        print(f"Processing {len(pdf.pages)} pages...")
        
        for page_num, page in enumerate(pdf.pages):
            text = page.extract_text()
            if not text:
                continue
            
            lines = text.split('\n')
            
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                
                # Skip header/artifact lines
                skip = False
                for pattern in SKIP_PATTERNS:
                    if re.match(pattern, line, re.IGNORECASE):
                        skip = True
                        break
                if skip:
                    continue
                
                # Try to parse the line as a data row
                # Format: PREFECTURE BRANCH_NAME CATEGORY ADDRESS PHONE EMAIL
                # or continuation of ATTICA block (no prefecture prefix since current_prefecture is set)
                
                # Split by multiple spaces (columns separated by >=2 spaces)
                # But we need to be careful — address has spaces too
                
                # Strategy: parse using known patterns
                # - First token could be a KNOWN PREFECTURE → update current_prefecture
                # - Second token = branch name (1+ words until we hit A/B/C category)
                # - Then category (A, B, or C)
                # - Then address (until phone number pattern)
                # - Then phone (10-digit pattern with spaces)
                # - Then email
                
                record = parse_line(line, current_prefecture)
                
                if record:
                    if record.get('_prefecture_only'):
                        current_prefecture = record['prefecture']
                        continue
                    current_prefecture = record.get('prefecture', current_prefecture)
                    records.append(record)
    
    return records


def parse_line(line: str, current_prefecture: str) -> dict | None:
    """
    Parse a single line from the PDF text.
    Lines are in format: [PREFECTURE] BRANCH_NAME CATEGORY ADDRESS PHONE EMAIL
    Some lines start with just a prefecture name (continuation marker).
    """
    
    # Known Greek prefectures (all uppercase)
    KNOWN_PREFECTURES = set(PREFECTURE_TO_REGION.keys()) | {
        "ATTICA", "THESSALONIKI", "HERAKLION", "LARISSA", "MAGNESIA",
        "CORINTHIA", "EVIA", "FTHIOTIDA", "FOKIDA", "VIOTIA",
        "CYCLADES", "DODECANESE", "CHALKIDIKI", "PIERIA", "PELLA",
        "SERRES", "DRAMA", "KAVALA", "XANTHI", "RHODOPE", "EVROS",
        "LESVOS", "CHIOS", "SAMOS", "KOZANI", "FLORINA", "GREVENA",
        "KASTORIA", "IOANNINA", "THESPROTIA", "PREVEZA", "ARTA",
        "TRIKALA", "KARDITSA", "LARISSA", "CORFU", "LEFKADA",
        "KEFALONIA", "ZAKYNTHOS", "ACHAIA", "ILIA", "AITOLOAKARNANIA",
        "ARGOLIDA", "ARKADIA", "LACONIA", "MESSENIA", "CHANIA",
        "RETHYMNO", "LASITHI", "IMATHIA", "KILKIS"
    }
    
    # Category codes used by Alpha Bank
    CATEGORY_CODES = {'A', 'B', 'C'}
    
    # Check if line is just a prefecture header
    # e.g., "ATTICA" alone or "THESSALONIKI" alone  
    if line.upper() in KNOWN_PREFECTURES and len(line.split()) == 1:
        return {'_prefecture_only': True, 'prefecture': line.upper()}
    
    # Try to find email at end of line
    email = ""
    phone = ""
    tokens = line.split()
    
    if not tokens:
        return None
    
    # Detect email (last token)
    if tokens and re.match(r'^branch\d+@alpha\.gr$|^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$', tokens[-1]):
        email = tokens[-1]
        tokens = tokens[:-1]
    
    if not tokens:
        return None
    
    # Detect phone (last 3 tokens forming phone: NNN NNN NNNN)
    # Or the last single token if it's a 10-digit number
    if len(tokens) >= 3:
        potential_phone = ' '.join(tokens[-3:])
        if re.match(r'^\d{3}\s\d{3}\s\d{4}$', potential_phone):
            phone = potential_phone
            tokens = tokens[:-3]
        elif len(tokens) >= 2:
            potential_phone2 = ' '.join(tokens[-2:])
            if re.match(r'^\d{3}\s\d{7}$', potential_phone2):
                phone = potential_phone2
                tokens = tokens[:-2]
    
    if not tokens:
        return None
    
    # Now we have: [PREFECTURE] BRANCH_NAME CATEGORY ADDRESS_PARTS
    # Find the category code (A, B, or C) which is a single letter
    # It separates branch name from address
    
    category = ""
    category_idx = -1
    for i, tok in enumerate(tokens):
        if tok in CATEGORY_CODES and i > 0:
            category = tok
            category_idx = i
            break
    
    if category_idx < 0:
        # No category found, might be a continuation line or malformed
        return None
    
    # First token - check if it's a prefecture
    first_token = tokens[0].upper()
    prefecture = current_prefecture
    branch_name_start = 0
    
    if first_token in KNOWN_PREFECTURES:
        prefecture = first_token
        branch_name_start = 1
    
    # Branch name = tokens from branch_name_start to category_idx
    branch_name = ' '.join(tokens[branch_name_start:category_idx])
    
    # Address = tokens after category
    address_parts = tokens[category_idx+1:]
    address = ' '.join(address_parts)
    
    if not branch_name or not address:
        return None
    
    # Clean address
    address = clean_address(address)
    
    # Extract city from branch name
    city = parse_city_from_address(address, branch_name)
    
    # Get state/region from prefecture
    state = get_state_from_prefecture(prefecture) if prefecture else ""
    
    return {
        'prefecture': prefecture,
        'branch_name': branch_name,
        'category': category,
        'address': address,
        'phone': phone,
        'email': email,
        'city': city,
        'state': state,
    }


def build_full_address(address: str, city: str, country: str = "Greece") -> str:
    """Build a geocoding-friendly full address."""
    parts = []
    if address:
        parts.append(address)
    if city and city.lower() not in address.lower():
        parts.append(city)
    parts.append(country)
    return ', '.join(parts)


def build_csv(records: list) -> pd.DataFrame:
    """Build the final CSV DataFrame from extracted records."""
    rows = []
    
    for rec in records:
        branch_name = rec.get('branch_name', '').strip()
        prefecture = rec.get('prefecture', '').strip()
        address = rec.get('address', '').strip()
        city = rec.get('city', '').strip()
        state = rec.get('state', '').strip()
        phone = rec.get('phone', '').strip()
        
        # Build full address for geocoding
        # Greek addresses: street+number, city, region, country
        full_address = address
        if city and city.lower() not in address.lower():
            full_address = f"{address}, {city}"
        
        # LOCATION_NAME = branch name
        location_name = branch_name
        
        # Build the LOCATION_ADDRESS as geocoding-friendly string
        location_address = clean_address(full_address)
        
        # CITY: from branch name parsing
        # If city couldn't be extracted from branch name, use prefecture capital or branch name
        if not city:
            city = branch_name  # Branch name often IS the city
        
        row = {
            'ISSUER_ID': ISSUER_ID,
            'ISSUER_NAME': ISSUER_NAME,
            'LOCATION_NAME': location_name,
            'LOCATION_NAME_LOCAL': location_name,  # Already in English transliteration
            'LOCATION_ADDRESS': location_address,
            'LOCATION_ADDRESS_LOCAL': location_address,  # Already in English
            'LATITUDE': '',
            'LONGITUDE': '',
            'COUNTRY': COUNTRY,
            'COUNTRY_ISO3': COUNTRY_ISO3,
            'POSTCODE': '',  # Not provided in the PDF
            'STATE': state,
            'CITY': city,
            'SOURCE_URL': SOURCE_URL,
            'SOURCE_TYPE': SOURCE_TYPE,
            'ACTIVITY_AT_ASSET': ACTIVITY,
            'PHONE': phone,
            'CATEGORY': rec.get('category', ''),
            'PREFECTURE': prefecture,
            'coord_source': '',  # No coordinates in source
        }
        rows.append(row)
    
    df = pd.DataFrame(rows)
    return df


if __name__ == '__main__':
    print("Alpha Bank S.A. — PDF Branch Extractor")
    print("=" * 60)
    
    # Extract data
    print(f"\nExtracting data from PDF: {PDF_PATH}")
    records = extract_pdf_data()
    print(f"Raw records extracted: {len(records)}")
    
    if records:
        # Show sample
        print("\nSample records (first 5):")
        for r in records[:5]:
            print(f"  Prefecture: {r['prefecture']}")
            print(f"  Branch: {r['branch_name']}")
            print(f"  Address: {r['address']}")
            print(f"  City: {r['city']}")
            print(f"  Phone: {r['phone']}")
            print()
        
        # Build DataFrame
        df = build_csv(records)
        print(f"\nDataFrame shape: {df.shape}")
        print(f"Columns: {list(df.columns)}")
        
        # Save intermediate CSV to Temp
        temp_csv = os.path.join(TEMP_DIR, f"{ISSUER_ID}_alpha_bank_intermediate.csv")
        df.to_csv(temp_csv, index=False, encoding='utf-8-sig')
        print(f"\nIntermediate CSV saved to: {temp_csv}")
        
        # Stats
        print(f"\nRecords by prefecture:")
        for pref, cnt in df['PREFECTURE'].value_counts().items():
            print(f"  {pref}: {cnt}")
        
        print(f"\nTotal records: {len(df)}")
    else:
        print("No records extracted!")
        sys.exit(1)
