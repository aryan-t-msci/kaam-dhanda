"""
Privia / myPrivia care-center location extractor.

Pattern handled:
- Static Drupal sitemap directory pages that link to practice homepages.
- Practice homepages expose static `section#cc-locations` blocks.
- Each location usually has a linked `/locations/...` detail page with the cleanest
  address, phone, and coordinate data.

How to reuse:
- Update the configuration block only.
- Keep the extraction logic generic for similar Drupal care-center networks.

Usage:
    python privia_myprivia_crawl.py
"""

from __future__ import annotations

import csv
import json
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup, Tag


# =============================================================================
# CONFIGURATION - Edit this block for each new issuer
# =============================================================================
ISSUER_ID = "IID000000005040216"
ISSUER_NAME = "PRIVIA HEALTH GROUP, INC."
BASE_URL = "https://www.myprivia.com"
SITEMAP_URL = f"{BASE_URL}/sitemap"
CONTACT_URL = f"{BASE_URL}/contact-us"
OUTPUT_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Run_asset_completeness_ondemand_batch7_8___straive_copy\IID000000005040216_PRIVIA HEALTH GROUP, INC."
)
STAGING_CSV = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Run_asset_completeness_ondemand_batch7_8___straive_copy\staging\IID000000005040216_PRIVIA HEALTH GROUP, INC..csv"
)
CHECKPOINT_CSV = OUTPUT_DIR / "checkpoint_rows.csv"
SUMMARY_JSON = OUTPUT_DIR / "crawl_summary.json"
PROGRESS_JSON = OUTPUT_DIR / "crawl_progress.json"
SAVE_EVERY = 20
REQUEST_TIMEOUT = 30
REQUEST_DELAY_SECONDS = 0.05


# =============================================================================
# GENERIC EXTRACTION LOGIC - Do not modify per issuer
# =============================================================================
CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
]

GENERIC_LOCATION_NAMES = {
    "main office",
    "office",
    "main location",
    "location",
    "clinic",
}


@dataclass
class PracticeLocation:
    practice_name: str
    practice_url: str
    location_name: str
    detail_url: str | None
    inline_address_lines: list[str]
    inline_latitude: str
    inline_longitude: str
    practice_description: str


def build_session() -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"
            )
        }
    )
    return session


def fetch(session: requests.Session, url: str) -> str:
    response = session.get(url, timeout=REQUEST_TIMEOUT)
    response.raise_for_status()
    response.encoding = "utf-8"
    time.sleep(REQUEST_DELAY_SECONDS)
    return response.text


def clean_text(value: str) -> str:
    value = value.replace("\xa0", " ")
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def clean_address_line(value: str) -> str:
    value = clean_text(value).replace("#", "")
    return value.strip(" ,")


def extract_last_page_index(soup: BeautifulSoup) -> int:
    page_numbers: list[int] = []
    for link in soup.select("ul.pagination a[href*='?page=']"):
        href = link.get("href", "")
        match = re.search(r"[?&]page=(\d+)", href)
        if match:
            page_numbers.append(int(match.group(1)))
    return max(page_numbers) if page_numbers else 0


def extract_practice_urls(soup: BeautifulSoup) -> list[str]:
    urls: list[str] = []
    for anchor in soup.select(".view-sitemap .view-content li a[href^='/']"):
        href = anchor.get("href", "")
        if not href or href.startswith("/sitemap") or href.startswith("/node/"):
            continue
        urls.append(urljoin(BASE_URL, href))
    return urls


def parse_practice_name(soup: BeautifulSoup) -> str:
    if soup.title and soup.title.string:
        return clean_text(soup.title.string.split("|")[0])
    h1 = soup.find("h1")
    if h1:
        return clean_text(h1.get_text(" ", strip=True))
    return ""


def parse_practice_description(soup: BeautifulSoup) -> str:
    meta = soup.find("meta", attrs={"name": "description"})
    if meta and meta.get("content"):
        return clean_text(meta["content"])
    return ""


def extract_city_state_postcode(address_lines: list[str]) -> tuple[str, str, str]:
    lines = normalize_address_lines(address_lines)
    if not lines:
        return "", "", ""
    full_text = " ".join(lines)
    matches = re.findall(
        r"([A-Za-z][A-Za-z .'-]+?),\s*([A-Z]{2})(?:\s+(\d{5}(?:-\d{4})?))?",
        full_text,
    )
    if matches:
        city, state, postcode = next((m for m in reversed(matches) if m[2]), matches[-1])
        return clean_text(city), state, postcode

    last_line = clean_text(lines[-1])
    match = re.search(
        r"^(?P<city>.*?),\s*(?P<state>[A-Z]{2})\s+(?P<postcode>\d{5}(?:-\d{4})?)$",
        last_line,
    )
    if match:
        return (
            clean_text(match.group("city")),
            match.group("state"),
            match.group("postcode"),
        )
    match = re.search(
        r"^(?P<city>.+?)\s+(?P<state>[A-Z]{2})\s+(?P<postcode>\d{5}(?:-\d{4})?)$",
        last_line,
    )
    if match:
        return (
            clean_text(match.group("city")),
            match.group("state"),
            match.group("postcode"),
    )
    return "", "", ""


def normalize_address_lines(address_lines: list[str]) -> list[str]:
    lines = [clean_address_line(x) for x in address_lines if clean_address_line(x)]
    if len(lines) >= 3 and re.fullmatch(r"[A-Z]{2}", lines[-2]) and re.fullmatch(
        r"\d{5}(?:-\d{4})?", lines[-1]
    ):
        city = lines[-3].rstrip(",")
        lines = lines[:-3] + [f"{city}, {lines[-2]} {lines[-1]}"]
    return lines


def normalize_location_name(practice_name: str, location_name: str) -> str:
    name = clean_text(location_name)
    if not name:
        return practice_name
    if name.lower() in GENERIC_LOCATION_NAMES and practice_name:
        return f"{name} - {practice_name}"
    return name


def address_lines_from_location_container(container: Tag) -> list[str]:
    lines: list[str] = []
    for cell in container.select(".location-address td"):
        text = clean_address_line(cell.get_text(" ", strip=True))
        if not text or "Get Directions" in text:
            continue
        lines.append(text)
    return lines


def address_lines_from_detail_page(soup: BeautifulSoup) -> list[str]:
    paragraph = soup.select_one("div.location-details div.map-location-address p")
    if paragraph:
        lines = [
            clean_address_line(line)
            for line in paragraph.get_text("\n", strip=True).splitlines()
            if clean_address_line(line)
        ]
        if lines:
            return lines

    lines = []
    for cell in soup.select(".location-address td"):
        text = clean_address_line(cell.get_text(" ", strip=True))
        if not text or "Get Directions" in text:
            continue
        lines.append(text)
    return lines


def map_points_from_section(section: Tag) -> list[dict[str, str]]:
    points: list[dict[str, str]] = []
    for point in section.select(".geolocation-location[data-lat][data-lng]"):
        title = clean_text(point.get_text(" ", strip=True))
        points.append(
            {
                "title": title,
                "lat": clean_text(point.get("data-lat", "")),
                "lng": clean_text(point.get("data-lng", "")),
            }
        )
    return points


def extract_lat_lng_from_html(html: str) -> tuple[str, str]:
    lat_match = re.search(r'data-lat="([^"]+)"', html)
    lng_match = re.search(r'data-lng="([^"]+)"', html)
    return (
        clean_text(lat_match.group(1)) if lat_match else "",
        clean_text(lng_match.group(1)) if lng_match else "",
    )


def location_candidates_from_practice(practice_url: str, html: str) -> list[PracticeLocation]:
    soup = BeautifulSoup(html, "html.parser")
    practice_name = parse_practice_name(soup)
    practice_description = parse_practice_description(soup)
    section = soup.select_one("section#cc-locations")
    if not section:
        return []

    points = map_points_from_section(section)
    items = section.select(".accordion-item")
    if not items:
        items = section.select(".location-address-hours")

    candidates: list[PracticeLocation] = []
    for index, item in enumerate(items):
        name_el = item.select_one(".accordion-button")
        location_name = clean_text(name_el.get_text(" ", strip=True)) if name_el else ""

        address_owner = item
        if "accordion-item" in item.get("class", []):
            body = item.select_one(".accordion-body")
            if body:
                address_owner = body

        address_lines = address_lines_from_location_container(address_owner)
        detail_link = address_owner.select_one("a.btn-seafoam[href*='/locations/']")
        if not detail_link:
            detail_links = address_owner.select("a[href*='/locations/']")
            detail_link = detail_links[-1] if detail_links else None
        detail_url = urljoin(BASE_URL, detail_link["href"]) if detail_link else None

        lat = ""
        lng = ""
        if index < len(points):
            lat = points[index]["lat"]
            lng = points[index]["lng"]

        candidates.append(
            PracticeLocation(
                practice_name=practice_name,
                practice_url=practice_url,
                location_name=location_name,
                detail_url=detail_url,
                inline_address_lines=address_lines,
                inline_latitude=lat,
                inline_longitude=lng,
                practice_description=practice_description,
            )
        )
    return candidates


def parse_detail_page(
    practice_name: str,
    practice_description: str,
    location_name_hint: str,
    detail_url: str,
    html: str,
) -> dict[str, str]:
    soup = BeautifulSoup(html, "html.parser")
    heading = soup.find("h1")
    location_name = clean_text(heading.get_text(" ", strip=True)) if heading else location_name_hint
    if (
        not location_name
        or location_name.lower().startswith("contact us")
        or location_name.lower() == "location"
    ):
        location_name = location_name_hint
    address_lines = address_lines_from_detail_page(soup)

    if not address_lines:
        address_lines = footer_address_lines(soup)

    lat, lng = extract_lat_lng_from_html(html)

    return build_row(
        practice_name=practice_name,
        practice_description=practice_description,
        location_name=location_name,
        address_lines=address_lines,
        latitude=lat,
        longitude=lng,
        source_url=detail_url,
    )


def footer_address_lines(soup: BeautifulSoup) -> list[str]:
    lines: list[str] = []
    for selector in [".footer-one-address1", ".footer-one-address2", ".footer-one-address3"]:
        node = soup.select_one(selector)
        if node:
            text = clean_address_line(node.get_text(" ", strip=True))
            if text:
                lines.append(text)
    return lines


def footer_city_line_from_text(soup: BeautifulSoup) -> str:
    text = soup.get_text("\n", strip=True)
    match = re.search(r"\b([A-Za-z][A-Za-z .'-]+,\s*[A-Z]{2}\s+\d{5}(?:-\d{4})?)\b", text)
    return clean_text(match.group(1)) if match else ""


def fallback_row_from_practice_page(practice_url: str, html: str) -> dict[str, str] | None:
    soup = BeautifulSoup(html, "html.parser")
    practice_name = parse_practice_name(soup)
    practice_description = parse_practice_description(soup)
    address_lines = footer_address_lines(soup)
    city_line = footer_city_line_from_text(soup)
    if city_line and (not address_lines or city_line not in address_lines):
        address_lines.append(city_line)
    if not address_lines:
        return None

    text = soup.get_text("\n", strip=True)
    location_name_match = re.search(r"\n([A-Za-z0-9&()'.,/ -]+Office)\n", text)
    location_name = clean_text(location_name_match.group(1)) if location_name_match else practice_name

    return build_row(
        practice_name=practice_name,
        practice_description=practice_description,
        location_name=location_name,
        address_lines=address_lines,
        latitude="",
        longitude="",
        source_url=practice_url,
    )


def build_row(
    practice_name: str,
    practice_description: str,
    location_name: str,
    address_lines: list[str],
    latitude: str,
    longitude: str,
    source_url: str,
) -> dict[str, str]:
    address_lines = normalize_address_lines(address_lines)
    location_address = ", ".join(address_lines)
    city, state, postcode = extract_city_state_postcode(address_lines)

    activity = clean_text(practice_name) or "Medical practice"
    if not activity and "medical practice" in practice_description.lower():
        activity = "Medical practice"

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": normalize_location_name(practice_name, location_name),
        "LOCATION_ADDRESS": location_address,
        "LATITUDE": latitude,
        "LONGITUDE": longitude,
        "COUNTRY": "United States",
        "COUNTRY_ISO3": "USA",
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": source_url,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": activity,
        "coord_source": "website" if latitude and longitude else "Not from website",
        "QA_flag": "",
    }


def fallback_row(candidate: PracticeLocation) -> dict[str, str]:
    return build_row(
        practice_name=candidate.practice_name,
        practice_description=candidate.practice_description,
        location_name=candidate.location_name,
        address_lines=candidate.inline_address_lines,
        latitude=candidate.inline_latitude,
        longitude=candidate.inline_longitude,
        source_url=candidate.practice_url,
    )


def write_csv(path: Path, rows: Iterable[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in CSV_COLUMNS})


def write_progress(
    processed_practices: int,
    total_practices: int,
    rows: list[dict[str, str]],
    summary: dict[str, object],
) -> None:
    PROGRESS_JSON.write_text(
        json.dumps(
            {
                "processed_practices": processed_practices,
                "total_practices": total_practices,
                "rows_found": len(rows),
                **summary,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    write_csv(CHECKPOINT_CSV, rows)


def add_hq_row(session: requests.Session, rows: list[dict[str, str]]) -> None:
    html = fetch(session, CONTACT_URL)
    soup = BeautifulSoup(html, "html.parser")
    address_lines = []
    for line in soup.select("h2, h3, p"):
        text = clean_text(line.get_text(" ", strip=True))
        if text == "Privia Health":
            address_lines = []
            continue
        if address_lines or text == "950 N. Glebe Road":
            if text in {
                "Corporate Phone: (571) 366-8850",
                "No medical care is delivered at this address",
            }:
                continue
            if text == "Privia Health":
                continue
            if text and not text.startswith("For general questions"):
                address_lines.append(text)
            if text.endswith("22203"):
                break

    if not address_lines:
        address_lines = ["950 N. Glebe Road", "Suite 700", "Arlington, VA 22203"]

    city, state, postcode = extract_city_state_postcode(address_lines)
    rows.append(
        {
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": "Privia Health Corporate Headquarters",
            "LOCATION_ADDRESS": ", ".join(address_lines),
            "LATITUDE": "",
            "LONGITUDE": "",
            "COUNTRY": "United States",
            "COUNTRY_ISO3": "USA",
            "POSTCODE": postcode,
            "STATE": state,
            "CITY": city or "Arlington",
            "SOURCE_URL": CONTACT_URL,
            "SOURCE_TYPE": "COMPANY WEBSITE",
            "ACTIVITY_AT_ASSET": "Corporate headquarters",
            "coord_source": "Not from website",
            "QA_flag": "",
        }
    )


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    session = build_session()

    sitemap_html = fetch(session, SITEMAP_URL)
    sitemap_soup = BeautifulSoup(sitemap_html, "html.parser")
    last_page_index = extract_last_page_index(sitemap_soup)

    practice_urls: list[str] = []
    practice_urls.extend(extract_practice_urls(sitemap_soup))
    for page_index in range(1, last_page_index + 1):
        page_html = fetch(session, f"{SITEMAP_URL}?page={page_index}")
        page_soup = BeautifulSoup(page_html, "html.parser")
        practice_urls.extend(extract_practice_urls(page_soup))

    seen_practice_urls: set[str] = set()
    unique_practice_urls: list[str] = []
    for url in practice_urls:
        if url not in seen_practice_urls:
            seen_practice_urls.add(url)
            unique_practice_urls.append(url)

    rows: list[dict[str, str]] = []
    seen_row_keys: set[tuple[str, str, str]] = set()
    summary: dict[str, object] = {
        "sitemap_pages": last_page_index + 1,
        "practice_urls": len(unique_practice_urls),
        "practice_pages_without_locations": [],
        "location_detail_pages_used": 0,
        "inline_fallback_rows": 0,
        "urls_attempted": len(unique_practice_urls) + (last_page_index + 1) + 1,
    }

    for idx, practice_url in enumerate(unique_practice_urls, start=1):
        practice_html = fetch(session, practice_url)
        candidates = location_candidates_from_practice(practice_url, practice_html)
        if not candidates:
            fallback = fallback_row_from_practice_page(practice_url, practice_html)
            if fallback:
                key = (fallback["LOCATION_NAME"], fallback["LOCATION_ADDRESS"], fallback["SOURCE_URL"])
                if key not in seen_row_keys:
                    seen_row_keys.add(key)
                    rows.append(fallback)
            else:
                cast_list = summary["practice_pages_without_locations"]
                assert isinstance(cast_list, list)
                cast_list.append(practice_url)
            if idx % SAVE_EVERY == 0:
                write_progress(idx, len(unique_practice_urls), rows, summary)
            continue

        for candidate in candidates:
            row: dict[str, str]
            if candidate.detail_url:
                try:
                    detail_html = fetch(session, candidate.detail_url)
                    row = parse_detail_page(
                        practice_name=candidate.practice_name,
                        practice_description=candidate.practice_description,
                        location_name_hint=candidate.location_name,
                        detail_url=candidate.detail_url,
                        html=detail_html,
                    )
                    summary["location_detail_pages_used"] = int(summary["location_detail_pages_used"]) + 1
                except Exception:
                    row = fallback_row(candidate)
                    summary["inline_fallback_rows"] = int(summary["inline_fallback_rows"]) + 1
            else:
                row = fallback_row(candidate)
                summary["inline_fallback_rows"] = int(summary["inline_fallback_rows"]) + 1

            key = (row["LOCATION_NAME"], row["LOCATION_ADDRESS"], row["SOURCE_URL"])
            if key in seen_row_keys:
                continue
            seen_row_keys.add(key)
            rows.append(row)

        if idx % SAVE_EVERY == 0:
            write_progress(idx, len(unique_practice_urls), rows, summary)

    add_hq_row(session, rows)
    summary["final_rows"] = len(rows)
    write_progress(len(unique_practice_urls), len(unique_practice_urls), rows, summary)
    write_csv(STAGING_CSV, rows)
    SUMMARY_JSON.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
