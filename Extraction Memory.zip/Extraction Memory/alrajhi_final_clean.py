"""
Al Rajhi Bank — Final Clean Pass
Removes diacritical/extended Latin characters from addresses
to ensure pure ASCII/UTF-8 geocoding-friendly output.
"""
import csv
import sys
import unicodedata
import re
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

OUTPUT_PATH = Path(r'C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output\IID000000002154955_AL RAJHI BANKING AND INVESTMENT CORPORATION SJSC.csv')

COLS = [
    "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS",
    "LATITUDE", "LONGITUDE", "COUNTRY", "COUNTRY_ISO3", "POSTCODE",
    "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE", "ACTIVITY_AT_ASSET",
    "LOCATION_NAME_NATIVE", "LOCATION_ADDRESS_NATIVE", "coord_source",
]


def normalize_to_ascii(text: str) -> str:
    """
    Normalize extended Latin / diacritical characters to plain ASCII.
    e.g., Ḥa'il → Ha'il, Khālid → Khalid
    Also handles Arabic characters by removing them.
    """
    if not text:
        return text
    
    # First, remove Arabic/RTL characters
    text = re.sub(r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF\u200F\u200E]', '', text)
    
    # Normalize diacritical marks using NFKD decomposition
    # This separates base characters from their diacritics
    normalized = unicodedata.normalize('NFKD', text)
    
    # Keep only ASCII characters (removes combining diacritics)
    ascii_text = normalized.encode('ascii', 'ignore').decode('ascii')
    
    # Clean up any resulting double spaces or stray punctuation
    ascii_text = re.sub(r'\s+', ' ', ascii_text)
    ascii_text = re.sub(r',\s*,', ',', ascii_text)
    ascii_text = re.sub(r'^,\s*', '', ascii_text)
    ascii_text = re.sub(r',\s*$', '', ascii_text)
    
    return ascii_text.strip()


def main():
    print("Al Rajhi Bank — Final Clean Pass")
    print("=" * 50)
    
    with open(OUTPUT_PATH, encoding='utf-8-sig') as f:
        rows = list(csv.DictReader(f))
    
    print(f"Loaded: {len(rows)} rows")
    
    cleaned = 0
    for row in rows:
        for field in ['LOCATION_ADDRESS', 'CITY', 'STATE', 'LOCATION_NAME']:
            original = row.get(field, '')
            if original and any(ord(c) > 127 for c in original):
                cleaned_val = normalize_to_ascii(original)
                if cleaned_val != original:
                    row[field] = cleaned_val
                    cleaned += 1
    
    print(f"Fields normalized: {cleaned}")
    
    # Re-validate
    non_ascii = [r for r in rows if any(ord(c) > 127 for c in r.get('LOCATION_ADDRESS', ''))]
    blank_city = [r for r in rows if not r.get('CITY', '').strip()]
    has_hash = [r for r in rows if '#' in r.get('LOCATION_ADDRESS', '')]
    
    print(f"Remaining non-ASCII in LOCATION_ADDRESS: {len(non_ascii)}")
    print(f"Blank CITY: {len(blank_city)}")
    print(f"Has #: {len(has_hash)}")
    
    # Show sample cleaned records
    print("\nSample records after cleaning:")
    for r in rows[:3]:
        print(f"  Name: {r['LOCATION_NAME']}")
        print(f"  Address: {r['LOCATION_ADDRESS']}")
        print(f"  City: {r['CITY']}")
        print(f"  State: {r['STATE']}")
        print()
    
    # Write back
    with open(OUTPUT_PATH, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=COLS)
        writer.writeheader()
        writer.writerows(rows)
    
    print(f"Written: {OUTPUT_PATH}")
    print(f"Total records: {len(rows)}")


if __name__ == "__main__":
    main()
