"""
Generic extractor for static HTML location directories built from grouped tables.

Pattern handled:
- A listing page contains one or more section headings followed by a table.
- Each table row represents one location.
- `rowspan` cells carry the city/market label and activity label for subsequent rows.
- The location address is stored in a detail cell, commonly in `<b class="address">`.
- Non-address metadata such as telephone, fax, and business hours are present in the
  same cell but separated by `<br>` tags.

This script is configured for Spring Airlines' business-place directory, but the
extraction logic is generalized for similar grouped-table directory pages.

Usage:
    python -X utf8 static_html_rowspan_table_extractor.py

Outputs:
- Progress JSON, raw rows JSON, checkpoint CSV, working CSV, run summary JSON, and a
  memory-append draft in TEMP_DIR
- Final CSV in OUTPUT_DIR
"""

from __future__ import annotations

import csv
import json
import re
import time
import unicodedata
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List

import requests
from bs4 import BeautifulSoup, Tag
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


# ============================================================
# CONFIGURATION - Change these for each issuer
# ============================================================
ISSUER_ID = "IID000000002718252"
ISSUER_NAME = "Spring Airlines Co., Ltd."
SOURCE_URL = "https://en.ch.com/flights/business-place/"
SOURCE_TYPE = "COMPANY WEBSITE"

TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")
OUTPUT_BASENAME = f"{ISSUER_ID}_{ISSUER_NAME}"
CHECKPOINT_THRESHOLD = 50
PROGRESS_EVERY = 20

HEADING_SELECTOR = "h2"
TABLE_SELECTOR = "table.list"
CITY_CELL_CLASS = "des"
ACTIVITY_CELL_CLASS = "place"
ADDRESS_SELECTOR = "b.address"

FINAL_CSV = OUTPUT_DIR / f"{OUTPUT_BASENAME}.csv"
CHECKPOINT_CSV = TEMP_DIR / f"{OUTPUT_BASENAME}_checkpoint.csv"
WORKING_CSV = TEMP_DIR / f"{OUTPUT_BASENAME}_working.csv"
PROGRESS_JSON = TEMP_DIR / f"{ISSUER_ID}_progress.json"
RAW_ROWS_JSON = TEMP_DIR / f"{ISSUER_ID}_raw_rows.json"
SUMMARY_JSON = TEMP_DIR / f"{ISSUER_ID}_run_summary.json"
MEMORY_DRAFT_MD = TEMP_DIR / f"{ISSUER_ID}_extraction_memory_note.md"

REQUEST_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/135.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": SOURCE_URL,
}


# ============================================================
# GENERIC EXTRACTION LOGIC BELOW - Do not modify per issuer
# ============================================================
CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS",
    "LOCATION_ADDRESS_NATIVE",
    "LATITUDE",
    "LONGITUDE",
    "coord_source",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
]

CITY_METADATA: Dict[str, Dict[str, str]] = {
    "Shanghai": {"country": "China", "iso3": "CHN", "state": "Shanghai", "city": "Shanghai"},
    "Beijing": {"country": "China", "iso3": "CHN", "state": "Beijing", "city": "Beijing"},
    "Shijiazhuang": {"country": "China", "iso3": "CHN", "state": "Hebei", "city": "Shijiazhuang"},
    "Beihai": {"country": "China", "iso3": "CHN", "state": "Guangxi", "city": "Beihai"},
    "Shenyang": {"country": "China", "iso3": "CHN", "state": "Liaoning", "city": "Shenyang"},
    "Taiyuan": {"country": "China", "iso3": "CHN", "state": "Shanxi", "city": "Taiyuan"},
    "Changchun": {"country": "China", "iso3": "CHN", "state": "Jilin", "city": "Changchun"},
    "Chengdu": {"country": "China", "iso3": "CHN", "state": "Sichuan", "city": "Chengdu"},
    "Chongqing": {"country": "China", "iso3": "CHN", "state": "Chongqing", "city": "Chongqing"},
    "Changsha": {"country": "China", "iso3": "CHN", "state": "Hunan", "city": "Changsha"},
    "Dalian": {"country": "China", "iso3": "CHN", "state": "Liaoning", "city": "Dalian"},
    "Fuzhou": {"country": "China", "iso3": "CHN", "state": "Fujian", "city": "Fuzhou"},
    "Guangzhou": {"country": "China", "iso3": "CHN", "state": "Guangdong", "city": "Guangzhou"},
    "Guiyang": {"country": "China", "iso3": "CHN", "state": "Guizhou", "city": "Guiyang"},
    "Guilin": {"country": "China", "iso3": "CHN", "state": "Guangxi", "city": "Guilin"},
    "Harbin": {"country": "China", "iso3": "CHN", "state": "Heilongjiang", "city": "Harbin"},
    "Hangzhou": {"country": "China", "iso3": "CHN", "state": "Zhejiang", "city": "Hangzhou"},
    "Hohhot": {"country": "China", "iso3": "CHN", "state": "Inner Mongolia", "city": "Hohhot"},
    "Kunming": {"country": "China", "iso3": "CHN", "state": "Yunnan", "city": "Kunming"},
    "Lanzhou": {"country": "China", "iso3": "CHN", "state": "Gansu", "city": "Lanzhou"},
    "Mianyang": {"country": "China", "iso3": "CHN", "state": "Sichuan", "city": "Mianyang"},
    "Nanchang": {"country": "China", "iso3": "CHN", "state": "Jiangxi", "city": "Nanchang"},
    "Ningbo": {"country": "China", "iso3": "CHN", "state": "Zhejiang", "city": "Ningbo"},
    "Nanjing": {"country": "China", "iso3": "CHN", "state": "Jiangsu", "city": "Nanjing"},
    "Nanning": {"country": "China", "iso3": "CHN", "state": "Guangxi", "city": "Nanning"},
    "Qingdao": {"country": "China", "iso3": "CHN", "state": "Shandong", "city": "Qingdao"},
    "Shantou": {"country": "China", "iso3": "CHN", "state": "Guangdong", "city": "Shantou"},
    "Shenzhen": {"country": "China", "iso3": "CHN", "state": "Guangdong", "city": "Shenzhen"},
    "Tianjin": {"country": "China", "iso3": "CHN", "state": "Tianjin", "city": "Tianjin"},
    "Wuhan": {"country": "China", "iso3": "CHN", "state": "Hubei", "city": "Wuhan"},
    "Xi'an": {"country": "China", "iso3": "CHN", "state": "Shaanxi", "city": "Xi'an"},
    "Xiamen": {"country": "China", "iso3": "CHN", "state": "Fujian", "city": "Xiamen"},
    "Yantai": {"country": "China", "iso3": "CHN", "state": "Shandong", "city": "Yantai"},
    "Zhengzhou": {"country": "China", "iso3": "CHN", "state": "Henan", "city": "Zhengzhou"},
    "Zhuhai": {"country": "China", "iso3": "CHN", "state": "Guangdong", "city": "Zhuhai"},
    "Yinchuan": {"country": "China", "iso3": "CHN", "state": "Ningxia", "city": "Yinchuan"},
    "Yangzhou": {"country": "China", "iso3": "CHN", "state": "Jiangsu", "city": "Yangzhou"},
    "Tokyo": {"country": "Japan", "iso3": "JPN", "state": "Chiba", "city": "Narita"},
    "Hong Kong": {"country": "Hong Kong", "iso3": "HKG", "state": "Hong Kong", "city": "Hong Kong"},
    "Macau": {"country": "Macau", "iso3": "MAC", "state": "Macau", "city": "Macau"},
    "Taipei": {"country": "Taiwan", "iso3": "TWN", "state": "Taipei", "city": "Taipei"},
    "Bangkok": {"country": "Thailand", "iso3": "THA", "state": "Bangkok", "city": "Bangkok"},
}

POSTCODE_PATTERNS = {
    "China": r"\b\d{6}\b",
    "Japan": r"\b\d{3}-\d{4}\b",
    "Taiwan": r"\b\d{5}\b",
    "Thailand": r"\b\d{5}\b",
}

FULLWIDTH_TRANSLATION = str.maketrans(
    {
        "，": ",",
        "：": ":",
        "（": "(",
        "）": ")",
        "－": "-",
        "—": "-",
        "–": "-",
        "／": "/",
        "。": ".",
        "　": " ",
    }
)

UNWANTED_ADDRESS_PATTERNS = [
    r"\(\s*unable to print itinerary[^)]*\)",
    r"\(\s*unable to print itinerary due to equipment issues[^)]*\)",
    r"\(\s*due to equipment issues[^)]*\)",
    r",\s*self-coded\s*\d+\b",
]


def build_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=4,
        connect=4,
        read=4,
        status=4,
        backoff_factor=1.0,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET"],
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=8, pool_maxsize=8)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.headers.update(REQUEST_HEADERS)
    session.verify = False
    requests.packages.urllib3.disable_warnings()  # type: ignore[attr-defined]
    return session


def normalize_whitespace(text: str) -> str:
    text = text.translate(FULLWIDTH_TRANSLATION)
    text = text.replace("\xa0", " ")
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\s+,", ",", text)
    text = re.sub(r",\s*", ", ", text)
    text = re.sub(r"\s*;\s*", "; ", text)
    return text.strip(" ,;")


def ascii_clean(text: str) -> str:
    if not text:
        return ""
    text = normalize_whitespace(text)
    text = text.replace("#", " ")
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\s+([,;:./-])", r"\1", text)
    return text.strip(" ,;")


def extract_page_html(session: requests.Session, url: str) -> str:
    response = session.get(url, timeout=30)
    response.raise_for_status()
    return response.text


def get_direct_text_lines(cell: Tag) -> List[str]:
    lines = [
        normalize_whitespace(fragment)
        for fragment in cell.get_text("\n", strip=True).splitlines()
        if normalize_whitespace(fragment)
    ]
    return lines


def parse_address_cell(cell: Tag) -> Dict[str, str]:
    address_tag = cell.select_one(ADDRESS_SELECTOR)
    lines = get_direct_text_lines(cell)
    address = normalize_whitespace(address_tag.get_text(" ", strip=True)) if address_tag else (lines[0] if lines else "")
    phone = ""
    fax = ""
    hours = ""
    for line in lines[1:] if address_tag and lines else lines[1:]:
        lower_line = line.lower()
        if lower_line.startswith("tel:"):
            phone = line.split(":", 1)[1].strip()
        elif lower_line.startswith("fax:"):
            fax = line.split(":", 1)[1].strip()
        elif lower_line.startswith("business hours:"):
            hours = line.split(":", 1)[1].strip()
    if not address and lines:
        address = lines[0]
    return {"address": address, "phone": phone, "fax": fax, "hours": hours}


def clean_address(address: str) -> str:
    cleaned = normalize_whitespace(address)
    cleaned = re.sub(r"^Address:\s*", "", cleaned, flags=re.IGNORECASE)
    for pattern in UNWANTED_ADDRESS_PATTERNS:
        cleaned = re.sub(pattern, "", cleaned, flags=re.IGNORECASE)
    cleaned = cleaned.replace("#", " ")
    cleaned = cleaned.replace("Terminal 1.D Island", "Terminal 1, D Island")
    cleaned = cleaned.replace("Mon-Fir", "Mon-Fri")
    cleaned = re.sub(r"\s*;\s*", ", ", cleaned)
    cleaned = re.sub(r"(?<=\w)\(", " (", cleaned)
    cleaned = normalize_whitespace(cleaned)
    return cleaned


def ensure_address_context(address: str, city: str, state: str, country: str) -> str:
    parts: List[str] = [address]
    haystack = f" {address.lower()} "
    for component in [city, state, country]:
        if not component:
            continue
        component_lower = component.lower()
        if component_lower not in haystack:
            parts.append(component)
            haystack += f"{component_lower} "
    unique_parts: List[str] = []
    for part in parts:
        if part and part not in unique_parts:
            unique_parts.append(part)
    return normalize_whitespace(", ".join(unique_parts))


def singularize_activity(activity: str) -> str:
    if activity == "Airport Ticket Counters":
        return "Airport Ticket Counter"
    if activity == "Spring Ticketing Outlets":
        return "Spring Ticketing Outlet"
    return activity.rstrip("s") if activity.endswith("s") else activity


def short_descriptor(address: str) -> str:
    descriptor = re.sub(r"\([^)]*\)", "", address)
    descriptor = normalize_whitespace(descriptor)
    if len(descriptor) <= 70:
        return descriptor
    head = ", ".join(descriptor.split(", ")[:3])
    return head if head else descriptor[:70].rstrip(", ")


def build_location_name(city_group: str, activity: str, address: str) -> str:
    return normalize_whitespace(f"{city_group} {singularize_activity(activity)} - {short_descriptor(address)}")


def extract_postcode(country: str, address: str) -> str:
    pattern = POSTCODE_PATTERNS.get(country)
    if not pattern:
        return ""
    match = re.search(pattern, address)
    return match.group(0) if match else ""


def resolve_city(metadata_city: str, city_group: str, address: str) -> str:
    address_ascii = ascii_clean(address).lower()
    if city_group == "Tokyo":
        if "narita" in address_ascii:
            return "Narita"
    return metadata_city


def resolve_state(metadata_state: str, city_group: str, address: str) -> str:
    address_ascii = ascii_clean(address).lower()
    if city_group == "Tokyo" and "chiba" in address_ascii:
        return "Chiba"
    return metadata_state


def write_csv(path: Path, rows: Iterable[Dict[str, str]]) -> None:
    rows = list(rows)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in CSV_COLUMNS})


def save_progress(rows: List[Dict[str, str]], processed_count: int, checkpoint_written: bool) -> None:
    payload = {
        "processed_count": processed_count,
        "checkpoint_written": checkpoint_written,
        "row_count": len(rows),
        "updated_utc": datetime.now(timezone.utc).isoformat(),
    }
    PROGRESS_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def parse_tables(html: str) -> List[Dict[str, str]]:
    soup = BeautifulSoup(html, "html.parser")
    parsed_rows: List[Dict[str, str]] = []
    current_city = ""
    current_activity = ""
    per_group_counter: Dict[tuple[str, str], int] = defaultdict(int)

    for heading in soup.select(HEADING_SELECTOR):
        section_name = normalize_whitespace(heading.get_text(" ", strip=True))
        table = heading.find_next_sibling("table")
        if not table or TABLE_SELECTOR.split(".")[-1] not in " ".join(table.get("class", [])):
            continue

        for tr in table.select("tr"):
            cells = tr.find_all("td", recursive=False)
            if not cells:
                continue
            index = 0
            first_classes = cells[0].get("class", [])
            if CITY_CELL_CLASS in first_classes:
                current_city = normalize_whitespace(cells[0].get_text(" ", strip=True))
                index += 1

            if index < len(cells) and ACTIVITY_CELL_CLASS in cells[index].get("class", []):
                current_activity = normalize_whitespace(cells[index].get_text(" ", strip=True))
                index += 1

            if not current_city or not current_activity or index >= len(cells):
                continue

            metadata = CITY_METADATA[current_city]
            detail = parse_address_cell(cells[index])
            raw_address = clean_address(detail["address"])
            city = resolve_city(metadata["city"], current_city, raw_address)
            state = resolve_state(metadata["state"], current_city, raw_address)
            contextual_address = ensure_address_context(raw_address, city, state, metadata["country"])
            ascii_address = ascii_clean(contextual_address)
            ascii_city = ascii_clean(city)
            ascii_state = ascii_clean(state)
            ascii_country = ascii_clean(metadata["country"])

            per_group_counter[(current_city, current_activity)] += 1
            location_name = build_location_name(current_city, current_activity, ascii_address)

            parsed_rows.append(
                {
                    "ISSUER_ID": ISSUER_ID,
                    "ISSUER_NAME": ISSUER_NAME,
                    "LOCATION_NAME": location_name,
                    "LOCATION_NAME_NATIVE": "",
                    "LOCATION_ADDRESS": ascii_address,
                    "LOCATION_ADDRESS_NATIVE": "",
                    "LATITUDE": "",
                    "LONGITUDE": "",
                    "coord_source": "not available on website",
                    "COUNTRY": ascii_country,
                    "COUNTRY_ISO3": metadata["iso3"],
                    "POSTCODE": extract_postcode(metadata["country"], ascii_address),
                    "STATE": ascii_state,
                    "CITY": ascii_city,
                    "SOURCE_URL": SOURCE_URL,
                    "SOURCE_TYPE": SOURCE_TYPE,
                    "ACTIVITY_AT_ASSET": current_activity,
                    "_section_name": section_name,
                    "_city_group": current_city,
                    "_phone": detail["phone"],
                    "_fax": detail["fax"],
                    "_business_hours": detail["hours"],
                }
            )
    return parsed_rows


def validate_rows(rows: List[Dict[str, str]]) -> None:
    missing_city = [row["LOCATION_NAME"] for row in rows if not row["CITY"].strip()]
    missing_address = [row["LOCATION_NAME"] for row in rows if not row["LOCATION_ADDRESS"].strip()]
    if missing_city or missing_address:
        raise ValueError(
            f"Validation failed. Missing city rows: {missing_city[:5]} | Missing address rows: {missing_address[:5]}"
        )


def write_memory_draft(total_rows: int) -> None:
    draft = f"""### 4.X {ISSUER_NAME} (Apr 2026)

| Source | URL | Records | Method | Script |
|--------|-----|---------|--------|--------|
| Spring Business Space | https://en.ch.com/flights/business-place/ | {total_rows} | Static HTML grouped-table parse with rowspan city/activity inheritance | `static_html_rowspan_table_extractor.py` |
| **TOTAL** | | **{total_rows}** | | |

**Platform Pattern**: [Reference to Section 3.5 Static HTML Card-Based Layouts] and [Reference to Section 3.7 Direct Contact Page Scraping] - specifically a server-rendered grouped table where the city (`td.des`) and activity (`td.place`) are inherited across multiple rows via `rowspan`.

**Key Approach**: The provided Spring Airlines page is fully server-rendered HTML. Each facility row can be extracted directly from the two `table.list` elements by carrying forward the current city and activity label whenever later rows omit those cells because of `rowspan`.

**Approaches Tried** (chronological):
1. Read the extraction memory and matched the site to the static-HTML family before writing any code - result: avoided unnecessary Playwright/API exploration.
2. Inspected the raw HTML of `https://en.ch.com/flights/business-place/` - result: confirmed the directory is stored in two server-rendered tables under `h2` headings, with address blocks inside `b.address`.
3. Checked the page for website-published coordinates - result: no `lat`, `lng`, map embeds, or coordinate attributes were present.
4. Final working approach: built a generalized grouped-table extractor that carries forward `rowspan` city/activity values, cleans the address text, appends missing city/state/country context for geocoding-friendly output, and writes a checkpoint CSV at 50 records before completing the full export.

**Key Learnings**:
- [OK] Plain HTTP fetch + BeautifulSoup was sufficient; no browser automation was needed.
- [OK] `rowspan` inheritance is the critical parser rule here: later rows may contain only the detail cell, so the previous city/activity values must be retained.
- [OK] Address enrichment is useful for airport counters because many website rows omit the city/country in the visible address text.
- [NO] The page does not publish coordinates, so `LATITUDE` and `LONGITUDE` must remain blank and `coord_source` should explicitly say they were not available on the website.

**Script Config** (for reuse with the generalized script):
```python
ISSUER_ID = "{ISSUER_ID}"
ISSUER_NAME = "{ISSUER_NAME}"
SOURCE_URL = "https://en.ch.com/flights/business-place/"
HEADING_SELECTOR = "h2"
TABLE_SELECTOR = "table.list"
CITY_CELL_CLASS = "des"
ACTIVITY_CELL_CLASS = "place"
ADDRESS_SELECTOR = "b.address"
```

### Section 9 Addition

| `static_html_rowspan_table_extractor.py` | {ISSUER_NAME} (Generic) | Static HTML grouped table | `rowspan` inheritance for city/activity labels, `b.address` extraction, checkpoint CSV at threshold |

### Section 10 Addition

- Static HTML directory tables that use `rowspan` often omit city/activity cells on subsequent rows; keep the last seen values in memory while iterating the detail rows.
"""
    MEMORY_DRAFT_MD.write_text(draft, encoding="utf-8")


def main() -> None:
    start_ts = time.time()
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    session = build_session()
    html = extract_page_html(session, SOURCE_URL)
    parsed_rows = parse_tables(html)
    validate_rows(parsed_rows)

    RAW_ROWS_JSON.write_text(json.dumps(parsed_rows, ensure_ascii=False, indent=2), encoding="utf-8")

    checkpoint_written = False
    working_rows: List[Dict[str, str]] = []
    for index, row in enumerate(parsed_rows, start=1):
        working_rows.append(row)
        if index % PROGRESS_EVERY == 0:
            save_progress(working_rows, index, checkpoint_written)
        if index == CHECKPOINT_THRESHOLD and not checkpoint_written:
            write_csv(CHECKPOINT_CSV, working_rows)
            checkpoint_written = True
            save_progress(working_rows, index, checkpoint_written)

    write_csv(WORKING_CSV, parsed_rows)
    write_csv(FINAL_CSV, parsed_rows)
    save_progress(parsed_rows, len(parsed_rows), checkpoint_written)
    write_memory_draft(len(parsed_rows))

    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "source_url": SOURCE_URL,
        "pattern_match": "Static HTML grouped-table directory with rowspan inheritance",
        "records_extracted": len(parsed_rows),
        "checkpoint_threshold": CHECKPOINT_THRESHOLD,
        "checkpoint_csv": str(CHECKPOINT_CSV),
        "working_csv": str(WORKING_CSV),
        "final_csv": str(FINAL_CSV),
        "memory_draft": str(MEMORY_DRAFT_MD),
        "progress_every": PROGRESS_EVERY,
        "coordinates_from_website": 0,
        "duration_seconds": round(time.time() - start_ts, 2),
        "completed_utc": datetime.now(timezone.utc).isoformat(),
    }
    SUMMARY_JSON.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
