"""WordPress plant-directory extractor for sites that 403 raw HTTP clients.

Platform: listing/detail plant pages with Google Maps embed iframe
(`maps.google.com/maps?q=...&output=embed`). Configure BASE_URL and listing paths
in the config block. No geocoding is performed.

Usage: python hinojosa_browser_extract.py
"""
from __future__ import annotations

import json
import re
import time
from pathlib import Path
from urllib.parse import parse_qs, unquote, urljoin, urlparse

from playwright.sync_api import sync_playwright

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Edit this block for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_ID = "IID000000000HINOJOSA"
ISSUER_NAME = "HINOJOSA GROUP"
BASE_URL = "https://hinojosagroup.com"
LISTING_PATHS = [
    "/en/plants/",
    "/plantas/",
    "/en/type-of-plant/packaging/",
    "/en/type-of-plant/packaging/page/2/",
    "/en/type-of-plant/paper/",
    "/tipo-de-planta/oficinas-hinojosa/",
]
OUT_DIR = Path(__file__).parent
RAW_JSON = OUT_DIR / "hinojosa_raw_plants.json"
PROGRESS_JSON = OUT_DIR / "hinojosa_progress.json"
# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════

SKIP_SLUGS = {"", "en", "plants", "plantas", "#", "#content"}
PHONE_RE = re.compile(r"(?:\+|00)?\d[\d\s().-]{7,}\d")
LATLNG_Q_RE = re.compile(r"^(-?\d+\.\d+)\s*,\s*(-?\d+\.\d+)$")
EMBED_2D3D_RE = re.compile(r"!2d(-?\d+\.\d+)!3d(-?\d+\.\d+)")
EMBED_3D2D_RE = re.compile(r"!3d(-?\d+\.\d+)!2d(-?\d+\.\d+)")
AT_RE = re.compile(r"@(-?\d+\.\d+),(-?\d+\.\d+)")


def clean(value: str) -> str:
    return re.sub(r"\s+", " ", (value or "").replace("\xa0", " ")).strip()


def is_plant_url(href: str) -> bool:
    if not href:
        return False
    p = urlparse(href.split("#")[0])
    if "hinojosagroup.com" not in (p.netloc or ""):
        return False
    parts = [x for x in p.path.strip("/").split("/") if x]
    if len(parts) < 2:
        return False
    if parts[0] in {"plants", "plantas"} and parts[1] not in SKIP_SLUGS:
        return True
    if len(parts) >= 3 and parts[0] == "en" and parts[1] in {"plants", "plantas"} and parts[2] not in SKIP_SLUGS:
        return True
    return False


def english_url(url: str) -> str:
    parsed = urlparse(url)
    path = parsed.path
    if path.startswith("/plantas/"):
        path = "/en/plants/" + path[len("/plantas/") :]
    elif path.startswith("/plants/") and not path.startswith("/en/"):
        path = "/en" + path
    return f"{BASE_URL}{path}"


def map_query(src: str) -> str:
    if not src:
        return ""
    q = parse_qs(urlparse(src).query).get("q", [""])[0]
    return clean(unquote(q))


def coords_from_src(src: str):
    if not src:
        return "", ""
    m = EMBED_2D3D_RE.search(src)
    if m:
        return m.group(2), m.group(1)  # 2d=lon 3d=lat
    m = EMBED_3D2D_RE.search(src)
    if m:
        return m.group(1), m.group(2)
    m = AT_RE.search(src)
    if m:
        return m.group(1), m.group(2)
    q = map_query(src)
    m = LATLNG_Q_RE.match(q)
    if m:
        return m.group(1), m.group(2)
    return "", ""


def extract_page(page, url: str) -> dict:
    rec = {"url": url}
    try:
        response = page.goto(url, wait_until="domcontentloaded", timeout=30_000)
        page.wait_for_timeout(800)
        rec["status"] = response.status if response else None
        rec["final_url"] = page.url
        rec["name"] = clean(page.locator("h1").first.inner_text()) if page.locator("h1").count() else ""
        iframe_sources = page.locator("iframe").evaluate_all(
            "(els) => els.map(e => e.getAttribute('src') || '').filter(Boolean)"
        )
        map_src = next((x for x in iframe_sources if "google.com/maps" in x or "maps.google" in x), "")
        rec["map_src"] = map_src
        rec["address"] = map_query(map_src)
        lat, lon = coords_from_src(map_src)
        rec["latitude"] = lat
        rec["longitude"] = lon
        tels = page.locator("a[href^='tel:']").evaluate_all(
            "els => els.map(e => e.getAttribute('href') || '')"
        )
        rec["phones"] = [clean(t.replace("tel:", "")) for t in tels if t]
        about = ""
        specialists = []
        sectors = []
        headings = page.locator("h2, h3")
        for i in range(headings.count()):
            title = clean(headings.nth(i).inner_text()).lower()
            if "about the plant" in title or "sobre la planta" in title:
                about = clean(
                    headings.nth(i).evaluate(
                        """e => {
                          let out=[], n=e.nextElementSibling;
                          while(n && !/^H[1-3]$/.test(n.tagName)) { out.push(n.innerText||''); n=n.nextElementSibling; }
                          return out.join(' ');
                        }"""
                    )
                )
            if "specialist" in title or "especialistas" in title:
                specialists = headings.nth(i).evaluate(
                    """e => {
                      let out=[], n=e.nextElementSibling;
                      while(n && !/^H[1-3]$/.test(n.tagName)) {
                        if(n.matches('ul,ol')) out.push(...[...n.querySelectorAll('li')].map(x=>x.innerText));
                        else if((n.innerText||'').trim()) out.push(n.innerText);
                        n=n.nextElementSibling;
                      }
                      return out;
                    }"""
                )
            if title in {"our sectors", "nuestros sectores", "sectores"}:
                sectors = headings.nth(i).evaluate(
                    """e => {
                      let out=[], n=e.nextElementSibling;
                      while(n && !/^H[1-3]$/.test(n.tagName)) {
                        out.push(...[...n.querySelectorAll('li,a,h4,span')].map(x=>x.innerText));
                        n=n.nextElementSibling;
                      }
                      return out;
                    }"""
                )
        rec["about"] = about
        rec["specialists"] = [clean(x) for x in (specialists or []) if clean(x)]
        rec["sectors"] = [clean(x) for x in (sectors or []) if clean(x) and len(clean(x)) < 80]
        rec["body_excerpt"] = clean(page.locator("body").inner_text())[:1200]
    except Exception as exc:
        rec["error"] = repr(exc)
    return rec


def collect_listing_urls(page) -> list[str]:
    found: set[str] = set()
    for path in LISTING_PATHS:
        url = urljoin(BASE_URL, path)
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=30_000)
            page.wait_for_timeout(600)
            hrefs = page.locator("a[href]").evaluate_all("els => els.map(e => e.href)")
            for h in hrefs:
                if is_plant_url(h):
                    found.add(english_url(h.split("#")[0].rstrip("/") + "/"))
        except Exception as exc:
            print("listing error", url, exc)
    return sorted(found)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        browser = p.chromium.launch(channel="msedge", headless=True)
        context = browser.new_context(locale="en-GB")
        context.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>undefined})")
        page = context.new_page()
        urls = collect_listing_urls(page)
        print(json.dumps({"detail_urls": len(urls), "urls": urls}, indent=2, ensure_ascii=False))
        rows = []
        for idx, url in enumerate(urls, 1):
            rec = extract_page(page, url)
            rows.append(rec)
            print(f"[{idx}/{len(urls)}] {rec.get('status')} {rec.get('name')} | addr={bool(rec.get('address'))} | {url}")
            if idx % 5 == 0 or idx == len(urls):
                PROGRESS_JSON.write_text(json.dumps({"done": idx, "total": len(urls)}, indent=2), encoding="utf-8")
                RAW_JSON.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
            time.sleep(0.2)
        # registered office from legal notice
        legal = extract_page(page, urljoin(BASE_URL, "/en/legal-notice/"))
        legal["name"] = legal.get("name") or "Hinojosa Packaging Group registered office"
        legal["is_legal_notice"] = True
        rows.append(legal)
        RAW_JSON.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
        browser.close()
    print(json.dumps({
        "records": len(rows),
        "errors": sum("error" in r for r in rows),
        "with_map_address": sum(bool(r.get("address")) for r in rows),
        "with_coords": sum(bool(r.get("latitude")) for r in rows),
        "raw_json": str(RAW_JSON),
    }, indent=2))


if __name__ == "__main__":
    main()
