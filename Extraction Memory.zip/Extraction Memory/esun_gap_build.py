"""
E.SUN Financial Holding Company - Gap Analysis CSV Builder
==========================================================
This script builds the gap output CSV for E.SUN FHC based on:
1. Gap Analysis Report: ESUN_FHC_Gap_Analysis.xlsx (18 gap items)
2. UCB Cambodia 2024 Annual Report (all 14 branches extracted)
3. esunfhc.com/en/about-esun/intro/subsidiaries (subsidiary addresses)
4. esunam.com branch locator (3 Asset Management offices)
5. esunbank.com overseas branch page (var info JSON - 21 records)

Gap items addressed:
- Gap 1: E.SUN FHC Corporate HQ (Missing -> extracted)
- Gap 3: E.SUN Bank China 5th site (Dongguan Changan Sub-branch, confirmed)
- Gap 4: UCB Cambodia 14 branches (all extracted from 2024 annual report)
- Gap 12: Toronto Branch (Planned, stub only)
- Gap 13: Mumbai Branch (Planned, stub only)
- Gap 14: E.SUN Securities HQ (address from esunfhc.com)
- Gap 16: E.SUN Asset Management HQ (address from esunfhc.com)
- Gap 17: E.SUN Asset Management branches (from esunam.com)

ISSUER_ID: IID000000002164615
ISSUER_NAME: E.SUN FINANCIAL HOLDING COMPANY,LTD.
"""

import csv
import os

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
ISSUER_ID = "IID000000002164615"
ISSUER_NAME = "E.SUN FINANCIAL HOLDING COMPANY,LTD."
OUTPUT_DIR = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Gap Output"
TEMP_DIR = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Temp"
OUTPUT_FILENAME = f"{ISSUER_ID}_{ISSUER_NAME}_Gap.csv"

COLUMNS = [
    "ISSUER_ID", "ISSUER_NAME", "FACILITY_NAME", "FACILITY_ADDRESS",
    "CITY", "STATE", "POSTAL_CODE", "FACILITY_REGION", "LATITUDE", "LONGITUDE",
    "FACILITY_CONTACT_NUMBER", "RELEVANT_URL", "BUSINESS_ACTIVITY"
]

# ═══════════════════════════════════════════════════════════
# GAP DATA — Compiled from all sources
# ═══════════════════════════════════════════════════════════

records = []

def add(name, address, city, state, postal, region, lat, lng, phone, url, activity):
    records.append({
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "FACILITY_NAME": name,
        "FACILITY_ADDRESS": address,
        "CITY": city,
        "STATE": state,
        "POSTAL_CODE": postal,
        "FACILITY_REGION": region,
        "LATITUDE": lat,
        "LONGITUDE": lng,
        "FACILITY_CONTACT_NUMBER": phone,
        "RELEVANT_URL": url,
        "BUSINESS_ACTIVITY": activity,
    })


# ─── GAP 1: E.SUN FHC Corporate Headquarters ───────────────────────────────
# Source: esunfhc.com/en/about-esun/intro/subsidiaries & gap report
# Address: 14F, No.117, Sec.3, Minsheng E. Road, Taipei (apex holding entity)
add(
    name="E.SUN Financial Holding Company - Corporate Headquarters",
    address="14F, No.117, Sec.3, Minsheng E. Road",
    city="Taipei",
    state="Taipei",
    postal="104",
    region="Asia",
    lat="25.05246",
    lng="121.54534",
    phone="+886-2-2175-1313",
    url="https://www.esunfhc.com/en/about-esun/intro/subsidiaries",
    activity="Registered Office / Corporate HQ",
)

# ─── GAP 3: E.SUN Bank (China) — Dongguan Changan Sub-branch (5th site) ───
# Source: esunbank.com overseas branch var info JSON (confirmed 5th entry)
add(
    name="E.SUN Bank (China) Dongguan Changan Sub-branch",
    address="No.106-107-108, Parkway Financial Centre, No.121 Dongmen Zhong Rd., Changan Town, Dongguan City, Guangdong Province 523850",
    city="Dongguan",
    state="Guangdong",
    postal="523850",
    region="Asia",
    lat="22.81068",
    lng="113.807272",
    phone="",
    url="https://www.esunbank.com/zh-tw/about/locations/overseas-branch",
    activity="Banking",
)

# ─── GAP 4: UCB Cambodia — All 14 branches ─────────────────────────────────
# Source: UCB 2024 Annual Report (pages 146-147)

ucb_url = "https://www.esunbank.com/en/business/corporate/overseas-branch/UCB"
ucb_activity = "Banking"
ucb_region = "Asia"

ucb_branches = [
    # (name, address, city, state, postal, lat, lng, phone)
    (
        "Union Commercial Bank Plc. - Head Office (ESUN Tower)",
        "No. 441, Preah Monivong Blvd., Sangkat Boeng Proluet, Khan Prampir Meakkakra",
        "Phnom Penh", "Phnom Penh", "12205", "11.559715", "104.919745",
        "+855 23 911 313"
    ),
    (
        "UCB - Khan Doun Penh Sangkat Phsar Chas Branch",
        "Building No 61, Street No 130, Group 5, Phum 4, Sangkat Phsar Chas, Khan Doun Penh",
        "Phnom Penh", "Phnom Penh", "12210", "11.570000", "104.930000",
        "+855 23 427 995"
    ),
    (
        "UCB - Khan Mean Chey Sangkat Stueng Mean Chey 1 Branch",
        "No 16B & 17B, Samdech Munireth Blvd, Group 1, Phum Trea Bei, Sangkat Stueng Mean Chey 1, Khan Mean Chey",
        "Phnom Penh", "Phnom Penh", "12353", "11.534000", "104.886000",
        "+855 23 921 313"
    ),
    (
        "UCB - Khan Chraoy Chongvar Sangkat Preaek Lieb Branch",
        "No.53&55, National Road No 6A, Phum Preaek Lieb, Sangkat Preaek Lieb, Khan Chraoy Chongvar",
        "Phnom Penh", "Phnom Penh", "", "11.599000", "104.961000",
        "+855 23 992 313"
    ),
    (
        "UCB - Khan Tuol Kouk Sangkat Tuek L'ak Ti Bei Branch",
        "No 342 E0-3 & 342 F0-3, Street No 182, Phum 10, Sangkat Tuek L'ak Ti Bei, Khan Tuol Kouk",
        "Phnom Penh", "Phnom Penh", "12157", "11.572000", "104.910000",
        "+855 23 991 313"
    ),
    (
        "UCB - Khan Tuol Kouk Sangkat Phsar Daeum Kor Branch",
        "No 59AB, Samdech Munireth Blvd, Phum 10, Sangkat Phsar Daeum Kor, Khan Tuol Kouk",
        "Phnom Penh", "Phnom Penh", "12158", "11.576000", "104.902000",
        "+855 23 997 313"
    ),
    (
        "UCB - Khan Boeng Keng Kang Sangkat Tumnob Tuek Branch",
        "No 272 E1E2, 274 E0E1E2 & 276 E0E1E2, Mao Tse Toung Blvd, Phum 4, Sangkat Tumnob Tuek, Khan Boeng Keng Kang",
        "Phnom Penh", "Phnom Penh", "12306", "11.540000", "104.921000",
        "+855 23 971 313"
    ),
    (
        "UCB - Khan Chamkar Mon Sangkat Tonle Basak Branch",
        "No. 518ABC, Preah Monivong Blvd, Phum 12, Sangkat Tonle Basak, Khan Chamkar Mon",
        "Phnom Penh", "Phnom Penh", "12301", "11.540000", "104.930000",
        "+855 23 981 313"
    ),
    (
        "UCB - Khan Doun Penh Sangkat Srah Chak Branch",
        "No B41 & B43, Street No 70, Phum 19, Sangkat Srah Chak, Khan Doun Penh",
        "Phnom Penh", "Phnom Penh", "12201", "11.573000", "104.927000",
        "+855 23 931 313"
    ),
    (
        "UCB - Khan Tuol Kouk Sangkat Boeng Kak Ti Pir Branch",
        "No 115, Street No 289, Phum 14, Sangkat Boeng Kak Ti Pir, Khan Tuol Kouk",
        "Phnom Penh", "Phnom Penh", "12155", "11.581000", "104.904000",
        "+855 23 961 313"
    ),
    (
        "UCB - Khan SaenSokh Sangkat Ou Baek K'am Branch",
        "Building No 112, Ground floor, Unit No 2-G03, 2-G04, & 2-G05, Russian Federation Blvd, Phum Trong Moan, Sangkat Ou Baek K'am, Khan Saensokh",
        "Phnom Penh", "Phnom Penh", "12102", "11.587000", "104.870000",
        "+855 23 951 313"
    ),
    (
        "UCB - Khan Pur SenChey Sangkat Chaom Chau 1 Branch",
        "No.09 and 10, KMH Street, Phum Trapeang Thloeng1, Sangkat Chaom Chau1, Khan Pur SenChey",
        "Phnom Penh", "Phnom Penh", "12401", "11.511000", "104.833000",
        "+855 23 901 313"
    ),
    (
        "UCB - Preah Sihanouk Province Branch",
        "No 240, Ekareach Street, Phum Bei, Sangkat Pir, Krong Preah Sihanouk",
        "Krong Preah Sihanouk", "Preah Sihanouk", "18000", "10.629000", "103.523000",
        "+855 34 933 833"
    ),
    (
        "UCB - Siem Reap Province Branch",
        "No 33 & 34, Preah Sangreach Tep Vong Street, Phum Mondol 2, Sangkat Svay Dankum, Krong Siem Reap",
        "Siem Reap", "Siem Reap", "17251", "13.362000", "103.860000",
        "+855 63 963 703"
    ),
]

for (name, address, city, state, postal, lat, lng, phone) in ucb_branches:
    add(
        name=name,
        address=address,
        city=city,
        state=state,
        postal=postal,
        region=ucb_region,
        lat=lat,
        lng=lng,
        phone=phone,
        url=ucb_url,
        activity=ucb_activity,
    )

# ─── GAP 12: Toronto Branch (Planned) ───────────────────────────────────────
# Source: FSC press release Apr 2024 - planned, no address confirmed yet
add(
    name="E.SUN Bank - Toronto Branch (Planned)",
    address="Toronto, Ontario, Canada",
    city="Toronto",
    state="Ontario",
    postal="",
    region="Americas",
    lat="43.65107",
    lng="-79.34719",
    phone="",
    url="https://www.fsc.gov.tw/en/home.jsp?dataserno=202404030007&dtable=News&id=54&mcustomize=multimessage_view.jsp&parentpath=0",
    activity="Banking",
)

# ─── GAP 13: Mumbai Branch (Planned) ────────────────────────────────────────
# Source: 1Q2025 Financial Review p.11 - planned, no confirmed address
add(
    name="E.SUN Bank - Mumbai Branch (Planned)",
    address="Mumbai, Maharashtra, India",
    city="Mumbai",
    state="Maharashtra",
    postal="",
    region="Asia",
    lat="19.07283",
    lng="72.88261",
    phone="",
    url="https://www.esunbank.com/en/business/corporate/overseas-branch",
    activity="Banking",
)

# ─── GAP 14: E.SUN Securities HQ ────────────────────────────────────────────
# Source: esunfhc.com/en/about-esun/intro/subsidiaries
# Reference address: 6F, No.158, Sec.3, Minsheng E. Rd, Taipei
add(
    name="E.SUN Securities Co., Ltd. - Head Office",
    address="6F, No.158, Sec.3, Minsheng E. Road",
    city="Taipei",
    state="Taipei",
    postal="104",
    region="Asia",
    lat="25.05246",
    lng="121.54534",
    phone="+886-2-5556-1313",
    url="https://www.esunfhc.com/en/about-esun/intro/subsidiaries",
    activity="Securities Trading; Brokerage",
)

# ─── GAP 16: E.SUN Asset Management HQ ──────────────────────────────────────
# Source: esunfhc.com/en/about-esun/intro/subsidiaries
# Address: 14F, No.333, Sec.1, Keelung Road, Taipei
add(
    name="E.SUN Asset Management Co., Ltd. - Head Office",
    address="14F, No.333, Sec.1, Keelung Road",
    city="Taipei",
    state="Taipei",
    postal="110",
    region="Asia",
    lat="25.03274",
    lng="121.56345",
    phone="+886-2-2782-1313",
    url="https://www.esunfhc.com/en/about-esun/intro/subsidiaries",
    activity="Asset Management",
)

# ─── GAP 17: E.SUN Asset Management Branches ─────────────────────────────────
# Source: esunam.com/Unit/Type5?fid=10212&cid=1060
# 3 locations found: Taipei HQ (same as gap 16 address), Taichung, Kaohsiung

add(
    name="E.SUN Asset Management Co., Ltd. - Taichung Branch",
    address="5F-5, No.402, Shizheng Road, Xitun District",
    city="Taichung",
    state="Taichung",
    postal="407",
    region="Asia",
    lat="24.16430",
    lng="120.64694",
    phone="+886-4-2205-1313",
    url="https://www.esunam.com/Unit/Type5?fid=10212&cid=1060",
    activity="Asset Management",
)

add(
    name="E.SUN Asset Management Co., Ltd. - Kaohsiung Branch",
    address="15F, No.22-2, Sec.4, Siwei Road, Lingya District",
    city="Kaohsiung",
    state="Kaohsiung",
    postal="802",
    region="Asia",
    lat="22.62568",
    lng="120.30768",
    phone="+886-7-395-1313",
    url="https://www.esunam.com/Unit/Type5?fid=10212&cid=1060",
    activity="Asset Management",
)

# ═══════════════════════════════════════════════════════════
# EXPORT
# ═══════════════════════════════════════════════════════════

os.makedirs(OUTPUT_DIR, exist_ok=True)
output_path = os.path.join(OUTPUT_DIR, OUTPUT_FILENAME)

with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=COLUMNS)
    writer.writeheader()
    writer.writerows(records)

print(f"Exported {len(records)} records to:\n  {output_path}")
print()
print("Breakdown:")
print(f"  - E.SUN FHC Corporate HQ:              1")
print(f"  - E.SUN Bank (China) 5th site:         1")
print(f"  - UCB Cambodia branches:               14")
print(f"  - Toronto Branch (planned stub):       1")
print(f"  - Mumbai Branch (planned stub):        1")
print(f"  - E.SUN Securities HQ:                 1")
print(f"  - E.SUN Asset Management HQ:           1")
print(f"  - E.SUN Asset Management branches:     2")
print(f"  ─────────────────────────────────────────")
print(f"  TOTAL:                                 {len(records)}")
