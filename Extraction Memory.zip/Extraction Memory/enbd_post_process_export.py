"""
Emirates NBD - Post-processing, validation, deduplication, and final export.
Reads raw data from checkpoint, fixes issues, exports final CSV.
"""
# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')

import csv, os, re, json, unicodedata, urllib.parse, urllib.request, ssl
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime

ISSUER_ID    = "IID000000002147467"
ISSUER_NAME  = "EMIRATES NBD BANK (P.J.S.C)"
OUTPUT_DIR   = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output"
TEMP_DIR     = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp"

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

# Load the original API data for reference
with open(os.path.join(TEMP_DIR, 'branch_api_data.json'), encoding='utf-8') as f:
    uae_data = json.load(f)
with open(os.path.join(TEMP_DIR, 'egypt_api_data.json'), encoding='utf-8') as f:
    egypt_data = json.load(f)
with open(os.path.join(TEMP_DIR, 'ksa_api_data.json'), encoding='utf-8') as f:
    ksa_data = json.load(f)

EMIRATE_MAP = {
    'd2abdab6-9f59-4710-a564-8a2acf431ddc': 'Abu Dhabi',
    '80557be2-d4bd-4466-a225-13df19faf1b4': 'Ajman',
    '427cfb3c-d003-46a4-b02b-b4041e2024a4': 'Dubai',
    'e520f341-c8e2-441c-ad85-c4b2596bc422': 'Fujairah',
    'fcded32f-c226-4eaf-87ab-796dd3c0f4a7': 'Ras Al Khaimah',
    'a4fd98c9-51d7-43eb-a4e3-ad2eea09e69d': 'Sharjah',
    'b4f4d399-e730-482a-9d0e-f7253e0bd6fa': 'Umm Al Quwain',
}

# Known UAE cities that are NOT emirate capitals (but still in UAE)
UAE_CITY_EXTRAS = {
    'al ain': 'Al Ain',
    'al-ain': 'Al Ain',
    'bur dubai': 'Dubai',
    'deira': 'Dubai',
    'jebel ali': 'Dubai',
    'business bay': 'Dubai',
    'al barsha': 'Dubai',
    'downtown': 'Dubai',
    'difc': 'Dubai',
    'marina': 'Dubai',
    'jumeirah': 'Dubai',
    'karama': 'Dubai',
    'mirdif': 'Dubai',
    'nad al sheba': 'Dubai',
    'muhaisnah': 'Dubai',
    'al rigga': 'Dubai',
    'al quoz': 'Dubai',
    'al nahda': 'Dubai',
    'al rashidiya': 'Dubai',
    'al garhoud': 'Dubai',
}

def transliterate(text):
    if not text:
        return ''
    replacements = {
        '\u00e4': 'ae', '\u00f6': 'oe', '\u00fc': 'ue', '\u00df': 'ss',
        '\u015f': 's', '\u015e': 'S', '\u011f': 'g', '\u011e': 'G',
        '\u0131': 'i', '\u0130': 'I', '\u00e7': 'c', '\u00c7': 'C',
        '\u00f1': 'n', '\u00d1': 'N', '\u2013': '-', '\u2014': '-',
        '\u2018': "'", '\u2019': "'", '\u201c': '"', '\u201d': '"',
        '\u00e9': 'e', '\u00e8': 'e', '\u00ea': 'e', '\u00eb': 'e',
        '\u00e0': 'a', '\u00e1': 'a', '\u00e2': 'a', '\u00e3': 'a',
        '\u00f3': 'o', '\u00f2': 'o', '\u00f4': 'o', '\u00f5': 'o',
        '\u00fa': 'u', '\u00f9': 'u', '\u00fb': 'u',
        '\u00ed': 'i', '\u00ec': 'i', '\u00ee': 'i',
        '\u00e6': 'ae', '\u00f8': 'o', '\u00e5': 'a',
    }
    for orig, repl in replacements.items():
        text = text.replace(orig, repl)
    try:
        normalized = unicodedata.normalize('NFKD', text)
        ascii_text = normalized.encode('ascii', 'ignore').decode('ascii')
        return re.sub(r'\s+', ' ', ascii_text).strip()
    except:
        return text.strip()

def clean_address(address):
    if not address:
        return ''
    addr = address.replace('#', '').replace('  ', ' ').strip()
    addr = re.sub(r'\s+', ' ', addr).strip(',').strip()
    return addr


def extract_city_from_address(address, country_iso3):
    """Enhanced city extraction."""
    addr_lower = address.lower()
    
    if country_iso3 == 'ARE':
        # Check for Al Ain specifically (not in emirate map but is a city in Abu Dhabi emirate)
        if 'al ain' in addr_lower or 'al-ain' in addr_lower:
            return 'Al Ain'
        # Check emirate names
        for emirate in ['Dubai', 'Abu Dhabi', 'Sharjah', 'Ajman', 'Fujairah', 'Ras Al Khaimah', 'Umm Al Quwain']:
            if emirate.lower() in addr_lower:
                return emirate
        return ''
    
    elif country_iso3 == 'EGY':
        egypt_cities = [
            'Cairo', 'Alexandria', 'Giza', 'Heliopolis', 'Maadi', 'Zamalek',
            'Nasr City', 'Dokki', 'Mohandessin', 'Mansoura', 'Tanta', 'Luxor', 'Aswan',
            'Port Said', 'Suez', 'Ismailia', 'Damietta', 'Zagazig', 'Minya', 'Asyut',
            'Sohag', 'Qena', 'Hurghada', 'Sharm El Sheikh', 'New Cairo', 'Beni Suef',
            'Fayoum', 'Borg El Arab', 'Kafr El Sheikh', 'Damanhour', 'Banha',
            'El Arish', 'Obour', 'Badr', 'Talkha', 'Mit Ghamr', 'Shibin El Kom',
            'Sheikh Zayed', '6th of October', '6 October', 'October City',
            'Shubra El Kheima', 'Shorouk', 'Madinaty', 'Rehab', 'Sheraton',
            'Ain Shams', 'Mataria', 'Downtown', 'Garden City', 'Smouha', 'Sporting',
            'Agami', 'Sidi Gaber', 'Ras Sudr', '10th of Ramadan',
        ]
        for city in egypt_cities:
            if city.lower() in addr_lower:
                return city
        # Fallback: extract city from comma-separated parts
        parts = [p.strip() for p in address.split(',')]
        # Usually second-to-last or last meaningful part
        for part in reversed(parts[:-1]):  # Skip last (likely 'Egypt')
            part = part.strip()
            if len(part) > 3 and not re.match(r'^\d', part) and 'egypt' not in part.lower():
                # Capitalize words
                return ' '.join(w.capitalize() for w in part.split())
        return 'Cairo'  # Default
    
    elif country_iso3 == 'SAU':
        ksa_cities = [
            'Riyadh', 'Jeddah', 'Makkah', 'Mecca', 'Madinah', 'Medina',
            'Khobar', 'Al Khobar', 'Dammam', 'AlHassa', 'Al Hassa', 'Hofuf',
            'Al Hofuf', 'Buraydah', 'Unaizah', 'AlJubail', 'Al Jubail', 'Al Jubayl',
            'AlTaif', 'Taif', 'Abha', 'Tabuk', 'Hail', 'Yanbu', 'Najran', 'Jizan',
            'AlQassim', 'Al Qassim',
        ]
        for city in ksa_cities:
            if city.lower() in addr_lower:
                # Clean it up
                if 'jubail' in city.lower() or 'jubayl' in city.lower():
                    return 'Al Jubail'
                if 'hassa' in city.lower():
                    return 'Al Hassa'
                if 'hofuf' in city.lower():
                    return 'Hofuf'
                return city
        return ''
    
    return ''


def get_state_for_city(city, country_iso3, address=''):
    """Derive state from city for given country."""
    if country_iso3 == 'ARE':
        # In UAE, emirate = state
        emirate_cities = {
            'Abu Dhabi': 'Abu Dhabi', 'Al Ain': 'Abu Dhabi',
            'Dubai': 'Dubai', 'Sharjah': 'Sharjah', 'Ajman': 'Ajman',
            'Fujairah': 'Fujairah', 'Ras Al Khaimah': 'Ras Al Khaimah',
            'Umm Al Quwain': 'Umm Al Quwain',
        }
        return emirate_cities.get(city, city)
    elif country_iso3 == 'EGY':
        # Egypt: state = governorate derived from city
        city_to_gov = {
            'Cairo': 'Cairo Governorate', 'Heliopolis': 'Cairo Governorate',
            'Nasr City': 'Cairo Governorate', 'Maadi': 'Cairo Governorate',
            'Zamalek': 'Cairo Governorate', 'Dokki': 'Giza Governorate',
            'Mohandessin': 'Giza Governorate', 'Giza': 'Giza Governorate',
            'Alexandria': 'Alexandria Governorate', 'Borg El Arab': 'Alexandria Governorate',
            'Sporting': 'Alexandria Governorate', 'Sidi Gaber': 'Alexandria Governorate',
            'Smouha': 'Alexandria Governorate', 'Agami': 'Alexandria Governorate',
            'Mansoura': 'Dakahlia Governorate', 'Talkha': 'Dakahlia Governorate',
            'Tanta': 'Gharbia Governorate', 'Hurghada': 'Red Sea Governorate',
            'Luxor': 'Luxor Governorate', 'Aswan': 'Aswan Governorate',
            'Port Said': 'Port Said Governorate', 'Suez': 'Suez Governorate',
            'Ismailia': 'Ismailia Governorate', 'Damietta': 'Damietta Governorate',
            'Zagazig': 'Sharqia Governorate', 'Sohag': 'Sohag Governorate',
            'Qena': 'Qena Governorate', 'Minya': 'Minya Governorate',
            'Asyut': 'Asyut Governorate', 'New Cairo': 'Cairo Governorate',
            'Beni Suef': 'Beni Suef Governorate', 'Fayoum': 'Fayoum Governorate',
            'Kafr El Sheikh': 'Kafr El Sheikh Governorate',
            'Damanhour': 'Beheira Governorate', 'Banha': 'Qalyubia Governorate',
            'El Arish': 'North Sinai Governorate', 'Sharm El Sheikh': 'South Sinai Governorate',
            'Ras Sudr': 'South Sinai Governorate', '6th of October': 'Giza Governorate',
            '6 October': 'Giza Governorate', 'Sheikh Zayed': 'Giza Governorate',
            'Obour': 'Cairo Governorate', 'Badr': 'Cairo Governorate',
            'Shorouk': 'Cairo Governorate', 'Madinaty': 'Cairo Governorate',
            'Rehab': 'Cairo Governorate', 'Sheraton': 'Cairo Governorate',
            'Ain Shams': 'Cairo Governorate', 'Mataria': 'Cairo Governorate',
            'Garden City': 'Cairo Governorate', 'Downtown': 'Cairo Governorate',
            'Shubra El Kheima': 'Qalyubia Governorate',
            '10th of Ramadan': 'Sharqia Governorate',
            'Mit Ghamr': 'Dakahlia Governorate', 'Shibin El Kom': 'Monufia Governorate',
        }
        for k, v in city_to_gov.items():
            if k.lower() == city.lower():
                return v
        return ''
    elif country_iso3 == 'SAU':
        city_to_region = {
            'Riyadh': 'Riyadh Region', 'Buraydah': 'Al Qassim Region', 'Unaizah': 'Al Qassim Region',
            'Jeddah': 'Makkah Region', 'Makkah': 'Makkah Region', 'Mecca': 'Makkah Region',
            'Taif': 'Makkah Region', 'Medina': 'Madinah Region', 'Madinah': 'Madinah Region',
            'Hofuf': 'Eastern Province', 'Al Hassa': 'Eastern Province',
            'Al Jubail': 'Eastern Province', 'Dammam': 'Eastern Province',
            'Khobar': 'Eastern Province', 'Al Khobar': 'Eastern Province',
            'Dhahran': 'Eastern Province', 'Qatif': 'Eastern Province',
        }
        for k, v in city_to_region.items():
            if k.lower() == city.lower():
                return v
        return ''
    return ''


def build_full_address(raw_address, city, country, country_iso3):
    """Build geocoding-friendly full address."""
    addr = clean_address(raw_address)
    addr = transliterate(addr)
    
    # Remove PO Box from address for geocoding
    # Keep it but ensure city is appended
    if city and city.lower() not in addr.lower():
        addr = f"{addr}, {city}"
    
    # Append country if missing
    country_variants = {
        'ARE': ['UAE', 'United Arab Emirates', 'emirates'],
        'EGY': ['Egypt', 'Egypt,'],
        'SAU': ['Saudi Arabia', 'Kingdom of Saudi Arabia', 'KSA'],
        'GBR': ['UK', 'United Kingdom', 'England'],
        'IND': ['India'],
        'TUR': ['Turkey', 'Turkiye', 'Istanbul'],
    }
    country_variants_list = country_variants.get(country_iso3, [country])
    if not any(cv.lower() in addr.lower() for cv in country_variants_list):
        addr = f"{addr}, {country}"
    
    return addr


def extract_postcode(address, country_iso3):
    if country_iso3 in ['SAU', 'EGY']:
        match = re.search(r'\b\d{5}\b', address)
        return match.group() if match else ''
    elif country_iso3 == 'GBR':
        match = re.search(r'\b[A-Z]{1,2}\d{1,2}[A-Z]?\s*\d[A-Z]{2}\b', address)
        return match.group() if match else ''
    elif country_iso3 == 'IND':
        match = re.search(r'\b\d{6}\b', address)
        return match.group() if match else ''
    elif country_iso3 == 'TUR':
        match = re.search(r'\b\d{5}\b', address)
        return match.group() if match else ''
    return ''


# ═══════════════════════════════════════════════════════════
# RE-PROCESS ALL API DATA FROM SCRATCH FOR CLEAN OUTPUT
# ═══════════════════════════════════════════════════════════

def process_all_records():
    all_records = []
    seen_keys = set()  # For deduplication
    
    def make_dedup_key(name, address):
        return (name.lower().strip(), address.lower()[:50].strip())
    
    # === UAE BRANCHES ===
    uae_branches = [b for b in uae_data['BranchAtms'] if b.get('CategoryName') in ['Branches', 'ITMs']]
    print(f"UAE: {len(uae_branches)} branches/ITMs")
    
    for branch in uae_branches:
        title = branch.get('Title', '') or ''
        raw_address = branch.get('Address', '') or ''
        lat = branch.get('Latitude') or ''
        lon = branch.get('Longitude') or ''
        emirate_id = branch.get('EmirateId', '') or ''
        category = branch.get('CategoryName', '') or ''
        
        emirate_name = EMIRATE_MAP.get(emirate_id, '')
        
        # City extraction
        city = extract_city_from_address(raw_address, 'ARE')
        if not city:
            city = emirate_name
        if not city:
            city = 'Dubai'  # Fallback
        
        state = get_state_for_city(city, 'ARE')
        if not state:
            state = emirate_name
        
        # Build full address
        addr_clean = clean_address(raw_address)
        addr_en = transliterate(addr_clean)
        
        # Ensure UAE is in address
        if 'united arab emirates' not in addr_en.lower() and 'uae' not in addr_en.lower():
            addr_en = f"{addr_en}, United Arab Emirates"
        
        postcode = extract_postcode(addr_en, 'ARE')
        
        # Coords
        lat_clean, lon_clean, coord_src = '', '', ''
        try:
            lf, lg = float(lat), float(lon)
            if lf != 0 and lg != 0:
                lat_clean, lon_clean = f"{lf}", f"{lg}"
                coord_src = 'website'
        except:
            pass
        
        loc_name_en = transliterate(title)
        
        # Activity
        activity = 'Banking Branch'
        if category == 'ITMs':
            activity = 'Interactive Teller Machine (ITM)'
        
        # Check facilities for Business Banking or Priority
        facilities = [f.get('Text', '') for f in branch.get('Facilities', [])]
        if any('Business Banking' in f for f in facilities):
            activity = 'Business Banking Centre'
        elif any('Priority' in f for f in facilities):
            activity = 'Priority Banking Centre'
        
        key = make_dedup_key(loc_name_en, addr_en)
        if key in seen_keys:
            print(f"  Duplicate skipped (UAE): {loc_name_en}")
            continue
        seen_keys.add(key)
        
        all_records.append({
            'ISSUER_ID': ISSUER_ID,
            'ISSUER_NAME': ISSUER_NAME,
            'LOCATION_NAME': loc_name_en,
            'LOCATION_ADDRESS': addr_en,
            'LATITUDE': lat_clean,
            'LONGITUDE': lon_clean,
            'COUNTRY': 'United Arab Emirates',
            'COUNTRY_ISO3': 'ARE',
            'POSTCODE': postcode,
            'STATE': state,
            'CITY': city,
            'SOURCE_URL': 'https://www.emiratesnbd.com/en/branches-and-atms',
            'SOURCE_TYPE': 'COMPANY WEBSITE',
            'ACTIVITY_AT_ASSET': activity,
            'coord_source': coord_src,
            'LOCATION_NAME_NATIVE': title if title != loc_name_en else '',
            'LOCATION_ADDRESS_NATIVE': raw_address if raw_address != addr_en else '',
        })
    
    # === EGYPT BRANCHES ===
    eg_branches = [b for b in egypt_data['BranchAtms'] if b.get('CategoryName') == 'Branches']
    print(f"Egypt: {len(eg_branches)} branches")
    
    for branch in eg_branches:
        title = branch.get('Title', '') or ''
        raw_address = branch.get('Address', '') or ''
        lat = branch.get('Latitude') or ''
        lon = branch.get('Longitude') or ''
        
        city = extract_city_from_address(raw_address, 'EGY')
        if not city:
            city = 'Cairo'
        state = get_state_for_city(city, 'EGY')
        
        addr_clean = clean_address(raw_address)
        addr_en = transliterate(addr_clean)
        
        if 'egypt' not in addr_en.lower():
            addr_en = f"{addr_en}, Egypt"
        
        postcode = extract_postcode(addr_en, 'EGY')
        
        lat_clean, lon_clean, coord_src = '', '', ''
        try:
            lf, lg = float(lat), float(lon)
            if lf != 0 and lg != 0:
                lat_clean, lon_clean = f"{lf}", f"{lg}"
                coord_src = 'website'
        except:
            pass
        
        loc_name_en = transliterate(title)
        
        key = make_dedup_key(loc_name_en, addr_en)
        if key in seen_keys:
            print(f"  Duplicate skipped (EGY): {loc_name_en}")
            continue
        seen_keys.add(key)
        
        all_records.append({
            'ISSUER_ID': ISSUER_ID,
            'ISSUER_NAME': ISSUER_NAME,
            'LOCATION_NAME': loc_name_en,
            'LOCATION_ADDRESS': addr_en,
            'LATITUDE': lat_clean,
            'LONGITUDE': lon_clean,
            'COUNTRY': 'Egypt',
            'COUNTRY_ISO3': 'EGY',
            'POSTCODE': postcode,
            'STATE': state,
            'CITY': city,
            'SOURCE_URL': 'https://www.emiratesnbd.com.eg/en/branches-and-atms',
            'SOURCE_TYPE': 'COMPANY WEBSITE',
            'ACTIVITY_AT_ASSET': 'Banking Branch',
            'coord_source': coord_src,
            'LOCATION_NAME_NATIVE': title if title != loc_name_en else '',
            'LOCATION_ADDRESS_NATIVE': raw_address if raw_address != addr_en else '',
        })
    
    # === KSA BRANCHES ===
    ksa_branches = [b for b in ksa_data['BranchAtms'] if b.get('CategoryName') == 'Branches']
    print(f"KSA: {len(ksa_branches)} branches")
    
    for branch in ksa_branches:
        title = branch.get('Title', '') or ''
        raw_address = branch.get('Address', '') or ''
        lat = branch.get('Latitude') or ''
        lon = branch.get('Longitude') or ''
        
        # Skip the 'Emirates NBD Head Office' which appears in KSA data but is actually UAE
        if 'Head Office' in title and 'Deira' in raw_address:
            print(f"  Skipping {title} (UAE entity in KSA data)")
            continue
        
        city = extract_city_from_address(raw_address, 'SAU')
        if not city:
            # Try to extract from title
            for kw in ['Riyadh', 'Jeddah', 'Khobar', 'Dammam', 'Makkah', 'Madinah', 'Jubail', 'Qassim']:
                if kw.lower() in title.lower():
                    city = kw
                    break
        
        # Fix Al Jubail
        if 'jubail' in city.lower() or 'jubayl' in city.lower():
            city = 'Al Jubail'
        if 'hofuf' in city.lower():
            city = 'Hofuf'
        
        state = get_state_for_city(city, 'SAU', raw_address)
        
        addr_clean = clean_address(raw_address)
        addr_en = transliterate(addr_clean)
        
        # Remove "Kingdom of Saudi Arabia" redundancy, keep clean
        if 'saudi arabia' not in addr_en.lower():
            addr_en = f"{addr_en}, Saudi Arabia"
        
        # Remove double country mentions
        addr_en = re.sub(r',?\s*Saudi Arabia,?\s*Saudi Arabia', ', Saudi Arabia', addr_en, flags=re.IGNORECASE)
        addr_en = re.sub(r',?\s*Kingdom of Saudi Arabia', ', Saudi Arabia', addr_en, flags=re.IGNORECASE)
        
        postcode = extract_postcode(addr_en, 'SAU')
        
        lat_clean, lon_clean, coord_src = '', '', ''
        try:
            lf, lg = float(lat), float(lon)
            if lf != 0 and lg != 0:
                lat_clean, lon_clean = f"{lf}", f"{lg}"
                coord_src = 'website'
        except:
            pass
        
        loc_name_en = transliterate(title)
        
        key = make_dedup_key(loc_name_en, addr_en)
        if key in seen_keys:
            print(f"  Duplicate skipped (KSA): {loc_name_en}")
            continue
        seen_keys.add(key)
        
        all_records.append({
            'ISSUER_ID': ISSUER_ID,
            'ISSUER_NAME': ISSUER_NAME,
            'LOCATION_NAME': loc_name_en,
            'LOCATION_ADDRESS': addr_en,
            'LATITUDE': lat_clean,
            'LONGITUDE': lon_clean,
            'COUNTRY': 'Saudi Arabia',
            'COUNTRY_ISO3': 'SAU',
            'POSTCODE': postcode,
            'STATE': state,
            'CITY': city,
            'SOURCE_URL': 'https://www.emiratesnbd.com.sa/en/branches-and-atms',
            'SOURCE_TYPE': 'COMPANY WEBSITE',
            'ACTIVITY_AT_ASSET': 'Banking Branch',
            'coord_source': coord_src,
            'LOCATION_NAME_NATIVE': title if title != loc_name_en else '',
            'LOCATION_ADDRESS_NATIVE': raw_address if raw_address != addr_en else '',
        })
    
    # === MANUAL RECORDS ===
    manual = [
        {
            'ISSUER_ID': ISSUER_ID, 'ISSUER_NAME': ISSUER_NAME,
            'LOCATION_NAME': 'Emirates NBD London Branch',
            'LOCATION_NAME_NATIVE': '',
            'LOCATION_ADDRESS': '1 Knightsbridge, London SW1X 7LX, United Kingdom',
            'LOCATION_ADDRESS_NATIVE': '',
            'CITY': 'London', 'STATE': 'England',
            'COUNTRY': 'United Kingdom of Great Britain and Northern Ireland (the)',
            'COUNTRY_ISO3': 'GBR', 'POSTCODE': 'SW1X 7LX',
            'LATITUDE': '', 'LONGITUDE': '',
            'SOURCE_URL': 'https://www.emiratesnbd.co.uk/en/contact-us',
            'SOURCE_TYPE': 'COMPANY WEBSITE',
            'ACTIVITY_AT_ASSET': 'Private Banking / Corporate Banking Branch',
            'coord_source': '',
        },
        {
            'ISSUER_ID': ISSUER_ID, 'ISSUER_NAME': ISSUER_NAME,
            'LOCATION_NAME': 'Emirates NBD India - Mumbai Office',
            'LOCATION_NAME_NATIVE': '',
            'LOCATION_ADDRESS': 'Gr. & 1st Floor, 5 North Avenue, Maker Maxity, Bandra Kurla Complex, Bandra (E), Mumbai 400051, India',
            'LOCATION_ADDRESS_NATIVE': '',
            'CITY': 'Mumbai', 'STATE': 'Maharashtra',
            'COUNTRY': 'India', 'COUNTRY_ISO3': 'IND', 'POSTCODE': '400051',
            'LATITUDE': '', 'LONGITUDE': '',
            'SOURCE_URL': 'https://www.emiratesnbd.bank.in/en/contact-us',
            'SOURCE_TYPE': 'COMPANY WEBSITE',
            'ACTIVITY_AT_ASSET': 'Banking Office / Nodal Office',
            'coord_source': '',
        },
        {
            'ISSUER_ID': ISSUER_ID, 'ISSUER_NAME': ISSUER_NAME,
            'LOCATION_NAME': 'Emirates NBD Asset Management - Dubai DIFC Office',
            'LOCATION_NAME_NATIVE': '',
            'LOCATION_ADDRESS': '8th Floor, East Wing, The Gate Building, Dubai International Financial Centre, Dubai, United Arab Emirates',
            'LOCATION_ADDRESS_NATIVE': '',
            'CITY': 'Dubai', 'STATE': 'Dubai',
            'COUNTRY': 'United Arab Emirates', 'COUNTRY_ISO3': 'ARE', 'POSTCODE': '',
            'LATITUDE': '', 'LONGITUDE': '',
            'SOURCE_URL': 'https://www.emiratesnbd.com/en/asset-management/contact-us',
            'SOURCE_TYPE': 'COMPANY WEBSITE',
            'ACTIVITY_AT_ASSET': 'Asset Management Office',
            'coord_source': '',
        },
        {
            'ISSUER_ID': ISSUER_ID, 'ISSUER_NAME': ISSUER_NAME,
            'LOCATION_NAME': 'DenizBank Headquarters',
            'LOCATION_NAME_NATIVE': 'DenizBank Genel Mudurlugu',
            'LOCATION_ADDRESS': 'Buyukdere Cad. No:141, Esentepe, Sisli, Istanbul, Turkiye',
            'LOCATION_ADDRESS_NATIVE': 'Buyukdere Cad. No:141, Esentepe, Sisli, Istanbul',
            'CITY': 'Istanbul', 'STATE': 'Istanbul',
            'COUNTRY': 'Turkiye', 'COUNTRY_ISO3': 'TUR', 'POSTCODE': '34394',
            'LATITUDE': '', 'LONGITUDE': '',
            'SOURCE_URL': 'https://www.denizbank.com/en/legal-warnings',
            'SOURCE_TYPE': 'COMPANY WEBSITE',
            'ACTIVITY_AT_ASSET': 'Bank Headquarters',
            'coord_source': '',
        },
        {
            'ISSUER_ID': ISSUER_ID, 'ISSUER_NAME': ISSUER_NAME,
            'LOCATION_NAME': 'Emirates NBD KSA Head Office - Riyadh',
            'LOCATION_NAME_NATIVE': '',
            'LOCATION_ADDRESS': 'Signature Center, 2nd Floor, Prince Turki Al Awwal, Hittin Neighborhood, Riyadh 11333, Saudi Arabia',
            'LOCATION_ADDRESS_NATIVE': '',
            'CITY': 'Riyadh', 'STATE': 'Riyadh Region',
            'COUNTRY': 'Saudi Arabia', 'COUNTRY_ISO3': 'SAU', 'POSTCODE': '11333',
            'LATITUDE': '', 'LONGITUDE': '',
            'SOURCE_URL': 'https://www.emiratesnbd.com.sa/en/about-emiratesnbd-ksa',
            'SOURCE_TYPE': 'COMPANY WEBSITE',
            'ACTIVITY_AT_ASSET': 'Banking Office / Country Head Office',
            'coord_source': '',
        },
    ]
    
    for rec in manual:
        key = make_dedup_key(rec['LOCATION_NAME'], rec['LOCATION_ADDRESS'])
        if key not in seen_keys:
            seen_keys.add(key)
            all_records.append(rec)
            print(f"  Manual added: {rec['LOCATION_NAME']}")
    
    return all_records


# Main execution
print("Processing all records from scratch...")
records = process_all_records()

print(f"\nTotal records after deduplication: {len(records)}")

# Validation
print("\nValidating...")
issues = []
for i, row in enumerate(records):
    if not row.get('CITY', '').strip():
        issues.append(f"  Row {i+1} [{row.get('LOCATION_NAME', '?')}]: CITY blank")
    if not row.get('LOCATION_ADDRESS', '').strip():
        issues.append(f"  Row {i+1} [{row.get('LOCATION_NAME', '?')}]: LOCATION_ADDRESS blank")
    if '#' in row.get('LOCATION_ADDRESS', ''):
        issues.append(f"  Row {i+1}: LOCATION_ADDRESS has # char")

if issues:
    print(f"Validation issues ({len(issues)}):")
    for issue in issues:
        print(issue)
else:
    print("  All records valid - no blank CITY or LOCATION_ADDRESS")

# Country breakdown
from collections import Counter
print("\nCountry breakdown:")
for country, count in Counter(r['COUNTRY'] for r in records).most_common():
    print(f"  {country}: {count}")

# Save output
fieldnames = [
    'ISSUER_ID', 'ISSUER_NAME', 'LOCATION_NAME', 'LOCATION_ADDRESS',
    'LATITUDE', 'LONGITUDE', 'COUNTRY', 'COUNTRY_ISO3', 'POSTCODE',
    'STATE', 'CITY', 'SOURCE_URL', 'SOURCE_TYPE', 'ACTIVITY_AT_ASSET',
    'coord_source', 'LOCATION_NAME_NATIVE', 'LOCATION_ADDRESS_NATIVE'
]

# Output CSV name: <ISSUER_ID>_<ISSUER_NAME>
output_filename = f"{ISSUER_ID}_{ISSUER_NAME}.csv"
output_path = os.path.join(OUTPUT_DIR, output_filename)

os.makedirs(OUTPUT_DIR, exist_ok=True)

with open(output_path, 'w', newline='', encoding='utf-8-sig') as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
    writer.writeheader()
    writer.writerows(records)

print(f"\nFinal output saved to: {output_path}")
print(f"Total records: {len(records)}")
print(f"\nThreshold check: {'PASSED' if len(records) >= 97 else 'FAILED'} ({len(records)}/97)")

# Activity breakdown
print("\nActivity breakdown:")
for act, count in Counter(r.get('ACTIVITY_AT_ASSET', '') for r in records).most_common():
    print(f"  {act}: {count}")

# Coord source
print("\nCoord source:")
for src, count in Counter(r.get('coord_source', '') for r in records).most_common():
    print(f"  {src or '(blank)'}: {count}")
