# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Edit this block for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_ID = "IID000000002201718"
COMPANY_NAME = "BERKSHIRE HATHAWAY ENERGY COMPANY"
URL_WORKBOOK = r"C:\Users\tiwaary\Downloads\BHE HSA.xlsx"
OUTPUT_DIR = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Barclays2 CQ\Berk HSA\Temp"
FINAL_DIR = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Barclays2 CQ\Berk HSA\Output"

# Hosts that mix company-owned and franchise offices. Keep only names matching the filter.
NETWORK_NAME_FILTER = {
    "www.bhhs.com": "first realty",
}

# bhhscarolinas.com serves four HSA brands. City -> brand, from the company's own market split.
CAROLINAS_BRAND_BY_CITY = {
    "charlotte": "BHHS Carolinas Realty",
    "winston-salem": "BHHS Carolinas Realty",
    "winston salem": "BHHS Carolinas Realty",
    "raleigh": "BHHS York Simpson Underwood Realty",
    "cary": "BHHS York Simpson Underwood Realty",
    "chapel hill": "BHHS York Simpson Underwood Realty",
    "durham": "BHHS York Simpson Underwood Realty",
    "greensboro": "BHHS Yost & Little Realty",
    "high point": "BHHS Yost & Little Realty",
    "pinehurst": "BHHS Pinehurst Realty Group",
    "southern pines": "BHHS Pinehurst Realty Group",
    "aberdeen": "BHHS Pinehurst Realty Group",
}

CANDIDATE_PATHS = [
    "/roster/offices",
    "/offices",
    "/real-estate-offices",
    "/office-search",
    "/Offices",
    "/resources/find-an-office",
    "/contact",
    "/contact/companysite",
]

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════
"""Roster JSON + DataFloat office-card extractor.

Two brokerage website patterns:
  1. RNG roster pages embed `offices = [{OfficeName, Address, City, State, Zip, Lat, Lng, PhoneNumber}]`
     and paginate at `/roster/offices/{n}`. Often behind Cloudflare; a patched Chrome session is the fallback.
  2. DataFloat office galleries use `div[data-office-id]` with `data-office-latitude` and
     `i[data-value]` street/city/state/postal parts.
  3. Some BHHS detail pages expose a `dataLayer` office object (`dL_OfficeStreetAddress`, lat/lng).

One row per building. Co-located suites and affiliate desks are listed in COMMENTS.
"""

import csv
import json
import re
import time
from collections import defaultdict
from pathlib import Path
from urllib.parse import urljoin, urlparse

import openpyxl
from bs4 import BeautifulSoup
from curl_cffi import requests as creq

OUT = Path(OUTPUT_DIR)
OUT.mkdir(parents=True, exist_ok=True)
PROGRESS_PATH = OUT / "hsa_progress.json"
LOG_PATH = OUT / "hsa_run.log"

US_STATES = {
    "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas", "CA": "California",
    "CO": "Colorado", "CT": "Connecticut", "DE": "Delaware", "DC": "District of Columbia",
    "FL": "Florida", "GA": "Georgia", "HI": "Hawaii", "ID": "Idaho", "IL": "Illinois",
    "IN": "Indiana", "IA": "Iowa", "KS": "Kansas", "KY": "Kentucky", "LA": "Louisiana",
    "ME": "Maine", "MD": "Maryland", "MA": "Massachusetts", "MI": "Michigan", "MN": "Minnesota",
    "MS": "Mississippi", "MO": "Missouri", "MT": "Montana", "NE": "Nebraska", "NV": "Nevada",
    "NH": "New Hampshire", "NJ": "New Jersey", "NM": "New Mexico", "NY": "New York",
    "NC": "North Carolina", "ND": "North Dakota", "OH": "Ohio", "OK": "Oklahoma", "OR": "Oregon",
    "PA": "Pennsylvania", "RI": "Rhode Island", "SC": "South Carolina", "SD": "South Dakota",
    "TN": "Tennessee", "TX": "Texas", "UT": "Utah", "VT": "Vermont", "VA": "Virginia",
    "WA": "Washington", "WV": "West Virginia", "WI": "Wisconsin", "WY": "Wyoming",
}
AFFILIATE = re.compile(r"title|insurance|relocation|mortgage|escrow|warranty", re.I)
COMMERCIAL = re.compile(r"\bcommercial\b", re.I)
SUITE = re.compile(
    r"\b(suite|ste|unit|apt|apartment|rm|room|fl|floor)\b\.?\s*[#\w-]*|#\s*[\w-]+",
    re.I,
)
ABBR = {
    "street": "st", "road": "rd", "avenue": "ave", "boulevard": "blvd", "drive": "dr",
    "parkway": "pkwy", "lane": "ln", "court": "ct", "place": "pl", "highway": "hwy",
    "north": "n", "south": "s", "east": "e", "west": "w",
}

_session = creq.Session()
_driver = None


def log(msg):
    line = f"{time.strftime('%H:%M:%S')} {msg}"
    print(line, flush=True)
    with LOG_PATH.open("a", encoding="utf-8") as f:
        f.write(line + "\n")


def load_sites():
    wb = openpyxl.load_workbook(URL_WORKBOOK, data_only=True)
    ws = wb.active
    grouped = {}
    order = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        company, url = row[0], row[1]
        if not url:
            continue
        url = str(url).strip()
        # Drop the state filter the source note flagged.
        if "bhhsnyproperties.com/offices/" in url:
            url = "https://www.bhhsnyproperties.com/offices"
        if url not in grouped:
            grouped[url] = []
            order.append(url)
        grouped[url].append(str(company).strip())
    sites = []
    for url in order:
        brands = grouped[url]
        sites.append({"url": url, "brands": brands, "brand": brands[0]})
    return sites


def blocked(status, html):
    if status != 200 or not html:
        return True
    head = html[:4000].lower()
    return "just a moment" in head or "attention required" in head or "cf-error" in head


def curl_get(url):
    try:
        r = _session.get(url, impersonate="chrome", timeout=30, allow_redirects=True)
        return r.status_code, r.text, str(r.url)
    except Exception as e:
        log(f"  curl error {url} {type(e).__name__}: {e}")
        return 0, "", url


def browser():
    global _driver
    if _driver is not None:
        return _driver
    import undetected_chromedriver as uc
    opts = uc.ChromeOptions()
    opts.add_argument("--window-size=1400,900")
    log("  starting patched Chrome")
    _driver = uc.Chrome(options=opts, headless=False)
    _driver.set_page_load_timeout(50)
    return _driver


def browser_get(url):
    d = browser()
    try:
        d.get(url)
    except Exception as e:
        log(f"  browser get error {type(e).__name__}: {str(e).splitlines()[0][:180]}")
    html = ""
    for i in range(20):
        time.sleep(3)
        try:
            title = (d.title or "").lower()
            html = d.page_source or ""
        except Exception:
            continue
        if "moment" not in title and "attention required" not in title and "checking" not in title:
            if len(html) > 8000:
                return html, d.current_url
    try:
        return d.page_source or html, d.current_url
    except Exception:
        return html, url


def fetch(url):
    status, html, final = curl_get(url)
    if not blocked(status, html):
        return html, final, "curl"
    log(f"  browser fallback {url}")
    html, final = browser_get(url)
    return html, final, "browser"


def clean_street(street):
    street = street or ""
    street = street.replace("\xa0", " ")
    street = re.sub(r"#\s*", "Unit ", street)
    street = re.sub(r"\s+", " ", street).strip(" ,")
    return street


def clean_zip(value):
    value = (value or "").strip().rstrip("-")
    m = re.search(r"\d{5}(?:-\d{4})?", value)
    return m.group(0) if m else ""


def state_name(value):
    value = (value or "").strip()
    if value.upper() in US_STATES:
        return US_STATES[value.upper()]
    return value


def valid_coord(lat, lng):
    try:
        lat_f = float(lat)
        lng_f = float(lng)
    except (TypeError, ValueError):
        return "", ""
    if abs(lat_f) < 0.01 and abs(lng_f) < 0.01:
        return "", ""
    if not (-90 <= lat_f <= 90 and -180 <= lng_f <= 180):
        return "", ""
    return f"{lat_f:.6f}".rstrip("0").rstrip("."), f"{lng_f:.6f}".rstrip("0").rstrip(".")


def activity_for(name):
    if AFFILIATE.search(name or "") and re.search(r"title", name, re.I):
        return "Title office"
    if re.search(r"insurance", name or "", re.I):
        return "Insurance office"
    if re.search(r"relocation", name or "", re.I):
        return "Relocation office"
    if re.search(r"mortgage", name or "", re.I):
        return "Mortgage office"
    if COMMERCIAL.search(name or ""):
        return "Commercial real estate office"
    return "Office"


def make_row(brand, name, street, city, state, zipc, lat, lng, phone, url):
    street = clean_street(street)
    city = re.sub(r"\s+", " ", (city or "")).strip(" ,")
    state = state_name(state)
    zipc = clean_zip(zipc)
    lat, lng = valid_coord(lat, lng)
    if not street or not city:
        return None
    if re.search(r"\b(bed|bath|sqft|for sale)\b", f"{name} {street}", re.I):
        return None
    return {
        "brand": brand,
        "name": re.sub(r"\s+", " ", (name or "Office")).strip(),
        "street": street,
        "city": city,
        "state": state,
        "zip": zipc,
        "lat": lat,
        "lng": lng,
        "phone": re.sub(r"\s+", " ", (phone or "")).strip(),
        "url": url,
    }


def abs_url(base, href):
    if not href or href.lower().startswith("javascript"):
        return ""
    return urljoin(base, href)


def parse_roster_json(html, page_url, brand):
    rows = []
    for m in re.finditer(r"\boffices\s*=\s*(\[.*?\])\s*;", html, re.S):
        try:
            data = json.loads(m.group(1))
        except json.JSONDecodeError:
            continue
        if not isinstance(data, list):
            continue
        for office in data:
            if not isinstance(office, dict):
                continue
            street = " ".join(
                x for x in [office.get("Address") or "", office.get("Address2") or ""] if x and x != "null"
            )
            username = office.get("UserName") or ""
            detail = page_url
            if username:
                root = "{uri.scheme}://{uri.netloc}".format(uri=urlparse(page_url))
                detail = f"{root}/roster/offices/{username}"
            row = make_row(
                brand,
                office.get("OfficeName") or "",
                street,
                office.get("City") or "",
                office.get("State") or "",
                str(office.get("Zip") or ""),
                office.get("Lat"),
                office.get("Lng"),
                str(office.get("PhoneNumber") or ""),
                detail,
            )
            if row:
                rows.append(row)
        if rows:
            break
    return rows


def parse_datafloat(html, page_url, brand):
    soup = BeautifulSoup(html, "html.parser")
    rows = []
    for card in soup.select("[data-office-id]"):
        name_el = card.select_one("h2 a, .office-header a, [itemprop=name] a")
        name = name_el.get_text(" ", strip=True) if name_el else ""
        vals = [i.get("data-value", "").strip() for i in card.select(".address i[data-value], [itemprop=streetAddress]")]
        if len(vals) >= 4:
            street, city, state, zipc = vals[0], vals[1], vals[2], vals[3]
        elif len(vals) == 3:
            street, city, state, zipc = vals[0], vals[1], vals[2], ""
        else:
            street = card.select_one("[itemprop=streetAddress]")
            city = card.select_one("[itemprop=addressLocality]")
            state = card.select_one("[itemprop=addressRegion]")
            zipc = card.select_one("[itemprop=postalCode]")
            street = street.get_text(" ", strip=True) if street else ""
            city = city.get_text(" ", strip=True) if city else ""
            state = state.get_text(" ", strip=True) if state else ""
            zipc = zipc.get_text(" ", strip=True) if zipc else ""
        phone_el = card.select_one("a[href^='tel:']")
        phone = phone_el.get_text(" ", strip=True) if phone_el else ""
        href = name_el.get("href") if name_el else ""
        row = make_row(
            brand, name, street, city, state, zipc,
            card.get("data-office-latitude"), card.get("data-office-longitude"),
            phone, abs_url(page_url, href) or page_url,
        )
        if row:
            rows.append(row)
    return rows


def parse_reliance(html, page_url, brand):
    """RELIANCEai roster: office names live in roster cards; street addresses live in the footer."""
    soup = BeautifulSoup(html, "html.parser")
    cards = []
    for article in soup.select("#rosterResults article"):
        heading = article.find(["h2", "h3"])
        name = heading.get_text(" ", strip=True) if heading else ""
        tel = article.select_one("a[href^='tel:']")
        phone_text = re.sub(r"^[Tt]\s*", "", tel.get_text(" ", strip=True)) if tel else ""
        roster = article.select_one("a[href*='roster/Office'], a[href*='roster/office']")
        href = roster.get("href") if roster else ""
        if name:
            cards.append({
                "name": name,
                "phone": re.sub(r"\D", "", phone_text),
                "phone_text": phone_text,
                "href": href,
            })
    footers = []
    for block in soup.select(".site-footer-office"):
        para = block.find("p")
        if para is None:
            continue
        parts = [re.sub(r"\s+", " ", x).strip(" ,") for x in para.get_text("\n").split("\n") if x.strip()]
        if len(parts) < 2:
            continue
        loc = re.search(r"^(.*?),\s*([A-Z]{2})\s+(\d{5}(?:-\d{4})?)$", parts[-1])
        if not loc:
            continue
        tel = block.select_one("a[href^='tel:']")
        phone_text = re.sub(r"^[Tt]\s*", "", tel.get_text(" ", strip=True)) if tel else ""
        footers.append({
            "street": " ".join(parts[:-1]),
            "city": loc.group(1).strip(),
            "state": loc.group(2),
            "zip": loc.group(3),
            "phone": re.sub(r"\D", "", phone_text),
            "phone_text": phone_text,
        })
    if not footers:
        return []
    used = set()
    rows = []
    for footer in footers:
        match = None
        phone_hits = [i for i, card in enumerate(cards) if card["phone"] and card["phone"] == footer["phone"]]
        if len(phone_hits) == 1:
            match = phone_hits[0]
        else:
            blob = f"{footer['street']} {footer['city']}".lower()
            for i, card in enumerate(cards):
                if i in used:
                    continue
                tokens = [t.lower() for t in re.findall(r"[A-Za-z]{4,}", card["name"])]
                tokens = [t for t in tokens if t not in {"office", "realty", "real", "estate", "group", "homes"}]
                if any(t in blob for t in tokens):
                    match = i
                    break
        name = cards[match]["name"] if match is not None else f"{brand} office"
        phone_text = footer["phone_text"]
        href = ""
        if match is not None:
            used.add(match)
            href = cards[match]["href"]
            phone_text = cards[match]["phone_text"] or phone_text
        row = make_row(
            brand, name, footer["street"], footer["city"], footer["state"], footer["zip"],
            "", "", phone_text, abs_url(page_url, href) or page_url,
        )
        if row:
            rows.append(row)
    return rows


def parse_bhhs_list(html, page_url, brand):
    """bhhs.com office-results cards. Caller must filter mixed-network pages."""
    soup = BeautifulSoup(html, "html.parser")
    rows = []
    for card in soup.select("div.office-list"):
        name_el = card.select_one(".office-list__officename-heading")
        addr_el = card.select_one(".office-list__location-address")
        if name_el is None or addr_el is None:
            continue
        name = name_el.get_text(" ", strip=True)
        parts = [re.sub(r"\s+", " ", x).strip(" ,") for x in addr_el.get_text("\n").split("\n") if x.strip()]
        if len(parts) < 2:
            continue
        loc = re.search(r"^(.*?),\s*([A-Z]{2})\s+(\d{5}(?:-\d{4})?)$", parts[-1])
        if not loc:
            continue
        phone_el = card.select_one(".office-list__connect-contact-number .number")
        phone = phone_el.get_text(" ", strip=True) if phone_el else ""
        link = card.select_one("a[href*='/oid-'], a[href*='/office']")
        url = abs_url(page_url, link["href"]) if link and link.has_attr("href") else page_url
        row = make_row(brand, name, " ".join(parts[:-1]), loc.group(1), loc.group(2), loc.group(3), "", "", phone, url or page_url)
        if row:
            rows.append(row)
    return rows


def parse_office_cards(html, page_url, brand):
    """kvCORE-style office cards: an h3 name plus an <address> of street / City, ST."""
    soup = BeautifulSoup(html, "html.parser")
    rows = []
    for card in soup.select("div.card"):
        address = card.find("address")
        heading = card.find(["h2", "h3"])
        if address is None or heading is None:
            continue
        name = heading.get_text(" ", strip=True)
        parts = [re.sub(r"\s+", " ", x).strip(" ,") for x in address.get_text("\n").split("\n") if x.strip()]
        if len(parts) < 2:
            continue
        loc = re.search(r"^(.*?),\s*([A-Z]{2})(?:\s+(\d{5}(?:-\d{4})?))?$", parts[-1])
        if not loc:
            continue
        tel = card.select_one("a[href^='tel:']")
        phone = tel.get_text(" ", strip=True) if tel else ""
        row = make_row(
            brand, name, " ".join(parts[:-1]), loc.group(1), loc.group(2), loc.group(3) or "",
            "", "", phone, page_url,
        )
        if row:
            rows.append(row)
    return rows


def parse_prose_offices(html, page_url, brand):
    """A few brokerages state their offices in a paragraph instead of a directory."""
    text = re.sub(r"\s+", " ", BeautifulSoup(html, "html.parser").get_text(" "))
    stated = []
    if "3838 Oak Lawn" in text and "6318 Gaston" in text and "550 Reserve" in text:
        stated = [
            ("Oak Lawn office", "3838 Oak Lawn Avenue #500", "Dallas", "TX"),
            ("Gaston Avenue office", "6318 Gaston Avenue #200", "Dallas", "TX"),
            ("Southlake office", "550 Reserve Street #320", "Southlake", "TX"),
        ]
    rows = []
    for name, street, city, state in stated:
        row = make_row(brand, name, street, city, state, "", "", "", "", page_url)
        if row:
            rows.append(row)
    return rows


def parse_datalayer(html, page_url, brand):
    def grab(key):
        m = re.search(rf"'{key}'\s*:\s*'([^']*)'", html)
        return m.group(1).strip() if m else ""

    street = grab("dL_OfficeStreetAddress")
    if not street:
        return []
    name = grab("dL_OfficeName") or brand
    row = make_row(
        brand, name, street, grab("dL_OfficeAddressLocality"), grab("dL_OfficeAddressRegion"),
        grab("dL_OfficePostalCode"), grab("dL_OfficeLatitude"), grab("dL_OfficeLongitude"),
        grab("dL_OfficeTelephone"), page_url,
    )
    return [row] if row else []


def parse_direction_cards(html, page_url, brand):
    soup = BeautifulSoup(html, "html.parser")
    rows = []
    for a in soup.select("a.directions, a[href*='maps.google']"):
        text = a.get_text(" ", strip=True)
        if text and "direction" not in text.lower() and "map" not in text.lower():
            continue
        node = a
        card = None
        for _ in range(6):
            node = node.parent
            if node is None:
                break
            if node.find("strong") or node.select_one(".js-sort-city"):
                card = node
                break
        if card is None:
            continue
        strong = card.find("strong")
        name = strong.get_text(" ", strip=True) if strong else ""
        city_el = card.select_one(".js-sort-city")
        city = city_el.get_text(" ", strip=True) if city_el else ""
        blob = card.get_text("\n", strip=True)
        lines = [re.sub(r"\s+", " ", ln).strip(" |") for ln in blob.split("\n") if ln.strip()]
        street = ""
        state = ""
        zipc = ""
        for ln in lines:
            m = re.search(r"\b([A-Z]{2})\s+(\d{5})", ln)
            if m and (city.lower() in ln.lower() or not city):
                state, zipc = m.group(1), m.group(2)
        if strong is not None:
            nxt = strong.find_next("br")
            # street is the text node after the name's <br>
        # Use the maps query as the address source when present.
        href = a.get("href") or ""
        qm = re.search(r"[?&]q=([^&]+)", href)
        if qm:
            from urllib.parse import unquote
            q = unquote(qm.group(1).replace("+", " "))
            parts = [p.strip() for p in q.split(",") if p.strip()]
            if parts:
                street = parts[0]
        if not street:
            for ln in lines:
                if ln == name or "direction" in ln.lower():
                    continue
                if city and city.lower() in ln.lower() and re.search(r"\b[A-Z]{2}\b", ln):
                    continue
                if re.search(r"\d", ln):
                    street = ln
                    break
        phone_m = re.search(r"\(?\d{3}\)?[-. ]\d{3}[-. ]\d{4}", card.get_text(" "))
        row = make_row(
            brand, name, street, city, state, zipc, "", "",
            phone_m.group(0) if phone_m else "", page_url,
        )
        if row:
            rows.append(row)
    return rows


def parse_page(html, page_url, brand):
    host = urlparse(page_url).netloc.lower()
    rows = []
    rows.extend(parse_roster_json(html, page_url, brand))
    rows.extend(parse_datafloat(html, page_url, brand))
    if not rows:
        rows.extend(parse_reliance(html, page_url, brand))
    if not rows:
        rows.extend(parse_office_cards(html, page_url, brand))
    if not rows:
        rows.extend(parse_bhhs_list(html, page_url, brand))
    if not rows:
        rows.extend(parse_datalayer(html, page_url, brand))
    if not rows:
        rows.extend(parse_prose_offices(html, page_url, brand))
    if not rows:
        rows.extend(parse_direction_cards(html, page_url, brand))
    filt = ""
    for key, needle in NETWORK_NAME_FILTER.items():
        if key in host:
            filt = needle
    if filt:
        rows = [r for r in rows if filt in r["name"].lower() or filt in r["brand"].lower()]
    # Dedup within the page.
    seen = set()
    out = []
    for r in rows:
        key = (r["name"].lower(), r["street"].lower(), r["zip"])
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out


def detail_links(html, page_url):
    soup = BeautifulSoup(html, "html.parser")
    found = []
    for a in soup.find_all("a", href=True):
        href = abs_url(page_url, a["href"])
        if not href:
            continue
        path = urlparse(href).path.lower()
        if "/real-estate-office/" in path or re.search(r"/roster/offices/[a-z0-9]", path):
            # Agent pages under an office are /roster/offices/{slug}/{page}. Skip numbered agent pages.
            if re.search(r"/roster/offices/[^/]+/\d+$", path):
                continue
            found.append(href.split("#")[0])
    # unique, preserve order
    uniq = []
    seen = set()
    for href in found:
        if href not in seen:
            seen.add(href)
            uniq.append(href)
    return uniq


def same_host_office_links(html, page_url):
    host = urlparse(page_url).netloc.lower()
    soup = BeautifulSoup(html, "html.parser")
    found = []
    for a in soup.find_all("a", href=True):
        href = abs_url(page_url, a["href"])
        if not href or urlparse(href).netloc.lower() != host:
            continue
        label = (a.get_text(" ", strip=True) + " " + href).lower()
        if any(k in label for k in ("office", "roster", "location", "contact")):
            if any(k in href.lower() for k in ("property", "homes/", "search", "agent")):
                continue
            found.append(href.split("#")[0])
    uniq = []
    seen = set()
    for href in found:
        if href not in seen:
            seen.add(href)
            uniq.append(href)
    return uniq[:12]


def paginated_urls(url):
    """Page 1 plus numeric suffixes used by the roster platform."""
    urls = [url]
    root = url.rstrip("/")
    if re.search(r"/(roster/)?offices$", root, re.I) or root.endswith("/real-estate-offices"):
        for n in range(2, 16):
            urls.append(f"{root}/{n}")
    return urls


def chrome_error(html):
    if not html:
        return False
    head = html[:4000]
    markers = (
        "ERR_SSL", "ERR_CONNECTION", "ERR_NAME_NOT_RESOLVED", "ERR_TIMED_OUT",
        "neterror", "interstitial-wrapper", "This site can’t be reached",
        "This site can't be reached",
    )
    return any(m in html[:8000] or m in head for m in markers)


def scrape_site(site):
    url = site["url"]
    brand = site["brand"]
    html, final, how = fetch(url)
    log(f"  fetched via {how} len={len(html)} final={final[:90]}")
    if chrome_error(html):
        log("  browser error page — not cached")
        return [], False
    landing = html
    rows = parse_page(html, final or url, brand)
    log(f"  parsed {len(rows)} from landing")
    if not rows and html and len(html) > 50000 and "just a moment" not in html[:3000].lower():
        dump = OUT / "debug" / (urlparse(url).netloc + ".html")
        dump.parent.mkdir(exist_ok=True)
        dump.write_text(html, encoding="utf-8")
        log(f"  dumped unrecognized page {dump.name}")

    # Numeric pagination. Stop when a page adds nothing.
    if rows and (re.search(r"/(roster/)?offices/?$", urlparse(url).path, re.I)):
        for page_url in paginated_urls(url)[1:]:
            html_n, final_n, how_n = fetch(page_url)
            extra = parse_page(html_n, final_n or page_url, brand) if html_n else []
            new = [r for r in extra if (r["name"], r["street"]) not in {(x["name"], x["street"]) for x in rows}]
            log(f"  page {page_url} +{len(new)}")
            if not new:
                break
            rows.extend(new)

    # A directory of office detail links is the full list, even if a couple of samples already parsed.
    directory = [lnk for lnk in detail_links(landing or "", final or url) if "/real-estate-office/" in lnk.lower()]
    if len(directory) >= 3 and len(rows) < len(directory) / 2:
        log(f"  crawling {len(directory)} office detail links")
        have = {r["url"].rstrip("/") for r in rows}
        for i, link in enumerate(directory, 1):
            if link.rstrip("/") in have:
                continue
            html_d, final_d, _how = fetch(link)
            extra = parse_page(html_d, final_d or link, brand) if html_d else []
            rows.extend(extra)
            have.update(r["url"].rstrip("/") for r in extra)
            if i % 15 == 0:
                log(f"    details {i}/{len(directory)} rows={len(rows)}")
            time.sleep(0.12)

    # Homepage or shell: try known office paths. Stop on a TLS error page.
    if len(rows) < 2:
        root = "{uri.scheme}://{uri.netloc}".format(uri=urlparse(final or url))
        for path in CANDIDATE_PATHS:
            candidate = root + path
            if candidate.rstrip("/") == (final or url).rstrip("/"):
                continue
            html_c, final_c, how_c = fetch(candidate)
            if chrome_error(html_c):
                log(f"  candidate {path} browser error — stop")
                break
            extra = parse_page(html_c, final_c or candidate, brand) if html_c else []
            if extra:
                log(f"  candidate {path} via {how_c} -> {len(extra)}")
                rows.extend(extra)
                if re.search(r"/(roster/)?offices/?$", urlparse(final_c or candidate).path, re.I):
                    for page_url in paginated_urls(final_c or candidate)[1:]:
                        html_n, final_n, _how = fetch(page_url)
                        more = parse_page(html_n, final_n or page_url, brand) if html_n else []
                        new = [r for r in more if (r["name"], r["street"]) not in {(x["name"], x["street"]) for x in rows}]
                        log(f"  page {page_url} +{len(new)}")
                        if not new:
                            break
                        rows.extend(new)
                break

    host = urlparse(url).netloc.lower()
    if "bhhscarolinas.com" in host:
        for r in rows:
            name = r["name"].lower()
            if "york simpson" in name:
                r["brand"] = "BHHS York Simpson Underwood Realty"
            elif "yost" in name:
                r["brand"] = "BHHS Yost & Little Realty"
            elif "pinehurst" in name:
                r["brand"] = "BHHS Pinehurst Realty Group"
            elif "carolinas realty" in name:
                r["brand"] = "BHHS Carolinas Realty"
            else:
                mapped = CAROLINAS_BRAND_BY_CITY.get(r["city"].lower())
                r["brand"] = mapped or "BHHS Carolinas Realty"
                if not mapped:
                    r["brand_unmapped"] = True
    real_page = bool(html) and not chrome_error(html) and "just a moment" not in html[:4000].lower() and len(html) > 20000
    return rows, real_page or bool(rows)


def building_key(row):
    street = SUITE.sub(" ", row["street"].lower())
    street = re.sub(r"[.,#]", " ", street)
    toks = [ABBR.get(t, t) for t in street.split()]
    # Keep building/bldg tokens so a campus building stays distinct.
    return (" ".join(toks), row["zip"] or row["city"].lower())


def suite_of(street):
    m = SUITE.search(street or "")
    if not m:
        return ""
    return m.group(0).replace("#", "Unit ").strip()


def rank(row):
    name = row["name"].lower()
    if re.search(r"corporate|headquarter|home office", name):
        return 0
    if AFFILIATE.search(name):
        return 2
    return 1


def to_output(raw_rows):
    groups = defaultdict(list)
    for row in raw_rows:
        groups[building_key(row)].append(row)
    out = []
    for members in groups.values():
        members.sort(key=rank)
        primary = members[0]
        others = members[1:]
        comment = ""
        if others:
            parts = []
            for m in others:
                suite = suite_of(m["street"])
                bits = m["name"]
                if m["brand"] != primary["brand"]:
                    bits += f", {m['brand']}"
                if suite:
                    bits += f", {suite}"
                parts.append(bits)
            comment = (
                "Co-located in same building: "
                + "; ".join(parts)
                + ". Not separate rows: one physical building = one asset; same issuer."
            )
        coords = {(m["lat"], m["lng"]) for m in members if m["lat"]}
        qa = []
        if len(coords) > 1:
            qa.append("LATITUDE|LONGITUDE")
        if primary.get("brand_unmapped"):
            qa.append("FACILITY_NAME")
        if not primary.get("state"):
            qa.append("STATE")
        city = primary["city"]
        if re.match(r"^\d", city) or re.search(r"\b(suite|floor|unit)\b", city, re.I):
            qa.append("CITY")
        address = f"{primary['street']}, {primary['city']}, {primary['state']} {primary['zip']}".strip()
        address = re.sub(r"\s+", " ", address).replace(" ,", ",").strip(" ,")
        name = primary["name"]
        if primary["brand"] and primary["brand"].lower() not in name.lower():
            name = f"{primary['brand']} - {name}"
        out.append({
            "ISSUER_ID": ISSUER_ID,
            "COMPANY_NAME": COMPANY_NAME,
            "FACILITY_NAME": name,
            "FACILITY_ADDRESS": address,
            "CITY": primary["city"],
            "STATE": primary["state"],
            "POSTAL_CODE": primary["zip"],
            "FACILITY_REGION": "United States of America (the)",
            "COUNTRY_ISO3": "USA",
            "LATITUDE": primary["lat"],
            "LONGITUDE": primary["lng"],
            "coord_source": "website" if primary["lat"] else "Not from website",
            "ACTIVITY_AT_ASSET": activity_for(primary["name"]),
            "FACILITY_CONTACT_NUMBER": primary["phone"],
            "SCOPE": "In-Scope",
            "SCOPE_REASON": (
                "In-scope: operational site: HSA-owned brokerage office published on the company roster"
            ),
            "RELEVANT_URL": primary["url"],
            "SOURCE_TYPE": "COMPANY WEBSITE" if "arec.alabama.gov" not in primary["url"] else "SECTOR REGISTRY",
            "VALIDATION_URL": "",
            "VALIDATION_SOURCE_TYPE": "",
            "QA_flag": "|".join(qa),
            "COMMENTS": comment,
        })
    out.sort(key=lambda r: (r["STATE"], r["CITY"], r["FACILITY_NAME"]))
    return out


COLUMNS = [
    "ISSUER_ID", "COMPANY_NAME", "FACILITY_NAME", "FACILITY_ADDRESS", "CITY", "STATE",
    "POSTAL_CODE", "FACILITY_REGION", "COUNTRY_ISO3", "LATITUDE", "LONGITUDE", "coord_source",
    "ACTIVITY_AT_ASSET", "FACILITY_CONTACT_NUMBER", "SCOPE", "SCOPE_REASON", "RELEVANT_URL",
    "SOURCE_TYPE", "VALIDATION_URL", "VALIDATION_SOURCE_TYPE", "QA_flag", "COMMENTS",
]


def main():
    sites = load_sites()
    state = {}
    if PROGRESS_PATH.exists():
        state = json.loads(PROGRESS_PATH.read_text(encoding="utf-8"))
    log(f"sites {len(sites)} already done {len(state)}")
    for site in sites:
        url = site["url"]
        if url in state:
            log(f"skip {site['brand']} ({len(state[url])} cached)")
            continue
        log(f"START {site['brand']} {url}")
        try:
            rows, cache = scrape_site(site)
        except Exception as e:
            log(f"  FAILED {type(e).__name__}: {e}")
            rows, cache = [], False
        if cache:
            state[url] = rows
            PROGRESS_PATH.write_text(json.dumps(state), encoding="utf-8")
            log(f"  saved {len(rows)}")
        else:
            log(f"  not cached ({len(rows)} rows) — page did not clear the bot check")
    raw = [r for rows in state.values() for r in rows]
    output = to_output(raw)
    final_name = f"{ISSUER_ID}_BERKSHIRE_HATHAWAY_ENERGY_COMPANY.csv"
    final_path = Path(FINAL_DIR) / final_name
    final_path.parent.mkdir(parents=True, exist_ok=True)
    with final_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerows(output)
    # Also keep a temp copy for the QA pass.
    with (OUT / final_name).open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerows(output)
    log(f"DONE raw={len(raw)} buildings={len(output)} -> {final_path}")
    if _driver is not None:
        try:
            _driver.quit()
        except Exception:
            pass


if __name__ == "__main__":
    main()
