"""
Generic tabular PDF facility extractor for branch/store/dealer directories.

This script handles facility directories published as PDF tables and converts
them into a normalized CSV schema suitable for issuer-level extraction work.

Supported source patterns:
1. Numbered location tables:
   Columns like:
   `SIRA | TURKCELL ADI | SEHIR | ADRES | ILCE | SEMT | TELEFON`
2. Dealer tables with activity/type:
   Columns like:
   `BAYI ADI | BAYI/FIRMA TICARI UNVANI | BAYI TIPI | ADRES | TELEFON | IL | ILCE`
3. Dealer tables without activity/type:
   Columns like:
   `BAYI/FIRMA ADI | BAYI/FIRMA TICARI UNVANI | IL | ILCE | ADRES | TELEFON`
4. Supplemental manual contact-page records supplied via configuration.

How to adapt for a new issuer:
- Update the CONFIG block only.
- Point each PDF source to the relevant local file or URL-derived file.
- Choose the appropriate `kind` for each PDF source.
- Adjust `ACTIVITY_LABEL` / `ACTIVITY_FROM_COLUMN` per source family.

Example config:
    PDF_SOURCES = [
        {
            "name": "Main Stores",
            "path": r"C:\\Temp\\company_store_list.pdf",
            "kind": "numbered_store_table",
            "activity": "Store",
            "relevant_url": "https://example.com/store-locator",
        }
    ]

Usage:
    python tabular_pdf_facility_extractor.py
"""

from __future__ import annotations

import csv
import json
import re
import shutil
import sys
import unicodedata
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import pdfplumber

sys.stdout.reconfigure(encoding="utf-8")


# ============================================================================
# CONFIGURATION - Change these for each issuer
# ============================================================================
ISSUER_ID = "IID000000002135566"
ISSUER_NAME = "TURKCELL ILETISIM HIZMETLERI ANONIM SIRKETI"

TEMP_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp"
)
OUTPUT_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output"
)
MEMORY_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Extraction Memory")

FINAL_CSV_NAME = f"{ISSUER_ID}_{ISSUER_NAME}.csv"
FINAL_OUTPUT_PATH = OUTPUT_DIR / FINAL_CSV_NAME
PROGRESS_PATH = TEMP_DIR / f"{ISSUER_ID}_progress.json"
SUMMARY_PATH = TEMP_DIR / f"{ISSUER_ID}_summary.json"

COUNTRY_NAME = "Turkey"
COORD_SOURCE_DEFAULT = "not_on_website"
EXPECTED_MIN_COUNT = 961

MAIN_LOCATOR_URL = "https://www.turkcell.com.tr/trc/hakkimizda/iletisim-merkezi"
HQ_URL = "https://www.turkcell.com.tr/hakkimizda/iletisim/genel-merkezlerimiz/detay"
MAIN_PDF_URL = (
    "https://s.turkcell.com.tr/SiteAssets/Hakkimizda/tim/turkcell-magaza-listesi.pdf"
)
DIGITAL_PDF_URL = (
    "https://s.turkcell.com.tr/SiteAssets/Hakkimizda/tim/"
    "Turkcell%20Dijital%20Sat%C4%B1%C5%9F%20Noktalar%C4%B1.pdf"
)
DIGITAL_STORE_PDF_URL = (
    "https://s.turkcell.com.tr/SiteAssets/Hakkimizda/tim/"
    "turkcell-dijital-satis-noktalari-magaza-listesi.pdf"
)

PDF_SOURCES = [
    {
        "name": "Turkcell Magazalari",
        "path": TEMP_DIR / "turkcell-magaza-listesi.pdf",
        "kind": "numbered_store_table",
        "activity": "Turkcell store",
        "relevant_url": MAIN_PDF_URL,
    },
    {
        "name": "Turkcell Dijital Satis Noktalari",
        "path": TEMP_DIR / "turkcell_dijital_satis_noktalari.pdf",
        "kind": "dealer_table_with_type",
        "activity": None,
        "relevant_url": DIGITAL_PDF_URL,
    },
    {
        "name": "Turkcell Dijital Satis Noktalari Magaza Listesi",
        "path": TEMP_DIR / "turkcell_dijital_satis_noktalari_magaza_listesi.pdf",
        "kind": "dealer_table_without_type",
        "activity": "Turkcell digital sales point",
        "relevant_url": DIGITAL_STORE_PDF_URL,
    },
]

# Manual HQ/plaza records from the supplied Turkcell HQ page.
SUPPLEMENTAL_RECORDS = [
    {
        "facility_name_native": "Turkcell Küçükyalı Plaza (Genel Müdürlük)",
        "facility_address_native": (
            "Aydınevler Mahallesi İnönü Caddesi No:20 Küçükyalı Ofispark B Blok - "
            "Maltepe / İstanbul"
        ),
        "city_native": "Maltepe",
        "state_native": "İstanbul",
        "postal_code": "",
        "phone": "(0212) 313 10 00",
        "activity": "Headquarters / plaza office",
        "relevant_url": HQ_URL,
    },
    {
        "facility_name_native": "Turkcell Tepebaşı Plaza",
        "facility_address_native": "Asmalı Mescit Mahallesi. Meşrutiyet Cad. No:71 Beyoğlu / İstanbul",
        "city_native": "Beyoğlu",
        "state_native": "İstanbul",
        "postal_code": "",
        "phone": "(0212) 313 10 00",
        "activity": "Plaza office",
        "relevant_url": HQ_URL,
    },
    {
        "facility_name_native": "Turkcell İzmir Plaza",
        "facility_address_native": "Kazım Dirik Mah. 367/7 Sok. No:12 Bornova / İzmir",
        "city_native": "Bornova",
        "state_native": "İzmir",
        "postal_code": "",
        "phone": "(0212) 313 10 00",
        "activity": "Plaza office",
        "relevant_url": HQ_URL,
    },
    {
        "facility_name_native": "Turkcell Ankara Plaza",
        "facility_address_native": "Eskişehir Yolu 9.Km. No:264 06510 Söğütözü / Ankara",
        "city_native": "Söğütözü",
        "state_native": "Ankara",
        "postal_code": "06510",
        "phone": "(0212) 313 10 00",
        "activity": "Plaza office",
        "relevant_url": HQ_URL,
    },
    {
        "facility_name_native": "Turkcell Adana Plaza",
        "facility_address_native": "Turhan Cemal Beriker Bulvarı Sakarya Mah. No.194/A Seyhan-Adana",
        "city_native": "Seyhan",
        "state_native": "Adana",
        "postal_code": "",
        "phone": "(0212) 313 10 00",
        "activity": "Plaza office",
        "relevant_url": HQ_URL,
    },
    {
        "facility_name_native": "Turkcell Antalya Plaza",
        "facility_address_native": "Kızıltoprak Mah. 915 Sk. No:3 07300 Muratpaşa / Antalya",
        "city_native": "Muratpaşa",
        "state_native": "Antalya",
        "postal_code": "07300",
        "phone": "(0212) 313 10 00",
        "activity": "Plaza office",
        "relevant_url": HQ_URL,
    },
    {
        "facility_name_native": "Turkcell Diyarbakır Plaza",
        "facility_address_native": "Urfa Bulvarı Bağcılar Mah. No:184 21100 Merkez / Diyarbakır",
        "city_native": "Merkez",
        "state_native": "Diyarbakır",
        "postal_code": "21100",
        "phone": "(0212) 313 10 00",
        "activity": "Plaza office",
        "relevant_url": HQ_URL,
    },
    {
        "facility_name_native": "Turkcell Trabzon Plaza",
        "facility_address_native": "Çukurçayır Mah. Hasan Turfanda yolu No:3 Ortahisar – Trabzon",
        "city_native": "Ortahisar",
        "state_native": "Trabzon",
        "postal_code": "",
        "phone": "(0212) 313 10 00",
        "activity": "Plaza office",
        "relevant_url": HQ_URL,
    },
    {
        "facility_name_native": "Turkcell Bursa Plaza",
        "facility_address_native": "Organize Sanayi Bölge Müd. Kırmızı Cad. No:14 Nilüfer - Bursa",
        "city_native": "Nilüfer",
        "state_native": "Bursa",
        "postal_code": "",
        "phone": "(0212) 313 10 00",
        "activity": "Plaza office",
        "relevant_url": HQ_URL,
    },
    {
        "facility_name_native": "Turkcell Erzurum Plaza",
        "facility_address_native": (
            "Ilıca yolu 1.Organize Sanayi Bölgesi 1.Cadde 4.Sok No:10 Aziziye - Erzurum"
        ),
        "city_native": "Aziziye",
        "state_native": "Erzurum",
        "postal_code": "",
        "phone": "(0212) 313 10 00",
        "activity": "Plaza office",
        "relevant_url": HQ_URL,
    },
    {
        "facility_name_native": "Turkcell Gaziantep Plaza",
        "facility_address_native": "Tekstilkent Mah. Demokrasi Bulvarı No:185 / 1 Şahinbey - Gaziantep",
        "city_native": "Şahinbey",
        "state_native": "Gaziantep",
        "postal_code": "",
        "phone": "(0212) 313 10 00",
        "activity": "Plaza office",
        "relevant_url": HQ_URL,
    },
    {
        "facility_name_native": "Turkcell İzmit Plaza",
        "facility_address_native": "Yahya kaptan Mah. Bahçeşehir Sok. No: 30 İzmit-Kocaeli",
        "city_native": "İzmit",
        "state_native": "Kocaeli",
        "postal_code": "",
        "phone": "(0212) 313 10 00",
        "activity": "Plaza office",
        "relevant_url": HQ_URL,
    },
    {
        "facility_name_native": "Turkcell Kayseri Plaza",
        "facility_address_native": "Kayseri Organize Sanayi Bölgesi 13. Cadde No:16 Melikgazi- Kayseri",
        "city_native": "Melikgazi",
        "state_native": "Kayseri",
        "postal_code": "",
        "phone": "(0212) 313 10 00",
        "activity": "Plaza office",
        "relevant_url": HQ_URL,
    },
    {
        "facility_name_native": "Turkcell Samsun Plaza",
        "facility_address_native": "Mimar Sinan Mah. 160.sok.No:18 PK:55200 Atakum - Samsun",
        "city_native": "Atakum",
        "state_native": "Samsun",
        "postal_code": "55200",
        "phone": "(0212) 313 10 00",
        "activity": "Plaza office",
        "relevant_url": HQ_URL,
    },
]

# ============================================================================
# GENERIC EXTRACTION LOGIC BELOW - Do not modify per issuer
# ============================================================================

CSV_HEADERS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "FACILITY_NAME",
    "FACILITY_ADDRESS",
    "CITY",
    "STATE",
    "POSTAL_CODE",
    "FACILITY_REGION",
    "LATITUDE",
    "LONGITUDE",
    "FACILITY_CONTACT_NUMBER",
    "RELEVANT_URL",
    "ACTIVITY_AT_SOURCE",
    "coord_source",
    "FACILITY_NAME_LOCAL",
    "FACILITY_ADDRESS_LOCAL",
]

TURKISH_ASCII_MAP = str.maketrans(
    {
        "ı": "i",
        "İ": "I",
        "ş": "s",
        "Ş": "S",
        "ğ": "g",
        "Ğ": "G",
        "ç": "c",
        "Ç": "C",
        "ö": "o",
        "Ö": "O",
        "ü": "u",
        "Ü": "U",
    }
)


def clean_native(text: Optional[str]) -> str:
    if text is None:
        return ""
    value = str(text).replace("\n", " ").replace("\r", " ")
    value = value.replace("#", "")
    value = re.sub(r"\s+", " ", value)
    return value.strip(" ,;")


def transliterate_ascii(text: Optional[str]) -> str:
    native = clean_native(text)
    if not native:
        return ""
    native = native.translate(TURKISH_ASCII_MAP)
    ascii_value = unicodedata.normalize("NFKD", native).encode("ascii", "ignore").decode("ascii")
    ascii_value = ascii_value.replace("#", "")
    ascii_value = re.sub(r"\s+", " ", ascii_value)
    return ascii_value.strip(" ,;")


def normalize_phone(text: Optional[str]) -> str:
    value = clean_native(text)
    if not value:
        return ""
    value = value.replace(" ", "")
    value = value.replace("–", "-").replace("—", "-")
    value = re.sub(r"[^0-9()+-]", "", value)
    return value


def clean_dealer_text(text: Optional[str]) -> str:
    value = clean_native(text)
    if not value:
        return ""
    # Some PDF rows leak tax IDs / long numeric blobs into the text columns.
    value = re.sub(r"-\s*\d{8,}$", "", value)
    value = re.sub(r"\b\d{8,}\b", "", value)
    value = re.sub(r"(?<=\D)\d{8,}(?=\D|$)", "", value)
    value = re.sub(r"\s+", " ", value)
    return value.strip(" -;,")


def extract_postal_code(text: Optional[str]) -> str:
    value = clean_native(text)
    match = re.search(r"\b\d{5}\b", value)
    return match.group(0) if match else ""


def infer_city_from_address(address_native: str, state_native: str) -> str:
    value = clean_native(address_native)
    if not value:
        return ""
    slash_parts = [part.strip() for part in re.split(r"/|-", value) if part.strip()]
    if len(slash_parts) >= 2:
        tail = transliterate_ascii(slash_parts[-1]).upper()
        state_ascii = transliterate_ascii(state_native).upper()
        if tail == state_ascii:
            return transliterate_ascii(slash_parts[-2])
    if re.search(r"\bMERKEZ\b", transliterate_ascii(value).upper()):
        return "MERKEZ"
    return ""


def normalize_activity_text(text: Optional[str], default_value: str = "Digital sales point") -> str:
    raw = transliterate_ascii(text)
    if not raw:
        return default_value
    squashed = re.sub(r"\s+", "", raw).upper()
    activity_key = re.sub(r"[^A-Z]", "", squashed)
    if activity_key == "DAN":
        activity_key = "DSN"
    if activity_key.startswith("DSNPLUS") and "EXTRA" in activity_key and "MOBIL" in activity_key:
        return "DSNPlus Extra Mobil"
    if activity_key.startswith("DSNPLUS") and "EXTRA" in activity_key:
        return "DSNPlus EXTRA"
    if activity_key.startswith("DSNPLUS") and "MOBIL" in activity_key:
        return "DSNPlus Mobil"
    if activity_key.startswith("DSNPLUS"):
        return "DSNPlus"
    if activity_key.startswith("DSN") and "MOBIL" in activity_key:
        return "DSN Mobil"
    if activity_key.startswith("DSN"):
        return "DSN"
    return raw


def dedupe_key(record: Dict[str, str]) -> Tuple[str, str, str, str]:
    return (
        record["FACILITY_NAME"].lower(),
        record["FACILITY_ADDRESS"].lower(),
        record["FACILITY_CONTACT_NUMBER"],
        record["ACTIVITY_AT_SOURCE"].lower(),
    )


def write_progress(progress: Dict[str, object]) -> None:
    PROGRESS_PATH.write_text(
        json.dumps(progress, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def ensure_dirs() -> None:
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def csv_write(records: Iterable[Dict[str, str]], append: bool) -> int:
    records = list(records)
    if not records:
        return 0
    mode = "a" if append and FINAL_OUTPUT_PATH.exists() else "w"
    with FINAL_OUTPUT_PATH.open(mode, newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_HEADERS)
        if mode == "w":
            writer.writeheader()
        writer.writerows(records)
    return len(records)


def base_record(
    *,
    facility_name_native: str,
    facility_address_native: str,
    city_native: str,
    state_native: str,
    postal_code: str,
    phone: str,
    relevant_url: str,
    activity: str,
) -> Dict[str, str]:
    facility_name_native = clean_dealer_text(facility_name_native)
    facility_address_native = clean_native(facility_address_native)
    facility_name = transliterate_ascii(facility_name_native)
    facility_address = transliterate_ascii(facility_address_native)
    city = transliterate_ascii(city_native) or infer_city_from_address(
        facility_address_native, state_native
    )
    state = transliterate_ascii(state_native)
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "FACILITY_NAME": facility_name,
        "FACILITY_ADDRESS": facility_address,
        "CITY": city,
        "STATE": state,
        "POSTAL_CODE": postal_code or extract_postal_code(facility_address_native),
        "FACILITY_REGION": COUNTRY_NAME,
        "LATITUDE": "",
        "LONGITUDE": "",
        "FACILITY_CONTACT_NUMBER": normalize_phone(phone),
        "RELEVANT_URL": relevant_url,
        "ACTIVITY_AT_SOURCE": normalize_activity_text(activity, default_value=transliterate_ascii(activity) or "Facility"),
        "coord_source": COORD_SOURCE_DEFAULT,
        "FACILITY_NAME_LOCAL": facility_name_native,
        "FACILITY_ADDRESS_LOCAL": facility_address_native,
    }


def normalize_row(row: List[Optional[str]]) -> List[str]:
    return [clean_native(cell) for cell in row]


def parse_numbered_store_table(source: Dict[str, object], progress: Dict[str, object]) -> List[Dict[str, str]]:
    path = Path(source["path"])
    relevant_url = str(source["relevant_url"])
    activity = str(source["activity"])
    records: List[Dict[str, str]] = []

    with pdfplumber.open(path) as pdf:
        total_pages = len(pdf.pages)
        for page_index, page in enumerate(pdf.pages, start=1):
            tables = page.extract_tables()
            for table in tables:
                for raw_row in table:
                    row = normalize_row(raw_row or [])
                    if not row or not row[0].isdigit():
                        continue
                    row += [""] * (7 - len(row))
                    _, dealer_name, state_native, address_native, city_native, neighborhood, phone, *_ = row
                    facility_name_native = dealer_name
                    if neighborhood:
                        facility_name_native = f"{dealer_name} - {neighborhood}"
                    records.append(
                        base_record(
                            facility_name_native=facility_name_native,
                            facility_address_native=address_native,
                            city_native=city_native,
                            state_native=state_native,
                            postal_code="",
                            phone=phone,
                            relevant_url=relevant_url,
                            activity=activity,
                        )
                    )

            if page_index % 20 == 0 or page_index == total_pages:
                progress["current_source"] = source["name"]
                progress["page"] = page_index
                progress["total_pages"] = total_pages
                progress["records_so_far"] = len(records)
                write_progress(progress)

    return records


def parse_dealer_table_with_type(source: Dict[str, object], progress: Dict[str, object]) -> List[Dict[str, str]]:
    path = Path(source["path"])
    relevant_url = str(source["relevant_url"])
    records: List[Dict[str, str]] = []

    with pdfplumber.open(path) as pdf:
        total_pages = len(pdf.pages)
        for page_index, page in enumerate(pdf.pages, start=1):
            tables = page.extract_tables()
            for table in tables:
                for raw_row in table:
                    row = normalize_row(raw_row or [])
                    if len(row) < 7:
                        continue
                    if "BAYI ADI" in " ".join(row).upper():
                        continue
                    dealer_name, company_name, activity_native, address_native, phone, state_native, city_native = row[:7]
                    if not dealer_name or not address_native or not phone:
                        continue
                    facility_name_native = dealer_name
                    if company_name and company_name != dealer_name:
                        facility_name_native = f"{dealer_name} - {company_name}"
                    activity = activity_native or "Digital sales point"
                    records.append(
                        base_record(
                            facility_name_native=facility_name_native,
                            facility_address_native=address_native,
                            city_native=city_native,
                            state_native=state_native,
                            postal_code="",
                            phone=phone,
                            relevant_url=relevant_url,
                            activity=activity,
                        )
                    )

            if page_index % 20 == 0 or page_index == total_pages:
                progress["current_source"] = source["name"]
                progress["page"] = page_index
                progress["total_pages"] = total_pages
                progress["records_so_far"] = len(records)
                write_progress(progress)

    return records


def parse_dealer_table_without_type(source: Dict[str, object], progress: Dict[str, object]) -> List[Dict[str, str]]:
    path = Path(source["path"])
    relevant_url = str(source["relevant_url"])
    activity = str(source["activity"])
    records: List[Dict[str, str]] = []

    with pdfplumber.open(path) as pdf:
        total_pages = len(pdf.pages)
        for page_index, page in enumerate(pdf.pages, start=1):
            tables = page.extract_tables()
            for table in tables:
                for raw_row in table:
                    row = normalize_row(raw_row or [])
                    if len(row) < 6:
                        continue
                    joined = " ".join(row).upper()
                    if "BAYI/FIRMA ADI" in joined or "TURKCELL DAHILI" in joined:
                        continue
                    dealer_name = row[0]
                    company_name = row[1] if len(row) > 1 else ""
                    state_native = row[2] if len(row) > 2 else ""
                    city_native = row[3] if len(row) > 3 else ""
                    address_native = row[4] if len(row) > 4 else ""
                    phone = row[5] if len(row) > 5 else ""
                    if not dealer_name or not address_native or not phone:
                        continue
                    facility_name_native = dealer_name
                    if company_name and company_name != dealer_name:
                        facility_name_native = f"{dealer_name} - {company_name}"
                    records.append(
                        base_record(
                            facility_name_native=facility_name_native,
                            facility_address_native=address_native,
                            city_native=city_native,
                            state_native=state_native,
                            postal_code="",
                            phone=phone,
                            relevant_url=relevant_url,
                            activity=activity,
                        )
                    )

            if page_index % 20 == 0 or page_index == total_pages:
                progress["current_source"] = source["name"]
                progress["page"] = page_index
                progress["total_pages"] = total_pages
                progress["records_so_far"] = len(records)
                write_progress(progress)

    return records


def build_supplemental_records() -> List[Dict[str, str]]:
    records = []
    for item in SUPPLEMENTAL_RECORDS:
        records.append(
            base_record(
                facility_name_native=item["facility_name_native"],
                facility_address_native=item["facility_address_native"],
                city_native=item["city_native"],
                state_native=item["state_native"],
                postal_code=item["postal_code"],
                phone=item["phone"],
                relevant_url=item["relevant_url"],
                activity=item["activity"],
            )
        )
    return records


def dedupe(records: Iterable[Dict[str, str]]) -> List[Dict[str, str]]:
    seen = set()
    unique_records = []
    for record in records:
        if not record["FACILITY_ADDRESS"]:
            continue
        key = dedupe_key(record)
        if key in seen:
            continue
        seen.add(key)
        unique_records.append(record)
    return unique_records


def copy_useful_files() -> None:
    memory_script = MEMORY_DIR / "tabular_pdf_facility_extractor.py"
    temp_script = TEMP_DIR / "tabular_pdf_facility_extractor.py"
    shutil.copyfile(Path(__file__), temp_script)
    shutil.copyfile(Path(__file__), memory_script)


def main() -> None:
    ensure_dirs()

    progress: Dict[str, object] = {"issuer_id": ISSUER_ID, "issuer_name": ISSUER_NAME}

    parser_map = {
        "numbered_store_table": parse_numbered_store_table,
        "dealer_table_with_type": parse_dealer_table_with_type,
        "dealer_table_without_type": parse_dealer_table_without_type,
    }

    # Stage 1: core Turkcell stores + HQ records for the required checkpoint.
    core_records: List[Dict[str, str]] = []
    core_records.extend(parser_map[PDF_SOURCES[0]["kind"]](PDF_SOURCES[0], progress))
    core_records.extend(build_supplemental_records())
    core_unique = dedupe(core_records)
    csv_write(core_unique, append=False)

    existing_keys = {dedupe_key(record) for record in core_unique}
    source_summaries = [
        {
            "name": PDF_SOURCES[0]["name"],
            "records_written": len(core_unique) - len(SUPPLEMENTAL_RECORDS),
            "relevant_url": PDF_SOURCES[0]["relevant_url"],
        },
        {
            "name": "Turkcell HQ and Plazas",
            "records_written": len(SUPPLEMENTAL_RECORDS),
            "relevant_url": HQ_URL,
        },
    ]

    # Stage 2: additional facility families present on the supplied Turkcell source.
    for source in PDF_SOURCES[1:]:
        parsed = parser_map[source["kind"]](source, progress)
        unique_new_records: List[Dict[str, str]] = []
        for record in parsed:
            key = dedupe_key(record)
            if key in existing_keys:
                continue
            existing_keys.add(key)
            unique_new_records.append(record)

        unique_new_records = dedupe(unique_new_records)
        csv_write(unique_new_records, append=True)
        source_summaries.append(
            {
                "name": source["name"],
                "records_written": len(unique_new_records),
                "relevant_url": source["relevant_url"],
            }
        )

    final_count = len(existing_keys)
    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "checkpoint_count_after_core_sources": len(core_unique),
        "appended_after_checkpoint": final_count - len(core_unique),
        "final_total_records": final_count,
        "expected_minimum": EXPECTED_MIN_COUNT,
        "minimum_met": final_count >= EXPECTED_MIN_COUNT,
        "output_csv": str(FINAL_OUTPUT_PATH),
        "sources": source_summaries,
    }
    SUMMARY_PATH.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    write_progress(
        {
            **progress,
            "status": "completed",
            "checkpoint_count_after_core_sources": len(core_unique),
            "appended_after_checkpoint": final_count - len(core_unique),
            "final_total_records": final_count,
            "output_csv": str(FINAL_OUTPUT_PATH),
        }
    )
    copy_useful_files()

    print(
        "Completed extraction:",
        json.dumps(
            {
                "checkpoint_count_after_core_sources": len(core_unique),
                "final_total_records": final_count,
                "output_csv": str(FINAL_OUTPUT_PATH),
            },
            ensure_ascii=False,
        ),
    )


if __name__ == "__main__":
    main()
