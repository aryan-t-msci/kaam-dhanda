"""Kroger-banner store locator extractor (atlas v2).

Platform: Kroger family sites (Ralphs, and the same atlas locator on other banners).
The store-search page is an Akamai-protected shell. Store records, including
coordinates, come from the first-party endpoint:

    GET {BASE_URL}/atlas/v1/stores/v2/locator?filter.locationIds={ids}&projections=full

Grocery and pharmacy pages are listed in {BASE_URL}/storelocator-sitemap.xml.
Fuel centers (storeType I) are often absent from that sitemap. A batch that
includes any unknown location id returns HTTP 404 for the whole batch, so gap
ids are probed one at a time.

Coordinates are taken only from the locator payload. No geocoding.

Usage: edit the config block, then run:
    python kroger_banner_atlas_locator_extractor.py
"""
from __future__ import annotations

import csv
import json
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from curl_cffi import requests

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Edit this block for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_ID = "NOT_PROVIDED"
ISSUER_NAME = "Ralphs"
BASE_URL = "https://www.ralphs.com"
DIVISION = "703"
SCAN_MAX = 1600
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\NBIM QA Check\output")
TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\NBIM QA Check\temp")
COUNTRY = "United States of America (the)"
COUNTRY_ISO3 = "USA"
# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════

LOCATOR_URL = f"{BASE_URL}/atlas/v1/stores/v2/locator"
SITEMAP_URL = f"{BASE_URL}/storelocator-sitemap.xml"
BATCH_SIZE = 25
STATE_ABBR = {
    "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas", "CA": "California",
    "CO": "Colorado", "CT": "Connecticut", "DE": "Delaware", "FL": "Florida", "GA": "Georgia",
    "HI": "Hawaii", "ID": "Idaho", "IL": "Illinois", "IN": "Indiana", "IA": "Iowa",
    "KS": "Kansas", "KY": "Kentucky", "LA": "Louisiana", "ME": "Maine", "MD": "Maryland",
    "MA": "Massachusetts", "MI": "Michigan", "MN": "Minnesota", "MS": "Mississippi", "MO": "Missouri",
    "MT": "Montana", "NE": "Nebraska", "NV": "Nevada", "NH": "New Hampshire", "NJ": "New Jersey",
    "NM": "New Mexico", "NY": "New York", "NC": "North Carolina", "ND": "North Dakota", "OH": "Ohio",
    "OK": "Oklahoma", "OR": "Oregon", "PA": "Pennsylvania", "RI": "Rhode Island", "SC": "South Carolina",
    "SD": "South Dakota", "TN": "Tennessee", "TX": "Texas", "UT": "Utah", "VT": "Vermont",
    "VA": "Virginia", "WA": "Washington", "WV": "West Virginia", "WI": "Wisconsin", "WY": "Wyoming",
    "DC": "District of Columbia",
}
COLUMNS = [
    "ISSUER_ID", "COMPANY_NAME", "FACILITY_NAME", "FACILITY_ADDRESS", "CITY", "STATE",
    "POSTAL_CODE", "FACILITY_REGION", "COUNTRY_ISO3", "LATITUDE", "LONGITUDE", "coord_source",
    "ACTIVITY_AT_ASSET", "FACILITY_CONTACT_NUMBER", "SCOPE", "SCOPE_REASON", "RELEVANT_URL",
    "SOURCE_TYPE", "VALIDATION_URL", "VALIDATION_SOURCE_TYPE", "QA_flag",
]


def clean(value: str) -> str:
    return re.sub(r"\s+", " ", (value or "").replace("#", " ")).strip(" ,")


def fmt_coord(value) -> str:
    if value is None or value == "":
        return ""
    return f"{float(value):.7f}".rstrip("0").rstrip(".")


def get(url: str, params: dict | None = None):
    last = None
    for attempt in range(4):
        try:
            # curl_cffi Chrome impersonation is required. urllib/schannel stalls on Akamai renegotiation.
            response = requests.get(
                url,
                params=params,
                impersonate="chrome",
                timeout=40,
                headers={"Accept": "application/json, application/xml, */*"},
            )
            if response.status_code in (429, 500, 502, 503, 504):
                time.sleep(1.2 * (attempt + 1))
                continue
            return response
        except Exception as exc:
            last = exc
            time.sleep(1.2 * (attempt + 1))
    raise RuntimeError(f"GET failed for {url}: {last}")


def sitemap_maps() -> tuple[dict[str, str], set[str]]:
    xml = get(SITEMAP_URL).text
    grocery: dict[str, str] = {}
    pharmacy: set[str] = set()
    for url in re.findall(r"<loc>(.*?)</loc>", xml):
        grocery_match = re.search(r"/stores/grocery/[^/]+/[^/]+/[^/]+/(\d+)/(\d+)$", url)
        if grocery_match:
            grocery[grocery_match.group(1) + grocery_match.group(2)] = url
            continue
        pharmacy_match = re.search(r"/rx/pharmacy/details/(\d+)/(\d+)$", url)
        if pharmacy_match:
            pharmacy.add(pharmacy_match.group(1) + pharmacy_match.group(2))
    return grocery, pharmacy


def fetch_known(location_ids: list[str]) -> dict[str, dict]:
    found: dict[str, dict] = {}
    for start in range(0, len(location_ids), BATCH_SIZE):
        batch = location_ids[start : start + BATCH_SIZE]
        response = get(LOCATOR_URL, {"filter.locationIds": ",".join(batch), "projections": "full"})
        for store in response.json().get("data", {}).get("stores") or []:
            if store.get("locationId"):
                found[store["locationId"]] = store
        time.sleep(0.25)
    return found


def probe_number(number: int):
    location_id = f"{DIVISION}{number:05d}"
    response = get(LOCATOR_URL, {"filter.locationIds": location_id, "projections": "full"})
    if response.status_code != 200:
        return None
    stores = response.json().get("data", {}).get("stores") or []
    if not stores:
        return None
    store = stores[0]
    if (store.get("banner") or "").lower() != ISSUER_NAME.lower() or store.get("isCrossBanner"):
        return None
    return store


def fetch_gaps(known_numbers: set[int]) -> list[dict]:
    targets = [number for number in range(1, SCAN_MAX + 1) if number not in known_numbers]
    found = []
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(probe_number, number) for number in targets]
        for future in as_completed(futures):
            store = future.result()
            if store:
                found.append(store)
    return found


def to_row(store: dict, grocery_urls: dict[str, str], pharmacy_ids: set[str]) -> dict:
    address = (store.get("locale") or {}).get("address") or {}
    location = (store.get("locale") or {}).get("location") or {}
    lines = [clean(line) for line in (address.get("addressLines") or []) if clean(line)]
    city = clean(address.get("cityTown") or "")
    abbr = clean(address.get("stateProvince") or "")
    postal = clean(address.get("postalCode") or "")
    vanity = clean(store.get("vanityName") or city)
    is_fuel = store.get("storeType") == "I" or "fuel" in vanity.lower()
    name = vanity if vanity.lower().startswith(ISSUER_NAME.lower()) else f"{ISSUER_NAME} - {vanity}"
    departments = " ".join(clean(item.get("vanityName") or "") for item in (store.get("departments") or [])).lower()
    if is_fuel:
        activity = "Fuel center"
        reason = "In-scope: operational site: fuel center published by the company store locator"
    else:
        activity = "Grocery store with pharmacy" if store.get("locationId") in pharmacy_ids or "pharmacy" in departments else "Grocery store"
        if "gas station" in departments or "fuel" in departments:
            activity += "; fuel center"
        reason = "In-scope: operational site: grocery store published on the company store locator"
    lat = fmt_coord(location.get("lat"))
    lng = fmt_coord(location.get("lng"))
    url = grocery_urls.get(store.get("locationId"), "")
    if not url:
        url = f"{LOCATOR_URL}?filter.locationIds={store.get('locationId')}&projections=full"
    return {
        "ISSUER_ID": ISSUER_ID,
        "COMPANY_NAME": ISSUER_NAME,
        "FACILITY_NAME": name,
        "FACILITY_ADDRESS": clean(", ".join(lines + [city, " ".join(part for part in (abbr, postal) if part)])),
        "CITY": city,
        "STATE": STATE_ABBR.get(abbr, abbr),
        "POSTAL_CODE": postal,
        "FACILITY_REGION": COUNTRY,
        "COUNTRY_ISO3": COUNTRY_ISO3,
        "LATITUDE": lat,
        "LONGITUDE": lng,
        "coord_source": "website" if lat and lng else "Not from website",
        "ACTIVITY_AT_ASSET": activity,
        "FACILITY_CONTACT_NUMBER": clean(((store.get("phoneNumber") or {}).get("pretty") or "")),
        "SCOPE": "In-Scope",
        "SCOPE_REASON": reason,
        "RELEVANT_URL": url,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "VALIDATION_URL": "",
        "VALIDATION_SOURCE_TYPE": "",
        "QA_flag": "" if lines else "FACILITY_ADDRESS",
    }


def main() -> None:
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    grocery_urls, pharmacy_ids = sitemap_maps()
    stores = fetch_known(sorted(grocery_urls))
    known_numbers = {int(store["storeNumber"]) for store in stores.values()}
    for store in fetch_gaps(known_numbers):
        stores.setdefault(store["locationId"], store)
    rows = [to_row(store, grocery_urls, pharmacy_ids) for store in stores.values()]
    rows.sort(key=lambda row: (row["CITY"], row["FACILITY_NAME"]))
    out = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
    with out.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerows(rows)
    (TEMP_DIR / f"{ISSUER_NAME.lower()}_raw.json").write_text(json.dumps(list(stores.values())), encoding="utf-8")
    print(f"wrote {len(rows)} rows to {out}")


if __name__ == "__main__":
    main()
