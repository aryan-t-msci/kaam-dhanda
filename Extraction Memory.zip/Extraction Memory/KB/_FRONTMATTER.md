# Extraction Knowledge Base â€” DETAIL
**Version:** 5.1 | **Last Updated:** 2026-05-29
**Index file:** `KB_INDEX.md` (read this first â€” decision tree, pattern list, script inventory)

> **How to use this file:**
> Do NOT read this file top-to-bottom on every task. Use `KB_INDEX.md` to identify which
> Pattern (P-XX) or Company Record (R-XX) you need, then jump directly to that anchor here.
> When appending new knowledge, follow the format rules in `Â§ APPENDING NEW KNOWLEDGE` at the end.

---

## TABLE OF CONTENTS

| Section | Content |
|---------|---------|
| [PATTERNS](#patterns) | Full implementation guide for each platform pattern (P-01 through P-26) |
| [UTILITIES](#utilities) | Reusable code blocks: CJK handling, address parsing, geocoding, deduplication |
| [COMPANY RECORDS](#company-records) | Per-issuer extraction history with approaches tried + learnings (R-01 onward) |
| [APPENDING NEW KNOWLEDGE](#appending-new-knowledge) | Rules and templates for adding new records |

---

# PATTERNS

Each pattern entry covers: detection signals, key characteristics, best approach, known failures, and the reference script.

---

# UTILITIES

Reusable code blocks. Copy these into your scripts rather than reimplementing.

---

# Usage: save every 20 iterations
if processed % 20 == 0:
    save_progress(records_dict, done_combos)
```

---

# Step 1: Navigate to the store locator page (sets session cookies)
await page.goto("https://www.example.com/branch-locator")

# Step 2: POST to token endpoint using browser session (not raw httpx â€” 404 without session)
token_data = await page.evaluate("""
    async () => {
        const r = await fetch('/api/v1/storelocator/token', {method: 'POST'});
        return await r.json();
    }
""")
access_token = token_data['data']['access_token']

# Step 3: Query MapMyIndia TextSearch API with token
# GET https://atlas.mapmyindia.com/api/places/search/json
#     ?query=<brand>+branch&access_token={access_token}&page=1
```

**Known limitation:** Token expires after a short period â€” re-acquire if paginating over many results.

**Reference:** First encountered on Bajaj Finserv (BFS) main branch locator (R-01). Not yet fully implemented â€” use as a starting pattern for future MapMyIndia-based extractors.

---

# COMPANY RECORDS

Each record follows this structure:
- **Sources table** (URL, records, method, script)
- **Platform Pattern** reference
- **Key Approach** (1â€“2 sentence summary)
- **Approaches Tried** (chronological, with results)
- **Key Learnings** (âœ… worked, âŒ failed)
- **Script Config** (reusable parameters)

> RULE - NEGATIVE LEARNINGS MUST BE EARNED. Only record a source as barren, "showcase-only",
> or exhausted-empty if you FULLY worked it (hardened locator discovery for a website; the
> complete schedule for a filing) and it genuinely returned nothing. A thin result or a gap is
> evidence the extraction fell short, not that the source lacks data - in that case note what
> was left unfinished and do NOT write the source off, so a later run still tries it.

Records are numbered R-01 onward. New records are appended at the end.

---

# BFS nearme
BASE_URL = "https://nearme.bajajfinserv.in"
MASTER_OUTLET_ID = "xxxx"  # find in hidden input on page
```

---

# Script not saved - batch-specific manual address pack for CHINA RESOURCES MIXC LIFESTYLE SERVICES LIMITED, no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for Gold Fields Limited, no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for Empresas Copec S.A., no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for J&T Global Express Limited, no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for QATAR NATIONAL BANK (Q.P.S.C.), no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for PRESTIGE ESTATES PROJECTS LIMITED, no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for PT Indofood Sukses Makmur Tbk, no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for HON HAI PRECISION INDUSTRY CO., LTD., no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for TRUE CORPORATION PUBLIC COMPANY LIMITED, no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for TELEFONICA BRASIL S.A, no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for TECH MAHINDRA LIMITED, no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for ANHUI GUJING DISTILLERY COMPANY LIMITED, no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for SHENZHEN SALUBRIS PHARMACEUTICALS CO., LTD., no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for Shennan Circuits Co., Ltd., no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for THE PHOENIX MILLS LIMITED, no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for Samsung Electronics Co., Ltd., no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for Jubilant FoodWorks Limited, no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for China Merchants Energy Shipping Co., Ltd., no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for XPENG INC., no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for Raia Drogasil S/A, no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for Grupo Aeroportuario del Sureste, S.A.B. de C.V., no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for SANLAM LIMITED, no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for Energisa S.A., no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for INTERGLOBE AVIATION LIMITED, no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for Focus Media Information Technology Co., Ltd., no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for UPL LIMITED, no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for Shanghai International Airport Co., Ltd., no reuse promise without re-curation.
```

# Script not saved - batch-specific manual address pack for GODREJ PROPERTIES LIMITED, no reuse promise without re-curation.
```

---

## BATCH UPDATE NOTES — Extraction_Batch_20260411_154132

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-127 CHINA RESOURCES MIXC. Count: 3/3. ✅ 2024 HKEX Annual Report same URL confirmed — office structure unchanged.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-128 GOLD FIELDS. Count: 3/3. ✅ 2018 admin page live (SSL verify=False required). JHB+London+Ghana confirmed.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-129 EMPRESAS COPEC. Count: 3/3. ✅ Sonacol contact live (verify=False): Av. Isabel La Católica 4472, Las Condes, Santiago. ❌ Golden Omega contact-us SSL UNEXPECTED_EOF persists — about-us fallback required.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-130 J&T GLOBAL EXPRESS. Count: 3/3. ✅ New 2024 Annual Report PDF confirmed — Shanghai Qingpu + HK Wanchai + Cayman. PDF section II Corporate Information consistently on PDF page 7.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-131 QATAR NATIONAL BANK. Count: 3/3. ❌ qnb.com ALL pages now 403 Cloudflare from this environment — broader block than prior run. ✅ Prior KB addresses used from R-131 remain valid cross-validated data.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-132 PRESTIGE ESTATES. Count: 3/3 (exceeded — 8+ offices available). ✅ our-investors page: Bengaluru (reg) + Chennai + Kochi + Hyderabad + Mumbai + Goa + Mangalore + NCR Delhi Aerocity + Dubai rep office — all static HTML. ✅ NCR+Dubai offices newly added since prior batch. ❌ Project microsite URLs marketing-only — no corporate address.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-133 PT INDOFOOD. Count: 3/3. ✅ All 3 brand URLs live: Indofood Tower Jakarta Selatan 12910; Jl. Raya Bogor Km 26.6 Jakarta 13710 (indomilk + icecream same factory).

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-134 HON HAI. Count: 3/3. ✅ en-us/contact: No.2, Ziyou St., Tucheng Dist., New Taipei City 236. ❌ es-mx/contact — no physical address (social links only). ✅ foxconnwiofficial.com/contact-us live (618KB).

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-135 TRUE CORPORATION. Count: 2/2. ✅ trueidc.com/en/contact NOW lists 4 offices: Bangkok HQ (Ratchadapisek 10310), Bangkok Branch (True Digital Park West Sukhumvit 10260), Myanmar MICT Park Yangon, Vietnam Me Linh Point Tower HCMC.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-136 TELEFONICA BRASIL. Count: 2/2. ✅ telefonica.com/en/contact-us/ live — Distrito Telefónica Madrid + London IR. ❌ This URL is Telefonica S.A. parent, not Telefonica Brasil — for Brazil rows use ri.vivo.com.br.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-137 TECH MAHINDRA. Count: 2/2. ❌ techmahindra.com/contact-us/ confirmed JS dropdown — 1459 static lines are country selector names, no addresses in HTML.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-138 ANHUI GUJING. Count: 2/2. ✅ 2024 interim PDF confirmed live (3.97MB); Gujing Road, Lixin, Bozhou unchanged.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-139 SHENZHEN SALUBRIS. Count: 2/2. ❌ salubrisbio.com/contact/ 403 bot-blocked. ✅ salubris.com fallback confirmed for Shenzhen+Beijing offices.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-140 SHENNAN CIRCUITS. Count: 2/2. ❌ scc.com.cn timed out — now unreachable (was accessible in prior batch). ✅ Sustainability PDF fallback reliable.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-141 PHOENIX MILLS. Count: 2/2. ✅ thephoenixmills.com/investors/ live (2.8MB); Lower Parel Mumbai 400013 confirmed.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-142 SAMSUNG ELECTRONICS. Count: 2/2. ❌ samsung.com/hu country splash — no office address. ✅ semiconductor locations page live (423KB); Austin TX confirmed.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-143 JUBILANT FOODWORKS. Count: 2/2. ✅ Both URLs 200 OK; Noida 201305 HQ + Peenya Bengaluru 560058 commissary confirmed.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-144 CHINA MERCHANTS ENERGY SHIPPING. Count: 2/2. ✅ Both CMES SG URLs live; Singapore Republic Plaza + Shanghai Huangpu confirmed.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-145 XPENG. Count: 1/1. ✅ find-us page preferred over news article; HK Causeway Bay showroom confirmed.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-146 RAIA DROGASIL. Count: 1/1. ✅ ir.rdsaude.com.br PDF live (1.4MB); São Paulo 01215-030 HQ confirmed.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-147 GRUPO AEROPORTUARIO. Count: 1/1. ❌ asur.com.mx shopping page — commercial only. ✅ Investor meeting page: Bosque de Alisos 47A, Bosques de las Lomas, CDMX 05120.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-148 SANLAM. Count: 1/1. ❌ gh.sanlamallianz.com SSL UNEXPECTED_EOF persists. ✅ Accra 68 Seventh Avenue Ridge confirmed from prior KB.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-149 ENERGISA. Count: 1/1. ✅ energisa.com.br/regioes/mato-grosso live (666KB); agency sub-page provides Cuiabá address — root regional page alone insufficient.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-150 INTERGLOBE AVIATION. Count: 1/1. ✅ interglobe.com/CSTPL live (88KB); Aerocity New Delhi 110037 confirmed.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-151 FOCUS MEDIA. Count: 1/1. ✅ focusmediamea.com/about/ live (228KB); Dubai Al Moosa Tower 2 confirmed.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-152 UPL LIMITED. Count: 1/1. ✅ upl-ltd.com investor contact live (317KB); Mumbai Bandra East 400051 confirmed.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-153 SHANGHAI INTL AIRPORT. Count: 1/1. ❌ shairport.com news/article URL — press release, not corporate address. ✅ Group contact pages (enhq/jcznt/) for Pudong Airport address.

> [!NOTE]
> **Update (2026-04-11) — Batch Extraction_Batch_20260411_154132:** R-154 GODREJ PROPERTIES. Count: 1/1. ✅ godrejproperties.com/reach-us live (482KB); Vikhroli East Mumbai 400079 confirmed.


# APPENDING NEW KNOWLEDGE

## Rules

### Rule 1 â€” APPEND ONLY
- **DO:** Add new sections, append to existing lists, add rows to tables.
- **DON'T:** Delete, rewrite, or modify existing text.
- If existing content is incorrect, add a correction note:
  ```
  > [!NOTE]
  > **Correction (YYYY-MM-DD):** The above is outdated because [reason].
  > Updated approach: [new approach].
  ```

### Rule 2 â€” Where to Append

| What you learned | Where to add |
|-----------------|--------------|
| New platform pattern | `KB_DETAIL.md` â€” add `## P-XX â€” Pattern Name` after last pattern. Add row to `KB_INDEX.md Â§ Platform Pattern Catalogue`. |
| New company record | `KB_DETAIL.md` â€” add `## R-XX â€” Company Name` after last record. Add row to `KB_INDEX.md Â§ Site Record Lookup`. |
| New reusable utility | `KB_DETAIL.md` â€” add `## U-XX â€” Utility Name` after last utility. |
| New script | Add row to `KB_INDEX.md Â§ Script Inventory`. |
| Top-priority rule | Append to `KB_INDEX.md Â§ Quick-Reference Rules`. |

### Rule 3 â€” Version Header
Update the `Last Updated` date in BOTH `KB_INDEX.md` and `KB_DETAIL.md` header lines.

### Rule 4 â€” Company Record Template

Use this exact template for new company records (`## R-XX`):

```markdown
## R-XX â€” COMPANY NAME
*Extracted: Mon YYYY*

| Source | URL | Records | Method | Script |
|--------|-----|---------|--------|--------|
| Source Name | example.com/locations | N | Method | `script.py` |
| **TOTAL** | | **N** | | |

**Platform Pattern:** P-XX (Pattern Name)

**Key Approach:** 1â€“2 sentences on what worked and why.

**Approaches Tried:**
1. First tried [approach] â€” [result: worked/failed because...]
2. Then tried [approach] â€” [result: worked/failed because...]
3. Final working approach: [description]

**Key Learnings:**
- âœ… [What worked and why]
- âŒ [What failed and why â€” prevents future agents from repeating it]

**Script Config:**
```python
ISSUER_ID   = "IID000000000000000"
ISSUER_NAME = "COMPANY NAME"
BASE_URL    = "https://..."
# key config params
```
```

### Rule 5 â€” Platform Pattern Template

```markdown
## P-XX â€” Pattern Name

**Detection:** [Signals that identify this platform in the wild]

**Key Characteristics:**
- [Characteristic 1]
- [Characteristic 2]

**Best Approach:**
1. [Step 1]
2. [Step 2]

**Known Failures:**
- âŒ [What NOT to do]

**Reference Script:** `script_name.py`
```

### Rule 6 â€” Quality Standards for New Records
Every new record must include:
- âœ… at least one "what worked" learning
- âŒ at least one "what failed" learning (prevents future agents from repeating dead ends)
- Script Config block (even if hardcoded â€” helps future agents understand the parameters)
- Platform Pattern reference (P-XX)

---

*End of KB_DETAIL.md â€” version 5.0*

---

## CORRECTION NOTE - 2026-04-11 - SABIC OUTPUT REPAIR

**Applies to:** R-83 - SAUDI BASIC INDUSTRIES CORPORATION SJSC

**Issue:** The earlier SABIC output was not broken at the CSV delimiter level, but the issuer-specific parser used flattened `soup.get_text()` extraction plus broad regex. That pulled compare-panel UI text into `ACTIVITY_AT_ASSET`, treated a support-hours string as a physical address, left most `LOCATION_NAME` fields blank, and misparsed several `COUNTRY` / `CITY` values on postal-heavy and hyphenated addresses.

**Correction:** `sabic_location_extractor.py` was rewritten to:
- read the scoped `div.block.location.contact_details` block for the address instead of scraping the full page text
- read `div.block.location.functions li` for business activity instead of using an unbounded regex slice
- reject non-physical support-hours rows
- infer country from case-insensitive address aliases plus location-page URL slugs
- derive city/state from country-aware token cleanup instead of naive comma/hyphen splitting

**Output Impact:** The repaired SABIC CSV was rebuilt from the official row-level source URLs, reduced from 108 rows to 107 valid physical-location rows, and cleared the previously observed blank-name / blank-country / blank-activity / UI-noise defects.

**Repair Script:** `sabic_location_extractor.py`

---

## CORRECTION NOTE - 2026-04-11 - LI AUTO COORD_SOURCE NORMALIZATION

**Applies to:** R-98 - LI AUTO INC.

**Issue:** The batch output used `coord_source = "From website API"` for Li Auto rows. That value is semantically true but not schema-compliant; the prompt standard requires `website` when coordinates come from an official source page or source API and `Not from website` otherwise.

**Correction:** `js_discovered_json_api_extractor.py` now derives `coord_source` from the row payload itself: `website` when both latitude and longitude are present, `Not from website` otherwise. The Li Auto output CSV was normalized accordingly.

**Repair Script:** `js_discovered_json_api_extractor.py`


---

