"""
Browser-session REST locator extractor.

Pattern:
- JS-rendered locator pages whose REST endpoints are protected by Cloudflare or
  a similar anti-bot layer for direct HTTP calls.
- The public page loads successfully in a verified real browser session, then
  the same session can `fetch()` the protected JSON endpoints from page context.

How to reuse:
1. Update the configuration block for a new issuer and page/API endpoints.
2. Complete any one-time browser verification in the persistent Chrome profile
   if the site is challenge-protected.
3. Run this script. It opens the configured locator page, fetches region and
   store JSON in browser context, saves progress every 20 iterations, and
   writes the final CSV once the threshold is crossed and again at completion.

Example config for another issuer:
    ISSUER_NAME = "Example Telecom"
    ISSUER_ID = "IID000000000000000"
    BASE_URL = "https://www.example.com"
    LOCATION_PATH = "/support/store-locator"
    REGION_API = "/api/regions?sido={sido}"
    STORE_API = "/api/stores?sido={sido}&sigungu={sigungu}&pageNo=1&rowSize=9999"
"""

from __future__ import annotations

import csv
import json
import re
import time
from pathlib import Path
from typing import Dict, Iterable, List
from urllib.parse import quote

from hangul_romanize import Transliter
from hangul_romanize.rule import academic
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_NAME = "LG Uplus Corp"
ISSUER_ID = "IID000000002173299"
BASE_URL = "https://www.lguplus.com"
LOCATION_PATH = "/support/store-address"
SOURCE_TYPE = "COMPANY WEBSITE"
COUNTRY = "South Korea"
COUNTRY_ISO3 = "KOR"
MIN_RECORD_COUNT = 200

REGION_API = "/uhdc/fo/cusp/cucm/v1/addr?sido={sido}"
STORE_API = (
    "/uhdc/fo/cusp/svug/shopinfo/v1/ccw-shop-nm?_paging=true"
    "&sido={sido}&sigungu={sigungu}&searchWord="
    "&callDtlInsptPsblYn=N&rnphnJobPsblYn=N&nameEmbzPsblYn=N"
    "&o2oShopYn=N&ptcrEntrPsblYn=N&smhPsblYn=N&eprnShopYn=N"
    "&apleAsYn=N&frgrRspoYn=N&parkPsblYn=N&shopVsitPsblYn=N"
    "&vsitDlvPsblYn=N&thdyDlvPsblYn=N&pageNo=1&rowSize=9999"
)

TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")
PROFILE_DIR = TEMP_DIR / "lguplus_chrome_profile"
OUTPUT_CSV = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
PROGRESS_JSON = TEMP_DIR / f"{ISSUER_ID}_progress.json"
SUMMARY_JSON = TEMP_DIR / f"{ISSUER_ID}_summary.json"
RAW_JSON = TEMP_DIR / f"{ISSUER_ID}_raw_records.json"
PARTIAL_ROWS_JSON = TEMP_DIR / f"{ISSUER_ID}_partial_rows.json"

CHROME_BINARY = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
PROGRESS_SAVE_EVERY = 20
REQUEST_DELAY_SECONDS = 1.2
RATE_LIMIT_SLEEP_SECONDS = 90
MAX_FETCH_RETRIES = 5

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC BELOW — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════

STATE_MAP = {
    "서울특별시": "Seoul Special City",
    "서울시": "Seoul",
    "부산광역시": "Busan Metropolitan City",
    "대구광역시": "Daegu Metropolitan City",
    "인천광역시": "Incheon Metropolitan City",
    "광주광역시": "Gwangju Metropolitan City",
    "대전광역시": "Daejeon Metropolitan City",
    "울산광역시": "Ulsan Metropolitan City",
    "세종특별자치시": "Sejong Special Self-Governing City",
    "경기도": "Gyeonggi-do",
    "충청북도": "Chungcheongbuk-do",
    "충청남도": "Chungcheongnam-do",
    "전라북도": "Jeollabuk-do",
    "전북특별자치도": "Jeonbuk Special Self-Governing Province",
    "전라남도": "Jeollanam-do",
    "경상북도": "Gyeongsangbuk-do",
    "경상남도": "Gyeongsangnam-do",
    "제주특별자치도": "Jeju Special Self-Governing Province",
    "강원도": "Gangwon-do",
    "강원특별자치도": "Gangwon Special Self-Governing Province",
}

# Only include services whose meaning is clear from the website UI and payload behavior.
SERVICE_FLAG_MAP = {
    "callDtlInsptPsblYn": "Call history review",
    "rnphnJobPsblYn": "Rental phone service",
    "nameEmbzPsblYn": "Identity theft report intake",
    "o2oShopYn": "Store pickup",
    "ptcrEntrPsblYn": "Pet care",
    "smhPsblYn": "U+ Pen experience",
    "apleAsYn": "Apple A/S",
    "frgrRspoYn": "Foreign language support",
}

CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS_NATIVE",
]

TRANSLITER = Transliter(academic)


def clean_text(value: str | None) -> str:
    if value is None:
        return ""
    value = str(value).replace("#", " ").replace("_", " ")
    value = re.sub(r"\s+", " ", value).strip()
    return value


def romanize_korean(text: str) -> str:
    text = clean_text(text)
    if not text:
        return ""
    romanized = TRANSLITER.translit(text)
    romanized = clean_text(romanized)
    replacements = {
        "seo-ulteugbyeolsi": "Seoul Special City",
        "seo-ulsi": "Seoul",
        "busangwang-yeogsi": "Busan Metropolitan City",
        "daegugwang-yeogsi": "Daegu Metropolitan City",
        "incheongwang-yeogsi": "Incheon Metropolitan City",
        "gwangjugwang-yeogsi": "Gwangju Metropolitan City",
        "daejeongwang-yeogsi": "Daejeon Metropolitan City",
        "ulsangwang-yeogsi": "Ulsan Metropolitan City",
        "sejongteugbyeoljachisi": "Sejong Special Self-Governing City",
        "gyeonggido": "Gyeonggi-do",
        "chungcheongbugdo": "Chungcheongbuk-do",
        "chungcheongnamdo": "Chungcheongnam-do",
        "jeollabugdo": "Jeollabuk-do",
        "jeonbugteugbyeoljachido": "Jeonbuk Special Self-Governing Province",
        "jeollanamdo": "Jeollanam-do",
        "gyeongsangbugdo": "Gyeongsangbuk-do",
        "gyeongsangnamdo": "Gyeongsangnam-do",
        "jejuteugbyeoljachido": "Jeju Special Self-Governing Province",
        "gang-wonteugbyeoljachido": "Gangwon Special Self-Governing Province",
        "gang-wondo": "Gangwon-do",
    }
    for src, dst in replacements.items():
        romanized = romanized.replace(src, dst)

    suffix_patterns = [
        ("yeogjeom", " Station Branch"),
        ("jeom", " Branch"),
        ("teugbyeoljachido", "-teugbyeoljachido"),
        ("teugbyeoljachisi", "-teugbyeoljachisi"),
        ("teugbyeolsi", "-teugbyeolsi"),
        ("gwang-yeogsi", "-gwangyeoksi"),
        ("gwangyeogsi", "-gwangyeoksi"),
        ("dong", "-dong"),
        ("gu", "-gu"),
        ("gun", "-gun"),
        ("si", "-si"),
        ("ro", "-ro"),
        ("gil", "-gil"),
        ("eup", "-eup"),
        ("myeon", "-myeon"),
        ("cheung", "-cheung"),
        ("ho", "-ho"),
    ]
    for suffix, replacement in suffix_patterns:
        romanized = re.sub(rf"([A-Za-z]+){suffix}\b", rf"\1{replacement}", romanized)

    romanized = re.sub(r"\(", " (", romanized)
    romanized = re.sub(r"\s+", " ", romanized).strip()
    romanized = " ".join(part.capitalize() if part and not part.isupper() else part for part in romanized.split(" "))
    romanized = romanized.replace("A/s", "A/S").replace("U+ Pen", "U+ Pen")
    return romanized


def state_to_english(state_native: str) -> str:
    return STATE_MAP.get(state_native, romanize_korean(state_native))


def city_to_english(city_native: str) -> str:
    return romanize_korean(city_native)


def address_to_english(address_native: str, state_native: str, city_native: str) -> str:
    address_native = clean_text(address_native)
    if not address_native:
        return ""
    english = romanize_korean(address_native)
    state_english = state_to_english(state_native)
    city_english = city_to_english(city_native)
    for src, dst in [
        (romanize_korean(state_native), state_english),
        (romanize_korean(city_native), city_english),
    ]:
        if src:
            english = english.replace(src, dst)
    english = clean_text(english)
    return english


def derive_activity(shop: Dict[str, str]) -> str:
    services = [label for key, label in SERVICE_FLAG_MAP.items() if shop.get(key) == "Y"]
    if services:
        return "LG Uplus retail store; " + "; ".join(services)
    return "LG Uplus retail store"


def build_row(shop: Dict[str, str], state_native: str, city_native: str) -> Dict[str, str]:
    location_name_native = clean_text(shop.get("posNm"))
    address_native = clean_text(shop.get("roadAddr") or f"{shop.get('basAddr', '')} {shop.get('detlAddr', '')}")
    state = state_to_english(state_native)
    city = city_to_english(city_native)
    location_name = romanize_korean(location_name_native)
    location_address = address_to_english(address_native, state_native, city_native)
    lat = clean_text(shop.get("posYcrdVlue"))
    lng = clean_text(shop.get("posXcrdVlue"))
    coord_source = "website" if lat and lng else "not_on_website"

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": location_name,
        "LOCATION_ADDRESS": location_address,
        "LATITUDE": lat,
        "LONGITUDE": lng,
        "COUNTRY": COUNTRY,
        "COUNTRY_ISO3": COUNTRY_ISO3,
        "POSTCODE": clean_text(shop.get("zip")),
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": f"{BASE_URL}{LOCATION_PATH}",
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": derive_activity(shop),
        "coord_source": coord_source,
        "LOCATION_NAME_NATIVE": location_name_native,
        "LOCATION_ADDRESS_NATIVE": address_native,
    }


def browser_fetch_json(driver: webdriver.Chrome, url: str):
    script = """
const url = arguments[0];
const done = arguments[arguments.length - 1];
fetch(url, {credentials: 'include'})
  .then(async (r) => {
    const text = await r.text();
    done({ok: r.ok, status: r.status, text});
  })
  .catch((e) => done({ok: false, status: 0, error: String(e)}));
"""
    for attempt in range(1, MAX_FETCH_RETRIES + 1):
        result = driver.execute_async_script(script, url)
        if result.get("ok"):
            return json.loads(result["text"])
        if result.get("status") == 429 and attempt < MAX_FETCH_RETRIES:
            time.sleep(RATE_LIMIT_SLEEP_SECONDS)
            driver.get(f"{BASE_URL}{LOCATION_PATH}")
            time.sleep(8)
            continue
        raise RuntimeError(f"Fetch failed for {url}: {result}")


def make_driver() -> webdriver.Chrome:
    options = Options()
    options.binary_location = CHROME_BINARY
    options.add_argument(f"--user-data-dir={PROFILE_DIR}")
    options.add_argument("--profile-directory=Default")
    options.add_argument("--window-size=1600,1200")
    options.add_argument("--lang=ko-KR,ko,en-US,en")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)
    return webdriver.Chrome(options=options)


def save_progress(
    completed: List[Dict[str, str]],
    total_rows: int,
    checkpoint_written: bool,
    rows_by_id: Dict[str, Dict[str, str]],
):
    payload = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "completed_region_pairs": completed,
        "completed_count": len(completed),
        "row_count": total_rows,
        "checkpoint_written": checkpoint_written,
        "saved_at_epoch": time.time(),
    }
    PROGRESS_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    PARTIAL_ROWS_JSON.write_text(
        json.dumps(list(rows_by_id.values()), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def load_resume_state():
    completed_pairs = []
    rows_by_id: Dict[str, Dict[str, str]] = {}
    if PROGRESS_JSON.exists():
        progress = json.loads(PROGRESS_JSON.read_text(encoding="utf-8"))
        completed_pairs = progress.get("completed_region_pairs", [])
    if PARTIAL_ROWS_JSON.exists():
        rows = json.loads(PARTIAL_ROWS_JSON.read_text(encoding="utf-8"))
        for row in rows:
            rows_by_id[row["LOCATION_NAME_NATIVE"] + "|" + row["LOCATION_ADDRESS_NATIVE"]] = row
    return completed_pairs, rows_by_id


def write_csv(path: Path, rows: Iterable[Dict[str, str]], mode: str = "w", write_header: bool = True):
    with path.open(mode, encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=CSV_COLUMNS)
        if write_header:
            writer.writeheader()
        for row in rows:
            writer.writerow(row)


def main():
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    started = time.time()
    driver = make_driver()
    completed_pairs, loaded_rows = load_resume_state()
    rows_by_id: Dict[str, Dict[str, str]] = {}
    for row in loaded_rows.values():
        key = row["LOCATION_NAME_NATIVE"] + "|" + row["LOCATION_ADDRESS_NATIVE"]
        rows_by_id[key] = row
    checkpoint_written = False
    written_ids = set()
    checkpoint_count = 0

    try:
        driver.get(f"{BASE_URL}{LOCATION_PATH}")
        time.sleep(5)

        completed_lookup = {(item["sido"], item["sigungu"]) for item in completed_pairs}
        sidos = browser_fetch_json(driver, f"{BASE_URL}{REGION_API.format(sido='')}")
        for sido in sidos:
            state_native = clean_text(sido["codeVal"])
            sigungus = browser_fetch_json(
                driver,
                f"{BASE_URL}{REGION_API.format(sido=quote(state_native))}",
            )
            time.sleep(REQUEST_DELAY_SECONDS)
            for sigungu in sigungus:
                city_native = clean_text(sigungu["codeVal"])
                if (state_native, city_native) in completed_lookup:
                    continue
                url = f"{BASE_URL}{STORE_API.format(sido=quote(state_native), sigungu=quote(city_native))}"
                shops = browser_fetch_json(driver, url)
                time.sleep(REQUEST_DELAY_SECONDS)
                new_rows = []
                for shop in shops:
                    row_key = clean_text(shop.get("posCd")) or (
                        clean_text(shop.get("posNm")) + "|" + clean_text(shop.get("roadAddr"))
                    )
                    if not row_key or row_key in rows_by_id:
                        continue
                    row = build_row(shop, state_native, city_native)
                    if not row["LOCATION_ADDRESS"] or not row["CITY"]:
                        continue
                    rows_by_id[row_key] = row
                    new_rows.append(row)

                completed_pairs.append({"sido": state_native, "sigungu": city_native, "records_seen": len(shops)})
                completed_lookup.add((state_native, city_native))

                if not checkpoint_written and len(rows_by_id) >= MIN_RECORD_COUNT:
                    checkpoint_count = len(rows_by_id)
                    ordered = list(rows_by_id.values())
                    write_csv(OUTPUT_CSV, ordered, mode="w", write_header=True)
                    written_ids.update(rows_by_id.keys())
                    checkpoint_written = True
                elif checkpoint_written and new_rows:
                    appendable = [row for shop_id, row in rows_by_id.items() if shop_id not in written_ids and row in new_rows]
                    if appendable:
                        write_csv(OUTPUT_CSV, appendable, mode="a", write_header=False)
                        written_ids.update(
                            shop_id for shop_id, row in rows_by_id.items() if row in appendable
                        )

                if len(completed_pairs) % PROGRESS_SAVE_EVERY == 0:
                    save_progress(completed_pairs, len(rows_by_id), checkpoint_written, rows_by_id)

        ordered_rows = list(rows_by_id.values())
        RAW_JSON.write_text(json.dumps(ordered_rows, ensure_ascii=False, indent=2), encoding="utf-8")
        write_csv(OUTPUT_CSV, ordered_rows, mode="w", write_header=True)

        summary = {
            "issuer_id": ISSUER_ID,
            "issuer_name": ISSUER_NAME,
            "source_url": f"{BASE_URL}{LOCATION_PATH}",
            "total_rows": len(ordered_rows),
            "threshold": MIN_RECORD_COUNT,
            "threshold_met": len(ordered_rows) >= MIN_RECORD_COUNT,
            "checkpoint_written": checkpoint_written,
            "checkpoint_count": checkpoint_count,
            "completed_region_pairs": len(completed_pairs),
            "duration_seconds": round(time.time() - started, 2),
        }
        SUMMARY_JSON.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
        save_progress(completed_pairs, len(rows_by_id), checkpoint_written, rows_by_id)
        print(json.dumps(summary, ensure_ascii=False))
    finally:
        driver.quit()


if __name__ == "__main__":
    main()
