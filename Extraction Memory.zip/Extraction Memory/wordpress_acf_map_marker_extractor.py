"""WordPress ACF Google Map marker extractor.

Platform: a page that renders an Advanced Custom Fields map as
``div.acf-map`` containing one ``div.marker`` per facility. Each marker
carries the facility fields as data attributes (title, address, city,
state, lat/lng, project category, status). No geocoding is performed.

Configure the block below for a new issuer. The generic section reads a
saved HTML file or fetches PAGE_URL, then writes the standard facility CSV.

Usage:
    python wordpress_acf_map_marker_extractor.py
"""

from __future__ import annotations

import csv
import html
import json
import re
from pathlib import Path

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Edit this block for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_ID = "IID000000002257452"
ISSUER_NAME = "LS POWER GROUP"
COMPANY_NAME = "LS POWER GROUP"
PAGE_URL = "https://www.lspower.com/what-we-do/"
HTML_PATH = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Barclays2 CQ\Assets to Add\_temp\_lspower_whatwedo.html"
)
OUTPUT_CSV = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Barclays2 CQ\Assets to Add"
) / "LS_Power.csv"
REJECT_CSV = Path(__file__).resolve().parent / "LS_Power_rejected.csv"
QA_JSON = Path(__file__).resolve().parent / "LS_Power_qa.json"

ACTIVITY_LABELS = {
    "Natural Gas": "Natural gas power generation",
    "Solar": "Solar power generation",
    "Wind": "Wind power generation",
    "Hydroelectric": "Hydroelectric power generation",
    "Battery Storage": "Battery energy storage",
    "Transmission": "Electric transmission",
    "Platforms": "Energy platform",
}
# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════

COLUMNS = [
    "ISSUER_ID",
    "COMPANY_NAME",
    "FACILITY_NAME",
    "FACILITY_ADDRESS",
    "CITY",
    "STATE",
    "POSTAL_CODE",
    "FACILITY_REGION",
    "COUNTRY_ISO3",
    "LATITUDE",
    "LONGITUDE",
    "coord_source",
    "ACTIVITY_AT_ASSET",
    "SOLD_TO",
    "FACILITY_CONTACT_NUMBER",
    "SCOPE",
    "SCOPE_REASON",
    "RELEVANT_URL",
    "SOURCE_TYPE",
    "VALIDATION_URL",
    "VALIDATION_SOURCE_TYPE",
    "QA_flag",
]

US_ABBREV = {
    "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas",
    "CA": "California", "CO": "Colorado", "CT": "Connecticut", "DE": "Delaware",
    "FL": "Florida", "GA": "Georgia", "HI": "Hawaii", "ID": "Idaho",
    "IL": "Illinois", "IN": "Indiana", "IA": "Iowa", "KS": "Kansas",
    "KY": "Kentucky", "LA": "Louisiana", "ME": "Maine", "MD": "Maryland",
    "MA": "Massachusetts", "MI": "Michigan", "MN": "Minnesota", "MS": "Mississippi",
    "MO": "Missouri", "MT": "Montana", "NE": "Nebraska", "NV": "Nevada",
    "NH": "New Hampshire", "NJ": "New Jersey", "NM": "New Mexico", "NY": "New York",
    "NC": "North Carolina", "ND": "North Dakota", "OH": "Ohio", "OK": "Oklahoma",
    "OR": "Oregon", "PA": "Pennsylvania", "RI": "Rhode Island", "SC": "South Carolina",
    "SD": "South Dakota", "TN": "Tennessee", "TX": "Texas", "UT": "Utah",
    "VT": "Vermont", "VA": "Virginia", "WA": "Washington", "WV": "West Virginia",
    "WI": "Wisconsin", "WY": "Wyoming", "DC": "District of Columbia",
}
CA_ABBREV = {
    "ON": "Ontario", "QC": "Quebec", "SK": "Saskatchewan", "AB": "Alberta",
    "BC": "British Columbia", "MB": "Manitoba", "NB": "New Brunswick",
    "NS": "Nova Scotia", "PE": "Prince Edward Island", "NL": "Newfoundland and Labrador",
    "NT": "Northwest Territories", "YT": "Yukon", "NU": "Nunavut",
}
CA_PROVINCES = set(CA_ABBREV.values())
US_STATES = set(US_ABBREV.values())
NYC_LOCALITIES = {
    "queens", "brooklyn", "bronx", "manhattan", "staten island",
    "long island city", "new york city",
}

ATTRS = [
    "data-lat", "data-lng", "data-status", "data-state", "data-project-category",
    "data-title", "data-address", "data-city", "data-region", "data-type",
    "data-capacity", "data-acquired_form", "data-sold",
]

US_ZIP_RE = re.compile(r"\b(\d{5})(?:-\d{4})?\b")
CA_POSTAL_RE = re.compile(r"\b([A-Z]\d[A-Z])\s?(\d[A-Z]\d)\b", re.I)
HASH_RE = re.compile(r"#")


def clean(value: str) -> str:
    text = html.unescape(value or "")
    text = text.replace("\xa0", " ")
    text = HASH_RE.sub("", text)
    text = re.sub(r"\s+", " ", text).strip(" ,")
    return text


def parse_markers(page_html: str) -> list[dict]:
    rows = []
    for part in page_html.split('<div class="marker"')[1:]:
        block = part.split("</div>", 1)[0]
        rec = {}
        for attr in ATTRS:
            match = re.search(attr + r'="([^"]*)"', block)
            rec[attr] = clean(match.group(1) if match else "")
        rows.append(rec)
    return rows


def split_locality(address: str) -> tuple[str, str, str]:
    """Return (city_candidate, state_name, postal) parsed from an address string."""
    text = clean(address)
    text = re.sub(r",?\s*(USA|United States(?: of America)?|Canada)\s*$", "", text, flags=re.I)
    postal = ""
    zip_match = US_ZIP_RE.search(text)
    if zip_match:
        postal = zip_match.group(1)
        text = (text[: zip_match.start()] + text[zip_match.end() :]).strip(" ,")
    else:
        ca_match = CA_POSTAL_RE.search(text)
        if ca_match:
            postal = f"{ca_match.group(1).upper()} {ca_match.group(2).upper()}"
            text = (text[: ca_match.start()] + text[ca_match.end() :]).strip(" ,")

    parts = [p.strip() for p in text.split(",") if p.strip()]
    state_name = ""
    city = ""
    if parts:
        last = parts[-1]
        last_tokens = last.split()
        abbrev = last_tokens[0].upper() if last_tokens else ""
        if abbrev in US_ABBREV and (len(last_tokens) == 1 or US_ZIP_RE.match(last_tokens[-1] or "")):
            state_name = US_ABBREV[abbrev]
            if len(parts) >= 2:
                city = parts[-2]
        elif abbrev in CA_ABBREV and len(last_tokens) == 1:
            state_name = CA_ABBREV[abbrev]
            if len(parts) >= 2:
                city = parts[-2]
        elif last in US_STATES or last in CA_PROVINCES:
            state_name = last
            if len(parts) >= 2:
                city = parts[-2]
        elif len(parts) == 1:
            city = parts[0]
    return clean(city), state_name, postal


def country_for(state_name: str, address: str) -> tuple[str, str]:
    blob = f"{state_name} {address}"
    if state_name in CA_PROVINCES or re.search(r"\bCanada\b", blob, re.I):
        return "Canada", "CAN"
    return "United States of America (the)", "USA"


def looks_non_city(city: str) -> bool:
    low = city.lower().strip()
    if not low:
        return True
    needles = ("county", "counties", "region", "township")
    return any(n in low for n in needles)


def state_level_only(city: str, state_name: str, raw_address: str) -> bool:
    """True when the only published locality is the state name itself."""
    if not city or not state_name:
        return False
    if city.lower() != state_name.lower():
        return False
    text = re.sub(r",?\s*(USA|United States(?: of America)?|Canada)\s*$", "", raw_address, flags=re.I)
    text = re.sub(rf",?\s*{re.escape(state_name)}\s*$", "", text, flags=re.I).strip(" ,")
    return text == "" or text.lower() == city.lower()


def activity_for(category: str, subtype: str) -> str:
    label = ACTIVITY_LABELS.get(category, category or "Power generation")
    if subtype:
        label = f"{label} ({subtype})"
    return label


def is_linear_transmission(title: str, category: str) -> bool:
    if category != "Transmission":
        return False
    if "substation" in title.lower():
        return False
    return True


def scope_for(status: str, category: str, title: str, sold: str) -> tuple[str, str, str]:
    """Return SCOPE, SCOPE_REASON, extra QA flag (may be empty)."""
    detail = title or "facility"
    if status == "Under Development":
        return (
            "Out-of-Scope",
            f"Out-of-scope: unconfirmed construction: {detail} is marked Under Development on the portfolio map",
            "",
        )
    if status == "Previously Owned":
        sold_bit = f"; sold to {sold}" if sold else ""
        return (
            "Out-of-Scope",
            f"Out-of-scope: ceased operations: {detail} is marked Previously Owned{sold_bit}",
            "",
        )
    if status == "Developed":
        if sold:
            return (
                "Out-of-Scope",
                f"Out-of-scope: completed project not owned: {detail} is marked Developed and sold to {sold}",
                "",
            )
        return (
            "Out-of-Scope",
            f"Out-of-scope: completed project not owned: {detail} is marked Developed and is not in the operating portfolio",
            "ownership_unverified",
        )
    if is_linear_transmission(title, category):
        return (
            "Out-of-Scope",
            f"Out-of-scope: linear asset: {detail} is an electric transmission asset on the portfolio map",
            "",
        )
    kind = category or "facility"
    return (
        "In-Scope",
        f"In-scope: operational site: {detail} is an operating {kind} asset on the LS Power portfolio map",
        "",
    )


def compose_address(raw_address: str, state_name: str, country_name: str) -> str:
    address = clean(raw_address)
    if state_name and state_name.lower() not in address.lower():
        abbrev = next((a for a, full in {**US_ABBREV, **CA_ABBREV}.items() if full == state_name), "")
        if not abbrev or re.search(rf"\b{abbrev}\b", address) is None:
            address = f"{address}, {state_name}" if address else state_name
    short_country = "Canada" if country_name == "Canada" else "United States"
    if short_country.lower() not in address.lower() and "usa" not in address.lower():
        address = f"{address}, {short_country}" if address else short_country
    return clean(address)


def build_row(raw: dict) -> tuple[dict | None, dict | None]:
    name = raw["data-title"]
    raw_address = raw["data-address"]
    if not name or not raw_address:
        return None, {
            "FACILITY_NAME": name,
            "FACILITY_ADDRESS": raw_address,
            "LATITUDE": raw["data-lat"],
            "LONGITUDE": raw["data-lng"],
            "rejection_reason": "No published address on the marker",
        }

    parsed_city, parsed_state, postal = split_locality(raw_address)
    state_name = raw["data-state"] or parsed_state
    published_city = raw["data-city"]
    qa_notes = []
    qa_flags: list[str] = []

    city = published_city or parsed_city
    tier_a = False
    trusted_city = False
    if published_city and "township" in published_city.lower() and parsed_city and "township" not in parsed_city.lower():
        city = parsed_city
        tier_a = True
        trusted_city = True
        qa_notes.append(f"CITY township '{published_city}' replaced with address city '{parsed_city}'")
    if city.lower() in NYC_LOCALITIES or parsed_city.lower() in NYC_LOCALITIES:
        city = "New York"
        tier_a = True
        trusted_city = True
        qa_notes.append(f"NYC locality '{published_city or parsed_city}' mapped to New York")

    country_name, iso3 = country_for(state_name, raw_address)
    if not city:
        locality = clean(re.sub(
            r",?\s*(USA|United States(?: of America)?|Canada)\s*$", "", raw_address, flags=re.I
        ))
        if locality and locality.lower() != (state_name or "").lower():
            city = locality
        else:
            city = state_name
    if trusted_city and tier_a:
        qa_flags.append("fixed")
    elif state_level_only(city, state_name, raw_address):
        qa_flags.append("CITY_IS_COUNTRY")
        qa_notes.append(f"CITY '{city}' matches the state and the address has no other locality")
    elif looks_non_city(city):
        qa_flags.append("CITY")
        qa_notes.append(f"CITY '{city}' is a county, township, or region rather than a city")

    extra_flag = ""
    scope, reason, extra_flag = scope_for(
        raw["data-status"], raw["data-project-category"], name, raw["data-sold"]
    )
    if extra_flag:
        qa_flags.append(extra_flag)

    if iso3 == "USA" and postal and not re.fullmatch(r"\d{5}", postal):
        qa_notes.append(f"Dropped non-US-ZIP postal '{postal}'")
        postal = ""
    if iso3 == "CAN" and postal and not re.fullmatch(r"[A-Z]\d[A-Z] \d[A-Z]\d", postal):
        qa_notes.append(f"Dropped non-Canadian postal '{postal}'")
        postal = ""

    address = compose_address(raw_address, state_name, country_name)
    lat = raw["data-lat"]
    lng = raw["data-lng"]
    try:
        lat_n = float(lat)
        lng_n = float(lng)
        if not (-90 <= lat_n <= 90 and -180 <= lng_n <= 180):
            raise ValueError
    except ValueError:
        return None, {
            "FACILITY_NAME": name,
            "FACILITY_ADDRESS": address,
            "LATITUDE": lat,
            "LONGITUDE": lng,
            "rejection_reason": "Coordinates missing or out of range",
        }

    row = {
        "ISSUER_ID": ISSUER_ID,
        "COMPANY_NAME": COMPANY_NAME,
        "FACILITY_NAME": name,
        "FACILITY_ADDRESS": address,
        "CITY": city,
        "STATE": state_name,
        "POSTAL_CODE": postal,
        "FACILITY_REGION": country_name,
        "COUNTRY_ISO3": iso3,
        "LATITUDE": lat,
        "LONGITUDE": lng,
        "coord_source": "website",
        "ACTIVITY_AT_ASSET": activity_for(raw["data-project-category"], raw["data-type"]),
        "SOLD_TO": raw["data-sold"],
        "FACILITY_CONTACT_NUMBER": "",
        "SCOPE": scope,
        "SCOPE_REASON": reason,
        "RELEVANT_URL": PAGE_URL,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "VALIDATION_URL": "",
        "VALIDATION_SOURCE_TYPE": "",
        "QA_flag": "|".join(dict.fromkeys(qa_flags)),
    }
    meta = {
        "status": raw["data-status"],
        "category": raw["data-project-category"],
        "notes": qa_notes,
        "published_city": published_city,
        "published_address": raw_address,
    }
    return row, meta


def load_html() -> str:
    if HTML_PATH and Path(HTML_PATH).exists():
        return Path(HTML_PATH).read_text(encoding="utf-8", errors="replace")
    import urllib.request

    request = urllib.request.Request(PAGE_URL, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.read().decode("utf-8", "replace")


def main() -> None:
    page_html = load_html()
    markers = parse_markers(page_html)
    kept = []
    rejected = []
    qa_rows = []
    seen = set()
    for raw in markers:
        row, meta = build_row(raw)
        if row is None:
            rejected.append(meta)
            continue
        key = (
            row["FACILITY_NAME"].lower(),
            row["FACILITY_ADDRESS"].lower(),
            row["LATITUDE"],
            row["LONGITUDE"],
        )
        if key in seen:
            rejected.append({
                "FACILITY_NAME": row["FACILITY_NAME"],
                "FACILITY_ADDRESS": row["FACILITY_ADDRESS"],
                "LATITUDE": row["LATITUDE"],
                "LONGITUDE": row["LONGITUDE"],
                "rejection_reason": "Duplicate marker",
            })
            continue
        seen.add(key)
        kept.append(row)
        qa_rows.append(meta)

    from collections import Counter
    coord_counts = Counter((m["data-lat"], m["data-lng"]) for m in markers)
    for row in kept:
        if coord_counts[(row["LATITUDE"], row["LONGITUDE"])] > 1:
            flags = [f for f in row["QA_flag"].split("|") if f]
            flags.extend(["LATITUDE", "LONGITUDE"])
            row["QA_flag"] = "|".join(dict.fromkeys(flags))

    OUTPUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT_CSV.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerows(kept)
    if rejected:
        with REJECT_CSV.open("w", newline="", encoding="utf-8") as handle:
            fields = ["FACILITY_NAME", "FACILITY_ADDRESS", "LATITUDE", "LONGITUDE", "rejection_reason"]
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rejected)

    from collections import Counter
    summary = {
        "markers": len(markers),
        "kept": len(kept),
        "rejected": rejected,
        "scope": dict(Counter(r["SCOPE"] for r in kept)),
        "activity": dict(Counter(r["ACTIVITY_AT_ASSET"].split(" (")[0] for r in kept)),
        "country": dict(Counter(r["COUNTRY_ISO3"] for r in kept)),
        "qa_flag": dict(Counter(r["QA_flag"] for r in kept)),
        "city_flags": [
            {
                "name": r["FACILITY_NAME"],
                "city": r["CITY"],
                "address": r["FACILITY_ADDRESS"],
                "flag": r["QA_flag"],
                "state": r["STATE"],
            }
            for r in kept
            if "CITY" in r["QA_flag"]
        ],
        "sample": [
            {k: r[k] for k in ("FACILITY_NAME", "FACILITY_ADDRESS", "CITY", "STATE", "POSTAL_CODE", "FACILITY_REGION", "ACTIVITY_AT_ASSET", "LATITUDE", "LONGITUDE", "SCOPE", "QA_flag")}
            for r in kept[:: max(1, len(kept) // 21)]
        ],
    }
    QA_JSON.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    required = [
        "FACILITY_NAME", "FACILITY_ADDRESS", "CITY", "FACILITY_REGION", "COUNTRY_ISO3",
        "ACTIVITY_AT_ASSET", "RELEVANT_URL", "SOURCE_TYPE", "coord_source", "SCOPE", "SCOPE_REASON",
    ]
    blank = [r["FACILITY_NAME"] for r in kept if any(not str(r[col]).strip() for col in required)]
    bad_coord = [r["FACILITY_NAME"] for r in kept if r["coord_source"] not in {"website", "Not from website"}]
    print("blank mandatory", blank)
    print("bad coord_source", bad_coord)
    print("sold_to", sum(1 for r in kept if r["SOLD_TO"]))
    print(f"markers={len(markers)} kept={len(kept)} rejected={len(rejected)}")
    print("scope", summary["scope"])
    print("country", summary["country"])
    print("qa", summary["qa_flag"])
    print("city flags", len(summary["city_flags"]))
    for item in summary["city_flags"]:
        print(f"  {item['name']} | {item['city']} | {item['address']} | {item['flag']}")


if __name__ == "__main__":
    main()
