"""
Pattern: CSRF-Protected Dependent-Dropdown Terminal Directory

This extractor handles sites where:
- a landing page exposes a CSRF token in meta tags,
- AJAX endpoints return JSON code lists for dependent dropdowns, and
- a search endpoint returns HTML table fragments with address/contact rows.

The HMM task also supplements the AJAX directory with a company-side terminal
portfolio page that lists operated/invested terminals not surfaced in the
network directory under the same names.

Usage:
    python csrf_dropdown_terminal_directory_extractor.py
"""

from __future__ import annotations

import csv
import json
import re
import time
import unicodedata
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Set, Tuple

import pycountry
import requests
import urllib3
from bs4 import BeautifulSoup


# ============================================================
# CONFIGURATION - Edit this block for each new issuer
# ============================================================
ISSUER_ID = "IID000000002169832"
ISSUER_NAME = "HMM CO.,LTD"

COUNT_THRESHOLD = 20
BASE_URL = "https://www.hmm21.com"
LANDING_URL = "https://www.hmm21.com/e-service/information/terminal/TerminalInfo.do"
NATION_LIST_URL = "https://www.hmm21.com/e-service/information/terminal/getNationList.do"
LOCATION_LIST_URL = "https://www.hmm21.com/e-service/information/terminal/getLocaionList.do"
SEARCH_URL = "https://www.hmm21.com/e-service/information/terminal/searchTerminalInfo.do"
TERMINAL_PORTFOLIO_URL = "https://www.hmm21.com/company/service/terminalMain.do"
USER_SUPPLIED_URL = "https://www.hmm21.com/cms/business/usa/network/terminal/index.jsp"

TEMP_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp"
)
OUTPUT_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output"
)
MEMORY_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Extraction Memory")

SCRIPT_FILENAME = "csrf_dropdown_terminal_directory_extractor.py"
FINAL_FILENAME = f"{ISSUER_ID}_{ISSUER_NAME}.csv"
CHECKPOINT_FILENAME = f"{ISSUER_ID}_{ISSUER_NAME}_checkpoint.csv"
PROGRESS_FILENAME = f"{ISSUER_ID}_progress.json"
SUMMARY_FILENAME = f"{ISSUER_ID}_summary.json"
KB_APPEND_FILENAME = f"KB_APPEND_{ISSUER_ID}_{time.strftime('%Y%m%d')}.md"


# ============================================================
# GENERIC EXTRACTION LOGIC - Do not modify per issuer
# ============================================================
warnings.simplefilter("ignore", urllib3.exceptions.InsecureRequestWarning)

FIELDNAMES = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS",
    "LOCATION_ADDRESS_NATIVE",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
]

COUNTRY_OVERRIDES = {
    "HK": ("Hong Kong", "HKG"),
    "KR": ("South Korea", "KOR"),
    "MO": ("Macau", "MAC"),
    "RU": ("Russia", "RUS"),
    "TW": ("Taiwan", "TWN"),
    "US": ("United States", "USA"),
    "GB": ("United Kingdom", "GBR"),
    "VN": ("Vietnam", "VNM"),
    "CZ": ("Czech Republic", "CZE"),
}

COMPANY_PORTFOLIO_COUNTRY_HINTS = [
    ("Republic of Korea", "KR"),
    ("USA", "US"),
    ("Singapore", "SG"),
    ("Spain", "ES"),
    ("The Netherlands", "NL"),
    ("Kaohsiung City", "TW"),
]


@dataclass
class LocationRecord:
    issuer_id: str
    issuer_name: str
    location_name: str
    location_name_native: str
    location_address: str
    location_address_native: str
    latitude: str
    longitude: str
    country: str
    country_iso3: str
    postcode: str
    state: str
    city: str
    source_url: str
    source_type: str
    activity_at_asset: str
    coord_source: str

    def to_row(self) -> dict:
        return {
            "ISSUER_ID": self.issuer_id,
            "ISSUER_NAME": self.issuer_name,
            "LOCATION_NAME": self.location_name,
            "LOCATION_NAME_NATIVE": self.location_name_native,
            "LOCATION_ADDRESS": self.location_address,
            "LOCATION_ADDRESS_NATIVE": self.location_address_native,
            "LATITUDE": self.latitude,
            "LONGITUDE": self.longitude,
            "COUNTRY": self.country,
            "COUNTRY_ISO3": self.country_iso3,
            "POSTCODE": self.postcode,
            "STATE": self.state,
            "CITY": self.city,
            "SOURCE_URL": self.source_url,
            "SOURCE_TYPE": self.source_type,
            "ACTIVITY_AT_ASSET": self.activity_at_asset,
            "coord_source": self.coord_source,
        }


def repair_mojibake(text: str) -> str:
    if not text:
        return ""
    if any(marker in text for marker in ("Ã", "Â", "â")):
        try:
            return text.encode("latin1").decode("utf-8")
        except Exception:
            return text
    return text


def clean_text(text: str) -> str:
    text = repair_mojibake(text or "")
    text = text.replace("\xa0", " ")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def transliterate_ascii(text: str) -> str:
    text = clean_text(text)
    text = (
        text.replace("ß", "ss")
        .replace("ä", "ae")
        .replace("ö", "oe")
        .replace("ü", "ue")
        .replace("Ä", "Ae")
        .replace("Ö", "Oe")
        .replace("Ü", "Ue")
    )
    text = re.sub(r"#\s*([A-Za-z0-9-]+)", r"No. \1", text)
    text = text.replace("#", "")
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\s+,", ",", text)
    return text.strip(" ,")


def normalize_key(text: str) -> str:
    text = transliterate_ascii(text).upper()
    return re.sub(r"[^A-Z0-9]+", "", text)


def normalize_address_key(text: str) -> str:
    text = transliterate_ascii(text).upper()
    text = text.replace("ROAD", "RD").replace("RO", "RD")
    return re.sub(r"[^A-Z0-9]+", "", text)


def country_from_code(alpha2: str) -> Tuple[str, str]:
    if alpha2 in COUNTRY_OVERRIDES:
        return COUNTRY_OVERRIDES[alpha2]
    country = pycountry.countries.get(alpha_2=alpha2)
    if country is None:
        raise KeyError(f"Unknown country code: {alpha2}")
    return country.name, country.alpha_3


def infer_company_country_code(address_native: str) -> str:
    for marker, alpha2 in COMPANY_PORTFOLIO_COUNTRY_HINTS:
        if marker.lower() in address_native.lower():
            return alpha2
    raise ValueError(f"Could not infer country from address: {address_native}")


def parse_location_label(label: str) -> Tuple[str, str]:
    parts = [transliterate_ascii(part).title() for part in clean_text(label).split(",") if part.strip()]
    city = parts[0] if parts else ""
    state = ""
    if len(parts) >= 3:
        state = parts[1]
    elif len(parts) == 2 and len(parts[1]) > 3:
        state = parts[1]
    return city, state


def extract_postcode(address: str) -> str:
    address_ascii = transliterate_ascii(address)
    patterns = [
        re.compile(r"\b[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}\b", re.I),
        re.compile(r"\b[A-Z]\d[A-Z]\s?\d[A-Z]\d\b", re.I),
        re.compile(r"\b\d{3}-\d{4}\b"),
        re.compile(r"\b\d{5}(?:-\d{4})?\b"),
        re.compile(r"\b\d{6}\b"),
        re.compile(r"\b\d{4}\b"),
        re.compile(r"\b\d{3}\b"),
    ]
    for pattern in patterns:
        match = pattern.search(address_ascii)
        if match:
            return match.group(0).upper()
    return ""


def looks_like_bad_city(candidate: str) -> bool:
    candidate = clean_text(candidate)
    if not candidate:
        return True
    lowered = candidate.lower()
    return bool(
        re.search(r"\d", candidate)
        or any(
            token in lowered
            for token in [
                " road",
                " rd",
                " drive",
                " avenue",
                " way",
                " street",
                " bl.",
                " blvd",
                "molenweg",
                "webb dock",
                "port central",
            ]
        )
        or len(candidate) > 30
    )


def infer_city_state_from_address(
    address_native: str,
    country_code: str,
    fallback_city: str = "",
    fallback_state: str = "",
) -> Tuple[str, str]:
    address = transliterate_ascii(address_native)
    postcode = extract_postcode(address)

    if country_code in {"US", "CA"}:
        match = re.search(r",\s*([^,]+),\s*([A-Z]{2})\s+[A-Z0-9 -]+(?:,\s*[A-Za-z .]+)?$", address)
        if match:
            city = clean_text(match.group(1)).title()
            state = match.group(2).upper()
            if looks_like_bad_city(city):
                tail = re.split(r"\b(?:RD|ROAD|DR|DRIVE|AVE|AVENUE|WAY|BLVD|BL|BL\.)\b", city, flags=re.I)[-1]
                tail = clean_text(tail).title()
                if tail and not looks_like_bad_city(tail):
                    city = tail
                elif fallback_city:
                    city = fallback_city
            return city, state

    if country_code == "AU":
        match = re.search(r"([A-Za-z .'-]+)\s+([A-Z]{2,3})\s+\d{4}(?:,\s*Australia)?$", address)
        if match:
            city = clean_text(match.group(1)).title()
            if looks_like_bad_city(city) and fallback_city:
                city = fallback_city
            return city, match.group(2).upper()

    if country_code == "SG":
        return "Singapore", ""

    if country_code == "TW":
        match = re.search(r"([^,]+City)", address, re.I)
        if match:
            return clean_text(match.group(1)).title(), ""

    if country_code == "NL":
        matches = re.findall(r"\b\d{4}\s?[A-Z]{2}\s+([A-Za-z ()-]+)", address, re.I)
        if matches:
            city = clean_text(matches[-1]).title()
            if looks_like_bad_city(city) and fallback_city:
                city = fallback_city
            return city, ""

    if country_code in {"DE", "FR", "ES", "IT", "BE"}:
        if country_code == "BE":
            matches = re.findall(r"(?:B\s*-\s*)?(\d{4})\s+([A-Za-z .'-]+)", address, re.I)
            if matches:
                return clean_text(matches[-1][1]).title(), ""
        match = re.search(r"\b\d{4,5}\s+([^,]+)", address)
        if match:
            city = clean_text(match.group(1)).title()
            if looks_like_bad_city(city) and fallback_city:
                city = fallback_city
            return city, ""

    if country_code == "KR":
        parts = [clean_text(part).title() for part in address.split(",") if part.strip()]
        for part in parts:
            if part.endswith("Gu") or part.endswith("District"):
                continue
            if part in {"Republic Of Korea", "South Korea"}:
                continue
            if any(token in part for token in ("Busan", "Gwangyang", "Incheon", "Seoul")):
                part = re.sub(r"\s+\d{4,6}$", "", part).strip()
                if looks_like_bad_city(part) and fallback_city:
                    part = fallback_city
                return part, ""

    if country_code == "HK":
        return "Hong Kong", ""

    if country_code == "MO":
        return "Macau", ""

    if fallback_city:
        return fallback_city, fallback_state

    parts = [clean_text(part).title() for part in address.split(",") if part.strip()]
    meaningful = [part for part in parts if part.upper() != postcode and not re.fullmatch(r"[A-Z]{2,3}", part)]
    if meaningful:
        candidate = meaningful[-2] if len(meaningful) >= 2 else meaningful[-1]
        if looks_like_bad_city(candidate) and fallback_city:
            candidate = fallback_city
        return candidate, ""
    return "", ""


def clean_address_lines(lines: List[str]) -> str:
    cleaned = []
    for line in lines:
        line = clean_text(line)
        if not line:
            continue
        if re.match(r"^(Tel|Fax|E-?mail|PIC)\s*:", line, re.I):
            continue
        cleaned.append(line)
    return clean_text(", ".join(cleaned[:1]))


def build_session() -> Tuple[requests.Session, Dict[str, str]]:
    session = requests.Session()
    session.headers.update({"User-Agent": "Mozilla/5.0"})
    response = session.get(LANDING_URL, timeout=30, verify=False)
    response.raise_for_status()

    soup = BeautifulSoup(response.text, "html.parser")
    csrf_token = soup.select_one("meta[name='_csrf']")
    csrf_header = soup.select_one("meta[name='_csrf_header']")
    if csrf_token is None or csrf_header is None:
        raise RuntimeError("Could not locate CSRF meta tags on landing page.")

    headers = {
        "Content-Type": "application/json; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest",
        "Origin": BASE_URL,
        "Referer": LANDING_URL,
        csrf_header["content"]: csrf_token["content"],
    }
    return session, headers


def post_json(
    session: requests.Session,
    headers: Dict[str, str],
    url: str,
    payload: Optional[dict] = None,
) -> object:
    response = session.post(
        url,
        headers=headers,
        data=json.dumps(payload) if payload is not None else None,
        timeout=30,
        verify=False,
    )
    response.raise_for_status()
    content_type = response.headers.get("content-type", "")
    if "json" in content_type:
        return response.json()
    return response.text


def get_nations(session: requests.Session, headers: Dict[str, str]) -> List[dict]:
    payload = post_json(session, headers, NATION_LIST_URL)
    return payload.get("code", [])  # type: ignore[union-attr]


def get_locations(session: requests.Session, headers: Dict[str, str], nation_code: str) -> List[dict]:
    payload = post_json(session, headers, LOCATION_LIST_URL, {"nation": nation_code})
    return payload.get("code", [])  # type: ignore[union-attr]


def get_terminal_fragment(session: requests.Session, headers: Dict[str, str], location_code: str) -> str:
    html = post_json(session, headers, SEARCH_URL, {"location": location_code})
    if not isinstance(html, str):
        raise TypeError("Expected HTML fragment from search endpoint.")
    return html


def build_network_record(
    nation: dict,
    location: dict,
    terminal_name_native: str,
    address_native: str,
) -> LocationRecord:
    country, iso3 = country_from_code(nation["NTN_CD"])
    fallback_city, fallback_state = parse_location_label(location["LOC_NM"])
    city, state = infer_city_state_from_address(
        address_native=address_native,
        country_code=nation["NTN_CD"],
        fallback_city=fallback_city,
        fallback_state=fallback_state,
    )

    return LocationRecord(
        issuer_id=ISSUER_ID,
        issuer_name=ISSUER_NAME,
        location_name=transliterate_ascii(terminal_name_native),
        location_name_native=clean_text(terminal_name_native),
        location_address=transliterate_ascii(address_native),
        location_address_native=clean_text(address_native),
        latitude="",
        longitude="",
        country=country,
        country_iso3=iso3,
        postcode=extract_postcode(address_native),
        state=state,
        city=city,
        source_url=LANDING_URL,
        source_type="COMPANY WEBSITE",
        activity_at_asset="Container shipping terminal in HMM service network",
        coord_source="Not from website",
    )


def parse_network_records(
    nation: dict,
    location: dict,
    fragment_html: str,
) -> List[LocationRecord]:
    soup = BeautifulSoup(fragment_html, "html.parser")
    records: List[LocationRecord] = []

    for row in soup.select("tbody tr"):
        name_node = row.select_one("th .text")
        terminal_name_native = clean_text(name_node.get_text(" ", strip=True) if name_node else "")
        address_native = clean_address_lines(
            [" ".join(li.stripped_strings) for li in row.select("td:last-child li")]
        )
        if not terminal_name_native or not address_native:
            continue
        records.append(
            build_network_record(
                nation=nation,
                location=location,
                terminal_name_native=terminal_name_native,
                address_native=address_native,
            )
        )

    return records


def parse_company_portfolio_records(html_text: str) -> List[LocationRecord]:
    soup = BeautifulSoup(html_text, "html.parser")
    records: List[LocationRecord] = []

    for cell in soup.select("table.terminal-table td"):
        container = cell.find("div")
        if container is None:
            continue

        title = container.find("div", class_=re.compile(r"\btitle\b"))
        if title is None:
            continue

        direct_spans = [clean_text(span.get_text(" ", strip=True)) for span in title.find_all("span", recursive=False)]
        nested_blocks = title.find_all("div", recursive=False)
        description = ""
        for child in container.find_all("span", recursive=False):
            text = clean_text(child.get_text(" ", strip=True))
            if text:
                description = text
                break

        if nested_blocks:
            bottom_rows = container.select("div.bottom-text")
            for idx, bottom_row in enumerate(bottom_rows):
                spans = [clean_text(span.get_text(" ", strip=True)) for span in bottom_row.find_all("span")]
                if len(spans) != 2:
                    continue
                code, address_native = spans
                terminal_name_native = ""
                if idx == 0 and len(direct_spans) >= 2 and direct_spans[0] == code:
                    terminal_name_native = direct_spans[1]
                else:
                    nested = title.find("div")
                    nested_spans = [clean_text(span.get_text(" ", strip=True)) for span in nested.find_all("span")] if nested else []
                    if len(nested_spans) >= 2 and nested_spans[0] == code:
                        terminal_name_native = nested_spans[1]
                if not terminal_name_native:
                    continue
                country_code = infer_company_country_code(address_native)
                country, iso3 = country_from_code(country_code)
                city, state = infer_city_state_from_address(address_native, country_code)
                records.append(
                    LocationRecord(
                        issuer_id=ISSUER_ID,
                        issuer_name=ISSUER_NAME,
                        location_name=transliterate_ascii(terminal_name_native),
                        location_name_native=terminal_name_native,
                        location_address=transliterate_ascii(address_native),
                        location_address_native=address_native,
                        latitude="",
                        longitude="",
                        country=country,
                        country_iso3=iso3,
                        postcode=extract_postcode(address_native),
                        state=state,
                        city=city,
                        source_url=TERMINAL_PORTFOLIO_URL,
                        source_type="COMPANY WEBSITE",
                        activity_at_asset=transliterate_ascii(description) or "Operated/invested container terminal",
                        coord_source="Not from website",
                    )
                )
            continue

        content_spans = [clean_text(span.get_text(" ", strip=True)) for span in container.find_all("span", recursive=False)]
        content_spans = [span for span in content_spans if span]
        if len(direct_spans) < 2 or len(content_spans) < 2:
            continue
        code, terminal_name_native = direct_spans[0], direct_spans[1]
        address_native = content_spans[-1]
        country_code = infer_company_country_code(address_native)
        country, iso3 = country_from_code(country_code)
        city, state = infer_city_state_from_address(address_native, country_code)
        records.append(
            LocationRecord(
                issuer_id=ISSUER_ID,
                issuer_name=ISSUER_NAME,
                location_name=transliterate_ascii(terminal_name_native),
                location_name_native=terminal_name_native,
                location_address=transliterate_ascii(address_native),
                location_address_native=address_native,
                latitude="",
                longitude="",
                country=country,
                country_iso3=iso3,
                postcode=extract_postcode(address_native),
                state=state,
                city=city,
                source_url=TERMINAL_PORTFOLIO_URL,
                source_type="COMPANY WEBSITE",
                activity_at_asset=transliterate_ascii(description) or f"{code} terminal",
                coord_source="Not from website",
            )
        )

    return records


def save_progress(path: Path, done_locations: Set[str], rows: List[dict]) -> None:
    path.write_text(
        json.dumps({"done_locations": sorted(done_locations), "records": rows}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def load_progress(path: Path) -> Tuple[Set[str], Dict[str, LocationRecord]]:
    if not path.exists():
        return set(), {}
    data = json.loads(path.read_text(encoding="utf-8"))
    done_locations = set(data.get("done_locations", []))
    records: Dict[str, LocationRecord] = {}
    for row in data.get("records", []):
        record = LocationRecord(
            issuer_id=row["ISSUER_ID"],
            issuer_name=row["ISSUER_NAME"],
            location_name=row["LOCATION_NAME"],
            location_name_native=row.get("LOCATION_NAME_NATIVE", row["LOCATION_NAME"]),
            location_address=row["LOCATION_ADDRESS"],
            location_address_native=row.get("LOCATION_ADDRESS_NATIVE", row["LOCATION_ADDRESS"]),
            latitude=row["LATITUDE"],
            longitude=row["LONGITUDE"],
            country=row["COUNTRY"],
            country_iso3=row["COUNTRY_ISO3"],
            postcode=row["POSTCODE"],
            state=row["STATE"],
            city=row["CITY"],
            source_url=row["SOURCE_URL"],
            source_type=row["SOURCE_TYPE"],
            activity_at_asset=row["ACTIVITY_AT_ASSET"],
            coord_source=row["coord_source"],
        )
        records[detailed_key(record)] = record
    return done_locations, records


def detailed_key(record: LocationRecord) -> str:
    return "|".join(
        [
            normalize_key(record.location_name),
            normalize_address_key(record.location_address),
            record.country_iso3,
        ]
    )


def name_country_key(record: LocationRecord) -> str:
    return "|".join([normalize_key(record.location_name), record.country_iso3])


def write_csv(path: Path, records: Iterable[LocationRecord]) -> None:
    rows = [record.to_row() for record in records]
    rows.sort(key=lambda row: (row["COUNTRY"], row["CITY"], row["LOCATION_NAME"], row["LOCATION_ADDRESS"]))
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDNAMES, quoting=csv.QUOTE_ALL)
        writer.writeheader()
        writer.writerows(rows)


def validate_records(records: Iterable[LocationRecord]) -> None:
    for record in records:
        if not record.location_address:
            raise ValueError(f"Blank address: {record}")
        if not record.city:
            raise ValueError(f"Blank city: {record}")
        if "#" in record.location_address:
            raise ValueError(f"Address contains '#': {record.location_address}")
        if record.coord_source != "Not from website":
            raise ValueError(f"Unexpected coord source: {record.coord_source}")


def build_kb_append(final_count: int, company_rows_added: int, script_saved: bool) -> str:
    script_name = f"`{SCRIPT_FILENAME}`" if script_saved else "`None`"
    today = time.strftime("%Y-%m-%d")
    month_year = time.strftime("%b %Y")
    return f"""# KB Append Draft — {ISSUER_NAME} ({ISSUER_ID})

## For `KB_INDEX.md`

### §2 Platform Pattern Catalogue — add row
| P-27 | CSRF Dependent Dropdown HTML Fragment | Page exposes CSRF meta tags, AJAX code lists for nation/location, and HTML fragment results table | `{SCRIPT_FILENAME}` | [→ P-27](#p-27-csrf-dependent-dropdown-html-fragment) |

### §3 Site Record Lookup — add row
| HMM CO.,LTD | {ISSUER_ID} | P-27 CSRF Dependent Dropdown | `{SCRIPT_FILENAME}` | [→ R-63](#r-63-hmm-coltd) |

### §4 Script Inventory — add row
| `{SCRIPT_FILENAME}` | P-27 CSRF Dropdown | CSRF-token replay, dependent nation/location sweep, HTML fragment terminal parsing, checkpoint export |

### §5 Quick-Reference Rules — append bullet
- CSRF-protected dropdown directories: replay the landing page's `_csrf` / `_csrf_header` meta values with the same browser session cookie before calling JSON/HTML AJAX endpoints; raw POSTs without the CSRF header return 403.

## For `KB_DETAIL.md`

## P-27 — CSRF Dependent Dropdown HTML Fragment

**Detection:** Landing page contains `_csrf` meta tags, page JS calls dependent dropdown endpoints such as `getNationList` / `getLocationList`, and search results arrive as HTML fragments that replace a result table container.

**Key Characteristics:**
- Public landing page is readable, but AJAX endpoints reject requests unless the session cookie and CSRF header from the landing page are replayed together.
- First endpoint returns JSON code lists (nation/location); second endpoint returns HTML `<tbody><tr>` fragments with address and contact `<li>` rows.
- Address is usually the first non-contact `<li>` in the contact-info column.

**Best Approach:**
1. GET the landing page first and parse `_csrf` / `_csrf_header` meta tags.
2. Reuse the same session cookies for dependent list endpoints.
3. Parse the result fragment with BeautifulSoup and keep the first non-contact contact-info line as the address.
4. If the company site has a supplemental terminal-portfolio page, merge it after de-duplicating by normalized terminal name/country.

**Known Failures:**
- ❌ POSTing directly to the AJAX endpoints without replaying the CSRF header — HMM returns 403 Denied.
- ❌ Trusting the stale company URL blindly — the supplied `/cms/business/usa/network/terminal/index.jsp` redirected to the dashboard on {today}, so live navigation had to be re-verified.

**Reference Script:** `{SCRIPT_FILENAME}`

## R-63 — HMM CO.,LTD
*Extracted: {month_year}*

| Source | URL | Records | Method | Script |
|--------|-----|---------|--------|--------|
| HMM Terminal Information | hmm21.com/e-service/information/terminal/TerminalInfo.do | {final_count - company_rows_added} | CSRF-token replay + nation/location sweep + HTML fragment parsing | `{SCRIPT_FILENAME}` |
| HMM Terminal Portfolio | hmm21.com/company/service/terminalMain.do | {company_rows_added} | Static company terminal table supplement | `{SCRIPT_FILENAME}` |
| **TOTAL** | | **{final_count}** | | |

**Platform Pattern:** P-27 (CSRF Dependent Dropdown HTML Fragment)

**Key Approach:** The live terminal dataset sat behind a CSRF-protected dependent-dropdown flow. Fetching the landing page first, replaying the CSRF header with the same session cookies, and then iterating nation → location → HTML fragment searches produced the terminal directory cleanly; the company terminal portfolio page added named HMM-operated/invested terminals that were not surfaced under the same labels in the network directory.

**Approaches Tried:**
1. First tried the user-supplied company URL — it redirected to the dashboard, so it could not be used directly as the extraction page.
2. Then tried raw POST requests to the AJAX endpoints — failed with 403 Denied until the CSRF header and landing-session cookies were replayed exactly like the site's own `comAjax` helper.
3. Final working approach: use the landing page to seed CSRF/session state, sweep nation/location dropdown APIs, parse HTML fragment rows, then supplement from the company terminal portfolio page and de-duplicate.

**Key Learnings:**
- ✅ HMM's shared `comAjax` helper in `/js/common/common.js` reveals the missing CSRF requirement quickly; reading site JS avoided wasting more time on browser automation.
- ✅ The first non-contact `<li>` in the result table's contact-info column is the address to keep for this pattern.
- ❌ Headless/raw requests without the CSRF replay look like anti-bot issues at first, but the real blocker is the missing CSRF header.
- ❌ The stale `/cms/business/usa/network/terminal/index.jsp` path is no longer the live data page as of {today}; always verify navigation targets on this site.

**Script Config:**
```python
ISSUER_ID = "{ISSUER_ID}"
ISSUER_NAME = "{ISSUER_NAME}"
LANDING_URL = "{LANDING_URL}"
NATION_LIST_URL = "{NATION_LIST_URL}"
LOCATION_LIST_URL = "{LOCATION_LIST_URL}"
SEARCH_URL = "{SEARCH_URL}"
TERMINAL_PORTFOLIO_URL = "{TERMINAL_PORTFOLIO_URL}"
COUNT_THRESHOLD = {COUNT_THRESHOLD}
```
"""


def main() -> None:
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    progress_path = TEMP_DIR / PROGRESS_FILENAME
    checkpoint_path = TEMP_DIR / CHECKPOINT_FILENAME
    output_path = OUTPUT_DIR / FINAL_FILENAME
    summary_path = TEMP_DIR / SUMMARY_FILENAME
    kb_append_path = TEMP_DIR / KB_APPEND_FILENAME
    memory_script_path = MEMORY_DIR / SCRIPT_FILENAME

    done_locations, records_by_key = load_progress(progress_path)
    existing_name_country_keys = {name_country_key(record) for record in records_by_key.values()}

    session, headers = build_session()
    user_url_response = session.get(USER_SUPPLIED_URL, timeout=30, verify=False, allow_redirects=True)
    user_url_effective = user_url_response.url

    nations = get_nations(session, headers)
    checkpoint_written = checkpoint_path.exists()
    processed_locations = 0

    for nation in nations:
        locations = get_locations(session, headers, nation["NTN_CD"])
        for location in locations:
            location_code = location["LOC_CD"]
            if location_code in done_locations:
                continue

            fragment_html = get_terminal_fragment(session, headers, location_code)
            for record in parse_network_records(nation, location, fragment_html):
                key = detailed_key(record)
                if key in records_by_key:
                    continue
                records_by_key[key] = record
                existing_name_country_keys.add(name_country_key(record))

                if len(records_by_key) >= COUNT_THRESHOLD and not checkpoint_written:
                    write_csv(checkpoint_path, records_by_key.values())
                    checkpoint_written = True

            done_locations.add(location_code)
            processed_locations += 1

            if processed_locations % 20 == 0:
                save_progress(
                    progress_path,
                    done_locations,
                    [record.to_row() for record in records_by_key.values()],
                )

    company_html = session.get(TERMINAL_PORTFOLIO_URL, timeout=30, verify=False).text
    company_records_added = 0
    for record in parse_company_portfolio_records(company_html):
        if name_country_key(record) in existing_name_country_keys:
            continue
        key = detailed_key(record)
        if key in records_by_key:
            continue
        records_by_key[key] = record
        existing_name_country_keys.add(name_country_key(record))
        company_records_added += 1

    records = list(records_by_key.values())
    validate_records(records)
    write_csv(output_path, records)

    kb_append_path.write_text(
        build_kb_append(
            final_count=len(records),
            company_rows_added=company_records_added,
            script_saved=True,
        ),
        encoding="utf-8",
    )

    memory_script_path.write_text(Path(__file__).read_text(encoding="utf-8"), encoding="utf-8")

    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "count_threshold": COUNT_THRESHOLD,
        "final_row_count": len(records),
        "network_row_count": len(records) - company_records_added,
        "company_portfolio_rows_added": company_records_added,
        "checkpoint_written": checkpoint_written,
        "checkpoint_path": str(checkpoint_path),
        "progress_path": str(progress_path),
        "output_csv": str(output_path),
        "kb_append_path": str(kb_append_path),
        "memory_script_path": str(memory_script_path),
        "user_supplied_url_effective": user_url_effective,
        "landing_url": LANDING_URL,
        "terminal_portfolio_url": TERMINAL_PORTFOLIO_URL,
    }
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
