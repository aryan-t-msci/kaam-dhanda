"""
Config-driven extractor for fitness club networks that expose official location
inventories either through JSON-LD ItemList pages or through a sitemap of detail
pages with JSON-LD business schemas.

How to adapt for a new issuer:
1. Update the CONFIG block with issuer constants and source definitions.
2. For list pages, provide the club-finder URLs in `ITEMLIST_SOURCES`.
3. For sitemap-backed brands, provide sitemap URLs in `SITEMAP_SOURCES`.
4. Run the script; it will checkpoint progress every 20 detail pages.

Usage:
    python fitness_brand_ldjson_sitemap_extractor.py
"""

from __future__ import annotations

import asyncio
import csv
import json
import math
import re
import unicodedata
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx
from bs4 import BeautifulSoup


# ============================================================
# CONFIGURATION - Edit this block for each new issuer
# ============================================================
ISSUER_ID = "IID000000002767056"
ISSUER_NAME = "Basic-Fit N.V."
COUNT_TARGET = 2152

STAGING_CSV = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp CLI\Extraction_Batch_odbatch9_10_output_for_straive_20260603_155947\staging\IID000000002767056_Basic-Fit N.V..csv"
)
ISSUER_TEMP_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp CLI\Extraction_Batch_odbatch9_10_output_for_straive_20260603_155947\IID000000002767056_Basic-Fit N.V."
)
REJECT_CSV = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp CLI\Extraction_Batch_odbatch9_10_output_for_straive_20260603_155947\reject\IID000000002767056_Basic-Fit N.V._rejected.csv"
)
CHECKPOINT_CSV = ISSUER_TEMP_DIR / f"{ISSUER_ID}_checkpoint.csv"
PROGRESS_JSON = ISSUER_TEMP_DIR / f"{ISSUER_ID}_progress.json"
QA_JSON = ISSUER_TEMP_DIR / f"{ISSUER_ID}_qa_summary.json"
EXTRACTION_JSON = ISSUER_TEMP_DIR / f"{ISSUER_ID}_extraction_summary.json"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9",
}

ITEMLIST_SOURCES = [
    {
        "page_url": "https://www.basic-fit.com/en-nl/club-finder",
        "activity": "Fitness club",
        "brand": "Basic-Fit",
        "fallback_country": "Netherlands",
        "fallback_iso3": "NLD",
    },
    {
        "page_url": "https://www.basic-fit.com/en-fr/club-finder",
        "activity": "Fitness club",
        "brand": "Basic-Fit",
        "fallback_country": "France",
        "fallback_iso3": "FRA",
    },
    {
        "page_url": "https://www.basic-fit.com/en-be/club-finder",
        "activity": "Fitness club",
        "brand": "Basic-Fit",
        "fallback_country": "Belgium",
        "fallback_iso3": "BEL",
    },
    {
        "page_url": "https://www.basic-fit.com/en-de/club-finder",
        "activity": "Fitness club",
        "brand": "Basic-Fit",
        "fallback_country": "Germany",
        "fallback_iso3": "DEU",
    },
    {
        "page_url": "https://www.basic-fit.com/en-es/club-finder",
        "activity": "Fitness club",
        "brand": "Basic-Fit",
        "fallback_country": "Spain",
        "fallback_iso3": "ESP",
    },
    {
        "page_url": "https://www.basic-fit.com/en-lu/club-finder",
        "activity": "Fitness club",
        "brand": "Basic-Fit",
        "fallback_country": "Luxembourg",
        "fallback_iso3": "LUX",
    },
]

SITEMAP_SOURCES = [
    {
        "sitemap_url": "https://www.clever-fit.com/studio-sitemap1.xml",
        "activity": "Fitness club",
        "brand": "clever fit",
        "source_type": "COMPANY WEBSITE",
    }
]

OUTPUT_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
]

COUNTRY_MAP = {
    "AT": ("Austria", "AUT"),
    "BE": ("Belgium", "BEL"),
    "CH": ("Switzerland", "CHE"),
    "CZ": ("Czech Republic", "CZE"),
    "DE": ("Germany", "DEU"),
    "ES": ("Spain", "ESP"),
    "FR": ("France", "FRA"),
    "HR": ("Croatia", "HRV"),
    "LU": ("Luxembourg", "LUX"),
    "NL": ("Netherlands", "NLD"),
    "RO": ("Romania", "ROU"),
}

CLEVERFIT_LOCALE_MAP = {
    "de": ("Germany", "DEU"),
    "de-AT": ("Austria", "AUT"),
    "de-CH": ("Switzerland", "CHE"),
    "fr-CH": ("Switzerland", "CHE"),
    "ro": ("Romania", "ROU"),
    "en": ("Romania", "ROU"),
    "hr": ("Croatia", "HRV"),
    "cz": ("Czech Republic", "CZE"),
}


# ============================================================
# GENERIC EXTRACTION LOGIC - Do not modify per issuer
# ============================================================
def ascii_clean(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if not text:
        return ""
    replacements = {
        "ß": "ss",
        "ä": "ae",
        "ö": "oe",
        "ü": "ue",
        "Ä": "Ae",
        "Ö": "Oe",
        "Ü": "Ue",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def clean_address(*parts: Any) -> str:
    kept = [ascii_clean(part) for part in parts if ascii_clean(part)]
    text = ", ".join(kept)
    text = text.replace("#", "")
    text = re.sub(r"\b(?:Tel|Phone|Email)\b.*$", "", text, flags=re.I)
    text = re.sub(r"\s*,\s*", ", ", text)
    text = re.sub(r"(,\s*){2,}", ", ", text)
    return text.strip(" ,")


def decimal_string(value: Any) -> str:
    if value in (None, ""):
        return ""
    try:
        return f"{float(str(value)):0.10f}".rstrip("0").rstrip(".")
    except ValueError:
        return ""


def country_from_code(code: str, fallback_country: str = "", fallback_iso3: str = "") -> tuple[str, str]:
    code = ascii_clean(code).upper()
    if code in COUNTRY_MAP:
        return COUNTRY_MAP[code]
    return fallback_country, fallback_iso3


def extract_jsonld_blocks(html: str) -> list[Any]:
    soup = BeautifulSoup(html, "html.parser")
    blocks: list[Any] = []
    for tag in soup.find_all("script", attrs={"type": "application/ld+json"}):
        raw = (tag.string or tag.get_text() or "").strip()
        if not raw:
            continue
        try:
            blocks.append(json.loads(raw))
        except json.JSONDecodeError:
            continue
    return blocks


def flatten_graph(node: Any) -> list[dict[str, Any]]:
    if isinstance(node, dict):
        if "@graph" in node and isinstance(node["@graph"], list):
            return [item for item in node["@graph"] if isinstance(item, dict)]
        return [node]
    if isinstance(node, list):
        return [item for item in node if isinstance(item, dict)]
    return []


def first_matching_schema(blocks: list[Any], schema_types: set[str]) -> dict[str, Any] | None:
    for block in blocks:
        for entry in flatten_graph(block):
            entry_type = entry.get("@type")
            types = {entry_type} if isinstance(entry_type, str) else set(entry_type or [])
            if types & schema_types:
                return entry
    return None


def first_itemlist(blocks: list[Any]) -> dict[str, Any] | None:
    for block in blocks:
        for entry in flatten_graph(block):
            if entry.get("@type") == "ItemList":
                return entry
    return None


def build_basicfit_seed_rows(itemlist: dict[str, Any], source_cfg: dict[str, str]) -> list[dict[str, Any]]:
    seeds: list[dict[str, Any]] = []
    for item in itemlist.get("itemListElement", []):
        row = item.get("item") or {}
        address = row.get("address") or {}
        seeds.append(
            {
                "detail_url": row.get("url", "").strip(),
                "fallback_name": ascii_clean(row.get("name")),
                "fallback_street": ascii_clean(address.get("streetAddress")),
                "fallback_city": ascii_clean(address.get("addressLocality")),
                "fallback_postcode": ascii_clean(address.get("postalCode")),
                "fallback_country_code": ascii_clean(address.get("addressCountry")),
                "fallback_country": source_cfg["fallback_country"],
                "fallback_iso3": source_cfg["fallback_iso3"],
                "list_source_url": source_cfg["page_url"],
                "activity": source_cfg["activity"],
                "brand": source_cfg["brand"],
                "source_type": "COMPANY WEBSITE",
            }
        )
    return seeds


def extract_basicfit_detail_hrefs(html: str, locale_slug: str) -> list[str]:
    soup = BeautifulSoup(html, "html.parser")
    hrefs: list[str] = []
    seen: set[str] = set()
    for anchor in soup.find_all("a", href=True):
        href = anchor["href"].strip()
        if f"/{locale_slug}/clubs/" not in href:
            continue
        if href.startswith("/"):
            href = f"https://www.basic-fit.com{href}"
        if href in seen:
            continue
        seen.add(href)
        hrefs.append(href)
    return hrefs


def parse_basicfit_tiles(page_html: str, page_url: str, source_cfg: dict[str, str]) -> dict[str, dict[str, Any]]:
    soup = BeautifulSoup(page_html, "html.parser")
    fallback_by_url: dict[str, dict[str, Any]] = {}
    for tile in soup.select("li.js-store-tile.store-tile"):
        title_link = tile.select_one("a.store-tile-title[href]")
        if not title_link:
            continue
        detail_url = title_link["href"].strip()
        if detail_url.startswith("/"):
            detail_url = f"https://www.basic-fit.com{detail_url}"

        street_node = tile.select_one("span.store-tile-street")
        city_node = tile.select_one("span.store-tile-city")
        street = ascii_clean(street_node.get_text(" ", strip=True) if street_node else "")
        city = ascii_clean(city_node.get_text(" ", strip=True) if city_node else "")
        fallback_by_url[detail_url] = {
            "detail_url": detail_url,
            "fallback_name": ascii_clean(title_link.get_text(" ", strip=True)),
            "fallback_street": street.rstrip(","),
            "fallback_city": city,
            "fallback_postcode": "",
            "fallback_country_code": "",
            "fallback_country": source_cfg["fallback_country"],
            "fallback_iso3": source_cfg["fallback_iso3"],
            "list_source_url": page_url,
            "activity": source_cfg["activity"],
            "brand": source_cfg["brand"],
            "source_type": "COMPANY WEBSITE",
        }
    return fallback_by_url


def parse_xml_urls(xml_text: str) -> list[str]:
    ns = {"sm": "http://www.sitemaps.org/schemas/sitemap/0.9"}
    root = ET.fromstring(xml_text)
    return [elem.text.strip() for elem in root.findall(".//sm:loc", ns) if elem.text]


def schema_address_parts(address: dict[str, Any]) -> tuple[str, str, str, str, str]:
    return (
        ascii_clean(address.get("streetAddress")),
        ascii_clean(address.get("addressLocality")),
        ascii_clean(address.get("addressRegion")),
        ascii_clean(address.get("postalCode")),
        ascii_clean(address.get("addressCountry")),
    )


def extract_cleverfit_impressum_address(html: str, fallback_country: str = "", fallback_iso3: str = "") -> dict[str, str]:
    soup = BeautifulSoup(html, "html.parser")
    impressum = soup.select_one("#impressum")
    if not impressum:
        return {}
    lines = [ascii_clean(part) for part in impressum.stripped_strings if ascii_clean(part)]
    if len(lines) < 3:
        return {}
    street = ""
    postcode = ""
    city = ""
    state = ""
    country = fallback_country
    iso3 = fallback_iso3

    street_idx = None
    street_rx = re.compile(r"(str\.|strasse|strasse|strasze|strasse|street|weg|gasse|platz|allee|ring|road|laan|avenue)", re.I)
    postcode_rx = re.compile(r"^(?P<postcode>\d{4,6}[A-Z\- ]*)\s+(?P<city>.+)$")

    for idx, line in enumerate(lines):
        if street_rx.search(line):
            street = line
            street_idx = idx
            break

    if street_idx is not None:
        for candidate in lines[street_idx + 1 : street_idx + 4]:
            m = postcode_rx.match(candidate)
            if m:
                postcode = ascii_clean(m.group("postcode"))
                city = ascii_clean(m.group("city"))
                break
            if city and not country and candidate.isalpha():
                country = candidate
    if not city:
        for line in lines:
            m = postcode_rx.match(line)
            if m:
                postcode = ascii_clean(m.group("postcode"))
                city = ascii_clean(m.group("city"))
                break
    if not country:
        for line in lines:
            if line in {"Germany", "Deutschland", "Austria", "Oesterreich", "Schweiz", "Switzerland", "Romania", "Croatia", "Czech Republic"}:
                country = line
                break
    return {
        "street": street,
        "postcode": postcode,
        "city": city,
        "state": state,
        "country": country,
        "iso3": iso3,
    }


def build_row_from_schema(
    schema: dict[str, Any],
    detail_url: str,
    source_type: str,
    activity: str,
    brand: str,
    fallback: dict[str, Any] | None = None,
    html: str = "",
) -> dict[str, str]:
    fallback = fallback or {}
    address = schema.get("address") or {}
    geo = schema.get("geo") or {}

    street, city, state, postcode, country_code = schema_address_parts(address)
    if not street:
        street = fallback.get("fallback_street", "")
    if not city:
        city = fallback.get("fallback_city", "")
    if not postcode:
        postcode = fallback.get("fallback_postcode", "")
    if not country_code:
        country_code = fallback.get("fallback_country_code", "")

    country, iso3 = country_from_code(
        country_code,
        fallback.get("fallback_country", ""),
        fallback.get("fallback_iso3", ""),
    )
    if not street and html and "clever-fit.com" in detail_url:
        impressum_addr = extract_cleverfit_impressum_address(
            html,
            fallback.get("fallback_country", country),
            fallback.get("fallback_iso3", iso3),
        )
        street = impressum_addr.get("street", street)
        city = impressum_addr.get("city", city)
        state = impressum_addr.get("state", state)
        postcode = impressum_addr.get("postcode", postcode)
        country = impressum_addr.get("country", country)
        iso3 = impressum_addr.get("iso3", iso3)
    name = ascii_clean(schema.get("name")) or fallback.get("fallback_name", "")
    if not name and city:
        name = f"{brand} - {city}"
    if brand.lower() == "clever fit" and name and "clever fit" not in name.lower():
        name = f"clever fit {name}"

    lat = decimal_string(geo.get("latitude"))
    lon = decimal_string(geo.get("longitude"))

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": ascii_clean(name),
        "LOCATION_ADDRESS": clean_address(street, postcode, city, state, country),
        "LATITUDE": lat,
        "LONGITUDE": lon,
        "COUNTRY": country,
        "COUNTRY_ISO3": iso3,
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": detail_url,
        "SOURCE_TYPE": source_type,
        "ACTIVITY_AT_ASSET": activity,
        "coord_source": "website" if lat and lon else "Not from website",
        "QA_flag": "",
    }


@dataclass
class ExtractionStats:
    seeded_basicfit: int
    sitemap_urls: int
    processed_pages: int
    checkpoint_written: bool
    fallback_rows_used: int


async def fetch_text(client: httpx.AsyncClient, url: str) -> str:
    resp = await client.get(url, headers=HEADERS)
    resp.raise_for_status()
    return resp.text


async def fetch_basicfit_seeds(client: httpx.AsyncClient) -> list[dict[str, Any]]:
    seeds: list[dict[str, Any]] = []
    for source_cfg in ITEMLIST_SOURCES:
        html = await fetch_text(client, source_cfg["page_url"])
        locale_slug = source_cfg["page_url"].split("basic-fit.com/")[1].split("/")[0]
        itemlist = first_itemlist(extract_jsonld_blocks(html))
        if not itemlist:
            continue

        fallback_by_url: dict[str, dict[str, Any]] = {}
        for seed in build_basicfit_seed_rows(itemlist, source_cfg):
            fallback_by_url[seed["detail_url"]] = seed
        for detail_url, seed in parse_basicfit_tiles(html, source_cfg["page_url"], source_cfg).items():
            fallback_by_url[detail_url] = seed

        number_of_items = int(itemlist.get("numberOfItems", 0) or 0)
        page_size = max(12, len(extract_basicfit_detail_hrefs(html, locale_slug)) or 12)
        page_urls = [
            source_cfg["page_url"] if offset == 0 else f"{source_cfg['page_url']}?s={offset}&sz={page_size}"
            for offset in range(0, number_of_items, page_size)
        ]

        detail_urls: set[str] = set()
        for page_url in page_urls:
            page_html = html if page_url == source_cfg["page_url"] else await fetch_text(client, page_url)
            for detail_url in extract_basicfit_detail_hrefs(page_html, locale_slug):
                detail_urls.add(detail_url)
            for detail_url, seed in parse_basicfit_tiles(page_html, page_url, source_cfg).items():
                fallback_by_url[detail_url] = seed
            page_itemlist = first_itemlist(extract_jsonld_blocks(page_html))
            if page_itemlist:
                for seed in build_basicfit_seed_rows(page_itemlist, source_cfg):
                    fallback_by_url[seed["detail_url"]] = seed

        for detail_url in sorted(detail_urls):
            seed = fallback_by_url.get(
                detail_url,
                {
                    "detail_url": detail_url,
                    "fallback_name": "",
                    "fallback_street": "",
                    "fallback_city": "",
                    "fallback_postcode": "",
                    "fallback_country_code": "",
                    "fallback_country": source_cfg["fallback_country"],
                    "fallback_iso3": source_cfg["fallback_iso3"],
                    "list_source_url": source_cfg["page_url"],
                    "activity": source_cfg["activity"],
                    "brand": source_cfg["brand"],
                    "source_type": "COMPANY WEBSITE",
                },
            )
            seeds.append(seed)
    return seeds


async def fetch_cleverfit_seeds(client: httpx.AsyncClient) -> list[dict[str, Any]]:
    seeds: list[dict[str, Any]] = []
    for source_cfg in SITEMAP_SOURCES:
        xml_text = await fetch_text(client, source_cfg["sitemap_url"])
        for detail_url in parse_xml_urls(xml_text):
            locale_slug = detail_url.split("clever-fit.com/")[1].split("/")[0]
            fallback_country, fallback_iso3 = CLEVERFIT_LOCALE_MAP.get(locale_slug, ("", ""))
            seeds.append(
                {
                    "detail_url": detail_url,
                    "list_source_url": source_cfg["sitemap_url"],
                    "activity": source_cfg["activity"],
                    "brand": source_cfg["brand"],
                    "source_type": source_cfg["source_type"],
                    "fallback_country": fallback_country,
                    "fallback_iso3": fallback_iso3,
                }
            )
    return seeds


async def fetch_detail_row(
    client: httpx.AsyncClient,
    seed: dict[str, Any],
    semaphore: asyncio.Semaphore,
) -> tuple[dict[str, str] | None, bool]:
    async with semaphore:
        detail_url = seed["detail_url"]
        try:
            html = await fetch_text(client, detail_url)
            blocks = extract_jsonld_blocks(html)
            schema = first_matching_schema(
                blocks,
                {
                    "ExerciseGym",
                    "SportsActivityLocation",
                    "HealthClub",
                    "LocalBusiness",
                },
            )
            if not schema:
                return None, False
            return (
                build_row_from_schema(
                    schema=schema,
                    detail_url=detail_url,
                    source_type=seed["source_type"],
                    activity=seed["activity"],
                    brand=seed["brand"],
                    fallback=seed,
                    html=html,
                ),
                False,
            )
        except Exception:
            if seed.get("fallback_name") and seed.get("fallback_street"):
                fallback_country, fallback_iso3 = country_from_code(
                    seed.get("fallback_country_code", ""),
                    seed.get("fallback_country", ""),
                    seed.get("fallback_iso3", ""),
                )
                return (
                    {
                        "ISSUER_ID": ISSUER_ID,
                        "ISSUER_NAME": ISSUER_NAME,
                        "LOCATION_NAME": seed["fallback_name"],
                        "LOCATION_ADDRESS": clean_address(
                            seed.get("fallback_street", ""),
                            seed.get("fallback_postcode", ""),
                            seed.get("fallback_city", ""),
                            fallback_country,
                        ),
                        "LATITUDE": "",
                        "LONGITUDE": "",
                        "COUNTRY": fallback_country,
                        "COUNTRY_ISO3": fallback_iso3,
                        "POSTCODE": seed.get("fallback_postcode", ""),
                        "STATE": "",
                        "CITY": seed.get("fallback_city", ""),
                        "SOURCE_URL": seed["list_source_url"],
                        "SOURCE_TYPE": seed["source_type"],
                        "ACTIVITY_AT_ASSET": seed["activity"],
                        "coord_source": "Not from website",
                        "QA_flag": "fixed",
                    },
                    True,
                )
            return None, False


def row_identity(row: dict[str, str]) -> tuple[str, str, str]:
    return (
        row["SOURCE_URL"],
        row["LOCATION_NAME"],
        row["LOCATION_ADDRESS"],
    )


def validate_rows(rows: list[dict[str, str]]) -> tuple[list[dict[str, str]], list[dict[str, str]], dict[str, Any]]:
    valid_rows: list[dict[str, str]] = []
    rejected_rows: list[dict[str, str]] = []
    tier_a_fixed: list[dict[str, Any]] = []
    tier_b_flagged: list[dict[str, Any]] = []
    semantic_flags: list[dict[str, Any]] = []
    blank_counts = {
        "LOCATION_NAME": 0,
        "LOCATION_ADDRESS": 0,
        "COUNTRY": 0,
        "COUNTRY_ISO3": 0,
        "CITY": 0,
        "ACTIVITY_AT_ASSET": 0,
        "SOURCE_URL": 0,
        "coord_source_violations": 0,
    }

    mandatory_columns = [
        "LOCATION_NAME",
        "LOCATION_ADDRESS",
        "COUNTRY",
        "COUNTRY_ISO3",
        "CITY",
        "ACTIVITY_AT_ASSET",
        "SOURCE_URL",
        "SOURCE_TYPE",
        "coord_source",
    ]

    for idx, row in enumerate(rows, start=1):
        row["LOCATION_NAME"] = ascii_clean(row["LOCATION_NAME"])
        row["LOCATION_ADDRESS"] = clean_address(row["LOCATION_ADDRESS"])
        row["CITY"] = ascii_clean(row["CITY"])
        row["STATE"] = ascii_clean(row["STATE"])
        row["POSTCODE"] = ascii_clean(row["POSTCODE"])
        row["ACTIVITY_AT_ASSET"] = ascii_clean(row["ACTIVITY_AT_ASSET"]) or "Fitness club"
        row["QA_flag"] = row.get("QA_flag", "")

        if (
            not row["CITY"]
            and row["LOCATION_ADDRESS"]
            and "clever-fit.com" in row["SOURCE_URL"]
            and re.search(r"\d", row["LOCATION_ADDRESS"])
        ):
            derived_city = ascii_clean(
                re.sub(r"^clever fit\s+", "", row["LOCATION_NAME"], flags=re.I)
            )
            if derived_city:
                row["CITY"] = derived_city
                if row["COUNTRY"] and row["COUNTRY"] not in row["LOCATION_ADDRESS"]:
                    row["LOCATION_ADDRESS"] = clean_address(row["LOCATION_ADDRESS"], row["CITY"], row["COUNTRY"])
                elif row["CITY"] not in row["LOCATION_ADDRESS"]:
                    row["LOCATION_ADDRESS"] = clean_address(row["LOCATION_ADDRESS"], row["CITY"])
                row["QA_flag"] = "CITY"
                tier_b_flagged.append(
                    {
                        "row_index": idx,
                        "location_name": row["LOCATION_NAME"],
                        "qa_flag": "CITY",
                        "columns_needing_review": ["CITY"],
                        "original_value": "",
                        "attempted_fix": row["CITY"],
                        "uncertainty_reason": "Derived city from the official studio slug/name because the page exposed a street address but omitted the city field.",
                    }
                )

        if row["coord_source"] not in {"website", "Not from website"}:
            original = row["coord_source"]
            row["coord_source"] = "website" if row["LATITUDE"] and row["LONGITUDE"] else "Not from website"
            row["QA_flag"] = "fixed"
            tier_a_fixed.append(
                {
                    "row_index": idx,
                    "location_name": row["LOCATION_NAME"],
                    "column": "coord_source",
                    "original_value": original,
                    "fixed_value": row["coord_source"],
                    "fix_reason": "Normalized to the allowed enum based on website coordinates.",
                }
            )

        if row["CITY"] and (re.match(r"^\d", row["CITY"]) or len(row["CITY"]) > 60):
            row["QA_flag"] = "CITY_SUSPICIOUS"
            semantic_flags.append(
                {
                    "row_index": idx,
                    "location_name": row["LOCATION_NAME"],
                    "flag_code": "CITY_SUSPICIOUS",
                    "flagged_value": row["CITY"],
                    "column": "CITY",
                }
            )

        reject_reason = ""
        for col in mandatory_columns:
            if not row.get(col, "").strip():
                if col in blank_counts:
                    blank_counts[col] += 1
                reject_reason = f"mandatory field blank: {col}"
        if not row["coord_source"] in {"website", "Not from website"}:
            blank_counts["coord_source_violations"] += 1
            reject_reason = "invalid coord_source"

        if reject_reason:
            rejected = {key: row.get(key, "") for key in OUTPUT_COLUMNS}
            rejected["rejection_reason"] = reject_reason
            rejected["rejected_by"] = "worker_qa"
            rejected_rows.append(rejected)
            continue

        valid_rows.append({key: row.get(key, "") for key in OUTPUT_COLUMNS})

    total = len(valid_rows)
    if total < 5:
        inspected = total
    elif total <= 50:
        inspected = min(total, 5)
    else:
        inspected = math.ceil(total * 0.10)

    sample_indices = []
    if inspected and total:
        step = max(1, total // inspected)
        sample_indices = list(range(0, total, step))[:inspected]

    qa_summary = {
        "rows_total": total,
        "rows_inspected": inspected,
        "inspection_pct": round((inspected / total) * 100, 2) if total else 0,
        "full_page_scraper": False,
        "tier_a_fixed": tier_a_fixed,
        "tier_b_flagged": tier_b_flagged,
        "tier_c_rejected": [
            {
                "row_index": idx + 1,
                "raw_content": rejected_rows[idx]["LOCATION_ADDRESS"][:200],
                "rejection_reason": rejected_rows[idx]["rejection_reason"],
            }
            for idx in range(len(rejected_rows))
        ],
        "semantic_flags": semantic_flags,
        "blank_mandatory_counts": blank_counts,
        "sample_indices": sample_indices,
        "clean_count": sum(1 for row in valid_rows if row["QA_flag"] == ""),
        "tier_b_count": len(tier_b_flagged),
        "tier_c_count": len(rejected_rows),
    }
    return valid_rows, rejected_rows, qa_summary


def write_csv(path: Path, rows: list[dict[str, str]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def checkpoint_rows(path: Path, rows: list[dict[str, str]]) -> None:
    write_csv(path, rows, OUTPUT_COLUMNS)


async def run() -> None:
    ISSUER_TEMP_DIR.mkdir(parents=True, exist_ok=True)
    timeout = httpx.Timeout(20.0, connect=10.0)
    limits = httpx.Limits(max_connections=20, max_keepalive_connections=20)
    processed_pages = 0
    fallback_rows_used = 0
    checkpoint_written = False

    async with httpx.AsyncClient(timeout=timeout, limits=limits, follow_redirects=True) as client:
        basicfit_seeds = await fetch_basicfit_seeds(client)
        cleverfit_seeds = await fetch_cleverfit_seeds(client)
        all_seeds = basicfit_seeds + cleverfit_seeds

        deduped_seeds: list[dict[str, Any]] = []
        seen_detail_urls: set[str] = set()
        for seed in all_seeds:
            if seed["detail_url"] in seen_detail_urls:
                continue
            seen_detail_urls.add(seed["detail_url"])
            deduped_seeds.append(seed)

        rows: list[dict[str, str]] = []
        seen_rows: set[tuple[str, str, str]] = set()
        semaphore = asyncio.Semaphore(20)

        for start in range(0, len(deduped_seeds), 20):
            batch = deduped_seeds[start : start + 20]
            results = await asyncio.gather(
                *(fetch_detail_row(client, seed, semaphore) for seed in batch)
            )
            for row, used_fallback in results:
                processed_pages += 1
                if not row:
                    continue
                if used_fallback:
                    fallback_rows_used += 1
                key = row_identity(row)
                if key in seen_rows:
                    continue
                seen_rows.add(key)
                rows.append(row)

            PROGRESS_JSON.write_text(
                json.dumps(
                    {
                        "issuer_id": ISSUER_ID,
                        "processed_pages": processed_pages,
                        "rows_collected": len(rows),
                        "target": COUNT_TARGET,
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )

            if len(rows) >= COUNT_TARGET and not checkpoint_written:
                checkpoint_rows(CHECKPOINT_CSV, rows)
                checkpoint_written = True

        valid_rows, rejected_rows, qa_summary = validate_rows(rows)
        write_csv(STAGING_CSV, valid_rows, OUTPUT_COLUMNS)
        if rejected_rows:
            write_csv(
                REJECT_CSV,
                rejected_rows,
                OUTPUT_COLUMNS + ["rejection_reason", "rejected_by"],
            )

        QA_JSON.write_text(
            json.dumps(
                {
                    "issuer_id": ISSUER_ID,
                    "issuer_name": ISSUER_NAME,
                    **qa_summary,
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        EXTRACTION_JSON.write_text(
            json.dumps(
                {
                    "issuer_id": ISSUER_ID,
                    "issuer_name": ISSUER_NAME,
                    "seeded_basicfit": len(basicfit_seeds),
                    "seeded_cleverfit": len(cleverfit_seeds),
                    "processed_pages": processed_pages,
                    "rows_before_validation": len(rows),
                    "rows_after_validation": len(valid_rows),
                    "rejected_rows": len(rejected_rows),
                    "checkpoint_written": checkpoint_written,
                    "fallback_rows_used": fallback_rows_used,
                    "target": COUNT_TARGET,
                },
                indent=2,
            ),
            encoding="utf-8",
        )


if __name__ == "__main__":
    asyncio.run(run())
