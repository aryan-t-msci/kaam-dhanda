"""
ASP.NET WebForms POST-to-Self Branch Locator Extractor
=======================================================
Handles branch locator pages built on ASP.NET WebForms where the page
issues `$.post(location.pathname)` to retrieve branch data as JSON.

Pattern detection:
  - Page has Mustache/Handlebars templates ({{EDept}}, {{Address}}, {{Tel}})
  - JS file contains `$.post(location.pathname).done(function(e){...})`
  - Response is JSON with "Branches" array and "Zips" region map

Demonstrated on:
  - E.SUN Securities (esunsec.com.tw/service/locations.aspx)

To adapt for another site:
  1. Update the CONFIGURATION block below
  2. Adjust INCLUDE_TYPES if the "Type" field values differ
  3. Adjust the name/address transliteration in build_facility_name() and parse_address()
     if the site is not Taiwan-based

Usage:
  python aspnet_post_json_locator_extractor.py
"""

import csv
import httpx
import json
import os
import re
import sys

sys.stdout.reconfigure(encoding='utf-8')

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_ID        = "IID000000002164615"
ISSUER_NAME      = "E.SUN FINANCIAL HOLDING COMPANY,LTD."
LOCATOR_URL      = "https://www.esunsec.com.tw/service/locations.aspx"
VERIFY_SSL       = False          # Self-signed cert on esunsec.com.tw
INCLUDE_TYPES    = ["Branch"]     # "Branch" = Securities own offices; "Service" = Bank counters
BUSINESS_ACTIVITY = "Securities Trading; Brokerage"
FACILITY_REGION  = "Asia"
RELEVANT_URL     = "https://www.esunsec.com.tw/service/locations.aspx"

OUTPUT_DIR = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Gap Output"
OUTPUT_FILENAME = f"{ISSUER_ID}_{ISSUER_NAME}_Gap.csv"
EXISTING_CSV = os.path.join(OUTPUT_DIR, OUTPUT_FILENAME)

# ═══════════════════════════════════════════════════════════
# TAIWAN CITY CJK → ENGLISH NAME MAPPING
# ═══════════════════════════════════════════════════════════
TW_CITY_EN = {
    "\u57fa\u9686\u5e02": "Keelung",
    "\u81fa\u5317\u5e02": "Taipei", "\u53f0\u5317\u5e02": "Taipei",
    "\u65b0\u5317\u5e02": "New Taipei",
    "\u6843\u5712\u5e02": "Taoyuan",
    "\u65b0\u7af9\u5e02": "Hsinchu", "\u65b0\u7af9\u7e23": "Hsinchu",
    "\u82d7\u6817\u7e23": "Miaoli",
    "\u81fa\u4e2d\u5e02": "Taichung", "\u53f0\u4e2d\u5e02": "Taichung",
    "\u5f70\u5316\u7e23": "Changhua",
    "\u5357\u6295\u7e23": "Nantou",
    "\u96f2\u6797\u7e23": "Yunlin",
    "\u5609\u7fa9\u5e02": "Chiayi", "\u5609\u7fa9\u7e23": "Chiayi",
    "\u81fa\u5357\u5e02": "Tainan", "\u53f0\u5357\u5e02": "Tainan",
    "\u9ad8\u96c4\u5e02": "Kaohsiung",
    "\u5c4f\u6771\u7e23": "Pingtung",
    "\u5b9c\u862d\u7e23": "Yilan",
    "\u82b1\u84ee\u7e23": "Hualien",
    "\u81fa\u6771\u7e23": "Taitung", "\u53f0\u6771\u7e23": "Taitung",
    "\u6f4e\u6e56\u7e23": "Penghu",
}

# ═══════════════════════════════════════════════════════════
# TAIWAN ZIP → CITY/STATE MAPPING
# Derived from Taiwan postal code system (3-digit prefecture codes)
# ═══════════════════════════════════════════════════════════
TW_ZIP_PREFIX_TO_CITY = {
    "100": ("Taipei", "Taipei"),
    "103": ("Taipei", "Taipei"),
    "104": ("Taipei", "Taipei"),
    "105": ("Taipei", "Taipei"),
    "106": ("Taipei", "Taipei"),
    "108": ("Taipei", "Taipei"),
    "110": ("Taipei", "Taipei"),
    "111": ("Taipei", "Taipei"),
    "112": ("Taipei", "Taipei"),
    "114": ("Taipei", "Taipei"),
    "115": ("Taipei", "Taipei"),
    "116": ("Taipei", "Taipei"),
    "220": ("New Taipei City", "New Taipei City"),
    "221": ("New Taipei City", "New Taipei City"),
    "222": ("New Taipei City", "New Taipei City"),
    "223": ("New Taipei City", "New Taipei City"),
    "224": ("New Taipei City", "New Taipei City"),
    "226": ("New Taipei City", "New Taipei City"),
    "227": ("New Taipei City", "New Taipei City"),
    "228": ("New Taipei City", "New Taipei City"),
    "231": ("New Taipei City", "New Taipei City"),
    "234": ("New Taipei City", "New Taipei City"),
    "235": ("New Taipei City", "New Taipei City"),
    "236": ("New Taipei City", "New Taipei City"),
    "237": ("New Taipei City", "New Taipei City"),
    "238": ("New Taipei City", "New Taipei City"),
    "239": ("New Taipei City", "New Taipei City"),
    "241": ("New Taipei City", "New Taipei City"),
    "242": ("New Taipei City", "New Taipei City"),
    "243": ("New Taipei City", "New Taipei City"),
    "244": ("New Taipei City", "New Taipei City"),
    "247": ("New Taipei City", "New Taipei City"),
    "248": ("New Taipei City", "New Taipei City"),
    "249": ("New Taipei City", "New Taipei City"),
    "251": ("New Taipei City", "New Taipei City"),
    "252": ("New Taipei City", "New Taipei City"),
    "253": ("New Taipei City", "New Taipei City"),
    "257": ("New Taipei City", "New Taipei City"),
    "259": ("New Taipei City", "New Taipei City"),
    "260": ("Yilan County", "Yilan County"),
    "270": ("Yilan County", "Yilan County"),
    "300": ("Hsinchu City", "Hsinchu City"),
    "302": ("Hsinchu County", "Hsinchu County"),
    "303": ("Hsinchu County", "Hsinchu County"),
    "304": ("Hsinchu County", "Hsinchu County"),
    "305": ("Hsinchu County", "Hsinchu County"),
    "306": ("Hsinchu County", "Hsinchu County"),
    "307": ("Hsinchu County", "Hsinchu County"),
    "308": ("Hsinchu County", "Hsinchu County"),
    "310": ("Hsinchu County", "Hsinchu County"),
    "320": ("Taoyuan City", "Taoyuan City"),
    "324": ("Taoyuan City", "Taoyuan City"),
    "325": ("Taoyuan City", "Taoyuan City"),
    "326": ("Taoyuan City", "Taoyuan City"),
    "327": ("Taoyuan City", "Taoyuan City"),
    "328": ("Taoyuan City", "Taoyuan City"),
    "330": ("Taoyuan City", "Taoyuan City"),
    "333": ("Taoyuan City", "Taoyuan City"),
    "334": ("Taoyuan City", "Taoyuan City"),
    "335": ("Taoyuan City", "Taoyuan City"),
    "336": ("Taoyuan City", "Taoyuan City"),
    "337": ("Taoyuan City", "Taoyuan City"),
    "338": ("Taoyuan City", "Taoyuan City"),
    "350": ("Miaoli County", "Miaoli County"),
    "360": ("Miaoli County", "Miaoli County"),
    "400": ("Taichung City", "Taichung City"),
    "401": ("Taichung City", "Taichung City"),
    "402": ("Taichung City", "Taichung City"),
    "403": ("Taichung City", "Taichung City"),
    "404": ("Taichung City", "Taichung City"),
    "406": ("Taichung City", "Taichung City"),
    "407": ("Taichung City", "Taichung City"),
    "408": ("Taichung City", "Taichung City"),
    "411": ("Taichung City", "Taichung City"),
    "412": ("Taichung City", "Taichung City"),
    "413": ("Taichung City", "Taichung City"),
    "414": ("Taichung City", "Taichung City"),
    "420": ("Taichung City", "Taichung City"),
    "500": ("Changhua County", "Changhua County"),
    "510": ("Changhua County", "Changhua County"),
    "520": ("Changhua County", "Changhua County"),
    "540": ("Nantou County", "Nantou County"),
    "600": ("Chiayi City", "Chiayi City"),
    "602": ("Chiayi County", "Chiayi County"),
    "610": ("Chiayi County", "Chiayi County"),
    "621": ("Chiayi County", "Chiayi County"),
    "630": ("Yunlin County", "Yunlin County"),
    "640": ("Yunlin County", "Yunlin County"),
    "700": ("Tainan City", "Tainan City"),
    "701": ("Tainan City", "Tainan City"),
    "702": ("Tainan City", "Tainan City"),
    "704": ("Tainan City", "Tainan City"),
    "708": ("Tainan City", "Tainan City"),
    "710": ("Tainan City", "Tainan City"),
    "800": ("Kaohsiung City", "Kaohsiung City"),
    "801": ("Kaohsiung City", "Kaohsiung City"),
    "802": ("Kaohsiung City", "Kaohsiung City"),
    "803": ("Kaohsiung City", "Kaohsiung City"),
    "804": ("Kaohsiung City", "Kaohsiung City"),
    "805": ("Kaohsiung City", "Kaohsiung City"),
    "806": ("Kaohsiung City", "Kaohsiung City"),
    "807": ("Kaohsiung City", "Kaohsiung City"),
    "811": ("Kaohsiung City", "Kaohsiung City"),
    "812": ("Kaohsiung City", "Kaohsiung City"),
    "813": ("Kaohsiung City", "Kaohsiung City"),
    "814": ("Kaohsiung City", "Kaohsiung City"),
    "815": ("Kaohsiung City", "Kaohsiung City"),
    "817": ("Kaohsiung City", "Kaohsiung City"),
    "819": ("Kaohsiung City", "Kaohsiung City"),
    "820": ("Kaohsiung City", "Kaohsiung City"),
    "830": ("Kaohsiung City", "Kaohsiung City"),
    "840": ("Kaohsiung City", "Kaohsiung City"),
    "900": ("Pingtung County", "Pingtung County"),
    "920": ("Pingtung County", "Pingtung County"),
    "940": ("Pingtung County", "Pingtung County"),
}

# Taiwan CJK city/district → English name mapping
TW_CJK_MAP = {
    # Cities
    "\u53f0\u5317\u5e02": "Taipei City",
    "\u65b0\u5317\u5e02": "New Taipei City",
    "\u6843\u5712\u5e02": "Taoyuan City",
    "\u65b0\u7af9\u5e02": "Hsinchu City",
    "\u65b0\u7af9\u7e23": "Hsinchu County",
    "\u82d7\u6817\u7e23": "Miaoli County",
    "\u81fa\u4e2d\u5e02": "Taichung City",
    "\u5f70\u5316\u7e23": "Changhua County",
    "\u5357\u6295\u7e23": "Nantou County",
    "\u96f2\u6797\u7e23": "Yunlin County",
    "\u5609\u7fa9\u5e02": "Chiayi City",
    "\u5609\u7fa9\u7e23": "Chiayi County",
    "\u81fa\u5357\u5e02": "Tainan City",
    "\u9ad8\u96c4\u5e02": "Kaohsiung City",
    "\u5c4f\u6771\u7e23": "Pingtung County",
    "\u5b9c\u862d\u7e23": "Yilan County",
    "\u82b1\u84ee\u7e23": "Hualien County",
    "\u53f0\u6771\u7e23": "Taitung County",
    "\u57fa\u96c6\u5e02": "Keelung City",
    # Districts (common)
    "\u677e\u5c71\u5340": "Songshan District",
    "\u4fe1\u7fa9\u5340": "Xinyi District",
    "\u58eb\u6797\u5340": "Shilin District",
    "\u5167\u6e56\u5340": "Neihu District",
    "\u6587\u5c71\u5340": "Wenshan District",
    "\u4e2d\u6b63\u5340": "Zhongzheng District",
    "\u6c38\u548c\u5340": "Yonghe District",
    "\u65b0\u838a\u5340": "Xinzhuang District",
    "\u677f\u6a4b\u5340": "Banqiao District",
    "\u4e09\u91cd\u5340": "Sanchong District",
    "\u82d7\u6817\u5340": "Miaoli District",
    "\u897f\u5c6f\u5340": "Xitun District",
    "\u5927\u91cc\u5340": "Dali District",
    "\u8292\u96c5\u5340": "Lingya District",
    "\u5de6\u71df\u5340": "Zuoying District",
    "\u6771\u5340": "East District",
    "\u897f\u5340": "West District",
    "\u6c38\u5eb7\u5340": "Yongkang District",
    "\u5b89\u5e73\u5340": "Anping District",
    "\u4e2d\u6b63\u8def": "Zhongzheng Road",
    "\u6c11\u751f\u6771\u8def": "Minsheng E. Road",
}

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC
# ═══════════════════════════════════════════════════════════

COLUMNS = [
    "ISSUER_ID", "ISSUER_NAME", "FACILITY_NAME", "FACILITY_ADDRESS",
    "CITY", "STATE", "POSTAL_CODE", "FACILITY_REGION", "LATITUDE", "LONGITUDE",
    "FACILITY_CONTACT_NUMBER", "RELEVANT_URL", "BUSINESS_ACTIVITY"
]

# Request headers for POST
REQUEST_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Accept-Language": "zh-TW,zh;q=0.9,en-US;q=0.8",
    "Content-Type": "application/x-www-form-urlencoded",
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "X-Requested-With": "XMLHttpRequest",
}


def fetch_branch_data(url: str, verify_ssl: bool = True) -> dict:
    """POST to the ASP.NET WebForms locator URL and return parsed JSON."""
    r = httpx.post(url, headers=REQUEST_HEADERS, timeout=20,
                   follow_redirects=True, verify=verify_ssl, data={})
    r.raise_for_status()
    return json.loads(r.text)


def strip_cjk(text: str) -> str:
    """Remove CJK characters from text, collapse whitespace."""
    result = re.sub(r"[\u4e00-\u9fff\u3400-\u4dbf\u3000-\u303f\uff00-\uffef]+", " ", text)
    result = re.sub(r"\s+", " ", result).strip()
    # Remove empty parentheses left after stripping
    result = re.sub(r"\(\s*\)", "", result).strip()
    return result


def transliterate_name(cjk_name: str) -> str:
    """
    Transliterate a CJK branch name to English.
    Strips the branch code prefix (e.g. '8841 ') and converts
    known E.SUN Securities name patterns to English.
    """
    # Remove numeric/alphanumeric branch code prefix (e.g. '8841 ', '884A ')
    name = re.sub(r"^[0-9A-Za-z]{4}\s+", "", cjk_name).strip()

    # Known E.SUN Securities CJK → English branch name map
    name_map = {
        "\u7389\u5c71\u8b49\u5238\u7d93\u7d00\u672c\u90e8": "E.SUN Securities Brokerage HQ",
        "\u7389\u5c71\u8b49\u5238\u96d9\u548c\u5206\u516c\u53f8": "E.SUN Securities Shuanghe Branch",
        "\u7389\u5c71\u8b49\u5238\u65b0\u838a\u5206\u516c\u53f8": "E.SUN Securities Xinzhuang Branch",
        "\u7389\u5c71\u8b49\u5238\u9ad8\u96c4\u5206\u516c\u53f8": "E.SUN Securities Kaohsiung Branch",
        "\u7389\u5c71\u8b49\u5238\u677f\u6a4b\u5206\u516c\u53f8": "E.SUN Securities Banqiao Branch",
        "\u7389\u5c71\u8b49\u5238\u53f0\u5357\u5206\u516c\u53f8": "E.SUN Securities Tainan Branch",
        "\u7389\u5c71\u8b49\u5238\u5609\u7fa9\u5206\u516c\u53f8": "E.SUN Securities Chiayi Branch",
        "\u7389\u5c71\u8b49\u5238\u666f\u7f8e\u5206\u516c\u53f8": "E.SUN Securities Jingmei Branch",
        "\u7389\u5c71\u8b49\u5238\u58eb\u6797\u5206\u516c\u53f8": "E.SUN Securities Shilin Branch",
        "\u7389\u5c71\u8b49\u5238\u53f0\u4e2d\u5206\u516c\u53f8": "E.SUN Securities Taichung Branch",
        "\u7389\u5c71\u8b49\u5238\u4fe1\u7fa9\u5206\u516c\u53f8": "E.SUN Securities Xinyi Branch",
        "\u7389\u5c71\u8b49\u5238\u5de6\u71df\u5206\u516c\u53f8": "E.SUN Securities Zuoying Branch",
        "\u7389\u5c71\u8b49\u5238\u57ce\u4e2d\u5206\u516c\u53f8": "E.SUN Securities Chengzhong Branch",
        "\u7389\u5c71\u8b49\u5238\u6843\u5712\u5206\u516c\u53f8": "E.SUN Securities Taoyuan Branch",
        "\u7389\u5c71\u8b49\u5238\u65b0\u7af9\u5206\u516c\u53f8": "E.SUN Securities Hsinchu Branch",
        "\u7389\u5c71\u8b49\u5238\u5927\u91cc\u5206\u516c\u53f8": "E.SUN Securities Dali Branch",
        "\u7389\u5c71\u8b49\u5238OSU": "E.SUN Securities Offshore Securities Unit (OSU)",
        "\u7389\u5c71\u8b49\u5238\u6578\u4f4d\u5206\u516c\u53f8": "E.SUN Securities Digital Branch",
    }

    for zh, en in name_map.items():
        if zh in name:
            return en

    # Fallback: strip CJK and clean up
    stripped = strip_cjk(name)
    return stripped if stripped else name


def parse_taiwan_address(address_zh: str, zip_code: str) -> dict:
    """
    Parse a Taiwan CJK address string into English components.
    Handles standard TW format: 縣市 [district] 路/街 [段] [號] [樓[之n]]
    Returns dict with: address_en, city, state, postal_code
    """
    postal = zip_code.strip() if zip_code else ""
    addr = address_zh.strip()

    # ── City ──────────────────────────────────────────────
    city_en = ""
    for zh, en in TW_CITY_EN.items():
        if addr.startswith(zh):
            city_en = en
            addr = addr[len(zh):]
            break

    # ── District ──────────────────────────────────────────
    district_zh = ""
    dist_m = re.match(r"^([\u4e00-\u9fff]+(?:區|鎮|鄉))", addr)
    if dist_m:
        district_zh = dist_m.group(1)
        addr = addr[len(district_zh):]

    # ── Floor (樓 / 樓之N / multi-floor 3、4樓) ──────────
    floor_en = ""
    # Multi-floor "3、4樓" — take the first floor number
    multi_m = re.search(r"(\d+)[、,]\d+樓", addr)
    if multi_m:
        floor_en = f"{multi_m.group(1)}F"
        addr = addr[:multi_m.start()] + addr[multi_m.end():]
    else:
        fl_m = re.search(r"(\d+)樓(?:之(\d+))?", addr)
        if fl_m:
            fl = fl_m.group(1)
            fl_sub = fl_m.group(2)
            floor_en = f"{fl}F" + (f"-{fl_sub}" if fl_sub else "")
            addr = addr[:fl_m.start()] + addr[fl_m.end():]

    # ── House number (號) ─────────────────────────────────
    num_en = ""
    num_m = re.search(r"(\d+(?:之\d+)?)號", addr)
    if num_m:
        num = num_m.group(1).replace("之", "-")
        num_en = f"No.{num}"
        addr = addr[:num_m.start()] + addr[num_m.end():]

    # ── Lane (巷) ─────────────────────────────────────────
    lane_en = ""
    lane_m = re.search(r"(\d+)巷", addr)
    if lane_m:
        lane_en = f"Lane {lane_m.group(1)}"
        addr = addr[:lane_m.start()] + addr[lane_m.end():]

    # ── Section (段) ──────────────────────────────────────
    sect_en = ""
    SECT_MAP = {"一": "1", "二": "2", "三": "3", "四": "4", "五": "5", "六": "6"}
    sect_m = re.search(r"([一二三四五六\d]+)段", addr)
    if sect_m:
        sc = sect_m.group(1)
        sc_num = SECT_MAP.get(sc, sc)
        sect_en = f"Sec. {sc_num}"
        addr = addr[:sect_m.start()] + addr[sect_m.end():]

    # ── Road name + type ──────────────────────────────────
    ROAD_TYPE = {"路": "Road", "街": "Street", "大道": "Boulevard", "巷": "Lane", "弄": "Alley"}
    ROAD_NAME_MAP = {
        "民生東": "Minsheng E.", "民生": "Minsheng",
        "保生": "Baosheng", "思源": "Siyuan",
        "四維四": "Siwei 4th", "四維": "Siwei",
        "中山": "Zhongshan", "崇學": "Chongxue",
        "信光": "Xinguang", "光復": "Guangfu",
        "國光": "Guoguang", "市政": "Shizheng",
        "景中": "Jingzhong", "中正": "Zhongzheng",
        "明誠二": "Mingcheng 2nd", "明誠": "Mingcheng",
        "武昌": "Wuchang", "基隆": "Keelung",
    }

    road_zh = addr.strip()
    road_type_en = ""
    for zh_suf, en_suf in ROAD_TYPE.items():
        if road_zh.endswith(zh_suf):
            road_type_en = en_suf
            road_zh = road_zh[:-len(zh_suf)]
            break

    road_name_en = road_zh
    for zh_name, en_name in ROAD_NAME_MAP.items():
        road_name_en = road_name_en.replace(zh_name, en_name)
    road_name_en = re.sub(r"[\u4e00-\u9fff]+", "", road_name_en).strip()
    full_road = f"{road_name_en} {road_type_en}".strip()

    # ── District English ───────────────────────────────────
    dist_en = ""
    if district_zh:
        DIST_NAME_MAP = {
            "松山": "Songshan", "信義": "Xinyi", "士林": "Shilin",
            "內湖": "Neihu", "文山": "Wenshan", "中正": "Zhongzheng",
            "永和": "Yonghe", "新莊": "Xinzhuang", "板橋": "Banqiao",
            "三重": "Sanchong", "西屯": "Xitun", "大里": "Dali",
            "苓雅": "Lingya", "左營": "Zuoying", "東": "East",
            "西": "West", "桃園": "Taoyuan", "東": "East",
        }
        dist_name = district_zh
        for zh_n, en_n in DIST_NAME_MAP.items():
            dist_name = dist_name.replace(zh_n, en_n)
        dist_name = re.sub(r"區$", " District", dist_name)
        dist_name = re.sub(r"鎮$", " Township", dist_name)
        dist_name = re.sub(r"[\u4e00-\u9fff]+", "", dist_name).strip()
        dist_en = dist_name

    # ── Assemble English address ───────────────────────────
    parts = []
    if floor_en:
        parts.append(floor_en)
    if num_en:
        parts.append(num_en)
    if lane_en:
        parts.append(lane_en)
    if sect_en:
        parts.append(sect_en)
    if full_road:
        parts.append(full_road)
    if dist_en:
        parts.append(dist_en)
    if city_en:
        parts.append(city_en)

    address_en = ", ".join(p for p in parts if p)

    # Fall back to zip-based city if city_en is empty
    city_out = city_en
    if not city_out:
        zip_prefix = postal[:3] if postal else ""
        if zip_prefix in TW_ZIP_PREFIX_TO_CITY:
            city_out, _ = TW_ZIP_PREFIX_TO_CITY[zip_prefix]

    return {
        "address_en": address_en,
        "city": city_out,
        "state": city_out,
        "postal_code": postal,
    }


def load_existing_csv(path: str) -> list:
    """Load existing CSV records."""
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        return list(reader)


def save_csv(path: str, rows: list):
    """Save records to CSV with UTF-8-BOM encoding."""
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


def main():
    print("=" * 60)
    print("E.SUN Securities Branch Extractor")
    print(f"Source: {LOCATOR_URL}")
    print("=" * 60)

    # 1. Fetch data
    print("\n[1] Fetching branch data...")
    data = fetch_branch_data(LOCATOR_URL, verify_ssl=VERIFY_SSL)
    all_branches = data.get("Branches", [])
    print(f"    Total records from API: {len(all_branches)}")

    # 2. Filter to target types
    target_branches = [b for b in all_branches if b.get("Type") in INCLUDE_TYPES]
    print(f"    After filtering (Type in {INCLUDE_TYPES}): {len(target_branches)} records")

    # 3. Build output rows
    print("\n[2] Building output rows...")
    new_rows = []
    for b in target_branches:
        raw_name   = b.get("EDept", "")
        raw_addr   = b.get("Address", "")
        zip_code   = str(b.get("Zip", ""))
        lat        = str(b.get("Lat", ""))
        lng        = str(b.get("Lng", ""))
        tel        = b.get("Tel", "")

        facility_name = transliterate_name(raw_name)
        parsed = parse_taiwan_address(raw_addr, zip_code)

        row = {
            "ISSUER_ID":               ISSUER_ID,
            "ISSUER_NAME":             ISSUER_NAME,
            "FACILITY_NAME":           facility_name,
            "FACILITY_ADDRESS":        parsed["address_en"],
            "CITY":                    parsed["city"],
            "STATE":                   parsed["state"],
            "POSTAL_CODE":             parsed["postal_code"],
            "FACILITY_REGION":         FACILITY_REGION,
            "LATITUDE":                lat,
            "LONGITUDE":               lng,
            "FACILITY_CONTACT_NUMBER": tel,
            "RELEVANT_URL":            RELEVANT_URL,
            "BUSINESS_ACTIVITY":       BUSINESS_ACTIVITY,
        }
        new_rows.append(row)
        print(f"    {facility_name}")
        print(f"      Addr: {parsed['address_en']}")
        print(f"      City: {parsed['city']} | State: {parsed['state']} | Zip: {parsed['postal_code']}")
        print(f"      Lat: {lat} | Lng: {lng}")
        print()

    # 4. Append to existing CSV
    print(f"\n[3] Appending {len(new_rows)} records to existing gap CSV...")
    existing = load_existing_csv(EXISTING_CSV)
    print(f"    Existing records: {len(existing)}")
    combined = existing + new_rows
    save_csv(EXISTING_CSV, combined)
    print(f"    Total after append: {len(combined)} records")
    print(f"    Saved to: {EXISTING_CSV}")

    print("\n[DONE]")
    print(f"  New records added: {len(new_rows)}")
    print(f"  Total records:     {len(combined)}")


if __name__ == "__main__":
    main()
