"""
WP Google Map Gold embedded-payload extractor.

This script handles WordPress pages that render a WP Google Map Gold map where
the marker dataset is embedded in the HTML as a base64-encoded
`window.wpgmp.mapdataN` payload rather than exposed through the public REST API.

Configure the issuer block for the relevant map pages and output paths, then run:

    python wp_google_map_gold_embedded_extractor.py

The script:
1. Downloads each configured map page.
2. Decodes the embedded map payload.
3. Normalizes marker records to the standing extraction schema.
4. Resolves same-website duplicate aliases conservatively.
5. Writes the staging CSV plus a JSON summary for downstream batch reporting.
"""

from __future__ import annotations

import base64
import csv
import html
import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse


# =============================================================================
# CONFIGURATION - Edit this block for each new issuer
# =============================================================================
ISSUER_ID = "IID000000002140731"
ISSUER_NAME = "THE ENSIGN GROUP, INC."
TARGET_COUNT = 1786

MAP_PAGES = [
    {
        "page_url": "https://ensignservices.net/map/",
        "source_label": "Ensign Services affiliated locations map",
    }
]

REFERENCE_MAP_PAGE = "https://ensigngroup.net/map/"

SUPPLEMENTAL_ROWS = [
    {
        "LOCATION_NAME": "The Ensign Group, Inc. Corporate Office",
        "LOCATION_ADDRESS": "29222 Rancho Viejo Rd, Ste 127, San Juan Capistrano, California 92675, United States",
        "LATITUDE": "",
        "LONGITUDE": "",
        "COUNTRY": "United States",
        "COUNTRY_ISO3": "USA",
        "POSTCODE": "92675",
        "STATE": "California",
        "CITY": "San Juan Capistrano",
        "SOURCE_URL": "https://ensigngroup.net/company-info/",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Corporate headquarters and service center",
        "coord_source": "Not from website",
        "QA_flag": "",
    }
]

ISSUER_WORK_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp"
    r"\Run_asset_completeness_ondemand_batch7_8___straive_copy"
    r"\IID000000002140731_THE ENSIGN GROUP, INC"
)
STAGING_CSV = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp"
    r"\Run_asset_completeness_ondemand_batch7_8___straive_copy\staging"
    r"\IID000000002140731_THE ENSIGN GROUP, INC.csv"
)
SUMMARY_JSON = ISSUER_WORK_DIR / "map_extraction_summary.json"


# =============================================================================
# GENERIC EXTRACTION LOGIC - Do not modify per issuer
# =============================================================================
CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
]

US_STATE_ABBREVIATIONS = {
    "AK": "Alaska",
    "AL": "Alabama",
    "AZ": "Arizona",
    "CA": "California",
    "CO": "Colorado",
    "IA": "Iowa",
    "ID": "Idaho",
    "KS": "Kansas",
    "NE": "Nebraska",
    "NV": "Nevada",
    "OR": "Oregon",
    "SC": "South Carolina",
    "TN": "Tennessee",
    "TX": "Texas",
    "UT": "Utah",
    "WA": "Washington",
    "WI": "Wisconsin",
}


@dataclass
class RawPlace:
    title: str
    address: str
    city: str
    state_raw: str
    postcode: str
    country_raw: str
    latitude: str
    longitude: str
    page_url: str
    website_url: str
    phone: str
    fax: str
    categories: list[str]
    raw_id: str


def build_session() -> requests.Session:
    session = requests.Session()
    session.headers.update({"User-Agent": "Mozilla/5.0 (Codex wp-google-map-gold extractor)"})
    return session


SESSION = build_session()


def clean_text(value: Any) -> str:
    text = html.unescape(str(value or ""))
    text = BeautifulSoup(text, "html.parser").get_text(" ", strip=True)
    return re.sub(r"\s+", " ", text.replace("\xa0", " ")).strip()


def normalize_key(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()


def extract_website(value: str) -> str:
    value = clean_text(value)
    if not value:
        return ""
    match = re.search(r"https?://[^\s<>\"']+", value)
    return match.group(0).rstrip("/") if match else value.rstrip("/")


def sanitize_street_address(address: str) -> str:
    address = clean_text(address)
    if not address:
        return address
    address = re.sub(r",?\s+Suite\s+#(\w+)", r", Suite \1", address, flags=re.I)
    address = re.sub(r"(?<!Suite )#(\w+)", r"Suite \1", address)
    address = re.sub(r"\s+,", ",", address)
    address = re.sub(r"\s{2,}", " ", address)
    return address.strip(" ,")


def normalize_address_key(address: str) -> str:
    address = sanitize_street_address(address)
    lowered = address.lower()
    replacements = [
        (r"\bbelt\s+line\b", "beltline"),
        (r"\bavenue\b", "ave"),
        (r"\bstreet\b", "st"),
        (r"\broad\b", "rd"),
        (r"\bdrive\b", "dr"),
        (r"\bboulevard\b", "blvd"),
        (r"\blane\b", "ln"),
        (r"\bsuite\b", "ste"),
        (r"\bmount\b", "mt"),
        (r"\bwest\b", "w"),
        (r"\beast\b", "e"),
        (r"\bnorth\b", "n"),
        (r"\bsouth\b", "s"),
    ]
    for pattern, replacement in replacements:
        lowered = re.sub(pattern, replacement, lowered)
    return normalize_key(lowered)


def normalize_state(value: str) -> str:
    value = clean_text(value)
    if not value:
        return ""
    if " - " in value:
        left, right = [part.strip() for part in value.split(" - ", 1)]
        if right:
            value = right
        elif left:
            value = left
    upper = value.upper()
    if upper in US_STATE_ABBREVIATIONS:
        return US_STATE_ABBREVIATIONS[upper]
    if value.title() in US_STATE_ABBREVIATIONS.values():
        return value.title()
    return value


def build_full_address(address: str, city: str, state: str, postcode: str, country: str) -> str:
    parts = [sanitize_street_address(address), clean_text(city), clean_text(state), clean_text(postcode), country]
    return ", ".join(part for part in parts if part)


def derive_activity(title: str, categories: list[str]) -> str:
    if any(normalize_key(cat) == "skilled nursing" for cat in categories):
        return "Skilled nursing facility"

    lowered = title.lower()
    if "transport" in lowered or "ems" in lowered:
        return "Medical transportation service"
    if "behavioral health" in lowered:
        return "Behavioral health center"
    if "specialty hospital" in lowered or "hospital" in lowered:
        return "Specialty hospital"
    if "memory care" in lowered:
        return "Assisted living and memory care community"
    if "senior apartments" in lowered:
        return "Senior apartments"
    if "independent living" in lowered and "assisted living" in lowered:
        return "Independent and assisted living community"
    if "independent living" in lowered:
        return "Independent living community"
    if "assisted living" in lowered:
        return "Assisted living community"
    if "senior living" in lowered or "retirement" in lowered:
        return "Senior living community"
    if " villa" in f" {lowered} ":
        return "Senior living community"
    if "residential care" in lowered:
        return "Residential care community"
    if "residential" in lowered:
        return "Residential care community"
    if "community services" in lowered:
        return "Community support services"
    if "rehabilitation" in lowered or "healthcare" in lowered or "health and rehabilitation" in lowered:
        return "Healthcare and rehabilitation center"
    if "care center" in lowered:
        return "Care center"
    return "Post-acute healthcare services"


def extract_embedded_places(page_url: str) -> list[RawPlace]:
    response = SESSION.get(page_url, timeout=30)
    response.raise_for_status()
    match = re.search(r'window\.wpgmp\.mapdata\d+\s*=\s*"([A-Za-z0-9+/=]+)"', response.text)
    if not match:
        raise RuntimeError(f"No embedded map payload found on {page_url}")

    payload = json.loads(base64.b64decode(match.group(1)))
    places = []
    for place in payload.get("places", []):
        location = place.get("location", {}) or {}
        extra = location.get("extra_fields", {}) or {}
        categories = [clean_text(item.get("name")) for item in (place.get("categories") or []) if clean_text(item.get("name"))]
        places.append(
            RawPlace(
                title=clean_text(place.get("title")),
                address=clean_text(place.get("address")),
                city=clean_text(location.get("city")),
                state_raw=clean_text(location.get("state")),
                postcode=clean_text(location.get("postal_code")),
                country_raw=clean_text(location.get("country")),
                latitude=clean_text(location.get("lat")),
                longitude=clean_text(location.get("lng")),
                page_url=page_url,
                website_url=extract_website(str(extra.get("website", ""))),
                phone=clean_text(extra.get("phone")),
                fax=clean_text(extra.get("fax")),
                categories=categories,
                raw_id=clean_text(place.get("id")),
            )
        )
    return places


def fetch_title(url: str) -> str:
    if not url:
        return ""
    try:
        response = SESSION.get(url, timeout=30)
        response.raise_for_status()
    except Exception:
        return ""
    match = re.search(r"<title>(.*?)</title>", response.text, re.I | re.S)
    return clean_text(match.group(1)) if match else ""


def resolve_same_site_aliases(rows: list[RawPlace]) -> tuple[list[RawPlace], list[dict[str, Any]]]:
    groups: defaultdict[tuple[str, str, str], list[RawPlace]] = defaultdict(list)
    for row in rows:
        key = (
            normalize_address_key(row.address),
            normalize_key(row.city),
            normalize_key(row.postcode),
        )
        groups[key].append(row)

    kept_ids: set[tuple[str, str, str]] = set()
    removed: list[dict[str, Any]] = []

    for entries in groups.values():
        if len(entries) == 1:
            row = entries[0]
            kept_ids.add((row.raw_id, row.title, row.page_url))
            continue

        title_pairs = [
            SequenceMatcher(None, normalize_key(left.title), normalize_key(right.title)).ratio()
            for index, left in enumerate(entries)
            for right in entries[index + 1 :]
        ]
        max_similarity = max(title_pairs, default=0)
        rich_metadata_gap = any(item.website_url for item in entries) and any(not item.website_url for item in entries)

        if max_similarity < 0.9 and not (max_similarity >= 0.72 and rich_metadata_gap):
            for row in entries:
                kept_ids.add((row.raw_id, row.title, row.page_url))
            continue

        title_cache = {row.website_url: normalize_key(fetch_title(row.website_url)) for row in entries if row.website_url}
        scored: list[tuple[tuple[float, int, int, int, int], RawPlace]] = []
        for row in entries:
            site_title = title_cache.get(row.website_url, "")
            site_match = SequenceMatcher(None, normalize_key(row.title), site_title).ratio() if site_title else 0
            score = (
                site_match,
                1 if row.website_url else 0,
                1 if row.phone else 0,
                1 if row.fax else 0,
                len(row.title),
            )
            scored.append((score, row))

        scored.sort(reverse=True, key=lambda item: item[0])
        keeper = scored[0][1]
        kept_ids.add((keeper.raw_id, keeper.title, keeper.page_url))

        for _, row in scored[1:]:
            removed.append(
                {
                    "raw_id": row.raw_id,
                    "title": row.title,
                    "website_url": row.website_url,
                    "address": row.address,
                    "city": row.city,
                    "state_raw": row.state_raw,
                    "reason": f"Removed as same-site alias; kept '{keeper.title}' after scoring website-title and metadata richness.",
                }
            )

    resolved = [row for row in rows if (row.raw_id, row.title, row.page_url) in kept_ids]
    return resolved, removed


def dedupe_cross_page(rows: list[RawPlace]) -> list[RawPlace]:
    deduped: dict[tuple[str, str, str, str], RawPlace] = {}
    for row in rows:
        key = (
            normalize_key(row.title),
            normalize_key(row.address),
            normalize_key(row.city),
            normalize_key(row.state_raw),
        )
        existing = deduped.get(key)
        if existing is None or (row.website_url and not existing.website_url):
            deduped[key] = row
    return list(deduped.values())


def build_output_rows(raw_rows: list[RawPlace]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for raw in raw_rows:
        state = normalize_state(raw.state_raw)
        country = "United States"
        country_iso3 = "USA"
        address = build_full_address(raw.address, raw.city, state, raw.postcode, country)
        rows.append(
            {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": raw.title,
                "LOCATION_ADDRESS": address,
                "LATITUDE": raw.latitude,
                "LONGITUDE": raw.longitude,
                "COUNTRY": country,
                "COUNTRY_ISO3": country_iso3,
                "POSTCODE": raw.postcode,
                "STATE": state,
                "CITY": raw.city,
                "SOURCE_URL": raw.page_url,
                "SOURCE_TYPE": "COMPANY WEBSITE",
                "ACTIVITY_AT_ASSET": derive_activity(raw.title, raw.categories),
                "coord_source": "website" if raw.latitude and raw.longitude else "Not from website",
                "QA_flag": "",
            }
        )

    for supplemental in SUPPLEMENTAL_ROWS:
        row = {column: "" for column in CSV_COLUMNS}
        row.update(supplemental)
        row["ISSUER_ID"] = ISSUER_ID
        row["ISSUER_NAME"] = ISSUER_NAME
        rows.append(row)
    return rows


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    ISSUER_WORK_DIR.mkdir(parents=True, exist_ok=True)

    extracted: list[RawPlace] = []
    page_counts: dict[str, int] = {}
    for page in MAP_PAGES:
        places = extract_embedded_places(page["page_url"])
        extracted.extend(places)
        page_counts[page["page_url"]] = len(places)

    cross_page_deduped = dedupe_cross_page(extracted)
    alias_deduped, website_duplicates_removed = resolve_same_site_aliases(cross_page_deduped)
    final_rows = build_output_rows(alias_deduped)

    reference_count = len(extract_embedded_places(REFERENCE_MAP_PAGE))

    final_rows.sort(key=lambda row: (row["STATE"], row["CITY"], row["LOCATION_NAME"]))
    write_csv(STAGING_CSV, final_rows)

    category_counter = Counter(row["ACTIVITY_AT_ASSET"] for row in final_rows)
    state_counter = Counter(row["STATE"] for row in final_rows if row["STATE"])
    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "target_count": TARGET_COUNT,
        "page_counts": page_counts,
        "reference_group_map_count": reference_count,
        "raw_rows": len(extracted),
        "cross_page_deduped_rows": len(cross_page_deduped),
        "website_duplicate_rows_removed": website_duplicates_removed,
        "final_rows": len(final_rows),
        "state_counts": dict(state_counter),
        "activity_counts": dict(category_counter),
    }
    SUMMARY_JSON.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
