"""
Generic extractor for static listing pages that link to server-rendered branch detail
pages where the primary location data lives in a "Branch Information" accordion and
each location block is expressed as:

    <h3>Section</h3>
    <h4>Optional subsection</h4>
    <div class="form-row">... cards such as Telephone / Address / More Info ...</div>

This script is configured for Korean Air Cargo's Branch Information directory, but the
extraction logic below is intentionally pattern-based and reusable for other sites that
share the same structure.

Usage:
    python -X utf8 static_html_branch_accordion_extractor.py

Output:
    - Progress JSON / raw JSON / checkpoint CSV / summary JSON in the configured TEMP_DIR
    - Final CSV in the configured OUTPUT_DIR

Notes:
    - This site presents only text addresses on the website. Latitude/longitude are left
      blank unless explicit coordinates are found on the page.
    - Some detail pages omit the country in the address string; airport-code reference
      data is used only as a fallback for COUNTRY / ISO / municipality / region.
"""

from __future__ import annotations

import json
import re
import time
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd
import pycountry
import requests
from bs4 import BeautifulSoup, Tag
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


# ============================================================
# CONFIGURATION - Change these for each new issuer
# ============================================================
ISSUER_ID = "IID000000002173014"
ISSUER_NAME = "KOREAN AIR LINES CO.,LTD"
BASE_URL = "https://cargo.koreanair.com"
LISTING_URL = f"{BASE_URL}/en/Branch-Information"
DETAIL_URL_TEMPLATE = f"{BASE_URL}/en/Branch-Details?airport_code={{airport_code}}"
TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")
FINAL_BASENAME = f"{ISSUER_ID}_{ISSUER_NAME}"
CHECKPOINT_THRESHOLD = 73
PROGRESS_EVERY = 20
AIRPORT_LOOKUP_URL = "https://raw.githubusercontent.com/datasets/airport-codes/master/data/airport-codes.csv"
AIRPORT_LOOKUP_CACHE = TEMP_DIR / "airport_codes_lookup.csv"
SOURCE_TYPE = "COMPANY WEBSITE"
REQUEST_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/135.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": LISTING_URL,
}


# ============================================================
# GENERIC EXTRACTION LOGIC BELOW - Do not modify per issuer
# ============================================================
COUNTRY_SYNONYMS = {
    "korea": "South Korea",
    "republic of korea": "South Korea",
    "u.s.a": "United States",
    "u.s.a.": "United States",
    "usa": "United States",
    "u.s.": "United States",
    "uk": "United Kingdom",
    "u.k.": "United Kingdom",
    "viet nam": "Vietnam",
    "hong kong": "Hong Kong",
    "china, hong kong": "Hong Kong",
    "uae": "United Arab Emirates",
    "u.a.e.": "United Arab Emirates",
    "r.o.c.": "Taiwan",
    "roc": "Taiwan",
    "kingdom of cambodia": "Cambodia",
    "people's republic of china": "China",
}

CITY_NAME_FIXES = {
    "Denpasa": "Denpasar",
    "Frankfrut": "Frankfurt",
    "Hongkong": "Hong Kong",
    "Ho Chi Minh city": "Ho Chi Minh City",
    "Sao Paulo": "Sao Paulo",
    "Xian": "Xian",
}

COUNTRY_BY_CODE_OVERRIDES = {
    "HKG": "Hong Kong",
    "MFM": "Macau",
    "KTI": "Cambodia",
}

CITY_BY_CODE_OVERRIDES = {
    "KTI": "Phnom Penh",
}

SUBDIVISION_FIXES = {
    "US-HI": "Hawaii",
    "US-DC": "District of Columbia",
    "GB-ENG": "England",
    "KR-11": "Seoul",
    "KR-26": "Busan",
    "KR-28": "Incheon",
    "KR-41": "Gyeonggi-do",
    "CN-HK": "Hong Kong",
}

DISPLAY_COUNTRY_NAMES = {
    "Korea, Republic of": "South Korea",
    "Viet Nam": "Vietnam",
    "Taiwan, Province of China": "Taiwan",
    "Macao": "Macau",
    "Russian Federation": "Russia",
}

ISO_LOOKUP_NAMES = {
    "South Korea": "Korea, Republic of",
    "Vietnam": "Viet Nam",
    "Taiwan": "Taiwan, Province of China",
    "Macau": "Macao",
    "Russia": "Russian Federation",
}

POSTCODE_PATTERNS_BY_COUNTRY = {
    "United States": [r"\b\d{5}(?:-\d{4})?\b"],
    "Canada": [r"\b[A-Z]\d[A-Z]\s*\d[A-Z]\d\b"],
    "United Kingdom": [r"\b[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}\b"],
    "Japan": [r"\b\d{3}-\d{4}\b"],
    "China": [r"\b\d{6}\b"],
    "Hong Kong": [],
    "Macau": [],
    "Singapore": [r"\b\d{6}\b"],
    "Taiwan": [r"\b\d{5}\b"],
    "India": [r"\b\d{6}\b"],
    "Thailand": [r"\b\d{5}\b"],
    "South Korea": [r"\b\d{5}\b"],
    "Australia": [r"\b\d{4}\b"],
    "New Zealand": [r"\b\d{4}\b"],
    "Brazil": [r"\b\d{5}-?\d{3}\b"],
    "Mexico": [r"\b\d{5}\b"],
    "Germany": [r"\b\d{5}\b"],
    "France": [r"\b\d{5}\b"],
    "Spain": [r"\b\d{5}\b"],
    "Italy": [r"\b\d{5}\b"],
    "Austria": [r"\bA-\d{4}\b", r"\b\d{4}\b"],
    "Netherlands": [r"\b\d{4}\s*[A-Z]{2}\b"],
    "Russia": [r"\b\d{6}\b"],
    "Peru": [r"\b\d{5}\b"],
    "Cambodia": [],
}


@dataclass
class BranchLink:
    airport_code: str
    display_city: str
    detail_url: str


def build_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=4,
        connect=4,
        read=4,
        status=4,
        backoff_factor=1.0,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET"],
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=8, pool_maxsize=8)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.headers.update(REQUEST_HEADERS)
    session.verify = False
    requests.packages.urllib3.disable_warnings()  # type: ignore[attr-defined]
    return session


def normalize_country_key(text: str) -> str:
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii").lower()
    text = text.replace("&", "and")
    text = re.sub(r"[().,']", "", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def build_country_aliases() -> dict[str, str]:
    aliases: dict[str, str] = {}
    for country in pycountry.countries:
        display = DISPLAY_COUNTRY_NAMES.get(country.name, country.name)
        aliases[normalize_country_key(display)] = display
        for attr in ("name", "official_name", "common_name"):
            value = getattr(country, attr, "")
            if value:
                aliases[normalize_country_key(value)] = display
    for raw, mapped in COUNTRY_SYNONYMS.items():
        aliases[normalize_country_key(raw)] = mapped
    return aliases


COUNTRY_ALIASES = build_country_aliases()


def fetch_text(session: requests.Session, url: str, timeout: int = 35) -> str:
    response = session.get(url, timeout=timeout)
    response.raise_for_status()
    return response.text


def normalize_whitespace(text: str) -> str:
    text = text.replace("\xa0", " ")
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\s+,", ",", text)
    text = re.sub(r",\s*", ", ", text)
    return text.strip(" ,")


def strip_hashes(text: str) -> str:
    return normalize_whitespace(text.replace("#", " "))


def ascii_clean(text: str) -> str:
    if not text:
        return ""
    text = unicodedata.normalize("NFKC", text)
    text = strip_hashes(text)
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\s+([,;:.])", r"\1", text)
    return text.strip(" ,")


def title_if_upper(text: str) -> str:
    if not text:
        return ""
    if re.search(r"[a-z]", text):
        return text
    return " ".join(token.capitalize() if token.isalpha() else token for token in text.split())


def clean_display_city(text: str) -> str:
    text = re.sub(r"\s*\[[A-Z0-9]+\]\s*$", "", text).strip()
    text = CITY_NAME_FIXES.get(text, text)
    return ascii_clean(text)


def load_airport_lookup() -> dict[str, dict[str, str]]:
    if AIRPORT_LOOKUP_CACHE.exists():
        df = pd.read_csv(AIRPORT_LOOKUP_CACHE)
    else:
        df = pd.read_csv(AIRPORT_LOOKUP_URL)
        df.to_csv(AIRPORT_LOOKUP_CACHE, index=False)

    df = df[df["iata_code"].notna()].copy()
    df["iata_code"] = df["iata_code"].astype(str).str.upper()
    lookup: dict[str, dict[str, str]] = {}
    for row in df.itertuples(index=False):
        code = getattr(row, "iata_code")
        lookup[code] = {
            "municipality": getattr(row, "municipality", "") or "",
            "iso_country": getattr(row, "iso_country", "") or "",
            "iso_region": getattr(row, "iso_region", "") or "",
            "airport_name": getattr(row, "name", "") or "",
        }
    return lookup


def display_country_name(country_name: str) -> str:
    return DISPLAY_COUNTRY_NAMES.get(country_name, country_name)


def country_name_from_iso2(iso2: str) -> str:
    if not iso2:
        return ""
    country = pycountry.countries.get(alpha_2=iso2.upper())
    return display_country_name(country.name) if country else ""


def iso3_from_country_name(country_name: str) -> str:
    if not country_name:
        return ""
    lookup_name = ISO_LOOKUP_NAMES.get(country_name, country_name)
    if country_name == "North Korea":
        lookup_name = "Korea, Democratic People's Republic of"

    country = pycountry.countries.get(name=lookup_name)
    if not country:
        country = pycountry.countries.search_fuzzy(lookup_name)[0]
    return getattr(country, "alpha_3", "")


def subdivision_name_from_iso_region(iso_region: str) -> str:
    if not iso_region:
        return ""
    if iso_region in SUBDIVISION_FIXES:
        return SUBDIVISION_FIXES[iso_region]
    subdiv = pycountry.subdivisions.get(code=iso_region)
    return subdiv.name if subdiv else ""


def canonicalize_country(country_text: str) -> str:
    raw = ascii_clean(country_text)
    if not raw:
        return ""
    return COUNTRY_ALIASES.get(normalize_country_key(raw), "")


def extract_explicit_country(address_ascii: str) -> str:
    if not address_ascii:
        return ""

    trailing = re.search(r"\(([^()]+)\)\s*$", address_ascii)
    if trailing:
        country = canonicalize_country(trailing.group(1))
        if country:
            return country

    parts = [p.strip() for p in address_ascii.split(",") if p.strip()]
    for part in reversed(parts[-3:]):
        country = canonicalize_country(part)
        if country:
            return country
    return ""


def extract_postcode(address_ascii: str, country_name: str) -> str:
    if country_name in POSTCODE_PATTERNS_BY_COUNTRY:
        patterns = POSTCODE_PATTERNS_BY_COUNTRY[country_name]
    else:
        patterns = [
            r"\b\d{6}\b",
            r"\b\d{5}(?:-\d{4})?\b",
            r"\b\d{4}\b",
            r"\b\d{3}-\d{4}\b",
            r"\b[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}\b",
            r"\b[A-Z]\d[A-Z]\s*\d[A-Z]\d\b",
            r"\b\d{4}\s*[A-Z]{2}\b",
        ]
    if not patterns:
        return ""

    for pattern in patterns:
        match = re.search(pattern, address_ascii, flags=re.IGNORECASE)
        if match:
            return match.group(0).strip()
    return ""


def extract_city_from_address(address_ascii: str, country_name: str, fallback_city: str) -> str:
    if not address_ascii:
        return fallback_city

    working = address_ascii
    working = re.sub(r"\bzip code\b[:]?", "", working, flags=re.IGNORECASE)
    working = re.sub(r"\(([^()]+)\)\s*$", "", working).strip()
    explicit_country = extract_explicit_country(address_ascii)
    if explicit_country:
        pattern = re.escape(explicit_country)
        working = re.sub(rf",?\s*{pattern}\s*$", "", working, flags=re.IGNORECASE).strip(" ,")

    postcode = extract_postcode(address_ascii, country_name)
    if postcode:
        working = re.sub(re.escape(postcode), "", working, flags=re.IGNORECASE)

    parts = [p.strip(" -") for p in working.split(",") if p.strip(" -")]
    state_like = re.compile(r"^(?:[A-Z]{2,3}|\b[A-Z]{2}\s+\d|\d{4,6}|[A-Z]\d[A-Z])")
    reject_keywords = {
        "airport",
        "terminal",
        "cargo",
        "building",
        "suite",
        "room",
        "warehouse",
        "tower",
        "office block",
        "super terminal",
        "complex",
        "district",
        "province",
        "zip code",
        "korean air",
        "unit:",
        "unit ",
        "floor",
        "village",
        "commune",
        "side",
        "ward",
        "area",
        "railroad",
        "station",
    }
    street_keywords = {"road", "rd", "street", "avenida", "ave", "highway", "hwy", "chalan", "lane"}
    street_term_words = {"road", "street", "avenue", "lane", "rd", "ave", "hwy", "highway", "chalan"}
    for part in reversed(parts):
        candidate = re.sub(r"\b\d[\w-]*\b", "", part).strip(" -")
        candidate = re.sub(r"\s+", " ", candidate).strip(" -")
        if not candidate:
            continue
        if "[" in candidate or "]" in candidate:
            continue
        if canonicalize_country(candidate):
            continue
        if state_like.match(candidate):
            continue
        lowered = candidate.lower()
        lowered_words = set(re.findall(r"[a-z]+", lowered))
        if ("pref" in lowered or "prefecture" in lowered) and fallback_city:
            return fallback_city
        if re.search(r"(?:-ku|-gu|-shi)\s+[A-Za-z][A-Za-z -]+$", candidate, flags=re.IGNORECASE):
            return title_if_upper(candidate.split()[-1])
        if fallback_city and ascii_clean(fallback_city).lower() in lowered and ascii_clean(fallback_city).lower() != lowered:
            return fallback_city
        if any(keyword in lowered_words for keyword in street_keywords):
            last_word = candidate.split()[-1].strip(".")
            if last_word and len(last_word) > 3 and last_word.lower() not in street_term_words:
                return title_if_upper(last_word)
            if fallback_city:
                return fallback_city
        if any(keyword in lowered for keyword in reject_keywords):
            continue
        if fallback_city and len(candidate) <= 4 and ascii_clean(candidate).lower() != ascii_clean(fallback_city).lower():
            continue
        return title_if_upper(candidate)
    return fallback_city


def clean_address(address: str) -> str:
    address = ascii_clean(address)
    address = re.sub(r"\bZip code\b[:]?\s*", "", address, flags=re.IGNORECASE)
    address = re.sub(r"\bLocated in\b.*$", "", address, flags=re.IGNORECASE)
    address = re.sub(r"\bNearest railroad station:.*$", "", address, flags=re.IGNORECASE)
    address = re.sub(r"\[[^\]]+\]", "", address)
    address = re.sub(r"\[[^\]]+\]\s*$", "", address)
    address = re.sub(r"\s*\(\s*([A-Za-z .]+)\s*\)\s*$", lambda m: f", {m.group(1).strip()}", address)
    address = re.sub(r",\s*Korean Air\s*$", "", address, flags=re.IGNORECASE)
    address = re.sub(r"\s-\s([A-Z][A-Za-z .'-]+)\s+(\d{4,6})$", r", \1, \2", address)
    address = re.sub(r"\s-\s([A-Z][A-Za-z .'-]+)$", r", \1", address)
    address = re.sub(r"\s+-\s+", " - ", address)
    address = re.sub(r"\s+/\s+", " / ", address)
    address = re.sub(r"\s+", " ", address)
    address = re.sub(r"\s+,", ",", address)
    address = re.sub(r",\s*,", ", ", address)
    return address.strip(" ,")


def parse_listing(session: requests.Session) -> list[BranchLink]:
    html = fetch_text(session, LISTING_URL)
    soup = BeautifulSoup(html, "html.parser")
    links: list[BranchLink] = []
    seen_codes: set[str] = set()

    for anchor in soup.select("a[href*='/en/Branch-Details?airport_code=']"):
        href = anchor.get("href", "")
        match = re.search(r"airport_code=([A-Z0-9]+)", href)
        if not match:
            continue
        airport_code = match.group(1).upper()
        if airport_code in seen_codes:
            continue
        seen_codes.add(airport_code)
        display_city = clean_display_city(" ".join(anchor.get_text(" ", strip=True).split()))
        detail_url = href if href.startswith("http") else f"{BASE_URL}{href}"
        links.append(BranchLink(airport_code=airport_code, display_city=display_city, detail_url=detail_url))

    return links


def parse_branch_page(html: str, link: BranchLink) -> list[dict[str, Any]]:
    soup = BeautifulSoup(html, "html.parser")
    branch_body = soup.select_one("div#collapseOne > div.card-body")
    if not branch_body:
        return []

    children = [child for child in branch_body.children if isinstance(child, Tag)]
    blocks: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None

    for child in children:
        name = child.name.lower()
        if name == "h3":
            if current:
                blocks.append(current)
            current = {
                "airport_code": link.airport_code,
                "display_city": link.display_city,
                "detail_url": link.detail_url,
                "section": normalize_whitespace(child.get_text(" ", strip=True)),
                "subsection": "",
                "fields": {},
            }
        elif name == "h4" and current is not None:
            current["subsection"] = normalize_whitespace(child.get_text(" ", strip=True))
        elif name == "div" and "form-row" in child.get("class", []) and current is not None:
            for card in child.select("div.card.static-address-card"):
                header_tag = card.select_one("div.card-header")
                body_tag = card.select_one("div.card-body")
                header = normalize_whitespace(header_tag.get_text(" ", strip=True)) if header_tag else ""
                body = normalize_whitespace(body_tag.get_text(" ", strip=True)) if body_tag else ""
                current["fields"][header] = body

    if current:
        blocks.append(current)
    return blocks


def build_location_name(city: str, section: str, subsection: str, airport_code: str) -> str:
    parts = [city, section]
    if subsection:
        parts.append(subsection)
    return ascii_clean(" - ".join(parts) + f" ({airport_code})")


def build_activity(section: str, subsection: str) -> str:
    if subsection:
        return ascii_clean(f"{section} - {subsection}")
    return ascii_clean(section)


def block_to_record(
    block: dict[str, Any],
    airport_lookup: dict[str, dict[str, str]],
) -> dict[str, Any] | None:
    raw_address = normalize_whitespace(block["fields"].get("Address", ""))
    if not raw_address:
        return None

    airport_code = block["airport_code"]
    lookup = airport_lookup.get(airport_code, {})
    municipality = ascii_clean((lookup.get("municipality") or "").split(" (")[0])
    display_city = clean_display_city(block["display_city"])
    fallback_city = CITY_BY_CODE_OVERRIDES.get(airport_code, display_city or municipality)

    address_native = strip_hashes(raw_address)
    address_ascii = clean_address(raw_address)
    explicit_country = extract_explicit_country(address_ascii)
    fallback_country = COUNTRY_BY_CODE_OVERRIDES.get(airport_code, "") or country_name_from_iso2(lookup.get("iso_country", ""))
    country_name = explicit_country or fallback_country
    country_name = canonicalize_country(country_name) if country_name else ""
    country_iso3 = iso3_from_country_name(country_name) if country_name else ""
    postcode = extract_postcode(address_ascii, country_name)
    city = extract_city_from_address(address_ascii, country_name, fallback_city)
    city = CITY_NAME_FIXES.get(city, city)
    if "Airport Operation Office" in block["section"] and fallback_city:
        if ascii_clean(fallback_city).lower() in address_ascii.lower():
            city = fallback_city
    state = subdivision_name_from_iso_region(lookup.get("iso_region", ""))
    if city and state and ascii_clean(state).lower() == ascii_clean(city).lower():
        state = ""
    if state and country_name not in {"United States", "Canada", "Australia", "Brazil", "Mexico"}:
        if ascii_clean(state).lower() not in address_ascii.lower():
            state = ""

    section = normalize_whitespace(block["section"])
    subsection = normalize_whitespace(block["subsection"])
    activity = build_activity(section, subsection)
    location_name = build_location_name(city or fallback_city or display_city, section, subsection, airport_code)

    address_has_non_ascii = any(ord(ch) > 127 for ch in address_native)
    name_has_non_ascii = any(ord(ch) > 127 for ch in location_name)

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": location_name,
        "LOCATION_NAME_NATIVE": location_name if name_has_non_ascii else "",
        "LOCATION_ADDRESS": address_ascii,
        "LOCATION_ADDRESS_NATIVE": address_native if address_has_non_ascii else "",
        "LATITUDE": "",
        "LONGITUDE": "",
        "coord_source": "Not from website",
        "COUNTRY": country_name,
        "COUNTRY_ISO3": country_iso3,
        "POSTCODE": postcode,
        "STATE": ascii_clean(state),
        "CITY": ascii_clean(city or fallback_city or display_city),
        "SOURCE_URL": block["detail_url"],
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": activity,
        "_airport_code": airport_code,
        "_section": section,
        "_subsection": subsection,
    }


def deduplicate_records(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    deduped: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str, str]] = set()
    for record in records:
        key = (
            record["SOURCE_URL"],
            record["LOCATION_ADDRESS"],
            record["ACTIVITY_AT_ASSET"],
            record["LOCATION_NAME"],
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(record)
    return deduped


def validate_records(records: list[dict[str, Any]]) -> list[str]:
    issues: list[str] = []
    blank_city = sum(1 for row in records if not row["CITY"])
    blank_address = sum(1 for row in records if not row["LOCATION_ADDRESS"])
    hash_count = sum(1 for row in records if "#" in row["LOCATION_ADDRESS"])
    blank_country = sum(1 for row in records if not row["COUNTRY"])
    blank_iso3 = sum(1 for row in records if not row["COUNTRY_ISO3"])

    if blank_city:
        issues.append(f"Blank CITY rows: {blank_city}")
    if blank_address:
        issues.append(f"Blank LOCATION_ADDRESS rows: {blank_address}")
    if hash_count:
        issues.append(f"Address rows still containing '#': {hash_count}")
    if blank_country:
        issues.append(f"Blank COUNTRY rows: {blank_country}")
    if blank_iso3:
        issues.append(f"Blank COUNTRY_ISO3 rows: {blank_iso3}")
    return issues


def write_csv(records: list[dict[str, Any]], path: Path) -> None:
    columns = [
        "ISSUER_ID",
        "ISSUER_NAME",
        "LOCATION_NAME",
        "LOCATION_NAME_NATIVE",
        "LOCATION_ADDRESS",
        "LOCATION_ADDRESS_NATIVE",
        "LATITUDE",
        "LONGITUDE",
        "coord_source",
        "COUNTRY",
        "COUNTRY_ISO3",
        "POSTCODE",
        "STATE",
        "CITY",
        "SOURCE_URL",
        "SOURCE_TYPE",
        "ACTIVITY_AT_ASSET",
    ]
    df = pd.DataFrame(records)
    df = df[columns]
    df.to_csv(path, index=False, encoding="utf-8-sig")


def write_progress(
    processed_codes: list[str],
    failed_codes: list[dict[str, str]],
    current_records: list[dict[str, Any]],
    progress_path: Path,
    raw_path: Path,
) -> None:
    progress_payload = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "processed_airport_codes": processed_codes,
        "processed_pages": len(processed_codes),
        "record_count": len(current_records),
        "failed_codes": failed_codes,
    }
    progress_path.write_text(json.dumps(progress_payload, ensure_ascii=False, indent=2), encoding="utf-8")
    raw_path.write_text(json.dumps(current_records, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> None:
    started = time.time()
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    progress_path = TEMP_DIR / f"{ISSUER_ID}_progress.json"
    raw_records_path = TEMP_DIR / f"{ISSUER_ID}_raw_records.json"
    checkpoint_path = TEMP_DIR / f"{FINAL_BASENAME}_checkpoint.csv"
    final_output_path = OUTPUT_DIR / f"{FINAL_BASENAME}.csv"
    summary_path = TEMP_DIR / f"{ISSUER_ID}_summary.json"

    airport_lookup = load_airport_lookup()
    session = build_session()
    links = parse_listing(session)

    records: list[dict[str, Any]] = []
    processed_codes: list[str] = []
    failed_codes: list[dict[str, str]] = []
    checkpoint_written = False

    for index, link in enumerate(links, start=1):
        try:
            html = fetch_text(session, link.detail_url)
            blocks = parse_branch_page(html, link)
            for block in blocks:
                record = block_to_record(block, airport_lookup)
                if record and record["LOCATION_ADDRESS"] and record["CITY"]:
                    records.append(record)
        except Exception as exc:  # noqa: BLE001
            failed_codes.append(
                {
                    "airport_code": link.airport_code,
                    "detail_url": link.detail_url,
                    "error": f"{exc.__class__.__name__}: {exc}",
                }
            )
        processed_codes.append(link.airport_code)

        deduped = deduplicate_records(records)
        if len(deduped) >= CHECKPOINT_THRESHOLD and not checkpoint_written:
            write_csv(deduped, checkpoint_path)
            checkpoint_written = True

        if index % PROGRESS_EVERY == 0 or index == len(links):
            write_progress(processed_codes, failed_codes, deduped, progress_path, raw_records_path)

        time.sleep(0.15)

    deduped = deduplicate_records(records)
    write_csv(deduped, final_output_path)
    if checkpoint_written:
        write_csv(deduped, checkpoint_path)
    else:
        write_csv(deduped, checkpoint_path)

    issues = validate_records(deduped)
    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "listing_url": LISTING_URL,
        "airport_pages_discovered": len(links),
        "records_extracted": len(deduped),
        "checkpoint_threshold": CHECKPOINT_THRESHOLD,
        "checkpoint_reached": len(deduped) >= CHECKPOINT_THRESHOLD,
        "failed_codes": failed_codes,
        "validation_issues": issues,
        "output_csv": str(final_output_path),
        "checkpoint_csv": str(checkpoint_path),
        "duration_seconds": round(time.time() - started, 2),
    }
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
