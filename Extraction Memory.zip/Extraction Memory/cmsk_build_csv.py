"""
CMSK Final CSV Builder
Combines:
1. PDF-extracted project table (378 projects from annual report)
2. Known operating assets (industrial parks, malls, cruise terminals, etc.)
3. Cleans, transliterates, and validates all records

Output: Final CSV with all required columns.
"""
import json, csv, re, io, sys, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

from pypinyin import lazy_pinyin, Style

# ── CONFIG ────────────────────────────────────────────────
ISSUER_ID   = "IID000000002751338"
ISSUER_NAME = "CHINA MERCHANTS SHEKOU INDUSTRIAL ZONE HOLDINGS CO., LTD."
TEMP_DIR    = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Temp"
OUTPUT_DIR  = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Output"
ANNUAL_RPT  = "https://disc.static.szse.cn/disc/disk03/finalpage/2025-03-17/919df473-7b93-462a-a2cf-a58b4c94adf3.PDF"

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ── TRANSLITERATION ───────────────────────────────────────

# Chinese → English administrative terms
CN_TO_EN = [
    ('经济技术开发区', 'Economic and Technological Development Zone'),
    ('高新技术产业开发区', 'Hi-Tech Industrial Development Zone'),
    ('高新区', 'Hi-Tech Zone'),
    ('开发区', 'Development Zone'),
    ('新区', 'New District'),
    ('工业区', 'Industrial Zone'),
    ('产业园区', 'Industrial Park'),
    ('产业园', 'Industrial Park'),
    ('工业园', 'Industrial Park'),
    ('科技园', 'Science Park'),
    ('软件园', 'Software Park'),
    ('创意园', 'Creative Park'),
    ('文创园', 'Creative Park'),
    ('创业园', 'Startup Park'),
    ('网谷', 'Wang Gu Innovation Hub'),
    ('意库', 'Yiku Creative Hub'),
    ('智慧城', 'Smart City Hub'),
    ('花园城', 'Garden City Mall'),
    ('花园里', 'Garden Li Mall'),
    ('邮轮母港', 'Cruise Homeport'),
    ('邮轮港', 'Cruise Terminal'),
    ('会展中心', 'Convention & Exhibition Center'),
    ('国际会展中心', 'International Convention & Exhibition Center'),
    ('大会展中心', 'Grand Convention Center'),
    ('国际会议中心', 'International Conference Center'),
    ('科学会堂', 'Science Hall'),
    ('海上世界', 'Sea World'),
    ('太子湾', 'Prince Bay'),
    ('太子路', 'Prince Road'),
    ('公园', 'Park'),
    ('住宅区', 'Residential Area'),
    ('商业中心', 'Commercial Center'),
    ('购物中心', 'Shopping Mall'),
    ('写字楼', 'Office Building'),
    ('综合体', 'Mixed-Use Complex'),
    ('地块', 'Land Plot'),
    ('街道', ' Street'),
    ('大道', ' Avenue'),
    ('路', ' Road'),
    ('号楼', ' Building'),
    ('号院', ' Yard'),
    ('东路', ' East Road'),
    ('西路', ' West Road'),
    ('南路', ' South Road'),
    ('北路', ' North Road'),
    ('区', ' District'),
    ('市', ' City'),
    ('省', ' Province'),
    ('县', ' County'),
    ('镇', ' Town'),
    ('乡', ' Township'),
    ('村', ' Village'),
    ('街', ' Street'),
    ('巷', ' Lane'),
    ('弄', ' Alley'),
    ('里', '',),  # short "li" suffix for addresses, often ignored
]

def to_pinyin_word(ch: str) -> str:
    """Convert a single Chinese character to capitalized pinyin."""
    result = lazy_pinyin(ch, style=Style.NORMAL)
    if result:
        return result[0].capitalize()
    return ch

def transliterate(text: str) -> str:
    """
    Convert Chinese text to English:
    1. Replace known administrative terms with English equivalents
    2. Convert remaining CJK characters to capitalized Pinyin
    """
    if not text:
        return text
    
    result = text
    
    # Apply known term replacements first (longest first to avoid partial replacements)
    for cn, en in sorted(CN_TO_EN, key=lambda x: -len(x[0])):
        result = result.replace(cn, f' {en} ' if en else '')
    
    # Convert any remaining CJK characters to Pinyin
    out = []
    for ch in result:
        if '\u4e00' <= ch <= '\u9fff' or '\u3400' <= ch <= '\u4dbf':
            out.append(to_pinyin_word(ch))
        else:
            out.append(ch)
    result = ''.join(out)
    
    # Clean up: collapse spaces, remove extra punctuation
    result = re.sub(r'\s+', ' ', result).strip()
    result = result.replace('  ', ' ')
    result = result.strip(' ,')
    
    return result


# ── CITY / STATE MAPPING ──────────────────────────────────
# Maps Chinese city/district string to (English city, English state/province)
LOCATION_MAP = {
    # Beijing
    '北京昌平': ('Changping', 'Beijing', 'Beijing', '102200'),
    '北京大兴': ('Daxing', 'Beijing', 'Beijing', '102600'),
    '北京亦庄': ('Yizhuang (Daxing)', 'Beijing', 'Beijing', '101111'),
    '北京朝阳': ('Chaoyang', 'Beijing', 'Beijing', '100020'),
    '北京丰台': ('Fengtai', 'Beijing', 'Beijing', '100071'),
    '北京海淀': ('Haidian', 'Beijing', 'Beijing', '100080'),
    '北京石景山': ('Shijingshan', 'Beijing', 'Beijing', '100043'),
    '北京通州': ('Tongzhou', 'Beijing', 'Beijing', '101100'),
    '北京东城': ('Dongcheng', 'Beijing', 'Beijing', '100010'),
    '北京顺义': ('Shunyi', 'Beijing', 'Beijing', '101300'),
    '北京': ('Beijing', 'Beijing', 'Beijing', '100000'),
    # Tianjin
    '天津北辰': ('Beichen', 'Tianjin', 'Tianjin', '300400'),
    '天津滨海新区': ('Binhai New Area', 'Tianjin', 'Tianjin', '300457'),
    '天津和平': ('Heping', 'Tianjin', 'Tianjin', '300040'),
    '天津河北': ('Hebei District', 'Tianjin', 'Tianjin', '300143'),
    '天津南开': ('Nankai', 'Tianjin', 'Tianjin', '300100'),
    '天津武清': ('Wuqing', 'Tianjin', 'Tianjin', '301700'),
    '天津': ('Tianjin', 'Tianjin', 'Tianjin', '300000'),
    # Hebei
    '雄安新区启动区': ('Xiong\'an New Area', 'Baoding', 'Hebei', '071800'),
    '雄安新区': ('Xiong\'an New Area', 'Baoding', 'Hebei', '071800'),
    # Liaoning
    '沈阳大东': ('Dadong, Shenyang', 'Shenyang', 'Liaoning', '110041'),
    '沈阳皇姑': ('Huanggu, Shenyang', 'Shenyang', 'Liaoning', '110036'),
    '沈阳铁西': ('Tiexi, Shenyang', 'Shenyang', 'Liaoning', '110020'),
    '沈阳于洪': ('Yuhong, Shenyang', 'Shenyang', 'Liaoning', '110141'),
    '沈阳于洪新区': ('Yuhong New Area, Shenyang', 'Shenyang', 'Liaoning', '110141'),
    '沈阳浑南': ('Hunnan, Shenyang', 'Shenyang', 'Liaoning', '110179'),
    '沈阳经济技术开发区': ('Shenyang Economic and Technological Development Zone', 'Shenyang', 'Liaoning', '110027'),
    '沈阳': ('Shenyang', 'Shenyang', 'Liaoning', '110000'),
    '大连甘井子': ('Ganjingzi, Dalian', 'Dalian', 'Liaoning', '116033'),
    '大连旅顺口': ('Lvshunkou, Dalian', 'Dalian', 'Liaoning', '116041'),
    '大连金州': ('Jinzhou, Dalian', 'Dalian', 'Liaoning', '116100'),
    '大连中山': ('Zhongshan District, Dalian', 'Dalian', 'Liaoning', '116001'),
    '大连': ('Dalian', 'Dalian', 'Liaoning', '116000'),
    # Jilin
    '长春净月': ('Jingyue, Changchun', 'Changchun', 'Jilin', '130117'),
    '长春新区': ('Changchun New Area', 'Changchun', 'Jilin', '130119'),
    '长春': ('Changchun', 'Changchun', 'Jilin', '130000'),
    # Heilongjiang
    '哈尔滨道里': ('Daoli, Harbin', 'Harbin', 'Heilongjiang', '150016'),
    '哈尔滨平房': ('Pingfang, Harbin', 'Harbin', 'Heilongjiang', '150066'),
    '哈尔滨': ('Harbin', 'Harbin', 'Heilongjiang', '150000'),
    # Shandong
    '青岛高新区': ('Hi-Tech Zone, Qingdao', 'Qingdao', 'Shandong', '266114'),
    '青岛即墨': ('Jimo, Qingdao', 'Qingdao', 'Shandong', '266200'),
    '青岛市北': ('Shibei, Qingdao', 'Qingdao', 'Shandong', '266011'),
    '青岛西海岸新区': ('West Coast New Area, Qingdao', 'Qingdao', 'Shandong', '266400'),
    '青岛李沧': ('Licang, Qingdao', 'Qingdao', 'Shandong', '266100'),
    '青岛城阳': ('Chengyang, Qingdao', 'Qingdao', 'Shandong', '266109'),
    '青岛': ('Qingdao', 'Qingdao', 'Shandong', '266000'),
    '烟台芝罘': ('Zhifu, Yantai', 'Yantai', 'Shandong', '264001'),
    '烟台开发区': ('Development Zone, Yantai', 'Yantai', 'Shandong', '265500'),
    '烟台牟平': ('Muping, Yantai', 'Yantai', 'Shandong', '264100'),
    '烟台': ('Yantai', 'Yantai', 'Shandong', '264000'),
    '日照东港': ('Donggang, Rizhao', 'Rizhao', 'Shandong', '276800'),
    '日照': ('Rizhao', 'Rizhao', 'Shandong', '276800'),
    '济南历下': ('Lixia, Jinan', 'Jinan', 'Shandong', '250014'),
    '济南': ('Jinan', 'Jinan', 'Shandong', '250000'),
    # Shanghai
    '上海浦东新区': ('Pudong New Area', 'Shanghai', 'Shanghai', '200120'),
    '上海浦东': ('Pudong New Area', 'Shanghai', 'Shanghai', '200120'),
    '上海宝山': ('Baoshan', 'Shanghai', 'Shanghai', '201900'),
    '上海松江': ('Songjiang', 'Shanghai', 'Shanghai', '201600'),
    '上海崇明': ('Chongming', 'Shanghai', 'Shanghai', '202150'),
    '上海金山': ('Jinshan', 'Shanghai', 'Shanghai', '201500'),
    '上海静安': ('Jing\'an', 'Shanghai', 'Shanghai', '200040'),
    '上海闵行': ('Minhang', 'Shanghai', 'Shanghai', '201100'),
    '上海虹口': ('Hongkou', 'Shanghai', 'Shanghai', '200080'),
    '上海奉贤': ('Fengxian', 'Shanghai', 'Shanghai', '201400'),
    '上海嘉定': ('Jiading', 'Shanghai', 'Shanghai', '201800'),
    '上海青浦': ('Qingpu', 'Shanghai', 'Shanghai', '201700'),
    '上海徐汇': ('Xuhui', 'Shanghai', 'Shanghai', '200030'),
    '上海普陀': ('Putuo', 'Shanghai', 'Shanghai', '200060'),
    '上海长宁': ('Changning', 'Shanghai', 'Shanghai', '200051'),
    '上海杨浦': ('Yangpu', 'Shanghai', 'Shanghai', '200090'),
    '上海': ('Shanghai', 'Shanghai', 'Shanghai', '200000'),
    # Jiangsu
    '太仓浏河': ('Liuhe, Taicang', 'Taicang', 'Jiangsu', '215411'),
    '太仓城厢镇': ('Chengxiang Town, Taicang', 'Taicang', 'Jiangsu', '215400'),
    '太仓高新区': ('Hi-Tech Zone, Taicang', 'Taicang', 'Jiangsu', '215400'),
    '太仓': ('Taicang', 'Taicang', 'Jiangsu', '215400'),
    '南京浦口': ('Pukou, Nanjing', 'Nanjing', 'Jiangsu', '211800'),
    '南京雨花台': ('Yuhuatai, Nanjing', 'Nanjing', 'Jiangsu', '210012'),
    '南京玄武': ('Xuanwu, Nanjing', 'Nanjing', 'Jiangsu', '210018'),
    '南京江宁': ('Jiangning, Nanjing', 'Nanjing', 'Jiangsu', '211100'),
    '南京秦淮': ('Qinhuai, Nanjing', 'Nanjing', 'Jiangsu', '210006'),
    '南京六合': ('Liuhe, Nanjing', 'Nanjing', 'Jiangsu', '211500'),
    '南京溧水': ('Lishui, Nanjing', 'Nanjing', 'Jiangsu', '211200'),
    '南京': ('Nanjing', 'Nanjing', 'Jiangsu', '210000'),
    '苏州': ('Suzhou', 'Suzhou', 'Jiangsu', '215000'),
    '无锡': ('Wuxi', 'Wuxi', 'Jiangsu', '214000'),
    '南通': ('Nantong', 'Nantong', 'Jiangsu', '226000'),
    '徐州': ('Xuzhou', 'Xuzhou', 'Jiangsu', '221000'),
    '扬州': ('Yangzhou', 'Yangzhou', 'Jiangsu', '225000'),
    '常州': ('Changzhou', 'Changzhou', 'Jiangsu', '213000'),
    '镇江': ('Zhenjiang', 'Zhenjiang', 'Jiangsu', '212000'),
    # Zhejiang
    '杭州': ('Hangzhou', 'Hangzhou', 'Zhejiang', '310000'),
    '宁波海曙': ('Haishu, Ningbo', 'Ningbo', 'Zhejiang', '315000'),
    '宁波鄞州': ('Yinzhou, Ningbo', 'Ningbo', 'Zhejiang', '315100'),
    '宁波慈溪': ('Cixi, Ningbo', 'Ningbo', 'Zhejiang', '315300'),
    '宁波奉化': ('Fenghua, Ningbo', 'Ningbo', 'Zhejiang', '315500'),
    '宁波镇海': ('Zhenhai, Ningbo', 'Ningbo', 'Zhejiang', '315200'),
    '宁波余姚': ('Yuyao, Ningbo', 'Ningbo', 'Zhejiang', '315400'),
    '宁波': ('Ningbo', 'Ningbo', 'Zhejiang', '315000'),
    '绍兴柯桥': ('Keqiao, Shaoxing', 'Shaoxing', 'Zhejiang', '312030'),
    '绍兴越城': ('Yuecheng, Shaoxing', 'Shaoxing', 'Zhejiang', '312000'),
    '绍兴': ('Shaoxing', 'Shaoxing', 'Zhejiang', '312000'),
    '温州鹿城': ('Lucheng, Wenzhou', 'Wenzhou', 'Zhejiang', '325000'),
    '温州永嘉县': ('Yongjia County, Wenzhou', 'Wenzhou', 'Zhejiang', '325100'),
    '温州': ('Wenzhou', 'Wenzhou', 'Zhejiang', '325000'),
    '台州温岭': ('Wenling, Taizhou', 'Taizhou', 'Zhejiang', '317500'),
    '台州': ('Taizhou', 'Taizhou', 'Zhejiang', '318000'),
    '嘉兴': ('Jiaxing', 'Jiaxing', 'Zhejiang', '314000'),
    # Anhui
    '合肥包河': ('Baohe, Hefei', 'Hefei', 'Anhui', '230041'),
    '合肥庐阳': ('Luyang, Hefei', 'Hefei', 'Anhui', '230001'),
    '合肥瑶海': ('Yaohai, Hefei', 'Hefei', 'Anhui', '230011'),
    '合肥': ('Hefei', 'Hefei', 'Anhui', '230000'),
    '芜湖': ('Wuhu', 'Wuhu', 'Anhui', '241000'),
    # Henan
    '郑州': ('Zhengzhou', 'Zhengzhou', 'Henan', '450000'),
    # Hubei
    '武汉青山': ('Qingshan, Wuhan', 'Wuhan', 'Hubei', '430080'),
    '武汉武昌': ('Wuchang, Wuhan', 'Wuhan', 'Hubei', '430070'),
    '武汉硚口': ('Qiaokou, Wuhan', 'Wuhan', 'Hubei', '430034'),
    '武汉洪山': ('Hongshan, Wuhan', 'Wuhan', 'Hubei', '430070'),
    '武汉': ('Wuhan', 'Wuhan', 'Hubei', '430000'),
    # Hunan
    '长沙': ('Changsha', 'Changsha', 'Hunan', '410000'),
    # Sichuan
    '成都天府新区': ('Tianfu New Area, Chengdu', 'Chengdu', 'Sichuan', '610213'),
    '成都金牛': ('Jinniu, Chengdu', 'Chengdu', 'Sichuan', '610036'),
    '成都': ('Chengdu', 'Chengdu', 'Sichuan', '610000'),
    # Chongqing
    '重庆': ('Chongqing', 'Chongqing', 'Chongqing', '400000'),
    # Shaanxi
    '西安': ('Xi\'an', 'Xi\'an', 'Shaanxi', '710000'),
    # Guizhou
    '贵阳': ('Guiyang', 'Guiyang', 'Guizhou', '550000'),
    # Yunnan
    '昆明': ('Kunming', 'Kunming', 'Yunnan', '650000'),
    # Guangxi
    '南宁': ('Nanning', 'Nanning', 'Guangxi', '530000'),
    # Hainan
    '海口': ('Haikou', 'Haikou', 'Hainan', '570000'),
    '三亚': ('Sanya', 'Sanya', 'Hainan', '572000'),
    '海南博鳌': ("Bo'ao, Qionghai", 'Hainan', 'Hainan', '571437'),
    '海南': ('Hainan', 'Hainan', 'Hainan', '570000'),
    # Guangdong
    '深圳南山': ('Nanshan, Shenzhen', 'Shenzhen', 'Guangdong', '518052'),
    '深圳宝安': ("Bao'an, Shenzhen", 'Shenzhen', 'Guangdong', '518100'),
    '深圳龙华': ('Longhua, Shenzhen', 'Shenzhen', 'Guangdong', '518110'),
    '深圳龙岗': ('Longgang, Shenzhen', 'Shenzhen', 'Guangdong', '518172'),
    '深圳福田': ('Futian, Shenzhen', 'Shenzhen', 'Guangdong', '518048'),
    '深圳罗湖': ('Luohu, Shenzhen', 'Shenzhen', 'Guangdong', '518001'),
    '深圳盐田': ('Yantian, Shenzhen', 'Shenzhen', 'Guangdong', '518083'),
    '深圳光明': ('Guangming, Shenzhen', 'Shenzhen', 'Guangdong', '518107'),
    '深圳前海': ('Qianhai, Shenzhen', 'Shenzhen', 'Guangdong', '518052'),
    '深圳': ('Shenzhen', 'Shenzhen', 'Guangdong', '518000'),
    '广州天河': ('Tianhe, Guangzhou', 'Guangzhou', 'Guangdong', '510620'),
    '广州越秀': ('Yuexiu, Guangzhou', 'Guangzhou', 'Guangdong', '510600'),
    '广州白云': ('Baiyun, Guangzhou', 'Guangzhou', 'Guangdong', '510400'),
    '广州': ('Guangzhou', 'Guangzhou', 'Guangdong', '510000'),
    '佛山顺德': ('Shunde, Foshan', 'Foshan', 'Guangdong', '528300'),
    '佛山': ('Foshan', 'Foshan', 'Guangdong', '528000'),
    '珠海斗门': ('Doumen, Zhuhai', 'Zhuhai', 'Guangdong', '519100'),
    '珠海': ('Zhuhai', 'Zhuhai', 'Guangdong', '519000'),
    '东莞': ('Dongguan', 'Dongguan', 'Guangdong', '523000'),
    '惠州': ('Huizhou', 'Huizhou', 'Guangdong', '516000'),
    '湛江': ('Zhanjiang', 'Zhanjiang', 'Guangdong', '524000'),
    # Fujian
    '厦门东渡': ('Dongdu, Xiamen', 'Xiamen', 'Fujian', '361009'),
    '厦门同安': ("Tong'an, Xiamen", 'Xiamen', 'Fujian', '361100'),
    '厦门海沧': ('Haicang, Xiamen', 'Xiamen', 'Fujian', '361026'),
    '厦门湖里': ('Huli, Xiamen', 'Xiamen', 'Fujian', '361010'),
    '厦门': ('Xiamen', 'Xiamen', 'Fujian', '361000'),
    '福州晋安': ("Jin'an, Fuzhou", 'Fuzhou', 'Fujian', '350011'),
    '福州长乐': ('Changle, Fuzhou', 'Fuzhou', 'Fujian', '350200'),
    '福州': ('Fuzhou', 'Fuzhou', 'Fujian', '350000'),
    '漳州芗城': ('Xiangcheng, Zhangzhou', 'Zhangzhou', 'Fujian', '363000'),
    '漳州龙海': ('Longhai, Zhangzhou', 'Zhangzhou', 'Fujian', '363100'),
    '漳州开发区': ('Development Zone, Zhangzhou', 'Zhangzhou', 'Fujian', '363107'),
    '漳州': ('Zhangzhou', 'Zhangzhou', 'Fujian', '363000'),
    '泉州': ('Quanzhou', 'Quanzhou', 'Fujian', '362000'),
    # Shanxi
    '太原小店': ('Xiaodian, Taiyuan', 'Taiyuan', 'Shanxi', '030032'),
    '太原': ('Taiyuan', 'Taiyuan', 'Shanxi', '030000'),
    # Hebei
    '保定': ('Baoding', 'Baoding', 'Hebei', '071000'),
    '廊坊': ('Langfang', 'Langfang', 'Hebei', '065000'),
    # Overseas
    '香港': ('Hong Kong', 'Hong Kong SAR', 'China', ''),
    '澳门': ('Macau', 'Macau SAR', 'China', ''),
    '新加坡': ('Singapore', 'Singapore', 'Singapore', ''),
    '英国伦敦': ('London', 'England', 'United Kingdom', ''),
    '德国法兰克福': ('Frankfurt', 'Hesse', 'Germany', ''),
}

def lookup_location(loc_cn: str):
    """
    Given a Chinese location string (e.g. '北京昌平', '深圳南山'),
    return (district_en, city_en, state_en, postal).
    """
    loc_cn = loc_cn.strip()
    
    # Try exact match first
    if loc_cn in LOCATION_MAP:
        return LOCATION_MAP[loc_cn]
    
    # Try progressively shorter prefixes
    for key in sorted(LOCATION_MAP.keys(), key=lambda x: -len(x)):
        if loc_cn.startswith(key) or key in loc_cn:
            return LOCATION_MAP[key]
    
    # Fallback: transliterate
    city_en = transliterate(loc_cn)
    return (city_en, city_en, 'China', '')


def build_address(loc_cn: str, name_cn: str) -> tuple:
    """
    Build English address string from Chinese location.
    Returns (address_en, city, state, postal)
    """
    district_en, city_en, state_en, postal = lookup_location(loc_cn)
    
    # Build address
    parts = []
    if district_en and district_en != city_en:
        parts.append(district_en)
    if city_en:
        parts.append(city_en)
    
    # Determine country
    if state_en in ['Hong Kong SAR', 'Macau SAR']:
        country = 'China'
    elif state_en == 'Singapore':
        country = 'Singapore'
    elif state_en in ['England', 'Scotland']:
        country = 'United Kingdom'
    elif state_en == 'Germany':
        country = 'Germany'
    else:
        country = 'China'
    
    parts.append(country)
    addr_en = ', '.join(parts)
    
    return addr_en, city_en, state_en, postal, country


def detect_activity(biz_type_cn: str, name_cn: str, status_cn: str) -> str:
    """Map Chinese business type to English activity."""
    btype = biz_type_cn if biz_type_cn else ''
    name = name_cn if name_cn else ''
    
    # Map status
    status_map = {'竣工': 'Completed', '在建': 'Under Construction', '拟建': 'Planned', '在营': 'Operating'}
    status_en = status_map.get(status_cn, status_cn)
    
    if '产业园' in btype or '网谷' in name or '意库' in name or '智慧城' in name:
        base = 'Industrial Park / Innovation Hub'
    elif '邮轮' in name or '邮轮' in btype:
        base = 'Cruise Terminal / Port Operations'
    elif '会展' in name or '会展' in btype:
        base = 'Exhibition / Convention Center'
    elif '酒店' in name or 'hotel' in name.lower():
        base = 'Hotel'
    elif '公寓' in name or '租赁' in name or '壹栈' in name or '壹间' in name or '壹棠' in name:
        base = 'Serviced Apartment / Rental Housing'
    elif '花园城' in name or '花园里' in name or '海上世界' in name:
        base = 'Shopping Mall / Commercial Complex'
    elif '住宅' in btype and '商业' in btype and '办公' in btype:
        base = 'Mixed-Use Residential, Commercial and Office Development'
    elif '住宅' in btype and '商业' in btype:
        base = 'Residential and Commercial Development'
    elif '住宅' in btype and '办公' in btype:
        base = 'Residential and Office Development'
    elif '住宅' in btype:
        base = 'Residential Development'
    elif '办公' in btype and '商业' in btype:
        base = 'Commercial and Office Development'
    elif '办公' in btype:
        base = 'Office Development'
    elif '商业' in btype:
        base = 'Commercial Development'
    elif '综合' in btype:
        base = 'Mixed-Use Development'
    elif '总部' in name:
        base = 'Corporate Headquarters / Office'
    else:
        base = 'Real Estate Development'
    
    if status_en and status_en != 'Operating':
        return f"{base} ({status_en})"
    return base


# ── KNOWN OPERATING ASSETS ────────────────────────────────
# These are explicitly mentioned assets from the annual report 
# narrative that are NOT in the main project table.
OPERATING_ASSETS = [
    # --- HQ ---
    {
        'name_cn': '招商蛇口总部', 'location_cn': '深圳南山',
        'name_en': 'CMSK Headquarters',
        'addr_en': 'Building 3, Nanhai Yiku, 6 Xinghua Road, Shekou, Nanshan District, Shenzhen, China',
        'city': 'Shenzhen', 'state': 'Guangdong', 'postal': '518067',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '0755-26688322',
        'url': 'http://001979.wqzcir.com/contact',
        'activity': 'Corporate Headquarters / Office',
    },
    # --- Cruise Terminals ---
    {
        'name_cn': '蛇口邮轮母港 (招商局邮轮母港)', 'location_cn': '深圳南山',
        'name_en': 'Shekou International Cruise Homeport',
        'addr_en': 'Sea World, Shekou, Nanshan District, Shenzhen, China',
        'city': 'Shenzhen', 'state': 'Guangdong', 'postal': '518067',
        'region': 'China', 'lat': '22.4804', 'lng': '113.9212', 'cs': 'not from website',
        'phone': '', 'url': 'https://en.portshekou.com/',
        'activity': 'Cruise Terminal / Port Operations',
    },
    {
        'name_cn': '上海吴淞口国际邮轮港', 'location_cn': '上海宝山',
        'name_en': 'Wusongkou International Cruise Terminal',
        'addr_en': 'Wusong, Baoshan District, Shanghai, China',
        'city': 'Shanghai', 'state': 'Shanghai', 'postal': '200940',
        'region': 'China', 'lat': '31.4062', 'lng': '121.4996', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Cruise Terminal / Port Operations',
    },
    {
        'name_cn': '太子湾国际邮轮母港', 'location_cn': '深圳南山',
        'name_en': 'Prince Bay International Cruise Terminal',
        'addr_en': 'Prince Bay, Shekou, Nanshan District, Shenzhen, China',
        'city': 'Shenzhen', 'state': 'Guangdong', 'postal': '518054',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': 'https://en.portshekou.com/',
        'activity': 'Cruise Terminal / Port Operations',
    },
    # --- Container Port Terminals (portshekou.com) ---
    {
        'name_cn': '蛇口集装箱码头 (SCT)', 'location_cn': '深圳南山',
        'name_en': 'Shekou Container Terminals (SCT)',
        'addr_en': 'Shekou Port, Nanshan District, Shenzhen, China',
        'city': 'Shenzhen', 'state': 'Guangdong', 'postal': '518067',
        'region': 'China', 'lat': '22.4802', 'lng': '113.9185', 'cs': 'not from website',
        'phone': '', 'url': 'https://en.portshekou.com/gsgk/',
        'activity': 'Container Terminal / Port Operations',
    },
    {
        'name_cn': '赤湾集装箱码头 (CCT)', 'location_cn': '深圳南山',
        'name_en': 'Chiwan Container Terminal (CCT)',
        'addr_en': 'Chiwan Port, Nanshan District, Shenzhen, China',
        'city': 'Shenzhen', 'state': 'Guangdong', 'postal': '518067',
        'region': 'China', 'lat': '22.4648', 'lng': '113.9029', 'cs': 'not from website',
        'phone': '', 'url': 'https://en.portshekou.com/gsgk/',
        'activity': 'Container Terminal / Port Operations',
    },
    {
        'name_cn': '妈湾港 (MCT/马旺智慧港)', 'location_cn': '深圳南山',
        'name_en': 'Mawan Smart Port (Mawan Container Terminal)',
        'addr_en': 'Mawan Port, Nanshan District, Shenzhen, China',
        'city': 'Shenzhen', 'state': 'Guangdong', 'postal': '518067',
        'region': 'China', 'lat': '22.4726', 'lng': '113.8967', 'cs': 'not from website',
        'phone': '', 'url': 'https://en.portshekou.com/xmgk/',
        'activity': 'Container Terminal / Smart Port',
    },
    # --- Exhibition Centers ---
    {
        'name_cn': '深圳国际会展中心 (深圳世界)', 'location_cn': '深圳宝安',
        'name_en': 'Shenzhen World (Shenzhen International Convention and Exhibition Center)',
        'addr_en': '1 Zhanlan Avenue, Fuhai Street, Bao\'an District, Shenzhen, China',
        'city': 'Shenzhen', 'state': 'Guangdong', 'postal': '518103',
        'region': 'China', 'lat': '22.6512', 'lng': '113.8229', 'cs': 'not from website',
        'phone': '', 'url': 'https://disc.static.szse.cn/disc/disk03/finalpage/2025-03-17/919df473-7b93-462a-a2cf-a58b4c94adf3.PDF',
        'activity': 'Exhibition / Convention Center',
    },
    {
        'name_cn': '杭州大会展中心', 'location_cn': '杭州',
        'name_en': 'Hangzhou Grand Convention and Exhibition Center',
        'addr_en': 'Hangzhou, Zhejiang, China',
        'city': 'Hangzhou', 'state': 'Zhejiang', 'postal': '310000',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Exhibition / Convention Center',
    },
    {
        'name_cn': '重庆科学会堂', 'location_cn': '重庆',
        'name_en': 'Chongqing Science Hall',
        'addr_en': 'Chongqing, China',
        'city': 'Chongqing', 'state': 'Chongqing', 'postal': '400000',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Exhibition / Convention Center',
    },
    # --- Industrial Parks (separately listed in report, 31 in operation across 17 cities) ---
    {
        'name_cn': '深圳蛇口网谷科创园', 'location_cn': '深圳南山',
        'name_en': 'Shenzhen Shekou Wang Gu Innovation Hub',
        'addr_en': 'Shekou, Nanshan District, Shenzhen, China',
        'city': 'Shenzhen', 'state': 'Guangdong', 'postal': '518067',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Industrial Park / Innovation Hub',
    },
    {
        'name_cn': '深圳南海意库文创园', 'location_cn': '深圳南山',
        'name_en': 'Shenzhen Nanhai Yiku Creative Park',
        'addr_en': '6 Xinghua Road, Shekou, Nanshan District, Shenzhen, China',
        'city': 'Shenzhen', 'state': 'Guangdong', 'postal': '518067',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Industrial Park / Innovation Hub',
    },
    {
        'name_cn': '深圳前海智慧城', 'location_cn': '深圳前海',
        'name_en': 'Shenzhen Qianhai Smart City Industrial Park',
        'addr_en': 'Qianhai Shenzhen-Hong Kong Modern Service Zone, Shenzhen, China',
        'city': 'Shenzhen', 'state': 'Guangdong', 'postal': '518052',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Industrial Park / Innovation Hub',
    },
    {
        'name_cn': '天津招商网谷产业园', 'location_cn': '天津武清',
        'name_en': 'Tianjin China Merchants Wang Gu Industrial Park',
        'addr_en': 'Wuqing District, Tianjin, China',
        'city': 'Tianjin', 'state': 'Tianjin', 'postal': '301700',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Industrial Park / Innovation Hub',
    },
    {
        'name_cn': '上海招商网谷产业园', 'location_cn': '上海浦东',
        'name_en': 'Shanghai China Merchants Wang Gu Industrial Park',
        'addr_en': 'Pudong New Area, Shanghai, China',
        'city': 'Shanghai', 'state': 'Shanghai', 'postal': '200120',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Industrial Park / Innovation Hub',
    },
    {
        'name_cn': '武汉招商意库创意园', 'location_cn': '武汉青山',
        'name_en': 'Wuhan China Merchants Yiku Creative Park',
        'addr_en': 'Qingshan District, Wuhan, Hubei, China',
        'city': 'Wuhan', 'state': 'Hubei', 'postal': '430080',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Industrial Park / Innovation Hub',
    },
    {
        'name_cn': '成都招商智慧城产业园', 'location_cn': '成都',
        'name_en': 'Chengdu China Merchants Smart City Industrial Park',
        'addr_en': 'Chengdu, Sichuan, China',
        'city': 'Chengdu', 'state': 'Sichuan', 'postal': '610000',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Industrial Park / Innovation Hub',
    },
    {
        'name_cn': '北京招商网谷产业园', 'location_cn': '北京朝阳',
        'name_en': 'Beijing China Merchants Wang Gu Industrial Park',
        'addr_en': 'Chaoyang District, Beijing, China',
        'city': 'Beijing', 'state': 'Beijing', 'postal': '100124',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Industrial Park / Innovation Hub',
    },
    {
        'name_cn': '南京招商网谷产业园', 'location_cn': '南京',
        'name_en': 'Nanjing China Merchants Wang Gu Industrial Park',
        'addr_en': 'Nanjing, Jiangsu, China',
        'city': 'Nanjing', 'state': 'Jiangsu', 'postal': '210000',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Industrial Park / Innovation Hub',
    },
    {
        'name_cn': '广州招商产业园', 'location_cn': '广州',
        'name_en': 'Guangzhou China Merchants Industrial Park',
        'addr_en': 'Guangzhou, Guangdong, China',
        'city': 'Guangzhou', 'state': 'Guangdong', 'postal': '510000',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Industrial Park / Innovation Hub',
    },
    # --- Sea World Cultural / Commercial Complexes ---
    {
        'name_cn': '深圳海上世界 (蛇口太子湾花园城)', 'location_cn': '深圳南山',
        'name_en': 'Shenzhen Sea World Cultural and Arts Center',
        'addr_en': 'Sea World Square, Shekou, Nanshan District, Shenzhen, China',
        'city': 'Shenzhen', 'state': 'Guangdong', 'postal': '518067',
        'region': 'China', 'lat': '22.4798', 'lng': '113.9218', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Shopping Mall / Commercial Complex',
    },
    {
        'name_cn': '上海海上世界 (吴淞)', 'location_cn': '上海宝山',
        'name_en': 'Shanghai Sea World (Wusong)',
        'addr_en': 'Wusong, Baoshan District, Shanghai, China',
        'city': 'Shanghai', 'state': 'Shanghai', 'postal': '200940',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Shopping Mall / Commercial Complex',
    },
    # Commercial Malls (花园城/花园里 network)
    {
        'name_cn': '上海曹路招商花园城', 'location_cn': '上海浦东',
        'name_en': 'Shanghai Caolu China Merchants Garden City Mall',
        'addr_en': 'Caolu, Pudong New Area, Shanghai, China',
        'city': 'Shanghai', 'state': 'Shanghai', 'postal': '201209',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Shopping Mall / Commercial Complex',
    },
    {
        'name_cn': '厦门海沧招商花园城', 'location_cn': '厦门海沧',
        'name_en': 'Xiamen Haicang China Merchants Garden City Mall',
        'addr_en': 'Haicang District, Xiamen, Fujian, China',
        'city': 'Xiamen', 'state': 'Fujian', 'postal': '361026',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Shopping Mall / Commercial Complex',
    },
    {
        'name_cn': '长沙观沙岭招商花园城', 'location_cn': '长沙',
        'name_en': 'Changsha Guanshaling China Merchants Garden City Mall',
        'addr_en': 'Changsha, Hunan, China',
        'city': 'Changsha', 'state': 'Hunan', 'postal': '410000',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Shopping Mall / Commercial Complex',
    },
    {
        'name_cn': '湛江招商花园城', 'location_cn': '湛江',
        'name_en': 'Zhanjiang China Merchants Garden City Mall',
        'addr_en': 'Zhanjiang, Guangdong, China',
        'city': 'Zhanjiang', 'state': 'Guangdong', 'postal': '524000',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Shopping Mall / Commercial Complex',
    },
    {
        'name_cn': '苏州琴湖溪里花园城', 'location_cn': '苏州',
        'name_en': 'Suzhou Qinhu Xili Garden City Mall',
        'addr_en': 'Suzhou, Jiangsu, China',
        'city': 'Suzhou', 'state': 'Jiangsu', 'postal': '215000',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Shopping Mall / Commercial Complex',
    },
    {
        'name_cn': '深圳会展湾花园里', 'location_cn': '深圳宝安',
        'name_en': 'Shenzhen Convention Bay Garden Li Mall',
        'addr_en': "Bao'an District, Shenzhen, Guangdong, China",
        'city': 'Shenzhen', 'state': 'Guangdong', 'postal': '518100',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Shopping Mall / Commercial Complex',
    },
    {
        'name_cn': '徐州花园里', 'location_cn': '徐州',
        'name_en': 'Xuzhou Garden Li Mall',
        'addr_en': 'Xuzhou, Jiangsu, China',
        'city': 'Xuzhou', 'state': 'Jiangsu', 'postal': '221000',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Shopping Mall / Commercial Complex',
    },
    {
        'name_cn': '宁波鄞州花园里', 'location_cn': '宁波鄞州',
        'name_en': 'Ningbo Yinzhou Garden Li Mall',
        'addr_en': 'Yinzhou District, Ningbo, Zhejiang, China',
        'city': 'Ningbo', 'state': 'Zhejiang', 'postal': '315100',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Shopping Mall / Commercial Complex',
    },
    {
        'name_cn': '博鳌乐城国际花园城', 'location_cn': '海南博鳌',
        'name_en': "Bo'ao Happy City International Garden Mall",
        'addr_en': "Bo'ao, Qionghai, Hainan, China",
        'city': "Bo'ao", 'state': 'Hainan', 'postal': '571437',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Shopping Mall / Commercial Complex',
    },
    {
        'name_cn': '深圳太子湾招商花园城', 'location_cn': '深圳南山',
        'name_en': 'Shenzhen Prince Bay China Merchants Garden City Mall',
        'addr_en': 'Prince Bay, Shekou, Nanshan District, Shenzhen, China',
        'city': 'Shenzhen', 'state': 'Guangdong', 'postal': '518067',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Shopping Mall / Commercial Complex',
    },
    {
        'name_cn': '成都天府招商花园城', 'location_cn': '成都',
        'name_en': 'Chengdu Tianfu China Merchants Garden City Mall',
        'addr_en': 'Tianfu New Area, Chengdu, Sichuan, China',
        'city': 'Chengdu', 'state': 'Sichuan', 'postal': '610213',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Shopping Mall / Commercial Complex',
    },
    {
        'name_cn': '成都金牛招商花园城', 'location_cn': '成都',
        'name_en': 'Chengdu Jinniu China Merchants Garden City Mall',
        'addr_en': 'Jinniu District, Chengdu, Sichuan, China',
        'city': 'Chengdu', 'state': 'Sichuan', 'postal': '610036',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Shopping Mall / Commercial Complex',
    },
    {
        'name_cn': '珠海斗门招商花园城', 'location_cn': '珠海斗门',
        'name_en': 'Zhuhai Doumen China Merchants Garden City Mall',
        'addr_en': 'Doumen District, Zhuhai, Guangdong, China',
        'city': 'Zhuhai', 'state': 'Guangdong', 'postal': '519100',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Shopping Mall / Commercial Complex',
    },
    {
        'name_cn': '上海传媒港花园里', 'location_cn': '上海徐汇',
        'name_en': 'Shanghai Media Port Garden Li Mall',
        'addr_en': 'Xuhui District, Shanghai, China',
        'city': 'Shanghai', 'state': 'Shanghai', 'postal': '200030',
        'region': 'China', 'lat': '', 'lng': '', 'cs': 'not from website',
        'phone': '', 'url': ANNUAL_RPT,
        'activity': 'Shopping Mall / Commercial Complex',
    },
]


# ── MAIN BUILD ────────────────────────────────────────────

def main():
    # Load parsed projects from PDF
    with open(rf"{TEMP_DIR}\cmsk_projects_parsed.json", 'r', encoding='utf-8') as f:
        pdf_projects = json.load(f)
    
    print(f"Loaded {len(pdf_projects)} projects from PDF")
    
    records = []
    seen_names = set()
    
    fieldnames = [
        'ISSUER_ID', 'ISSUER_NAME',
        'FACILITY_NAME', 'FACILITY_NAME_LOCAL',
        'FACILITY_ADDRESS', 'FACILITY_ADDRESS_LOCAL',
        'CITY', 'STATE', 'POSTAL_CODE',
        'FACILITY_REGION',
        'LATITUDE', 'LONGITUDE', 'coord_source',
        'FACILITY_CONTACT_NUMBER',
        'RELEVANT_URL',
        'ACTIVITY_AT_SOURCE',
    ]
    
    # 1. Add operating assets first
    for asset in OPERATING_ASSETS:
        name_en = asset['name_en']
        if name_en in seen_names:
            continue
        seen_names.add(name_en)
        
        rec = {
            'ISSUER_ID': ISSUER_ID,
            'ISSUER_NAME': ISSUER_NAME,
            'FACILITY_NAME': name_en,
            'FACILITY_NAME_LOCAL': asset['name_cn'],
            'FACILITY_ADDRESS': asset['addr_en'].replace('#', ''),
            'FACILITY_ADDRESS_LOCAL': asset['location_cn'] + ', China',
            'CITY': asset['city'],
            'STATE': asset['state'],
            'POSTAL_CODE': asset['postal'],
            'FACILITY_REGION': asset['region'],
            'LATITUDE': asset['lat'],
            'LONGITUDE': asset['lng'],
            'coord_source': asset['cs'],
            'FACILITY_CONTACT_NUMBER': asset['phone'],
            'RELEVANT_URL': asset['url'],
            'ACTIVITY_AT_SOURCE': asset['activity'],
        }
        records.append(rec)
    
    print(f"Added {len(records)} operating assets")
    
    # 2. Add PDF project table records
    added_from_pdf = 0
    for proj in pdf_projects:
        name_cn = proj.get('name_cn', '').strip()
        loc_cn  = proj.get('location_cn', '').strip()
        btype   = proj.get('biz_type_cn', '')
        status  = proj.get('status_cn', '')
        
        if not name_cn or not loc_cn:
            continue
        
        # Transliterate
        name_en = transliterate(name_cn)
        
        # Normalize name_en to avoid near-duplicates
        if name_en in seen_names:
            continue
        seen_names.add(name_en)
        
        # Build address
        addr_en, city, state, postal, region = build_address(loc_cn, name_cn)
        addr_en = addr_en.replace('#', '')
        
        # Validate address not blank
        if not addr_en or addr_en == ', China':
            addr_en = f"{transliterate(loc_cn)}, China"
        
        activity = detect_activity(btype, name_cn, status)
        
        rec = {
            'ISSUER_ID': ISSUER_ID,
            'ISSUER_NAME': ISSUER_NAME,
            'FACILITY_NAME': name_en,
            'FACILITY_NAME_LOCAL': name_cn,
            'FACILITY_ADDRESS': addr_en,
            'FACILITY_ADDRESS_LOCAL': loc_cn + ', China',
            'CITY': city,
            'STATE': state,
            'POSTAL_CODE': postal,
            'FACILITY_REGION': region,
            'LATITUDE': '',
            'LONGITUDE': '',
            'coord_source': 'not from website',
            'FACILITY_CONTACT_NUMBER': '',
            'RELEVANT_URL': ANNUAL_RPT,
            'ACTIVITY_AT_SOURCE': activity,
        }
        records.append(rec)
        added_from_pdf += 1
    
    print(f"Added {added_from_pdf} projects from PDF table")
    print(f"Total records: {len(records)}")
    
    # 3. Save checkpoint
    checkpoint_path = rf"{TEMP_DIR}\cmsk_checkpoint_v2.csv"
    with open(checkpoint_path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)
    
    print(f"\n✅ Checkpoint saved: {checkpoint_path}")
    print(f"   Total: {len(records)} records (target: 222+)")
    
    # 4. Gap analysis
    if len(records) >= 222:
        print(f"   ✅ Count threshold MET: {len(records)} >= 222")
    else:
        print(f"   ⚠️ Gap: {222 - len(records)} records short")
    
    return records

if __name__ == '__main__':
    records = main()
