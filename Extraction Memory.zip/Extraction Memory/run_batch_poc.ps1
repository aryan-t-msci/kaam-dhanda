# ============================================================================
#  run_batch_poc.ps1  -  PROOF OF CONCEPT
#  codex exec per-issuer orchestrator (fresh context per worker)
# ----------------------------------------------------------------------------
#  PURPOSE: Prove the codex-exec loop works end-to-end on a few issuers before
#  building the full hardened production orchestrator. This runs N workers in
#  parallel, each a fresh `codex exec` invocation that reads prompt.md +
#  WORKER_PROMPT.md and does the FULL extraction workflow (unchanged), writes to
#  staging, and drops a DONE flag. The script then promotes completed issuers.
#
#  This PoC deliberately keeps scope small:
#    - processes only the first $POC_LIMIT issuers from the input
#    - main pass only (no rework pass, no URL-classifier step - uses raw URLs)
#    - simple promotion (copy staging -> output); full scrub is in the prod version
#  If this works, the production script adds: URL classification, rework pass,
#  size-aware throttling, full orchestrator scrub, resume-skip, etc.
#
#  THE THREE WINDOWS BUGS FROM THE EARLIER RUN ARE PRE-FIXED HERE:
#    1. Path-with-spaces quoting in Start-Process (uses -Command "& '...'" form)
#    2. codex banner on stderr no longer fatal ($ErrorActionPreference='Continue')
#    3. real node.exe worker PID tracked (not the PowerShell wrapper PID)
# ----------------------------------------------------------------------------
#  USAGE (all three are optional - defaults below are used if omitted):
#    powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch_poc.ps1" `
#        -Model "gpt-5.4" -Reasoning "high" `
#        -InputFile "C:\path\to\your_input.xlsx"
#
#    # bare run (uses all defaults):
#    powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch_poc.ps1"
#
#    # just override the input file:
#    powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch_poc.ps1" -InputFile "C:\path\to\file.xlsx"
# ============================================================================

param(
    # Model + reasoning for EVERY worker. One explicit setting -> every worker is
    # identical (deterministic, so no silent downgrade). Pass on the command line
    # to override, or leave off to use the defaults here.
    [string]$Model     = "gpt-5.4",
    [string]$Reasoning = "high",

    # Input workbook to process. Override per run with -InputFile.
    [string]$InputFile = "C:\Users\tiwaary\Downloads\asset_completeness_ondemand_batch7&8 - straive copy.xlsx"
)

# ============================ CONFIG ========================================
# These come from the command-line parameters above (with defaults).
$MODEL      = $Model
$REASONING  = $Reasoning
$INPUT_FILE = $InputFile

# Paths (EDIT to your machine if different)
$MEMORY_FOLDER = "C:\Users\tiwaary\OneDrive - MSCI Office 365\Extraction Memory"
$TEMP_ROOT     = "C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp"
$OUTPUT_ROOT   = "C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Output"

# PoC limits
$POC_LIMIT   = 3       # how many issuers to process in this proof of concept
$WORKER_CAP  = 3       # how many run in parallel (keep <= SESSION_CAP-1; 5 in prod)
$POLL_SECONDS = 20     # how often to check for completions

# Codex CLI location (from your environment)
$NodeExe = "node"
$CodexJs = "C:\Users\tiwaary\AppData\Roaming\npm\node_modules\@openai\codex\bin\codex.js"
# ============================================================================


$ErrorActionPreference = "Stop"  # script-level; worker launchers use 'Continue'

function Write-Log($msg) {
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$ts] $msg"
}

# ---- 1. Validate prerequisites --------------------------------------------
Write-Log "PoC starting. Validating prerequisites..."
Write-Log "  Model=$MODEL | Reasoning=$REASONING"
Write-Log "  InputFile=$INPUT_FILE"
if (-not (Test-Path -LiteralPath $CodexJs)) { throw "codex.js not found at: $CodexJs" }
if (-not (Test-Path -LiteralPath (Join-Path $MEMORY_FOLDER 'WORKER_PROMPT.md'))) {
    throw "WORKER_PROMPT.md not found in MEMORY_FOLDER: $MEMORY_FOLDER"
}
if (-not (Test-Path -LiteralPath $INPUT_FILE)) { throw "INPUT_FILE not found: $INPUT_FILE" }
Write-Log "Prerequisites OK. Model=$MODEL/$REASONING  WORKER_CAP=$WORKER_CAP  POC_LIMIT=$POC_LIMIT"

# ---- 2. Create batch workspace --------------------------------------------
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$inputName = [System.IO.Path]::GetFileNameWithoutExtension($INPUT_FILE) -replace '[^A-Za-z0-9_]', '_'
$batchId   = "PoC_Batch_${inputName}_${timestamp}"
$batchTemp = Join-Path $TEMP_ROOT $batchId
$batchOut  = Join-Path $OUTPUT_ROOT $batchId
foreach ($d in @($batchTemp, $batchOut,
                 (Join-Path $batchTemp 'workers'), (Join-Path $batchTemp 'staging'),
                 (Join-Path $batchTemp 'status'),  (Join-Path $batchTemp 'exhaustion_proof'),
                 (Join-Path $batchTemp 'reject'),  (Join-Path $batchTemp 'gap'))) {
    New-Item -ItemType Directory -Force -Path $d | Out-Null
}
Write-Log "Batch workspace: $batchTemp"

# ---- 3. Parse input (first $POC_LIMIT issuers, heaviest first) -------------
# Use a tiny Python helper for robust xlsx parsing (handles Format A and B).
$parseScript = Join-Path $batchTemp '_parse_input.py'
@"
import json, sys, traceback
from pathlib import Path
try:
    from openpyxl import load_workbook
except Exception as e:
    print(json.dumps({'error': f'openpyxl not available: {e}'})); sys.exit(0)

def norm(s):
    return ''.join(ch.lower() for ch in str(s) if ch.isalnum())

def clip(s, n=60):
    s = '' if s is None else str(s)
    s = ' '.join(s.split())
    return s if len(s) <= n else s[:n] + '...'

ID_KEYS    = ('issuerid', 'iid', 'msciissuerid')
NAME_KEYS  = ('companyname', 'issuername', 'company', 'issuer', 'entityname', 'name')
COUNT_KEYS = ('expectedcount', 'totalassets', 'assetcount', 'expectedassets', 'count')
URL_KEYS   = ('relevanturl', 'sourceurl', 'companyurl', 'companywebsite', 'website', 'weburl', 'homepage', 'url', 'link')
ALL_KEYS   = ID_KEYS + NAME_KEYS + COUNT_KEYS + URL_KEYS

def find_header_row(rows, scan=25):
    best_i, best_score = None, 0
    limit = min(scan, len(rows))
    for i in range(limit):
        r = rows[i]
        if not r: continue
        keys = {norm(c) for c in r if c is not None and str(c).strip() != ''}
        if not keys: continue
        score = sum(1 for k in ALL_KEYS if k in keys)
        has_id = any(k in keys for k in ID_KEYS)
        if has_id and score > best_score:
            best_score, best_i = score, i
    if best_i is not None:
        return best_i
    for i in range(limit):
        if rows[i] and any(c is not None and str(c).strip() != '' for c in rows[i]):
            return i
    return 0

def colmap(header_row):
    h = {}
    for idx, c in enumerate(header_row):
        k = norm(c)
        if k and k not in h:
            h[k] = idx
    def pick(keys):
        for k in keys:
            if k in h: return h[k]
        return None
    return h, pick

try:
    inp = Path(r'''$INPUT_FILE''')
    if not inp.exists():
        print(json.dumps({'error': f'input file does not exist: {inp}'})); sys.exit(0)
    wb = load_workbook(inp, read_only=True, data_only=True)
    sheets = wb.sheetnames

    issuers = {}
    sheet_diag = []
    total_id_rows = 0
    iid_rows = 0
    non_iid_samples = []

    for sname in sheets:
        ws = wb[sname]
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            sheet_diag.append({'sheet': clip(sname, 40), 'header_row': None, 'cols': {}, 'headers': [], 'sample': []})
            continue
        hr = find_header_row(rows)
        header_row = rows[hr] if hr < len(rows) else []
        h, pick = colmap(header_row)
        c_id  = pick(ID_KEYS)
        c_nm  = pick(NAME_KEYS)
        c_ct  = pick(COUNT_KEYS)
        c_url = pick(URL_KEYS)
        headers_disp = [clip(c, 60) for c in header_row][:40]
        sample_row = []
        for r in rows[hr+1:]:
            if r and any(c is not None and str(c).strip() != '' for c in r):
                sample_row = [clip(c, 40) for c in r][:40]; break
        sheet_diag.append({'sheet': clip(sname, 40), 'header_row': hr,
                           'cols': {'id': c_id, 'name': c_nm, 'count': c_ct, 'url': c_url},
                           'headers': headers_disp, 'sample': sample_row})
        if c_id is None:
            continue
        for r in rows[hr+1:]:
            if not r: continue
            raw_id = r[c_id] if c_id < len(r) else None
            if raw_id is None or str(raw_id).strip() == '': continue
            sid = str(raw_id).strip()
            total_id_rows += 1
            if not sid.startswith('IID'):
                if len(non_iid_samples) < 5: non_iid_samples.append(clip(sid, 40))
                continue
            iid_rows += 1
            if sid not in issuers:
                issuers[sid] = {'name': '', 'count': None, 'urls': []}
            if c_nm is not None and c_nm < len(r) and r[c_nm] not in (None, ''):
                nm = str(r[c_nm]).strip()
                if nm and not issuers[sid]['name']:
                    issuers[sid]['name'] = nm
            if c_ct is not None and c_ct < len(r) and r[c_ct] not in (None, ''):
                try:
                    ct = int(float(str(r[c_ct]).replace(',', '').strip()))
                    issuers[sid]['count'] = ct if issuers[sid]['count'] is None else max(issuers[sid]['count'], ct)
                except: pass
            if c_url is not None and c_url < len(r) and r[c_url] not in (None, ''):
                url = str(r[c_url]).strip()
                if url and url not in issuers[sid]['urls']:
                    issuers[sid]['urls'].append(url)

    diag = {'sheets': [clip(s, 40) for s in sheets],
            'per_sheet': sheet_diag,
            'rows_with_id': total_id_rows,
            'iid_rows': iid_rows,
            'non_iid_id_samples': non_iid_samples}

    if not issuers:
        print(json.dumps({'error': 'no IID issuers found', 'diagnostics': diag})); sys.exit(0)

    ordered = sorted(issuers.items(), key=lambda kv: (kv[1]['count'] if kv[1]['count'] is not None else -1), reverse=True)
    out = [{'issuer_id': k, 'issuer_name': v['name'], 'count': v['count'], 'urls': v['urls']} for k, v in ordered]
    print(json.dumps(out))
except Exception as e:
    print(json.dumps({'error': f'{type(e).__name__}: {e}', 'traceback': traceback.format_exc()})); sys.exit(0)
"@ | Set-Content -LiteralPath $parseScript -Encoding UTF8

Write-Log "Parsing input workbook..."

# Find a working Python interpreter (the helper shells out to Python for xlsx parsing).
$pythonCmd = $null
foreach ($cand in @('python', 'py', 'python3')) {
    $resolved = Get-Command $cand -ErrorAction SilentlyContinue
    if ($resolved) { $pythonCmd = $resolved.Source; break }
}
if (-not $pythonCmd) {
    throw "No Python interpreter found on PATH (tried python, py, python3). The parse step needs Python + openpyxl. Install Python, then: pip install openpyxl"
}
Write-Log "  using Python: $pythonCmd"

# Run the parser, capturing BOTH stdout and stderr so failures are visible.
$stdOutFile = Join-Path $batchTemp '_parse_stdout.txt'
$stdErrFile = Join-Path $batchTemp '_parse_stderr.txt'
$proc = Start-Process -FilePath $pythonCmd -ArgumentList @("`"$parseScript`"") `
        -NoNewWindow -Wait -PassThru `
        -RedirectStandardOutput $stdOutFile -RedirectStandardError $stdErrFile
$parsedJson = if (Test-Path $stdOutFile) { Get-Content -LiteralPath $stdOutFile -Raw } else { "" }
$parseErr   = if (Test-Path $stdErrFile) { Get-Content -LiteralPath $stdErrFile -Raw } else { "" }

if ([string]::IsNullOrWhiteSpace($parsedJson)) {
    $errTail = if ($parseErr) { (($parseErr -split "\r?\n") | Select-Object -Last 40) -join "`n" } else { "(stderr was empty)" }
    Write-Host "Parser produced NO stdout. Last lines of stderr:"
    Write-Host $errTail
    Write-Host "Full stderr saved to: $stdErrFile"
    throw "Parser produced no output (exit code $($proc.ExitCode)). Most likely openpyxl is not installed for this Python. Full stderr at: $stdErrFile"
}

try {
    $parsed = $parsedJson | ConvertFrom-Json
} catch {
    $head = if ($parsedJson.Length -gt 1500) { $parsedJson.Substring(0,1500) + " ...[truncated - see file]" } else { $parsedJson }
    Write-Host "Could not parse the parser's JSON. First 1500 chars of raw output:"
    Write-Host $head
    Write-Host "Full raw parser output saved to: $stdOutFile"
    throw "Could not parse the parser's JSON output. Full raw output at: $stdOutFile"
}

# A parser ERROR is a SINGLE object carrying a non-empty 'error' field.
# A SUCCESS is a JSON array of issuer objects (ConvertFrom-Json unwraps a
# 1-element array to a single object, handled by the @() wrap below). Testing
# `if ($parsed.error)` directly is unsafe: on an array, member-enumeration
# returns one $null per element, and PowerShell treats a multi-element
# collection as truthy -> a false "parse failed" even though parsing worked.
$parserError = ''
if ($parsed -isnot [System.Array]) {
    if (@($parsed.PSObject.Properties.Name) -contains 'error') {
        $parserError = "$($parsed.error)".Trim()
    }
}
if ($parserError -ne '') {
    Write-Host ""
    Write-Host "PARSE FAILED: $parserError"
    if ((@($parsed.PSObject.Properties.Name) -contains 'diagnostics') -and $parsed.diagnostics) {
        Write-Host "--- diagnostics (bounded; safe to paste back) ---"
        $parsed.diagnostics | ConvertTo-Json -Depth 6
        Write-Host "-------------------------------------------------"
    }
    Write-Host "Full raw parser output saved to: $stdOutFile"
    throw "Parse failed: $parserError"
}

$queue = @($parsed) | Select-Object -First $POC_LIMIT
if ($queue.Count -eq 0) {
    throw "Parser returned 0 issuers. Check the input file format / sheet names. Raw output: $parsedJson"
}
Write-Log "Parsed. Processing first $($queue.Count) issuers (of $(@($parsed).Count) total)."
foreach ($it in $queue) {
    Write-Log "  - $($it.issuer_id) | $($it.issuer_name) | target=$($it.count) | urls=$($it.urls.Count)"
}

# ---- 4. Worker spawn helper (BUGS PRE-FIXED) ------------------------------
function Spawn-Worker($issuer, $workerId) {
    $iid = $issuer.issuer_id
    $safeName = ($issuer.issuer_name -replace '[\\/:*?"<>|]', '_')
    $queueFile = Join-Path $batchTemp "workers\${iid}_queue.md"
    $logFile   = Join-Path $batchTemp "workers\${iid}_worker.log"
    $lastFile  = Join-Path $batchTemp "workers\${iid}_last.txt"

    # Build the worker queue file (exact format from ORCHESTRATOR_PROMPT O-1b)
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine("# Worker Queue - Single Issuer")
    [void]$sb.AppendLine("# Batch: $batchId")
    [void]$sb.AppendLine("# Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') | Pass: main")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("From MEMORY_FOLDER, read and execute:")
    [void]$sb.AppendLine("1. prompt.md")
    [void]$sb.AppendLine("2. WORKER_PROMPT.md")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("## PARAMETERS")
    [void]$sb.AppendLine("ISSUER_ID     : $iid")
    [void]$sb.AppendLine("ISSUER_NAME   : $($issuer.issuer_name)")
    [void]$sb.AppendLine("COUNT         : $($issuer.count)")
    [void]$sb.AppendLine("WORKER_ID     : $workerId")
    [void]$sb.AppendLine("MODEL         : $MODEL")
    [void]$sb.AppendLine("REASONING     : $REASONING")
    [void]$sb.AppendLine("MEMORY_FOLDER : $MEMORY_FOLDER")
    [void]$sb.AppendLine("BATCH_TEMP    : $batchTemp")
    [void]$sb.AppendLine("BATCH_OUTPUT  : $batchOut")
    [void]$sb.AppendLine("STAGING_DIR   : $(Join-Path $batchTemp 'staging')")
    [void]$sb.AppendLine("STATUS_DIR    : $(Join-Path $batchTemp 'status')")
    [void]$sb.AppendLine("PROOF_DIR     : $(Join-Path $batchTemp 'exhaustion_proof')")
    [void]$sb.AppendLine("REJECT_DIR    : $(Join-Path $batchTemp 'reject')")
    [void]$sb.AppendLine("GAP_DIR       : $(Join-Path $batchTemp 'gap')")
    [void]$sb.AppendLine("BATCH_ID      : $batchId")
    [void]$sb.AppendLine("PASS_TYPE     : main")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("## URLS")
    [void]$sb.AppendLine("| URL | URL_Type | URL_Purpose | Confidence |")
    [void]$sb.AppendLine("|-----|----------|-------------|------------|")
    foreach ($u in $issuer.urls) {
        $cleanU = $u -replace '\|', '%7C'
        [void]$sb.AppendLine("| $cleanU | unknown | Unknown | 0.5 |")
    }
    Set-Content -LiteralPath $queueFile -Value $sb.ToString() -Encoding UTF8

    # Generate a launcher script. BUG FIX #2: ErrorActionPreference=Continue so
    # codex's stderr banner is not treated as a fatal NativeCommandError.
    $launcherFile = Join-Path $batchTemp "workers\${iid}_launch.ps1"
    $launcher = @"
`$ErrorActionPreference = 'Continue'
Get-Content -Raw -LiteralPath '$queueFile' | & '$NodeExe' '$CodexJs' exec - --skip-git-repo-check --dangerously-bypass-approvals-and-sandbox -m '$MODEL' -c 'model_reasoning_effort="$REASONING"' -C '$MEMORY_FOLDER' -o '$lastFile' *> '$logFile'
"@
    Set-Content -LiteralPath $launcherFile -Value $launcher -Encoding UTF8

    # BUG FIX #1: launch with -Command "& '...'" (robust for paths with spaces),
    # not -File (which truncates at the first space in OneDrive paths).
    $argList = @('-NoProfile','-ExecutionPolicy','Bypass','-Command', "& '$launcherFile'")
    $proc = Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -WindowStyle Hidden -PassThru

    # BUG FIX #3: resolve the real node.exe worker PID (not the wrapper PID),
    # by matching the unique _last.txt marker in its command line.
    $marker = "${iid}_last.txt"
    $nodePid = $null
    for ($i = 0; $i -lt 12; $i++) {
        Start-Sleep -Milliseconds 500
        $np = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
              Where-Object { $_.Name -eq 'node.exe' -and $_.CommandLine -like "*$marker*" } |
              Select-Object -First 1
        if ($np) { $nodePid = [int]$np.ProcessId; break }
    }
    Write-Log "  spawned worker $workerId for $iid ($($issuer.issuer_name)) | node pid=$nodePid"
    return [pscustomobject]@{
        issuer_id = $iid; worker_id = $workerId; node_pid = $nodePid
        launcher_pid = $proc.Id; spawned_at = (Get-Date)
    }
}

# ---- 5. Rolling pool: spawn up to WORKER_CAP, promote on DONE, refill ------
$statusDir  = Join-Path $batchTemp 'status'
$stagingDir = Join-Path $batchTemp 'staging'
$queueIndex = 0
$active = @{}   # iid -> worker info
$promoted = @{} # iid -> $true

function Promote-Issuer($iid, $name) {
    $safeName = ($name -replace '[\\/:*?"<>|]', '_')
    # find the staging CSV for this issuer (worker names it {IID}_{NAME}.csv)
    $cand = Get-ChildItem -LiteralPath $stagingDir -Filter "*$iid*.csv" -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $cand) { Write-Log "  ! $iid completed but no staging CSV found"; return $false }
    $dest = Join-Path $batchOut $cand.Name
    Copy-Item -LiteralPath $cand.FullName -Destination $dest -Force
    $rows = (Get-Content -LiteralPath $dest | Measure-Object -Line).Lines - 1
    Write-Log "  promoted $iid -> output ($rows rows)"
    return $true
}

Write-Log "Starting rolling pool (cap=$WORKER_CAP)..."
# initial fill
while ($active.Count -lt $WORKER_CAP -and $queueIndex -lt $queue.Count) {
    $it = $queue[$queueIndex]; $queueIndex++
    $w = Spawn-Worker $it ("{0:D2}" -f $queueIndex)
    $active[$it.issuer_id] = $w
}

# monitor loop
while ($active.Count -gt 0) {
    Start-Sleep -Seconds $POLL_SECONDS
    $doneNow = @()
    foreach ($iid in @($active.Keys)) {
        $doneFlag = Join-Path $statusDir "${iid}_DONE.flag"
        if (Test-Path -LiteralPath $doneFlag) { $doneNow += $iid }
    }
    foreach ($iid in $doneNow) {
        $name = ($queue | Where-Object { $_.issuer_id -eq $iid }).issuer_name
        Promote-Issuer $iid $name | Out-Null
        $promoted[$iid] = $true
        $active.Remove($iid)
        # refill from queue with a FRESH worker
        if ($queueIndex -lt $queue.Count) {
            $it = $queue[$queueIndex]; $queueIndex++
            $w = Spawn-Worker $it ("{0:D2}" -f $queueIndex)
            $active[$it.issuer_id] = $w
        }
    }
    $doneCount = $promoted.Count
    Write-Log "[MONITOR] promoted=$doneCount/$($queue.Count) | active=$($active.Count) | queued=$([Math]::Max(0,$queue.Count-$queueIndex))"
}

Write-Log "PoC complete. Promoted $($promoted.Count)/$($queue.Count) issuers."
Write-Log "Output folder: $batchOut"
Write-Log "Inspect staging/status/logs under: $batchTemp"
