"""
KTB Exchange Booth Scraper
Checks if there are Exchange Booths (service type 2) not in the existing collection.
"""
import asyncio, json, re, sys
from pathlib import Path
from playwright.async_api import async_playwright

sys.stdout.reconfigure(encoding='utf-8')

BASE_URL      = "https://krungthai.com"
LOCATION_URL  = f"{BASE_URL}/en/contact-us/ktb-location"
SERVICE_TYPES = [2]   # Exchange Booths only

TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Temp")
OUT_JSON = TEMP_DIR / "ktb_exchange_booths.json"


def clean_address(addr_html: str) -> str:
    clean = re.sub(r'<[^>]+>', ' ', addr_html)
    clean = re.sub(r'\s+', ' ', clean).strip()
    return clean.rstrip(', ').strip()


def parse_record(item: dict, province_name: str) -> dict:
    addr_html = item.get('Address', '')
    full_address = clean_address(addr_html)
    if 'Remark :' in full_address:
        full_address = full_address[:full_address.index('Remark :')].strip().rstrip(',').strip()

    parts = [p.strip() for p in full_address.split(',') if p.strip()]
    city = state = postal_code = ''
    if parts:
        for i in range(len(parts) - 1, -1, -1):
            if re.match(r'^\d{4,6}$', parts[i].strip()):
                postal_code = parts[i].strip()
                if i > 0:
                    state = parts[i-1].strip()
                    city = state
                break
    if not state and province_name:
        state = province_name
        city = province_name

    lat_str = item.get('STR_SERVICE_POINT_MAP_X', '').strip()
    lon_str = item.get('STR_SERVICE_POINT_MAP_Y', '').strip()
    try:
        lat = float(lat_str) if lat_str else None
        lon = float(lon_str) if lon_str else None
    except ValueError:
        lat = lon = None

    phones = item.get('lstConnectPhone', []) or []
    phone = ''
    for ph in phones:
        if not ph.get('isFax', False) and ph.get('Title'):
            phone = ph['Title']
            break

    relevant_url = f"https://maps.google.com/maps?q={lat},{lon}" if (lat and lon) else LOCATION_URL
    bc_str = item.get('BranchCode', '')
    m = re.search(r'\d+', bc_str or '')

    return {
        'FACILITY_NAME': item.get('Branch', '').strip(),
        'FACILITY_ADDRESS': full_address,
        'CITY': city,
        'STATE': state,
        'POSTAL_CODE': postal_code,
        'FACILITY_REGION': 'Thailand',
        'LATITUDE': lat,
        'LONGITUDE': lon,
        'FACILITY_CONTACT_NUMBER': phone,
        'RELEVANT_URL': relevant_url,
        'BUSINESS_ACTIVITY': 'Foreign Exchange',
        'SERVICE_TYPE': 2,
        '_id': item.get('INT_SERVICE_POINT_MAIN_ID'),
        '_province': province_name,
    }


async def main():
    all_records = []
    seen_ids = set()

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True, channel='msedge')
        context = await browser.new_context(
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            extra_http_headers={'Accept-Language': 'en-US,en;q=0.9'}
        )
        page = await context.new_page()

        print(f"Loading {LOCATION_URL}...")
        await page.goto(LOCATION_URL, timeout=45000, wait_until='networkidle')
        await asyncio.sleep(3)

        try:
            accept_btn = await page.query_selector('#onetrust-accept-btn-handler')
            if accept_btn:
                await accept_btn.click()
                await asyncio.sleep(1)
        except Exception:
            pass

        provinces = await page.evaluate("""
            () => {
                const sel = document.getElementById('selectval3');
                if (!sel) return [];
                return Array.from(sel.options)
                    .filter(o => o.value && o.value !== '0')
                    .map(o => ({id: parseInt(o.value), name: o.text.trim()}));
            }
        """)
        print(f"Provinces: {len(provinces)}")

        for i, prov in enumerate(provinces):
            prov_id = prov['id']
            prov_name = prov['name']

            api_response_data = {'data': None, 'event': asyncio.Event()}

            async def handle_response(response):
                if 'getservicelocationresult' in response.url:
                    try:
                        body = await response.body()
                        text = body.decode('utf-8', errors='replace')
                        if text.strip().startswith('{') or text.strip().startswith('['):
                            api_response_data['data'] = json.loads(text)
                    except Exception as e:
                        pass
                    api_response_data['event'].set()

            page.on("response", handle_response)

            try:
                await page.select_option('#selectval1', '2')  # Exchange Booths
                await asyncio.sleep(0.3)
                await page.select_option('#selectval3', str(prov_id))
                await asyncio.sleep(0.5)
                await page.click('#btnSearch')
                try:
                    await asyncio.wait_for(api_response_data['event'].wait(), timeout=8)
                except asyncio.TimeoutError:
                    pass
            finally:
                page.remove_listener("response", handle_response)

            data = api_response_data.get('data')
            if not data:
                continue

            items = data.get('ListItems', [])
            for item in items:
                uid = item.get('INT_SERVICE_POINT_MAIN_ID')
                if uid and uid not in seen_ids:
                    seen_ids.add(uid)
                    record = parse_record(item, prov_name)
                    all_records.append(record)

            if items:
                print(f"  [{i+1}/{len(provinces)}] {prov_name}: {len(items)} exchange booths")

            await asyncio.sleep(0.4)

        await browser.close()

    with open(OUT_JSON, 'w', encoding='utf-8') as f:
        json.dump(all_records, f, ensure_ascii=False, indent=2, default=str)

    print(f"\nTotal exchange booths found: {len(all_records)}")
    for r in all_records:
        print(f"  [{r['_province']}] {r['FACILITY_NAME']} | {r['CITY']}")

    return all_records


if __name__ == "__main__":
    asyncio.run(main())
