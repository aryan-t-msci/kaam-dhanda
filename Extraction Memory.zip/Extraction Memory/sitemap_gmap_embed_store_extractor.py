"""
Sitemap + Google Maps embed/static-map store extractor.

Platform patterns: P-06 (sitemap URL enumeration) + P-21 (GMap iframe / static map coords).

Handles JS-rendered retail store locators that:
- Publish store detail URLs in a sitemap XML (e.g. sitemap/Store.xml)
- Render address/phone/activity on per-store detail pages (Playwright required)
- Expose coordinates via Google Maps embed iframe and/or static map thumbnail + map-click

Configure ISSUER_ID, BASE_URL, SITEMAP_STORE_URL, and output paths in the config block.
Usage: python sitemap_gmap_embed_store_extractor.py
"""

from __future__ import annotations

import csv
import json
import re
import time
import unicodedata
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from urllib.parse import urljoin

import httpx
from playwright.sync_api import sync_playwright

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Edit this block for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_ID = "IID000000005492828"
ISSUER_NAME = "Bob's Discount Furniture, Inc"
BASE_URL = "https://www.mybobs.com"
SITEMAP_STORE_URL = f"{BASE_URL}/sitemap/Store.xml"
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\In House Issuers\Output")
TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\In House Issuers\Temp")
COUNTRY = "United States"
COUNTRY_ISO3 = "USA"
SOURCE_TYPE = "COMPANY WEBSITE"
ACTIVITY_DEFAULT = "Furniture retail store"
# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════

CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "PHONE",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
]

NS = {"sm": "http://www.sitemaps.org/schemas/sitemap/0.9"}
COORD_EMBED_RE = re.compile(r"!2m2!1d([\d.-]+)!2d([\d.-]+)")
COORD_AT_RE = re.compile(r"@(-?\d+\.\d+),(-?\d+\.\d+)")
PHONE_RE = re.compile(r"\((\d{3})\)\s*(\d{3})-(\d{4})")
ZIP_RE = re.compile(r"\b(\d{5})(?:-\d{4})?\b")


def ascii_text(value: str) -> str:
    value = value.replace("\u00a0", " ").replace("\u2019", "'").replace("\u2013", "-")
    return unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")


def clean(value: str) -> str:
    return re.sub(r"\s+", " ", value.replace("\r", " ").replace("\n", " ")).strip()


def geocode_friendly(value: str) -> str:
    return clean(value.replace("#", ""))


def fetch_store_urls() -> List[str]:
    r = httpx.get(SITEMAP_STORE_URL, timeout=30, follow_redirects=True)
    r.raise_for_status()
    root = ET.fromstring(r.text)
    urls = []
    for loc in root.findall(".//sm:loc", NS):
        url = loc.text.strip()
        if "/store/" in url and url.rstrip("/") != f"{BASE_URL}/stores":
            urls.append(url)
    return sorted(set(urls))


def parse_coords_from_iframes(iframes: List[str]) -> Tuple[Optional[float], Optional[float]]:
    for src in iframes:
        if "google.com/maps/embed" in src:
            m = COORD_EMBED_RE.search(src)
            if m:
                lat, lon = float(m.group(1)), float(m.group(2))
                return lat, lon
    return None, None


def parse_coords_from_google_maps_url(url: str) -> Tuple[Optional[float], Optional[float]]:
    m = COORD_AT_RE.search(url)
    if m:
        return float(m.group(1)), float(m.group(2))
    return None, None


def extract_activities(page_text: str, activity_links: List[str]) -> str:
    activities = []
    for label in ["Outlet Location", "Pickup Location"]:
        if label in activity_links or label.replace(" ", "") in page_text.replace(" ", ""):
            if label == "Outlet Location" and "Outlet Location" in page_text:
                activities.append(label)
            elif label == "Pickup Location" and "Pickup Location" in page_text:
                activities.append(label)
    # dedupe preserve order from links first
    ordered = []
    for link_text in activity_links:
        t = clean(link_text)
        if t and t not in ordered:
            ordered.append(t)
    if not ordered:
        if "Outlet Location" in page_text:
            ordered.append("Outlet Location")
        if "Pickup Location" in page_text:
            ordered.append("Pickup Location")
    return ", ".join(ordered) if ordered else ACTIVITY_DEFAULT


def parse_address_parts(street: str, city_line: str) -> Tuple[str, str, str, str]:
    street = geocode_friendly(ascii_text(street)).rstrip(",")
    city_line = geocode_friendly(ascii_text(city_line))
    postcode = ""
    m = ZIP_RE.search(city_line)
    if m:
        postcode = m.group(1)
    parts = [p.strip() for p in city_line.split(",")]
    city = parts[0] if parts else ""
    state = parts[1].strip() if len(parts) > 1 else ""
    if not postcode and len(parts) > 2:
        z = ZIP_RE.search(parts[-1])
        if z:
            postcode = z.group(1)
    full_address = clean(f"{street}, {city_line}")
    return full_address, city, state, postcode


def validate_row(row: Dict) -> Tuple[Dict, str]:
    qa = row.get("QA_flag", "") or ""
    if not row.get("ACTIVITY_AT_ASSET"):
        row["ACTIVITY_AT_ASSET"] = ACTIVITY_DEFAULT
        qa = "fixed" if not qa else qa
    if row.get("coord_source") not in ("website", "Not from website"):
        row["coord_source"] = "website" if row.get("LATITUDE") and row.get("LONGITUDE") else "Not from website"
        qa = "fixed" if not qa else qa
    if not row.get("CITY"):
        qa = "CITY" if not qa else f"{qa}|CITY"
    return row, qa


def extract_store_page(page, url: str) -> Optional[Dict]:
    try:
        page.goto(url, wait_until="load", timeout=45000)
        page.wait_for_timeout(4000)
    except Exception as e:
        print(f"  FAIL load {url}: {e}")
        return None

    data = page.evaluate(
        """() => {
        const h1 = document.querySelector('main h1');
        let storeName = '';
        let cityHeading = '';
        if (h1) {
          const ps = [...h1.querySelectorAll('p')].map(p => p.textContent.trim());
          storeName = ps.join(' | ');
          cityHeading = ps.length > 1 ? ps[1] : '';
        }
        const activityLinks = [...document.querySelectorAll('main a')]
          .filter(a => ['Outlet Location','Pickup Location'].includes(a.textContent.trim()))
          .map(a => a.textContent.trim());
        const addrHeading = [...document.querySelectorAll('main h2')]
          .find(h => h.textContent.trim() === 'Address');
        let street = '';
        let cityLine = '';
        if (addrHeading && addrHeading.parentElement) {
          const addrBlock = addrHeading.nextElementSibling;
          if (addrBlock) {
            const paras = [...addrBlock.querySelectorAll('p')];
            if (paras.length >= 2) {
              street = paras[0].textContent.trim();
              cityLine = paras[1].textContent.trim();
            } else {
              const text = addrBlock.textContent.trim();
              const lines = text.split(/\\n+/).map(s => s.trim()).filter(Boolean);
              if (lines.length >= 2) {
                street = lines[0];
                cityLine = lines[1];
              }
            }
          }
        }
        const phoneLink = document.querySelector('main a[href^="tel:"]');
        const phone = phoneLink ? phoneLink.textContent.trim() : '';
        const iframes = [...document.querySelectorAll('iframe')].map(f => f.src || '');
        return {
          storeName, cityHeading, activityLinks, street, cityLine, phone, iframes,
          bodyText: document.body.innerText.slice(0, 800)
        };
    }"""
    )

    if not data.get("street") or not data.get("cityLine"):
        print(f"  SKIP no address: {url}")
        return None

    full_address, city, state, postcode = parse_address_parts(data["street"], data["cityLine"])
    city_display = clean(ascii_text(data.get("cityHeading", city).split(",")[0]))
    if not city_display:
        city_display = city

    lat, lon = parse_coords_from_iframes(data.get("iframes", []))
    coord_source = "website" if lat and lon else "Not from website"

    # Fallback: click map pin / get directions if no embed coords
    if not lat or not lon:
        try:
            # Try clicking google map image link
            map_img = page.locator('img[alt="googleMap"]').first
            if map_img.count():
                with page.context.expect_page(timeout=8000) as new_page_info:
                    map_img.click()
                new_page = new_page_info.value
                new_page.wait_for_load_state("domcontentloaded", timeout=15000)
                lat, lon = parse_coords_from_google_maps_url(new_page.url)
                new_page.close()
                if lat and lon:
                    coord_source = "website"
        except Exception:
            pass

    location_base = "Bob's Discount Furniture & Mattress Store"
    location_name = ascii_text(f"{location_base} - {city_display}")

    activities = extract_activities(data.get("bodyText", ""), data.get("activityLinks", []))

    phone = clean(ascii_text(data.get("phone", "")))
    m = PHONE_RE.search(phone)
    if m:
        phone = f"({m.group(1)}) {m.group(2)}-{m.group(3)}"

    row = {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": location_name,
        "LOCATION_ADDRESS": full_address,
        "LATITUDE": f"{lat:.7f}" if lat else "",
        "LONGITUDE": f"{lon:.7f}" if lon else "",
        "COUNTRY": COUNTRY,
        "COUNTRY_ISO3": COUNTRY_ISO3,
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city_display,
        "PHONE": phone,
        "SOURCE_URL": url,
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": activities,
        "coord_source": coord_source,
        "QA_flag": "",
    }
    row, qa = validate_row(row)
    row["QA_flag"] = qa
    return row


def main():
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    urls = fetch_store_urls()
    print(f"Found {len(urls)} store URLs in sitemap")

    progress_file = TEMP_DIR / f"{ISSUER_ID}_progress.json"
    checkpoint_file = TEMP_DIR / f"{ISSUER_ID}_checkpoint.csv"
    done_urls = set()
    rows: List[Dict] = []

    if progress_file.exists():
        prog = json.loads(progress_file.read_text(encoding="utf-8"))
        done_urls = set(prog.get("done_urls", []))
        if checkpoint_file.exists():
            with checkpoint_file.open(encoding="utf-8") as f:
                rows = list(csv.DictReader(f))

    remaining = [u for u in urls if u not in done_urls]
    print(f"Remaining: {len(remaining)} (already done: {len(done_urls)})")

    start = time.time()
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        )
        page = context.new_page()

        for i, url in enumerate(remaining, 1):
            print(f"[{i}/{len(remaining)}] {url}")
            row = extract_store_page(page, url)
            if row:
                rows.append(row)
            done_urls.add(url)

            if i % 20 == 0:
                progress_file.write_text(
                    json.dumps({"done_urls": list(done_urls), "count": len(rows)}, indent=2),
                    encoding="utf-8",
                )
                with checkpoint_file.open("w", newline="", encoding="utf-8") as f:
                    w = csv.DictWriter(f, fieldnames=CSV_COLUMNS, extrasaction="ignore")
                    w.writeheader()
                    w.writerows(rows)
                print(f"  checkpoint: {len(rows)} rows")

        browser.close()

    # Dedupe by SOURCE_URL
    seen = set()
    unique_rows = []
    for r in rows:
        if r["SOURCE_URL"] not in seen:
            seen.add(r["SOURCE_URL"])
            unique_rows.append(r)

    out_file = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
    with out_file.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=CSV_COLUMNS, extrasaction="ignore")
        w.writeheader()
        w.writerows(unique_rows)

    summary = {
        "issuer_id": ISSUER_ID,
        "total_urls": len(urls),
        "rows": len(unique_rows),
        "with_coords": sum(1 for r in unique_rows if r.get("LATITUDE")),
        "elapsed_sec": round(time.time() - start, 1),
    }
    (TEMP_DIR / f"{ISSUER_ID}_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    progress_file.write_text(json.dumps({"done_urls": list(done_urls), "count": len(unique_rows)}, indent=2), encoding="utf-8")

    print(json.dumps(summary, indent=2))
    print(f"Wrote {out_file}")


if __name__ == "__main__":
    main()
