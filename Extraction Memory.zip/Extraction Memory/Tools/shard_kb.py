#!/usr/bin/env python3
"""
shard_kb.py - one-time bootstrap: split the monolithic KB_DETAIL.md into per-record
files under KB/, so a worker opens only the 1-2 small records it needs (via KB_INDEX.md)
instead of reading the whole ~91K-token monolith into context on every task.

LOSSLESS: bytes are preserved exactly (records concatenated in file order reproduce the
original byte-for-byte).

Run:  python Tools/shard_kb.py        (resolves paths from its own location; any cwd is fine)

SELF-SKIPPING: if KB/ already contains record shards this does nothing, because from then
on the workers maintain KB/ directly - they write each new learned record straight into KB/,
NOT into the (now frozen) monolith. Pass --force to wipe KB/ and regenerate from KB_DETAIL.md;
only do that on a deliberate re-bootstrap, since it deletes any shard record the monolith
does not contain.
"""
import re, sys, pathlib, statistics

# Resolve paths relative to MEMORY_FOLDER (this script lives in MEMORY_FOLDER/Tools/),
# so it works no matter what the current working directory is.
BASE = pathlib.Path(__file__).resolve().parent.parent
SRC = BASE / "KB_DETAIL.md"
OUT = BASE / "KB"
FORCE = "--force" in sys.argv[1:]

def main():
    # Self-skip guard (checked FIRST): once KB/ holds per-record shards, the workers maintain
    # them directly (each new learned record is written straight into KB/). Regenerating from
    # the frozen monolith would DELETE any record the monolith does not contain - silent KB
    # loss. So we only build when KB/ is empty/absent, unless --force is given. Checking this
    # before requiring KB_DETAIL.md also means the per-run bootstrap stays a clean no-op even
    # after you retire the monolith to Archive\.
    if OUT.exists() and not FORCE:
        existing = [p for p in OUT.glob("*.md") if re.match(r"^[A-Z]+-\d", p.name)]
        if existing:
            print(f"KB/ already sharded ({len(existing)} record shards) - skipping (workers maintain KB/ directly).")
            print("Pass --force to wipe KB/ and regenerate from KB_DETAIL.md "
                  "(WARNING: drops any shard record not present in the monolith).")
            return
    # Reaching here means KB/ is empty/absent (first-time bootstrap) or --force was given:
    # we must (re)build from the monolith, so it has to exist.
    if not SRC.exists():
        print("KB_DETAIL.md not found next to this script (needed only to build KB/ the first time; "
              "expected at MEMORY_FOLDER/KB_DETAIL.md)."); sys.exit(1)
    raw = SRC.read_bytes()
    text = raw.decode("latin-1")               # 1:1 byte map; re-encode == original
    lines = text.splitlines(keepends=True)

    is_heading = lambda l: bool(re.match(r"^#{1,2} ", l))
    def rec_id(l):
        m = re.match(r"^##\s+([A-Z]+-\d+[a-z]?)\b", l)   # real records only; excludes ## R-XX / ## P-XX templates
        return m.group(1) if m else None

    bounds = [i for i,l in enumerate(lines) if is_heading(l)]
    segs = []
    if not bounds or bounds[0] != 0:
        segs.append((0, bounds[0] if bounds else len(lines), None))
    for k,b in enumerate(bounds):
        e = bounds[k+1] if k+1 < len(bounds) else len(lines)
        segs.append((b, e, rec_id(lines[b])))

    # lossless guarantee
    recon = "".join("".join(lines[s:e]) for s,e,_ in segs)
    assert recon == text and recon.encode("latin-1") == raw, "LOSSLESS CHECK FAILED - aborting"

    records = [(rid,s,e) for (s,e,rid) in segs if rid]
    ids = [r[0] for r in records]
    assert len(set(ids)) == len(ids), f"duplicate record ids: {[i for i in ids if ids.count(i)>1]}"
    # invariant: every uncaptured '## [A-Z]+-' heading must be a template (id core is non-numeric, e.g. R-XX)
    captured_ids = set(ids)
    for l in (x for x in lines if re.match(r"^##\s+[A-Z]+-", x)):
        m = re.match(r"^##\s+([A-Z]+-\S+)", l)
        hid = m.group(1) if m else ""
        if hid not in captured_ids:
            assert not re.match(r"^[A-Z]+-\d", hid), f"real record dropped: {l.strip()}"

    OUT.mkdir(exist_ok=True)
    for f in OUT.glob("*.md"): f.unlink()       # clean regenerate
    sizes = []
    for rid,s,e in records:
        b = "".join(lines[s:e]).encode("latin-1")
        (OUT/f"{rid}.md").write_bytes(b); sizes.append(len(b))
    front = "".join("".join(lines[s:e]) for s,e,rid in segs if not rid).encode("latin-1")
    (OUT/"_FRONTMATTER.md").write_bytes(front)

    print(f"OK - lossless. {len(records)} record shards written to KB/ "
          f"(P={sum(i.startswith('P-') for i in ids)} U={sum(i.startswith('U-') for i in ids)} R={sum(i.startswith('R-') for i in ids)})")
    print(f"median shard {int(statistics.median(sizes))}B (~{int(statistics.median(sizes)/4)} tok), max {max(sizes)}B; "
          f"_FRONTMATTER.md {len(front)}B")
    print(f"old wholesale read ~{len(raw)//4:,} tok  ->  new per-lookup ~{int(2*statistics.median(sizes)/4):,} tok")

if __name__ == "__main__":
    main()
