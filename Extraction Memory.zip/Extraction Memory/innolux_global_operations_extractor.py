"""
Innolux global-operations extractor.

Pulls structured location data from the official Innolux contacts endpoint and
exports global operation rows. Category B reusable script.
"""

from __future__ import annotations

import csv
from pathlib import Path

import requests


ISSUER_ID = "IID000000002151318"
ISSUER_NAME = "Innolux Corporation"
SOURCE_URL = "https://www.innolux.com/api/CRUD/GetList?nav_id=57&lang=EN"
OUTPUT_DIR = Path(".")
OUTPUT_CSV = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"

HEADERS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
]


def fetch_rows() -> list[dict]:
    response = requests.get(
        SOURCE_URL,
        timeout=30,
        verify=False,
        headers={"User-Agent": "Mozilla/5.0"},
    )
    response.raise_for_status()
    payload = response.json()
    rows: list[dict] = []
    for section in payload["list"]:
        title = section["title"].strip()
        if "Japan" in title:
            continue
        for spot in section.get("items_spot", []):
            address = spot.get("address", "").strip()
            if not address:
                continue
            location_name = (spot.get("title") or "").strip() or title
            rows.append(build_row(title, location_name, address))
    return rows


def build_row(section_title: str, location_name: str, address: str) -> dict:
    country, iso3, state, city, postcode = parse_address(section_title, address)
    activity = infer_activity(section_title, location_name)
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": location_name,
        "LOCATION_ADDRESS": address,
        "LATITUDE": "",
        "LONGITUDE": "",
        "COUNTRY": country,
        "COUNTRY_ISO3": iso3,
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": SOURCE_URL,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": activity,
        "coord_source": "Not from website",
    }


def parse_address(section_title: str, address: str) -> tuple[str, str, str, str, str]:
    if "Taiwan" in address or section_title in {
        "Jhunan Fab",
        "Tainan Fab",
        "Innolux Corporation Tree Valley Branch",
        "Fab F",
        "Neihu Office",
    }:
        if "Miaoli" in address:
            return "Taiwan", "TWN", "Miaoli County", "Zhunan Township", "35053"
        if "Xinshi Dist" in address and "74147" in address:
            return "Taiwan", "TWN", "Tainan", "Xinshi Dist", "74147"
        if "Xinshi Dist" in address and "74144" in address:
            return "Taiwan", "TWN", "Tainan", "Xinshi Dist", "74144"
        if "Xinshi Dist" in address and "74148" in address:
            return "Taiwan", "TWN", "Tainan", "Xinshi Dist", "74148"
        if "Shanhua" in address:
            return "Taiwan", "TWN", "Tainan", "Shanhua District", "74144"
        if "Kaohsiung" in address:
            return "Taiwan", "TWN", "Kaohsiung City", "Luzhu District", "82151"
        if "Taipei" in address:
            return "Taiwan", "TWN", "Taipei City", "Neihu District", "11466"
    if section_title in {"Ningbo Fab", "Foshan Fab", "Nanjing Fab", "Shanghai Fab", "Longhua Fab"}:
        if "Ningbo" in address:
            return "China", "CHN", "Zhejiang", "Ningbo", "315800"
        if "Foshan" in address:
            return "China", "CHN", "Guangdong Province", "Foshan", "528237"
        if "Nanjing" in address:
            return "China", "CHN", "Jiangsu Province", "Nanjing", ""
        if "Shanghai" in address:
            return "China", "CHN", "Shanghai", "Shanghai", ""
        if "Shenzhen" in address:
            return "China", "CHN", "Guangdong", "Shenzhen", "518109"
    if "Netherlands" in address:
        return "Netherlands", "NLD", "Limburg", "Heerlen", "6411 NK"
    if "United States" in address:
        return "United States of America", "USA", "California", "San Jose", "95110"
    if "Korea" in address:
        return "South Korea", "KOR", "Gyeonggi-do", "Suwon", "16547"
    raise ValueError(f"Could not parse address: {section_title} | {address}")


def infer_activity(section_title: str, location_name: str) -> str:
    text = f"{section_title} {location_name}".lower()
    if "fab" in text or "headquarters" in text:
        return "Display manufacturing and operations"
    if "branch" in text:
        return "Branch operations"
    if "office" in text:
        return "Commercial office"
    return "Business operations"


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    rows = fetch_rows()
    with OUTPUT_CSV.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=HEADERS)
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()
