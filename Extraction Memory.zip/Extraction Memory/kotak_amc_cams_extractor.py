"""
Process CAMS Service Centre data and append to Kotak Gap CSV.
CAMS (Computer Age Management Services) is the RTA for Kotak Mutual Fund.
CAMS CSCs serve Kotak MF investors for transaction submission, statements, etc.
"""
import csv
import sys
import re
import json
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

ISSUER_ID   = "IID000000002173037"
ISSUER_NAME = "KOTAK MAHINDRA BANK LIMITED"
OUTPUT_FILE = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Gap Output\IID000000002173037_KOTAK MAHINDRA BANK LIMITED_Gap.csv")

COLUMNS = [
    "ISSUER_ID", "ISSUER_NAME", "FACILITY_NAME", "FACILITY_ADDRESS",
    "CITY", "STATE", "POSTAL_CODE", "FACILITY_REGION",
    "LATITUDE", "LONGITUDE", "FACILITY_CONTACT_NUMBER",
    "RELEVANT_URL", "BUSINESS_ACTIVITY"
]

INDIAN_STATES = {
    'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chandigarh',
    'Chhattisgarh', 'Delhi', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh',
    'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra',
    'Meghalaya', 'Nagaland', 'Odisha', 'Puducherry', 'Punjab', 'Rajasthan',
    'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand',
    'West Bengal', 'Jammu & Kashmir', 'Sikkim', 'Manipur', 'Mizoram',
    'Lakshadweep', 'Andaman and Nicobar Islands', 'Dadra and Nagar Haveli', 'Daman and Diu',
}

POSTAL_STATE = {
    '11': 'Delhi', '12': 'Haryana', '13': 'Haryana', '14': 'Punjab',
    '15': 'Punjab', '16': 'Chandigarh', '17': 'Himachal Pradesh',
    '18': 'Jammu & Kashmir', '19': 'Jammu & Kashmir',
    '20': 'Uttar Pradesh', '21': 'Uttar Pradesh', '22': 'Uttar Pradesh',
    '23': 'Uttar Pradesh', '24': 'Uttar Pradesh', '25': 'Uttar Pradesh',
    '26': 'Uttarakhand', '27': 'Uttar Pradesh', '28': 'Uttar Pradesh',
    '30': 'Rajasthan', '31': 'Rajasthan', '32': 'Rajasthan', '33': 'Rajasthan', '34': 'Rajasthan',
    '36': 'Gujarat', '37': 'Gujarat', '38': 'Gujarat', '39': 'Gujarat',
    '40': 'Maharashtra', '41': 'Maharashtra', '42': 'Maharashtra', '43': 'Maharashtra', '44': 'Maharashtra',
    '45': 'Madhya Pradesh', '46': 'Madhya Pradesh', '47': 'Madhya Pradesh', '48': 'Madhya Pradesh',
    '49': 'Chhattisgarh',
    '50': 'Telangana', '51': 'Andhra Pradesh', '52': 'Andhra Pradesh', '53': 'Andhra Pradesh',
    '56': 'Karnataka', '57': 'Karnataka', '58': 'Karnataka', '59': 'Karnataka',
    '60': 'Tamil Nadu', '61': 'Tamil Nadu', '62': 'Tamil Nadu', '63': 'Tamil Nadu',
    '64': 'Tamil Nadu', '65': 'Tamil Nadu',
    '67': 'Kerala', '68': 'Kerala', '69': 'Kerala',
    '70': 'West Bengal', '71': 'West Bengal', '72': 'West Bengal', '73': 'West Bengal', '74': 'West Bengal',
    '75': 'Odisha', '76': 'Odisha', '77': 'Odisha',
    '78': 'Assam', '79': 'Assam',
    '80': 'Bihar', '81': 'Bihar', '82': 'Jharkhand', '83': 'Jharkhand', '84': 'Bihar', '85': 'Bihar',
    '90': 'Goa', '91': 'Goa',
    '74': 'West Bengal', '79': 'Assam',
    '79': 'Assam', '78': 'Assam',
    '73': 'West Bengal', '72': 'West Bengal',
    '49': 'Chhattisgarh', '48': 'Madhya Pradesh', '47': 'Madhya Pradesh',
    '46': 'Madhya Pradesh', '45': 'Madhya Pradesh',
    '79': 'Assam',
    '09': 'Rajasthan',  # Rajasthan 09xxxx
    '30': 'Rajasthan', '31': 'Rajasthan', '32': 'Rajasthan', '33': 'Rajasthan', '34': 'Rajasthan',
    '35': 'Rajasthan',  # 35xxxx Rajasthan Bikaner
}

CITY_STATE = {
    'delhi': 'Delhi', 'new delhi': 'Delhi', 'gurugram': 'Haryana', 'gurgaon': 'Haryana',
    'noida': 'Uttar Pradesh', 'faridabad': 'Haryana', 'ghaziabad': 'Uttar Pradesh',
    'mumbai': 'Maharashtra', 'pune': 'Maharashtra', 'nagpur': 'Maharashtra',
    'nashik': 'Maharashtra', 'nasik': 'Maharashtra', 'aurangabad': 'Maharashtra',
    'navi mumbai': 'Maharashtra', 'thane': 'Maharashtra', 'kolhapur': 'Maharashtra',
    'bangalore': 'Karnataka', 'bengaluru': 'Karnataka', 'mysore': 'Karnataka',
    'mysuru': 'Karnataka', 'hubli': 'Karnataka', 'mangalore': 'Karnataka',
    'chennai': 'Tamil Nadu', 'coimbatore': 'Tamil Nadu', 'madurai': 'Tamil Nadu',
    'hyderabad': 'Telangana', 'secunderabad': 'Telangana', 'visakhapatnam': 'Andhra Pradesh',
    'vijayawada': 'Andhra Pradesh', 'kolkata': 'West Bengal', 'ahmedabad': 'Gujarat',
    'surat': 'Gujarat', 'baroda': 'Gujarat', 'vadodara': 'Gujarat', 'rajkot': 'Gujarat',
    'jaipur': 'Rajasthan', 'jodhpur': 'Rajasthan', 'udaipur': 'Rajasthan',
    'lucknow': 'Uttar Pradesh', 'kanpur': 'Uttar Pradesh', 'agra': 'Uttar Pradesh',
    'chandigarh': 'Chandigarh', 'ludhiana': 'Punjab', 'amritsar': 'Punjab',
    'indore': 'Madhya Pradesh', 'bhopal': 'Madhya Pradesh', 'jabalpur': 'Madhya Pradesh',
    'bhubaneswar': 'Odisha', 'patna': 'Bihar', 'ranchi': 'Jharkhand',
    'dehradun': 'Uttarakhand', 'kochi': 'Kerala', 'cochin': 'Kerala',
    'thiruvananthapuram': 'Kerala', 'trivandrum': 'Kerala', 'kozhikode': 'Kerala',
    'calicut': 'Kerala', 'thrissur': 'Kerala', 'kottayam': 'Kerala',
    'guwahati': 'Assam', 'raipur': 'Chhattisgarh',
    'agartala': 'Tripura', 'imphal': 'Manipur', 'aizawl': 'Mizoram',
    'shillong': 'Meghalaya', 'kohima': 'Nagaland', 'itanagar': 'Arunachal Pradesh',
    'gangtok': 'Sikkim', 'panaji': 'Goa', 'panjim': 'Goa',
    'shimla': 'Himachal Pradesh', 'dharamsala': 'Himachal Pradesh',
    'pondicherry': 'Puducherry', 'puducherry': 'Puducherry',
    'port blair': 'Andaman and Nicobar Islands',
    'jammu': 'Jammu & Kashmir', 'srinagar': 'Jammu & Kashmir',
    'allahabad': 'Uttar Pradesh', 'prayagraj': 'Uttar Pradesh',
    'ahmednagar': 'Maharashtra', 'ahilyanagar': 'Maharashtra',
    'amravati': 'Maharashtra', 'amaravati': 'Andhra Pradesh',
}

def extract_postal(text):
    m = re.search(r'\b(\d{6})\b', text)
    return m.group(1) if m else ""

def get_state(city, address):
    # Try city first
    st = CITY_STATE.get(city.lower().strip(), '')
    if st:
        return st
    # Try state name in address
    for state in sorted(INDIAN_STATES, key=len, reverse=True):
        if state.lower() in address.lower():
            return state
    # Try postal prefix
    postal = extract_postal(address)
    if postal and len(postal) >= 2:
        return POSTAL_STATE.get(postal[:2], '')
    return ''

# Load CAMS CSC data
with open("C:/Temp/cams_csc_all.json", encoding='utf-8') as f:
    csc_data = json.load(f)

print(f"CAMS CSC records: {len(csc_data)}")

# Process into CSV records
cams_records = []
for item in csc_data:
    city = item.get('city', '').strip()
    address = item.get('address', '').strip()
    phone = item.get('phone', '').strip()
    email = item.get('email', '').strip()
    
    # Clean up address (remove "view map" text)
    address = re.sub(r'\s*view map\s*', '', address, flags=re.IGNORECASE).strip()
    address = re.sub(r'\s+', ' ', address)
    
    state = get_state(city, address)
    postal = extract_postal(address)
    contact = phone
    
    rec = {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "FACILITY_NAME": f"Kotak MF - CAMS Investor Service Centre ({city})",
        "FACILITY_ADDRESS": address,
        "CITY": city,
        "STATE": state,
        "POSTAL_CODE": postal,
        "FACILITY_REGION": "Asia",
        "LATITUDE": "",
        "LONGITUDE": "",
        "FACILITY_CONTACT_NUMBER": contact,
        "RELEVANT_URL": "https://www.camsonline.com/Investors/Support/CAMS-Location&Service-center",
        "BUSINESS_ACTIVITY": "Asset Management - CAMS Investor Service Centre (Kotak MF RTA)",
    }
    cams_records.append(rec)

print(f"Processed: {len(cams_records)} records")

# Stats
with_state = [r for r in cams_records if r['STATE']]
with_postal = [r for r in cams_records if r['POSTAL_CODE']]
print(f"With state: {len(with_state)}/{len(cams_records)}")
print(f"With postal: {len(with_postal)}/{len(cams_records)}")

# Sample
for r in cams_records[:3]:
    print(f"\n  City: {r['CITY']}, State: {r['STATE']}")
    print(f"  Address: {r['FACILITY_ADDRESS'][:80]}")
    print(f"  Phone: {r['FACILITY_CONTACT_NUMBER']}")

# Append to existing CSV
existing = []
with open(OUTPUT_FILE, encoding='utf-8-sig', newline='') as f:
    existing = list(csv.DictReader(f))

print(f"\nExisting records: {len(existing)}")
all_records = existing + cams_records

with open(OUTPUT_FILE, 'w', newline='', encoding='utf-8-sig') as f:
    writer = csv.DictWriter(f, fieldnames=COLUMNS)
    writer.writeheader()
    writer.writerows(all_records)

print(f"Total after append: {len(all_records)}")
print(f"File: {OUTPUT_FILE}")
