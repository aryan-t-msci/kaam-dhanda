"""
shriram_gap_extractor.py
========================
Gap fill extractor for SHRIRAM FINANCE LIMITED (IID000000002129317)
Platform: SingleInterface (branches.shriramfinance.in)
URL format: /location/{state-slug}/{city-slug}?page=N

Extracts branches for ALL gap states:
 - Fully missing: Gujarat, Haryana, Jharkhand, Himachal Pradesh, Delhi,
                  Jammu & Kashmir, Goa, Dadra & Nagar Haveli
 - Partially collected: TN, AP, Maharashtra, Telangana, Karnataka, UP,
                        Rajasthan, Kerala, MP, Bihar, West Bengal, Punjab,
                        Chhattisgarh, Odisha, Assam, Puducherry, Uttarakhand
 - Manual stubs: Registered Office, Corporate Office, Manipur, Andaman & Nicobar

Usage:
    python shriram_gap_extractor.py

Output:
    Temp/shriram_gap_raw.json  (progress)
    Gap Output/IID000000002129317_SHRIRAM FINANCE LIMITED_Gap.csv (final)
"""
import sys, json, time, re, warnings
from pathlib import Path
from datetime import datetime
sys.stdout.reconfigure(encoding='utf-8')
warnings.filterwarnings("ignore")

import requests
from bs4 import BeautifulSoup

# ===================================================================
# CONFIGURATION
# ===================================================================
ISSUER_ID   = "IID000000002129317"
ISSUER_NAME = "SHRIRAM FINANCE LIMITED"
BASE_URL    = "https://branches.shriramfinance.in"
BUSINESS_ACTIVITY = "Financial Services; NBFC"

TEMP_DIR   = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Temp")
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Gap Output")
STATE_CITY_MAP_FILE = TEMP_DIR / "shriram_state_city_map_v2.json"
PROGRESS_FILE = TEMP_DIR / "shriram_gap_progress.json"
OUTLETS_FILE  = TEMP_DIR / "shriram_gap_outlets.json"

# States present in original collection (to allow dedup checking)
ALREADY_COLLECTED_STATES = {
    'Andhra Pradesh', 'Assam', 'Bihar', 'Chandigarh', 'Chhattisgarh',
    'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Meghalaya',
    'Odisha', 'Puducherry', 'Punjab', 'Rajasthan', 'Sikkim',
    'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand',
    'West Bengal'
}

# Fully missing states that need complete extraction
FULLY_MISSING_STATES = {
    'gujarat', 'haryana', 'jharkhand', 'himachal-pradesh', 'delhi',
    'jammu-and-kashmir', 'goa', 'dadra-and-nagar-haveli'
}

# Partially collected states where we need to get everything and dedup
PARTIAL_STATES = {
    'tamil-nadu', 'andhra-pradesh', 'maharashtra', 'telangana', 'karnataka',
    'uttar-pradesh', 'rajasthan', 'kerala', 'madhya-pradesh', 'bihar',
    'west-bengal', 'punjab', 'chhattisgarh', 'odisha', 'assam',
    'puducherry', 'uttarakhand'
}

MAX_PAGES = 50  # Safety cap

COLS = ['ISSUER_ID', 'ISSUER_NAME', 'FACILITY_NAME', 'FACILITY_ADDRESS',
        'CITY', 'STATE', 'POSTAL_CODE', 'FACILITY_REGION',
        'LATITUDE', 'LONGITUDE', 'FACILITY_CONTACT_NUMBER',
        'RELEVANT_URL', 'BUSINESS_ACTIVITY']

OUTPUT_DIR.mkdir(exist_ok=True)

session = requests.Session()
session.headers.update({
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Referer': BASE_URL + '/',
    'Connection': 'keep-alive',
})


def log(msg): print(msg, flush=True)


def parse_cards(html, state_name):
    """Parse branch cards from SI HTML page."""
    soup = BeautifulSoup(html, 'html.parser')
    cards = soup.find_all('div', class_='store-info-box')
    results = []
    for card in cards:
        o = {
            'ISSUER_ID': ISSUER_ID,
            'ISSUER_NAME': ISSUER_NAME,
            'STATE': state_name,
            'CITY': '',
            'POSTAL_CODE': '',
            'FACILITY_CONTACT_NUMBER': '',
            'LATITUDE': '',
            'LONGITUDE': '',
            '_oid': '',
        }

        lat = card.find('input', class_='outlet-latitude')
        lng = card.find('input', class_='outlet-longitude')
        o['LATITUDE']  = lat.get('value', '').strip() if lat else ''
        o['LONGITUDE'] = lng.get('value', '').strip() if lng else ''

        name_a = card.find('a', attrs={'data-track-event-business-name': True})
        if name_a:
            o['FACILITY_NAME'] = name_a.get('data-track-event-business-name', '').strip()
            o['CITY']  = name_a.get('data-track-event-city', '').strip()
            o['STATE'] = name_a.get('data-track-event-state', state_name).strip() or state_name
            href = name_a.get('href', '').strip()
            o['RELEVANT_URL'] = href
            m = re.search(r'-(\d{4,10})/Home', href)
            if m:
                o['_oid'] = m.group(1)

        addr_li = card.find('li', class_='outlet-address')
        if addr_li:
            parts = [s.get_text(strip=True) for s in addr_li.find_all('span') if s.get_text(strip=True)]
            o['FACILITY_ADDRESS'] = ', '.join(parts)
            for p in parts:
                if re.match(r'^\d{6}$', p):
                    o['POSTAL_CODE'] = p

        ph = card.find('a', href=re.compile(r'^tel:'))
        o['FACILITY_CONTACT_NUMBER'] = ph.get_text(strip=True) if ph else ''

        o['FACILITY_REGION'] = 'India'
        o['BUSINESS_ACTIVITY'] = BUSINESS_ACTIVITY
        results.append(o)
    return results


def get_max_page(html):
    """Get max page number from pagination."""
    soup = BeautifulSoup(html, 'html.parser')
    pagination = soup.find('ul', class_='pagination')
    max_page = 1
    if pagination:
        for lnk in pagination.find_all('a', href=re.compile(r'\?page=\d+')):
            m = re.search(r'page=(\d+)', lnk.get('href', ''))
            if m:
                max_page = max(max_page, int(m.group(1)))
    return max_page


def dedup_key(o):
    oid = o.get('_oid')
    if oid:
        return f'oid:{oid}'
    lat, lng = o.get('LATITUDE', ''), o.get('LONGITUDE', '')
    if lat and lng and lat != '0' and lng != '0':
        return f'll:{lat},{lng}'
    name = o.get('FACILITY_NAME', '').lower().strip()
    addr = o.get('FACILITY_ADDRESS', '').lower().strip()[:50]
    return f'na:{name}|{addr}'


def fetch_state_by_pages(state_slug, state_name, max_pages_hint):
    """Fetch all branches for a state using state-level pagination."""
    all_outlets = {}
    
    for page_num in range(1, MAX_PAGES + 1):
        if page_num == 1:
            url = f'{BASE_URL}/location/{state_slug}'
        else:
            url = f'{BASE_URL}/location/{state_slug}?page={page_num}'
        
        try:
            r = session.get(url, timeout=20, verify=False)
            if r.status_code != 200:
                break
        except Exception as e:
            log(f'    Error p{page_num}: {e}')
            break
        
        cards = parse_cards(r.text, state_name)
        if not cards:
            break
        
        new_n = 0
        for c in cards:
            k = dedup_key(c)
            if k not in all_outlets:
                all_outlets[k] = c
                new_n += 1
        
        if new_n == 0:
            break  # Pagination loop detected
        
        # Check if there's more pages
        actual_max = get_max_page(r.text)
        if page_num >= actual_max:
            break
        
        time.sleep(0.3)
    
    return list(all_outlets.values())


def fetch_state_by_city(state_slug, state_name, cities):
    """Fetch branches city by city."""
    all_outlets = {}
    
    for city_slug, city_name in cities.items():
        for page_num in range(1, MAX_PAGES + 1):
            if page_num == 1:
                url = f'{BASE_URL}/location/{state_slug}/{city_slug}'
            else:
                url = f'{BASE_URL}/location/{state_slug}/{city_slug}?page={page_num}'
            
            try:
                r = session.get(url, timeout=20, verify=False)
                if r.status_code != 200:
                    break
            except Exception as e:
                log(f'    Error {city_name} p{page_num}: {e}')
                break
            
            cards = parse_cards(r.text, state_name)
            if not cards:
                break
            
            new_n = 0
            for c in cards:
                k = dedup_key(c)
                if k not in all_outlets:
                    all_outlets[k] = c
                    new_n += 1
            
            if new_n == 0:
                break
            
            actual_max = get_max_page(r.text)
            if page_num >= actual_max:
                break
            
            time.sleep(0.25)
        
        time.sleep(0.2)
    
    return list(all_outlets.values())


def load_progress():
    outlets = {}
    done_states = set()
    if OUTLETS_FILE.exists():
        with open(OUTLETS_FILE, encoding='utf-8') as f:
            outlets = json.load(f)
    if PROGRESS_FILE.exists():
        with open(PROGRESS_FILE, encoding='utf-8') as f:
            prog = json.load(f)
        done_states = set(prog.get('done_states', []))
    return outlets, done_states


def save_progress(outlets, done_states):
    with open(OUTLETS_FILE, 'w', encoding='utf-8') as f:
        json.dump(outlets, f, ensure_ascii=False, indent=2)
    with open(PROGRESS_FILE, 'w', encoding='utf-8') as f:
        json.dump({'done_states': list(done_states)}, f)


# ===================================================================
# MANUAL STUBS (registered/corporate offices + unreachable branches)
# ===================================================================
MANUAL_RECORDS = [
    # Asset 1: Registered Office
    {
        'ISSUER_ID': ISSUER_ID,
        'ISSUER_NAME': ISSUER_NAME,
        'FACILITY_NAME': 'SHRIRAM FINANCE LIMITED - Registered Office (Sri Towers, Guindy)',
        'FACILITY_ADDRESS': 'Plot No. 14A, South Phase, Industrial Estate, Guindy, Chennai - 600032',
        'CITY': 'Chennai',
        'STATE': 'Tamil Nadu',
        'POSTAL_CODE': '600032',
        'FACILITY_REGION': 'India',
        'LATITUDE': '',
        'LONGITUDE': '',
        'FACILITY_CONTACT_NUMBER': '',
        'RELEVANT_URL': 'https://www.shriramfinance.in/contact-us',
        'BUSINESS_ACTIVITY': 'Financial Services; NBFC - Registered Office',
    },
    # Asset 2: Corporate Office (BKC Mumbai)
    {
        'ISSUER_ID': ISSUER_ID,
        'ISSUER_NAME': ISSUER_NAME,
        'FACILITY_NAME': 'SHRIRAM FINANCE LIMITED - Corporate Office (Wockhardt Towers, BKC)',
        'FACILITY_ADDRESS': 'West Wing, Level-3, C-2, G-Block, Bandra-Kurla Complex, Bandra East, Mumbai - 400051',
        'CITY': 'Mumbai',
        'STATE': 'Maharashtra',
        'POSTAL_CODE': '400051',
        'FACILITY_REGION': 'India',
        'LATITUDE': '',
        'LONGITUDE': '',
        'FACILITY_CONTACT_NUMBER': '',
        'RELEVANT_URL': 'https://www.shriramfinance.in/contact-us',
        'BUSINESS_ACTIVITY': 'Financial Services; NBFC - Corporate Office',
    },
    # Asset 10: Manipur (1 branch - Imphal, not in branch locator)
    {
        'ISSUER_ID': ISSUER_ID,
        'ISSUER_NAME': ISSUER_NAME,
        'FACILITY_NAME': 'SHRIRAM FINANCE LIMITED - Imphal Branch',
        'FACILITY_ADDRESS': 'Imphal, Manipur',
        'CITY': 'Imphal',
        'STATE': 'Manipur',
        'POSTAL_CODE': '',
        'FACILITY_REGION': 'India',
        'LATITUDE': '',
        'LONGITUDE': '',
        'FACILITY_CONTACT_NUMBER': '18004107711',
        'RELEVANT_URL': 'https://www.shriramfinance.in/branch-locator',
        'BUSINESS_ACTIVITY': BUSINESS_ACTIVITY,
    },
    # Asset 12: Andaman & Nicobar (1 branch - Port Blair, not in branch locator)
    {
        'ISSUER_ID': ISSUER_ID,
        'ISSUER_NAME': ISSUER_NAME,
        'FACILITY_NAME': 'SHRIRAM FINANCE LIMITED - Port Blair Branch',
        'FACILITY_ADDRESS': 'Port Blair, Andaman and Nicobar Islands',
        'CITY': 'Port Blair',
        'STATE': 'Andaman and Nicobar Islands',
        'POSTAL_CODE': '',
        'FACILITY_REGION': 'India',
        'LATITUDE': '',
        'LONGITUDE': '',
        'FACILITY_CONTACT_NUMBER': '18004107711',
        'RELEVANT_URL': 'https://www.shriramfinance.in/branch-locator',
        'BUSINESS_ACTIVITY': BUSINESS_ACTIVITY,
    },
]


def main():
    log('=' * 70)
    log(f'SHRIRAM FINANCE Gap Extractor')
    log(f'Issuer: {ISSUER_NAME} ({ISSUER_ID})')
    log('=' * 70)

    # Load state/city map
    with open(STATE_CITY_MAP_FILE, encoding='utf-8') as f:
        state_city_map = json.load(f)

    # Determine which states to scrape (gap states only)
    gap_states = FULLY_MISSING_STATES | PARTIAL_STATES

    # Load progress
    all_outlets, done_states = load_progress()
    log(f'Resumed: {len(all_outlets)} outlets, {len(done_states)} states done')

    processed = 0
    for state_slug, state_data in state_city_map.items():
        state_name = state_data['name']
        
        # Only scrape gap states
        if state_slug not in gap_states:
            log(f'[SKIP] {state_name} - not in gap list')
            continue
        
        if state_slug in done_states:
            log(f'[DONE] {state_name} - already done')
            continue

        cities = state_data.get('cities', {})
        max_pages = state_data.get('max_pages', 1)
        
        log(f'\n[STATE] {state_name} — {len(cities)} cities, {max_pages} pages')
        
        # Use page-by-page for small states (<=3 pages), city-by-city for large
        if max_pages <= 3 or len(cities) <= 5:
            branches = fetch_state_by_pages(state_slug, state_name, max_pages)
            log(f'  Page-by-page: {len(branches)} branches found')
        else:
            branches = fetch_state_by_city(state_slug, state_name, cities)
            log(f'  City-by-city: {len(branches)} branches found')
        
        new_n = 0
        for b in branches:
            k = dedup_key(b)
            if k not in all_outlets:
                all_outlets[k] = b
                new_n += 1
        log(f'  New unique: {new_n}')

        done_states.add(state_slug)
        processed += 1

        if processed % 3 == 0:
            save_progress(all_outlets, done_states)
            log(f'  [SAVED] {len(all_outlets)} total outlets')

    save_progress(all_outlets, done_states)
    log(f'\nBranch extraction complete: {len(all_outlets)} outlets')

    # Load original collection for deduplication
    log('\nLoading original collection for dedup...')
    import openpyxl
    original_keys = set()
    orig_wb = openpyxl.load_workbook(
        r'C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Original Collection\SHRIRAM_FINANCE_LIMITED_20260326_112722_final (1).xlsx'
    )
    orig_ws = orig_wb.active
    for r in range(2, orig_ws.max_row + 1):
        name = orig_ws.cell(r, 3).value or ''
        addr = orig_ws.cell(r, 4).value or ''
        key = f'{name.lower().strip()}|{addr.lower().strip()[:50]}'
        original_keys.add(key)
        # Also by lat/lng
        lat = str(orig_ws.cell(r, 9).value or '').strip()
        lng = str(orig_ws.cell(r, 10).value or '').strip()
        if lat and lng and lat != '0' and lng != '0':
            original_keys.add(f'll:{lat},{lng}')
        # Also by outlet ID from URL
        url = str(orig_ws.cell(r, 12).value or '')
        m = re.search(r'-(\d{4,10})/Home', url)
        if m:
            original_keys.add(f'oid:{m.group(1)}')
    log(f'Original collection: {len(original_keys)} dedup keys')

    # Build final rows — only NEW branches not in original
    rows = []
    
    # Add manual stubs first
    rows.extend(MANUAL_RECORDS)
    log(f'Added {len(MANUAL_RECORDS)} manual stubs (offices + Manipur + A&N)')

    # Add scraped branches with dedup
    skipped = 0
    for k, o in all_outlets.items():
        # Check all dedup keys
        name = o.get('FACILITY_NAME', '').lower().strip()
        addr = o.get('FACILITY_ADDRESS', '').lower().strip()[:50]
        name_addr_key = f'{name}|{addr}'
        
        lat, lng = o.get('LATITUDE', ''), o.get('LONGITUDE', '')
        ll_key = f'll:{lat},{lng}' if lat and lng and lat != '0' and lng != '0' else None
        oid_key = f'oid:{o.get("_oid")}' if o.get('_oid') else None
        
        is_dup = (
            name_addr_key in original_keys or
            (ll_key and ll_key in original_keys) or
            (oid_key and oid_key in original_keys)
        )
        
        if is_dup:
            skipped += 1
            continue
        
        rows.append({
            'ISSUER_ID': ISSUER_ID,
            'ISSUER_NAME': ISSUER_NAME,
            'FACILITY_NAME': o.get('FACILITY_NAME', ''),
            'FACILITY_ADDRESS': o.get('FACILITY_ADDRESS', ''),
            'CITY': o.get('CITY', ''),
            'STATE': o.get('STATE', ''),
            'POSTAL_CODE': o.get('POSTAL_CODE', ''),
            'FACILITY_REGION': 'India',
            'LATITUDE': o.get('LATITUDE', ''),
            'LONGITUDE': o.get('LONGITUDE', ''),
            'FACILITY_CONTACT_NUMBER': o.get('FACILITY_CONTACT_NUMBER', ''),
            'RELEVANT_URL': o.get('RELEVANT_URL', BASE_URL),
            'BUSINESS_ACTIVITY': BUSINESS_ACTIVITY,
        })

    log(f'Total new branches (after dedup): {len(rows) - len(MANUAL_RECORDS)}')
    log(f'Skipped (already in original): {skipped}')
    log(f'Total output rows: {len(rows)}')

    # Write final CSV
    import csv
    output_file = OUTPUT_DIR / f'{ISSUER_ID}_SHRIRAM FINANCE LIMITED_Gap.csv'
    with open(output_file, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=COLS)
        writer.writeheader()
        writer.writerows(rows)
    
    log(f'\nFinal CSV written: {output_file}')
    log(f'Total records: {len(rows)}')


if __name__ == '__main__':
    main()
