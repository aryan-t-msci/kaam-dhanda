"""
Generic VTEX store-locator GraphQL extractor.

Pattern:
- VTEX `store.storelocator` pages backed by the `vtex.store-locator` GraphQL
  provider.
- The page itself may render only a nearby-store widget, but the JS bundle
  exposes a public `getStores(latitude, longitude, keyword)` query that
  returns store details, address fields, business hours, and coordinates.

How to reuse:
1. Update the configuration block for a new issuer / domain / locale.
2. Adjust the query hash only if the VTEX bundle changes.
3. Tune the geographic sweep grid for the issuer's operating footprint.
4. Run the script. It saves progress every 20 coordinates, writes a checkpoint
   CSV after crossing the minimum threshold, then writes the final CSV.

Example config for another issuer:
    ISSUER_NAME = "Example Retailer"
    ISSUER_ID = "IID000000000000000"
    STORE_PAGE_URL = "https://www.example.com/stores"
    GRAPHQL_BASE = (
        "https://www.example.com/_v/public/graphql/v1"
        "?workspace=master&maxAge=medium&appsEtag=remove&domain=store&locale=en-US"
    )
    COUNTRY = "Mexico"
    COUNTRY_ISO3 = "MEX"
"""

from __future__ import annotations

import csv
import json
import math
import time
import unicodedata
from dataclasses import dataclass
from datetime import datetime, timezone
from itertools import product
from pathlib import Path
from typing import Dict, Iterable, List, Optional

import requests
import urllib3


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


# ============================================================
# CONFIGURATION - Change these for each new issuer
# ============================================================
ISSUER_NAME = "Grupo Comercial Chedraui, S.A.B. de C.V."
ISSUER_ID = "IID000000002240529"
SOURCE_URL = "https://www.chedraui.com.mx/stores"
SOURCE_TYPE = "COMPANY WEBSITE"
STORE_PAGE_URL = "https://www.chedraui.com.mx/stores"
GRAPHQL_BASE = (
    "https://www.chedraui.com.mx/_v/public/graphql/v1"
    "?workspace=master&maxAge=medium&appsEtag=remove&domain=store&locale=es-MX"
)
GRAPHQL_SENDER = "vtex.store-locator@0.10.15"
GRAPHQL_PROVIDER = "vtex.store-locator"
GRAPHQL_RUNTIME_HASH = "84c1d7c12d4b507dff72e8579bde396ec66c33f78d94188fcf756bfa14cc8518"

COUNTRY = "Mexico"
COUNTRY_ISO3 = "MEX"
MIN_RECORD_COUNT = 100
REQUEST_SLEEP_SECONDS = 0.15
REQUEST_TIMEOUT_SECONDS = 60
PROGRESS_SAVE_EVERY = 20

# 2-degree grid keeps every point within ~157 km of a query center.
LAT_MIN = 14.0
LAT_MAX = 33.0
LAT_STEP = 2.0
LON_MIN = -118.0
LON_MAX = -86.0
LON_STEP = 2.0

TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")
FINAL_OUTPUT_CSV = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
CHECKPOINT_CSV = TEMP_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_checkpoint.csv"
RAW_JSON = TEMP_DIR / f"{ISSUER_ID}_raw_records.json"
PROGRESS_JSON = TEMP_DIR / f"{ISSUER_ID}_progress.json"
SUMMARY_JSON = TEMP_DIR / f"{ISSUER_ID}_summary.json"


# ============================================================
# GENERIC EXTRACTION LOGIC BELOW - Do not modify per-issuer
# ============================================================
GET_STORES_QUERY = f"""
query getStores($latitude: Float, $longitude: Float, $filterByTag: String)
  @context(sender: "{GRAPHQL_SENDER}") {{
  getStores(latitude: $latitude, longitude: $longitude, keyword: $filterByTag)
    @context(provider: "{GRAPHQL_PROVIDER}")
    @runtimeMeta(hash: "{GRAPHQL_RUNTIME_HASH}") {{
    items {{
      distance
      name
      instructions
      id
      isActive
      address {{
        postalCode
        country
        city
        state
        neighborhood
        street
        number
        complement
        reference
        location {{
          latitude
          longitude
          __typename
        }}
        __typename
      }}
      pickupHolidays {{
        date
        hourBegin
        hourEnd
        __typename
      }}
      businessHours {{
        dayOfWeek
        openingTime
        closingTime
        __typename
      }}
      __typename
    }}
    __typename
  }}
}}
""".strip()


CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS_NATIVE",
]


STATE_NORMALIZATION = {
    "CDMX": "Ciudad de Mexico",
    "CIUDAD DE MEXICO": "Ciudad de Mexico",
    "Q. ROO": "Quintana Roo",
    "Q.ROO": "Quintana Roo",
    "Q ROO": "Quintana Roo",
    "EDO. MEX.": "Estado de Mexico",
    "EDO MEX": "Estado de Mexico",
    "MEX.": "Estado de Mexico",
    "NL": "Nuevo Leon",
}

# Source payload occasionally omits `address.city`; keep issuer-specific fixes in config.
CITY_OVERRIDES_BY_STORE_ID = {
    "PP0274": "Cancun",
    "PP0277": "Lerma",
}


@dataclass(frozen=True)
class GridPoint:
    latitude: float
    longitude: float


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def frange(start: float, stop: float, step: float) -> Iterable[float]:
    current = start
    # Include the stop bound when step lands exactly.
    while current <= stop + 1e-9:
        yield round(current, 6)
        current += step


def build_grid() -> List[GridPoint]:
    return [
        GridPoint(latitude=lat, longitude=lon)
        for lat, lon in product(
            frange(LAT_MIN, LAT_MAX, LAT_STEP),
            frange(LON_MIN, LON_MAX, LON_STEP),
        )
    ]


def compact_spaces(value: str | None) -> str:
    if value is None:
        return ""
    value = str(value).replace("\xa0", " ").replace("#", " ")
    value = " ".join(value.split())
    return value.strip()


def strip_accents(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value)
    return "".join(ch for ch in normalized if not unicodedata.combining(ch))


def to_ascii(value: str | None) -> str:
    return compact_spaces(strip_accents(compact_spaces(value)))


def normalize_state(value: str | None) -> str:
    native = compact_spaces(value)
    if not native:
        return ""
    ascii_value = to_ascii(native).upper()
    if ascii_value in STATE_NORMALIZATION:
        return STATE_NORMALIZATION[ascii_value]
    return to_ascii(native)


def normalize_city(value: str | None) -> str:
    return to_ascii(value)


def derive_activity(location_name_native: str) -> str:
    upper_name = to_ascii(location_name_native).upper()
    if "SUPERCITO" in upper_name:
        return "Neighborhood supermarket retail store"
    return "Supermarket retail store"


def merge_parts(parts: Iterable[str]) -> str:
    return ", ".join(part for part in parts if part)


def build_native_address(address: dict | None, city_override: str = "") -> str:
    address = address or {}
    street = compact_spaces(address.get("street"))
    number = compact_spaces(address.get("number"))
    neighborhood = compact_spaces(address.get("neighborhood"))
    city = compact_spaces(address.get("city")) or compact_spaces(city_override)
    state = compact_spaces(address.get("state"))
    postal_code = compact_spaces(address.get("postalCode"))
    country = compact_spaces(address.get("country")) or COUNTRY

    first_line = merge_parts([merge_parts([street, number]).strip(", "), neighborhood])
    return merge_parts([first_line, city, state, postal_code, country])


def build_ascii_address(address: dict | None, city_override: str = "") -> str:
    address = address or {}
    street = to_ascii(address.get("street"))
    number = to_ascii(address.get("number"))
    neighborhood = to_ascii(address.get("neighborhood"))
    city = normalize_city(address.get("city")) or normalize_city(city_override)
    state = normalize_state(address.get("state"))
    postal_code = to_ascii(address.get("postalCode"))
    country = COUNTRY

    first_line = merge_parts([merge_parts([street, number]).strip(", "), neighborhood])
    return merge_parts([first_line, city, state, postal_code, country])


def normalize_float(value: object) -> str:
    if value in (None, ""):
        return ""
    try:
        return f"{float(value):.6f}".rstrip("0").rstrip(".")
    except (TypeError, ValueError):
        return ""


def more_complete(current: str, incoming: str) -> str:
    current = current or ""
    incoming = incoming or ""
    if len(incoming.strip()) > len(current.strip()):
        return incoming
    return current


def merge_store(existing: dict, incoming: dict) -> dict:
    if not existing:
        return incoming
    merged = dict(existing)
    for key, value in incoming.items():
        if isinstance(value, dict):
            merged[key] = merge_store(merged.get(key, {}), value)
        elif value not in (None, "", []):
            if isinstance(value, str):
                merged[key] = more_complete(str(merged.get(key, "")), value)
            else:
                merged[key] = value
    return merged


def request_get_stores(latitude: float, longitude: float) -> List[dict]:
    payload = {
        "operationName": "getStores",
        "variables": {
            "latitude": latitude,
            "longitude": longitude,
            "filterByTag": "",
        },
        "query": GET_STORES_QUERY,
    }
    response = requests.post(
        GRAPHQL_BASE,
        json=payload,
        timeout=REQUEST_TIMEOUT_SECONDS,
        verify=False,
    )
    response.raise_for_status()
    data = response.json()
    return data.get("data", {}).get("getStores", {}).get("items", []) or []


def store_to_row(store: dict) -> dict:
    address = store.get("address") or {}
    location = address.get("location") or {}
    store_id = compact_spaces(store.get("id"))
    city_override = CITY_OVERRIDES_BY_STORE_ID.get(store_id, "")

    location_name_native = compact_spaces(store.get("name"))
    location_name_ascii = to_ascii(location_name_native)

    location_address_native = build_native_address(address, city_override=city_override)
    location_address_ascii = build_ascii_address(address, city_override=city_override)

    city_ascii = normalize_city(address.get("city")) or normalize_city(city_override)
    state_ascii = normalize_state(address.get("state"))
    postcode_ascii = to_ascii(address.get("postalCode"))

    latitude = normalize_float(location.get("latitude"))
    longitude = normalize_float(location.get("longitude"))
    coord_source = "website" if latitude and longitude else "not_on_website"

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": location_name_ascii,
        "LOCATION_ADDRESS": location_address_ascii,
        "LATITUDE": latitude,
        "LONGITUDE": longitude,
        "COUNTRY": COUNTRY,
        "COUNTRY_ISO3": COUNTRY_ISO3,
        "POSTCODE": postcode_ascii,
        "STATE": state_ascii,
        "CITY": city_ascii,
        "SOURCE_URL": SOURCE_URL,
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": derive_activity(location_name_native),
        "coord_source": coord_source,
        "LOCATION_NAME_NATIVE": location_name_native,
        "LOCATION_ADDRESS_NATIVE": location_address_native,
    }


def validate_rows(rows: List[dict]) -> List[str]:
    issues: List[str] = []
    for row in rows:
        if not row["LOCATION_ADDRESS"]:
            issues.append(f"{row['LOCATION_NAME']} has blank LOCATION_ADDRESS")
        if not row["CITY"]:
            issues.append(f"{row['LOCATION_NAME']} has blank CITY")
    return issues


def write_csv(path: Path, rows: List[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in CSV_COLUMNS})


def save_progress(
    grid: List[GridPoint],
    next_index: int,
    store_map: Dict[str, dict],
    checkpoint_written: bool,
    started_at: str,
) -> None:
    payload = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "source_url": SOURCE_URL,
        "started_at_utc": started_at,
        "updated_at_utc": utc_now_iso(),
        "next_grid_index": next_index,
        "grid_size": len(grid),
        "unique_store_count": len(store_map),
        "checkpoint_written": checkpoint_written,
    }
    PROGRESS_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    RAW_JSON.write_text(
        json.dumps(list(store_map.values()), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def load_progress(grid: List[GridPoint]) -> tuple[int, Dict[str, dict], bool, str]:
    if not PROGRESS_JSON.exists() or not RAW_JSON.exists():
        return 0, {}, False, utc_now_iso()

    progress = json.loads(PROGRESS_JSON.read_text(encoding="utf-8"))
    raw_records = json.loads(RAW_JSON.read_text(encoding="utf-8"))
    next_index = int(progress.get("next_grid_index", 0))
    checkpoint_written = bool(progress.get("checkpoint_written", False))
    started_at = progress.get("started_at_utc") or utc_now_iso()

    store_map = {}
    for store in raw_records:
        store_id = compact_spaces(store.get("id"))
        if store_id:
            store_map[store_id] = store

    # Protect against config changes that shrink the grid.
    next_index = min(next_index, len(grid))
    return next_index, store_map, checkpoint_written, started_at


def main() -> None:
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    grid = build_grid()
    next_index, store_map, checkpoint_written, started_at = load_progress(grid)

    print(f"Grid points: {len(grid)}")
    print(f"Resuming at grid index: {next_index}")
    print(f"Existing unique stores: {len(store_map)}")

    for index in range(next_index, len(grid)):
        point = grid[index]
        try:
            items = request_get_stores(point.latitude, point.longitude)
        except Exception as exc:  # noqa: BLE001 - keep resumable progress
            print(f"[WARN] Grid {index + 1}/{len(grid)} failed at ({point.latitude}, {point.longitude}): {exc}")
            save_progress(grid, index, store_map, checkpoint_written, started_at)
            time.sleep(REQUEST_SLEEP_SECONDS)
            continue

        new_ids = 0
        for item in items:
            if not item.get("isActive"):
                continue
            store_id = compact_spaces(item.get("id"))
            if not store_id:
                continue
            if store_id in store_map:
                store_map[store_id] = merge_store(store_map[store_id], item)
            else:
                store_map[store_id] = item
                new_ids += 1

        print(
            f"[INFO] Grid {index + 1}/{len(grid)} ({point.latitude}, {point.longitude}) "
            f"returned {len(items)} items, +{new_ids} new, unique total {len(store_map)}"
        )

        if not checkpoint_written and len(store_map) >= MIN_RECORD_COUNT:
            checkpoint_rows = [store_to_row(store) for store in store_map.values()]
            checkpoint_rows.sort(key=lambda row: (row["STATE"], row["CITY"], row["LOCATION_NAME"], row["POSTCODE"]))
            write_csv(CHECKPOINT_CSV, checkpoint_rows)
            checkpoint_written = True
            print(f"[INFO] Wrote checkpoint CSV: {CHECKPOINT_CSV}")

        if (index + 1) % PROGRESS_SAVE_EVERY == 0 or index == len(grid) - 1:
            save_progress(grid, index + 1, store_map, checkpoint_written, started_at)
            print(f"[INFO] Saved progress at grid index {index + 1}")

        time.sleep(REQUEST_SLEEP_SECONDS)

    rows = [store_to_row(store) for store in store_map.values()]
    rows.sort(key=lambda row: (row["STATE"], row["CITY"], row["LOCATION_NAME"], row["POSTCODE"]))

    issues = validate_rows(rows)
    if issues:
        raise RuntimeError("Validation failed:\n" + "\n".join(issues[:25]))

    write_csv(FINAL_OUTPUT_CSV, rows)
    save_progress(grid, len(grid), store_map, checkpoint_written, started_at)

    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "source_url": SOURCE_URL,
        "source_page_used": STORE_PAGE_URL,
        "grid_size": len(grid),
        "final_unique_store_count": len(rows),
        "checkpoint_written": checkpoint_written,
        "started_at_utc": started_at,
        "finished_at_utc": utc_now_iso(),
        "final_output_csv": str(FINAL_OUTPUT_CSV),
        "checkpoint_csv": str(CHECKPOINT_CSV) if checkpoint_written else "",
        "progress_json": str(PROGRESS_JSON),
        "raw_json": str(RAW_JSON),
    }
    SUMMARY_JSON.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"[DONE] Final rows: {len(rows)}")
    print(f"[DONE] Output CSV: {FINAL_OUTPUT_CSV}")


if __name__ == "__main__":
    main()
