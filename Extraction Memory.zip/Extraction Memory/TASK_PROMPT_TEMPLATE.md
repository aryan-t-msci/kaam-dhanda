# Extraction Task Prompt — Single Issuer
#
# HOW TO USE:
#   1. Fill in the PARAMETERS section below.
#   2. Send the entire contents to the agent as-is.
#   3. Delete the FILLED EXAMPLE section at the bottom before sending.

---

From MEMORY_FOLDER, read and execute these files in order:
1. prompt.md — standing rules for all extraction tasks
2. TASK_PROMPT_TEMPLATE.md — this file (already loaded)

Then execute the following task using the parameters below.

---

## PARAMETERS

```
MEMORY_FOLDER : <path to your Extraction Memory folder>
ISSUER_ID     : IID000000000000000
ISSUER_NAME   : Company Name Here
COUNT         : 0
TEMP_FOLDER   : <path to your Temp folder>
OUTPUT_FOLDER : <path to your Output folder>
```

## URLS

Paste URLs below — one per line, or comma-separated, or tab-separated. All formats accepted.

```
https://www.example.com/locations
https://www.example.com/contact
```

## NOTES  ← delete this section if nothing to add

```
- [Any known quirks, specific pages, or context about this company]
```

---

# ═══════════════════════════════════════════════════════════
# FILLED EXAMPLE — delete this section before sending
# ═══════════════════════════════════════════════════════════

## PARAMETERS

```
MEMORY_FOLDER : C:\Users\yourname\OneDrive\Extraction Memory
ISSUER_ID     : IID000000005041473
ISSUER_NAME   : Eternal Ltd
COUNT         : 35
TEMP_FOLDER   : C:\Users\yourname\OneDrive\ACWI Collection\Temp
OUTPUT_FOLDER : C:\Users\yourname\OneDrive\ACWI Collection\Output
```

## URLS

```
https://www.eternal.com/policies/license/
https://www.eternal.com/investor-relations/
```
