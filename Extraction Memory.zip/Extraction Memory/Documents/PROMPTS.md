# Extraction System — Trigger Prompts
# Version: 1.0 | Last Updated: 2026-05-04
#
# This file contains the exact prompts to paste into any agent (Codex, Claude Code,
# Cursor, Gemini CLI, VS Code Copilot, etc.) to start an extraction run.
#
# Copy the relevant section, fill in the placeholder values, and paste.
# Nothing else is needed — the agent handles everything from there.

---

## 1. BATCH RUN (Multi-Agent — Recommended for 2+ issuers)

Uses the orchestrator + one-worker-per-issuer architecture.
The orchestrator probes the session cap dynamically, builds an issuer queue,
and spawns one isolated worker per issuer in a rolling pool. After the main
pass, gap issuers automatically enter a rework pass. Fully autonomous.

> Note: the conversation you paste this into becomes the orchestrator and runs the
> workflow itself. It should NOT spawn a separate agent "to run the orchestrator" — if a
> model does that, the run hard-blocks after setup. Models on Codex 5.4+ handle this
> correctly; weaker/older tiers (e.g. 5.3) may mis-delegate and fail. Prefer 5.4+ for batches.

```
From MEMORY_FOLDER, read and execute these files in order:
1. prompt.md
2. ORCHESTRATOR_PROMPT.md

MEMORY_FOLDER : <path to your Extraction Memory folder>
INPUT_FILE    : <path to your input xlsx file>
TEMP_FOLDER   : <path to your Temp folder>
OUTPUT_FOLDER : <path to your Output folder>
SCOPE_METHODOLOGY : <optional: path/URL to an updated scope methodology; blank = use SCOPE_METHODOLOGY.md in MEMORY_FOLDER>
```

**Input file formats accepted:**
- Format A (single sheet): `ISSUER_ID`, `ISSUER_NAME`, `COUNT` (per URL), `URL`, `URL_Type` (optional)
- Format B (two sheets): Sheet 1 = `Issuer ID`, `Issuer Name`, `Expected Count`; Sheet 2 = `ISSUER_ID`, `COMPANY_NAME`, `relevant_url`

**Example (filled in):**
```
From MEMORY_FOLDER, read and execute these files in order:
1. prompt.md
2. ORCHESTRATOR_PROMPT.md

MEMORY_FOLDER : C:\Users\yourname\OneDrive\Extraction Memory
INPUT_FILE    : C:\Users\yourname\OneDrive\ACWI Collection\Output\April2026.xlsx
TEMP_FOLDER   : C:\Users\yourname\OneDrive\ACWI Collection\Temp
OUTPUT_FOLDER : C:\Users\yourname\OneDrive\ACWI Collection\Output
```

---

## 2. SINGLE ISSUER RUN

For one company at a time. The agent reads prompt.md and runs the full
extraction pipeline — recon, extraction, validation, QA, KB update.

```
From MEMORY_FOLDER, read and execute these files in order:
1. prompt.md
2. TASK_PROMPT_TEMPLATE.md

MEMORY_FOLDER : <path to your Extraction Memory folder>
ISSUER_ID     : IID000000000000000
ISSUER_NAME   : Company Name Here
COUNT         : 0
TEMP_FOLDER   : <path to your Temp folder>
OUTPUT_FOLDER : <path to your Output folder>
SCOPE_METHODOLOGY : <optional: path/URL to an updated scope methodology; blank = use SCOPE_METHODOLOGY.md in MEMORY_FOLDER>

URLS
<paste URLs here — one per line, or comma-separated, or tab-separated>
```

**Example (filled in):**
```
From MEMORY_FOLDER, read and execute these files in order:
1. prompt.md
2. TASK_PROMPT_TEMPLATE.md

MEMORY_FOLDER : C:\Users\yourname\OneDrive\Extraction Memory
ISSUER_ID     : IID000000002182781
ISSUER_NAME   : SABIC
COUNT         : 15
TEMP_FOLDER   : C:\Users\yourname\OneDrive\ACWI Collection\Temp
OUTPUT_FOLDER : C:\Users\yourname\OneDrive\ACWI Collection\Output

URLS
https://www.sabic.com/en/locations/35180-united-states
https://www.sabic.com/en/locations/5916-united-states
https://www.sabic.com/en/locations/14348-canada-cobe
```

---

## 3. SINGLE-AGENT BATCH RUN (Fallback — if multi-agent spawn unavailable)

Uses the legacy single-agent batch template. One agent handles all issuers
sequentially with an internal rolling queue. Use this if the platform you
are running on does not support autonomous subagent spawning.

```
From MEMORY_FOLDER, read and execute these files in order:
1. prompt.md
2. TASK_PROMPT_TEMPLATE_BATCH.md

MEMORY_FOLDER : <path to your Extraction Memory folder>
INPUT_FILE    : <path to your input xlsx file>
TEMP_FOLDER   : <path to your Temp folder>
OUTPUT_FOLDER : <path to your Output folder>
SCOPE_METHODOLOGY : <optional: path/URL to an updated scope methodology; blank = use SCOPE_METHODOLOGY.md in MEMORY_FOLDER>
```

**Example (filled in):**
```
From MEMORY_FOLDER, read and execute these files in order:
1. prompt.md
2. TASK_PROMPT_TEMPLATE_BATCH.md

MEMORY_FOLDER : C:\Users\yourname\OneDrive\Extraction Memory
INPUT_FILE    : C:\Users\yourname\OneDrive\ACWI Collection\Output\April2026.xlsx
TEMP_FOLDER   : C:\Users\yourname\OneDrive\ACWI Collection\Temp
OUTPUT_FOLDER : C:\Users\yourname\OneDrive\ACWI Collection\Output
```

---

## NOTES

**WORKER_COUNT is no longer a parameter.** The orchestrator probes the session cap dynamically (trying 20 → 15 → 10 → 6) and uses whatever the platform supports. One slot is always reserved for the orchestrator.

**One worker per issuer.** Each worker is a fully isolated single-issuer conversation. The orchestrator manages a rolling pool — as workers complete, new ones are spawned for the next queued issuer.

**Rework pass is automatic.** After the main pass, gap issuers automatically enter a rework pass targeting Tier 3/4/5 sources. No manual action needed.

**URL_Type column:** If your input Excel does not have a URL_Type column (Format B), the orchestrator automatically invokes the URL classification agent before spawning workers.

**Platforms:** These prompts work identically on Codex Desktop, Claude Code, Cursor, Windsurf, Aider, VS Code Copilot Agent, Gemini CLI, and any other agent with filesystem access.
