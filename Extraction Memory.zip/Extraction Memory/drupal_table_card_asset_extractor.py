"""Generalized extractor for Drupal static-table asset listings plus paginated card/detail pages.

This pattern fits corporate sites where one source page exposes facility rows in plain HTML tables
and a second source exposes paginated cards that link to detail pages. The detail pages may expose
either direct address fields or alternate entity pages (financial / annual report / draft filing)
with official registered-office addresses.

How to adapt for another issuer:
1. Update the CONFIGURATION block below with the issuer metadata and source URLs.
2. Adjust the subsidiary/address discovery settings if the site uses a different address label.
3. Keep the generic logic below unchanged unless the Drupal markup pattern itself changes.

Example configuration:
    ISSUER_NAME = "Example Utility"
    ISSUER_ID = "IID000000000000000"
    SUBSTATION_URL = "https://www.example.com/en/assets"
    SUBSIDIARIES_URL = "https://www.example.com/en/subsidiaries"
    ADDRESS_LABEL = "Registered Office"
"""

from __future__ import annotations

import csv
import json
import re
import time
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
from urllib.parse import urljoin, urlparse

import requests
import urllib3
from bs4 import BeautifulSoup


# ============================================================================
# CONFIGURATION — Change these for each issuer
# ============================================================================
ISSUER_ID = "IID000000002179967"
ISSUER_NAME = "POWER GRID CORPORATION OF INDIA LIMITED"
BASE_URL = "https://www.powergrid.in"
SUBSTATION_URL = "https://www.powergrid.in/en/substation"
SUBSIDIARIES_URL = "https://www.powergrid.in/en/subsidiaries"
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")
WORK_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")

FINAL_CSV_NAME = f"{ISSUER_ID}_{ISSUER_NAME}.csv"
CHECKPOINT_NAME = f"{ISSUER_ID}_{ISSUER_NAME}_checkpoint.csv"
PROGRESS_PATH = WORK_DIR / f"{ISSUER_ID}_progress.json"
PARTIAL_ROWS_PATH = WORK_DIR / f"{ISSUER_ID}_partial_rows.json"
SUMMARY_PATH = WORK_DIR / f"{ISSUER_ID}_summary.json"

COUNT_THRESHOLD = 360
PROGRESS_SAVE_EVERY = 20
MAIN_TIMEOUT = 30
PROBE_TIMEOUT = 4

COUNTRY = "India"
COUNTRY_ISO3 = "IND"
COORD_SOURCE = "not_on_website"
SOURCE_TYPE_WEBSITE = "COMPANY WEBSITE"
ADDRESS_LABEL = "Registered Office"

DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/123.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
}

BUSINESS_ACTIVITY_OVERRIDES = {
    "POWERGRID Energy Services Limited": "Energy services business subsidiary",
    "POWERGRID Teleservices Limited": "Telecom / teleservices business subsidiary",
    "Central Transmission Utility Of India Limited": "Central transmission utility business subsidiary",
}

OFFICE_ADDRESS_OVERRIDES = {
    "POWERGRID Energy Services Limited": {
        "source_url": "https://www.powergrid.in/en/powergrid-energy-services-limited-0",
        "registered_office": "B-9, Qutab Institutional Area, Katwaria Sarai, New Delhi-110016, India",
    },
    "POWERGRID Teleservices Limited": {
        "source_url": "https://www.powergrid.in/en/powergrid-teleservices-limited-0",
        "registered_office": "B-9, Qutab Institutional Area, Katwaria Sarai, New Delhi-110016, India",
    },
    "Central Transmission Utility Of India Limited": {
        "source_url": "https://www.powergrid.in/en/central-transmission-utility-india-limited-2",
        "registered_office": "B-9, Qutab Institutional Area, Katwaria Sarai, New Delhi-110016, India",
    },
}

REGION_TITLE_OVERRIDES = {
    "SR and ER Power Transmission Limited": ("Southern Region / Eastern Region", "Multiple States"),
    "SR WR Power Transmission Limited": ("Southern Region / Western Region", "Multiple States"),
    "POWERGRID ERWR Power Transmission Limited [former TBCB Project SPV of Power Grid Corporation of India Limited (POWERGRID)]": (
        "Eastern Region / Western Region",
        "Multiple States",
    ),
    "POWERGRID ER NER Transmission Limited": ("Eastern Region / North Eastern Region", "Multiple States"),
    "POWERGRID West Central Transmission Limited": ("West Central Region", "Multiple States"),
    "POWERGRID Southern Interconnector Transmission System Limited": ("Southern Interconnector", "Multiple States"),
}


INDIAN_STATES = [
    "Andhra Pradesh",
    "Arunachal Pradesh",
    "Assam",
    "Bihar",
    "Chhattisgarh",
    "Delhi",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jammu & Kashmir",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Ladakh",
    "Madhya Pradesh",
    "Maharashtra",
    "Manipur",
    "Meghalaya",
    "Mizoram",
    "Nagaland",
    "Odisha",
    "Punjab",
    "Rajasthan",
    "Sikkim",
    "Tamil Nadu",
    "Telangana",
    "Tripura",
    "Uttar Pradesh",
    "Uttarakhand",
    "West Bengal",
]

TITLE_LOCATION_STATE_HINTS = {
    "Pune": "Maharashtra",
    "Bellary": "Karnataka",
    "Davanagere": "Karnataka",
    "Parli": "Maharashtra",
    "Bidar": "Karnataka",
    "Varanasi": "Uttar Pradesh",
    "Mandsaur": "Madhya Pradesh",
    "Rewa": "Madhya Pradesh",
    "Kurnool": "Andhra Pradesh",
    "Banaskantha": "Gujarat",
    "Sirohi": "Rajasthan",
    "Khandwa": "Madhya Pradesh",
    "Fatehgarh": "Rajasthan",
    "Barmer": "Rajasthan",
    "Chitradurga": "Karnataka",
    "Koppal": "Karnataka",
    "Gadag": "Karnataka",
    "Kudankulam": "Tamil Nadu",
    "Ghiror": "Uttar Pradesh",
    "Siwani": "Haryana",
    "Bikaner": "Rajasthan",
    "Khavda": "Gujarat",
    "Jam Khambhaliya": "Gujarat",
    "Olpad": "Gujarat",
    "Kurawar": "Madhya Pradesh",
    "Bhadla": "Rajasthan",
    "Beawar": "Rajasthan",
    "Sikar": "Rajasthan",
    "Neemrana": "Rajasthan",
    "Vataman": "Gujarat",
    "Ananthpuram": "Andhra Pradesh",
    "Raipur": "Chhattisgarh",
    "Dhamtari": "Chhattisgarh",
    "Neemuch": "Madhya Pradesh",
    "Narela": "Delhi",
    "Vemagiri": "Andhra Pradesh",
    "Meerut": "Uttar Pradesh",
    "Rampur": "Uttar Pradesh",
    "Sambhal": "Uttar Pradesh",
    "Bhuj": "Gujarat",
    "Ajmer": "Rajasthan",
    "Phagi": "Rajasthan",
    "Bhind": "Madhya Pradesh",
    "Guna": "Madhya Pradesh",
    "Khetri": "Rajasthan",
    "Jawaharpur": "Uttar Pradesh",
    "Firozabad": "Uttar Pradesh",
    "Mithilanchal": "Bihar",
    "Medinipur": "West Bengal",
    "Jeerat": "West Bengal",
    "Unchahar": "Uttar Pradesh",
}


OUTPUT_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS",
    "LOCATION_ADDRESS_NATIVE",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
]


urllib3.disable_warnings()


@dataclass
class OfficeAddress:
    source_url: str
    registered_office: str
    corporate_office: str = ""


def make_session() -> requests.Session:
    session = requests.Session()
    session.headers.update(DEFAULT_HEADERS)
    return session


def clean_text(value: str) -> str:
    value = value.replace("\xa0", " ").replace("#", " ")
    value = re.sub(r"\s+", " ", value).strip(" ,;")
    return value


def ascii_text(value: str) -> str:
    value = clean_text(value)
    normalized = unicodedata.normalize("NFKD", value)
    return clean_text(normalized.encode("ascii", "ignore").decode("ascii"))


def title_case_token(token: str) -> str:
    if token.upper() in {"AIS", "GIS", "HVDC", "PS", "TBCB", "RE", "ER", "WR", "SR", "NER"}:
        return token.upper()
    if re.fullmatch(r"[IVX]+", token):
        return token.upper()
    return token.capitalize()


def prettify_name(value: str) -> str:
    value = clean_text(value)
    value = value.replace("(", " (").replace(")", ") ")
    value = re.sub(r"([a-z])([A-Z])", r"\1 \2", value)
    value = re.sub(r"\s+", " ", value).strip()
    parts = re.split(r"(\s+|/|-)", value)
    pretty_parts = []
    for part in parts:
        if not part or part.isspace() or part in {"/", "-"}:
            pretty_parts.append(part)
            continue
        pretty_parts.append(title_case_token(part))
    return clean_text("".join(pretty_parts))


def derive_substation_city(name: str) -> str:
    value = name.upper()
    replacements = {
        "BIHARSHRIFF": "Bihar Sharif",
        "NEW PURNEA": "Purnea",
        "PURNEA": "Purnea",
        "SASARAMHVDC": "Sasaram",
        "ALIPURDUARHVDC": "Alipurduar",
        "BISHWANATH CHARIALI(HVDC)": "Bishwanath Chariali",
        "BHIWADIHVDC": "Bhiwadi",
        "DADRI HVDC": "Dadri",
        "MEERUT(765 KV)": "Meerut",
        "PARBATI PS / BANALA": "Banala",
        "DRASS GIS": "Drass",
        "BIKANER-II PS": "Bikaner",
        "SIKAR-2 TBCB": "Sikar",
        "KHAVDA": "Khavda",
        "NEEMARANA": "Neemrana",
        "LADDLAKH": "Ladakh",
    }
    if value in replacements:
        return replacements[value]
    city = re.sub(r"\(.*?\)", "", name)
    city = re.sub(r"\b(HVDC|AIS|GIS|PS|TBCB)\b", "", city, flags=re.I)
    city = re.sub(r"\bNEW\b", "", city, flags=re.I)
    city = re.sub(r"\b[IVX]+$|\b\d+\b", "", city, flags=re.I)
    city = clean_text(city.replace("/", " ").replace("-", " "))
    city = prettify_name(city)
    return city or prettify_name(name)


def parse_indian_address(address: str) -> Tuple[str, str, str]:
    text = clean_text(address)
    postcode_match = re.search(r"\b(\d{6})\b", text)
    postcode = postcode_match.group(1) if postcode_match else ""

    city = ""
    state = ""
    if "New Delhi" in text:
        city, state = "New Delhi", "Delhi"
    elif "Gurgaon" in text or "Gurugram" in text:
        city, state = "Gurgaon", "Haryana"
    else:
        for state_name in INDIAN_STATES:
            if state_name.lower() in text.lower():
                state = state_name
                break
        parts = [clean_text(part) for part in text.split(",") if clean_text(part)]
        if parts:
            city = parts[-2] if len(parts) >= 2 else parts[-1]
            city = re.sub(r"\(.*?\)", "", city).strip()

    return clean_text(city), clean_text(state), postcode


def classify_source_type(url: str) -> str:
    if re.search(r"\.(pdf|docx?|xlsx?)($|\?)", url, flags=re.I):
        return "COMPANY REPORT"
    return SOURCE_TYPE_WEBSITE


def save_progress(rows: Sequence[Dict[str, str]], stage: str, extra: Optional[Dict[str, object]] = None) -> None:
    PROGRESS_PATH.write_text(
        json.dumps({"stage": stage, "count": len(rows), **(extra or {})}, indent=2),
        encoding="utf-8",
    )
    PARTIAL_ROWS_PATH.write_text(json.dumps(list(rows), indent=2), encoding="utf-8")


def write_csv(path: Path, rows: Sequence[Dict[str, str]]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=OUTPUT_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


def fetch_html(session: requests.Session, url: str, timeout: int = MAIN_TIMEOUT) -> str:
    response = session.get(url, timeout=timeout, verify=False)
    response.raise_for_status()
    return response.text


def extract_lines_text(html: str) -> List[str]:
    soup = BeautifulSoup(html, "html.parser")
    lines = [clean_text(line) for line in soup.get_text("\n").splitlines()]
    return [line for line in lines if line]


def extract_registered_office_from_html(html: str) -> Tuple[str, str]:
    lines = extract_lines_text(html)
    registered = ""
    corporate = ""
    for index, line in enumerate(lines):
        if line == "Registered Office" and index + 1 < len(lines):
            registered = lines[index + 1]
        if line == "Corporate Office" and index + 1 < len(lines):
            corporate = lines[index + 1]
    if registered:
        return registered, corporate

    patterns = {
        "registered": r"Registered Office.*?>([^<>]+)</a>",
        "corporate": r"Corporate Office.*?>([^<>]+)</a>",
    }
    reg_match = re.search(patterns["registered"], html, flags=re.I | re.S)
    corp_match = re.search(patterns["corporate"], html, flags=re.I | re.S)
    if reg_match:
        registered = BeautifulSoup(reg_match.group(1), "html.parser").get_text(" ", strip=True)
    if corp_match:
        corporate = BeautifulSoup(corp_match.group(1), "html.parser").get_text(" ", strip=True)
    return clean_text(registered), clean_text(corporate)


def candidate_entity_urls(listing_url: str) -> Iterable[str]:
    parsed = urlparse(listing_url)
    slug = parsed.path.rstrip("/").split("/")[-1]
    base_slug = re.sub(r"-\d+$", "", slug)
    seen = set()
    variants = [slug, base_slug]
    variants.extend(f"{base_slug}-{idx}" for idx in range(10))
    variants.extend(f"{slug}-{idx}" for idx in range(10))
    for variant in variants:
        if variant and variant not in seen:
            seen.add(variant)
            yield urljoin(f"{parsed.scheme}://{parsed.netloc}", f"/en/{variant}")


def discover_office_address(session: requests.Session, listing_url: str) -> Optional[OfficeAddress]:
    for candidate in candidate_entity_urls(listing_url):
        try:
            html = fetch_html(session, candidate, timeout=PROBE_TIMEOUT)
        except Exception:
            continue
        registered, corporate = extract_registered_office_from_html(html)
        if registered:
            return OfficeAddress(source_url=candidate, registered_office=registered, corporate_office=corporate)
    return None


def parse_substation_rows(session: requests.Session, rows_out: List[Dict[str, str]]) -> None:
    html = fetch_html(session, SUBSTATION_URL)
    soup = BeautifulSoup(html, "html.parser")
    processed = 0
    for table in soup.select("table"):
        for tr in table.select("tbody tr"):
            cells = [clean_text(td.get_text(" ", strip=True)) for td in tr.select("td")]
            if len(cells) < 4:
                continue
            _, state, substation, substation_type = cells[:4]
            city = derive_substation_city(substation)
            pretty_substation = prettify_name(substation)
            rows_out.append(
                {
                    "ISSUER_ID": ISSUER_ID,
                    "ISSUER_NAME": ISSUER_NAME,
                    "LOCATION_NAME": ascii_text(f"{pretty_substation} Substation"),
                    "LOCATION_NAME_NATIVE": "",
                    "LOCATION_ADDRESS": ascii_text(f"{pretty_substation} Substation, {city}, {state}, {COUNTRY}"),
                    "LOCATION_ADDRESS_NATIVE": "",
                    "LATITUDE": "",
                    "LONGITUDE": "",
                    "COUNTRY": COUNTRY,
                    "COUNTRY_ISO3": COUNTRY_ISO3,
                    "POSTCODE": "",
                    "STATE": ascii_text(prettify_name(state)),
                    "CITY": ascii_text(city),
                    "SOURCE_URL": SUBSTATION_URL,
                    "SOURCE_TYPE": SOURCE_TYPE_WEBSITE,
                    "ACTIVITY_AT_ASSET": ascii_text(f"Transmission Substation ({substation_type.upper()})"),
                    "coord_source": COORD_SOURCE,
                }
            )
            processed += 1
            if processed % PROGRESS_SAVE_EVERY == 0:
                save_progress(rows_out, "substations", {"processed_substations": processed})


def extract_detail_fields(html: str) -> Dict[str, str]:
    soup = BeautifulSoup(html, "html.parser")
    title = clean_text(soup.select_one("h2").get_text(" ", strip=True)) if soup.select_one("h2") else ""
    category = clean_text(
        soup.select_one(".field--name-field-subsidiaries-category").get_text(" ", strip=True)
    ) if soup.select_one(".field--name-field-subsidiaries-category") else ""
    status = clean_text(
        soup.select_one(".field--name-field-project-status").get_text(" ", strip=True)
    ) if soup.select_one(".field--name-field-project-status") else ""
    objective_node = soup.select_one(".field--name-field-subsidiaries-objective")
    objective = clean_text(objective_node.get_text(" ", strip=True)) if objective_node else ""
    return {"title": title, "category": category, "status": status, "objective": objective}


def derive_title_geography(title: str, objective: str) -> Tuple[str, str]:
    if title in REGION_TITLE_OVERRIDES:
        return REGION_TITLE_OVERRIDES[title]
    title_clean = re.sub(r"\[.*?\]", "", title)
    title_clean = re.sub(r"^POWERGRID\s+", "", title_clean, flags=re.I)
    title_clean = re.sub(r"^NES\s+", "", title_clean, flags=re.I)
    title_clean = re.sub(
        r"\b(Power )?Transmission( System)? Limited\.?$|\bAugmentation Transmission Limited\.?$|\bEnergy Services Limited\.?$|\bTeleservices Limited\.?$",
        "",
        title_clean,
        flags=re.I,
    )
    title_clean = clean_text(title_clean)
    title_clean = re.sub(r"\bformer .*", "", title_clean, flags=re.I)
    city = ascii_text(prettify_name(title_clean.replace(" and ", " / ").replace(" Of India", "")))
    states = []
    for state_name in INDIAN_STATES:
        if state_name.lower() in objective.lower():
            states.append(state_name)
    if not states:
        for hint, state_name in TITLE_LOCATION_STATE_HINTS.items():
            if hint.lower() in city.lower():
                states.append(state_name)
    deduped_states = []
    for state_name in states:
        if state_name not in deduped_states:
            deduped_states.append(state_name)
    return city or "Project Geography", " / ".join(deduped_states)


def activity_for_subsidiary(title: str, category: str, status: str) -> str:
    if title in BUSINESS_ACTIVITY_OVERRIDES:
        return BUSINESS_ACTIVITY_OVERRIDES[title]
    if category:
        if "TBCB" in category.upper():
            base = "Transmission project SPV"
        else:
            base = category
    else:
        base = "Subsidiary"
    if status:
        return f"{base} ({status})"
    return base


def parse_subsidiary_rows(session: requests.Session, rows_out: List[Dict[str, str]]) -> None:
    listing_html = fetch_html(session, SUBSIDIARIES_URL)
    listing_soup = BeautifulSoup(listing_html, "html.parser")
    max_page = 0
    for anchor in listing_soup.select('a[href*="?page="]'):
        match = re.search(r"[?&]page=(\d+)", anchor.get("href", ""))
        if match:
            max_page = max(max_page, int(match.group(1)))

    detail_urls: List[str] = []
    for page_no in range(max_page + 1):
        page_url = f"{SUBSIDIARIES_URL}?page={page_no}"
        page_html = fetch_html(session, page_url)
        page_soup = BeautifulSoup(page_html, "html.parser")
        for anchor in page_soup.select("h4 a[href]"):
            href = anchor.get("href")
            if href and href not in detail_urls:
                detail_urls.append(href)

    processed = 0
    for detail_url in detail_urls:
        html = fetch_html(session, detail_url)
        detail = extract_detail_fields(html)
        override = OFFICE_ADDRESS_OVERRIDES.get(detail["title"])
        if override:
            office = OfficeAddress(
                source_url=override["source_url"],
                registered_office=override["registered_office"],
            )
        else:
            office = discover_office_address(session, detail_url)

        if office:
            address = ascii_text(office.registered_office)
            source_url = office.source_url
            city, state, postcode = parse_indian_address(address)
        else:
            city, state = derive_title_geography(detail["title"], detail["objective"])
            postcode = ""
            address = ascii_text(f"{city}, {state}, {COUNTRY}" if state else f"{city}, {COUNTRY}")
            source_url = detail_url

        rows_out.append(
            {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": ascii_text(detail["title"]),
                "LOCATION_NAME_NATIVE": "",
                "LOCATION_ADDRESS": address,
                "LOCATION_ADDRESS_NATIVE": "",
                "LATITUDE": "",
                "LONGITUDE": "",
                "COUNTRY": COUNTRY,
                "COUNTRY_ISO3": COUNTRY_ISO3,
                "POSTCODE": postcode,
                "STATE": ascii_text(state),
                "CITY": ascii_text(city),
                "SOURCE_URL": source_url,
                "SOURCE_TYPE": classify_source_type(source_url),
                "ACTIVITY_AT_ASSET": ascii_text(activity_for_subsidiary(detail["title"], detail["category"], detail["status"])),
                "coord_source": COORD_SOURCE,
            }
        )
        processed += 1
        if processed % PROGRESS_SAVE_EVERY == 0:
            save_progress(rows_out, "subsidiaries", {"processed_subsidiaries": processed})
        if len(rows_out) >= COUNT_THRESHOLD and not (WORK_DIR / CHECKPOINT_NAME).exists():
            write_csv(WORK_DIR / CHECKPOINT_NAME, rows_out)


def validate_rows(rows: Sequence[Dict[str, str]]) -> None:
    if not rows:
        raise ValueError("No rows extracted.")
    for idx, row in enumerate(rows, start=1):
        if not clean_text(row["LOCATION_ADDRESS"]):
            raise ValueError(f"Blank LOCATION_ADDRESS at row {idx}")
        if not clean_text(row["CITY"]):
            raise ValueError(f"Blank CITY at row {idx}")


def dedupe_rows(rows: Sequence[Dict[str, str]]) -> List[Dict[str, str]]:
    seen = set()
    deduped = []
    for row in rows:
        key = (
            row["LOCATION_NAME"],
            row["LOCATION_ADDRESS"],
            row["SOURCE_URL"],
            row["ACTIVITY_AT_ASSET"],
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)
    return deduped


def main() -> None:
    started = time.time()
    WORK_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    session = make_session()
    rows: List[Dict[str, str]] = []

    parse_substation_rows(session, rows)
    parse_subsidiary_rows(session, rows)

    rows = dedupe_rows(rows)
    validate_rows(rows)
    write_csv(OUTPUT_DIR / FINAL_CSV_NAME, rows)
    save_progress(rows, "completed")

    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "total_rows": len(rows),
        "threshold": COUNT_THRESHOLD,
        "threshold_met": len(rows) >= COUNT_THRESHOLD,
        "substation_source_url": SUBSTATION_URL,
        "subsidiaries_source_url": SUBSIDIARIES_URL,
        "runtime_seconds": round(time.time() - started, 2),
        "output_csv": str(OUTPUT_DIR / FINAL_CSV_NAME),
        "checkpoint_csv": str(WORK_DIR / CHECKPOINT_NAME) if (WORK_DIR / CHECKPOINT_NAME).exists() else "",
    }
    SUMMARY_PATH.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
