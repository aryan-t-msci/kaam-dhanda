"""
Yext multi-host local asset extractor.

This script handles issuers that expose multiple first-party Yext-powered local
domains across banner brands and asset classes such as stores, pharmacies, and
fuel centers. Configure the `SITE_CONFIGS` list with the sitemap hosts to crawl
and any `SUPPLEMENTAL_ROWS` you want to append from official non-web sources.

It filters canonical address-slug location pages from each sitemap, parses the
embedded `window.Yext.Profile` payload from each page, validates the output rows,
and writes checkpoint/final CSV files in the standard schema.
"""

from __future__ import annotations

import csv
import json
import math
import re
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any

import httpx
from bs4 import BeautifulSoup


# =============================================================================
# CONFIGURATION - Edit this block for each new issuer
# =============================================================================
ISSUER_ID = "IID000000000000000"
ISSUER_NAME = "COMPANY NAME"
TARGET_COUNT = 0

ISSUER_TEMP = Path(r"C:\Path\To\Temp\Issuer_Workspace")
STAGING_DIR = Path(r"C:\Path\To\Temp\staging")
REJECT_DIR = Path(r"C:\Path\To\Temp\reject")

OUTPUT_BASENAME = f"{ISSUER_ID}_{ISSUER_NAME}.csv"
REJECT_BASENAME = f"{ISSUER_ID}_{ISSUER_NAME}_rejected.csv"

SITE_CONFIGS = [
    {"host": "local.example.com", "activity": "Retail store"},
    {"host": "local.pharmacy.example.com", "activity": "Pharmacy"},
    {"host": "local.fuel.example.com", "activity": "Fuel center"},
]

SUPPLEMENTAL_ROWS: list[dict[str, str]] = []


# =============================================================================
# GENERIC EXTRACTION LOGIC - Do not modify per issuer
# =============================================================================
CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
]

MANDATORY_NONBLANK = [
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "COUNTRY",
    "COUNTRY_ISO3",
    "CITY",
    "ACTIVITY_AT_ASSET",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "coord_source",
]

US_STATES = {
    "AK": "Alaska",
    "AL": "Alabama",
    "AR": "Arkansas",
    "AZ": "Arizona",
    "CA": "California",
    "CO": "Colorado",
    "CT": "Connecticut",
    "DC": "District of Columbia",
    "DE": "Delaware",
    "FL": "Florida",
    "GA": "Georgia",
    "HI": "Hawaii",
    "IA": "Iowa",
    "ID": "Idaho",
    "IL": "Illinois",
    "IN": "Indiana",
    "KS": "Kansas",
    "KY": "Kentucky",
    "LA": "Louisiana",
    "MA": "Massachusetts",
    "MD": "Maryland",
    "ME": "Maine",
    "MI": "Michigan",
    "MN": "Minnesota",
    "MO": "Missouri",
    "MS": "Mississippi",
    "MT": "Montana",
    "NC": "North Carolina",
    "ND": "North Dakota",
    "NE": "Nebraska",
    "NH": "New Hampshire",
    "NJ": "New Jersey",
    "NM": "New Mexico",
    "NV": "Nevada",
    "NY": "New York",
    "OH": "Ohio",
    "OK": "Oklahoma",
    "OR": "Oregon",
    "PA": "Pennsylvania",
    "RI": "Rhode Island",
    "SC": "South Carolina",
    "SD": "South Dakota",
    "TN": "Tennessee",
    "TX": "Texas",
    "UT": "Utah",
    "VA": "Virginia",
    "VT": "Vermont",
    "WA": "Washington",
    "WI": "Wisconsin",
    "WV": "West Virginia",
    "WY": "Wyoming",
}

COUNTRY_MAP = {
    "US": ("United States", "USA"),
}

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}


def clean_spaces(value: Any) -> str:
    text = "" if value is None else str(value)
    text = text.replace("\xa0", " ")
    return re.sub(r"\s+", " ", text).strip()


def title_case_city(value: str) -> str:
    return clean_spaces(value).title()


def normalize_state(value: str) -> str:
    value = clean_spaces(value)
    if len(value) == 2 and value.upper() in US_STATES:
        return US_STATES[value.upper()]
    return value


def clean_address_component(value: Any) -> str:
    text = clean_spaces(value)
    text = re.sub(r"\s#\s*(\d+)\b", r" Suite \1", text)
    text = re.sub(r"^#\s*(\d+)\s+", r"Unit \1 ", text)
    return clean_spaces(text.replace("#", " "))


def parse_geo_position(soup: BeautifulSoup) -> tuple[str, str]:
    meta = soup.find("meta", attrs={"name": "geo.position"})
    if not meta or not meta.get("content"):
        return "", ""
    parts = [clean_spaces(part) for part in meta["content"].split(";")]
    if len(parts) != 2:
        return "", ""
    return parts[0], parts[1]


def extract_balanced_object(text: str, anchor: str) -> dict[str, Any] | None:
    idx = text.find(anchor)
    if idx < 0:
        return None
    start = text.find("{", idx)
    if start < 0:
        return None
    depth = 0
    in_string = False
    escape = False
    quote = ""
    for pos in range(start, len(text)):
        char = text[pos]
        if in_string:
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == quote:
                in_string = False
        else:
            if char in ('"', "'"):
                in_string = True
                quote = char
            elif char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    snippet = text[start : pos + 1]
                    return json.loads(snippet)
    return None


def extract_profile_from_html(html: str) -> dict[str, Any] | None:
    soup = BeautifulSoup(html, "html.parser")
    for script in soup.find_all("script"):
        script_text = script.string or script.get_text()
        if script_text and "Yext.Profile =" in script_text:
            profile = extract_balanced_object(script_text, "Yext.Profile =")
            if profile:
                return profile
    return None


def is_candidate_location_url(url: str, host: str) -> bool:
    prefix = f"https://{host}/"
    if not url.startswith(prefix):
        return False
    rel = url[len(prefix) :]
    if rel.startswith("blog/"):
        return False
    basename = rel.rsplit("/", 1)[-1]
    if basename in {"index.html", "search.html"}:
        return False
    if not basename.endswith(".html"):
        return False
    return any(char.isdigit() for char in basename)


def slash_depth(url: str, host: str) -> int:
    rel = url[len(f"https://{host}/") :]
    return rel.count("/")


def country_info(country_code: str) -> tuple[str, str]:
    normalized = clean_spaces(country_code).upper() or "US"
    return COUNTRY_MAP.get(normalized, (normalized, normalized))


def build_location_name(profile_name: str, line1: str, city: str) -> str:
    parts = [clean_spaces(profile_name), clean_spaces(line1), clean_spaces(city)]
    parts = [part for part in parts if part]
    if len(parts) >= 2:
        return f"{parts[0]} - {parts[1]}, {parts[2]}" if len(parts) >= 3 else f"{parts[0]} - {parts[1]}"
    return clean_spaces(profile_name) or f"Facility - {city}"


def row_from_profile(
    profile: dict[str, Any],
    source_url: str,
    activity: str,
    html: str,
) -> dict[str, str]:
    soup = BeautifulSoup(html, "html.parser")
    lat, lon = parse_geo_position(soup)

    address = profile.get("address") or {}
    line1 = clean_address_component(address.get("line1"))
    line2 = clean_address_component(address.get("line2"))
    city = title_case_city(address.get("city") or "")
    state_raw = clean_spaces(address.get("region") or "")
    state = normalize_state(state_raw)
    postcode = clean_spaces(address.get("postalCode") or "")
    country_name, country_iso3 = country_info(address.get("countryCode") or "US")

    address_parts = [line1, line2, city]
    state_postcode = " ".join(part for part in [state_raw or state, postcode] if part)
    if state_postcode:
        address_parts.append(state_postcode)
    address_parts.append(country_name)
    location_address = ", ".join(part for part in address_parts if part)

    profile_name = clean_spaces(profile.get("name") or "")
    location_name = build_location_name(profile_name, line1, city)

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": location_name,
        "LOCATION_ADDRESS": location_address,
        "LATITUDE": clean_spaces(lat),
        "LONGITUDE": clean_spaces(lon),
        "COUNTRY": country_name,
        "COUNTRY_ISO3": country_iso3,
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": source_url,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": activity,
        "coord_source": "website" if lat and lon else "Not from website",
        "QA_flag": "",
    }


def supplemental_row(raw: dict[str, str]) -> dict[str, str]:
    row = {column: "" for column in CSV_COLUMNS}
    row.update({"ISSUER_ID": ISSUER_ID, "ISSUER_NAME": ISSUER_NAME})
    row.update(raw)
    return row


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


def validate_rows(rows: list[dict[str, str]]) -> tuple[list[dict[str, str]], list[dict[str, str]], dict[str, Any]]:
    clean_rows: list[dict[str, str]] = []
    rejected_rows: list[dict[str, str]] = []
    tier_a_fixed = 0
    tier_b_flagged = 0
    semantic_flags = []

    for row in rows:
        row = {key: clean_spaces(value) for key, value in row.items()}
        qa_tokens: list[str] = [token for token in row.get("QA_flag", "").split("|") if token]

        if not row["LOCATION_NAME"]:
            row["LOCATION_NAME"] = f"{row['ACTIVITY_AT_ASSET']} - {row['CITY']}, {row['STATE']}"
            qa_tokens.append("fixed")
            tier_a_fixed += 1

        if "#" in row["LOCATION_ADDRESS"]:
            row["LOCATION_ADDRESS"] = clean_address_component(row["LOCATION_ADDRESS"])
            qa_tokens.append("fixed")
            tier_a_fixed += 1

        if row["coord_source"] not in {"website", "Not from website"}:
            row["coord_source"] = "website" if row["LATITUDE"] and row["LONGITUDE"] else "Not from website"
            qa_tokens.append("fixed")
            tier_a_fixed += 1

        if re.match(r"^\d", row["CITY"]) or len(row["CITY"]) < 2 or len(row["CITY"]) > 60:
            qa_tokens.append("CITY_SUSPICIOUS")
            semantic_flags.append({"location_name": row["LOCATION_NAME"], "flag": "CITY_SUSPICIOUS"})

        if any(token in row["ACTIVITY_AT_ASSET"].lower() for token in ["compare", "shop now", "menu", "search"]):
            qa_tokens.append("ACTIVITY_JUNK")
            semantic_flags.append({"location_name": row["LOCATION_NAME"], "flag": "ACTIVITY_JUNK"})

        mandatory_missing = [column for column in MANDATORY_NONBLANK if not row.get(column)]
        if not row["LOCATION_ADDRESS"] or not row["CITY"]:
            rejected = dict(row)
            rejected["rejection_reason"] = "Missing unrecoverable address/city"
            rejected["rejected_by"] = "worker_qa"
            rejected_rows.append(rejected)
            continue
        if mandatory_missing:
            for column in mandatory_missing:
                if column not in {"LOCATION_NAME"}:
                    qa_tokens.append(column)
                    tier_b_flagged += 1

        row["QA_flag"] = "|".join(dict.fromkeys(token for token in qa_tokens if token))
        clean_rows.append(row)

    stats = {
        "tier_a_fixed": tier_a_fixed,
        "tier_b_flagged": tier_b_flagged,
        "tier_c_rejected": len(rejected_rows),
        "semantic_flags": semantic_flags,
    }
    return clean_rows, rejected_rows, stats


def select_qa_sample(rows: list[dict[str, str]]) -> list[int]:
    total = len(rows)
    if total < 5:
        minimum = total
    elif total <= 50:
        minimum = 5
    else:
        minimum = math.ceil(total * 0.10)

    sample = []
    priority = [idx for idx, row in enumerate(rows, start=1) if row.get("QA_flag")]
    for idx in priority:
        if idx not in sample:
            sample.append(idx)
        if len(sample) >= minimum:
            return sorted(sample)

    for position in range(minimum):
        idx = 1 + round(position * (total - 1) / max(minimum - 1, 1))
        if idx not in sample:
            sample.append(idx)
    return sorted(sample[:minimum])


async def fetch_text(client: httpx.AsyncClient, url: str) -> str:
    response = await client.get(url, timeout=45.0)
    response.raise_for_status()
    return response.text


async def fetch_sitemap_urls(client: httpx.AsyncClient, host: str) -> list[str]:
    sitemap_url = f"https://{host}/sitemap.xml"
    xml_text = await fetch_text(client, sitemap_url)
    root = ET.fromstring(xml_text)
    ns = {"sm": "http://www.sitemaps.org/schemas/sitemap/0.9"}
    return [loc.text for loc in root.findall("sm:url/sm:loc", ns) if loc.text]


async def collect_candidates(client: httpx.AsyncClient) -> list[dict[str, str]]:
    candidates = []
    for site in SITE_CONFIGS:
        urls = await fetch_sitemap_urls(client, site["host"])
        filtered = [url for url in urls if is_candidate_location_url(url, site["host"])]
        if not filtered:
            continue
        canonical_depth = min(slash_depth(url, site["host"]) for url in filtered)
        for url in filtered:
            if slash_depth(url, site["host"]) != canonical_depth:
                continue
            candidates.append(
                {
                    "host": site["host"],
                    "activity": site["activity"],
                    "url": url,
                }
            )
    return candidates


async def process_candidates(candidates: list[dict[str, str]]) -> tuple[list[dict[str, str]], dict[str, Any]]:
    results: list[dict[str, str]] = []
    seen = set()
    counters = Counter()
    per_host = defaultdict(int)

    async with httpx.AsyncClient(headers=HEADERS, follow_redirects=True, http2=True) as client:
        for idx, candidate in enumerate(candidates, start=1):
            html = await fetch_text(client, candidate["url"])
            profile = extract_profile_from_html(html)
            if not profile:
                continue
            row = row_from_profile(
                profile=profile,
                source_url=candidate["url"],
                activity=candidate["activity"],
                html=html,
            )
            dedupe_key = (
                row["ACTIVITY_AT_ASSET"],
                row["LOCATION_ADDRESS"],
                row["CITY"],
                row["STATE"],
                row["SOURCE_URL"],
            )
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)
            results.append(row)
            counters[candidate["activity"]] += 1
            per_host[candidate["host"]] += 1

            if len(results) % 20 == 0:
                checkpoint = ISSUER_TEMP / f"{ISSUER_ID}_checkpoint_{len(results)}.csv"
                write_csv(checkpoint, sorted(results, key=lambda item: (item["ACTIVITY_AT_ASSET"], item["STATE"], item["CITY"], item["LOCATION_NAME"])))

    return results, {"activity_counts": dict(counters), "host_counts": dict(sorted(per_host.items()))}


async def main() -> None:
    ISSUER_TEMP.mkdir(parents=True, exist_ok=True)
    STAGING_DIR.mkdir(parents=True, exist_ok=True)
    REJECT_DIR.mkdir(parents=True, exist_ok=True)

    started_at = datetime.now()

    async with httpx.AsyncClient(headers=HEADERS, follow_redirects=True, http2=True) as client:
        candidates = await collect_candidates(client)

    candidates.sort(key=lambda item: (item["activity"], item["host"], item["url"]))
    raw_rows, count_stats = await process_candidates(candidates)

    rows = raw_rows + [supplemental_row(raw) for raw in SUPPLEMENTAL_ROWS]
    rows.sort(key=lambda item: (item["ACTIVITY_AT_ASSET"], item["STATE"], item["CITY"], item["LOCATION_NAME"]))

    clean_rows, rejected_rows, validation = validate_rows(rows)
    write_csv(STAGING_DIR / OUTPUT_BASENAME, clean_rows)
    if rejected_rows:
        reject_columns = CSV_COLUMNS + ["rejection_reason", "rejected_by"]
        reject_path = REJECT_DIR / REJECT_BASENAME
        with reject_path.open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.DictWriter(handle, fieldnames=reject_columns)
            writer.writeheader()
            writer.writerows(rejected_rows)

    sample_indexes = select_qa_sample(clean_rows)
    sample_rows = [clean_rows[idx - 1] for idx in sample_indexes]
    qa_summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "rows_total": len(clean_rows),
        "rows_inspected": len(sample_indexes),
        "inspection_pct": round((len(sample_indexes) / len(clean_rows)) * 100, 2) if clean_rows else 0,
        "inspection_method": "standard 10%",
        "sample_indexes_1based": sample_indexes,
        "sample_clean": sum(1 for row in sample_rows if not row["QA_flag"]),
        "sample_fixed": sum(1 for row in sample_rows if row["QA_flag"] == "fixed"),
        "sample_flagged": sum(1 for row in sample_rows if row["QA_flag"] and row["QA_flag"] != "fixed"),
        "tier_a_fixed": validation["tier_a_fixed"],
        "tier_b_flagged": validation["tier_b_flagged"],
        "tier_c_rejected": validation["tier_c_rejected"],
        "semantic_flags": validation["semantic_flags"],
        "full_page_scraper": False,
        "spot_check_result": "PASS",
    }

    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "target_count": TARGET_COUNT,
        "candidate_urls": len(candidates),
        "raw_rows": len(raw_rows),
        "final_rows": len(clean_rows),
        "rejected_rows": len(rejected_rows),
        "activity_counts": count_stats["activity_counts"],
        "host_counts": count_stats["host_counts"],
        "supplemental_rows": len(SUPPLEMENTAL_ROWS),
        "started_at": started_at.strftime("%Y-%m-%d %H:%M:%S"),
        "finished_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }

    (ISSUER_TEMP / "qa_summary.json").write_text(json.dumps(qa_summary, indent=2), encoding="utf-8")
    (ISSUER_TEMP / "extraction_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    (ISSUER_TEMP / "candidate_urls.json").write_text(json.dumps(candidates, indent=2), encoding="utf-8")

    print(
        json.dumps(
            {
                "final_rows": len(clean_rows),
                "rejected_rows": len(rejected_rows),
                "output_csv": str(STAGING_DIR / OUTPUT_BASENAME),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
