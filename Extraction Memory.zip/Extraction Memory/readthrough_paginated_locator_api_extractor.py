"""
Extract a paginated facility-locator JSON inventory through a remote text fetch.

Knowledge-base classification: Category A reusable P-30 extractor.

Platform pattern:
    P-30 JS-discovered JSON API. The locator exposes a public paginated JSON
    endpoint, but its host may be unreachable from the local network. A
    configurable read-through URL can retrieve the exact official response.

How to configure:
    Edit only the CONFIGURATION block for another issuer using the same payload
    shape. Set the issuer identity, official locator URL/key, page size,
    country/postcode rules, source corrections, and optional supplements.

Usage:
    python readthrough_paginated_locator_api_extractor.py

The script checkpoints every page, deduplicates by store ID, enforces the
standard facility schema, writes rejected rows and QA detail to Temp, and
exports only the final CSV to Output.
"""

from __future__ import annotations

import csv
import json
import re
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

import requests


# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Edit this block for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_ID = "IID000000002149182"
ISSUER_NAME = "FIRSTCASH, INC."

LOCATOR_PAGE_URL = "http://find.cashamerica.us/#/stores"
API_BASE_URL = "http://find.cashamerica.us/api/stores"
API_KEY = "D21BFED01A40402BADC9B931165432CD"
READ_THROUGH_PREFIX = "https://r.jina.ai/"
REQUEST_LATITUDE = 39.5
REQUEST_LONGITUDE = -98.35
REQUEST_DATE = "2026-07-28T00:00:00.000Z"
PAGE_SIZE = 1500
MAX_PAGES = 10

TEMP_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\In House Issuers\Temp"
)
OUTPUT_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\In House Issuers\Output"
)
OUTPUT_CSV = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
REJECTED_CSV = TEMP_DIR / f"{ISSUER_ID}_rejected.csv"
PROGRESS_JSON = TEMP_DIR / f"{ISSUER_ID}_progress.json"
QA_JSON = TEMP_DIR / f"{ISSUER_ID}_qa.json"

US_STATE_CODES = {
    "AL",
    "AK",
    "AZ",
    "AR",
    "CA",
    "CO",
    "CT",
    "DE",
    "DC",
    "FL",
    "GA",
    "HI",
    "ID",
    "IL",
    "IN",
    "IA",
    "KS",
    "KY",
    "LA",
    "ME",
    "MD",
    "MA",
    "MI",
    "MN",
    "MS",
    "MO",
    "MT",
    "NE",
    "NV",
    "NH",
    "NJ",
    "NM",
    "NY",
    "NC",
    "ND",
    "OH",
    "OK",
    "OR",
    "PA",
    "RI",
    "SC",
    "SD",
    "TN",
    "TX",
    "UT",
    "VT",
    "VA",
    "WA",
    "WV",
    "WI",
    "WY",
}

PRIMARY_STATE_CODES = US_STATE_CODES
PRIMARY_STATE_CODE_COUNTRY = ("United States of America (the)", "USA")
COUNTRY_BY_STATE_VALUE = {
    "Guatemala": ("Guatemala", "GTM"),
    "El Salvador": ("El Salvador", "SLV"),
    "Colombia": ("Colombia", "COL"),
}
DEFAULT_COUNTRY = ("Mexico", "MEX")
COUNTRY_LABEL_STATE_VALUES = set(COUNTRY_BY_STATE_VALUE)
POSTCODE_PATTERNS = {
    "USA": r"^\d{5}(?:-\d{4})?$",
    "MEX": r"^\d{5}$",
    "GTM": r"^\d{5}$",
    "SLV": r"^\d{4}$",
    "COL": r"^\d{6}$",
}
STORE_ACTIVITY = "Pawn lending and retail store"
SOURCE_TYPE = "COMPANY WEBSITE"

# Explicit corrections are confined to configuration so the generic extraction
# logic remains reusable. Each correction must be supported by the source data.
STORE_CORRECTIONS = {
    "3537": {
        "city": "Bogota",
        "qa_flag": "CITY",
        "note": "Source city was S/D; official coordinates and the matching Colombia cluster place the store in Bogota.",
    },
    "5834": {
        "city": "Torreon",
        "state": "Coahuila",
        "postcode": "27000",
        "qa_flag": "fixed",
        "note": "Source embedded city, state, and postcode in the city field.",
    },
    "4076": {
        "city": "San Miguel",
        "qa_flag": "CITY",
        "note": "Source city repeated the country; Avenida Roosevelt and the official coordinates place the store in San Miguel.",
    },
    "4077": {
        "city": "Usulutan",
        "qa_flag": "CITY",
        "note": "Source city repeated the country; Barrio La Parroquia and the official coordinates place the store in Usulutan.",
    },
    "3823": {
        "city": "Agua Prieta",
        "qa_flag": "CITY",
        "note": "Source city was S/D; street and postcode context identify Agua Prieta.",
    },
    "3828": {
        "city": "Garcia",
        "qa_flag": "CITY",
        "note": "Source city was S/D; Abraham Lincoln and postcode 66003 identify Garcia, Nuevo Leon.",
    },
    "3819": {
        "city": "Gutierrez Zamora",
        "qa_flag": "CITY",
        "note": "Source city was S/D; Avenida Benito Juarez, Veracruz, and postcode 93556 identify Gutierrez Zamora.",
    },
    "3626": {
        "city": "Acaxochitlan",
        "qa_flag": "CITY",
        "note": "Source city was S/D; Javier Rojo Gomez and postcode 43720 identify Acaxochitlan, Hidalgo.",
    },
    "4031": {
        "city": "Santa Elena",
        "output_state": "Peten",
        "qa_flag": "CITY",
        "note": "Source combined Santa Elena and the Flores municipality in CITY.",
    },
    "4045": {
        "city": "Poptun",
        "output_state": "Peten",
        "postcode": "",
        "qa_flag": "CITY",
        "note": "Source used the Peten department as CITY; official coordinates place the store in Poptun. The inconsistent source postcode was cleared.",
    },
    "3961": {
        "city": "San Juan Sacatepequez",
        "qa_flag": "CITY",
        "note": "Corrected the source spelling 'Scatepequez' using the duplicate municipality spelling in the official locator.",
    },
    "3964": {
        "city": "Zacapa",
        "output_state": "Zacapa",
        "qa_flag": "CITY",
        "note": "Corrected the source typo 'Zazapa'; the official coordinates match another Zacapa locator row.",
    },
    "4052": {
        "city": "El Progreso",
        "output_state": "Jutiapa",
        "qa_flag": "CITY",
        "note": "Source combined the municipality and department in CITY.",
    },
}

# The source uses the country name "Guatemala" as a placeholder city for these
# rows. Cities below were recovered from the locator's own coordinates and
# checked against the street/postcode context; they remain Tier B review flags.
GUATEMALA_CITY_BY_STORE = {
    "3970": "Huehuetenango",
    "3959": "San Pedro Carcha",
    "3968": "Coatepeque",
    "3958": "Retalhuleu",
    "3966": "Mazatenango",
    "3962": "Zacapa",
    "4002": "Guatemala City",
    "4043": "Guatemala City",
    "4008": "Guatemala City",
    "4015": "Guatemala City",
    "4051": "Guatemala City",
    "4020": "Guatemala City",
    "4023": "Guatemala City",
    "4032": "Guatemala City",
    "4005": "Guatemala City",
    "4059": "Guatemala City",
    "4041": "Guatemala City",
    "4033": "Guatemala City",
    "4003": "Guatemala City",
    "3972": "Palencia",
    "4046": "Guatemala City",
    "4047": "Guatemala City",
    "3957": "Patulul",
    "4026": "Guatemala City",
    "3967": "Villa Canales",
    "3953": "Barberena",
    "3963": "Jutiapa",
}

OFFICIAL_SUPPLEMENTS = [
    {
        "LOCATION_NAME": "FirstCash Headquarters",
        "LOCATION_ADDRESS": (
            "1600 West 7th Street, Fort Worth, TX 76102, "
            "United States of America (the)"
        ),
        "LATITUDE": "",
        "LONGITUDE": "",
        "COUNTRY": "United States of America (the)",
        "COUNTRY_ISO3": "USA",
        "POSTCODE": "76102",
        "STATE": "TX",
        "CITY": "Fort Worth",
        "SOURCE_URL": "https://firstcash.com/",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Corporate office",
        "coord_source": "Not from website",
        "QA_flag": "",
        "LOCATION_NAME_NATIVE": "",
        "LOCATION_ADDRESS_NATIVE": "",
    }
]

HTTP_TIMEOUT_SECONDS = 60
USER_AGENT = "Mozilla/5.0 (compatible; FacilityExtraction/1.0)"


# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════
OUTPUT_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS_NATIVE",
]


def ascii_text(value: Any) -> str:
    """Transliterate Latin-script source strings to ASCII."""
    text = "" if value is None else str(value)
    replacements = str.maketrans(
        {
            "ß": "ss",
            "ä": "ae",
            "ö": "oe",
            "ü": "ue",
            "Ä": "Ae",
            "Ö": "Oe",
            "Ü": "Ue",
            "–": "-",
            "—": "-",
            "’": "'",
            "“": '"',
            "”": '"',
        }
    )
    text = text.translate(replacements)
    return unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()


def clean_space(value: Any) -> str:
    return re.sub(r"\s+", " ", "" if value is None else str(value)).strip()


def clean_address_component(value: Any) -> str:
    text = ascii_text(clean_space(value))
    # Preserve unit/building numbers while complying with the no-# rule.
    text = re.sub(r"\s*#\s*", " No. ", text)
    text = re.sub(r"\s+,", ",", text)
    text = re.sub(r",\s*,+", ", ", text)
    return clean_space(text).strip(" ,")


def has_non_ascii(value: str) -> bool:
    return any(ord(char) > 127 for char in value)


def build_api_url(page: int) -> str:
    query = urlencode(
        {
            "p": page,
            "s": PAGE_SIZE,
            "lat": REQUEST_LATITUDE,
            "lng": REQUEST_LONGITUDE,
            "d": REQUEST_DATE,
            "key": API_KEY,
        }
    )
    return f"{API_BASE_URL}?{query}"


def fetch_page(session: requests.Session, page: int) -> tuple[list[dict], str]:
    official_url = build_api_url(page)
    read_url = f"{READ_THROUGH_PREFIX}{official_url}"
    response = session.get(
        read_url,
        headers={"User-Agent": USER_AGENT, "X-Return-Format": "text"},
        timeout=HTTP_TIMEOUT_SECONDS,
    )
    response.raise_for_status()
    payload = response.json()
    if isinstance(payload, dict) and not payload:
        payload = []
    if not isinstance(payload, list):
        raise ValueError(f"Page {page} did not return a JSON list")
    checkpoint = TEMP_DIR / f"{ISSUER_ID}_locator_current_p{page}.json"
    checkpoint.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return payload, official_url


def country_from_source(state: str) -> tuple[str, str]:
    if state in PRIMARY_STATE_CODES:
        return PRIMARY_STATE_CODE_COUNTRY
    if state in COUNTRY_BY_STATE_VALUE:
        return COUNTRY_BY_STATE_VALUE[state]
    return DEFAULT_COUNTRY


def valid_postcode(value: str, iso3: str) -> str:
    value = clean_space(value)
    if value in {"", "0", "0000", "00000", "000000"}:
        return ""
    pattern = POSTCODE_PATTERNS.get(iso3)
    return value if pattern and re.fullmatch(pattern, value) else ""


def make_native_address(
    address1: str,
    address2: str,
    city: str,
    state: str,
    postcode: str,
    country: str,
) -> str:
    parts = [address1, address2, city, state, postcode, country]
    return ", ".join(clean_space(part) for part in parts if clean_space(part))


def reject_reason(item: dict, city: str, address1: str) -> str:
    if not address1:
        return "No recoverable street address in list or official detail endpoint"
    if not city or city.upper() in {"S/D", "N/A", "NA"}:
        return "No recoverable city"
    return ""


def build_row(item: dict, source_url: str, qa_log: list[dict]) -> tuple[dict, str]:
    address = item.get("address") or {}
    store_id = clean_space(item.get("storeNumber"))
    brand_raw = clean_space(item.get("brand")) or "FirstCash"
    address1_raw = clean_space(address.get("address1"))
    address2_raw = clean_space(address.get("address2"))
    city_raw = clean_space(address.get("city"))
    state_raw = clean_space(address.get("state"))
    postcode_raw = clean_space(address.get("zipCode"))

    correction = dict(STORE_CORRECTIONS.get(store_id, {}))
    if store_id in GUATEMALA_CITY_BY_STORE:
        correction = {
            "city": GUATEMALA_CITY_BY_STORE[store_id],
            "qa_flag": "CITY",
            "note": (
                "Source repeated the country in CITY; repaired from the "
                "official coordinates and checked against address context."
            ),
            **correction,
        }
    city_raw = correction.get("city", city_raw)
    state_raw = correction.get("state", state_raw)
    postcode_raw = correction.get("postcode", postcode_raw)

    country, iso3 = country_from_source(state_raw)
    # The API repeats the country name in STATE for these countries; STATE is
    # optional and must not contain a country label.
    output_state = correction.get(
        "output_state",
        "" if state_raw in COUNTRY_LABEL_STATE_VALUES else state_raw,
    )

    reason = reject_reason(item, city_raw, address1_raw)
    if reason:
        rejected = {
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": f"{ascii_text(brand_raw)} - Store {store_id}",
            "LOCATION_ADDRESS": clean_address_component(address1_raw),
            "LATITUDE": clean_space(item.get("latitude")),
            "LONGITUDE": clean_space(item.get("longitude")),
            "COUNTRY": country,
            "COUNTRY_ISO3": iso3,
            "POSTCODE": valid_postcode(postcode_raw, iso3),
            "STATE": ascii_text(output_state),
            "CITY": ascii_text(city_raw),
            "SOURCE_URL": source_url,
            "SOURCE_TYPE": SOURCE_TYPE,
            "ACTIVITY_AT_ASSET": STORE_ACTIVITY,
            "coord_source": (
                "website"
                if item.get("latitude") is not None and item.get("longitude") is not None
                else "Not from website"
            ),
            "QA_flag": "",
            "LOCATION_NAME_NATIVE": "",
            "LOCATION_ADDRESS_NATIVE": "",
        }
        return rejected, reason

    postcode = valid_postcode(postcode_raw, iso3)
    address_parts = [
        clean_address_component(address1_raw),
        clean_address_component(address2_raw),
        clean_address_component(city_raw),
        clean_address_component(output_state),
        postcode,
        country,
    ]
    location_address = ", ".join(part for part in address_parts if part)

    native_source = " ".join(
        [brand_raw, address1_raw, address2_raw, city_raw, state_raw]
    )
    native_address = ""
    native_name = ""
    if has_non_ascii(native_source):
        native_name = brand_raw if has_non_ascii(brand_raw) else ""
        native_address = make_native_address(
            address1_raw, address2_raw, city_raw, state_raw, postcode_raw, country
        )

    latitude = clean_space(item.get("latitude"))
    longitude = clean_space(item.get("longitude"))
    row = {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": f"{ascii_text(brand_raw)} - Store {store_id}",
        "LOCATION_ADDRESS": location_address,
        "LATITUDE": latitude,
        "LONGITUDE": longitude,
        "COUNTRY": country,
        "COUNTRY_ISO3": iso3,
        "POSTCODE": postcode,
        "STATE": ascii_text(output_state),
        "CITY": ascii_text(city_raw),
        "SOURCE_URL": source_url,
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": STORE_ACTIVITY,
        "coord_source": "website" if latitude and longitude else "Not from website",
        "QA_flag": correction.get("qa_flag", ""),
        "LOCATION_NAME_NATIVE": native_name,
        "LOCATION_ADDRESS_NATIVE": native_address,
    }
    if correction:
        qa_log.append(
            {
                "storeNumber": store_id,
                "tier": "A" if row["QA_flag"] == "fixed" else "B",
                "flag": row["QA_flag"],
                "detail": correction.get("note", "Configured source correction"),
            }
        )
    return row, ""


def validate_row(row: dict) -> list[str]:
    issues: list[str] = []
    mandatory = [
        "LOCATION_NAME",
        "LOCATION_ADDRESS",
        "COUNTRY",
        "COUNTRY_ISO3",
        "CITY",
        "SOURCE_URL",
        "SOURCE_TYPE",
        "ACTIVITY_AT_ASSET",
        "coord_source",
    ]
    for field in mandatory:
        if not clean_space(row.get(field)):
            issues.append(f"{field}_BLANK")
    if row.get("coord_source") not in {"website", "Not from website"}:
        issues.append("COORD_SOURCE_INVALID")
    city = clean_space(row.get("CITY"))
    if re.match(r"^\d", city) or re.search(
        r"(?i)\b(?:floor|suite|level|unit|po box|p\.o\. box|gpo box)\b|#", city
    ):
        issues.append("CITY_SUSPICIOUS")
    if len(city) < 2 or len(city) > 60:
        issues.append("CITY_SUSPICIOUS")
    if city.casefold() in {
        row.get("COUNTRY", "").casefold(),
        row.get("COUNTRY_ISO3", "").casefold(),
    }:
        issues.append("CITY_IS_COUNTRY")
    if "#" in row.get("LOCATION_ADDRESS", ""):
        issues.append("ADDRESS_HASH")
    if re.search(
        r"(?i)\b(compare|add to|shop now|click here|menu|search|helpdesk)\b",
        row.get("ACTIVITY_AT_ASSET", ""),
    ):
        issues.append("ACTIVITY_JUNK")
    return sorted(set(issues))


def dedupe(rows: list[dict]) -> list[dict]:
    seen: set[tuple[str, str]] = set()
    output: list[dict] = []
    for row in rows:
        # Outlet IDs are embedded in LOCATION_NAME and were already used as
        # the primary identity. Distinct IDs can legitimately be co-located
        # (for example, a pawn counter and an auto-pawn counter), so coordinates
        # alone must not collapse them.
        key = (
            row["LOCATION_NAME"].casefold(),
            row["LOCATION_ADDRESS"].casefold(),
        )
        if key not in seen:
            seen.add(key)
            output.append(row)
    return output


def write_csv(path: Path, rows: list[dict], columns: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def qa_sample(rows: list[dict]) -> tuple[list[dict], list[dict]]:
    required = max(1, (len(rows) + 9) // 10)
    # Deterministic spread across the full locator ordering, then force every
    # flagged row into the sample.
    indexes = {
        min(len(rows) - 1, (i * len(rows)) // required) for i in range(required)
    }
    flagged_indexes = {i for i, row in enumerate(rows) if row["QA_flag"]}
    indexes.update(flagged_indexes)
    while len(indexes) > required:
        removable = sorted(indexes - flagged_indexes, reverse=True)
        indexes.remove(removable[0])
    sample = [rows[i] for i in sorted(indexes)]
    findings = []
    for row in sample:
        issues = validate_row(row)
        if issues:
            findings.append(
                {
                    "LOCATION_NAME": row["LOCATION_NAME"],
                    "issues": issues,
                }
            )
    return sample, findings


def main() -> None:
    started = datetime.now(timezone.utc)
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    session = requests.Session()
    all_items: list[tuple[dict, str]] = []
    completed_pages: list[int] = []
    for page in range(1, MAX_PAGES + 1):
        items, official_url = fetch_page(session, page)
        if not items:
            break
        all_items.extend((item, official_url) for item in items)
        completed_pages.append(page)
        PROGRESS_JSON.write_text(
            json.dumps(
                {
                    "completed_pages": completed_pages,
                    "records_collected": len(all_items),
                    "updated_at": datetime.now(timezone.utc).isoformat(),
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        if len(items) < PAGE_SIZE:
            break

    # Outlet ID is the locator's primary identity.
    unique_items: dict[str, tuple[dict, str]] = {}
    for item, source_url in all_items:
        store_id = clean_space(item.get("storeNumber"))
        if store_id:
            unique_items[store_id] = (item, source_url)

    rows: list[dict] = []
    rejected: list[dict] = []
    qa_log: list[dict] = []
    for item, source_url in unique_items.values():
        row, reason = build_row(item, source_url, qa_log)
        if reason:
            rejected.append({**row, "REJECTION_REASON": reason})
        else:
            rows.append(row)

    for supplement in OFFICIAL_SUPPLEMENTS:
        rows.append(
            {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                **supplement,
            }
        )

    rows = dedupe(rows)
    validation_failures = []
    for row in rows:
        issues = validate_row(row)
        if issues:
            validation_failures.append(
                {"LOCATION_NAME": row["LOCATION_NAME"], "issues": issues}
            )
    if validation_failures:
        raise ValueError(
            "Validation failures remain: "
            + json.dumps(validation_failures[:20], ensure_ascii=False)
        )

    write_csv(OUTPUT_CSV, rows, OUTPUT_COLUMNS)
    if rejected:
        write_csv(
            REJECTED_CSV,
            rejected,
            OUTPUT_COLUMNS + ["REJECTION_REASON"],
        )
    elif REJECTED_CSV.exists():
        REJECTED_CSV.unlink()

    sample, sample_findings = qa_sample(rows)
    qa_payload = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "total_rows": len(rows),
        "rejected_rows": len(rejected),
        "rows_inspected": len(sample),
        "sample_percent": round((len(sample) / len(rows)) * 100, 2),
        "method": "standard 10%",
        "sample_findings": sample_findings,
        "tier_a_fixed": sum(row["QA_flag"] == "fixed" for row in rows),
        "tier_b_flagged": sum(
            bool(row["QA_flag"]) and row["QA_flag"] != "fixed" for row in rows
        ),
        "qa_log": qa_log,
        "sample_location_names": [row["LOCATION_NAME"] for row in sample],
        "started_at": started.isoformat(),
        "completed_at": datetime.now(timezone.utc).isoformat(),
    }
    QA_JSON.write_text(
        json.dumps(qa_payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(
        json.dumps(
            {
                "output_csv": str(OUTPUT_CSV),
                "rows": len(rows),
                "rejected": len(rejected),
                "qa_rows_inspected": len(sample),
                "qa_findings": len(sample_findings),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
