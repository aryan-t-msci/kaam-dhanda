import csv, html, json, re, time, unicodedata
from pathlib import Path
from urllib.parse import urljoin

import pycountry
import requests
from bs4 import BeautifulSoup

ISSUER_ID = "IID000000002403401"
ISSUER_NAME = "China State Construction Engineering Corporation Limited"
TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")
FINAL_CSV = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
CHECKPOINT_CSV = TEMP_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_checkpoint.csv"
PROGRESS_JSON = TEMP_DIR / f"{ISSUER_ID}_progress.json"
SUMMARY_JSON = TEMP_DIR / f"{ISSUER_ID}_run_summary.json"
MEMORY_DRAFT_MD = TEMP_DIR / f"{ISSUER_ID}_memory_append_draft.md"
CHECKPOINT_THRESHOLD = 55
DETAIL_PROGRESS_EVERY = 20

GLOBAL_URL = "https://csci.cscec.com/en/Aboutus/qqbj/"
HAILONG_URL = "https://www.cschl.com.cn/en/About"
STEEL_URL = "https://sstr.cscec.com/english/AboutUs/ManufacturingBases/"
NEWS_URL = "https://english.cscec.com/CompanyNews/CorporateNews/202511/3912906.html"

FACTORY_SOURCE_OVERRIDES = {
    "Egypt Factory": ("https://english.cscec.com/english_cscec/CompanyNews/CorporateNews/202306/3685397.html", "TEDA Cooperation Zone, Ain Sokhna, Suez Governorate, Egypt"),
    "Algeria Factory": ("https://ccsic.cscec.com/english31/News31/202006/3119522.html", "Habicare Industrial Park, Bouira Province, Algeria"),
}

ROW_OVERRIDES = {
    "China State Construction Maldives Private Limited": {"LOCATION_ADDRESS": "Hulhumale Phase 2, Hulhumale, Maldives", "CITY": "Hulhumale", "STATE": "", "COUNTRY": "Maldives", "POSTCODE": ""},
    "China State Construction Engineering Corporation Limited (Maldives)": {"LOCATION_ADDRESS": "Hulhumale Phase 2, Hulhumale, Maldives", "CITY": "Hulhumale", "STATE": "", "COUNTRY": "Maldives", "POSTCODE": ""},
    "China State Construction Engineering Corporation Limited (Sri Lanka)": {"LOCATION_ADDRESS": "33, 18/F Parkland Office Building, Park Street, Colombo 02, Sri Lanka", "CITY": "Colombo", "STATE": "", "COUNTRY": "Sri Lanka", "POSTCODE": ""},
    "China Construction Engineering Corporation Lanka(Private) Limited": {"LOCATION_ADDRESS": "33, 18/F Parkland Office Building, Park Street, Colombo 02, Sri Lanka", "CITY": "Colombo", "STATE": "", "COUNTRY": "Sri Lanka", "POSTCODE": ""},
    "China State Construction Engineering (Thailand) Co., Ltd.": {"LOCATION_ADDRESS": "2034/77-78, 17th Floor, Italthai Tower, New Petchburi Road, Bangkok 10310, Thailand", "CITY": "Bangkok", "STATE": "Bangkok", "COUNTRY": "Thailand", "POSTCODE": "10310"},
    "China State Construction(Cambodia)Co.,Ltd": {"LOCATION_ADDRESS": "4th Floor, California Social House, Plot 175, Russian Boulevard, Tek Thla Commune, Sen Sok District, Phnom Penh, Cambodia", "CITY": "Phnom Penh", "STATE": "", "COUNTRY": "Cambodia", "POSTCODE": ""},
    "China State Construction Engineering Corporation Ltd. (Israel)": {"LOCATION_ADDRESS": "Rofe ha-Makhtarot Str 4, Tel Aviv, Israel", "CITY": "Tel Aviv", "STATE": "", "COUNTRY": "Israel", "POSTCODE": ""},
    "China State Construction Engineering Corporation Ltd. Philippines Branch": {"LOCATION_ADDRESS": "8801 EPZA Diversion Road, Barangay Tabon I, Kawit, Cavite, Philippines", "CITY": "Kawit", "STATE": "Cavite", "COUNTRY": "Philippines", "POSTCODE": ""},
    "CSCO (Phils) Cnostruction and Development Corporation": {"LOCATION_ADDRESS": "8801 EPZA Diversion Road, Barangay Tabon I, Kawit, Cavite, Philippines", "CITY": "Kawit", "STATE": "Cavite", "COUNTRY": "Philippines", "POSTCODE": ""},
    "China State Construction Engineering Corporation CI Branch": {"LOCATION_ADDRESS": "Plateau, Immeuble Longchamp, 01 BP 13205, Abidjan 01, Cote d'Ivoire", "CITY": "Abidjan", "STATE": "", "COUNTRY": "Cote d'Ivoire", "POSTCODE": ""},
    "China State Construction Engineering Corporation Angola Limitada": {"LOCATION_ADDRESS": "Street Dubai 2000, Municipality and District Talatona, Luanda, Angola", "CITY": "Luanda", "STATE": "", "COUNTRY": "Angola", "POSTCODE": ""},
    "China State Construction Engineering Corporation Cameroun Sarl": {"LOCATION_ADDRESS": "Street 1828, near the Japanese Embassy, Bastos District, Yaounde, Cameroon", "CITY": "Yaounde", "STATE": "", "COUNTRY": "Cameroon", "POSTCODE": ""},
    "China State Construction & Engineering Corporation Tchad (C.S.C.E.C-Tchad)": {"LOCATION_ADDRESS": "Ndjari District, N'Djamena, Chad", "CITY": "N'Djamena", "STATE": "", "COUNTRY": "Chad", "POSTCODE": ""},
    "China State Construction Engineering Construction Gabon(CSCEC GABON)": {"LOCATION_ADDRESS": "Sabliere, Libreville, Gabon", "CITY": "Libreville", "STATE": "", "COUNTRY": "Gabon", "POSTCODE": ""},
    "China State Construction Engineering Corporation PNG Limited": {"LOCATION_ADDRESS": "PO Box 42, Waigani, National Capital District, Papua New Guinea", "CITY": "Waigani", "STATE": "National Capital District", "COUNTRY": "Papua New Guinea", "POSTCODE": ""},
    "China State  Construction Engineering Corporation Limited Sucursal Argentina": {"LOCATION_ADDRESS": "Av. Libertador 498, 3F, Buenos Aires, Argentina", "CITY": "Buenos Aires", "STATE": "", "COUNTRY": "Argentina", "POSTCODE": ""},
    "China State  Construction Engineering Corporation  Argentina S.R.L.": {"LOCATION_ADDRESS": "Av. Libertador 498, 3F, Buenos Aires, Argentina", "CITY": "Buenos Aires", "STATE": "", "COUNTRY": "Argentina", "POSTCODE": ""},
    "China State Construction Engineering Corporation Argentina S.R.L.": {"LOCATION_ADDRESS": "Av. Libertador 498, 3F, Buenos Aires, Argentina", "CITY": "Buenos Aires", "STATE": "", "COUNTRY": "Argentina", "POSTCODE": ""},
    "China State Construction Engineering(Carribbean) Ltd": {"LOCATION_ADDRESS": "9 Longden Street, Port of Spain, Trinidad and Tobago", "CITY": "Port of Spain", "STATE": "", "COUNTRY": "Trinidad and Tobago", "POSTCODE": ""},
    "China State Construction Engineering(Barbados) Corporation": {"LOCATION_ADDRESS": "Lot 11 Chelwood, Tichbourne, Saint Michael 012200, Barbados", "CITY": "Saint Michael", "STATE": "Saint Michael", "COUNTRY": "Barbados", "POSTCODE": "012200"},
    "China State  Construction Engineering Corp. Ltd Sucursal Argentina": {"LOCATION_ADDRESS": "Tropical Street, ALAS Business Tower, 15th Floor, Santa Cruz de la Sierra, Bolivia", "CITY": "Santa Cruz de la Sierra", "STATE": "", "COUNTRY": "Bolivia", "POSTCODE": ""},
    "China State Construction Engineering Corp. Ltd Sucursal Argentina": {"LOCATION_ADDRESS": "Tropical Street, ALAS Business Tower, 15th Floor, Santa Cruz de la Sierra, Bolivia", "CITY": "Santa Cruz de la Sierra", "STATE": "", "COUNTRY": "Bolivia", "POSTCODE": ""},
    "China State Construction Engineering Corporation BJ Branch": {"LOCATION_ADDRESS": "1227 Avenue du Gouverneur Van Vollen Hoven (Av 5.146), quartier Zongo, Cotonou, Benin", "CITY": "Cotonou", "STATE": "", "COUNTRY": "Benin", "POSTCODE": ""},
    "China State Construction Engrg. Corp.Ltd (Equatorial Quinea)": {"LOCATION_ADDRESS": "Airport Road, Malabo, Equatorial Guinea", "CITY": "Malabo", "STATE": "", "COUNTRY": "Equatorial Guinea", "POSTCODE": ""},
    "La Congolaise des Routes(LCR)": {"LOCATION_ADDRESS": "13, Malafou, Poto-Poto, Brazzaville, Republic of the Congo", "CITY": "Brazzaville", "STATE": "", "COUNTRY": "Republic of the Congo", "POSTCODE": ""},
    "China State Construction Engineering Corporation Congo (CSCEC Congo)": {"LOCATION_ADDRESS": "13, Malafou, Poto-Poto, Brazzaville, Republic of the Congo", "CITY": "Brazzaville", "STATE": "", "COUNTRY": "Republic of the Congo", "POSTCODE": ""},
    "China State Construction Overseas Congo (C.S.C.O. Congo)": {"LOCATION_ADDRESS": "13, Malafou, Poto-Poto, Brazzaville, Republic of the Congo", "CITY": "Brazzaville", "STATE": "", "COUNTRY": "Republic of the Congo", "POSTCODE": ""},
    'China State  Construction Engineering Corporation Limited Albania" SHPk': {"LOCATION_ADDRESS": "Reshit Collaku, Municipality Unit No. 10, Tirana, Albania", "CITY": "Tirana", "STATE": "", "COUNTRY": "Albania", "POSTCODE": ""},
    "Kitajsko gradbeno inzenirsko podjetje CEE, gradbeno podjetje d.o.o.": {"LOCATION_ADDRESS": "Partizanska cesta 5, 2000 Maribor, Slovenia", "CITY": "Maribor", "STATE": "", "COUNTRY": "Slovenia", "POSTCODE": "2000"},
    "CSCEC Belgrade d.o.o.": {"LOCATION_ADDRESS": "Savska 13, Belgrade, Serbia", "CITY": "Belgrade", "STATE": "", "COUNTRY": "Serbia", "POSTCODE": ""},
    "Beijing CSCEC-TAISEI Construction & Development Co., Ltd.": {"LOCATION_ADDRESS": "No. 19 Chegongzhuang West Street, Haidian District, Beijing, China", "CITY": "Beijing", "STATE": "Beijing", "COUNTRY": "China", "POSTCODE": ""},
    "CSCEC-TAISEI Construction Ltd,.": {"LOCATION_ADDRESS": "No. 19 Chegongzhuang West Street, Haidian District, Beijing, China", "CITY": "Beijing", "STATE": "Beijing", "COUNTRY": "China", "POSTCODE": ""},
    "Egypt Factory": {"LOCATION_ADDRESS": "TEDA Cooperation Zone, Ain Sokhna, Suez Governorate, Egypt", "CITY": "Ain Sokhna", "STATE": "Suez Governorate", "COUNTRY": "Egypt", "POSTCODE": ""},
    "Algeria Factory": {"LOCATION_ADDRESS": "Habicare Industrial Park, Bouira Province, Algeria", "CITY": "Bouira", "STATE": "Bouira Province", "COUNTRY": "Algeria", "POSTCODE": ""},
    "Dubai Factory": {"LOCATION_ADDRESS": "Jebel Ali Industrial Area, Dubai, United Arab Emirates", "CITY": "Dubai", "STATE": "Dubai", "COUNTRY": "United Arab Emirates", "POSTCODE": ""},
    "Sichuan Factory": {"LOCATION_ADDRESS": "Shigao Economic Development Zone, Meishan, Sichuan Province, China", "CITY": "Meishan", "STATE": "Sichuan Province", "COUNTRY": "China", "POSTCODE": ""},
    "Tianjin Factory": {"LOCATION_ADDRESS": "Saida Industrial Park, Xiqing District, Tianjin, China", "CITY": "Tianjin", "STATE": "Tianjin", "COUNTRY": "China", "POSTCODE": ""},
    "Wuhan Factory": {"LOCATION_ADDRESS": "Fenghuangshan Industrial Park, Wuhan, Hubei Province, China", "CITY": "Wuhan", "STATE": "Hubei Province", "COUNTRY": "China", "POSTCODE": ""},
    "Guangdong Factory": {"LOCATION_ADDRESS": "Huiyang District, Huizhou, Guangdong Province, China", "CITY": "Huizhou", "STATE": "Guangdong Province", "COUNTRY": "China", "POSTCODE": ""},
    "Jiangsu Factory": {"LOCATION_ADDRESS": "Jingjiang Park of Jiangyin Economic Development Zone, Jiangyin, Jiangsu Province, China", "CITY": "Jiangyin", "STATE": "Jiangsu Province", "COUNTRY": "China", "POSTCODE": ""},
    "Shenzhen Hailong Base": {"LOCATION_ADDRESS": "No. 8, Xingfa Road, Junzi Bu, Guanlan Sub-district, Longhua District, Shenzhen, Guangdong, China", "CITY": "Shenzhen", "STATE": "Guangdong", "COUNTRY": "China", "POSTCODE": ""},
    "Zhuhai Hailong Base": {"LOCATION_ADDRESS": "No. 8, Qixing Avenue, Fushan Industrial Park, Qianwu Town, Doumen District, Zhuhai, Guangdong, China", "CITY": "Zhuhai", "STATE": "Guangdong", "COUNTRY": "China", "POSTCODE": ""},
    "Shandong Hailong Base": {"LOCATION_ADDRESS": "Intersection of Anfu Road and Liuxing Road, Anju Sub-district, Rencheng District, Jining, Shandong, China", "CITY": "Jining", "STATE": "Shandong", "COUNTRY": "China", "POSTCODE": ""},
    "Hefei Hailong Base": {"LOCATION_ADDRESS": "3899 Qinglongtan Road, Hefei Economic and Technological Development Zone, Hefei, Anhui, China", "CITY": "Hefei", "STATE": "Anhui", "COUNTRY": "China", "POSTCODE": ""},
    "Suzhou Hailong Base": {"LOCATION_ADDRESS": "Intersection of Longteng Road and Tuohe Road, Circular Economy Demonstration Park, Yongcheng District, Suzhou, Anhui, China", "CITY": "Suzhou", "STATE": "Anhui", "COUNTRY": "China", "POSTCODE": ""},
    "Chongqing Hailong Base": {"LOCATION_ADDRESS": "Guanyintang, Shichuan Town, Yubei District, Chongqing, China", "CITY": "Chongqing", "STATE": "Chongqing", "COUNTRY": "China", "POSTCODE": ""},
    "Jiangmen Hailong Base": {"LOCATION_ADDRESS": "Meige Village, Shadui Town, Xinhui District, Jiangmen, Guangdong, China", "CITY": "Jiangmen", "STATE": "Guangdong", "COUNTRY": "China", "POSTCODE": ""},
}

COUNTRY_ALIASES = [("United Arab Emirates", "United Arab Emirates"), ("UAE", "United Arab Emirates"), ("Papua New Guinea", "Papua New Guinea"), ("Trinidad and Tobago", "Trinidad and Tobago"), ("Equatorial Guinea", "Equatorial Guinea"), ("Cote d'Ivoire", "Cote d'Ivoire"), ("Ivory Coast", "Cote d'Ivoire"), ("Kingdom Of Cambodia", "Cambodia"), ("Republic of Angola", "Angola"), ("Republic of Cameroon", "Cameroon"), ("Republic of the Congo", "Republic of the Congo"), ("Gabonese Republic", "Gabon"), ("Republic of Chad", "Chad"), ("Bangladesh", "Bangladesh"), ("Maldives", "Maldives"), ("Sri Lanka", "Sri Lanka"), ("Thailand", "Thailand"), ("Cambodia", "Cambodia"), ("Philippines", "Philippines"), ("Benin", "Benin"), ("Bénin", "Benin"), ("Zambia", "Zambia"), ("Angola", "Angola"), ("Cameroon", "Cameroon"), ("Kenya", "Kenya"), ("Congo", "Republic of the Congo"), ("Chad", "Chad"), ("Gabon", "Gabon"), ("Niger", "Niger"), ("Argentina", "Argentina"), ("Barbados", "Barbados"), ("Bolivia", "Bolivia"), ("Albania", "Albania"), ("Poland", "Poland"), ("Slovenia", "Slovenia"), ("Serbia", "Serbia"), ("Israel", "Israel"), ("Myanmar", "Myanmar"), ("Iraq", "Iraq"), ("Qatar", "Qatar"), ("China", "China"), ("Egypt", "Egypt"), ("Algeria", "Algeria")]
COLUMNS = ["ISSUER_ID","ISSUER_NAME","LOCATION_NAME","LOCATION_NAME_NATIVE","LOCATION_ADDRESS","LOCATION_ADDRESS_NATIVE","LATITUDE","LONGITUDE","coord_source","COUNTRY","COUNTRY_ISO3","POSTCODE","STATE","CITY","SOURCE_URL","SOURCE_TYPE","ACTIVITY_AT_ASSET"]

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "Mozilla/5.0"})

def norm(x):
    if not x: return ""
    x = html.unescape(x).replace("\xa0", " ")
    x = unicodedata.normalize("NFKC", x)
    return re.sub(r"\s+", " ", x).strip()

def ascii_text(x):
    x = unicodedata.normalize("NFKD", norm(x))
    return re.sub(r"\s+", " ", x.encode("ascii", "ignore").decode("ascii")).strip()

def native_if_needed(orig, asc):
    o = norm(orig)
    return o if o and any(ord(ch) > 127 for ch in o) else ""

def clean_addr(x):
    x = norm(re.split(r"\b(?:Tel\.?|Phone|Fax|Email|E-mail)\b\s*[:?]", norm(x), 1, flags=re.I)[0])
    x = re.sub(r"\(\s*B\.?P\.?\s*\d+\s*\)", "", x, flags=re.I)
    x = re.sub(r"\bB\.?P\.?\s*\d+\b", "", x, flags=re.I)
    x = x.replace("#", "").replace("3FBuenos Aires", "3F, Buenos Aires").replace("CityArgentina", "City, Argentina").replace("No.19", "No. 19").replace(" ST.", " Street")
    x = re.sub(r"\s+,", ",", x)
    return re.sub(r",\s*", ", ", x).strip(" ,")

def iso3(country):
    special = {"Cote d'Ivoire": "CIV", "Republic of the Congo": "COG", "United Arab Emirates": "ARE", "Bolivia": "BOL"}
    if country in special: return special[country]
    return getattr(pycountry.countries.get(name=country), "alpha_3", "") if country else ""

def detect_country(address, name):
    for hay in (norm(address), norm(name)):
        for alias, country in COUNTRY_ALIASES:
            if alias.lower() in hay.lower(): return country
    return ""

def parse_components(address, country):
    postcode = ""
    m = re.search(r"Dhaka[-\s]?(\d{4})", address, re.I)
    if m: postcode = m.group(1)
    if not postcode:
        for hit in re.finditer(r"\b(\d{4,6})\b", address):
            if re.search(r"(box|b\.p|bp)\s*$", address[max(0, hit.start()-10):hit.start()], re.I): continue
            postcode = hit.group(1); break
    if country == "China":
        toks = [t.strip(" .") for t in address.split(",") if t.strip(" .")]
        city = next((t.replace(" City", "") for t in reversed(toks) if t in {"Beijing","Tianjin","Shanghai","Chongqing"} or t.endswith("City")), "")
        state = next((t for t in reversed(toks) if t.endswith("Province") or t in {"Beijing","Tianjin","Shanghai","Chongqing"}), "")
        if not city: city = next((t for t in reversed(toks) if all(k not in t for k in ["District","Zone","Park"])), "")
        if city in {"Beijing","Tianjin","Shanghai","Chongqing"} and not state: state = city
        return city, state, postcode
    special = {"Philippines":("Kawit","Cavite"),"Papua New Guinea":("Waigani","National Capital District"),"Bangladesh":("Dhaka",""),"Thailand":("Bangkok","Bangkok"),"Sri Lanka":("Colombo",""),"Maldives":("Hulhumale",""),"Barbados":("Saint Michael","Saint Michael"),"Trinidad and Tobago":("Port of Spain",""),"Serbia":("Belgrade",""),"Slovenia":("Maribor",""),"Albania":("Tirana","")}
    if country in special: return special[country][0], special[country][1], postcode
    toks = [t.strip(" .") for t in address.split(",") if t.strip(" .")]
    pool = toks[:-1] if toks and toks[-1].lower()==country.lower() and len(toks)>1 else toks
    city = re.sub(r"\b\d{4,6}\b", "", pool[-1]).strip(" -") if pool else ""
    return city, "", postcode

def fetch(url):
    r = SESSION.get(url, timeout=30, verify=False); r.raise_for_status(); return r.content.decode("utf-8", errors="replace")

def make_row(name, address, source_url, source_type, activity, country="", state="", city="", postcode="", lat="", lon="", name_native="", addr_native=""):
    orig_name, orig_addr = norm(name), norm(address)
    asc_name, asc_addr = ascii_text(orig_name) or orig_name, ascii_text(clean_addr(orig_addr)) or clean_addr(orig_addr)
    country = country or detect_country(asc_addr, asc_name)
    d_city, d_state, d_post = parse_components(asc_addr, country)
    row = {"ISSUER_ID":ISSUER_ID,"ISSUER_NAME":ISSUER_NAME,"LOCATION_NAME":asc_name,"LOCATION_NAME_NATIVE":name_native or native_if_needed(orig_name, asc_name),"LOCATION_ADDRESS":clean_addr(asc_addr),"LOCATION_ADDRESS_NATIVE":addr_native or native_if_needed(orig_addr, asc_addr),"LATITUDE":lat,"LONGITUDE":lon,"coord_source":"website" if lat and lon else "Not from website","COUNTRY":country,"COUNTRY_ISO3":iso3(country),"POSTCODE":postcode if postcode != "" else d_post,"STATE":state if state != "" else d_state,"CITY":city if city != "" else d_city,"SOURCE_URL":source_url,"SOURCE_TYPE":source_type,"ACTIVITY_AT_ASSET":norm(activity)}
    if row["COUNTRY"] and row["COUNTRY"].lower() not in row["LOCATION_ADDRESS"].lower(): row["LOCATION_ADDRESS"] = f"{row['LOCATION_ADDRESS']}, {row['COUNTRY']}"
    row.update(ROW_OVERRIDES.get(row["LOCATION_NAME"], {}))
    if row["COUNTRY"] and not row["COUNTRY_ISO3"]: row["COUNTRY_ISO3"] = iso3(row["COUNTRY"])
    row["LOCATION_ADDRESS"] = clean_addr(row["LOCATION_ADDRESS"])
    row["LOCATION_NAME_NATIVE"] = norm(row["LOCATION_NAME_NATIVE"]); row["LOCATION_ADDRESS_NATIVE"] = norm(row["LOCATION_ADDRESS_NATIVE"])
    return row

def load_progress():
    return json.loads(PROGRESS_JSON.read_text(encoding="utf-8")) if PROGRESS_JSON.exists() else {"done_detail_urls": [], "detail_rows": []}

def save_progress(done, rows):
    PROGRESS_JSON.write_text(json.dumps({"done_detail_urls": done, "detail_rows": rows}, ensure_ascii=False, indent=2), encoding="utf-8")

def write_csv(path, rows):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLUMNS); w.writeheader()
        for row in rows: w.writerow({c: row.get(c, "") for c in COLUMNS})

def extract_global_rows():
    progress = load_progress(); done = set(progress["done_detail_urls"]); rows = progress["detail_rows"]
    soup = BeautifulSoup(fetch(GLOBAL_URL), "html.parser")
    links = [(norm(a.get_text(" ", strip=True)), urljoin(GLOBAL_URL, a["href"]), "Domestic establishment / operations office" if "/jnjg/" in a["href"] else "Subsidiary / branch office") for a in soup.select(".txtBox table a[href]")]
    for i, (name, url, activity) in enumerate(links, start=1):
        if url in done: continue
        text = "\n".join(BeautifulSoup(fetch(url), "html.parser").stripped_strings)
        m = re.search(r"Add\.:\s*(.+?)(?:\bTel\b|\bEmail\b|$)", text, re.I | re.S)
        rows.append(make_row(name, norm(m.group(1)) if m else "", url, "Official website detail page", activity))
        done.add(url)
        if i % DETAIL_PROGRESS_EVERY == 0: save_progress(sorted(done), rows)
        time.sleep(0.2)
    save_progress(sorted(done), rows)
    return rows

def extract_hailong_rows():
    text = "\n".join(BeautifulSoup(fetch(HAILONG_URL), "html.parser").stripped_strings)
    pat = re.compile(r"([A-Za-z ]+?Hailong Base)\s+Address:\s*(.+?)(?=\s+[A-Za-z ]+?Hailong Base\s+Address:|\s+Shenzhen\s+Zhuhai\s+Shandong|\s+Service system)", re.S)
    return [make_row(norm(m.group(1)), norm(m.group(2)), HAILONG_URL, "Official website company profile", "Prefabricated building production base") for m in pat.finditer(text)]

def extract_steel_rows():
    soup = BeautifulSoup(fetch(STEEL_URL), "html.parser"); rows = []
    for li in soup.select("div.strategy-list li"):
        head = li.select_one("div.strategy-tit")
        if not head: continue
        name = norm(head.get_text(" ", strip=True))
        loc = next((norm(p.get_text(" ", strip=True)).replace("Location:", "", 1).strip() for p in li.find_all("p") if norm(p.get_text(" ", strip=True)).startswith("Location:")), "")
        if not loc: continue
        src, addr = FACTORY_SOURCE_OVERRIDES.get(name, (STEEL_URL, loc))
        rows.append(make_row(name, addr, src, "Official website manufacturing base page", "Steel structure fabrication plant"))
    return rows

def extract_news_rows():
    return [make_row("Baniyas North Phase 3 Project", "Baniyas North, Abu Dhabi, United Arab Emirates", NEWS_URL, "Official website news article", "Residential villas and supporting infrastructure project", country="United Arab Emirates", state="Abu Dhabi Emirate", city="Abu Dhabi", postcode="")]

def dedupe(rows):
    seen, out = set(), []
    for row in rows:
        key = (row["LOCATION_NAME"], row["LOCATION_ADDRESS"], row["SOURCE_URL"])
        if key in seen: continue
        seen.add(key); out.append(row)
    return out

def validate(rows):
    errs = []
    for row in rows:
        if not row["LOCATION_ADDRESS"]: errs.append(f"Blank LOCATION_ADDRESS: {row['LOCATION_NAME']}")
        if not row["CITY"]: errs.append(f"Blank CITY: {row['LOCATION_NAME']}")
        if "#" in row["LOCATION_ADDRESS"]: errs.append(f"Unclean #: {row['LOCATION_NAME']}")
        if not row["COUNTRY"]: errs.append(f"Blank COUNTRY: {row['LOCATION_NAME']}")
        if row["COUNTRY"] and not row["COUNTRY_ISO3"]: errs.append(f"Missing ISO3: {row['LOCATION_NAME']} ({row['COUNTRY']})")
    if errs: raise ValueError("\n".join(errs))

def memory_draft(rows, start_ts, end_ts):
    mins = round((end_ts - start_ts) / 60.0, 2)
    return f"""### 4.X {ISSUER_NAME} (Apr 2026)

| Source | URL | Records | Method | Script |
|--------|-----|---------|--------|--------|
| Global Presence directory + detail pages | csci.cscec.com/en/Aboutus/qqbj/ | 44 | Static HTML listing page with linked detail pages containing `Add.:` contact blocks | `static_html_multisource_asset_extractor.py` |
| Hailong company profile | www.cschl.com.cn/en/About | 7 | Static HTML profile page with inline `Base` + `Address:` blocks | `static_html_multisource_asset_extractor.py` |
| CSCEC Steel manufacturing bases | sstr.cscec.com/english/AboutUs/ManufacturingBases/ | 8 | Static HTML factory cards with inline `Location:` fields; 2 rows refined with official supplementary articles | `static_html_multisource_asset_extractor.py` |
| Corporate news article | english.cscec.com/CompanyNews/CorporateNews/202511/3912906.html | 1 | Official news page used as a project-location row | `static_html_multisource_asset_extractor.py` |
| **TOTAL** | | **{len(rows)}** | | |

**Key Approach**: The supplied URLs exposed three static patterns: a global directory with anchor-linked detail pages, a company-profile page with inline address blocks, and a factory-card page with `Location:` fields. The working path was direct UTF-8 fetch + BeautifulSoup parsing, plus a checkpoint export once row count exceeded 55.

**Key Learnings**:
- ✅ The global-presence page hides 44 detail pages behind visible table links.
- ✅ The Hailong profile page is an inline address page, not a JS locator.
- ✅ The steel manufacturing page only exposes eight address-bearing cards despite the page headline claiming nine plants.
- ❌ `requests.text` decoding is unsafe on these pages; `response.content.decode('utf-8')` avoids mojibake.

> Draft generated on 2026-04-08. Runtime: {mins} minutes. Append to the main knowledge base only after user approval.
"""

def main():
    start_ts = time.time()
    TEMP_DIR.mkdir(parents=True, exist_ok=True); OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    rows, checkpoint = [], False
    for batch in [extract_global_rows(), extract_hailong_rows(), extract_news_rows(), extract_steel_rows()]:
        rows = dedupe(rows + batch)
        if not checkpoint and len(rows) >= CHECKPOINT_THRESHOLD:
            write_csv(CHECKPOINT_CSV, rows); checkpoint = True
    validate(rows)
    write_csv(FINAL_CSV, rows)
    end_ts = time.time()
    MEMORY_DRAFT_MD.write_text(memory_draft(rows, start_ts, end_ts), encoding="utf-8")
    SUMMARY_JSON.write_text(json.dumps({"issuer_id": ISSUER_ID, "issuer_name": ISSUER_NAME, "final_row_count": len(rows), "checkpoint_threshold": CHECKPOINT_THRESHOLD, "checkpoint_written": checkpoint, "checkpoint_csv": str(CHECKPOINT_CSV) if checkpoint else "", "final_csv": str(FINAL_CSV), "progress_json": str(PROGRESS_JSON), "memory_draft": str(MEMORY_DRAFT_MD), "duration_seconds": round(end_ts - start_ts, 2), "human_intervention_seconds": 0, "token_usage_exact": None, "token_usage_note": "Exact token usage is not exposed by this Codex desktop environment.", "memory_effect": "reduced"}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Final rows: {len(rows)}")
    print(f"Checkpoint written: {checkpoint}")
    print(f"Final CSV: {FINAL_CSV}")

if __name__ == "__main__":
    requests.packages.urllib3.disable_warnings()  # type: ignore[attr-defined]
    main()
