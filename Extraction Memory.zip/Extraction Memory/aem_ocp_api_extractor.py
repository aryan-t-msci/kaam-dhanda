"""
STC Business Offices Extraction — AEM /bin/ocp Servlet Pattern
==============================================================
Issuer: SAUDI TELECOM COMPANY SJSC (IID000000002153141)
Source: https://www.stc.com.sa/en/personal/support/contact-us/business-offices-coverage-maps.html#listview
API:    https://www.stc.com.sa/bin/ocp?apiName=getContentByCategory&category=offices

Strategy (from extraction memory Section 4.10):
  1. Fetch API with Accept-Language: en  → English fields
  2. Fetch API with Accept-Language: ar  → Native Arabic fields
  3. Merge by unique 'key' field
  4. Compose address from name + city + area
  5. Export to CSV with native parallel columns
"""

import json
import csv
import urllib.request
import urllib.error
import ssl
import re
import os
import sys
import time

sys.stdout.reconfigure(encoding='utf-8')

# Bypass SSL certificate verification (corporate TLS chain issue — known pattern)
SSL_CTX = ssl.create_default_context()
SSL_CTX.check_hostname = False
SSL_CTX.verify_mode = ssl.CERT_NONE

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
ISSUER_NAME   = "SAUDI TELECOM COMPANY SJSC"
ISSUER_ID     = "IID000000002153141"
SOURCE_URL    = "https://www.stc.com.sa/en/personal/support/contact-us/business-offices-coverage-maps.html#listview"
API_ENDPOINT  = "https://www.stc.com.sa/bin/ocp?apiName=getContentByCategory&category=offices"

COUNTRY       = "Saudi Arabia"
COUNTRY_ISO3  = "SAU"
SOURCE_TYPE   = "COMPANY WEBSITE"

TEMP_DIR      = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp"
OUTPUT_DIR    = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output"
OUTPUT_FILE   = f"{ISSUER_ID}_{ISSUER_NAME}.csv"
# ═══════════════════════════════════════════════════════════

HEADERS_BASE = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "x-requested-with": "XMLHttpRequest",
    "accept": "application/json, text/javascript, */*; q=0.01",
    "referer": SOURCE_URL,
    "sec-ch-ua-platform": '"Windows"',
    "sec-ch-ua": '"Chromium";v="124", "Not-A.Brand";v="24"',
    "sec-ch-ua-mobile": "?0",
    "connection": "keep-alive",
}


def fetch_data(lang="en", retries=3):
    """Fetch the AEM /bin/ocp API data with a specific Accept-Language header."""
    headers = dict(HEADERS_BASE)
    headers["accept-language"] = lang
    print(f"[INFO] Fetching API with language: {lang} ...")
    req = urllib.request.Request(API_ENDPOINT, headers=headers)
    for attempt in range(1, retries + 1):
        try:
            with urllib.request.urlopen(req, timeout=30, context=SSL_CTX) as response:
                raw = response.read().decode('utf-8')
                data = json.loads(raw)
                print(f"[INFO] [{lang}] Response keys: {list(data.keys()) if isinstance(data, dict) else type(data).__name__}")
                return data
        except Exception as e:
            print(f"[WARN] Attempt {attempt}/{retries} failed for lang={lang}: {e}")
            time.sleep(2)
    return None


def clean_text(text):
    """Normalize whitespace and strip leading/trailing spaces."""
    if not text:
        return ""
    return re.sub(r'\s+', ' ', str(text)).strip()


def clean_address(address):
    """Make address geocoding-friendly: remove '#', normalize whitespace."""
    if not address:
        return ""
    addr = str(address).replace("#", "").replace("،", ",")
    addr = re.sub(r'\s+', ' ', addr).strip()
    return addr


def build_address(name, city, area, district=""):
    """Compose a geocoding-friendly English address from parts."""
    parts = []
    if name:
        parts.append(name)
    if city and city.lower() not in (name or "").lower():
        parts.append(city)
    if area and area.lower() not in (city or "").lower() and area.lower() not in (name or "").lower():
        parts.append(area)
    if district and district.lower() not in " ".join(parts).lower():
        parts.append(district)
    return clean_address(", ".join(p for p in parts if p))


def build_ar_address(name, city, area):
    """Compose Arabic address from parts."""
    parts = []
    if name:
        parts.append(name)
    if city and city not in (name or ""):
        parts.append(city)
    if area and area not in (city or ""):
        parts.append(area)
    return clean_address("، ".join(p for p in parts if p))


# Mapping from region name to primary city (for fallback when city field is blank)
REGION_TO_CITY = {
    "Riyadh Region": "Riyadh",
    "Makkah Region": "Makkah",
    "Eastern Province": "Dammam",
    "Asir Region": "Abha",
    "Madinah Region": "Madinah",
    "Qassim Region": "Buraidah",
    "Najran Region": "Najran",
    "Jizan Region": "Jizan",
    "Tabuk Region": "Tabuk",
    "Hail Region": "Hail",
    "Jawf Region": "Sakaka",
    "Northern Borders": "Arar",
    "Bahah Region": "Al Bahah",
}


def map_activity(raw_type):
    """Map raw type field to standardized activity description."""
    if not raw_type:
        return "Business Office"
    t = raw_type.strip().upper()
    if t == "OFFICE":
        return "Business Office"
    if t == "KIOSK":
        return "Kiosk / Self-Service Point"
    if t == "MAINTENANCE_CENTER":
        return "Maintenance Center"
    if "BRANCH" in t:
        return "Branch Office"
    if "SERVICE" in t:
        return "Service Center"
    if "RETAIL" in t or "STORE" in t or "SHOP" in t:
        return "Retail Store"
    return raw_type.strip().title()


def save_debug(data, filename):
    """Save raw API response to temp dir for debugging."""
    path = os.path.join(TEMP_DIR, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"[DEBUG] Saved raw response to {path}")


def run_extraction():
    start_time = time.time()
    os.makedirs(TEMP_DIR, exist_ok=True)
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # 1. Fetch English and Arabic data
    data_en = fetch_data("en")
    data_ar = fetch_data("ar")

    if data_en:
        save_debug(data_en, "stc_raw_en.json")
    if data_ar:
        save_debug(data_ar, "stc_raw_ar.json")

    if not data_en:
        print("[ERROR] Failed to fetch English data. Exiting.")
        return

    # 2. Parse content — handle various API response shapes
    def extract_content(data):
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            for key in ("content", "data", "items", "offices", "results", "response"):
                if key in data and isinstance(data[key], list):
                    return data[key]
            # Check nested structures
            for v in data.values():
                if isinstance(v, list) and len(v) > 0:
                    return v
        return []

    records_en = extract_content(data_en)
    records_ar = extract_content(data_ar) if data_ar else []

    print(f"[INFO] English records: {len(records_en)}")
    print(f"[INFO] Arabic records:  {len(records_ar)}")

    if len(records_en) == 0:
        print("[WARN] No records extracted. Printing raw structure for inspection:")
        print(json.dumps(data_en, ensure_ascii=False, indent=2)[:3000])
        return

    # 3. Build Arabic lookup by key
    ar_map = {}
    for r in records_ar:
        if isinstance(r, dict):
            k = r.get("key") or r.get("id") or r.get("officeId") or r.get("nodeId")
            msg = r.get("message", r)  # Some APIs nest under 'message', some don't
            if k:
                ar_map[k] = msg

    # 4. Process each English record
    final_rows = []
    skipped = 0

    for en_item in records_en:
        if not isinstance(en_item, dict):
            continue

        # Support both nested 'message' structure and flat structure
        key = en_item.get("key") or en_item.get("id") or en_item.get("officeId")
        en_msg = en_item.get("message", en_item)

        # Extract English fields
        loc_name    = clean_text(en_msg.get("name", "") or en_msg.get("officeName", "") or en_msg.get("title", ""))
        loc_city    = clean_text(en_msg.get("city", "") or en_msg.get("cityName", ""))
        loc_area    = clean_text(en_msg.get("area", "") or en_msg.get("region", "") or en_msg.get("district", ""))
        loc_district= clean_text(en_msg.get("district", "") or en_msg.get("zone", ""))
        loc_address = clean_text(en_msg.get("address", "") or en_msg.get("streetAddress", ""))
        raw_lat     = en_msg.get("lat", "") or en_msg.get("latitude", "") or en_msg.get("Lat", "")
        raw_lng     = en_msg.get("long", "") or en_msg.get("longitude", "") or en_msg.get("lng", "") or en_msg.get("Lng", "")
        raw_type    = en_msg.get("type", "") or en_msg.get("officeType", "") or en_msg.get("category", "")
        phone       = clean_text(en_msg.get("phone", "") or en_msg.get("telephone", ""))
        postcode    = clean_text(en_msg.get("postCode", "") or en_msg.get("postalCode", "") or en_msg.get("zipCode", ""))

        # Validate lat/lng
        lat_val = str(raw_lat).strip() if raw_lat and str(raw_lat).strip() not in ("", "0", "0.0", "null") else ""
        lng_val = str(raw_lng).strip() if raw_lng and str(raw_lng).strip() not in ("", "0", "0.0", "null") else ""
        coord_source = "website" if (lat_val and lng_val) else ""

        # Arabic parallel fields
        ar_msg = {}
        if key and key in ar_map:
            ar_msg = ar_map[key]
        elif isinstance(ar_map, dict) and len(ar_map) > 0:
            # Try positional match if keys don't align
            pass

        ar_name    = clean_text(ar_msg.get("name", "") or ar_msg.get("officeName", "")) if ar_msg else ""
        ar_city    = clean_text(ar_msg.get("city", "") or ar_msg.get("cityName", "")) if ar_msg else ""
        ar_area    = clean_text(ar_msg.get("area", "") or ar_msg.get("region", "")) if ar_msg else ""

        # City fallback needs to happen BEFORE address building
        # (so we can include it in the address if derived)
        derived_city = loc_city
        if not derived_city:
            derived_city = REGION_TO_CITY.get(loc_area, loc_area or "")

        # Build addresses
        # STC API: 'name' is the office name/location name (street-level descriptor)
        # city = city, area = region. Build: "name, city, region"
        if loc_address:
            full_en_addr = clean_address(loc_address)
            if derived_city and derived_city not in full_en_addr:
                full_en_addr = full_en_addr + ", " + derived_city
            if loc_area and loc_area not in full_en_addr:
                full_en_addr = full_en_addr + ", " + loc_area
        else:
            addr_parts = []
            if loc_name:
                addr_parts.append(loc_name)
            if derived_city and (not addr_parts or derived_city.lower() not in " ".join(addr_parts).lower()):
                addr_parts.append(derived_city)
            if loc_area and loc_area not in " ".join(addr_parts):
                addr_parts.append(loc_area)
            full_en_addr = clean_address(", ".join(p for p in addr_parts if p))

        ar_full_addr = build_ar_address(ar_name, ar_city, ar_area)

        # City value from derivation done above
        city_val = derived_city or loc_area or ""
        # State: use area/region
        state_val = loc_area or loc_district or ""

        # Skip records with no address and no city
        if not full_en_addr and not city_val:
            skipped += 1
            continue

        # Ensure LOCATION_ADDRESS and CITY are not blank
        if not full_en_addr:
            if city_val:
                full_en_addr = city_val + ", " + COUNTRY
            else:
                full_en_addr = loc_name + ", " + COUNTRY if loc_name else COUNTRY

        if not city_val:
            # Derive city from address if possible
            city_val = loc_area or state_val or ""

        activity = map_activity(raw_type)

        row = {
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": loc_name,
            "LOCATION_ADDRESS": full_en_addr,
            "LATITUDE": lat_val,
            "LONGITUDE": lng_val,
            "COUNTRY": COUNTRY,
            "COUNTRY_ISO3": COUNTRY_ISO3,
            "POSTCODE": postcode,
            "STATE": state_val,
            "CITY": city_val,
            "SOURCE_URL": SOURCE_URL,
            "SOURCE_TYPE": SOURCE_TYPE,
            "ACTIVITY_AT_ASSET": activity,
            "coord_source": coord_source,
            "LOCATION_NAME_LOCAL": ar_name,
            "LOCATION_ADDRESS_LOCAL": ar_full_addr,
        }
        final_rows.append(row)

    print(f"\n[RESULT] Total records extracted: {len(final_rows)}")
    print(f"[RESULT] Records skipped (no address/city): {skipped}")

    if len(final_rows) < 260:
        print(f"[WARN] Count {len(final_rows)} is below the expected ~260. Inspect stc_raw_en.json for full structure.")

    # 5. Save to output CSV
    fieldnames = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS",
        "LATITUDE", "LONGITUDE", "COUNTRY", "COUNTRY_ISO3", "POSTCODE",
        "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE", "ACTIVITY_AT_ASSET",
        "coord_source", "LOCATION_NAME_LOCAL", "LOCATION_ADDRESS_LOCAL"
    ]

    out_path = os.path.join(OUTPUT_DIR, OUTPUT_FILE)
    with open(out_path, mode="w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(final_rows)

    elapsed = time.time() - start_time
    print(f"\n[DONE] Written {len(final_rows)} rows to: {out_path}")
    print(f"[TIME] Elapsed: {elapsed:.1f}s")

    # Quick preview of first 3 rows
    print("\n[PREVIEW] First 3 rows:")
    for row in final_rows[:3]:
        print(f"  NAME={row['LOCATION_NAME']!r}, CITY={row['CITY']!r}, ADDR={row['LOCATION_ADDRESS']!r}, LAT={row['LATITUDE']!r}")


if __name__ == "__main__":
    run_extraction()
