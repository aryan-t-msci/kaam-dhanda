"""
WP Google Maps REST extractor.

This script handles WordPress sites using the WP Google Maps plugin where the
public REST route `/wp-json/wpgmza/v1/markers` exposes marker records with
title, address, category, and website coordinates. Configure the issuer block
and map IDs, then run with Python to export a validated batch CSV.

Usage:
    python wp_google_maps_rest_extractor.py
"""

from __future__ import annotations

import csv
import html
import json
import re
import statistics
from datetime import datetime
from pathlib import Path
from typing import Any

import pycountry
import requests
from bs4 import BeautifulSoup
from unidecode import unidecode


# =============================================================================
# CONFIGURATION - Edit this block for each new issuer
# =============================================================================
ISSUER_ID = "IID000000002145518"
ISSUER_NAME = "THE TIMKEN COMPANY"
BASE_URL = "https://locations.timken.com"
MARKERS_API = f"{BASE_URL}/wp-json/wpgmza/v1/markers"
MAPS = {
    "1": {
        "page_url": "https://locations.timken.com/sales-locator",
        "label": "Timken sales office",
        "source_url": f"{MARKERS_API}?filter%5Bmap_id%5D=1",
    },
    "2": {
        "page_url": "https://locations.timken.com/distributor-locator",
        "label": "Authorized Timken distributor",
        "source_url": f"{MARKERS_API}?filter%5Bmap_id%5D=2",
    },
}
CATEGORY_LABELS = {
    "4": "Automotive",
    "5": "Industrial",
    "6": "Aircraft landing wheel specialist",
}
OUTPUT_BASENAME = "IID000000002145518_THE TIMKEN COMPANY.csv"
ISSUER_TEMP = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive"
    r"\Temp\Extraction_Batch_20260504_165656"
    r"\IID000000002145518_THE TIMKEN COMPANY"
)
STAGING_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive"
    r"\Temp\Extraction_Batch_20260504_165656\staging"
)
TARGET_COUNT = 198
TIMKEN_INDIA_PAGE_URL = "https://www.timken.com/en-in/about/timken-in-india"

SUPPLEMENTAL_OFFICIAL_ROWS = [
    {
        "LOCATION_NAME": "Timken India Limited - Jamshedpur Plant",
        "LOCATION_ADDRESS": "Bara, P.O. Agrico, Jamshedpur 831009, Jharkhand, India",
        "COUNTRY": "India",
        "COUNTRY_ISO3": "IND",
        "POSTCODE": "831009",
        "STATE": "Jharkhand",
        "CITY": "Jamshedpur",
        "SOURCE_URL": TIMKEN_INDIA_PAGE_URL,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Manufacturing plant",
        "LATITUDE": "",
        "LONGITUDE": "",
        "coord_source": "Not from website",
        "QA_flag": "",
        "LOCATION_NAME_NATIVE": "",
        "LOCATION_ADDRESS_NATIVE": "",
    },
    {
        "LOCATION_NAME": "Timken India Limited - Bharuch Plant",
        "LOCATION_ADDRESS": "Plot No. 109A, 109B, 1B and 1C, PO Narmada Nagar, Bharuch 392015, Gujarat, India",
        "COUNTRY": "India",
        "COUNTRY_ISO3": "IND",
        "POSTCODE": "392015",
        "STATE": "Gujarat",
        "CITY": "Bharuch",
        "SOURCE_URL": TIMKEN_INDIA_PAGE_URL,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Manufacturing plant",
        "LATITUDE": "",
        "LONGITUDE": "",
        "coord_source": "Not from website",
        "QA_flag": "",
        "LOCATION_NAME_NATIVE": "",
        "LOCATION_ADDRESS_NATIVE": "",
    },
    {
        "LOCATION_NAME": "Timken Engineering and Research India Private Limited - Chennai Plant",
        "LOCATION_ADDRESS": "6th Avenue, Plot No. AA-3, Mahindra World City, Chengalpattu, Kanchipuram, Tamil Nadu 603004, India",
        "COUNTRY": "India",
        "COUNTRY_ISO3": "IND",
        "POSTCODE": "603004",
        "STATE": "Tamil Nadu",
        "CITY": "Chengalpattu",
        "SOURCE_URL": TIMKEN_INDIA_PAGE_URL,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Manufacturing plant",
        "LATITUDE": "",
        "LONGITUDE": "",
        "coord_source": "Not from website",
        "QA_flag": "",
        "LOCATION_NAME_NATIVE": "",
        "LOCATION_ADDRESS_NATIVE": "",
    },
]


# =============================================================================
# GENERIC EXTRACTION LOGIC - Do not modify per issuer
# =============================================================================
CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS_NATIVE",
]

MANDATORY_NONBLANK = [
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "COUNTRY",
    "COUNTRY_ISO3",
    "CITY",
    "ACTIVITY_AT_ASSET",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "coord_source",
]

COUNTRY_ALIASES = {
    "USA": ("United States", "USA"),
    "UNITED STATES": ("United States", "USA"),
    "UNITED STATES OF AMERICA": ("United States", "USA"),
    "UK": ("United Kingdom", "GBR"),
    "UNITED KINGDOM": ("United Kingdom", "GBR"),
    "UNITED KINGDOM OF GREAT BRITAIN & NORTHERN IRELAND": ("United Kingdom", "GBR"),
    "GREAT BRITAIN": ("United Kingdom", "GBR"),
    "PEOPLE'S REPUBLIC OF CHINA": ("China", "CHN"),
    "CHINA": ("China", "CHN"),
    "REPUBLIC OF KOREA": ("South Korea", "KOR"),
    "SOUTH KOREA": ("South Korea", "KOR"),
    "REPUBLIC OF POLAND": ("Poland", "POL"),
    "TURKEY": ("Turkey", "TUR"),
    "UTD.ARAB EMIR.": ("United Arab Emirates", "ARE"),
    "UNITED ARAB EMIRATES": ("United Arab Emirates", "ARE"),
    "DOMINICAN REP.": ("Dominican Republic", "DOM"),
    "BOSNIA-HERZ.": ("Bosnia and Herzegovina", "BIH"),
    "COTE D'IVOIRE": ("Cote d'Ivoire", "CIV"),
    "CURACAO": ("Curacao", "CUW"),
    "CURACAO": ("Curacao", "CUW"),
    "CURAÇAO": ("Curacao", "CUW"),
    "PAP. NEW GUINEA": ("Papua New Guinea", "PNG"),
    "TOBAGO": ("Trinidad and Tobago", "TTO"),
    "TRINIDAD AND TOBAGO": ("Trinidad and Tobago", "TTO"),
    "MACEDONIA": ("North Macedonia", "MKD"),
    "SWAZILAND": ("Eswatini", "SWZ"),
    "VIETNAM": ("Vietnam", "VNM"),
    "VENEZUELA": ("Venezuela", "VEN"),
    "TANZANIA": ("Tanzania", "TZA"),
    "MOLDOVA": ("Moldova", "MDA"),
    "BOLIVIA": ("Bolivia", "BOL"),
    "CZECH REPUBLIC": ("Czech Republic", "CZE"),
}

POSTCODE_PLACEHOLDERS = {"", ".", "-", "NA", "N/A", "NONE", "0", "00", "000", "0000", "00000", "000000", "99999", "999999"}
CITY_JUNK_RE = re.compile(r"\b(floor|suite|level|unit|po box|p\.o\. box|gpo box)\b|^#", re.I)
ACTIVITY_JUNK_RE = re.compile(r"\b(compare|add to|shop now|click here|menu|search|support|helpdesk)\b", re.I)
LONG_REGION_NAMES = {
    "BEIJING",
    "BUENOS AIRES",
    "CALIFORNIA",
    "DELHI",
    "DKI JAKARTA JAKARTA",
    "GAUTENG",
    "GUANGDONG",
    "HENAN",
    "HUBEI",
    "ILLINOIS",
    "JIANGSU",
    "KANAGAWA",
    "KARNATAKA",
    "LIAONING",
    "MAHARASHTRA",
    "NORTH CAROLINA",
    "ONTARIO",
    "PENNSYLVANIA",
    "QUEENSLAND",
    "SAO PAULO",
    "SELANGOR",
    "SHANDONG",
    "SHANGHAI",
    "SHANXI",
    "SICHUAN",
    "TEXAS",
    "VICTORIA",
    "WEST BENGAL",
}


def clean_html_text(value: Any) -> str:
    text = html.unescape(str(value or ""))
    text = BeautifulSoup(text, "html.parser").get_text(" ", strip=True)
    text = text.replace("\xa0", " ")
    return re.sub(r"\s+", " ", text).strip()


def ascii_text(value: str) -> str:
    value = value.replace("ß", "ss").replace("ä", "ae").replace("ö", "oe").replace("ü", "ue")
    value = value.replace("Ä", "Ae").replace("Ö", "Oe").replace("Ü", "Ue")
    value = unidecode(value)
    value = value.replace("#", "Suite ")
    value = re.sub(r"\s+", " ", value)
    value = re.sub(r"\s+,", ",", value)
    return value.strip(" ,")


def standardize_country(raw_country: str) -> tuple[str, str]:
    key = ascii_text(raw_country).upper().strip()
    key = re.sub(r"\s+", " ", key)
    if key in COUNTRY_ALIASES:
        return COUNTRY_ALIASES[key]
    try:
        country = pycountry.countries.lookup(key)
        return ascii_text(country.name), country.alpha_3
    except LookupError:
        return ascii_text(raw_country).title(), ""


def split_country(parts: list[str]) -> tuple[list[str], str]:
    if len(parts) >= 2 and parts[-2].strip().upper() == "TRINIDAD" and parts[-1].strip().upper() == "TOBAGO":
        return parts[:-2], "TRINIDAD AND TOBAGO"
    return parts[:-1], parts[-1] if parts else ""


def looks_like_postcode(token: str) -> bool:
    token = token.strip()
    if not token:
        return False
    if token.upper() in POSTCODE_PLACEHOLDERS:
        return True
    return bool(re.search(r"\d", token)) and len(token) <= 14


def parse_address(address: str) -> tuple[str, str, str, str, str]:
    parts = [p.strip() for p in address.split(",") if p.strip()]
    if not parts:
        return "", "", "", "", ""
    remaining, raw_country = split_country(parts)
    country, iso3 = standardize_country(raw_country)
    country_obj = pycountry.countries.get(alpha_3=iso3) if iso3 else None
    if country_obj and remaining and ascii_text(remaining[-1]).upper() == country_obj.alpha_2:
        remaining.pop()
    postcode = ""
    state = ""
    city = ""
    if (
        remaining
        and looks_like_postcode(remaining[-1])
        and not (
            country in {"Colombia", "United Arab Emirates"}
            and remaining[-1].isdigit()
            and len(remaining[-1]) <= 3
        )
    ):
        postcode = remaining.pop().strip()
        if postcode.upper() in POSTCODE_PLACEHOLDERS:
            postcode = ""
    if remaining:
        state_candidate = remaining[-1].strip()
        state_key = ascii_text(state_candidate).upper()
        if len(remaining) >= 2 and (
            len(state_candidate) <= 4
            or any(ch.isdigit() for ch in state_candidate)
            or state_key in LONG_REGION_NAMES
        ):
            state = remaining.pop().strip()
    if remaining:
        city = remaining.pop().strip()
    if not city and state:
        city, state = state, ""
    return country, iso3, ascii_text(postcode), ascii_text(state), ascii_text(city)


def marker_activity(marker: dict[str, Any]) -> str:
    map_id = str(marker.get("map_id", ""))
    if map_id == "1":
        first = clean_html_text(marker.get("address")).split(",")[0].strip()
        first_ascii = ascii_text(first)
        if "headquarters" in first_ascii.lower():
            return first_ascii
        if "office" in first_ascii.lower():
            return first_ascii
        return "Sales office"
    cats = [str(c) for c in marker.get("categories") or []]
    if not cats and marker.get("category"):
        cats = [str(marker["category"])]
    labels = [CATEGORY_LABELS.get(c, "").strip() for c in cats if CATEGORY_LABELS.get(c)]
    suffix = " - " + "; ".join(dict.fromkeys(labels)) if labels else ""
    return f"Authorized Timken distributor{suffix}"


def marker_name(marker: dict[str, Any]) -> tuple[str, str]:
    title_native = clean_html_text(marker.get("title"))
    title = ascii_text(title_native)
    if str(marker.get("map_id")) == "1":
        first = clean_html_text(marker.get("address")).split(",")[0].strip()
        first_ascii = ascii_text(first)
        if first_ascii and first_ascii.lower() not in title.lower():
            title = f"{title} - {first_ascii}"
    return title, title_native if title_native != title else ""


def marker_to_row(marker: dict[str, Any]) -> dict[str, str]:
    address_native = clean_html_text(marker.get("address"))
    address = ascii_text(address_native)
    country, iso3, postcode, state, city = parse_address(address)
    name, name_native = marker_name(marker)
    map_id = str(marker.get("map_id", ""))
    lat = clean_html_text(marker.get("lat"))
    lng = clean_html_text(marker.get("lng"))
    row = {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": name,
        "LOCATION_ADDRESS": address,
        "LATITUDE": lat,
        "LONGITUDE": lng,
        "COUNTRY": country,
        "COUNTRY_ISO3": iso3,
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": MAPS.get(map_id, {}).get("source_url", MARKERS_API),
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": marker_activity(marker),
        "coord_source": "website" if lat and lng else "Not from website",
        "QA_flag": "",
        "LOCATION_NAME_NATIVE": name_native,
        "LOCATION_ADDRESS_NATIVE": address_native if address_native != address else "",
    }
    return row


def fetch_markers() -> list[dict[str, Any]]:
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36",
        "Accept": "application/json,text/plain,*/*",
        "Referer": MAPS["2"]["page_url"],
    }
    response = requests.get(MARKERS_API, headers=headers, timeout=90)
    response.raise_for_status()
    markers = response.json()
    if not isinstance(markers, list):
        raise ValueError("WPGMZA markers route did not return a JSON list")
    return markers


def dedupe_rows(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    seen: set[tuple[str, str, str]] = set()
    output: list[dict[str, str]] = []
    for row in rows:
        key = (
            row["LOCATION_NAME"].lower(),
            row["LOCATION_ADDRESS"].lower(),
            row["SOURCE_URL"].lower(),
        )
        if key in seen:
            continue
        seen.add(key)
        output.append(row)
    return output


def validate_rows(rows: list[dict[str, str]]) -> tuple[list[dict[str, str]], list[dict[str, Any]], dict[str, Any]]:
    valid: list[dict[str, str]] = []
    rejected: list[dict[str, Any]] = []
    tier_a: list[dict[str, Any]] = []
    tier_b: list[dict[str, Any]] = []
    semantic_flags: list[dict[str, Any]] = []
    blank_counts = {col: 0 for col in MANDATORY_NONBLANK}
    blank_counts["coord_source_violations"] = 0

    for idx, row in enumerate(rows, start=1):
        flags: list[str] = []
        original_address = row["LOCATION_ADDRESS"]
        if "#" in original_address:
            row["LOCATION_ADDRESS"] = ascii_text(original_address)
            row["QA_flag"] = "fixed"
            tier_a.append(
                {
                    "row_index": idx,
                    "location_name": row["LOCATION_NAME"],
                    "column": "LOCATION_ADDRESS",
                    "original_value": original_address,
                    "fixed_value": row["LOCATION_ADDRESS"],
                    "fix_reason": "Replaced hash unit marker with Suite text.",
                }
            )
        if row["coord_source"] not in {"website", "Not from website"}:
            original = row["coord_source"]
            row["coord_source"] = "website" if row["LATITUDE"] and row["LONGITUDE"] else "Not from website"
            row["QA_flag"] = "fixed"
            blank_counts["coord_source_violations"] += 1
            tier_a.append(
                {
                    "row_index": idx,
                    "location_name": row["LOCATION_NAME"],
                    "column": "coord_source",
                    "original_value": original,
                    "fixed_value": row["coord_source"],
                    "fix_reason": "Normalized coordinate source enum.",
                }
            )
        for col in MANDATORY_NONBLANK:
            if not row.get(col, "").strip():
                blank_counts[col] += 1
        city = row.get("CITY", "")
        if city and (re.match(r"^\d", city) or len(city) < 2 or len(city) > 60 or CITY_JUNK_RE.search(city)):
            flags.append("CITY_SUSPICIOUS")
            semantic_flags.append(
                {
                    "row_index": idx,
                    "location_name": row["LOCATION_NAME"],
                    "flag_code": "CITY_SUSPICIOUS",
                    "flagged_value": city,
                    "column": "CITY",
                }
            )
        if city and city.upper() in {row.get("COUNTRY", "").upper(), row.get("COUNTRY_ISO3", "").upper()}:
            flags.append("CITY_IS_COUNTRY")
        activity = row.get("ACTIVITY_AT_ASSET", "")
        if ACTIVITY_JUNK_RE.search(activity):
            flags.append("ACTIVITY_JUNK")
        missing_core = [col for col in MANDATORY_NONBLANK if not row.get(col, "").strip()]
        if missing_core:
            rejected.append(
                {
                    "row_index": idx,
                    "raw_content": json.dumps(row, ensure_ascii=False)[:200],
                    "rejection_reason": "Mandatory fields missing: " + ", ".join(missing_core),
                }
            )
            continue
        if flags and row["QA_flag"] != "fixed":
            row["QA_flag"] = "|".join(dict.fromkeys(flags))
            tier_b.append(
                {
                    "row_index": idx,
                    "location_name": row["LOCATION_NAME"],
                    "qa_flag": row["QA_flag"],
                    "columns_needing_review": sorted({"CITY" if "CITY" in f else "ACTIVITY_AT_ASSET" for f in flags}),
                    "original_value": city if any("CITY" in f for f in flags) else activity,
                    "attempted_fix": row["CITY"] if any("CITY" in f for f in flags) else activity,
                    "uncertainty_reason": "Semantic validator flagged a value that could not be confidently auto-rectified.",
                }
            )
        valid.append(row)

    qa = {
        "tier_a_fixed": tier_a,
        "tier_b_flagged": tier_b,
        "tier_c_rejected": rejected,
        "semantic_flags": semantic_flags,
        "blank_mandatory_counts": blank_counts,
    }
    return valid, rejected, qa


def qa_spot_check(rows: list[dict[str, str]], qa: dict[str, Any]) -> dict[str, Any]:
    total = len(rows)
    sample_size = total if total < 5 else (5 if total <= 50 else max(5, round(total * 0.10)))
    if total == 0:
        sample = []
    else:
        step = max(1, total // sample_size)
        sample = list(range(0, total, step))[:sample_size]
    clean = 0
    for idx in sample:
        row = rows[idx]
        if (
            row["LOCATION_ADDRESS"]
            and row["CITY"]
            and row["ACTIVITY_AT_ASSET"]
            and row["coord_source"] in {"website", "Not from website"}
            and not row["QA_flag"]
        ):
            clean += 1
    return {
        "rows_total": total,
        "rows_inspected": len(sample),
        "inspection_pct": round((len(sample) / total) * 100, 2) if total else 0,
        "full_page_scraper": False,
        "sample_method": "standard 10%",
        "sample_indices": [idx + 1 for idx in sample[:50]],
        "sample_index_count": len(sample),
        "qa_clean_in_sample": clean,
        **qa,
    }


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    ISSUER_TEMP.mkdir(parents=True, exist_ok=True)
    STAGING_DIR.mkdir(parents=True, exist_ok=True)
    markers = fetch_markers()
    rows = []
    for marker in markers:
        map_id = str(marker.get("map_id", ""))
        if map_id not in MAPS or str(marker.get("approved", "1")) != "1":
            continue
        rows.append(marker_to_row(marker))

    checkpoint_rows = rows[:TARGET_COUNT]
    write_csv(ISSUER_TEMP / f"{ISSUER_ID}_checkpoint_at_{TARGET_COUNT}.csv", checkpoint_rows)

    for supplemental in SUPPLEMENTAL_OFFICIAL_ROWS:
        row = {col: "" for col in CSV_COLUMNS}
        row.update(supplemental)
        row["ISSUER_ID"] = ISSUER_ID
        row["ISSUER_NAME"] = ISSUER_NAME
        rows.append(row)

    rows = dedupe_rows(rows)
    rows, rejected, qa = validate_rows(rows)
    output_path = STAGING_DIR / OUTPUT_BASENAME
    write_csv(output_path, rows)

    rejected_path = ISSUER_TEMP / f"{ISSUER_ID}_rejected.csv"
    if rejected:
        with rejected_path.open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.DictWriter(handle, fieldnames=["row_index", "raw_content", "rejection_reason"])
            writer.writeheader()
            writer.writerows(rejected)
    else:
        rejected_path.write_text("row_index,raw_content,rejection_reason\n", encoding="utf-8")

    qa_summary = qa_spot_check(rows, qa)
    qa_summary.update(
        {
            "issuer_id": ISSUER_ID,
            "issuer_name": ISSUER_NAME,
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "output_path": str(output_path),
            "rejected_path": str(rejected_path),
            "marker_rows_fetched": len(markers),
            "marker_rows_exported": len(rows) - len(SUPPLEMENTAL_OFFICIAL_ROWS),
            "supplemental_rows_added": len(SUPPLEMENTAL_OFFICIAL_ROWS),
            "maps": {map_id: cfg["page_url"] for map_id, cfg in MAPS.items()},
            "row_count_by_source_url": {},
        }
    )
    for row in rows:
        qa_summary["row_count_by_source_url"][row["SOURCE_URL"]] = qa_summary["row_count_by_source_url"].get(row["SOURCE_URL"], 0) + 1

    (ISSUER_TEMP / "wp_google_maps_qa_summary.json").write_text(
        json.dumps(qa_summary, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    country_counts = {}
    for row in rows:
        country_counts[row["COUNTRY"]] = country_counts.get(row["COUNTRY"], 0) + 1
    (ISSUER_TEMP / "country_counts.json").write_text(
        json.dumps(dict(sorted(country_counts.items(), key=lambda kv: (-kv[1], kv[0]))), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(json.dumps({
        "rows": len(rows),
        "rejected": len(rejected),
        "output": str(output_path),
        "qa_rows_inspected": qa_summary["rows_inspected"],
        "tier_a_fixed": len(qa_summary["tier_a_fixed"]),
        "tier_b_flagged": len(qa_summary["tier_b_flagged"]),
    }, indent=2))


if __name__ == "__main__":
    main()
