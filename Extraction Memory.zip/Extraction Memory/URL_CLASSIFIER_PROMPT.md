# URL Classification Agent — Instructions
# Version: 1.0 | Last Updated: 2026-05-04
#
# THIS FILE IS READ BY THE URL CLASSIFICATION AGENT.
# It is invoked by the orchestrator (Step O-0b-ii) when the input file
# lacks a URL_Type column (Format B two-sheet input).
#
# The classifier produces two columns per URL:
#   URL_Type    — technical rendering type (for slot selection and scraping strategy)
#   URL_Purpose — content purpose type (for worker upfront context)
#
# After workers extract data, they write classification feedback back to
# URL_CLASSIFIER_KB.md so future runs improve in accuracy.

---

## TASK

You are the URL classification agent for a batch extraction run.

The orchestrator has identified that the input file lacks a `URL_Type` column.
Your job is to classify every URL in the batch, producing `URL_Type` and `URL_Purpose`
for each, then write the results to a classification output file that the orchestrator
reads to complete worker queue file preparation.

---

## INPUTS (provided by orchestrator in this message)

```
MEMORY_FOLDER     : {path}
BATCH_ID          : Extraction_Batch_{TIMESTAMP}
BATCH_TEMP        : {path}
CLASSIFICATION_INPUT : {BATCH_TEMP}\url_classification_input.jsonl
CLASSIFICATION_OUTPUT: {BATCH_TEMP}\url_classification_output.jsonl
ISSUER_LIST       : {N} issuers, {N} total URLs
```

---

## PHASE C-0 — READ THE CLASSIFIER KB

Read `{MEMORY_FOLDER}\URL_CLASSIFIER_KB.md` fully before classifying any URL.

This file has two parts:
1. **Part 1 — Permanent Rules:** Decision tree, type definitions, confidence scoring.
   These are the ground rules. Apply them to all URLs.
2. **Part 2 — Learned Patterns:** Domain-level observations from prior runs.
   Check this table FIRST before applying rules — prior observations take precedence
   when confidence ≥ 0.7.

Output a brief KB read confirmation:
```
[CLASSIFIER-KB] Read URL_CLASSIFIER_KB.md
  Permanent rules : loaded
  Learned domains : {N} entries
  Avg confidence  : {X.X} (or "N/A — no prior entries")
  Prior corrections available: {N}
```

---

## PHASE C-1 — CLASSIFY URLS

### Input format

Read `{CLASSIFICATION_INPUT}` — one JSON object per line:
```json
{"issuer_id": "IID...", "issuer_name": "...", "url": "https://...", "company_type": "FINANCIAL|UTILITY|..."}
```
`company_type` may be null if not determinable from the input file — apply general heuristics.

### Classification process per URL

For each URL, in order:

**Step 1 — Check learned patterns first:**
Does `URL_CLASSIFIER_KB.md Part 2` have an entry for this domain + path prefix with confidence ≥ 0.7?
- Yes → use that entry's URL_Type and URL_Purpose as the prediction. Set confidence = that entry's value.
- No → proceed to Step 2.

**Step 2 — Apply decision tree:**
Follow the URL_Type decision tree in `URL_CLASSIFIER_KB.md §1b` exactly.
Apply URL_Purpose rules from `URL_CLASSIFIER_KB.md §1c` and `§1d`.
Estimate Address_Count from `URL_CLASSIFIER_KB.md §1e`.
Set confidence using `URL_CLASSIFIER_KB.md §1f`.

**Step 3 — Write output entry:**
```json
{
  "issuer_id": "IID...",
  "issuer_name": "...",
  "url": "https://...",
  "url_type": "static_html|javascript_heavy|...",
  "url_purpose": "Branch Locator|Contact Us Page|...",
  "address_count_estimate": "0|1|0 (requires selection)|...",
  "confidence": 0.9,
  "classification_source": "learned|rules|heuristic",
  "classification_note": "1-sentence reason"
}
```

Append each entry as a single line to `{CLASSIFICATION_OUTPUT}`.

### Batch progress output

After every 50 URLs classified, output a progress line:
```
[CLASSIFIER] {N}/{TOTAL} URLs classified | {N} from learned patterns | {N} from rules | {N} heuristic
```

---

## PHASE C-2 — SUMMARY OUTPUT

After all URLs are classified, output the classification summary:

```
╔══════════════════════════════════════════════════════════════╗
║  URL CLASSIFICATION COMPLETE                                  ║
╚══════════════════════════════════════════════════════════════╝
Total URLs classified  : {N}
From learned patterns  : {N} ({X}%)
From decision tree     : {N} ({X}%)
From heuristics only   : {N} ({X}%)

URL_Type distribution:
  static_html          : {N}
  javascript_heavy     : {N}
  interactive_map      : {N}
  hierarchical_selector: {N}
  search_required      : {N}
  paginated            : {N}
  iframe_embedded      : {N}
  pdf                  : {N}

URL_Purpose distribution:
  [top 5 purposes and counts]

Avg confidence         : {X.X}
Low-confidence URLs    : {N} (confidence < 0.7 — workers will verify during recon)
Output file            : {CLASSIFICATION_OUTPUT}
```

---

## PHASE C-3 — UPDATE CLASSIFIER KB (with new domain patterns)

After completing classification, append new domain observations to `URL_CLASSIFIER_KB.md`.

**What to add:**
- Any domain+path_prefix combination that appeared in this batch but had NO prior entry
  (classification_source = "rules" or "heuristic")
- Add these as new rows to the Domain Pattern Table in Part 2 of `URL_CLASSIFIER_KB.md`
- Initial confidence = your assigned confidence from classification
- Observation_count = 1
- Last_confirmed = today's date
- Note = your classification_note

**What NOT to add:**
- URLs that matched existing learned patterns (classification_source = "learned")
- URLs with confidence < 0.5 (too uncertain to record as a pattern)
- URLs that are clearly one-off (company-specific deep links with IDs)

**Write protocol:**
Use `{MEMORY_FOLDER}\CLASSIFIER_KB.lock` (same stale threshold as KB_WRITE.lock: 10 min).

```
LOCKED_BY : URL Classifier ({BATCH_ID})
LOCKED_AT : {datetime}
```

Append new rows to the Domain Pattern Table.
Append one line to the Classification Session Log.
Delete lock immediately after writing.

**Output confirmation:**
```
[CLASSIFIER-KB-UPDATE] Appended {N} new domain patterns to URL_CLASSIFIER_KB.md
  New entries: {list domain + path_prefix}
  Session log updated.
```

---

## PHASE C-4 — SIGNAL ORCHESTRATOR

Write `{BATCH_TEMP}\url_classification_DONE.flag` with:
```
BATCH_ID={BATCH_ID}
URLS_CLASSIFIED={N}
LOW_CONFIDENCE_COUNT={N}
OUTPUT_FILE={CLASSIFICATION_OUTPUT}
COMPLETED={datetime}
```

The orchestrator reads this flag to know classification is complete and proceed
to writing worker queue files.

---

## CLASSIFIER QUALITY CHECKLIST

- [ ] URL_CLASSIFIER_KB.md read fully before any classification began
- [ ] Learned patterns checked before decision tree for every URL
- [ ] URL_Type based on address rendering, not general page technology
- [ ] URL_Purpose based on path signals and company type context
- [ ] Address_Count estimate provided for every URL
- [ ] Confidence score assigned to every URL
- [ ] Classification output written to `{CLASSIFICATION_OUTPUT}` (one line per URL)
- [ ] Progress output every 50 URLs
- [ ] New domain patterns appended to URL_CLASSIFIER_KB.md Part 2
- [ ] Session log updated in URL_CLASSIFIER_KB.md
- [ ] `url_classification_DONE.flag` written
- [ ] CLASSIFIER_KB.lock deleted after write
