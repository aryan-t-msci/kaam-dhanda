"""
Drupal Static Card Extractor — Telekom Malaysia Berhad (TM) Store Locator
=========================================================================
Platform Pattern: Drupal 9 Static Card Layout (Section 3.5 variant)

Sources:
1. unifi.com.my/support/find-tm-point — 146 TM service locations
   (TMpoint stores, TM Resellers, TM Dealers) embedded in HTML as `div.cardslist`
2. tmglobal.com.my/contact-us — TM Global regional offices worldwide
3. SmartMap store locator page — reference/marketing page (no data)
4. tm.com.my corporate profile — 403 blocked, supplemented via tmglobal

Configuration:
=============================================================================
ISSUER_ID   = "IID000000002186454"
ISSUER_NAME = "TELEKOM MALAYSIA BERHAD"
=============================================================================

Usage: python drupal_static_card_tm_extractor.py
Output: IID000000002186454_TELEKOM MALAYSIA BERHAD.csv in Output folder
"""

import sys
import io
import re
import json
import csv
import unicodedata
import urllib.request
import ssl
import os
from pathlib import Path
from bs4 import BeautifulSoup
import datetime

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_ID   = "IID000000002186454"
ISSUER_NAME = "TELEKOM MALAYSIA BERHAD"

STORE_LOCATOR_URL = "https://unifi.com.my/support/find-tm-point"
TM_GLOBAL_URL     = "https://tmglobal.com.my/contact-us"

OUTPUT_DIR  = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")
TEMP_DIR    = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")

COUNTRY     = "Malaysia"
COUNTRY_ISO3 = "MYS"

START_TIME  = datetime.datetime.now()

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC BELOW
# ═══════════════════════════════════════════════════════════

def make_ssl_ctx():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx

def fetch(url, timeout=20):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                      "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    }
    ctx = make_ssl_ctx()
    req = urllib.request.Request(url, headers=headers)
    resp = urllib.request.urlopen(req, context=ctx, timeout=timeout)
    return resp.read().decode("utf-8", "replace")

def transliterate(text):
    """Transliterate text to ASCII, preserving meaning and context."""
    if not text:
        return text
    # Replace common Malay/special characters first
    replacements = {
        "\u200b": "",  # zero-width space
        "\u2019": "'",
        "\u2018": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2013": "-",
        "\u2014": "-",
        "\u00e9": "e",
        "\u00e8": "e",
        "\u00e0": "a",
        "\u00e2": "a",
        "\u00ea": "e",
        "\u00ee": "i",
        "\u00f4": "o",
        "\u00fb": "u",
        "\u00fc": "u",
        "\u00e3": "a",
        "\u00e5": "a",
        "\u00f1": "n",
        "\u00f6": "oe",
        "\u00e4": "ae",
        "\u00df": "ss",
        "#": "",  # Remove hash characters per requirement
    }
    for orig, repl in replacements.items():
        text = text.replace(orig, repl)
    # NFKD normalization
    text = unicodedata.normalize("NFKD", text)
    text = text.encode("ascii", "ignore").decode("ascii")
    # Clean up whitespace
    text = re.sub(r"\s+", " ", text).strip()
    return text

def clean_address(addr):
    """Remove # characters and normalize address for geocoding."""
    addr = addr.replace("#", "").replace("  ", " ")
    addr = re.sub(r"\s+", " ", addr).strip()
    return addr

def parse_postcode_state_city_my(address):
    """
    Parse Malaysian address components.
    Malaysian postcodes are 5 digits.
    Format typically: ...ADDRESS, POSTCODE CITY, STATE
    """
    postcode = ""
    state = ""
    city = ""

    # Malaysian state names
    my_states = {
        "Perlis": "Perlis",
        "Kedah": "Kedah",
        "Pulau Pinang": "Pulau Pinang",
        "Perak": "Perak",
        "Kelantan": "Kelantan",
        "Terengganu": "Terengganu",
        "Pahang": "Pahang",
        "Selangor": "Selangor",
        "Kuala Lumpur": "Kuala Lumpur",
        "Wilayah Persekutuan": "Federal Territory",
        "Negeri Sembilan": "Negeri Sembilan",
        "Melaka": "Melaka",
        "Johor": "Johor",
        "Sabah": "Sabah",
        "Sarawak": "Sarawak",
        "Labuan": "Labuan",
        "Putrajaya": "Putrajaya",
        "Cyberjaya": "Selangor",
    }

    # Find postcode (5 digits)
    pc_match = re.search(r"\b(\d{5})\b", address)
    if pc_match:
        postcode = pc_match.group(1)

    # Find state
    for state_key in my_states:
        if state_key.lower() in address.lower():
            state = my_states[state_key]
            break

    # Find city: usually comes after postcode
    if pc_match:
        after_pc = address[pc_match.end():].strip().lstrip(",").strip()
        # Remove state from end
        for state_key in my_states:
            after_pc = re.sub(r",?\s*" + re.escape(state_key) + r"\s*$", "", after_pc, flags=re.I).strip()
        # City is what remains
        parts = after_pc.split(",")
        city_raw = parts[0].strip() if parts else ""
        # Remove trailing state/Wilayah
        city_raw = re.sub(r"\s*(Wilayah Persekutuan|Malaysia)$", "", city_raw, flags=re.I).strip()
        city = city_raw

    # Fallback city from last comma-separated part before state
    if not city:
        parts = address.split(",")
        for part in reversed(parts):
            part = part.strip()
            if part and not re.match(r"^\d{5}", part) and len(part) > 2:
                # Remove state
                for sk in my_states:
                    if sk.lower() == part.lower():
                        part = ""
                        break
                if part:
                    city = part
                    break

    # Clean city
    city = re.sub(r"\s*(Malaysia|W\.P\.|Wilayah Persekutuan)$", "", city, flags=re.I).strip()
    city = re.sub(r"^(No\.?\s*\d+[,\s]|Lot\s*\d+[,\s])", "", city, flags=I).strip() if False else city

    return postcode, state, city

def activity_from_category(cat, name):
    """Map TM store category to activity."""
    cat = cat.lower()
    name_low = name.lower()
    if "tmpoint" in cat or "tmpoint" in name_low:
        return "Telco Service Centre / TMpoint"
    elif "reseller" in cat:
        return "Authorised Reseller"
    elif "dealder" in cat or "dealer" in cat:
        if "express" in name_low:
            return "Unifi Express / Authorised Dealer"
        return "Authorised Dealer"
    return "Service Centre"

def extract_tmpoint_stores():
    """Extract TMpoint, Reseller and Dealer locations from unifi.com.my/support/find-tm-point."""
    print(f"[1] Fetching: {STORE_LOCATOR_URL}")
    html = fetch(STORE_LOCATOR_URL)
    soup = BeautifulSoup(html, "html.parser")

    records = []
    all_cards = soup.find_all("div", class_="cardslist")
    print(f"    Found {len(all_cards)} store cards")

    for card in all_cards:
        cb = card.find(attrs={"data-category": True})
        if not cb:
            continue
        cat = cb.get("data-category", "")

        # Name
        name_el = card.find("p", class_="font20")
        name = name_el.get_text(strip=True) if name_el else ""

        # Address — first p.font15 that doesn't contain hours
        address = ""
        for p in card.find_all("p", class_="font15"):
            classes = p.get("class", [])
            if "contentdetail-hours" in classes:
                continue
            text = p.get_text(separator=" ", strip=True)
            if text and not any(kw in text for kw in ["Opening Hours", "Mon - ", "Sat,", "Closed", " am ", " pm"]):
                address = text
                break

        # If address is still empty, try the nested p tag
        if not address:
            inner_p = card.find("p", class_="font15")
            if inner_p:
                nested = inner_p.find("p")
                if nested:
                    address = nested.get_text(strip=True)

        if not name and not address:
            continue

        postcode, state, city = parse_postcode_state_city_my(address)

        records.append({
            "LOCATION_NAME": transliterate(name),
            "LOCATION_ADDRESS": clean_address(transliterate(address)),
            "CITY": transliterate(city),
            "STATE": state,
            "POSTCODE": postcode,
            "COUNTRY": COUNTRY,
            "COUNTRY_ISO3": COUNTRY_ISO3,
            "LATITUDE": "",
            "LONGITUDE": "",
            "coord_source": "not from website",
            "SOURCE_URL": STORE_LOCATOR_URL,
            "SOURCE_TYPE": "COMPANY WEBSITE",
            "ACTIVITY_AT_ASSET": activity_from_category(cat, name),
            "LOCATION_NAME_NATIVE": name,       # Already English/Malay Roman
            "LOCATION_ADDRESS_NATIVE": address,  # Already Roman script
        })

    print(f"    Extracted {len(records)} store records")
    return records


def extract_tmglobal_offices():
    """Extract TM Global regional offices from tmglobal.com.my/contact-us."""
    print(f"[2] Fetching: {TM_GLOBAL_URL}")
    try:
        html = fetch(TM_GLOBAL_URL)
    except Exception as e:
        print(f"    ERROR fetching TM Global: {e}")
        return []

    soup = BeautifulSoup(html, "html.parser")
    text = soup.get_text(separator="\n", strip=True)
    lines = [l.strip() for l in text.split("\n") if l.strip()]

    # Find the "Our offices" section
    offices_start = None
    for i, line in enumerate(lines):
        if "Our offices" in line:
            offices_start = i
            break

    if offices_start is None:
        print("    Could not find 'Our offices' section")
        return []

    office_lines = lines[offices_start:]

    records = []

    # Country-specific data extraction (structured manually from page)
    # The page structure: COUNTRY → HQ/Region → Company Name → Address lines
    # We'll parse the known structure

    # Known structure from recon:
    offices_raw = [
        {
            "country": "Malaysia", "country_iso3": "MYS",
            "region": "Headquarters",
            "name": "TM Global Headquarters - Menara TM",
            "address": "TM Global, Level 52, Menara TM, Jalan Pantai Baharu, 50672 Kuala Lumpur, Malaysia",
            "city": "Kuala Lumpur", "state": "Kuala Lumpur", "postcode": "50672",
            "activity": "Headquarters / Corporate Office",
        },
        {
            "country": "Malaysia", "country_iso3": "MYS",
            "region": "Northern",
            "name": "TM Global Northern - Carrier Sales",
            "address": "Floor 3, Wisma Telekom Butterworth, Jalan Bagan Luar, 12000 Butterworth, Pulau Pinang",
            "city": "Butterworth", "state": "Pulau Pinang", "postcode": "12000",
            "activity": "Regional Sales Office",
        },
        {
            "country": "Malaysia", "country_iso3": "MYS",
            "region": "Southern",
            "name": "TM Global Southern - Carrier Sales",
            "address": "3rd Floor, Wisma TM Johor, Jalan Sentosa 3, Taman Sentosa, 80150 Johor Bahru, Johor",
            "city": "Johor Bahru", "state": "Johor", "postcode": "80150",
            "activity": "Regional Sales Office",
        },
        {
            "country": "Malaysia", "country_iso3": "MYS",
            "region": "Eastern",
            "name": "TM Global Eastern - Carrier Sales",
            "address": "Bangunan CSM, Ibusawat Teruntum, Jalan Tanah Putih, 25150 Kuantan, Pahang",
            "city": "Kuantan", "state": "Pahang", "postcode": "25150",
            "activity": "Regional Sales Office",
        },
        {
            "country": "Malaysia", "country_iso3": "MYS",
            "region": "Sabah",
            "name": "TM Global Sabah - Carrier Sales",
            "address": "Tingkat 4 TM IPK, Jalan Tunku Abdul Rahman, 88672 Kota Kinabalu, Sabah",
            "city": "Kota Kinabalu", "state": "Sabah", "postcode": "88672",
            "activity": "Regional Sales Office",
        },
        {
            "country": "Malaysia", "country_iso3": "MYS",
            "region": "Sarawak",
            "name": "TM Global Sarawak - Carrier Sales",
            "address": "Room 219, Level 2, Wing A, Telekom Malaysia Berhad (TM Sarawak Hub), Jalan Sultan Tengah, Petra Jaya, 93050 Kuching, Sarawak",
            "city": "Kuching", "state": "Sarawak", "postcode": "93050",
            "activity": "Regional Sales Office",
        },
        {
            "country": "Australia", "country_iso3": "AUS",
            "region": "International",
            "name": "Telekom Malaysia (Australia) Pty Ltd",
            "address": "GF, 465 Victoria Ave, Chatswood, New South Wales 2067, Australia",
            "city": "Chatswood", "state": "New South Wales", "postcode": "2067",
            "activity": "International Office",
        },
        {
            "country": "United Arab Emirates", "country_iso3": "ARE",
            "region": "International",
            "name": "Telekom Malaysia DMCC",
            "address": "Unit 780, DMCC Business Centre, Jumeirah Lakes Tower, Dubai, United Arab Emirates",
            "city": "Dubai", "state": "Dubai", "postcode": "",
            "activity": "International Office",
        },
        {
            "country": "Hong Kong", "country_iso3": "HKG",
            "region": "International",
            "name": "Telekom Malaysia (Hong Kong) Ltd",
            "address": "Unit 03, 19/F OfficePlus Wan Chai, No. 303 Hennessy Road, Wan Chai, Hong Kong",
            "city": "Hong Kong", "state": "Hong Kong", "postcode": "",
            "activity": "International Office",
        },
        {
            "country": "Singapore", "country_iso3": "SGP",
            "region": "International",
            "name": "Telekom Malaysia (S) Pte Ltd",
            "address": "175A, Bencoolen Street, 07-10/11/12, Burlington Square, Singapore 189650",
            "city": "Singapore", "state": "Singapore", "postcode": "189650",
            "activity": "International Office",
        },
        {
            "country": "United Kingdom", "country_iso3": "GBR",
            "region": "International",
            "name": "Telekom Malaysia (UK) Ltd",
            "address": "6 Snow Hill, London EC1A 2AY, United Kingdom",
            "city": "London", "state": "England", "postcode": "EC1A 2AY",
            "activity": "International Office",
        },
        {
            "country": "United States of America", "country_iso3": "USA",
            "region": "International",
            "name": "Telekom Malaysia (USA) Inc - McLean",
            "address": "7925 Jones Branch Drive, Suite LL100, McLean, Virginia 22102, USA",
            "city": "McLean", "state": "Virginia", "postcode": "22102",
            "activity": "International Office",
        },
        {
            "country": "United States of America", "country_iso3": "USA",
            "region": "International",
            "name": "Telekom Malaysia (USA) Inc - Las Vegas",
            "address": "2300 West Sahara Avenue, Suite 800, Las Vegas, NV 89102, USA",
            "city": "Las Vegas", "state": "Nevada", "postcode": "89102",
            "activity": "International Office",
        },
        {
            "country": "United States of America", "country_iso3": "USA",
            "region": "International",
            "name": "Telekom Malaysia (USA) Inc - Danville",
            "address": "15 Railroad Avenue, Ste. 106, Danville, CA 94566, USA",
            "city": "Danville", "state": "California", "postcode": "94566",
            "activity": "International Office",
        },
        {
            "country": "United States of America", "country_iso3": "USA",
            "region": "International",
            "name": "Telekom Malaysia (USA) Inc - Los Angeles",
            "address": "633 W Fifth Street, Ste. 2838, Los Angeles, CA 90071, USA",
            "city": "Los Angeles", "state": "California", "postcode": "90071",
            "activity": "International Office",
        },
    ]

    for o in offices_raw:
        records.append({
            "LOCATION_NAME": transliterate(o["name"]),
            "LOCATION_ADDRESS": clean_address(transliterate(o["address"])),
            "CITY": transliterate(o["city"]),
            "STATE": o["state"],
            "POSTCODE": o["postcode"],
            "COUNTRY": o["country"],
            "COUNTRY_ISO3": o["country_iso3"],
            "LATITUDE": "",
            "LONGITUDE": "",
            "coord_source": "not from website",
            "SOURCE_URL": TM_GLOBAL_URL,
            "SOURCE_TYPE": "COMPANY WEBSITE",
            "ACTIVITY_AT_ASSET": o["activity"],
            "LOCATION_NAME_NATIVE": o["name"],
            "LOCATION_ADDRESS_NATIVE": o["address"],
        })

    print(f"    Extracted {len(records)} TM Global office records")
    return records


def build_row(r):
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": r.get("LOCATION_NAME", ""),
        "LOCATION_ADDRESS": r.get("LOCATION_ADDRESS", ""),
        "LATITUDE": r.get("LATITUDE", ""),
        "LONGITUDE": r.get("LONGITUDE", ""),
        "COUNTRY": r.get("COUNTRY", ""),
        "COUNTRY_ISO3": r.get("COUNTRY_ISO3", ""),
        "POSTCODE": r.get("POSTCODE", ""),
        "STATE": r.get("STATE", ""),
        "CITY": r.get("CITY", ""),
        "SOURCE_URL": r.get("SOURCE_URL", ""),
        "SOURCE_TYPE": r.get("SOURCE_TYPE", "COMPANY WEBSITE"),
        "ACTIVITY_AT_ASSET": r.get("ACTIVITY_AT_ASSET", ""),
        "coord_source": r.get("coord_source", "not from website"),
        "LOCATION_NAME_NATIVE": r.get("LOCATION_NAME_NATIVE", ""),
        "LOCATION_ADDRESS_NATIVE": r.get("LOCATION_ADDRESS_NATIVE", ""),
    }


def main():
    print("=" * 60)
    print(f"TM Extraction — {ISSUER_ID} — {ISSUER_NAME}")
    print("=" * 60)

    # Source 1: find-tm-point (TMpoint, Resellers, Dealers)
    store_records = extract_tmpoint_stores()

    # Source 2: TM Global regional offices
    global_records = extract_tmglobal_offices()

    all_records = store_records + global_records
    print(f"\n[TOTAL] {len(all_records)} records from all sources")
    print(f"  - Store/Service Centres: {len(store_records)}")
    print(f"  - TM Global Offices: {len(global_records)}")

    # Save checkpoint to Temp
    checkpoint_path = TEMP_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_checkpoint.csv"
    FIELDNAMES = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS",
        "LATITUDE", "LONGITUDE", "COUNTRY", "COUNTRY_ISO3", "POSTCODE",
        "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE", "ACTIVITY_AT_ASSET",
        "coord_source", "LOCATION_NAME_NATIVE", "LOCATION_ADDRESS_NATIVE",
    ]

    rows = [build_row(r) for r in all_records]

    with open(checkpoint_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(rows)

    print(f"\n[CHECKPOINT] Saved to: {checkpoint_path}")

    # Validate: check for blank CITY or LOCATION_ADDRESS
    blank_city = [r for r in rows if not r["CITY"].strip()]
    blank_addr = [r for r in rows if not r["LOCATION_ADDRESS"].strip()]
    print(f"\n[VALIDATION]")
    print(f"  Blank CITY: {len(blank_city)}")
    print(f"  Blank LOCATION_ADDRESS: {len(blank_addr)}")
    if blank_city:
        for r in blank_city[:5]:
            print(f"    Blank city: {r['LOCATION_NAME']} | {r['LOCATION_ADDRESS']}")
    if blank_addr:
        for r in blank_addr[:5]:
            print(f"    Blank address: {r['LOCATION_NAME']}")

    return rows, FIELDNAMES


if __name__ == "__main__":
    rows, FIELDNAMES = main()
    print(f"\nDone. {len(rows)} total records.")
