# `run_batch_poc.ps1` - Proof-of-Concept Runbook

## What this is
A **small proof of concept** for replacing the fragile chat-as-orchestrator with the
official `codex exec` per-issuer loop. It processes just a **few issuers** so you can verify
on your own machine that the mechanism works end-to-end **before** we build the full
production orchestrator.

Each issuer is handled by a **fresh `codex exec` worker** that reads `prompt.md` +
`WORKER_PROMPT.md` and runs the **complete, unchanged extraction workflow** (KB check ->
tier ladder -> exhaustive search -> checkpoint -> QA). Fresh context per worker = no
context-window blowup, the root problem that broke the chat orchestrator at scale.

## Why this architecture
- **No turn/context limit problem** - each worker starts with a clean context window.
- **Fully unattended** - `--dangerously-bypass-approvals-and-sandbox` means no approval stalls.
- **Workflow & quality unchanged** - the worker still does everything `WORKER_PROMPT.md` says.
- **The three Windows bugs from the earlier live run are pre-fixed** (path quoting, stderr
  banner handling, real node PID tracking).

## Before you run
**Model, reasoning, and input file are command-line parameters** (see "How to run" below) -
you don't need to edit the file for those. Pass `-Model`, `-Reasoning`, `-InputFile` on the
command line, or omit them to use the defaults.

The remaining settings live in the `CONFIG` block near the top of `run_batch_poc.ps1` and
are edited in-file if you ever need to change them:
- `$MEMORY_FOLDER`, `$TEMP_ROOT`, `$OUTPUT_ROOT` - your folder paths.
- `$POC_LIMIT` (default 3) - how many issuers to process in this test.
- `$WORKER_CAP` (default 3) - how many run in parallel.
- `$CodexJs` - path to codex.js (default matches your environment).

Model defaults are `gpt-5.4` / `high`. This is deterministic on purpose: one explicit
setting, so no worker ever silently downgrades. Override per run with `-Model` / `-Reasoning`.

## How to run
Open a **plain terminal** (PowerShell or the Codex app's `Cmd+J` terminal) in the
`In House Issuers` folder (or anywhere), then run one of:

```powershell
# Bare run - uses the defaults baked into the script (gpt-5.4 / high / the default input)
powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch_poc.ps1"

# Override model, reasoning, and/or input file on the command line:
powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch_poc.ps1" -Model "gpt-5.4" -Reasoning "high" -InputFile "C:\path\to\your_input.xlsx"

# Override just the input file:
powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch_poc.ps1" -InputFile "C:\Users\tiwaary\Downloads\odbatch9_10_output_for_straive.xlsx"
```

`-Model`, `-Reasoning`, and `-InputFile` are all optional. Anything you omit falls back to
the default in the script's `param()` block. The script prints the resolved Model /
Reasoning / InputFile at startup so you can confirm your overrides took effect.

> Run it directly in a terminal, **not** by asking a Codex chat to run it. The script
> *is* the orchestrator; the Codex chat is not needed.

## What success looks like
You should see log lines like:
```
[..] Parsed. Processing first 3 issuers (of 499 total).
[..]   spawned worker 01 for IID... (Company) | node pid=12345
[..] [MONITOR] promoted=0/3 | active=3 | queued=0
[..]   promoted IID... -> output (NN rows)
[..] [MONITOR] promoted=1/3 | active=2 | queued=0
...
[..] PoC complete. Promoted 3/3 issuers.
```
Then check the **output folder** it prints - you should find `{IID}_{NAME}.csv` files with
real extracted facility rows.

## What to look for (the verification questions)
1. **Do workers actually spawn and run?** (log shows `node pid=` for each)
2. **Do they write staging CSVs and DONE flags?** (check `...\staging\` and `...\status\`)
3. **Does promotion work?** (CSVs appear in the output folder)
4. **Is the extraction correct?** (open a CSV - are the rows real facilities matching the
   `WORKER_PROMPT.md` schema, with the exhaustive search behavior we built?)
5. **Does it run unattended?** (no approval prompts, no manual nudging)

## If something fails
### Parse stage (before any worker spawns)
The input is parsed by an embedded Python helper that **auto-detects the header row** (a title
or instructions row above the real headers is fine) and reads issuer ID / name / count / URL
columns from whichever sheet holds them (a stray cover or summary sheet is ignored). If it
finds no `IID` rows it prints a **short, bounded diagnostics block** - sheet names, the detected
header row per sheet, the columns it matched, a sample data row, and a sample of any IDs that
did NOT start with `IID`. That block is safe to paste back. The **full** raw parser output and
stderr are always saved to `...\_parse_stdout.txt` and `...\_parse_stderr.txt` in the batch Temp
folder, so the console never floods. The two most likely causes the diagnostics will surface:
column names that don't match, or issuer IDs missing the `IID` prefix.

### Worker stage
Each worker writes a full log at `...\workers\{IID}_worker.log` - open it to see the worker's
own transcript and any error. Common things to check:
- `codex.js` path correct in CONFIG?
- Model string valid for your account (`gpt-5.4`)?
- Worker log shows it reading `prompt.md` + `WORKER_PROMPT.md`?

## Scope NOT in this PoC (comes in the production version if this works)
- URL classification step (this PoC feeds raw URLs with `unknown` type)
- Rework pass for gap issuers
- Size-aware throttling
- Full orchestrator scrub + reject consolidation
- Resume-skip (skipping already-completed issuers on restart)
- Heaviest-first across the full 500 with proper logging/usage tracking

Once you confirm the PoC works end-to-end, those get added to a hardened
`run_batch.ps1` production orchestrator.
