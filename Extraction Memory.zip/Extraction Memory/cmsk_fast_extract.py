"""
CMSK Fast Extraction - Targeted PDF Table Parser
Extracts project data from pages 11-35 of the 2024 annual report.
"""
import pdfplumber, re, csv, json, io, sys, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

TEMP_DIR = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Temp"
PDF_PATH = rf"{TEMP_DIR}\cmsk_annual_report_2024.pdf"

def extract_project_pages(pdf_path):
    """Extract text from pages containing project table (~pages 11-35)."""
    all_text = ""
    target_pages = list(range(10, 50))  # pages 11-50 (0-indexed 10-49)
    
    with pdfplumber.open(pdf_path) as pdf:
        for i in target_pages:
            if i >= len(pdf.pages):
                break
            text = pdf.pages[i].extract_text()
            if text:
                all_text += f"\n\n===PAGE{i+1}===\n{text}"
    
    return all_text

def parse_project_rows(text: str) -> list:
    """
    Parse project rows from the PDF text.
    Row format: SEQ PROJECT_NAME LOCATION BIZ_TYPE STATUS [equity% ...]
    """
    projects = []
    seen = set()
    
    # More flexible pattern that handles the actual PDF text structure
    # The text from pdfplumber puts columns in order but sometimes wraps
    # Pattern: line starting with a digit or digits, followed by project data
    
    # Split into lines and process
    lines = text.split('\n')
    
    # State machine to build project rows
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            continue
        
        # Skip header lines
        if any(h in line for h in ['===PAGE', '招商局蛇口工业区', '序号', '序\n', '项目名称', '项目\n号',
                                    '规划计容', '2024年开', '累计开工', '累计竣工', 
                                    '2024年竣', '2024年签', '2024年结', '2024年末']):
            i += 1
            continue
        
        # Check if line starts with a sequence number
        # Pattern: "26 项目名 地址 业态 状态 ..."
        # Or multi-line: "26 (挂)2024-013号地\n块*\n天津武清\n住宅..."
        
        m = re.match(r'^(\d{1,3})\s+(.+)', line)
        if m:
            seq = m.group(1)
            rest = m.group(2).strip()
            
            # Accumulate continuation lines until next numbered row
            full_row = rest
            j = i + 1
            while j < len(lines):
                next_line = lines[j].strip()
                if not next_line:
                    j += 1
                    continue
                # Check if next line starts a new row
                if re.match(r'^\d{1,3}\s+[\u4e00-\u9fff（(]', next_line):
                    break
                # Check if it looks like a header line
                if any(h in next_line for h in ['===PAGE', '招商局蛇口', '序号', '规划计容', '2024年']):
                    break
                # Numbers-only line (data columns)
                if re.match(r'^[\d,，\-\s%\.]+$', next_line):
                    j += 1
                    continue
                full_row += ' ' + next_line
                j += 1
            
            # Parse the accumulated row
            proj = parse_single_row(seq, full_row)
            if proj:
                key = (proj['name_cn'], proj['location_cn'])
                if key not in seen and key[0]:
                    seen.add(key)
                    projects.append(proj)
            
            i = j
        else:
            i += 1
    
    return projects

def parse_single_row(seq: str, row_text: str) -> dict:
    """Parse a single project row into structured data."""
    # The row should look like: "项目名称 地址 业态 状态 ..."
    # Business types to look for
    biz_types = ['住宅、商业、办公', '住宅、商业', '住宅、办公', '商业、办公', '办公、商业', 
                 '住宅', '商业', '办公', '产业园', '综合']
    statuses = ['竣工', '在建', '拟建']
    
    # Find status first (rightmost occurrence before data columns)
    status_cn = ''
    biz_type_cn = ''
    
    for s in statuses:
        if s in row_text:
            status_cn = s
            break
    
    for bt in biz_types:
        if bt in row_text:
            biz_type_cn = bt
            break
    
    if not status_cn:
        return None
    
    # Everything before the business type is name + location
    if biz_type_cn:
        idx = row_text.find(biz_type_cn)
        before = row_text[:idx].strip()
    elif status_cn:
        idx = row_text.find(status_cn)
        before = row_text[:idx].strip()
    else:
        return None
    
    # The "before" part has: name_cn + location_cn
    # Try to split by known city/location patterns
    # Location is typically 2-8 chars at the end before biz_type
    location_patterns = [
        r'(北京\S{1,6}|天津\S{1,6}|上海\S{1,6}|深圳\S{1,6}|广州\S{1,6}|沈阳\S{1,6}|'
        r'大连\S{1,6}|长春\S{1,6}|哈尔滨\S{1,6}|青岛\S{1,6}|烟台\S{1,6}|济南\S{1,6}|'
        r'日照\S{1,6}|太原\S{1,6}|保定\S{1,6}|雄安\S{1,6}|徐州\S{1,6}|南通\S{1,6}|'
        r'苏州\S{1,6}|无锡\S{1,6}|太仓\S{1,6}|南京\S{1,6}|杭州\S{1,6}|宁波\S{1,6}|'
        r'绍兴\S{1,6}|温州\S{1,6}|台州\S{1,6}|嘉兴\S{1,6}|合肥\S{1,6}|郑州\S{1,6}|'
        r'武汉\S{1,6}|长沙\S{1,6}|成都\S{1,6}|重庆\S{1,6}|西安\S{1,6}|贵阳\S{1,6}|'
        r'昆明\S{1,6}|南宁\S{1,6}|海口\S{1,6}|三亚\S{1,6}|'
        r'漳州\S{1,6}|厦门\S{1,6}|福州\S{1,6}|泉州\S{1,6}|珠海\S{1,6}|佛山\S{1,6}|'
        r'东莞\S{1,6}|惠州\S{1,6}|湛江\S{1,6}|慈溪\S{1,6}|慈溪\S{1,6})'
    ]
    
    location_cn = ''
    name_cn = before
    
    loc_re = re.compile('|'.join(location_patterns))
    all_locs = list(loc_re.finditer(before))
    if all_locs:
        # Use the LAST match as the location (it's at the end)
        last_match = all_locs[-1]
        location_cn = last_match.group(0)
        name_cn = before[:last_match.start()].strip()
    
    # Clean name
    name_cn = re.sub(r'\s+', '', name_cn).strip()
    name_cn = name_cn.replace('*', '').strip()
    
    # Filter obvious non-project names
    if len(name_cn) < 2 or not any('\u4e00' <= c <= '\u9fff' for c in name_cn):
        return None
    
    return {
        'seq': seq,
        'name_cn': name_cn,
        'location_cn': location_cn,
        'biz_type_cn': biz_type_cn,
        'status_cn': status_cn,
    }


if __name__ == '__main__':
    print("Extracting PDF text from project table pages...")
    text = extract_project_pages(PDF_PATH)
    
    # Save raw text
    with open(rf"{TEMP_DIR}\cmsk_table_text.txt", 'w', encoding='utf-8') as f:
        f.write(text)
    print(f"Saved raw text: {len(text)} chars")
    
    # Parse project rows
    print("\nParsing project rows...")
    projects = parse_project_rows(text)
    print(f"Found {len(projects)} unique projects")
    
    # Save to JSON
    with open(rf"{TEMP_DIR}\cmsk_projects_parsed.json", 'w', encoding='utf-8') as f:
        json.dump(projects, f, ensure_ascii=False, indent=2)
    
    print("\nFirst 10 projects:")
    for p in projects[:10]:
        print(f"  [{p['seq']}] {p['name_cn']} | {p['location_cn']} | {p['biz_type_cn']} | {p['status_cn']}")
    
    print(f"\nTotal: {len(projects)} projects")
