"""Check finished rows before building the report.
usage: python validate.py row_queue.csv sec_master_20260828.parquet  -> prints problems, writes validation_issues.csv"""
import sys, pandas as pd, helpers as H
qf, smf = sys.argv[1:3]; H.load(smf)
q = pd.read_csv(qf, dtype=str, keep_default_na=False, encoding='utf-8-sig')
d = q[q.CHECK_STATUS == 'DONE']
VERD = {'CORRECT','URL_CORRECTION_ONLY','CORRECT_BETTER_MATCH','WRONG_REMAP','WRONG_OWNER_NOT_IN_DMX','OUT_OF_SCOPE_DROP','LIFECYCLE_DIVESTED','RECOLLECT'}
NEEDS_SUGG = {'CORRECT_BETTER_MATCH','WRONG_REMAP'}
iss = []
def add(r, msg): iss.append((r.FACILITY_ID, r.ISSUER_ID, r.EVAL_VERDICT, msg))
for _, r in d.iterrows():
    v, s = r.EVAL_VERDICT, r.EVAL_SUGGESTED_ISSUER_ID
    if v not in VERD: add(r, 'invalid verdict'); continue
    if v in NEEDS_SUGG and not s: add(r, 'verdict needs EVAL_SUGGESTED_ISSUER_ID')
    if s and s not in H.SM.index: add(r, 'suggested ID not in secmaster')
    if s and s == r.ISSUER_ID: add(r, 'suggested ID equals current issuer')
    if s and H.same_url_parent(s): add(r, f'same-URL rule: suggested child shares URL with parent {H.climb_same_url(s)} -> use parent')
    if not r.EVAL_REASON: add(r, 'missing EVAL_REASON')
    if v in ('CORRECT','CORRECT_BETTER_MATCH','WRONG_REMAP','WRONG_OWNER_NOT_IN_DMX','LIFECYCLE_DIVESTED') and not r.EVIDENCE_URL: add(r, 'missing EVIDENCE_URL')
    if v == 'URL_CORRECTION_ONLY' and not r.CORRECTED_URL: add(r, 'URL_CORRECTION_ONLY needs CORRECTED_URL')
    if v == 'CORRECT' and H.homepage_generic(r.FACILITY_NAME, r.RELEVANT_URL) and not r.CORRECTED_URL: add(r, 'homepage-only numbered name marked CORRECT (rule D16 -> RECOLLECT unless a specific page is found)')
    if len(r.EVIDENCE_EXTRACT.split()) > 25: add(r, 'EVIDENCE_EXTRACT longer than 25 words')
x = pd.DataFrame(iss, columns=['FACILITY_ID','ISSUER_ID','EVAL_VERDICT','ISSUE'])
x.to_csv('validation_issues.csv', index=False, encoding='utf-8-sig')
print(f'DONE rows: {len(d)}  issues: {len(x)}'); print(x.ISSUE.value_counts().to_string() if len(x) else 'clean')
