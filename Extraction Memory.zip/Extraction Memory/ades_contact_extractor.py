"""
ADES contact-page extractor for the batch run.

Builds the official regional-office output from the company contact page.
"""

from __future__ import annotations

import csv
from pathlib import Path


ISSUER_ID = "IID000000005119265"
ISSUER_NAME = "ADES Holding Company Listed Joint Stock Company"
SOURCE_URL = "https://adesgroup.com/contact-us/"
FLEET_URL = "https://adesgroup.com/our-fleet/onshore-fleet/"
OUTPUT_CSV = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output\Extraction_Batch_20260410_123343\IID000000005119265_ADES Holding Company Listed Joint Stock Company.csv"
)

HEADERS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
]


def row(name: str, address: str, country: str, iso3: str, postcode: str, state: str, city: str) -> dict:
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": name,
        "LOCATION_ADDRESS": address,
        "LATITUDE": "",
        "LONGITUDE": "",
        "COUNTRY": country,
        "COUNTRY_ISO3": iso3,
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": SOURCE_URL,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Regional office",
        "coord_source": "Not from website",
    }


def custom_row(
    name: str,
    address: str,
    country: str,
    iso3: str,
    postcode: str,
    state: str,
    city: str,
    source_url: str,
    activity: str,
) -> dict:
    data = row(name, address, country, iso3, postcode, state, city)
    data["SOURCE_URL"] = source_url
    data["ACTIVITY_AT_ASSET"] = activity
    return data


ROWS = [
    row("Headquarter: Saudi Arabia", "Al Zamil House, 7429 Prince Turki Road, Al Corniche, Al Khobar, Kingdom of Saudi Arabia", "Saudi Arabia", "SAU", "", "Eastern Province", "Al Khobar"),
    row("Saudi Arabia", "Juffali Building, King Fahad Road, Al Bandariyah 34423, Postal Code 3605 - 34232, Al Khobar, Saudi Arabia", "Saudi Arabia", "SAU", "34232", "Eastern Province", "Al Khobar"),
    row("Egypt", "B5, Capital Business Park, Al Sheikh Zayed, Giza, Egypt", "Egypt", "EGY", "", "Giza Governorate", "Giza"),
    row("Kuwait", "Block 8, Plot 144, East Ahmadi, P.O. Box 9282, 61003 Ahmadi, Kuwait", "Kuwait", "KWT", "61003", "Al Ahmadi Governorate", "Ahmadi"),
    row("Qatar", "Al-Jazeera Tower, 24th floor, Unit 2403, Conference Center Street, Zone 61, Al Dafna, P.O. Box 18577, West Bay, Doha, Qatar", "Qatar", "QAT", "", "Doha Municipality", "Doha"),
    row("United Arab Emirates", "Office 1301-A, North Tower, Emirates Financial Towers, DIFC, Dubai, UAE", "United Arab Emirates", "ARE", "", "Dubai", "Dubai"),
    row("India", "ADES, Unit no. A-403, 4th Floor, Kanakia Wallstreet, A.K. Road, Chakala, Andheri (East), Mumbai 400093, India", "India", "IND", "400093", "Maharashtra", "Mumbai"),
    row("Algeria", "Base Irara, Route de In Amenas, 30500, Hassi Messaoud, Algeria", "Algeria", "DZA", "30500", "Ouargla", "Hassi Messaoud"),
    row("Tunisia", "IMM. Horizon, Imp. du lac Maracaibo Bloc B App. 22, Les Berges du lac, 1053 Tunis, Tunisia", "Tunisia", "TUN", "1053", "Tunis Governorate", "Tunis"),
    row("Indonesia", "Millennium Centennial Center, 2nd floor unit D158, Jl. Jend. Sudirman, Jakarta, Indonesia", "Indonesia", "IDN", "", "Jakarta", "Jakarta"),
    row("Thailand", "555 Rasa Tower Building B, 14th Floor, Unit No. 1406, Phaholyothin Road, Chatuchak, Bangkok 10900, Thailand", "Thailand", "THA", "10900", "Bangkok", "Bangkok"),
    custom_row(
        "ADES 882",
        "Block 8, Plot 144, East Ahmadi, P.O. Box 9282, 61003 Ahmadi, Kuwait",
        "Kuwait",
        "KWT",
        "61003",
        "Al Ahmadi Governorate",
        "Ahmadi",
        FLEET_URL,
        "Onshore rig",
    ),
]


def main() -> None:
    OUTPUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT_CSV.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=HEADERS)
        writer.writeheader()
        writer.writerows(ROWS)
    print(f"Wrote {len(ROWS)} rows to {OUTPUT_CSV}")


if __name__ == "__main__":
    main()
