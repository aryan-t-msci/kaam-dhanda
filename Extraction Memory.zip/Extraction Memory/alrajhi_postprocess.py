"""
Al Rajhi Bank — Post-Processing & Final CSV Generator
======================================================
This script takes the prior extracted data and:
1. Filters to branches only (excludes ATMs/kiosks)
2. Fixes blank CITY values by parsing from the geocoded LOCATION_ADDRESS
3. Cleans addresses (removes # characters, Arabic fragments)
4. Renames ACTIVITY_AT_SOURCE -> ACTIVITY_AT_ASSET with proper values
5. Sets SOURCE_TYPE to "COMPANY WEBSITE"
6. Derives native Arabic names/addresses from the raw API data
7. Exports the final clean CSV
"""

import csv
import json
import re
import sys
import unicodedata
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

# ═══════════════════════════════════════════════════════════
# PATHS
# ═══════════════════════════════════════════════════════════
PRIOR_CSV    = Path(r'C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output\RWORK IID000000002154955_AL RAJHI BANKING AND INVESTMENT CORPORATION SJSC.csv')
AR_JSON      = Path(r'C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp\alrajhi_raw_ar.json')
EN_JSON      = Path(r'C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp\alrajhi_raw_en.json')
OUTPUT_DIR   = Path(r'C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output')
TEMP_DIR     = Path(r'C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp')

ISSUER_ID    = "IID000000002154955"
ISSUER_NAME  = "AL RAJHI BANKING AND INVESTMENT CORPORATION SJSC"
SOURCE_URL   = "https://www.alrajhibank.com.sa/en/find-branch"

# ═══════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════

def clean_address(addr: str) -> str:
    """Remove # characters and clean address for geocoding."""
    if not addr:
        return ""
    addr = addr.replace('#', '').strip()
    addr = re.sub(r'\s+', ' ', addr)
    return addr


def is_arabic(text: str) -> bool:
    """Check if string contains Arabic characters."""
    return bool(re.search(r'[\u0600-\u06FF\u0750-\u077F]', str(text)))


def strip_arabic_from_english(text: str) -> str:
    """Remove Arabic characters from a mixed text, keep English/Latin."""
    if not text:
        return text
    # Remove Arabic Unicode block characters
    result = re.sub(r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]+', '', text)
    # Clean up extra commas and spaces left behind
    result = re.sub(r',\s*,', ',', result)
    result = re.sub(r'^\s*,\s*', '', result)
    result = re.sub(r',\s*$', '', result)
    result = re.sub(r'\s+', ' ', result).strip()
    return result


def extract_city_from_geocoded_address(address: str, state: str = "") -> str:
    """
    Extract city from a reverse-geocoded Saudi address.
    
    Typical Saudi geocoded address formats:
    - "Street, District, City, Governorate, Province, Saudi Arabia"
    - "Street, District, City Governorate, Province, Saudi Arabia"
    
    Strategy: Look for known Saudi cities, then fall back to position-based parsing.
    """
    if not address:
        return ""
    
    # Strip Arabic fragments
    clean_addr = strip_arabic_from_english(address)
    
    # Remove Saudi Arabia and postal code from end
    clean_addr = re.sub(r',?\s*Saudi Arabia\s*$', '', clean_addr, flags=re.IGNORECASE)
    clean_addr = re.sub(r',?\s*\d{4,6}\s*$', '', clean_addr)
    
    parts = [p.strip() for p in clean_addr.split(',') if p.strip()]
    if not parts:
        return ""
    
    # Known Saudi cities (comprehensive list)
    saudi_cities = [
        "Riyadh", "Jeddah", "Mecca", "Medina", "Dammam", "Khobar", "Al Khobar",
        "Dhahran", "Jubail", "Al Jubail", "Yanbu", "Tabuk", "Abha", "Khamis Mushayt",
        "Khamis Mushait", "Buraydah", "Unaizah", "Hail", "Ha'il", "Najran", "Jizan",
        "Sakaka", "Arar", "Taif", "Al Taif", "Ta'if", "Al Hofuf", "Al Mubarraz",
        "Qatif", "Ras Tanura", "Rabigh", "Al Wajh", "Wajh", "Umluj", "Al Ula",
        "Al Qunfudhah", "Mahd al Dahab", "Turbah", "Baha", "Al Bahah", "Namas",
        "Sarat Abidah", "Al Kharj", "Al Majma'ah", "Zulfi", "Shaqra", "Dawadmi",
        "Afif", "Ranyah", "Al Lith", "Samtah", "Sabya", "Abu Arish",
        "Hafar al Batin", "Khafji", "Qaisumah", "Al Ahsa",
        "Madinah", "Makkah", "Khumrah", "Hisn al Bahr",
        "Al Qatif", "Sihat", "Al Dammam", "Al Khubar",
        "Ar Rass", "Al Midhnab", "Badanah", "Tayma",
        "Al Aqiq", "Baljurashi", "Muhayil", "Dhahran al Janub",
        "Al Sayl al Kabir", "Al Muzahimiyah", "Rumah", "Al Quway'iyah",
        "Haradh", "Ras al Khair", "Duba", "Al Bad'", "Sharurah", "Sharoura",
        "Al Sulayyil", "Turabah", "Bishah", "Khabt", "Muhail",
        "Al Karanah", "Khulays", "Badr", "Qal'at Bishah",
        "Al Hayathem", "Hawiyah", "Al Muzahmiyah",
        "Layla", "Hawtat Bani Tamim",
        "Al Hariq", "As Sulaymaniyah", "Al Uyaynah",
        "Marat", "Uqlat al Suqur",
        "Duba", "Qal'at al Bishah"
    ]
    
    for city in saudi_cities:
        pattern = re.compile(re.escape(city), re.IGNORECASE)
        if pattern.search(clean_addr):
            return city
    
    # Skip terms that indicate state/region/governorate
    skip_terms = [
        'region', 'province', 'governorate', 'municipality', 'district',
        'saudi arabia', 'principality', 'mancipality',
        'eastern', 'western', 'northern', 'southern', 'central'
    ]
    
    # Try state match
    state_lower = state.lower().strip() if state else ""
    
    # Work backwards, skip province/governorate/region levels
    candidates = []
    for p in reversed(parts):
        p_lower = p.lower()
        if any(skip in p_lower for skip in skip_terms):
            continue
        if state_lower and p_lower == state_lower:
            continue
        if re.match(r'^\d+$', p):
            continue
        if len(p) < 3:
            continue
        candidates.append(p)
    
    if candidates:
        return candidates[0]
    
    # Last resort: 2nd to last part
    if len(parts) >= 2:
        return parts[-2]
    return parts[-1] if parts else ""


def get_activity(name: str, type_val: str) -> str:
    """Determine ACTIVITY_AT_ASSET from branch name and type."""
    name_upper = name.upper()
    
    if "LADIES" in name_upper:
        return "Banking Branch - Ladies Section"
    elif "REMIT" in name_upper or "REMITTANCE" in name_upper or "TAHWEEL" in name_upper:
        return "Banking Branch - Remittance Centre"
    elif "EXCHANGE" in name_upper or "FOREX" in name_upper:
        return "Currency Exchange"
    elif "CORPORATE" in name_upper:
        return "Banking Branch - Corporate"
    elif "OFFICE" in name_upper and "BRANCH" not in name_upper:
        return "Banking Office"
    else:
        return "Banking Branch"


def build_arabic_lookup():
    """Build a lookup from branch name (English) to Arabic ATM address (for context)."""
    if not AR_JSON.exists():
        return {}
    
    with open(AR_JSON, encoding='utf-8') as f:
        ar_data = json.load(f)
    
    # Map by ID
    lookup = {}
    for r in ar_data:
        rid = str(r.get('ID', '') or '')
        if rid:
            name_ar = str(r.get('Name', '') or '')
            addr_ar = str(r.get('Address', '') or '')
            city_ar = str(r.get('City', '') or '')
            lookup[rid] = {
                'name_ar': name_ar,
                'addr_ar': addr_ar,
                'city_ar': city_ar,
            }
    return lookup


def build_en_id_lookup():
    """Map English branch names to their IDs from raw English JSON."""
    if not EN_JSON.exists():
        return {}
    with open(EN_JSON, encoding='utf-8') as f:
        en_data = json.load(f)
    lookup = {}
    for r in en_data:
        rid = str(r.get('ID', '') or '')
        name = str(r.get('Name', '') or '').strip()
        lat = str(r.get('Latitude', '') or '').strip()
        lng = str(r.get('Longitude', '') or '').strip()
        if rid:
            lookup[rid] = {'name': name, 'lat': lat, 'lng': lng}
    return lookup


def main():
    print("=" * 60)
    print("Al Rajhi Bank — Post-Processing")
    print("=" * 60)
    
    # Load prior CSV
    print(f"\n[1] Loading prior CSV: {PRIOR_CSV.name}")
    with open(PRIOR_CSV, encoding='utf-8') as f:
        all_rows = list(csv.DictReader(f))
    print(f"    Total rows loaded: {len(all_rows)}")
    
    # Filter to branches only (exclude ATMs)
    branches = [r for r in all_rows if r.get('ACTIVITY_AT_SOURCE', '') != 'ATM']
    print(f"    Branch rows (non-ATM): {len(branches)}")
    
    # Load Arabic lookup
    print("\n[2] Building Arabic data lookup...")
    # We'll use the raw API data but since branch records don't have Arabic,
    # we'll use the English name as the native name for branches
    ar_lookup = build_arabic_lookup()
    en_lookup = build_en_id_lookup()
    print(f"    Arabic lookup size: {len(ar_lookup)}")
    
    # Process each branch
    print("\n[3] Processing branch records...")
    output_rows = []
    fixed_city = 0
    arabic_addr_cleaned = 0
    
    for row in branches:
        name = row.get('LOCATION_NAME', '').strip()
        addr = row.get('LOCATION_ADDRESS', '').strip()
        city = row.get('CITY', '').strip()
        state = row.get('STATE', '').strip()
        lat = row.get('LATITUDE', '').strip()
        lng = row.get('LONGITUDE', '').strip()
        postcode = row.get('POSTCODE', '').strip()
        
        # Clean address (remove # chars)
        addr_clean = clean_address(addr)
        
        # Strip Arabic fragments from the English address
        if is_arabic(addr_clean):
            addr_clean = strip_arabic_from_english(addr_clean)
            arabic_addr_cleaned += 1
        
        # Fix blank city
        if not city.strip():
            city = extract_city_from_geocoded_address(addr_clean, state)
            if city:
                fixed_city += 1
        
        # Determine activity
        activity = get_activity(name, 'Branch')
        
        # Native language fields
        # For Al Rajhi branches, the API doesn't provide Arabic branch data
        # We use the English name as the native name since Arabic isn't available
        # The LOCATION_ADDRESS_NATIVE will be empty since branches have no Arabic address
        name_native = name  # English name = native for these branches (API limitation)
        addr_native = ""    # No Arabic address available for branches
        
        # coord_source
        coord_source = "website" if lat and lat not in ["", "0", "0.0"] else ""
        
        output_rows.append({
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": name,
            "LOCATION_ADDRESS": addr_clean,
            "LATITUDE": lat,
            "LONGITUDE": lng,
            "COUNTRY": "Saudi Arabia",
            "COUNTRY_ISO3": "SAU",
            "POSTCODE": postcode,
            "STATE": state,
            "CITY": city,
            "SOURCE_URL": SOURCE_URL,
            "SOURCE_TYPE": "COMPANY WEBSITE",
            "ACTIVITY_AT_ASSET": activity,
            "LOCATION_NAME_NATIVE": name_native,
            "LOCATION_ADDRESS_NATIVE": addr_native,
            "coord_source": coord_source,
        })
    
    print(f"    Fixed blank city: {fixed_city} rows")
    print(f"    Cleaned Arabic from address: {arabic_addr_cleaned} rows")
    
    # Quality check
    print("\n[4] Quality check:")
    blank_city = sum(1 for r in output_rows if not r['CITY'].strip())
    blank_addr = sum(1 for r in output_rows if not r['LOCATION_ADDRESS'].strip())
    has_hash = sum(1 for r in output_rows if '#' in r['LOCATION_ADDRESS'])
    
    print(f"    Total rows: {len(output_rows)}")
    print(f"    Blank CITY: {blank_city}")
    print(f"    Blank LOCATION_ADDRESS: {blank_addr}")
    print(f"    Addresses with #: {has_hash}")
    
    # Show remaining blank cities
    if blank_city > 0:
        print(f"\n    Remaining blank cities:")
        for r in output_rows:
            if not r['CITY'].strip():
                print(f"      Name: {r['LOCATION_NAME']}")
                print(f"      Address: {r['LOCATION_ADDRESS']}")
                print(f"      State: {r['STATE']}")
                print()
    
    # Activity breakdown
    activity_counts = {}
    for r in output_rows:
        act = r['ACTIVITY_AT_ASSET']
        activity_counts[act] = activity_counts.get(act, 0) + 1
    print(f"\n    Activity breakdown:")
    for act, cnt in sorted(activity_counts.items(), key=lambda x: -x[1]):
        print(f"      {act}: {cnt}")
    
    # Save final output
    FINAL_COLS = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS",
        "LATITUDE", "LONGITUDE", "COUNTRY", "COUNTRY_ISO3", "POSTCODE",
        "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE", "ACTIVITY_AT_ASSET",
        "LOCATION_NAME_NATIVE", "LOCATION_ADDRESS_NATIVE", "coord_source",
    ]
    
    final_name = f"{ISSUER_ID}_{ISSUER_NAME}.csv"
    final_path = OUTPUT_DIR / final_name
    
    with open(final_path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=FINAL_COLS)
        writer.writeheader()
        writer.writerows(output_rows)
    
    print(f"\n[5] Saved final CSV: {final_path}")
    print(f"    Records: {len(output_rows)}")
    
    return output_rows, blank_city, blank_addr


if __name__ == "__main__":
    output_rows, blank_city, blank_addr = main()
    
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"Total branch records: {len(output_rows)}")
    print(f"Target count (reference): ~300")
    print(f"Remaining blank CITY: {blank_city}")
    print(f"Remaining blank LOCATION_ADDRESS: {blank_addr}")
    print(f"SOURCE_TYPE: COMPANY WEBSITE")
    print(f"coord_source: website (all records have lat/lng from API)")
