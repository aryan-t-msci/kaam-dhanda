"""
Sitecore SXA search-results locator extractor with detail-page enrichment.

Pattern handled:
- Public Sitecore SXA locator pages that expose an `/sxa/search/results/` JSON endpoint.
- Result rows include linked detail pages with structured address HTML.
- Detail pages expose website coordinates through schema.org `GeoCoordinates`.

How to reuse:
- Update the configuration block only.
- Keep the generic SXA endpoint flow and detail-page selectors unchanged unless the
  target issuer uses a different Sitecore rendering pattern.

Usage:
    python sxa_search_results_center_extractor.py
"""

from __future__ import annotations

import csv
import json
import math
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from html import unescape
from pathlib import Path
from typing import Iterable
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


# =============================================================================
# CONFIGURATION - Edit this block for each new issuer
# =============================================================================
ISSUER_ID = "IID000000000000000"
ISSUER_NAME = "COMPANY NAME"
BASE_URL = "https://www.example.com"
LOCATOR_URL = f"{BASE_URL}/urgent-care-centers/"
CONTACT_URL = f"{BASE_URL}/contact-us/"
SEARCH_RESULTS_URL = (
    f"{BASE_URL}//sxa/search/results/"
    "?s=%7BSEARCH_SCOPE_ID%7D%7C%7BSEARCH_SCOPE_ID%7D"
    "&itemid=%7BSEARCH_ITEM_ID%7D"
    "&sig=&autoFireSearch=true&v=%7BRENDERING_VARIANT_ID%7D&p=1000"
)
WORK_DIR = Path(r"C:\path\to\issuer_temp_folder")
STAGING_CSV = Path(r"C:\path\to\staging\IID000000000000000_COMPANY NAME.csv")
CHECKPOINT_CSV = WORK_DIR / "checkpoint_rows.csv"
RAW_RESULTS_JSON = WORK_DIR / "search_results.json"
PROGRESS_JSON = WORK_DIR / "progress.json"
SUMMARY_JSON = WORK_DIR / "summary.json"
QA_DETAILS_JSON = WORK_DIR / "qa_details.json"
REJECTED_CSV = Path(r"C:\path\to\reject\IID000000000000000_COMPANY NAME_rejected.csv")
SAVE_EVERY = 20
DETAIL_WORKERS = 10
REQUEST_TIMEOUT = 30
DETAIL_RETRIES = 3
DETAIL_SLEEP_SECONDS = 0.1


# =============================================================================
# GENERIC EXTRACTION LOGIC - Do not modify per issuer
# =============================================================================
CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
]


@dataclass(frozen=True)
class SearchResult:
    result_id: str
    location_name: str
    address_line1: str
    city: str
    state: str
    postcode: str
    detail_url: str
    raw_html: str


def clean_text(value: str) -> str:
    value = unescape(value or "")
    value = value.replace("\xa0", " ")
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def clean_address(value: str) -> str:
    value = clean_text(value).replace("#", "")
    value = re.sub(r"\s+,", ",", value)
    return value.strip(" ,")


def write_csv(path: Path, rows: Iterable[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in CSV_COLUMNS})


def write_rejected_csv(path: Path, rows: list[dict[str, str]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = CSV_COLUMNS + ["rejection_reason", "rejected_by"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in fieldnames})


def build_browser() -> webdriver.Chrome:
    options = Options()
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)
    driver = webdriver.Chrome(options=options)
    driver.execute_cdp_cmd(
        "Page.addScriptToEvaluateOnNewDocument",
        {"source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"},
    )
    return driver


def seed_session_from_browser() -> tuple[str, dict[str, str]]:
    driver = build_browser()
    try:
        driver.get(LOCATOR_URL)
        time.sleep(8)
        user_agent = driver.execute_script("return navigator.userAgent;")
        cookies = {cookie["name"]: cookie["value"] for cookie in driver.get_cookies()}
        return user_agent, cookies
    finally:
        driver.quit()


def build_session(user_agent: str, cookies: dict[str, str]) -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": user_agent,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": LOCATOR_URL,
        }
    )
    for name, value in cookies.items():
        session.cookies.set(name, value, domain=".concentra.com", path="/")
    return session


def fetch_json(session: requests.Session, url: str) -> dict[str, object]:
    response = session.get(url, timeout=REQUEST_TIMEOUT)
    response.raise_for_status()
    return response.json()


def parse_result_html(result_id: str, detail_url: str, html: str) -> SearchResult:
    soup = BeautifulSoup(html, "html.parser")
    location_name = clean_text(soup.select_one(".field-centername").get_text(" ", strip=True))
    address_line1 = clean_address(
        soup.select_one(".field-addressline1").get_text(" ", strip=True)
    )
    city = clean_text(soup.select_one(".field-city").get_text(" ", strip=True))
    state = clean_text(soup.select_one(".field-stateabbreviation").get_text(" ", strip=True))
    postcode = clean_text(soup.select_one(".field-zipcode").get_text(" ", strip=True))
    return SearchResult(
        result_id=result_id,
        location_name=location_name,
        address_line1=address_line1,
        city=city,
        state=state,
        postcode=postcode,
        detail_url=detail_url,
        raw_html=html,
    )


def parse_activity(page_soup: BeautifulSoup, title_text: str) -> str:
    title_text = clean_text(title_text)
    if "urgent care" in title_text.lower():
        return "Urgent care center"
    meta_description = page_soup.find("meta", attrs={"name": "description"})
    if meta_description and meta_description.get("content"):
        description = clean_text(meta_description["content"])
        if "urgent care" in description.lower():
            return "Urgent care center"
        if "occupational" in description.lower():
            return "Occupational health center"
    return "Occupational health center"


def parse_detail_page(result: SearchResult, html: str) -> dict[str, str]:
    soup = BeautifulSoup(html, "html.parser")

    title_text = clean_text(soup.title.get_text(" ", strip=True)) if soup.title else ""
    latitude = ""
    longitude = ""
    geo = soup.select_one('[itemprop="geo"]')
    if geo:
        lat_meta = geo.select_one('meta[itemprop="latitude"]')
        lng_meta = geo.select_one('meta[itemprop="longitude"]')
        if lat_meta and lng_meta:
            latitude = clean_text(lat_meta.get("content", ""))
            longitude = clean_text(lng_meta.get("content", ""))

    if not latitude or not longitude:
        map_image = soup.select_one("img[data-latlong]")
        if map_image:
            lat_long = clean_text(map_image.get("data-latlong", ""))
            if "|" in lat_long:
                latitude, longitude = [clean_text(part) for part in lat_long.split("|", 1)]

    name = result.location_name
    h1 = soup.find("h1")
    if h1:
        possible_name = clean_text(h1.get_text(" ", strip=True))
        if possible_name and possible_name.lower() not in {"concentra", "urgent care"}:
            name = possible_name

    address_line1 = ""
    street = soup.select_one('[itemprop="streetAddress"]')
    if street:
        address_line1 = clean_address(street.get_text(" ", strip=True))
    if not address_line1:
        address_line1 = result.address_line1

    city = ""
    city_node = soup.select_one('[itemprop="addressLocality"]')
    if city_node:
        city = clean_text(city_node.get_text(" ", strip=True))
    if not city:
        city = result.city

    state = ""
    state_node = soup.select_one('[itemprop="addressRegion"]')
    if state_node:
        state = clean_text(state_node.get_text(" ", strip=True))
    if not state:
        state = result.state

    postcode = ""
    postcode_node = soup.select_one('[itemprop="postalCode"]')
    if postcode_node:
        postcode = clean_text(postcode_node.get_text(" ", strip=True))
    if not postcode:
        postcode = result.postcode

    location_address = ", ".join(part for part in [address_line1, f"{city}, {state} {postcode}".strip()] if part)
    location_address = clean_address(location_address)

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": name,
        "LOCATION_ADDRESS": location_address,
        "LATITUDE": latitude,
        "LONGITUDE": longitude,
        "COUNTRY": "United States",
        "COUNTRY_ISO3": "USA",
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": result.detail_url,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": parse_activity(soup, title_text),
        "coord_source": "website" if latitude and longitude else "Not from website",
        "QA_flag": "",
    }


def fetch_detail_html(session: requests.Session, url: str) -> str:
    last_error: Exception | None = None
    for attempt in range(DETAIL_RETRIES):
        try:
            response = session.get(url, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
            return response.text
        except Exception as exc:  # pragma: no cover - network retry
            last_error = exc
            time.sleep(1 + attempt)
    raise RuntimeError(f"Failed detail fetch for {url}: {last_error}") from last_error


def build_hq_row(session: requests.Session) -> dict[str, str]:
    response = session.get(CONTACT_URL, timeout=REQUEST_TIMEOUT)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    text = soup.get_text("\n", strip=True)
    match = re.search(
        r"Corporate Headquarters\s+([^\n]+)\s+([A-Za-z .'-]+,\s*[A-Z]{2}\s+\d{5}(?:-\d{4})?)",
        text,
    )
    if match:
        address_line1 = clean_address(match.group(1))
        city_line = clean_text(match.group(2))
    else:
        address_line1 = "5080 Spectrum Drive, Suite 1200W"
        city_line = "Addison, TX 75001"
    city_match = re.match(r"(?P<city>.+?),\s*(?P<state>[A-Z]{2})\s+(?P<postcode>\d{5}(?:-\d{4})?)", city_line)
    city = city_match.group("city") if city_match else "Addison"
    state = city_match.group("state") if city_match else "TX"
    postcode = city_match.group("postcode") if city_match else "75001"
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": "Concentra Corporate Headquarters",
        "LOCATION_ADDRESS": f"{address_line1}, {city_line}",
        "LATITUDE": "",
        "LONGITUDE": "",
        "COUNTRY": "United States",
        "COUNTRY_ISO3": "USA",
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": CONTACT_URL,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Corporate headquarters",
        "coord_source": "Not from website",
        "QA_flag": "",
    }


def validate_rows(rows: list[dict[str, str]]) -> tuple[list[dict[str, str]], list[dict[str, str]], dict[str, object]]:
    clean_rows: list[dict[str, str]] = []
    rejected_rows: list[dict[str, str]] = []
    tier_a_fixed: list[dict[str, object]] = []
    tier_b_flagged: list[dict[str, object]] = []
    semantic_flags: list[dict[str, object]] = []
    blank_mandatory_counts = {
        "LOCATION_NAME": 0,
        "LOCATION_ADDRESS": 0,
        "COUNTRY": 0,
        "COUNTRY_ISO3": 0,
        "CITY": 0,
        "ACTIVITY_AT_ASSET": 0,
        "SOURCE_URL": 0,
        "coord_source_violations": 0,
    }

    for index, row in enumerate(rows, start=1):
        row = dict(row)
        original_row = dict(row)
        if row["coord_source"] not in {"website", "Not from website"}:
            row["coord_source"] = "website" if row["LATITUDE"] and row["LONGITUDE"] else "Not from website"
            row["QA_flag"] = "fixed"
            tier_a_fixed.append(
                {
                    "row_index": index,
                    "location_name": row["LOCATION_NAME"],
                    "column": "coord_source",
                    "original_value": original_row["coord_source"],
                    "fixed_value": row["coord_source"],
                    "fix_reason": "Normalized coord_source to required enum.",
                }
            )

        if not row["ACTIVITY_AT_ASSET"]:
            row["ACTIVITY_AT_ASSET"] = "Occupational health center"
            row["QA_flag"] = "fixed"
            tier_a_fixed.append(
                {
                    "row_index": index,
                    "location_name": row["LOCATION_NAME"],
                    "column": "ACTIVITY_AT_ASSET",
                    "original_value": original_row["ACTIVITY_AT_ASSET"],
                    "fixed_value": row["ACTIVITY_AT_ASSET"],
                    "fix_reason": "Derived activity from issuer context.",
                }
            )

        if not row["LOCATION_NAME"]:
            row["LOCATION_NAME"] = f"Medical center - {row['CITY']}, {row['STATE']}".strip(" -,")
            row["QA_flag"] = "fixed"
            tier_a_fixed.append(
                {
                    "row_index": index,
                    "location_name": row["LOCATION_NAME"],
                    "column": "LOCATION_NAME",
                    "original_value": original_row["LOCATION_NAME"],
                    "fixed_value": row["LOCATION_NAME"],
                    "fix_reason": "Built descriptive name from city/state fallback.",
                }
            )

        row["LOCATION_ADDRESS"] = clean_address(row["LOCATION_ADDRESS"])

        missing_hard = False
        for column in [
            "LOCATION_NAME",
            "LOCATION_ADDRESS",
            "COUNTRY",
            "COUNTRY_ISO3",
            "CITY",
            "ACTIVITY_AT_ASSET",
            "SOURCE_URL",
        ]:
            if not clean_text(row[column]):
                blank_mandatory_counts[column] += 1
                missing_hard = True

        if row["coord_source"] not in {"website", "Not from website"}:
            blank_mandatory_counts["coord_source_violations"] += 1
            missing_hard = True

        suspicious_city_pattern = re.compile(r"\b(floor|suite|level|unit|po\.?\s*box)\b", re.I)
        if row["CITY"] and (
            re.match(r"^\d", row["CITY"])
            or suspicious_city_pattern.search(row["CITY"]) is not None
        ):
            semantic_flags.append(
                {
                    "row_index": index,
                    "location_name": row["LOCATION_NAME"],
                    "flag_code": "CITY_SUSPICIOUS",
                    "flagged_value": row["CITY"],
                    "column": "CITY",
                }
            )

        if missing_hard:
            reject_row = dict(row)
            reject_row["rejection_reason"] = "Missing mandatory structured fields"
            reject_row["rejected_by"] = "worker_qa"
            rejected_rows.append(reject_row)
            continue

        clean_rows.append(row)

    qa_details = {
        "tier_a_fixed": tier_a_fixed,
        "tier_b_flagged": tier_b_flagged,
        "tier_c_rejected": [
            {
                "row_index": idx,
                "raw_content": reject["LOCATION_ADDRESS"][:200],
                "rejection_reason": reject["rejection_reason"],
            }
            for idx, reject in enumerate(rejected_rows, start=1)
        ],
        "semantic_flags": semantic_flags,
        "blank_mandatory_counts": blank_mandatory_counts,
    }
    return clean_rows, rejected_rows, qa_details


def build_sample_indexes(total_rows: int, sample_size: int) -> list[int]:
    if sample_size >= total_rows:
        return list(range(total_rows))
    return sorted({min(total_rows - 1, math.floor(i * total_rows / sample_size)) for i in range(sample_size)})


def run_spot_check(rows: list[dict[str, str]]) -> dict[str, object]:
    total_rows = len(rows)
    sample_size = max(5, math.ceil(total_rows * 0.10)) if total_rows >= 5 else total_rows
    sample_indexes = build_sample_indexes(total_rows, sample_size)
    inspected = []
    clean_count = 0

    for index in sample_indexes:
        row = rows[index]
        checks = {
            "address_has_number": bool(re.search(r"\d", row["LOCATION_ADDRESS"])),
            "city_present": bool(row["CITY"]),
            "activity_present": bool(row["ACTIVITY_AT_ASSET"]),
            "coord_source_valid": row["coord_source"] in {"website", "Not from website"},
        }
        passed = all(checks.values())
        if passed:
            clean_count += 1
        inspected.append(
            {
                "row_index": index + 1,
                "location_name": row["LOCATION_NAME"],
                "source_url": row["SOURCE_URL"],
                "checks": checks,
                "passed": passed,
            }
        )

    return {
        "rows_total": total_rows,
        "rows_inspected": len(sample_indexes),
        "inspection_pct": round((len(sample_indexes) / total_rows) * 100, 2) if total_rows else 0,
        "clean_rows": clean_count,
        "method": "standard 10%",
        "samples": inspected,
    }


def write_progress(
    processed: int,
    total: int,
    rows: list[dict[str, str]],
    detail_failures: list[dict[str, str]],
    summary: dict[str, object],
) -> None:
    write_csv(CHECKPOINT_CSV, rows)
    PROGRESS_JSON.write_text(
        json.dumps(
            {
                "processed_detail_pages": processed,
                "total_detail_pages": total,
                "rows_found": len(rows),
                "detail_failures": detail_failures,
                **summary,
            },
            indent=2,
        ),
        encoding="utf-8",
    )


def main() -> None:
    WORK_DIR.mkdir(parents=True, exist_ok=True)

    user_agent, cookies = seed_session_from_browser()
    seed_session = build_session(user_agent, cookies)

    search_payload = fetch_json(seed_session, SEARCH_RESULTS_URL)
    RAW_RESULTS_JSON.write_text(json.dumps(search_payload, indent=2), encoding="utf-8")

    search_results: list[SearchResult] = []
    seen_urls: set[str] = set()
    for result in search_payload.get("Results", []):
        result_id = clean_text(result.get("Id", ""))
        detail_url = urljoin(BASE_URL, clean_text(result.get("Url", "")))
        if not detail_url or detail_url in seen_urls:
            continue
        seen_urls.add(detail_url)
        search_results.append(parse_result_html(result_id, detail_url, result.get("Html", "")))

    rows: list[dict[str, str]] = []
    detail_failures: list[dict[str, str]] = []
    lock = threading.Lock()
    processed = 0
    summary: dict[str, object] = {
        "locator_url": LOCATOR_URL,
        "search_endpoint": SEARCH_RESULTS_URL,
        "search_result_count": len(search_results),
        "search_reported_count": int(search_payload.get("Count", 0)),
        "hq_added": False,
    }

    def worker(result: SearchResult) -> dict[str, str]:
        session = build_session(user_agent, cookies)
        html = fetch_detail_html(session, result.detail_url)
        time.sleep(DETAIL_SLEEP_SECONDS)
        return parse_detail_page(result, html)

    with ThreadPoolExecutor(max_workers=DETAIL_WORKERS) as executor:
        future_map = {executor.submit(worker, result): result for result in search_results}
        for future in as_completed(future_map):
            result = future_map[future]
            try:
                row = future.result()
                rows.append(row)
            except Exception as exc:  # pragma: no cover - network retry accounting
                detail_failures.append(
                    {
                        "detail_url": result.detail_url,
                        "location_name": result.location_name,
                        "error": str(exc),
                    }
                )
            with lock:
                processed += 1
                if processed % SAVE_EVERY == 0:
                    write_progress(processed, len(search_results), rows, detail_failures, summary)

    hq_row = build_hq_row(seed_session)
    rows.append(hq_row)
    summary["hq_added"] = True

    deduped: dict[tuple[str, str, str], dict[str, str]] = {}
    for row in rows:
        key = (row["LOCATION_NAME"], row["LOCATION_ADDRESS"], row["SOURCE_URL"])
        deduped[key] = row

    final_rows = sorted(
        deduped.values(),
        key=lambda row: (
            row["STATE"],
            row["CITY"],
            row["LOCATION_NAME"],
            row["SOURCE_URL"],
        ),
    )
    clean_rows, rejected_rows, qa_details = validate_rows(final_rows)
    spot_check = run_spot_check(clean_rows)

    write_csv(STAGING_CSV, clean_rows)
    write_csv(CHECKPOINT_CSV, clean_rows)
    write_rejected_csv(REJECTED_CSV, rejected_rows)

    summary.update(
        {
            "final_rows": len(clean_rows),
            "rejected_rows": len(rejected_rows),
            "detail_failures": detail_failures,
            "spot_check": spot_check,
        }
    )
    SUMMARY_JSON.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    QA_DETAILS_JSON.write_text(
        json.dumps(
            {
                "rows_total": len(clean_rows),
                "rows_inspected": spot_check["rows_inspected"],
                "inspection_pct": spot_check["inspection_pct"],
                "full_page_scraper": False,
                **qa_details,
                "spot_check": spot_check,
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    print(
        json.dumps(
            {
                "rows_total": len(clean_rows),
                "rejected_rows": len(rejected_rows),
                "detail_failures": len(detail_failures),
                "rows_inspected": spot_check["rows_inspected"],
                "search_reported_count": search_payload.get("Count", 0),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
