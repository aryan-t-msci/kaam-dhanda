"""
Generalized mirrored prefecture/city store extractor.

Pattern:
- Official store-locator browse pages are country-blocked to direct worker HTTP.
- The same official pages remain readable through a text mirror such as r.jina.ai.
- A top-level prefecture page links to prefecture city pages, and each city page
  exposes structured markdown tables containing the store rows.

How to adapt for another issuer:
1. Update the configuration block with issuer metadata and the browse URLs.
2. Adjust the prefecture/city link regexes if the mirrored markdown uses a
   different browse structure.
3. Tune the activity heuristics and state parser for the local market.
"""

from __future__ import annotations

import csv
import json
import random
import re
import time
import unicodedata
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
from urllib.parse import quote, unquote, urljoin, urlparse

import requests
from pykakasi import kakasi
from unidecode import unidecode


# ============================================================================
# CONFIGURATION - Edit this block for each new issuer
# ============================================================================
ISSUER_ID = "IID000000002143781"
ISSUER_NAME = "KOMERI CO.,LTD."
BASE_URL = "https://www.komeri.com"
CRITERIA_URL = "https://www.komeri.com/shop/storeSearch/CriteriaInput.aspx"
SELECT_PREF_URL = "https://www.komeri.com/shop/storeSearch/SelectPref.aspx"
POWER_URL = "https://www.komeri.bit.or.jp/pw/store-search/"
PET_URL = "https://www.komeri.bit.or.jp/pw/pet-store-search/"
COUNT_THRESHOLD = 1270

MIRROR_PREFIX = "https://r.jina.ai/http://"
SOURCE_TYPE = "COMPANY WEBSITE"
COUNTRY = "Japan"
COUNTRY_ISO3 = "JPN"

BATCH_TEMP = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Run_asset_completeness_ondemand_batch7_8___straive_copy"
)
STAGING_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Run_asset_completeness_ondemand_batch7_8___straive_copy\staging"
)
REJECT_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Run_asset_completeness_ondemand_batch7_8___straive_copy\reject"
)
PROOF_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Run_asset_completeness_ondemand_batch7_8___straive_copy\exhaustion_proof"
)
OUTPUT_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Output\Run_asset_completeness_ondemand_batch7_8___straive_copy"
)
ISSUER_TEMP_DIR = BATCH_TEMP / f"{ISSUER_ID}_{ISSUER_NAME}"

REQUEST_TIMEOUT = 90
REQUEST_SLEEP_SECONDS = 1.0
MAX_RETRIES = 5
PROGRESS_SAVE_EVERY = 20
QA_SAMPLE_RATIO = 0.10

OUTPUT_BASENAME = f"{ISSUER_ID}_{ISSUER_NAME}"
STAGING_CSV = STAGING_DIR / f"{OUTPUT_BASENAME}.csv"
OUTPUT_CSV = OUTPUT_DIR / f"{OUTPUT_BASENAME}.csv"
CHECKPOINT_CSV = ISSUER_TEMP_DIR / f"{OUTPUT_BASENAME}_checkpoint.csv"
REJECT_CSV = REJECT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_rejected.csv"
PROGRESS_JSON = ISSUER_TEMP_DIR / f"{ISSUER_ID}_progress.json"
PARTIAL_ROWS_JSON = ISSUER_TEMP_DIR / f"{ISSUER_ID}_partial_rows.json"
SUMMARY_JSON = ISSUER_TEMP_DIR / f"{ISSUER_ID}_summary.json"
CRITERIA_MIRROR_TXT = ISSUER_TEMP_DIR / f"{ISSUER_ID}_criteria_mirror.txt"
SELECT_PREF_MIRROR_TXT = ISSUER_TEMP_DIR / f"{ISSUER_ID}_select_pref_mirror.txt"
POWER_MIRROR_TXT = ISSUER_TEMP_DIR / f"{ISSUER_ID}_power_mirror.txt"
PET_MIRROR_TXT = ISSUER_TEMP_DIR / f"{ISSUER_ID}_pet_mirror.txt"
CITY_URLS_JSON = ISSUER_TEMP_DIR / f"{ISSUER_ID}_city_urls.json"
PREF_URLS_JSON = ISSUER_TEMP_DIR / f"{ISSUER_ID}_pref_urls.json"
ROWS_JSON = ISSUER_TEMP_DIR / f"{ISSUER_ID}_rows.json"
PROOF_JSON = PROOF_DIR / f"{ISSUER_ID}_exhaustion_proof.json"
CACHE_DIR = ISSUER_TEMP_DIR / "mirror_cache"

CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS",
    "LOCATION_ADDRESS_NATIVE",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
    "VALIDATION_URL",
]

REJECT_COLUMNS = CSV_COLUMNS + ["rejection_reason", "rejected_by"]

PREFECTURE_MAP = {
    "北海道": "Hokkaido",
    "青森県": "Aomori",
    "岩手県": "Iwate",
    "宮城県": "Miyagi",
    "秋田県": "Akita",
    "山形県": "Yamagata",
    "福島県": "Fukushima",
    "茨城県": "Ibaraki",
    "栃木県": "Tochigi",
    "群馬県": "Gunma",
    "埼玉県": "Saitama",
    "千葉県": "Chiba",
    "東京都": "Tokyo",
    "神奈川県": "Kanagawa",
    "新潟県": "Niigata",
    "富山県": "Toyama",
    "石川県": "Ishikawa",
    "福井県": "Fukui",
    "山梨県": "Yamanashi",
    "長野県": "Nagano",
    "岐阜県": "Gifu",
    "静岡県": "Shizuoka",
    "愛知県": "Aichi",
    "三重県": "Mie",
    "滋賀県": "Shiga",
    "京都府": "Kyoto",
    "大阪府": "Osaka",
    "兵庫県": "Hyogo",
    "奈良県": "Nara",
    "和歌山県": "Wakayama",
    "鳥取県": "Tottori",
    "島根県": "Shimane",
    "岡山県": "Okayama",
    "広島県": "Hiroshima",
    "山口県": "Yamaguchi",
    "徳島県": "Tokushima",
    "香川県": "Kagawa",
    "愛媛県": "Ehime",
    "高知県": "Kochi",
    "福岡県": "Fukuoka",
    "佐賀県": "Saga",
    "長崎県": "Nagasaki",
    "熊本県": "Kumamoto",
    "大分県": "Oita",
    "宮崎県": "Miyazaki",
    "鹿児島県": "Kagoshima",
    "沖縄県": "Okinawa",
}

PREFECTURE_KEYS = sorted(PREFECTURE_MAP, key=len, reverse=True)

SERVICE_ACTIVITY_HINTS = (
    ("リフォーム", "Home renovation service office"),
    ("ペットアミ", "Pet store"),
    ("アテーナ", "Home goods retail store"),
    ("PRO", "Building materials and professional supplies store"),
    ("資材館", "Building materials and professional supplies store"),
    ("パワー", "Home improvement retail store"),
    ("ハード＆グリーン", "Home improvement retail store"),
    ("ハード&グリーン", "Home improvement retail store"),
)

BRAND_REPLACEMENTS = (
    ("コメリパワー", "Komeri Power"),
    ("コメリハード＆グリーン", "Komeri Hard & Green"),
    ("コメリハード&グリーン", "Komeri Hard & Green"),
    ("コメリPRO", "Komeri PRO"),
    ("コメリリフォーム", "Komeri Reform"),
    ("ペットアミ", "Pet Ami"),
    ("アテーナ", "Athena"),
    ("資材館", "Materials Center"),
    ("店", " Store"),
    ("館", " Hall"),
)

SESSION = requests.Session()
SESSION.trust_env = False
KAKASI = kakasi()


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def write_json(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def load_json(path: Path, default):
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return default


def fetch_mirror(url: str, dump_path: Optional[Path] = None) -> str:
    ensure_dir(CACHE_DIR)
    cache_key = quote(url, safe="")
    cache_path = CACHE_DIR / f"{cache_key}.txt"
    if cache_path.exists():
        return cache_path.read_text(encoding="utf-8")
    mirror_url = f"{MIRROR_PREFIX}{url}"
    last_error: Optional[Exception] = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = SESSION.get(
                mirror_url,
                timeout=REQUEST_TIMEOUT,
                headers={"User-Agent": "Mozilla/5.0"},
            )
            response.raise_for_status()
            text = response.text
            cache_path.write_text(text, encoding="utf-8")
            if dump_path is not None and not dump_path.exists():
                dump_path.write_text(text, encoding="utf-8")
            time.sleep(REQUEST_SLEEP_SECONDS)
            return text
        except Exception as exc:  # pragma: no cover - network variability
            last_error = exc
            time.sleep(min(15.0 * attempt, 60.0))
    raise RuntimeError(f"Mirror fetch failed for {url}: {last_error}")


def ascii_cleanup(value: str) -> str:
    text = unicodedata.normalize("NFKC", value or "")
    text = text.replace("＆", "&").replace("　", " ")
    text = text.replace("’", "'").replace("–", "-").replace("—", "-")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def romanize_japanese(value: str) -> str:
    cleaned = ascii_cleanup(value)
    if not cleaned:
        return ""
    if cleaned.isascii():
        return cleaned
    parts: List[str] = []
    for token in KAKASI.convert(cleaned):
        chunk = token.get("hepburn") or token.get("passport") or token.get("kunrei") or token.get("orig") or ""
        parts.append(chunk)
    text = " ".join(parts)
    text = unidecode(text)
    text = ascii_cleanup(text)
    text = re.sub(r"\b1 choume\b", "1-chome", text, flags=re.I)
    text = re.sub(r"\b(\d+)\s*choume\b", r"\1-chome", text, flags=re.I)
    return text


def smart_title(text: str) -> str:
    words = []
    for token in text.split():
        if token.isupper() or any(ch.isdigit() for ch in token):
            words.append(token)
        else:
            words.append(token.capitalize())
    return " ".join(words)


def name_to_ascii(name_native: str) -> str:
    text = ascii_cleanup(name_native)
    for native, english in BRAND_REPLACEMENTS:
        text = text.replace(native, english)
    if not text.isascii():
        text = romanize_japanese(text)
    text = text.replace("StoreMaterials", "Store Materials")
    text = re.sub(r"\s+", " ", text).strip()
    return smart_title(text)


def address_to_ascii(address_native: str) -> str:
    text = ascii_cleanup(address_native)
    if not text.isascii():
        text = romanize_japanese(text)
    text = text.replace(" - ", "-")
    text = re.sub(r"\s+", " ", text).strip()
    return smart_title(text)


def parse_prefecture_city_from_heading(heading: str) -> Tuple[str, str]:
    cleaned = heading.replace("にある店舗一覧", "").strip()
    for native_pref in PREFECTURE_KEYS:
        if cleaned.startswith(native_pref):
            return native_pref, cleaned[len(native_pref) :].strip()
    return "", cleaned


def parse_city_from_address(address_native: str) -> str:
    address = ascii_cleanup(address_native)
    for native_pref in PREFECTURE_KEYS:
        if address.startswith(native_pref):
            address = address[len(native_pref) :].strip()
            break
    for pattern in (
        r"^(.+?市.+?区)",
        r"^(.+?郡.+?[町村])",
        r"^(.+?[市区町村])",
    ):
        match = re.match(pattern, address)
        if match:
            return match.group(1)
    return address[:40].strip()


def derive_activity(name_native: str) -> str:
    for marker, activity in SERVICE_ACTIVITY_HINTS:
        if marker in name_native:
            return activity
    return "Retail store"


def postcode_from_text(value: str) -> str:
    match = re.search(r"\b\d{3}-\d{4}\b", value)
    if match:
        return match.group(0).replace("-", "")
    return ""


def detail_id_from_url(detail_url: str) -> str:
    match = re.search(r"id=(\d+)", detail_url)
    return match.group(1) if match else ""


def canonical_row(row: Dict[str, str]) -> Dict[str, str]:
    out = {col: row.get(col, "") for col in CSV_COLUMNS}
    out["ISSUER_ID"] = ISSUER_ID
    out["ISSUER_NAME"] = ISSUER_NAME
    out["COUNTRY"] = COUNTRY
    out["COUNTRY_ISO3"] = COUNTRY_ISO3
    out["SOURCE_TYPE"] = SOURCE_TYPE
    out["coord_source"] = "Not from website"
    out["QA_flag"] = row.get("QA_flag", "")
    out["VALIDATION_URL"] = row.get("VALIDATION_URL", "")
    out["LATITUDE"] = row.get("LATITUDE", "")
    out["LONGITUDE"] = row.get("LONGITUDE", "")
    out["POSTCODE"] = row.get("POSTCODE", "")
    return out


def write_csv(path: Path, rows: Sequence[Dict[str, str]], columns: Sequence[str]) -> None:
    ensure_dir(path.parent)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(columns))
        writer.writeheader()
        writer.writerows(rows)


def save_progress(
    rows: Sequence[Dict[str, str]],
    processed_city_urls: Sequence[str],
    pending_city_urls: Sequence[str],
    checkpoint_written: bool,
) -> None:
    write_json(
        PROGRESS_JSON,
        {
            "updated_at": now_iso(),
            "processed_city_urls": list(processed_city_urls),
            "pending_city_urls": list(pending_city_urls),
            "row_count": len(rows),
            "checkpoint_written": checkpoint_written,
        },
    )
    write_json(PARTIAL_ROWS_JSON, rows)


def parse_prefecture_links(criteria_text: str) -> List[Dict[str, str]]:
    seen = set()
    links: List[Dict[str, str]] = []
    pattern = re.compile(
        r"\[(?P<label>[^\]]+)\]\((?P<url>https://www\.komeri\.com/shop/storeSearch/CtiySelect\.aspx\?p_code=\d+)\)"
    )
    for match in pattern.finditer(criteria_text):
        url = match.group("url")
        if url in seen:
            continue
        seen.add(url)
        label = match.group("label").strip()
        links.append({"prefecture_label": label, "url": url})
    return links


def parse_city_links(pref_text: str) -> List[Dict[str, str]]:
    seen = set()
    links: List[Dict[str, str]] = []
    pattern = re.compile(
        r"\[(?P<label>[^\]]+)\]\((?P<url>https://www\.komeri\.com/shop/storeSearch/StoreSelect\.aspx\?[^\)]*)\)"
    )
    for match in pattern.finditer(pref_text):
        url = match.group("url")
        if "a_name=" not in url or "p_code=" not in url:
            continue
        if url in seen:
            continue
        seen.add(url)
        links.append(
            {
                "city_label": match.group("label").strip(),
                "url": url,
            }
        )
    return links


def parse_city_page_rows(city_url: str, text: str) -> List[Dict[str, str]]:
    heading_match = re.search(r"##\s+(.+?)にある店舗一覧", text)
    heading = ascii_cleanup(heading_match.group(1)) if heading_match else ""
    pref_native, city_native_from_heading = parse_prefecture_city_from_heading(heading)
    state_ascii = PREFECTURE_MAP.get(pref_native, romanize_japanese(pref_native))
    rows: List[Dict[str, str]] = []
    sections = text.split("\n### ")
    for section in sections[1:]:
        name_raw, _, body = section.partition("\n")
        if "| 住所 |" not in body:
            continue
        lines = [line.rstrip() for line in body.splitlines()]
        table_lines: List[str] = []
        tail_lines: List[str] = []
        in_table = False
        for line in lines:
            if line.startswith("| "):
                in_table = True
                table_lines.append(line)
                continue
            if in_table:
                tail_lines.append(line)
        table_raw = "\n".join(table_lines)
        tail_raw = "\n".join(tail_lines)
        table_lines = [line.strip() for line in table_raw.strip().splitlines() if line.strip()]
        table: Dict[str, str] = {}
        for line in table_lines:
            if line.startswith("| ---"):
                continue
            cells = [cell.strip() for cell in line.strip("|").split("|")]
            if len(cells) >= 2:
                table[cells[0]] = cells[1]
        address_native = ascii_cleanup(table.get("住所", ""))
        if not address_native:
            continue
        phone = ascii_cleanup(table.get("電話番号", ""))
        detail_match = re.search(
            r"\[詳細を見る\]\((https://www\.komeri\.com/shop/storeSearch/storeDetail\.aspx\?id=\d+(?:&cmdStoreSearch=\d+)?)\)",
            tail_raw,
        )
        detail_url = detail_match.group(1) if detail_match else ""
        detail_id = detail_id_from_url(detail_url)
        city_native = city_native_from_heading or parse_city_from_address(address_native)
        postcode = postcode_from_text(address_native)
        rows.append(
            canonical_row(
                {
                    "LOCATION_NAME": name_to_ascii(name_raw),
                    "LOCATION_NAME_NATIVE": ascii_cleanup(name_raw),
                    "LOCATION_ADDRESS": address_to_ascii(address_native),
                    "LOCATION_ADDRESS_NATIVE": address_native,
                    "POSTCODE": postcode,
                    "STATE": state_ascii,
                    "CITY": smart_title(romanize_japanese(city_native)),
                    "SOURCE_URL": city_url,
                    "ACTIVITY_AT_ASSET": derive_activity(name_raw),
                    "VALIDATION_URL": "",
                    "_detail_url": detail_url,
                    "_detail_id": detail_id,
                    "_phone": phone,
                    "_state_native": pref_native,
                    "_city_native": city_native,
                }
            )
        )
    return rows


def row_key(row: Dict[str, str]) -> str:
    detail_id = row.get("_detail_id", "")
    if detail_id:
        return f"detail:{detail_id}"
    return "||".join(
        [
            row.get("LOCATION_NAME_NATIVE", ""),
            row.get("LOCATION_ADDRESS_NATIVE", ""),
            row.get("SOURCE_URL", ""),
        ]
    )


def validate_rows(rows: Iterable[Dict[str, str]]) -> Tuple[List[Dict[str, str]], List[Dict[str, str]]]:
    valid: List[Dict[str, str]] = []
    rejected: List[Dict[str, str]] = []
    seen = set()
    for row in rows:
        key = row_key(row)
        if key in seen:
            continue
        seen.add(key)
        reason = ""
        for field in (
            "LOCATION_NAME",
            "LOCATION_ADDRESS",
            "COUNTRY",
            "COUNTRY_ISO3",
            "CITY",
            "ACTIVITY_AT_ASSET",
            "SOURCE_URL",
            "SOURCE_TYPE",
            "coord_source",
        ):
            if not row.get(field):
                reason = f"missing_{field.lower()}"
                break
        if not reason and row.get("coord_source") not in {"website", "Not from website"}:
            reason = "invalid_coord_source"
        if not reason and row.get("LOCATION_ADDRESS", "").startswith("電話番号"):
            reason = "address_is_contact_text"
        if not reason and re.search(r"Compare|Shop Now|Menu|Search", row.get("ACTIVITY_AT_ASSET", ""), flags=re.I):
            reason = "activity_ui_junk"
        if reason:
            rejected_row = {col: row.get(col, "") for col in REJECT_COLUMNS}
            rejected_row["rejection_reason"] = reason
            rejected_row["rejected_by"] = "worker_qa"
            rejected.append(rejected_row)
            continue
        valid.append({col: row.get(col, "") for col in CSV_COLUMNS})
    valid.sort(key=lambda r: (r["STATE"], r["CITY"], r["LOCATION_NAME_NATIVE"], r["LOCATION_ADDRESS_NATIVE"]))
    return valid, rejected


def qa_sample(rows: Sequence[Dict[str, str]]) -> Dict[str, object]:
    total = len(rows)
    sample_size = total if total < 5 else max(5, int(round(total * QA_SAMPLE_RATIO)))
    sample_size = min(sample_size, total)
    step = max(1, total // sample_size) if sample_size else 1
    inspected = [rows[i] for i in range(0, total, step)][:sample_size]
    clean = 0
    flagged = 0
    for row in inspected:
        if (
            row["LOCATION_NAME"]
            and row["LOCATION_ADDRESS"]
            and row["CITY"]
            and row["ACTIVITY_AT_ASSET"]
            and row["coord_source"] == "Not from website"
        ):
            clean += 1
        else:
            flagged += 1
    return {
        "rows_inspected": len(inspected),
        "rows_total": total,
        "rows_clean": clean,
        "rows_flagged": flagged,
        "sample_keys": [
            {
                "location_name_native": row["LOCATION_NAME_NATIVE"],
                "address_native": row["LOCATION_ADDRESS_NATIVE"],
                "source_url": row["SOURCE_URL"],
            }
            for row in inspected[:20]
        ],
    }


def main() -> None:
    ensure_dir(ISSUER_TEMP_DIR)
    ensure_dir(STAGING_DIR)
    ensure_dir(REJECT_DIR)
    ensure_dir(PROOF_DIR)
    ensure_dir(OUTPUT_DIR)

    criteria_text = fetch_mirror(CRITERIA_URL, dump_path=CRITERIA_MIRROR_TXT)
    select_pref_text = fetch_mirror(SELECT_PREF_URL, dump_path=SELECT_PREF_MIRROR_TXT)
    power_text = fetch_mirror(POWER_URL, dump_path=POWER_MIRROR_TXT)
    pet_text = fetch_mirror(PET_URL, dump_path=PET_MIRROR_TXT)

    pref_links = parse_prefecture_links(criteria_text)
    if not pref_links:
        pref_links = parse_prefecture_links(select_pref_text)
    write_json(PREF_URLS_JSON, pref_links)

    processed_city_urls = set(load_json(PROGRESS_JSON, {}).get("processed_city_urls", []))
    stored_rows = load_json(PARTIAL_ROWS_JSON, [])
    rows_by_key: Dict[str, Dict[str, str]] = {row_key(row): row for row in stored_rows}
    checkpoint_written = bool(load_json(PROGRESS_JSON, {}).get("checkpoint_written", False))

    city_entries: List[Dict[str, str]] = []
    for pref in pref_links:
        pref_text = fetch_mirror(pref["url"])
        for city in parse_city_links(pref_text):
            city_entries.append(
                {
                    "prefecture_label": pref["prefecture_label"],
                    "city_label": city["city_label"],
                    "url": city["url"],
                }
            )
    write_json(CITY_URLS_JSON, city_entries)

    for index, city_entry in enumerate(city_entries, start=1):
        city_url = city_entry["url"]
        if city_url in processed_city_urls:
            continue
        city_text = fetch_mirror(city_url)
        city_rows = parse_city_page_rows(city_url, city_text)
        for row in city_rows:
            rows_by_key[row_key(row)] = row
        processed_city_urls.add(city_url)

        current_rows = list(rows_by_key.values())
        if not checkpoint_written and len(current_rows) >= COUNT_THRESHOLD:
            valid_rows, _ = validate_rows(current_rows)
            write_csv(CHECKPOINT_CSV, valid_rows, CSV_COLUMNS)
            checkpoint_written = True

        if index % PROGRESS_SAVE_EVERY == 0:
            pending_urls = [entry["url"] for entry in city_entries if entry["url"] not in processed_city_urls]
            save_progress(current_rows, sorted(processed_city_urls), pending_urls, checkpoint_written)

    all_rows = list(rows_by_key.values())
    valid_rows, rejected_rows = validate_rows(all_rows)
    write_json(ROWS_JSON, all_rows)
    save_progress(valid_rows, sorted(processed_city_urls), [], checkpoint_written)
    write_csv(STAGING_CSV, valid_rows, CSV_COLUMNS)
    write_csv(OUTPUT_CSV, valid_rows, CSV_COLUMNS)
    if rejected_rows:
        write_csv(REJECT_CSV, rejected_rows, REJECT_COLUMNS)

    power_detail_ids = sorted(set(re.findall(r"storeDetail\.aspx\?id=(\d+)", power_text, flags=re.I)))
    pet_detail_ids = sorted(set(re.findall(r"storeDetail\.aspx\?id=(\d+)", pet_text, flags=re.I)))
    extracted_detail_ids = sorted(
        {
            row.get("_detail_id", "")
            for row in all_rows
            if row.get("_detail_id", "")
        }
    )
    extracted_detail_id_set = set(extracted_detail_ids)

    qa = qa_sample(valid_rows)
    proof = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "target_count": COUNT_THRESHOLD,
        "achieved_count": len(valid_rows),
        "gap": max(COUNT_THRESHOLD - len(valid_rows), 0),
        "completed_at": now_iso(),
        "root_cause": None if len(valid_rows) >= COUNT_THRESHOLD else "Official mirrored city-page crawl exhausted but produced fewer rows than the reference estimate.",
        "tiers_attempted": {
            "tier1": {
                "attempted": True,
                "outcome": "Official mirrored browse pages fully enumerated via SelectPref -> CtiySelect -> StoreSelect.",
                "prefecture_pages": len(pref_links),
                "city_pages": len(city_entries),
                "rows_found": len(valid_rows),
            },
            "tier2": {
                "attempted": True,
                "outcome": "Official Komeri Power and Pet Ami pages checked as alternative official pages.",
                "power_detail_ids": len(power_detail_ids),
                "pet_detail_ids": len(pet_detail_ids),
                "power_ids_missing_from_city_crawl": len([x for x in power_detail_ids if x not in extracted_detail_id_set]),
                "pet_ids_missing_from_city_crawl": len([x for x in pet_detail_ids if x not in extracted_detail_id_set]),
                "rows_found": len(valid_rows),
            },
            "tier3": {
                "attempted": False,
                "outcome": "Not required after exhausting official locator sources.",
                "rows_found": 0,
            },
            "tier4": {
                "attempted": False,
                "outcome": "Not required after exhausting official locator sources.",
                "rows_found": 0,
            },
            "tier5": {
                "attempted": False,
                "outcome": "Not required after mirrored official pages succeeded.",
                "rows_found": 0,
            },
        },
        "qa": qa,
    }
    write_json(PROOF_JSON, proof)

    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "prefecture_pages": len(pref_links),
        "city_pages": len(city_entries),
        "rows_total_raw": len(all_rows),
        "rows_total_valid": len(valid_rows),
        "rows_rejected": len(rejected_rows),
        "checkpoint_written": checkpoint_written,
        "power_detail_ids": len(power_detail_ids),
        "pet_detail_ids": len(pet_detail_ids),
        "power_ids_missing_from_city_crawl": len([x for x in power_detail_ids if x not in extracted_detail_id_set]),
        "pet_ids_missing_from_city_crawl": len([x for x in pet_detail_ids if x not in extracted_detail_id_set]),
        "qa": qa,
        "proof_json": str(PROOF_JSON),
        "staging_csv": str(STAGING_CSV),
    }
    write_json(SUMMARY_JSON, summary)

    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
