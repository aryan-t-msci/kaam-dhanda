"""
Chunghwa Telecom global-office extractor.

Collects overseas office/contact locations from the official Chunghwa Telecom
global pages. Category B reusable script pending broader parameterisation of the
page map and office selectors.
"""

from __future__ import annotations

import csv
import re
from pathlib import Path

import requests
from bs4 import BeautifulSoup


ISSUER_ID = "IID000000002162015"
ISSUER_NAME = "Chunghwa Telecom Co., Ltd."
OUTPUT_DIR = Path(".")
OUTPUT_CSV = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"

PAGES = [
    "https://www.cht.com.tw/home/chtweb/europe/EN/contact.html",
    "https://www.chtglobal.com/en/global/us/about-us",
    "https://www.cht.com.tw/global/sg",
]

HEADERS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
]


def emit_row(name: str, address: str, country: str, iso3: str, state: str, city: str, postcode: str, url: str) -> dict:
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": name,
        "LOCATION_ADDRESS": address,
        "LATITUDE": "",
        "LONGITUDE": "",
        "COUNTRY": country,
        "COUNTRY_ISO3": iso3,
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": url,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Telecommunications office",
        "coord_source": "Not from website",
    }


def parse_pages() -> list[dict]:
    rows: list[dict] = []
    for url in PAGES:
        html = requests.get(url, timeout=30, verify=False, headers={"User-Agent": "Mozilla/5.0"}).text
        text = BeautifulSoup(html, "html.parser").get_text("\n", strip=True)
        if "europe" in url.lower():
            rows.extend(parse_europe(text, url))
        elif "chtglobal" in url.lower():
            rows.extend(parse_us_page(text, url))
        else:
            rows.extend(parse_sg_page(text, url))
    return rows


def parse_europe(text: str, url: str) -> list[dict]:
    patterns = [
        ("Chunghwa Telecom Vietnam Co., Ltd. (Hanoi)", "Vietnam", "VNM", "Hanoi", "Hanoi", "123000"),
        ("Chunghwa Telecom Vietnam Co., Ltd. (Hochiminh City)", "Vietnam", "VNM", "Ho Chi Minh City", "Ho Chi Minh City", ""),
        ("Chunghwa Telecom Hong Kong Co., Ltd.", "Hong Kong", "HKG", "", "Kowloon", ""),
        ("Chunghwa Telecom USA", "United States of America", "USA", "California", "San Jose", "95131"),
    ]
    rows = []
    for name, country, iso3, state, city, postcode in patterns:
        m = re.search(name + r".*?Address[:：]\s*(.+?)(?:Address[:：]|$)", text, re.S)
        if not m:
            continue
        address = " ".join(m.group(1).split())
        rows.append(emit_row(name, address, country, iso3, state, city, postcode, url))
    return rows


def parse_us_page(text: str, url: str) -> list[dict]:
    rows = []
    matches = [
        ("Santa Clara Office", "2107 N First Street, Ste 580, San Jose, CA 95131", "United States of America", "USA", "California", "San Jose", "95131"),
        ("Phoenix Office", "2550 W Union Hills Dr, Suite 350, Phoenix, AZ 85027", "United States of America", "USA", "Arizona", "Phoenix", "85027"),
    ]
    for name, address, country, iso3, state, city, postcode in matches:
        if address.split(",")[0] in text:
            rows.append(emit_row(name, address, country, iso3, state, city, postcode, url))
    return rows


def parse_sg_page(text: str, url: str) -> list[dict]:
    rows = []
    if "331 North Bridge Road" in text:
        rows.append(
            emit_row(
                "Chunghwa Telecom Singapore",
                "331 North Bridge Road, #05-03, Odeon Towers, Singapore 188720",
                "Singapore",
                "SGP",
                "",
                "Singapore",
                "188720",
                url,
            )
        )
    return rows


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    rows = parse_pages()
    with OUTPUT_CSV.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=HEADERS)
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()
