# HANDOFF — Row-by-row issuer attribution check (Hierarchy Check, 14,600 rows)

**Owner:** Aryan (MSCI GSAI Physical Assets) · **Prepared by:** Claude (chat), 3-Nov-2026 · **Executor:** Claude Cowork

## 0. Mission (read first)

For **every row** of `row_queue.csv` (14,600 facilities), decide whether the assigned `ISSUER_ID` / `SECMASTER_NAME` is the right issuer for that facility. Write one verdict per row, with evidence. When all rows are done, build the report workbook with `build_report.py`. The report has the same structure as the sample union report.

- **Check each row yourself.** The `BASELINE_*` columns are the chat pass. About 87% of them were *propagated* (inferred from similar rows), not checked. Treat them as hints only. A baseline verdict is never evidence.
- **Work one group at a time.** A group is one issuer × one URL domain (`GROUP_KEY`). Open the source page once per group, then judge each row on it separately.
- **Checkpoint after every group or batch.** You must be able to stop and resume without losing or redoing work (§3).
- **Never edit the source columns** (everything left of `CHECK_STATUS`). Name corrections go in `CORRECTED_NAME`.

## 1. What is in this kit

| File | Purpose |
|---|---|
| `HANDOFF.md` | This document: the rules and procedure. Authoritative. |
| `row_queue.csv` | 14,600 rows: original 26 columns, plus `PRIORITY` and `GROUP_KEY`, plus `BASELINE_*` hints, plus empty output columns. |
| `helpers.py` | Secmaster and URL helpers: lookup, ancestors, same-URL rule, URL-bearing ancestor, registrable domain, homepage rule. |
| `merge.py` | Folds `results/batch_*.csv` into `row_queue.csv` (keeps a `.bak`). |
| `validate.py` | Rule checks on finished rows. Writes `validation_issues.csv`. |
| `build_report.py` | Builds the formula-driven report workbook from the finished queue. |
| `known_remap_targets.csv` | DMX entities already identified as correct owners (118). These are leads to re-verify, not answers. |
| `baseline_name_fixes.csv`, `baseline_dmx_updates.csv` | Name-contamination fixes and DMX updates found so far. |
| `M3_Asset_Location_Collection_Methodology_v3_1.docx` | Scope authority. |
| `Issuer_ID_Remap_SecMaster_Check_v2_HierarchyCheck_REPORT.xlsx` | Baseline report, for reference only. |

**Also needed, not bundled (85 MB):** `sec_master_20260828.parquet`. Aryan supplies it; put it in the kit folder.

**Setup:**
```bash
pip install pandas openpyxl pyarrow tldextract
python -c "import helpers as H; H.load('sec_master_20260828.parquet'); print(H.search('Belron'))"
```

## 2. Glossary
- **DMX / secmaster:** MSCI's entity master (`sec_master_20260828.parquet`). Each entity record has an issuer ID (IID), name, URL, parent and ultimate parent.
- **Issuer:** the entity the facility is currently booked to (`ISSUER_ID`).
- **Owner / operator:** the entity that owns, leases or runs the facility. This is what we are trying to identify.
- **Group:** all rows sharing `GROUP_KEY` = `ISSUER_ID|registrable domain of RELEVANT_URL`.
- **URL-bearing:** has a non-empty `url` in secmaster.

## 3. Order of work, batching, checkpointing

1. **Sort.** Sort by `PRIORITY` ascending; `row_queue.csv` is already sorted this way. Inside a priority level, work through groups (`GROUP_KEY`).

   | PRIORITY | Baseline basis | Rows | Why this order |
   |---|---|---|---|
   | 1 | PROPAGATED_NEAREST | 1,231 | Weakest inference. Mixed groups copied from the most similar name. |
   | 2 | PROPAGATED_COUNTRY | 876 | Mixed groups copied by country. |
   | 3 | NEW_REVIEW_GROUP | 982 | Group-level review only. |
   | 4 | PROPAGATED_GROUP | 9,640 | Uniform groups; most rows. |
   | 5 | DIRECT | 1,871 | Already checked row by row in the samples. Re-check last, for consistency. |

2. **Batch.** One group per batch. Split groups larger than 50 rows into batches of 50 or fewer.

3. **Write the batch file.** After each batch, write `results/batch_<NNNN>.csv`:
   - one row per facility;
   - columns: `FACILITY_ID` plus the output columns in §6;
   - `CHECK_STATUS=DONE` on every finished row.

   Never write partial rows. If a row is blocked, set `CHECK_STATUS=BLOCKED` and give the reason in `EVAL_REASON`.

4. **Merge.** Run `python merge.py row_queue.csv results/` every 10 batches and at the end.

5. **Resume.** When restarting, skip any `FACILITY_ID` already `DONE` in `row_queue.csv` or in any `results/batch_*.csv`.

6. **Keep a log.** Keep `progress_log.md` with one line per batch: batch number, group key, rows, verdict counts, and anything escalated.

7. **Store evidence.** Keep an extract per row in `EVIDENCE_URL` / `EVIDENCE_EXTRACT`. Optionally save screenshots to `evidence/<GROUP_KEY>/`. Evidence is internal and is deleted after the task.

## 4. Per-row procedure

Do steps A–H for every row. Steps A–C can be shared across a group. Steps D–H are per row.

**A. Read the row.** Read:
- `FACILITY_NAME`, `ASSET_COUNTRY`, `BUSINESS_ACTIVITY` and `RELEVANT_URL`;
- `ISSUER_ID` and `SECMASTER_NAME`, plus the issuer's parent and ultimate parent (`H.ancestors`);
- the issuer's DMX URL (`H.url_of`) and the DMX entities owning the URL's domain (`H.owners_of`).

**B. Open the source** (Rule 5.1, open-before-include). Access tiers:
1. direct fetch;
2. browser;
3. same URL via `www`/non-`www` or `http`/`https`;
4. the site's own locator or contact page reached by navigation.

Record `URL_ACCESS` = `OK` / `BLOCKED` / `DEAD`. Do not use archived copies to make ownership calls, because ownership changes over time. Respect robots.txt.

**C. Identify whose page it is.** Is the page the issuer's own, a sibling's, the parent's, or a third party's (directory, news, partner, dealer, client)?

**D. Find the facility on the page.** Record `FACILITY_ON_PAGE` = `YES` / `NO` / `UNCLEAR`. Then:
- **Facility not on the page:** look for the issuer's own official locator. If you find the facility there, set `CORRECTED_URL` and continue.
- **Not found anywhere:** use RECOLLECT.

**E. Identify the owner or operator** of this specific facility, using first-party or official evidence (§7). Write it in `OWNER_OPERATOR_FOUND`.

**F. Apply the scope rules** (§5, S-rules). If the row is out of scope, the verdict is `OUT_OF_SCOPE_DROP`; stop here for this row.

**G. Map the owner to DMX.** Use §5 O-rules:
- `H.search(...)` and `known_remap_targets.csv` to find the entity;
- `H.relation(current, candidate)` to see how it relates to the current issuer;
- `H.climb_same_url(candidate)` for the same-URL rule;
- `H.url_bearing_ancestor(...)` for the no-website fallback.

**H. Write the verdict.** Fill in the reason, rule reference, evidence and confidence. Add flags where they apply: JV, lifecycle, M3 miss, DMX issue, name fix.

## 5. Decision rules (authoritative)

### Ownership / attribution (O-rules)

- **O1 — Owner rule.** Assign the facility to its direct owner or operator if that entity is in DMX **and** has its own website. Its own website counts even if DMX lacks the URL. Otherwise assign it to the closest ancestor in DMX that has a URL.
  - If you keep a subsidiary that has its own website but no DMX URL, add DMX issue "DMX URL missing for issuer".
  - Do **not** move such rows to the parent. The strict N6 view is noted automatically by the report builder, not applied.
- **O2 — Same-URL rule.** If a child and its parent share the same DMX URL, the asset belongs under the **parent**.
  - Current issuer is such a child: the row is not wrong. The report flags it automatically.
  - Suggested target is such a child: suggest the parent instead (`H.climb_same_url`). If that equals the current issuer, the verdict is CORRECT.
- **O3 — Asset on a sibling's or parent's page.**
  - The facility belongs to a sibling or subsidiary with its own IID and website: WRONG_REMAP to that entity.
  - The facility belongs to the parent: remap to the parent.
  - A subsidiary's site mentioning a parent's asset does not make it the subsidiary's.
- **O4 — Owner absent from DMX.** Name the owner in the reason. The verdict is WRONG_OWNER_NOT_IN_DMX. Suggest the closest URL-bearing ancestor of the true owner, if that ancestor is in DMX; otherwise leave the suggestion blank.
- **O5 — Owner ≠ operator.** If either is the issuer or in its hierarchy, assign that entity and name the other in the reason. If neither is in the hierarchy but one is in DMX, assign that one. If both are in DMX, name both and pick the operator.
- **O6 — Joint ventures.** Include minority stakes of any size and in any sector.
  - Suggest the hierarchy company. If the JV company itself is in DMX with its own website, suggest that company per O1.
  - Fill `JV_HIERARCHY_CO` (entity, IID, stake if known).
  - Fill `JV_PARTNERS` (partner, IID if in DMX). This follows the September rule: hierarchy company plus JV partner.
- **O7 — Stale DMX hierarchy.** Attribute to the evidenced owner even if DMX doesn't link it. Record the needed fix in `DMX_ISSUE`, e.g. "parent should be X (IID)".
- **O8 — Same building under two issuers** can be legitimate, e.g. an owner and a tenant-operator, or a business park. Don't drop a row for that reason alone.
- **O9 — Group-level standing exception.** Lifco AB (IID000000002715781) is held at group level, so never remap to Lifco subsidiaries.

### Scope (S-rules; M3 v3.1)

| Rule | Out of scope → `OUT_OF_SCOPE_DROP` | M3 ref |
|---|---|---|
| S1 | Independent dealers, distributors, agents, authorised retailers or service partners, and dealer/distributor locators. Includes dealers carrying the brand name, e.g. AHASS, Lynk & Co China, Linde MH, Goulds, Quantum Design. | 6.3 |
| S2 | Franchise / licensee stores: "FC" stores (Housecom), Jean Coutu pharmacist-owned stores, Carglass licensees (Morocco, Ukraine, GBH Réunion), Beltone independents. | 6.2 |
| S3 | Kiosks, and concessions inside a third-party store: AFC/Snowfox/Snowfruit/Bento Sushi counters in grocers, "at Myer", John Lewis concessions, MTR concourse kiosks. Leased **shop units** in malls or airports are in scope (e.g. CTG duty free, Drogas in Maxima). | Table 6.2 + Aryan ruling |
| S4 | Linear assets: pipelines, electric lines, rail track, **toll roads/motorways**, fuel hydrant systems. Offices and plants on them are in scope. | Table 6.2 |
| S5 | Points of presence in third-party colocation data centres (Equinix, Digital Realty, NTT…), e.g. Console Connect. | Aryan ruling |
| S6 | Client or project sites where the issuer is only contractor, EPC or service provider (Argan solar projects, ista client buildings, airport-owned lounges, partner lounges, F1 circuits). | 6.6 / 6.3 |
| S7 | Reference / completed-project pages (`referenz`, `references`, portfolio cases) not owned by the issuer. | 6.6 |
| S8 | Mailing-only addresses: P.O. box, "correspondence address", `c/o`, `Postadres`. | Aryan rule |
| S9 | A subsidiary list without addresses (Exhibit 21 etc.). | 6.3 |
| S10 | Third-party businesses on the page: principal banker or auditor in an annual report, tenants in an issuer's mall (Lopia, Doutor), fuel-card acceptance networks (Routex). | 6.3 |

**In scope:**
- owned, operated, leased or controlled sites (6.1);
- **managed hotels**: in scope, and set `M3_MISS` = "management contract previously treated as out of scope — M3 6.1 'operated'";
- BUWOG units for sale that are still owned (in scope until sold); sold-out reference projects are out.

### Lifecycle (L-rules)

- **L1 — Divested, merged away or closed, and confirmed.** Verdict `LIFECYCLE_DIVESTED`. Name the buyer or successor in the reason, with its IID if it is in DMX; the buyer is not the suggestion. Examples: Take 5 Car Wash → Whistle Express (Apr-2025); Akros Pharma → Shionogi (Dec-2025); EQRx → Revolution Medicines.
- **L2 — Announced but not completed, or closure not confirmed.** Keep the verdict and fill `LIFECYCLE_WATCH`. Examples: DFI/Maxim's Starbucks (Sep-2026, conditional); Cleanaway New Chum.
- **L3 — Entity merged into a successor that is in DMX.** Remap to the successor (6.3 "acquired or renamed issuer"). Examples: Viva Home → Arclands; WestlandUtrecht Bank → ING (same-URL rule → ING Groep).

### Source quality (Q-rules)

- **Q1 — Homepage-only URL with a numbered or brand-only name** (e.g. "Powercor 1", "Bandung 115"): `RECOLLECT`. The exception is when you find the specific branch on an official locator; then use `URL_CORRECTION_ONLY` (issuer right) with `CORRECTED_URL`.
- **Q2 — Synthetic-looking names** (city + running number, JSON fragments like `'code': ''`): `RECOLLECT` unless a specific official page confirms the site.
- **Q3 — Issuer right but the source is third-party** (directory, Waze, Apple Maps, chamber listing, aggregator, news): `URL_CORRECTION_ONLY` with a first-party `CORRECTED_URL`. If no first-party page exists: `CORRECT` (low confidence) when an official second-party source confirms it, otherwise `RECOLLECT`.
- **Q4 — `URL_OWNERS_SECMASTER` is unreliable on shared hosts.** On sec.gov, emis.com, q4ir.com, gcs-web.com, annualreports.com, investorroom.com, bank.in, home.scarlet.be and similar hosts, the listed "owners" are unrelated. Judge the page content, not the domain owner.
- **Q5 — `GICS_MISMATCH` / `GICS_CHECK`** is a category only. It never decides a verdict.

## 6. Output columns (fill per row)

| Column | Allowed values / content |
|---|---|
| `CHECK_STATUS` | `DONE` · `BLOCKED` (give the reason) · `PENDING` |
| `URL_ACCESS` | `OK` · `BLOCKED` · `DEAD` · `NOT_ATTEMPTED` |
| `FACILITY_ON_PAGE` | `YES` · `NO` · `UNCLEAR` |
| `OWNER_OPERATOR_FOUND` | Legal or brand name of the entity evidenced as owner/operator |
| `EVAL_VERDICT` | One of the 8 codes below |
| `EVAL_SUGGESTED_ISSUER_ID` / `_NAME` | Required for `WRONG_REMAP` and `CORRECT_BETTER_MATCH`. Optional for `WRONG_OWNER_NOT_IN_DMX`. Must exist in secmaster. |
| `EVAL_CONFIDENCE` | `H` (first-party, explicit) · `M` (first-party, inferred, or official second-party) · `L` (indirect) |
| `EVAL_REASON` | One or two sentences: who owns/operates the site and why the verdict follows |
| `RULE_REF` | e.g. `O1`, `S3`, `L1`, `Q1` (several allowed, `;`-separated) |
| `CORRECTED_URL` | First-party page that lists this facility (when the given URL is wrong or weak) |
| `EVIDENCE_URL` / `EVIDENCE_EXTRACT` | Exact source URL, plus an extract of at most 25 words |
| `M3_MISS` | Only when an earlier treatment contradicted M3 (e.g. managed hotels) |
| `JV_HIERARCHY_CO` / `JV_PARTNERS` | Per O6 |
| `LIFECYCLE_WATCH` | Per L2 |
| `DMX_ISSUE` | Needed DMX fix: wrong or stale parent, missing URL, missing entity, wrong GICS, URL pollution |
| `CORRECTED_NAME` / `NAME_FIX_COMMENT` | Only when the facility name is contaminated (see below); explain the change |
| `CHECKED_AT` | ISO date |

**Name contamination.** A facility name is contaminated when it carries another company's name as a prefix, for example:
- `THE FOSCHINI GROUP LIMITED /` on Bloomingdale's;
- `QUEBECOR INC. /` on Walmart and Best Buy;
- `ASHTEAD GROUP … /`, `Ferrari Group PLC /`, `OceanaGold Corporation /`, `NIPPON EXPRESS HOLDINGS /`, `KAGOME CO., LTD. /`.

### Verdict codes

| Code | Meaning | Counts as correct (strict) |
|---|---|---|
| `CORRECT` | The assigned issuer is right | yes |
| `URL_CORRECTION_ONLY` | Issuer right; `RELEVANT_URL` must be replaced | yes |
| `CORRECT_BETTER_MATCH` | Right group, but a more accurate DMX entity exists (O1/O3) | no (group-level yes) |
| `WRONG_REMAP` | Wrong issuer; the correct owner is in DMX | no |
| `WRONG_OWNER_NOT_IN_DMX` | Wrong issuer; the owner is absent from DMX | no |
| `OUT_OF_SCOPE_DROP` | Out of scope (S-rules) | no |
| `LIFECYCLE_DIVESTED` | Divested or closed (L1) | no |
| `RECOLLECT` | Cannot be confirmed from any admissible source (Q-rules) | no |

## 7. Evidence standard
- **Admissible:** first-party sources (the company's own site, filings, reports, press releases) or official second-party sources (regulator, exchange, government registry, SEC/EDINET filings).
- **Not admissible:** social media (very-high-confidence last resort only), aggregators and directories (leads only), and archived pages for ownership calls.
- **Divestments:** need a dated first-party or official source.

## 8. Known traps and precedents

These were found in the chat pass. Re-verify each one; don't copy it.

| Pattern | What was found |
|---|---|
| Sukiya / Hanamaru cross-contamination | Hama-sushi, Nakau, Coco's and Big Boy rows sit under Sukiya or Hanamaru. These are Zensho subsidiaries: Hama Sushi IID000000005310227, NAKAU IID000000002176370, COCO'S JAPAN IID000000002160636, Big Boy Japan IID000000002274456, ZENSHO HD IID000000002151268. US-grocer kiosks are tagged JPN/SGP/THA, which is wrong. |
| Carglass NV used for all countries | National Carglass companies are Belron's (BELRON INTERNATIONAL LIMITED IID000000002278435). Belgium and Luxembourg stay with Carglass NV. Licensees are out (S2). |
| Circle K Lietuva on circlek.eu Routex | German stations are a fuel-card partner network, so out (S10). Northern Ireland belongs to CIRCLE K IRELAND HOLDING IID000000002781344. |
| Console Connect | All rows are third-party colocation halls, so out (S5). |
| Astra group | Dealer/AHASS networks are out (S1). Synthetic numbered names → RECOLLECT (Q2). Auto2000 is Astra-owned; locator: https://auto2000.co.id/dealer-toyota. Named subsidiaries have their own IIDs (Astra Otoparts, Astra Honda Motor, Astra Sedaya Finance, TMMIN). |
| Bwi BVBA (home.scarlet.be) | Personal web pages of small independent businesses → WRONG_OWNER_NOT_IN_DMX. Not Proximus. |
| Wrong plant or mall project company | EEW (Helmstedt company used for other plants), Centennial mines, Klépierre mall companies, ABS, Quirónsalud hospitals, Mold-Tech, Nabtesco: check every site's own entity. |
| Brand ≠ entity | KAY stores → Sterling Inc (IID000000005538832); Eddie V's and Seasons 52 → Darden; Steigenberger hotels → Steigenberger Hotels AG; Maeda overseas → MAEDA CORPORATION; e& UAE stores → IID000000002148408. |
| Homepage-only utilities | Powercor, CitiPower and United Energy rows named after the company with homepage URLs → RECOLLECT unless a specific site is found. |
| Reviewer findings (source file sheet "Findings Related to Mapping") | 18 rows already reviewed by a human. Follow them unless first-party evidence contradicts; if so, explain in the reason. |

## 9. Finishing

1. Merge: `python merge.py row_queue.csv results/`
2. Validate: `python validate.py row_queue.csv sec_master_20260828.parquet`. Fix everything listed in `validation_issues.csv`, then re-run until it is clean.
3. Build the report: `python build_report.py row_queue.csv sec_master_20260828.parquet Issuer_ID_Remap_HierarchyCheck_ROWLEVEL_REPORT.xlsx`
4. Open the report in Excel so it recalculates; the formulas need it. Check that SUMMARY totals equal 14,600 and that no sheet shows `#VALUE!` or `#NAME?`.
5. Write `FINAL_NOTE.md` covering:
   - rows done, blocked and dead;
   - strict accuracy overall, by STATUS and by URL_CHECK;
   - the change-versus-baseline matrix headline (how many baseline verdicts flipped, and which kinds);
   - the 10 issuers with the most errors;
   - new DMX updates;
   - escalations.

## 10. Escalate to Aryan (do not decide alone)
- A financing company or SPV is the only plausible owner. The subtype gate is an open item and secmaster has no subtype field.
- A conflict with a reviewer finding or a standing rule.
- Any scope pattern not covered by the S-rules.
- Ownership evidence that is time-sensitive and contradictory (a recent deal, unclear completion).

Log each escalation in `progress_log.md` and set `CHECK_STATUS=BLOCKED` with the question in `EVAL_REASON`.

## 11. Prompt to start Cowork (copy-paste)
> You are continuing an MSCI GSAI issuer-attribution audit. Read `HANDOFF.md` in this folder fully. It is the authority for rules, order of work, output format and checkpointing. Load `sec_master_20260828.parquet` with `helpers.load`.
>
> Process `row_queue.csv` group by group (`GROUP_KEY`), in `PRIORITY` order. For every row, open the source page and judge that row individually using §4–§5. Treat `BASELINE_*` columns as hints only, never as evidence.
>
> After each group, write `results/batch_<NNNN>.csv` and append to `progress_log.md`. Run `merge.py` every 10 batches. When all rows are DONE or BLOCKED, run `validate.py` until clean, then `build_report.py`, then write `FINAL_NOTE.md`.
>
> Stop and ask before deciding anything listed in §10. Start now with PRIORITY 1.
