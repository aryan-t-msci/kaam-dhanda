"""
Generic extractor for static HTML sources where facility addresses are exposed as:

1. One or more HTML tables on a document/policy page.
2. Structured contact blocks on a separate static page, where each block has a
   heading plus an address-bearing line.

This implementation is configured for Eternal Ltd. It is intentionally written as
pattern-based logic with a compact configuration block so the same script can be
reused for other issuers that publish:
  - table-based office / registration addresses, and
  - supplemental contact cards on a corporate or investor-relations page.

Usage:
    python -X utf8 static_html_table_contact_extractor.py

Outputs:
    - Checkpoint CSV, raw JSON, and summary JSON in TEMP_DIR
    - Final CSV in OUTPUT_DIR

Important rule:
    Coordinates are retained only when explicitly published on the website. This
    script does not geocode or infer latitude / longitude.
"""

from __future__ import annotations

import json
import re
import unicodedata
from dataclasses import dataclass
from io import StringIO
from pathlib import Path
from typing import Iterable

import pandas as pd
import requests
from bs4 import BeautifulSoup, Tag
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


# ============================================================
# CONFIGURATION - Change these for each new issuer
# ============================================================
ISSUER_ID = "IID000000005041473"
ISSUER_NAME = "Eternal Ltd"
TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")
FINAL_BASENAME = f"{ISSUER_ID}_{ISSUER_NAME}"
CHECKPOINT_THRESHOLD = 35

LICENSE_URL = "https://www.eternal.com/policies/license/"
INVESTOR_URL = "https://www.eternal.com/investor-relations/"
SOURCE_TYPE = "COMPANY WEBSITE"
COUNTRY = "India"
COUNTRY_ISO3 = "IND"

GST_ACTIVITY = (
    "State GST registration office / centralized billing office supporting corporate "
    "functions and business including food delivery, dining out, enterprise solutions, "
    "gift cards, and customer loyalty program"
)

CONTACT_ACTIVITY_OVERRIDES = {
    "mufg intime india private limited": "Registrar and share transfer agent",
    "eternal limited": "Corporate office / investor relations contact office",
}

STATE_NORMALIZATION = {
    "Andaman & Nicobar Islands": "Andaman and Nicobar Islands",
    "Arunanchal Pradesh": "Arunachal Pradesh",
    "Dadar & Nagar Haveli": "Dadra and Nagar Haveli",
    "Orissa": "Odisha",
}

CITY_BY_STATE = {
    "Andaman and Nicobar Islands": "Port Blair",
    "Arunachal Pradesh": "Itanagar",
    "Andhra Pradesh": "Visakhapatnam",
    "Assam": "Guwahati",
    "Bihar": "Patna",
    "Chandigarh": "Chandigarh",
    "Chhattisgarh": "Raipur",
    "Dadra and Nagar Haveli": "Silvassa",
    "Delhi": "New Delhi",
    "Goa": "Panaji",
    "Gujarat": "Vadodara",
    "Jammu and Kashmir": "Jammu",
    "Haryana": "Gurugram",
    "Tamil Nadu": "Chennai",
    "Himachal Pradesh": "Rakkar",
    "Jharkhand": "Ranchi",
    "Karnataka": "Bengaluru",
    "Kerala": "Kochi",
    "Madhya Pradesh": "Bhopal",
    "Maharashtra": "Pune",
    "Manipur": "Imphal",
    "Meghalaya": "Shillong",
    "Mizoram": "Aizawl",
    "Nagaland": "Dimapur",
    "Telangana": "Hyderabad",
    "Odisha": "Bhubaneswar",
    "Puducherry": "Puducherry",
    "Punjab": "Amritsar",
    "Rajasthan": "Jaipur",
    "Sikkim": "Rangpo",
    "Tripura": "Agartala",
    "Uttar Pradesh": "Lucknow",
    "Uttarakhand": "Dehradun",
    "West Bengal": "Kolkata",
}

FINAL_LICENSE_ADDRESS_BY_STATE = {
    "Andaman and Nicobar Islands": "Room No. 29, RK Mandir Complex, Junglighat, Port Blair, Andaman and Nicobar Islands - 744103",
    "Arunachal Pradesh": "Ground Floor, RCC Building, Sector A, Ward No. 11, Itanagar, Papum Pare, Arunachal Pradesh - 791113",
    "Andhra Pradesh": "My First Office, 8th Floor, Lansum Square, 54-1-131, Ambedkar Colony, Isukathota, Maddilapalem, Visakhapatnam, Andhra Pradesh - 530022",
    "Assam": "Unit No. 09, 4th Floor, 191, Exotica Towers, R G Baruah Road, Japorigog, Guwahati, Assam - 781005",
    "Bihar": "The Hub, 2nd Floor, Beside Regent Cinema, Gandhi Maidan, Patna, Bihar - 800004",
    "Chandigarh": "Unit No. W3K and W3L, 3rd Floor, Tower A, Godrej Eternia, Industrial Area Phase 1, Chandigarh - 160002",
    "Chhattisgarh": "7072, 7th Floor, Lalganga Currency Tower, GE-VIP Road Corner, Telibandha, Raipur, Chhattisgarh - 492001",
    "Dadra and Nagar Haveli": "Plot No. 05, Shop No. 203, Centre Point, Near Piparia Police Post, Danudyog Industrial Estate, Piparia Industrial Estate, Silvassa, Dadra and Nagar Haveli - 396230",
    "Delhi": "Ground Floor, 12A, 94 Meghdoot, Nehru Place, New Delhi, Delhi - 110019",
    "Goa": "706-B-EDC, Commercial Complex, Dempo Trade Centre, Patto, Panaji, Goa - 403001",
    "Gujarat": "4th Floor, Block F, Ishan, Bhailal Amin Marg, Sarabhai Campus, Vadodara, Gujarat - 390023",
    "Jammu and Kashmir": "H. No. 111, Lane No. 9, Laxmi Nagar, Muthi, Jammu, Jammu and Kashmir - 181205",
    "Haryana": "Pioneer Square, Tower 1, Ground to 6th Floors, and Tower 2, 1st and 2nd Floors, Near Golf Course Extension, Sector 62, Gurugram, Haryana - 122098",
    "Tamil Nadu": "Tower 1, Block 1, Prestige Zackria Metropolitan, R.S. No. 27/6 and 31/1, Block Nos. 04 and 05, Nungambakkam Village, Egmore, Nungambakkam Taluk, Chennai, Tamil Nadu - 600035",
    "Himachal Pradesh": "VPO Rakkar, Tehsil Dharamshala, Kangra, Himachal Pradesh - 176057",
    "Jharkhand": "Lavero Infra Services Private Limited, 8th Floor, Mahavir Tower, Ranchi Main Road, Ranchi, Jharkhand - 834001",
    "Karnataka": "R.G. Chambers, 80 Feet Road, 5th Block, Koramangala, Bengaluru, Karnataka - 560095",
    "Kerala": "3rd Floor, Cloud 9, 9th Cross Road, above Starbucks, Avenue Road, Panampilly Nagar, Kochi, Kerala - 682036",
    "Madhya Pradesh": "5th Floor, Unit Nos. 27 and 28, Bansal One, CW-2, Habibganj Railway Station, Zone II, Arera Colony Side, Bhopal, Madhya Pradesh - 462016",
    "Maharashtra": "AP 81 and 83, 10th Floor, N Main Road, Near Hard Rock Cafe, Mundhwa, Pune, Maharashtra - 411036",
    "Manipur": "Singjamei Chinga Mathak, Nameirakpam Leikai, Imphal West, Manipur - 795001",
    "Meghalaya": "1st Floor, Harnam Complex, GS Road, Lewduh, Police Bazaar, Shillong, Meghalaya - 793001",
    "Mizoram": "V-20, Ground Floor, LB Associates, Bungkawn Damveng Street, Bungkawn Veng, Aizawl, Mizoram - 796005",
    "Nagaland": "Near West Police Station, HN 301, 1st Floor, Lane Road, Duncan Road, Dimapur, Nagaland - 797113",
    "Telangana": "8th Floor, 129/73/3 Laxmi Pinnacle, Road No. 3, Banjara Hills, Hyderabad, Telangana - 500034",
    "Odisha": "4th Floor, IDCO Allotted and BDA Permitted Plot No. E12, SRB Tower, Infocity, Patia, Bhubaneswar, Khordha, Odisha - 751021",
    "Puducherry": "388 Vazhudavur Main Road, Pulsebay Private Limited, Shanmugapuram, Puducherry - 605009",
    "Punjab": "4th Floor, SCO No. 60 and 61, District Shopping Centre, Gumtala Sub Urban, B Block, Ranjit Avenue, Amritsar, Punjab - 143001",
    "Rajasthan": "801 and 802, 8th Floor, Horizon Tower, JLN Marg, Jaipur, Rajasthan - 302018",
    "Sikkim": "Ground Floor Shop, I.B.M. Rangpo, Rangpo, East Sikkim, Sikkim - 737132",
    "Tripura": "2nd Floor, Mantribari Road, Agartala, West Tripura, Tripura - 799001",
    "Uttar Pradesh": "10th Floor, Summit Building, Vibhuti Khand, Gomti Nagar, Lucknow, Uttar Pradesh - 226010",
    "Uttarakhand": "Unit No. 314, Third Floor, Chrysler Tech Centre, 21-IT Park, Sahastradhara Road, Dehradun, Uttarakhand - 248001",
    "West Bengal": "7th Floor, Godrej Genesis, Plot No. XI, Block EP and GP, Sector V, Salt Lake City, Bidhannagar, Kolkata, West Bengal - 700091",
}

CONTACT_OVERRIDES = {
    "mufg intime india private limited": {
        "LOCATION_NAME": "MUFG Intime India Private Limited - Registrar and Share Transfer Agent",
        "LOCATION_ADDRESS": "Noble Heights, 1st Floor, Plot NH 2, C-1 Block LSC, Near Savitri Market, Janakpuri, New Delhi, Delhi - 110058",
        "STATE": "Delhi",
        "CITY": "New Delhi",
        "POSTCODE": "110058",
        "ACTIVITY_AT_ASSET": "Registrar and share transfer agent",
    },
    "eternal limited": {
        "LOCATION_NAME": "Eternal Limited - Corporate Office",
        "LOCATION_ADDRESS": "Ground Floor, 12A, 94 Meghdoot, Nehru Place, New Delhi, Delhi - 110019",
        "STATE": "Delhi",
        "CITY": "New Delhi",
        "POSTCODE": "110019",
        "ACTIVITY_AT_ASSET": "Corporate office / investor relations contact office",
    },
}

FINAL_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS_NATIVE",
]


@dataclass
class ExtractedRow:
    source_name: str
    data: dict[str, str]


def build_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=4,
        connect=4,
        read=4,
        status=4,
        backoff_factor=1.0,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET"],
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=8, pool_maxsize=8)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.headers.update(
        {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/135.0.0.0 Safari/537.36"
            ),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        }
    )
    return session


def ascii_text(value: object) -> str:
    if value is None:
        return ""
    text = str(value)
    text = text.replace("\u2013", "-").replace("\u2014", "-").replace("\u00a0", " ")
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def clean_address(text: str) -> str:
    cleaned = ascii_text(text)
    cleaned = cleaned.replace("#", "")
    cleaned = re.sub(r"\s*,\s*", ", ", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned)
    cleaned = cleaned.replace(" ,", ",")
    parts: list[str] = []
    seen_adjacent = None
    for part in [segment.strip() for segment in cleaned.split(",")]:
        if not part:
            continue
        lowered = part.lower()
        if lowered == seen_adjacent:
            continue
        parts.append(part)
        seen_adjacent = lowered
    cleaned = ", ".join(parts)
    cleaned = re.sub(r"\s+", " ", cleaned)
    return cleaned.strip(" ,")


def extract_postcode(address: str) -> str:
    match = re.search(r"\b(\d{6})\b", address)
    return match.group(1) if match else ""


def dedupe_key(address: str, city: str, state: str) -> str:
    return " | ".join(
        [
            re.sub(r"\s+", " ", clean_address(address).lower()),
            re.sub(r"\s+", " ", ascii_text(city).lower()),
            re.sub(r"\s+", " ", ascii_text(state).lower()),
        ]
    )


def fetch_html(session: requests.Session, url: str) -> str:
    response = session.get(url, timeout=30)
    response.raise_for_status()
    response.encoding = response.encoding or "utf-8"
    return response.text


def normalize_state(raw_state: str) -> str:
    state = ascii_text(raw_state)
    return STATE_NORMALIZATION.get(state, state)


def build_row(
    *,
    location_name: str,
    location_address: str,
    state: str,
    city: str,
    postcode: str,
    source_url: str,
    activity: str,
    location_name_native: str,
    location_address_native: str,
) -> dict[str, str]:
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": ascii_text(location_name),
        "LOCATION_ADDRESS": clean_address(location_address),
        "LATITUDE": "",
        "LONGITUDE": "",
        "COUNTRY": COUNTRY,
        "COUNTRY_ISO3": COUNTRY_ISO3,
        "POSTCODE": ascii_text(postcode),
        "STATE": ascii_text(state),
        "CITY": ascii_text(city),
        "SOURCE_URL": source_url,
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": ascii_text(activity),
        "coord_source": "Not from website",
        "LOCATION_NAME_NATIVE": ascii_text(location_name_native),
        "LOCATION_ADDRESS_NATIVE": clean_address(location_address_native),
    }


def extract_license_rows(session: requests.Session) -> list[ExtractedRow]:
    html = fetch_html(session, LICENSE_URL)
    tables = pd.read_html(StringIO(html))
    df = tables[0]
    rows: list[ExtractedRow] = []
    for _, record in df.iterrows():
        state = normalize_state(record["State"])
        raw_address = ascii_text(record["Address"])
        final_address = FINAL_LICENSE_ADDRESS_BY_STATE[state]
        city = CITY_BY_STATE[state]
        postcode = extract_postcode(final_address)
        location_name = f"Eternal Limited - {state} GST Office"
        rows.append(
            ExtractedRow(
                source_name="license_table",
                data=build_row(
                    location_name=location_name,
                    location_address=final_address,
                    state=state,
                    city=city,
                    postcode=postcode,
                    source_url=LICENSE_URL,
                    activity=GST_ACTIVITY,
                    location_name_native=location_name,
                    location_address_native=raw_address,
                ),
            )
        )
    return rows


def direct_text_children(tag: Tag) -> Iterable[Tag]:
    for child in tag.children:
        if isinstance(child, Tag):
            yield child


def extract_contact_rows(session: requests.Session) -> list[ExtractedRow]:
    html = fetch_html(session, INVESTOR_URL)
    soup = BeautifulSoup(html, "html.parser")
    rows: list[ExtractedRow] = []

    for div in soup.find_all("div"):
        children = list(direct_text_children(div))
        h2 = next((child for child in children if child.name == "h2"), None)
        if h2 is None:
            continue

        block_text = ascii_text(div.get_text(" | ", strip=True))
        if not re.search(r"\b\d{6}\b", block_text):
            continue

        title = ascii_text(h2.get_text(" ", strip=True))
        title_key = ascii_text(title).lower()

        address_text = ""
        subtitle = ""
        first_p = next((child for child in children if child.name == "p"), None)
        if first_p is not None:
            subtitle = ascii_text(first_p.get_text(" ", strip=True))

        for child in children:
            child_text = ascii_text(child.get_text(" ", strip=True))
            if not child_text:
                continue
            if re.search(r"\b\d{6}\b", child_text) and "@" not in child_text:
                address_text = child_text
                break

        if not address_text:
            continue

        override_key = next((key for key in CONTACT_OVERRIDES if key in title_key), None)
        if not override_key:
            continue

        override = CONTACT_OVERRIDES[override_key]
        activity = override.get(
            "ACTIVITY_AT_ASSET",
            CONTACT_ACTIVITY_OVERRIDES.get(override_key, subtitle),
        )
        rows.append(
            ExtractedRow(
                source_name="investor_contact_block",
                data=build_row(
                    location_name=override["LOCATION_NAME"],
                    location_address=override["LOCATION_ADDRESS"],
                    state=override["STATE"],
                    city=override["CITY"],
                    postcode=override["POSTCODE"],
                    source_url=INVESTOR_URL,
                    activity=activity,
                    location_name_native=title,
                    location_address_native=address_text,
                ),
            )
        )
    return rows


def write_csv(rows: list[dict[str, str]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(rows)
    df = df[FINAL_COLUMNS]
    df.to_csv(path, index=False, encoding="utf-8-sig")


def main() -> None:
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    session = build_session()
    license_rows = extract_license_rows(session)
    contact_rows = extract_contact_rows(session)

    all_candidates = [*license_rows, *contact_rows]
    final_rows: list[dict[str, str]] = []
    seen: set[str] = set()
    duplicates: list[dict[str, str]] = []
    checkpoint_written = False
    checkpoint_path = TEMP_DIR / f"{FINAL_BASENAME}_checkpoint.csv"

    for candidate in all_candidates:
        row = candidate.data
        key = dedupe_key(row["LOCATION_ADDRESS"], row["CITY"], row["STATE"])
        if key in seen:
            duplicates.append(
                {
                    "source_name": candidate.source_name,
                    "location_name": row["LOCATION_NAME"],
                    "location_address": row["LOCATION_ADDRESS"],
                }
            )
            continue

        seen.add(key)
        final_rows.append(row)

        if len(final_rows) >= CHECKPOINT_THRESHOLD and not checkpoint_written:
            write_csv(final_rows, checkpoint_path)
            checkpoint_written = True

    raw_json_path = TEMP_DIR / f"{FINAL_BASENAME}_raw_rows.json"
    raw_json_path.write_text(json.dumps(final_rows, ensure_ascii=False, indent=2), encoding="utf-8")

    final_output_path = OUTPUT_DIR / f"{FINAL_BASENAME}.csv"
    write_csv(final_rows, final_output_path)

    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "license_rows_found": len(license_rows),
        "contact_rows_found": len(contact_rows),
        "final_unique_rows": len(final_rows),
        "checkpoint_threshold": CHECKPOINT_THRESHOLD,
        "checkpoint_written": checkpoint_written,
        "checkpoint_path": str(checkpoint_path) if checkpoint_written else "",
        "final_output_path": str(final_output_path),
        "duplicates_skipped": duplicates,
        "count_gap": max(0, CHECKPOINT_THRESHOLD - len(final_rows)),
        "post_threshold_extra_rows": max(0, len(final_rows) - CHECKPOINT_THRESHOLD),
        "notes": [
            "Table 0 on the license page provided 34 address-bearing GST rows.",
            "Table 1 on the license page listed TCS GSTINs only and did not contain addresses, so it was not usable for CSV rows.",
            "Investor-relations contact blocks produced one additional unique physical address (MUFG registrar) and one duplicate Eternal corporate-office address already present in the Delhi GST row.",
            "Latitude and longitude were left blank because no coordinates were published on the website.",
        ],
    }
    summary_path = TEMP_DIR / f"{FINAL_BASENAME}_summary.json"
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
