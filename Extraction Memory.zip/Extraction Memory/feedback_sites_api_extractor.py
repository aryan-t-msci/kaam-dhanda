"""
Generic extractor for public "feedback / sites" APIs that expose facility lists.

Pattern handled:
- Corporate websites that power a feedback/contact form from a public JSON endpoint
  such as `/api/.../feedback/sites/v2` and optionally `/api/.../feedback/site/v2`.
- The bulk endpoint returns all facilities with fields like location name, address,
  city, state, postcode, and facility type.

How to reuse:
1. Update the CONFIG block below for the new issuer and endpoint(s).
2. Run the script. It will:
   - download the public JSON
   - filter to the target legal entity if needed
   - clean and dedupe physical facilities
   - write a checkpoint CSV once the requested threshold is reached
   - write the final CSV
   - save a stats JSON and progress JSON

Example:
    python feedback_sites_api_extractor.py
"""

from __future__ import annotations

import csv
import json
import re
import unicodedata
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple
from urllib.request import Request, urlopen


# ============================================================
# CONFIGURATION - Change these for each new issuer
# ============================================================
ISSUER_ID = "IID000000002740831"
ISSUER_NAME = "AVENUE SUPERMARTS LIMITED"
TARGET_COMPANY = "ASL"
BASE_URL = "https://www.dmartindia.com"
SITES_URL = "https://api.dmartindia.com/api/corporate/feedback/sites/v2"
COUNT_URL = (
    "https://api.dmartindia.com/corporate/content/v1"
    "?contentPlaceholder=AboutUs_StoreCount&page=AboutUs"
)
SOURCE_TYPE = "API"
COUNTRY = "India"
COUNTRY_ISO3 = "IND"
COUNT_THRESHOLD = 114
OUTPUT_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS",
    "LOCATION_ADDRESS_NATIVE",
    "LATITUDE",
    "LONGITUDE",
    "coord_source",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
]


@dataclass
class Paths:
    temp_dir: Path
    output_dir: Path
    raw_sites: Path
    raw_count: Path
    progress_json: Path
    checkpoint_csv: Path
    stats_json: Path
    final_csv: Path


def make_paths() -> Paths:
    root = Path(__file__).resolve().parent
    output_dir = root.parent / "Output"
    safe_name = f"{ISSUER_ID}_{ISSUER_NAME}"
    return Paths(
        temp_dir=root,
        output_dir=output_dir,
        raw_sites=root / "dmart_sites.json",
        raw_count=root / "dmart_aboutus_storecount.json",
        progress_json=root / "dmart_asl_progress.json",
        checkpoint_csv=root / f"{safe_name}_checkpoint.csv",
        stats_json=root / f"{safe_name}_stats.json",
        final_csv=output_dir / f"{safe_name}.csv",
    )


def fetch_json(url: str, output_path: Path) -> object:
    req = Request(
        url,
        headers={
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/123.0.0.0 Safari/537.36"
            )
        },
    )
    with urlopen(req, timeout=60) as response:
        data = response.read().decode("utf-8")
    output_path.write_text(data, encoding="utf-8")
    return json.loads(data)


def load_or_fetch_json(url: str, output_path: Path) -> object:
    if output_path.exists():
        return json.loads(output_path.read_text(encoding="utf-8"))
    return fetch_json(url, output_path)


def ascii_transliterate(value: str) -> str:
    if value is None:
        return ""
    text = str(value)
    normalized = unicodedata.normalize("NFKD", text)
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    return ascii_text if ascii_text.strip() else text


def has_non_ascii(value: str) -> bool:
    if value is None:
        return False
    return any(ord(char) > 127 for char in str(value))


def normalize_space(value: str) -> str:
    text = ascii_transliterate(value)
    text = text.replace("\r", " ").replace("\n", " ").replace("\t", " ")
    text = text.replace("#", " ")
    text = re.sub(r"\s*&\s*", " & ", text)
    text = re.sub(r"\s*,\s*", ", ", text)
    text = re.sub(r"\s*\.\s*", ". ", text)
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r",\s*,+", ", ", text)
    text = re.sub(r"\s+([,.;:])", r"\1", text)
    text = text.strip(" ,.;")
    return text


def clean_postcode(value: str) -> str:
    text = normalize_space(value)
    return re.sub(r"[^0-9A-Za-z -]", "", text)


def activity_for_type(location_type: str) -> str:
    mapping = {
        "Store": "Retail supermarket",
        "Distribution Center": "Distribution center and warehousing",
        "Head Office": "Corporate head office",
    }
    return mapping.get(location_type, normalize_space(location_type))


def row_group_key(row: Dict[str, str]) -> Tuple[str, str, str, str, str]:
    return (
        normalize_space(row.get("company", "")).lower(),
        normalize_space(row.get("locationType", "")).lower(),
        normalize_space(row.get("locationName", "")).lower(),
        clean_postcode(row.get("pincode", "")),
        normalize_space(row.get("siteState", "")).lower(),
    )


def score_row(row: Dict[str, str], preferred_city: str) -> Tuple[int, int, int]:
    city = normalize_space(row.get("siteCity", ""))
    address = normalize_space(row.get("address", ""))
    contains_city = int(city.lower() in address.lower()) if city else 0
    preferred = int(city == preferred_city)
    return preferred, contains_city, len(address)


def dedupe_rows(rows: Sequence[Dict[str, str]]) -> Tuple[List[Dict[str, str]], List[Dict[str, object]]]:
    grouped: Dict[Tuple[str, str, str, str, str], List[Dict[str, str]]] = defaultdict(list)
    for row in rows:
        grouped[row_group_key(row)].append(row)

    deduped: List[Dict[str, str]] = []
    duplicate_groups: List[Dict[str, object]] = []

    for key, group in grouped.items():
        if len(group) == 1:
            deduped.append(group[0])
            continue
        city_counter = Counter(normalize_space(item.get("siteCity", "")) for item in group)
        preferred_city = city_counter.most_common(1)[0][0]
        canonical = sorted(
            group,
            key=lambda item: score_row(item, preferred_city),
            reverse=True,
        )[0]
        deduped.append(canonical)
        duplicate_groups.append(
            {
                "group_key": key,
                "duplicate_count": len(group),
                "kept_location_code": canonical.get("locationCode", ""),
                "all_location_codes": [item.get("locationCode", "") for item in group],
                "location_name": canonical.get("locationName", ""),
                "location_type": canonical.get("locationType", ""),
                "postcode": canonical.get("pincode", ""),
                "state": canonical.get("siteState", ""),
            }
        )

    return deduped, duplicate_groups


def build_output_row(row: Dict[str, str]) -> Dict[str, str]:
    location_name_native = str(row.get("locationName", "") or "").strip()
    location_address_native = str(row.get("address", "") or "").strip()
    location_name = normalize_space(location_name_native)
    location_address = normalize_space(location_address_native)
    city = normalize_space(row.get("siteCity", ""))
    state = normalize_space(row.get("siteState", ""))
    postcode = clean_postcode(row.get("pincode", ""))

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": location_name,
        "LOCATION_NAME_NATIVE": location_name_native if has_non_ascii(location_name_native) else "",
        "LOCATION_ADDRESS": location_address,
        "LOCATION_ADDRESS_NATIVE": (
            location_address_native if has_non_ascii(location_address_native) else ""
        ),
        "LATITUDE": "",
        "LONGITUDE": "",
        "coord_source": "not_on_website",
        "COUNTRY": COUNTRY,
        "COUNTRY_ISO3": COUNTRY_ISO3,
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": SITES_URL,
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": activity_for_type(row.get("locationType", "")),
    }


def write_csv(path: Path, rows: Sequence[Dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=OUTPUT_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


def save_progress(progress_path: Path, processed_rows: Sequence[Dict[str, str]]) -> None:
    payload = {
        "processed_count": len(processed_rows),
        "rows": list(processed_rows),
    }
    progress_path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def main() -> None:
    paths = make_paths()

    sites_payload = load_or_fetch_json(SITES_URL, paths.raw_sites)
    count_payload = load_or_fetch_json(COUNT_URL, paths.raw_count)

    if not isinstance(sites_payload, list):
        raise RuntimeError("Expected a list from the sites endpoint.")

    if not isinstance(count_payload, list) or not count_payload:
        raise RuntimeError("Unexpected About Us count payload.")

    about_us_count = (
        str(count_payload[0].get("content", {}).get("body", "")).strip()
        if isinstance(count_payload[0], dict)
        else ""
    )

    company_rows = [
        row for row in sites_payload
        if normalize_space(row.get("company", "")) == TARGET_COMPANY
    ]

    deduped_rows, duplicate_groups = dedupe_rows(company_rows)
    deduped_rows.sort(
        key=lambda row: (
            normalize_space(row.get("siteState", "")),
            normalize_space(row.get("siteCity", "")),
            normalize_space(row.get("locationType", "")),
            normalize_space(row.get("locationName", "")),
        )
    )

    output_rows: List[Dict[str, str]] = []
    for index, row in enumerate(deduped_rows, start=1):
        output_rows.append(build_output_row(row))
        if index % 20 == 0:
            save_progress(paths.progress_json, output_rows)

    save_progress(paths.progress_json, output_rows)

    if len(output_rows) >= COUNT_THRESHOLD:
        write_csv(paths.checkpoint_csv, output_rows[:COUNT_THRESHOLD])

    write_csv(paths.final_csv, output_rows)

    stats = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "source_url": SITES_URL,
        "source_type": SOURCE_TYPE,
        "target_company": TARGET_COMPANY,
        "website_about_us_location_count": about_us_count,
        "raw_site_rows_all_companies": len(sites_payload),
        "raw_site_rows_target_company": len(company_rows),
        "final_rows_after_dedupe": len(output_rows),
        "count_threshold": COUNT_THRESHOLD,
        "location_type_counts_raw_target_company": dict(
            Counter(row.get("locationType", "") for row in company_rows)
        ),
        "location_type_counts_final": dict(
            Counter(row.get("ACTIVITY_AT_ASSET", "") for row in output_rows)
        ),
        "duplicate_groups_collapsed": duplicate_groups,
        "notes": [
            "Coordinates are blank because neither sites/v2 nor site/v2 exposes latitude/longitude.",
            (
                "The About Us content API currently says 439 locations, "
                "while the live feedback/sites API exposes a larger current ASL facility list."
            ),
        ],
    }
    paths.stats_json.write_text(
        json.dumps(stats, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
