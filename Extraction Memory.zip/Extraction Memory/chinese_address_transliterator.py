"""
Post-processing script for Bank of Nanjing output.
Improves transliteration quality and address readability.
Uses a comprehensive replacement-first approach before pypinyin fallback.
"""
import sys, io, csv, re, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

try:
    from pypinyin import lazy_pinyin, Style
    HAS_PYPINYIN = True
except ImportError:
    HAS_PYPINYIN = False

OUTPUT_DIR = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Output"
TEMP_DIR = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Temp"

# Read ebank JSON data for reference
with open(f"{TEMP_DIR}\\ebank_nanjing.json", encoding='utf-8') as f:
    nanjing_data = json.load(f)
with open(f"{TEMP_DIR}\\ebank_beijing.json", encoding='utf-8') as f:
    beijing_data = json.load(f)

# ═══════════════════════════════════════════════════════════
# COMPREHENSIVE CHINESE → ENGLISH MAPPING
# ═══════════════════════════════════════════════════════════

# Administrative unit suffixes - these need spaces before them
ADMIN_SUFFIX_MAP = {
    '省': ' Province',
    '市': ' City',
    '县': ' County',
    '区': ' District',
    '镇': ' Town',
    '乡': ' Township',
    '街道': ' Subdistrict',
    '开发区': ' Development Zone',
    '高新区': ' Hi-Tech Zone',
    '工业园区': ' Industrial Park',
    '经济开发区': ' Economic Development Zone',
    '新区': ' New Area',
    '保税区': ' Bonded Zone',
    '自贸区': ' Free Trade Zone',
    '综合保税区': ' Comprehensive Bonded Zone',
}

# Street type suffixes - these need spaces
STREET_SUFFIX_MAP = {
    '大道': ' Avenue',
    '大街': ' Boulevard',
    '大路': ' Road',
    '路': ' Road',
    '街': ' Street',
    '巷': ' Lane',
    '弄': ' Alley',
    '胡同': ' Hutong',
    '里': ' Li',
}

# Building/unit type
BUILDING_MAP = {
    '号': '',        # number - handled separately
    '幢': ' Building',
    '栋': ' Block',
    '楼': 'F',       # floor
    '层': 'F',
    '室': ' Room',
    '单元': ' Unit',
    '座': ' Tower',
    '号楼': ' Building',
    '号院': ' Compound',
    '号馆': ' Hall',
}

# Comprehensive city/district full-string replacements (ordered by length, longest first)
FULL_STRING_REPLACEMENTS = [
    # Provinces first
    ('江苏省', 'Jiangsu Province'),
    ('浙江省', 'Zhejiang Province'),
    ('山东省', 'Shandong Province'),
    ('广东省', 'Guangdong Province'),
    ('湖北省', 'Hubei Province'),
    ('湖南省', 'Hunan Province'),
    ('四川省', 'Sichuan Province'),
    ('河南省', 'Henan Province'),
    ('河北省', 'Hebei Province'),
    ('辽宁省', 'Liaoning Province'),
    ('安徽省', 'Anhui Province'),
    ('福建省', 'Fujian Province'),
    ('江西省', 'Jiangxi Province'),
    ('陕西省', 'Shaanxi Province'),
    ('山西省', 'Shanxi Province'),
    ('吉林省', 'Jilin Province'),
    ('黑龙江省', 'Heilongjiang Province'),
    ('云南省', 'Yunnan Province'),
    ('贵州省', 'Guizhou Province'),
    ('甘肃省', 'Gansu Province'),
    
    # Direct-controlled municipalities
    ('北京市', 'Beijing'),
    ('上海市', 'Shanghai'),
    ('天津市', 'Tianjin'),
    ('重庆市', 'Chongqing'),
    
    # Jiangsu cities
    ('南京市', 'Nanjing'),
    ('苏州市', 'Suzhou'),
    ('无锡市', 'Wuxi'),
    ('常州市', 'Changzhou'),
    ('南通市', 'Nantong'),
    ('扬州市', 'Yangzhou'),
    ('镇江市', 'Zhenjiang'),
    ('泰州市', 'Taizhou'),
    ('淮安市', "Huai'an"),
    ('盐城市', 'Yancheng'),
    ('宿迁市', 'Suqian'),
    ('连云港市', 'Lianyungang'),
    ('徐州市', 'Xuzhou'),
    
    # Zhejiang cities
    ('杭州市', 'Hangzhou'),
    ('宁波市', 'Ningbo'),
    ('温州市', 'Wenzhou'),
    
    # Key Nanjing districts
    ('玄武区', 'Xuanwu District'),
    ('秦淮区', 'Qinhuai District'),
    ('建邺区', 'Jianye District'),
    ('鼓楼区', 'Gulou District'),
    ('雨花台区', 'Yuhuatai District'),
    ('栖霞区', 'Qixia District'),
    ('浦口区', 'Pukou District'),
    ('六合区', 'Liuhe District'),
    ('溧水区', 'Lishui District'),
    ('高淳区', 'Gaochun District'),
    ('江宁区', 'Jiangning District'),
    
    # Shanghai districts
    ('黄浦区', 'Huangpu District'),
    ('徐汇区', 'Xuhui District'),
    ('长宁区', 'Changning District'),
    ('静安区', "Jing'an District"),
    ('普陀区', 'Putuo District'),
    ('虹口区', 'Hongkou District'),
    ('杨浦区', 'Yangpu District'),
    ('浦东新区', 'Pudong New Area'),
    ('闵行区', 'Minhang District'),
    ('宝山区', 'Baoshan District'),
    ('嘉定区', 'Jiading District'),
    ('金山区', 'Jinshan District'),
    ('松江区', 'Songjiang District'),
    ('青浦区', 'Qingpu District'),
    ('奉贤区', 'Fengxian District'),
    ('崇明区', 'Chongming District'),
    
    # Beijing districts
    ('东城区', 'Dongcheng District'),
    ('西城区', 'Xicheng District'),
    ('朝阳区', 'Chaoyang District'),
    ('海淀区', 'Haidian District'),
    ('丰台区', 'Fengtai District'),
    ('石景山区', 'Shijingshan District'),
    ('门头沟区', 'Mentougou District'),
    ('房山区', 'Fangshan District'),
    ('通州区', 'Tongzhou District'),
    ('顺义区', 'Shunyi District'),
    ('昌平区', 'Changping District'),
    ('大兴区', 'Daxing District'),
    ('怀柔区', 'Huairou District'),
    ('平谷区', 'Pinggu District'),
    ('密云区', 'Miyun District'),
    ('延庆区', 'Yanqing District'),
    
    # Suzhou districts
    ('姑苏区', 'Gusu District'),
    ('虎丘区', 'Huqiu District'),
    ('吴中区', 'Wuzhong District'),
    ('相城区', 'Xiangcheng District'),
    ('吴江区', 'Wujiang District'),
    ('昆山市', 'Kunshan City'),
    ('太仓市', 'Taicang City'),
    ('常熟市', 'Changshu City'),
    ('张家港市', 'Zhangjiagang City'),
    ('苏州工业园区', 'Suzhou Industrial Park'),
    ('苏州高新区', 'Suzhou Hi-Tech District'),
    
    # Wuxi districts  
    ('梁溪区', 'Liangxi District'),
    ('锡山区', 'Xishan District'),
    ('惠山区', 'Huishan District'),
    ('滨湖区', 'Binhu District'),
    ('新吴区', 'Xinwu District'),
    ('江阴市', "Jiang'yin City"),
    ('宜兴市', 'Yixing City'),
    ('无锡国家高新技术产业开发区', 'Wuxi National Hi-Tech Development Zone'),
    ('无锡高新区', 'Wuxi Hi-Tech Zone'),
    
    # Changzhou districts
    ('天宁区', 'Tianning District'),
    ('钟楼区', 'Zhonglou District'),
    ('新北区', 'Xinbei District'),
    ('武进区', 'Wujin District'),
    ('金坛区', 'Jintan District'),
    ('溧阳市', 'Liyang City'),
    
    # Hangzhou districts
    ('上城区', 'Shangcheng District'),
    ('拱墅区', 'Gongshu District'),
    ('西湖区', 'Xihu District'),
    ('滨江区', 'Binjiang District'),
    ('萧山区', 'Xiaoshan District'),
    ('余杭区', 'Yuhang District'),
    ('富阳区', 'Fuyang District'),
    ('临安区', "Lin'an District"),
    ('临平区', 'Linping District'),
    ('钱塘区', 'Qiantang District'),
    
    # Nantong
    ('崇川区', 'Chongchuan District'),
    ('通州区', 'Tongzhou District'),
    ('海安市', 'Hai\'an City'),
    ('如皋市', "Rugao City"),
    ('启东市', 'Qidong City'),
    ('如东县', 'Rudong County'),
    
    # Other common terms
    ('号', ''),
    ('大厦', ' Tower'),
    ('广场', ' Plaza'),
    ('中心', ' Center'),
    ('国际', ' International'),
    ('金融', ' Finance'),
    ('银行', ' Bank'),
    ('大楼', ' Building'),
    ('写字楼', ' Office Building'),
    ('商务中心', ' Business Center'),
    ('科技园', ' Science Park'),
    ('商业街', ' Commercial Street'),
    ('金融街', ' Finance Street'),
    ('步行街', ' Pedestrian Street'),
]

def translate_address(cn_addr):
    """
    Translate a Chinese address to English using comprehensive replacement mapping.
    """
    if not cn_addr:
        return cn_addr
    
    result = cn_addr
    
    # Apply all full-string replacements (longest first to avoid partial matches)
    for cn, en in FULL_STRING_REPLACEMENTS:
        result = result.replace(cn, en)
    
    # Now handle remaining Chinese characters with pypinyin
    if HAS_PYPINYIN:
        # Process character by character
        parts = []
        i = 0
        while i < len(result):
            c = result[i]
            if '\u4e00' <= c <= '\u9fff' or '\u3400' <= c <= '\u4dbf':
                # Get a run of Chinese characters
                j = i
                while j < len(result) and ('\u4e00' <= result[j] <= '\u9fff' or '\u3400' <= result[j] <= '\u4dbf'):
                    j += 1
                cn_chunk = result[i:j]
                pinyin_words = lazy_pinyin(cn_chunk, style=Style.NORMAL)
                # Capitalize each word
                pinyin_str = ' '.join(w.capitalize() for w in pinyin_words)
                parts.append(pinyin_str)
                i = j
            else:
                parts.append(c)
                i += 1
        result = ''.join(parts)
    
    # Clean up
    result = re.sub(r'\s+', ' ', result).strip()
    result = result.replace('#', 'No.')
    
    return result

def translate_branch_name(cn_name):
    """Translate a Chinese branch name to English."""
    if not cn_name:
        return cn_name
    
    result = cn_name
    
    # Branch type translations
    branch_types = [
        ('营业部', ' Operations Department'),
        ('营业厅', ' Business Hall'),
        ('储蓄所', ' Savings Office'),
        ('储蓄部', ' Savings Department'),
        ('中心支行', ' Center Sub-Branch'),
        ('副中心支行', ' Sub-Center Branch'),
        ('支行', ' Sub-Branch'),
        ('分理处', ' Sub-Branch Office'),
        ('分行', ' Branch'),
        ('办事处', ' Representative Office'),
        ('代表处', ' Representative Office'),
    ]
    
    # Apply branch type translations first
    for cn, en in branch_types:
        result = result.replace(cn, en)
    
    # Apply area/city translations
    city_maps = [
        ('南京', 'Nanjing'),
        ('北京', 'Beijing'),
        ('上海', 'Shanghai'),
        ('苏州', 'Suzhou'),
        ('无锡', 'Wuxi'),
        ('杭州', 'Hangzhou'),
        ('常州', 'Changzhou'),
        ('南通', 'Nantong'),
        ('扬州', 'Yangzhou'),
        ('镇江', 'Zhenjiang'),
        ('泰州', 'Taizhou'),
        ('淮安', "Huai'an"),
        ('盐城', 'Yancheng'),
        ('宿迁', 'Suqian'),
        ('连云港', 'Lianyungang'),
        ('徐州', 'Xuzhou'),
    ]
    for cn, en in city_maps:
        result = result.replace(cn, en)
    
    # Convert remaining Chinese with pypinyin
    if HAS_PYPINYIN:
        parts = []
        i = 0
        while i < len(result):
            c = result[i]
            if '\u4e00' <= c <= '\u9fff' or '\u3400' <= c <= '\u4dbf':
                j = i
                while j < len(result) and ('\u4e00' <= result[j] <= '\u9fff' or '\u3400' <= result[j] <= '\u4dbf'):
                    j += 1
                cn_chunk = result[i:j]
                pinyin_words = lazy_pinyin(cn_chunk, style=Style.NORMAL)
                pinyin_str = ' '.join(w.capitalize() for w in pinyin_words)
                parts.append(pinyin_str)
                i = j
            else:
                parts.append(c)
                i += 1
        result = ''.join(parts)
    
    result = re.sub(r'\s+', ' ', result).strip()
    return result

# ═══════════════════════════════════════════════════════════
# MAIN POST-PROCESSING
# ═══════════════════════════════════════════════════════════

def main():
    print("Reading input CSV...")
    csv_path = f"{OUTPUT_DIR}\\IID000000002159087_BANK OF NANJING CO., LTD..csv"
    
    with open(csv_path, encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        records = list(reader)
    
    print(f"Total records: {len(records)}")
    
    # Re-process all records with improved transliteration
    print("Applying improved transliteration...")
    
    # Track issues
    issues = []
    
    for i, rec in enumerate(records):
        cn_name = rec['FACILITY_NAME_LOCAL']
        cn_addr = rec['FACILITY_ADDRESS_LOCAL']
        
        # Skip subsidiary records (already have proper English)
        if rec.get('RELEVANT_URL', '') in [
            'https://www.nanyinwealth.com/',
            'https://boncfc.com/',
            'https://www.xyamc.com/',
        ]:
            continue
        
        # Re-transliterate
        new_name = translate_branch_name(cn_name)
        new_addr = translate_address(cn_addr)
        
        # Validation: address must not be blank
        if not new_addr.strip():
            issues.append(f"Row {i}: Empty address for {cn_name}")
            new_addr = cn_addr  # Fallback to original
        
        rec['FACILITY_NAME'] = new_name
        rec['FACILITY_ADDRESS'] = new_addr
    
    if issues:
        print(f"Issues found: {len(issues)}")
        for issue in issues:
            print(f"  {issue}")
    
    # Check for any remaining Chinese in English fields
    chinese_in_name = [(i, r) for i, r in enumerate(records) 
                       if any('\u4e00' <= c <= '\u9fff' for c in r['FACILITY_NAME'])]
    chinese_in_addr = [(i, r) for i, r in enumerate(records) 
                       if any('\u4e00' <= c <= '\u9fff' for c in r['FACILITY_ADDRESS'])]
    
    print(f"After re-processing:")
    print(f"  Chinese in FACILITY_NAME: {len(chinese_in_name)}")
    print(f"  Chinese in FACILITY_ADDRESS: {len(chinese_in_addr)}")
    
    if chinese_in_addr[:5]:
        print("  Remaining Chinese in address (sample):")
        for i, r in chinese_in_addr[:5]:
            print(f"    [{i}] {r['FACILITY_ADDRESS_LOCAL']} -> {r['FACILITY_ADDRESS']}")
    
    # Show sample of improved records
    print()
    print("Sample records after re-processing:")
    for rec in records[:5]:
        print(f"  [{rec['FACILITY_NAME_LOCAL']}]")
        print(f"    -> {rec['FACILITY_NAME']}")
        print(f"  [{rec['FACILITY_ADDRESS_LOCAL']}]")
        print(f"    -> {rec['FACILITY_ADDRESS']}")
        print()
    
    # Save updated CSV
    columns = list(records[0].keys())
    output_path = f"{OUTPUT_DIR}\\IID000000002159087_BANK OF NANJING CO., LTD..csv"
    
    with open(output_path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction='ignore')
        writer.writeheader()
        for rec in records:
            writer.writerow(rec)
    
    print(f"Updated CSV saved: {output_path}")
    print(f"Total records: {len(records)}")

if __name__ == '__main__':
    main()
