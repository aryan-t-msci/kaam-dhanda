"""
Radware-protected branch-detail enumerator.

This extractor handles locator pages that:
- require a headed-browser bootstrap to satisfy Radware / Bot Manager,
- expose a dynamic session header on a real search request, and
- reveal complete location records through an enumerable HTML detail endpoint
  such as `...costCentreCode={code}&details=true`.

How to adapt it for a new issuer:
- update the config block with the issuer details, locator URL, and detail path;
- confirm the live search request still yields the required dynamic header;
- tune the enumerated code range if the site uses a different namespace.

Checkpoint behavior:
- As soon as the configured COUNT threshold is reached, write a checkpoint CSV.
- Continue scanning the remaining code range and then write the final CSV.

Usage:
    python radware_branch_detail_enumerator.py
"""

from __future__ import annotations

import csv
import json
import math
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from email.utils import parseaddr
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import requests
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright

requests.packages.urllib3.disable_warnings()  # type: ignore[attr-defined]


# ============================================================
# CONFIGURATION - Edit this block for each new issuer
# ============================================================
ISSUER_ID = "IID000000002134538"
ISSUER_NAME = "FIRSTRAND LIMITED"
COUNT_THRESHOLD = 19

LOCATOR_URL = "https://www.fnb.co.za/locators/branch-locator.html"
DETAIL_PATH = "/Controller?nav=locators.BranchLocatorSearch&costCentreCode={code}&details=true"

COUNTRY = "South Africa"
COUNTRY_ISO3 = "ZAF"
SOURCE_TYPE = "COMPANY WEBSITE"
SOURCE_URL = LOCATOR_URL

TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")

CHECKPOINT_CSV = TEMP_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_checkpoint.csv"
FINAL_CSV = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
RUN_SUMMARY_JSON = TEMP_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_summary.json"
RAW_JSON = TEMP_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_raw_rows.json"
PROGRESS_JSON = TEMP_DIR / f"{ISSUER_ID}_progress.json"

MAX_COST_CENTRE = 10000
MIN_VALID_HTML_BYTES = 30000
WORKERS = 16
PROGRESS_SAVE_EVERY = 20
VERIFY_TLS = False


# ============================================================
# GENERIC EXTRACTION LOGIC - Do not modify per-issuer
# ============================================================

POSTCODE_RE = re.compile(r"\b\d{4}\b")
EMAIL_RE = re.compile(r"\b[^@\s]+@[^@\s]+\.[^@\s]+\b", re.I)
PHONE_RE = re.compile(r"\(?0\d{2,3}\)?[\s-]?\d{3}[\s-]?\d{4}")
COORD_RE = re.compile(r"maps\.google\.com/\?q=([-\d.]+),([-\d.]+)")


CITY_PRIORITY = [
    "Cape Town",
    "Johannesburg",
    "Durban",
    "Pretoria",
    "Sandton",
    "Bloemfontein",
    "Gqeberha",
    "Port Elizabeth",
    "East London",
    "Mthatha",
    "George",
    "Mossel Bay",
    "Paarl",
    "Stellenbosch",
    "Bellville",
    "Somerset West",
    "Worcester",
    "Vredenburg",
    "Richards Bay",
    "Pietermaritzburg",
    "Ballito",
    "Newcastle",
    "Ladysmith",
    "Empangeni",
    "Ulundi",
    "Polokwane",
    "Makhado",
    "Thohoyandou",
    "Tzaneen",
    "Mokopane",
    "Musina",
    "Lephalale",
    "Nelspruit",
    "Mbombela",
    "Middelburg",
    "Emalahleni",
    "Witbank",
    "Ermelo",
    "Secunda",
    "Klerksdorp",
    "Potchefstroom",
    "Mahikeng",
    "Rustenburg",
    "Brits",
    "Welkom",
    "Bethlehem",
    "Kroonstad",
    "Sasolburg",
    "Kimberley",
    "Upington",
    "Kuruman",
    "Colesberg",
    "Grahamstown",
    "Makhanda",
    "Alexandra",
    "Centurion",
    "Roodepoort",
    "Randburg",
    "Soweto",
    "Benoni",
    "Boksburg",
    "Kempton Park",
    "Alberton",
    "Krugersdorp",
    "Springs",
    "Vereeniging",
    "Midrand",
]


CITY_TO_PROVINCE = {
    "alexandra": "Gauteng",
    "alberton": "Gauteng",
    "ballito": "KwaZulu-Natal",
    "bellville": "Western Cape",
    "benoni": "Gauteng",
    "bethlehem": "Free State",
    "bloemfontein": "Free State",
    "boksburg": "Gauteng",
    "brits": "North West",
    "cape town": "Western Cape",
    "centurion": "Gauteng",
    "colesberg": "Northern Cape",
    "durban": "KwaZulu-Natal",
    "east london": "Eastern Cape",
    "emalahleni": "Mpumalanga",
    "empangeni": "KwaZulu-Natal",
    "ermelo": "Mpumalanga",
    "george": "Western Cape",
    "gqeberha": "Eastern Cape",
    "grahamstown": "Eastern Cape",
    "heidelberg": "Gauteng",
    "johannesburg": "Gauteng",
    "kempton park": "Gauteng",
    "kimberley": "Northern Cape",
    "klerksdorp": "North West",
    "kroonstad": "Free State",
    "krugersdorp": "Gauteng",
    "kuruman": "Northern Cape",
    "ladysmith": "KwaZulu-Natal",
    "lephalale": "Limpopo",
    "mafikeng": "North West",
    "mahikeng": "North West",
    "makhanda": "Eastern Cape",
    "makhado": "Limpopo",
    "mbombela": "Mpumalanga",
    "middelburg": "Mpumalanga",
    "midrand": "Gauteng",
    "mokopane": "Limpopo",
    "mossel bay": "Western Cape",
    "mthatha": "Eastern Cape",
    "musina": "Limpopo",
    "newcastle": "KwaZulu-Natal",
    "nelspruit": "Mpumalanga",
    "paarl": "Western Cape",
    "pietermaritzburg": "KwaZulu-Natal",
    "polokwane": "Limpopo",
    "port elizabeth": "Eastern Cape",
    "potchefstroom": "North West",
    "pretoria": "Gauteng",
    "randburg": "Gauteng",
    "richards bay": "KwaZulu-Natal",
    "roodepoort": "Gauteng",
    "rustenburg": "North West",
    "sandton": "Gauteng",
    "sasolburg": "Free State",
    "secunda": "Mpumalanga",
    "somerset west": "Western Cape",
    "soweto": "Gauteng",
    "springs": "Gauteng",
    "stellenbosch": "Western Cape",
    "thohoyandou": "Limpopo",
    "tzaneen": "Limpopo",
    "ulundi": "KwaZulu-Natal",
    "upington": "Northern Cape",
    "vereeniging": "Gauteng",
    "vredenburg": "Western Cape",
    "welkom": "Free State",
    "witbank": "Mpumalanga",
    "worcester": "Western Cape",
}

CITY_ALIASES = {
    "alexandra": "Johannesburg",
    "bankcity": "Johannesburg",
    "braamfontein": "Johannesburg",
    "fordsburg": "Johannesburg",
    "glenvista": "Johannesburg",
    "highlands north": "Johannesburg",
    "marshalltown": "Johannesburg",
    "newtown": "Johannesburg",
    "parktown": "Johannesburg",
    "southdale": "Johannesburg",
    "umtata": "Mthatha",
}


thread_local = threading.local()


@dataclass
class RawBranch:
    cost_centre_code: str
    branch_code: str
    branch_name: str
    branch_type: str
    address: str
    latitude: str
    longitude: str
    source_url: str
    raw_text: str


@dataclass
class BootstrapState:
    cookies: List[dict]
    uzlc: str


def ensure_dirs() -> None:
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def bootstrap_fnb_state() -> BootstrapState:
    with sync_playwright() as pw:
        browser = pw.chromium.launch(
            channel="msedge",
            headless=False,
            args=["--disable-blink-features=AutomationControlled"],
        )
        ctx = browser.new_context()
        page = ctx.new_page()
        page.add_init_script(
            "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
        )
        captured_requests: List[dict] = []

        def on_request(req) -> None:
            if "Controller?nav=locators.BranchLocatorSearch" in req.url:
                captured_requests.append({"url": req.url, "headers": req.headers})

        page.on("request", on_request)
        page.goto(LOCATOR_URL, wait_until="domcontentloaded", timeout=60000)
        page.wait_for_timeout(7000)
        try:
            page.locator("button:has-text('Accept all cookies')").click(timeout=5000)
            page.wait_for_timeout(1500)
        except Exception:
            pass
        page.fill("input[name='branchName']", "Johannesburg")
        page.keyboard.press("Enter")
        page.wait_for_timeout(5000)
        cookies = ctx.cookies()
        uzlc = ""
        if captured_requests:
            uzlc = captured_requests[-1]["headers"].get("uzlc", "")
        browser.close()
        return BootstrapState(cookies=cookies, uzlc=uzlc)


def make_session(state: BootstrapState) -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0"
            ),
            "Referer": LOCATOR_URL,
            "X-Requested-With": "XMLHttpRequest",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Accept": "text/html, */*; q=0.01",
            "DNT": "1",
        }
    )
    if state.uzlc:
        session.headers["uzlc"] = state.uzlc
    for cookie in state.cookies:
        session.cookies.set(
            cookie["name"],
            cookie["value"],
            domain=cookie.get("domain"),
            path=cookie.get("path"),
        )
    return session


def get_thread_session(state: BootstrapState) -> requests.Session:
    session = getattr(thread_local, "session", None)
    if session is None:
        session = make_session(state)
        thread_local.session = session
    return session


def fetch_detail_html(code: int, state: BootstrapState) -> Tuple[int, Optional[str]]:
    session = get_thread_session(state)
    url = f"https://www.fnb.co.za{DETAIL_PATH.format(code=code)}"
    payload = f"nav=locators.BranchLocatorSearch&costCentreCode={code}&details=true"
    for attempt in range(3):
        try:
            resp = session.post(url, data=payload, timeout=20, verify=VERIFY_TLS)
            text = resp.text
        except Exception:
            text = ""
            resp = None
        if resp is not None and resp.status_code == 200:
            if len(text) >= MIN_VALID_HTML_BYTES and "Branch Code" in text and "Latitude" in text:
                return code, text
        time.sleep(0.25 * (attempt + 1))
    return code, None


def clean_text(value: str) -> str:
    value = re.sub(r"\s+", " ", value or "").strip()
    return value


def is_email(value: str) -> bool:
    return bool(EMAIL_RE.search(value))


def is_phone(value: str) -> bool:
    candidate = re.sub(r"\s+", " ", value or "").strip()
    if not candidate:
        return False
    return bool(PHONE_RE.search(candidate)) or bool(parseaddr(candidate)[1] == "")


def extract_heading(soup: BeautifulSoup) -> str:
    heading = soup.find("h2")
    return clean_text(heading.get_text(" ", strip=True)) if heading else ""


def extract_address(soup: BeautifulSoup) -> str:
    for strong in soup.find_all("strong"):
        text = clean_text(strong.get_text(" ", strip=True))
        if text and "," in text and "Longitude" not in text and "Latitude" not in text:
            return text
    text = clean_text(soup.get_text(" ", strip=True))
    match = re.search(r"Close\s+(.+?)\s+Longitude", text)
    if match:
        merged = clean_text(match.group(1))
        if " " in merged:
            parts = merged.split(" ", 1)
            if len(parts) == 2 and "," in parts[1]:
                return parts[1]
    return ""


def extract_label_value_pairs(soup: BeautifulSoup) -> Dict[str, str]:
    pairs: Dict[str, str] = {}
    for div in soup.select("div.readOut"):
        lines = [clean_text(piece) for piece in div.stripped_strings]
        if len(lines) >= 2:
            label = lines[0]
            value = " ".join(lines[1:])
            pairs[label] = clean_text(value)
    return pairs


def extract_coordinates(soup: BeautifulSoup) -> Tuple[str, str]:
    map_link = soup.find("a", href=re.compile(r"maps\.google\.com/\?q="))
    if map_link:
        match = COORD_RE.search(map_link.get("href", ""))
        if match:
            # Google `q=` uses `latitude,longitude`.
            return match.group(2), match.group(1)
    longitude = ""
    latitude = ""
    for p in soup.find_all("p"):
        text = clean_text(p.get_text(" ", strip=True))
        if text.startswith("Longitude"):
            longitude = clean_text(text.replace("Longitude", "", 1))
        elif text.startswith("Latitude"):
            latitude = clean_text(text.replace("Latitude", "", 1))
    return longitude, latitude


def parse_branch_detail(code: int, html: str) -> Optional[RawBranch]:
    soup = BeautifulSoup(html, "html.parser")
    branch_name = extract_heading(soup)
    address = extract_address(soup)
    label_values = extract_label_value_pairs(soup)
    branch_code = label_values.get("Branch Code", "")
    branch_type = label_values.get("Branch Type", "")
    longitude, latitude = extract_coordinates(soup)

    if not branch_name or not address or not branch_code:
        return None

    return RawBranch(
        cost_centre_code=str(code),
        branch_code=branch_code,
        branch_name=branch_name,
        branch_type=branch_type,
        address=address,
        latitude=latitude,
        longitude=longitude,
        source_url=SOURCE_URL,
        raw_text=clean_text(soup.get_text(" ", strip=True)),
    )


def infer_postcode(address: str) -> str:
    match = POSTCODE_RE.search(address)
    return match.group(0) if match else ""


def infer_city(address: str, branch_name: str) -> str:
    address_clean = clean_text(address)
    for city in CITY_PRIORITY:
        if re.search(rf"\b{re.escape(city)}\b", address_clean, re.I):
            return CITY_ALIASES.get(city.lower(), city)
    parts = [clean_text(part) for part in address_clean.split(",") if clean_text(part)]
    if parts:
        tail = parts[-1]
        tail = re.sub(r"\b\d{4}\b", "", tail)
        tail = clean_text(tail)
        if tail and not re.search(r"\d", tail):
            words = tail.split()
            if 1 <= len(words) <= 3:
                normalized = CITY_ALIASES.get(tail.lower(), tail.title())
                return normalized
    if re.search(r"\bBankcity\b", branch_name, re.I):
        return "Johannesburg"
    return ""


def infer_state(city: str, address: str) -> str:
    if city:
        state = CITY_TO_PROVINCE.get(city.lower())
        if state:
            return state
    address_clean = clean_text(address)
    for city_name, province in CITY_TO_PROVINCE.items():
        if re.search(rf"\b{re.escape(city_name)}\b", address_clean, re.I):
            return province
    return ""


def build_activity(branch_type: str) -> str:
    branch_type = clean_text(branch_type)
    return f"Retail banking branch ({branch_type})" if branch_type else "Retail banking branch"


def dedupe_records(records: Iterable[RawBranch]) -> List[RawBranch]:
    deduped: Dict[str, RawBranch] = {}
    for record in records:
        key = record.branch_code or record.cost_centre_code
        existing = deduped.get(key)
        if existing is None or len(record.address) > len(existing.address):
            deduped[key] = record
    return sorted(deduped.values(), key=lambda r: (r.branch_name.lower(), r.branch_code))


def to_output_row(record: RawBranch) -> Dict[str, str]:
    city = infer_city(record.address, record.branch_name)
    state = infer_state(city, record.address)
    postcode = infer_postcode(record.address)
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": record.branch_name,
        "LOCATION_ADDRESS": record.address.replace("#", "").strip(),
        "LATITUDE": record.latitude,
        "LONGITUDE": record.longitude,
        "COUNTRY": COUNTRY,
        "COUNTRY_ISO3": COUNTRY_ISO3,
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": record.source_url,
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": build_activity(record.branch_type),
        "coord_source": "website" if record.latitude and record.longitude else "Not from website",
    }


def output_columns() -> List[str]:
    return [
        "ISSUER_ID",
        "ISSUER_NAME",
        "LOCATION_NAME",
        "LOCATION_ADDRESS",
        "LATITUDE",
        "LONGITUDE",
        "COUNTRY",
        "COUNTRY_ISO3",
        "POSTCODE",
        "STATE",
        "CITY",
        "SOURCE_URL",
        "SOURCE_TYPE",
        "ACTIVITY_AT_ASSET",
        "coord_source",
    ]


def write_csv(path: Path, rows: List[Dict[str, str]]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=output_columns())
        writer.writeheader()
        writer.writerows(rows)


def write_json(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def enumerate_valid_branches(state: BootstrapState) -> List[RawBranch]:
    found: List[RawBranch] = []
    checkpoint_written = False
    started = time.time()

    with ThreadPoolExecutor(max_workers=WORKERS) as executor:
        futures = {
            executor.submit(fetch_detail_html, code, state): code
            for code in range(1, MAX_COST_CENTRE + 1)
        }
        for idx, future in enumerate(as_completed(futures), start=1):
            code, html = future.result()
            if html:
                record = parse_branch_detail(code, html)
                if record:
                    found.append(record)
                    deduped = dedupe_records(found)
                    if not checkpoint_written and len(deduped) >= COUNT_THRESHOLD:
                        checkpoint_rows = [to_output_row(item) for item in deduped]
                        write_csv(CHECKPOINT_CSV, checkpoint_rows)
                        checkpoint_written = True
            if idx % PROGRESS_SAVE_EVERY == 0:
                deduped_count = len(dedupe_records(found))
                write_json(
                    PROGRESS_JSON,
                    {
                        "scanned_codes": idx,
                        "latest_code": code,
                        "valid_records": len(found),
                        "deduped_records": deduped_count,
                        "elapsed_seconds": round(time.time() - started, 2),
                    },
                )

    return dedupe_records(found)


def main() -> None:
    ensure_dirs()
    started = time.time()
    state = bootstrap_fnb_state()
    raw_records = enumerate_valid_branches(state)
    rows = [to_output_row(record) for record in raw_records]

    # Drop rows that still violate the no-city/no-address rule.
    rows = [row for row in rows if row["LOCATION_ADDRESS"] and row["CITY"]]
    rows.sort(key=lambda row: (row["CITY"].lower(), row["LOCATION_NAME"].lower()))

    write_csv(FINAL_CSV, rows)
    write_json(
        RAW_JSON,
        [record.__dict__ for record in raw_records],
    )
    write_json(
        RUN_SUMMARY_JSON,
        {
            "issuer_id": ISSUER_ID,
            "issuer_name": ISSUER_NAME,
            "final_row_count": len(rows),
            "checkpoint_csv": str(CHECKPOINT_CSV),
            "final_csv": str(FINAL_CSV),
            "elapsed_minutes": round((time.time() - started) / 60, 2),
            "max_cost_centre": MAX_COST_CENTRE,
        },
    )

    print(f"Rows exported: {len(rows)}")
    print(f"Checkpoint: {CHECKPOINT_CSV}")
    print(f"Final CSV: {FINAL_CSV}")


if __name__ == "__main__":
    main()
