# ============================================================================
#  run_batch.ps1  -  SCALED RUN (50-issuer scale test)
#  codex exec per-issuer orchestrator, with resume + failure-safe pool
# ----------------------------------------------------------------------------
#  PURPOSE: validate the proven codex-exec per-issuer loop AT SCALE (default 50
#  issuers: >=25% heaviest + remainder random) before the full ~500 universe. Same
#  per-worker mechanism as run_batch_poc.ps1, plus the three things a longer
#  unattended run actually needs:
#    1. RESUME-SKIP   - re-running the SAME input skips already-completed issuers
#                       (state in done_iids.txt). Survives usage-window stalls.
#    2. FAILURE-SAFE  - a worker that dies / usage-limits with no output does NOT
#                       crash the pool; it is logged and left for the next re-run.
#    3. HALT-ON-STALL - N consecutive empty workers (usage limit / environment)
#                       -> stop cleanly with a resume hint instead of burning the
#                       plan window on failing workers.
#    4. DYNAMIC CAP   - the parallel worker count is auto-sized to the machine (RAM +
#                       cores), gated on live free RAM, and backed off if codex rejects
#                       workers. -WorkerCap 0 = auto (default); a positive value forces a
#                       fixed cap. The codex usage window cannot be queried, so it is
#                       handled empirically (admission + backoff + halt-on-stall), NOT by
#                       trying to "detect" an allowed concurrency up front.
#  Encoding is pinned on every orchestrator-written file (the recurring bug class).
#
#  SCOPE (kept deliberately close to the proven PoC):
#    - main pass only, raw URLs (no URL-classifier step yet)
#    - simple promotion (copy staging -> output); canonical-schema merge is a
#      separate production step, intentionally NOT done here
#    - NO GEOCODING: coordinates kept only if present in the source. The workflow
#      (prompt.md section 5c) was changed to forbid geocoding entirely.
#
#  REALISTIC RUNTIME: at ~20-40 min/issuer and cap=3, 50 issuers is several hours
#  and will likely hit the rolling 5h / weekly plan window. That is expected: when
#  it halts, re-run the SAME command after the window resets - it resumes.
#
#  THE THREE WINDOWS BUGS ARE PRE-FIXED (path quoting, stderr banner, node PID).
# ----------------------------------------------------------------------------
#  USAGE (all optional):
#    powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch.ps1"
#    powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch.ps1" -Limit 50           # cap auto-sized
#    powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch.ps1" -WorkerCap 4         # force a fixed cap of 4
#    powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch.ps1" -InputFile "C:\path\to\file.xlsx"
#    # force a clean start (ignore previous progress for this input):
#    powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch.ps1" -Fresh
# ============================================================================

param(
    [string]$Model     = "gpt-5.4",
    [string]$Reasoning = "high",
    [string]$InputFile = "C:\Users\tiwaary\Downloads\asset_completeness_ondemand_batch7&8 - straive copy.xlsx",
    [string]$OutputRoot   = "C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Output",
    [string]$TempRoot     = "C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp",
    [string]$MemoryFolder = "",   # blank = use the folder this script lives in (recommended); set only to point elsewhere
    [string]$ScopeDoc     = "",   # blank = use SCOPE_METHODOLOGY.md in MEMORY_FOLDER; set to a path or URL to override the scope/ownership methodology
    [int]$Limit        = 50,
    [int]$WorkerCap    = 0,   # 0 = auto-size to the machine (see CONFIG); a positive value forces a fixed cap
    [int]$Seed         = 0,   # 0 = random draw (a NEW sample on each -Fresh); a positive value reproduces a specific draw
    [int]$MinYieldFloor       = 3,    # results with fewer rows than this are always retried once (degenerate-output guard)
    [double]$MinYieldFraction = 0.30, # also retry if rows < this fraction of the reference COUNT...
    [int]$YieldOkAbs          = 25,   # ...but NEVER retry a result with >= this many rows (guards against unreliable COUNTs)
    [string[]]$IssuerIds      = @(),  # run EXACTLY these issuer ids (bypasses sampling) - for targeted / validation runs
    [string]$RunTag           = "",   # suffix appended to the run key, to isolate a run in its own temp / output folders
    [int]$MaxWorkerMinutes    = 90,   # a worker running longer than this (active minutes) with no DONE is killed as stuck
    [switch]$Fresh
)

# ============================ CONFIG ========================================
$MODEL      = $Model
$REASONING  = $Reasoning
$INPUT_FILE = $InputFile
$RUN_LIMIT  = $Limit
$MIN_YIELD_FLOOR    = $MinYieldFloor      # retry any result below this many rows (absolute degenerate guard)
$MIN_YIELD_FRACTION = $MinYieldFraction   # retry if rows < fraction * reference COUNT (only for small results)
$YIELD_OK_ABS       = $YieldOkAbs         # results with >= this many rows are accepted as-is (COUNT may be unreliable)
# $WORKER_CAP is resolved after the logger is set up (auto-sized when -WorkerCap is 0).

# Paths. Defaults below are used unless you override them with -OutputRoot / -TempRoot
# (and, rarely, -MemoryFolder) on the command line.
# TIP: for large runs, point -TempRoot and -OutputRoot at a LOCAL (non-OneDrive) folder
# to avoid OneDrive "automatic file downloads" popups and sync contention.
# MEMORY_FOLDER defaults to the folder this script lives in, so the system always uses the
# prompts + KB sitting next to run_batch.ps1 (no stale hardcoded path). It can stay on OneDrive.
$MEMORY_FOLDER = if ([string]::IsNullOrWhiteSpace($MemoryFolder)) { $PSScriptRoot } else { $MemoryFolder }
$SCOPE_DOC     = if ([string]::IsNullOrWhiteSpace($ScopeDoc)) { Join-Path $MEMORY_FOLDER 'SCOPE_METHODOLOGY.md' } else { $ScopeDoc }
$TEMP_ROOT     = $TempRoot
$OUTPUT_ROOT   = $OutputRoot

# Pool / resilience knobs
$POLL_SECONDS        = 20    # how often to check for completions / failures
$MAX_WORKER_MINUTES  = $MaxWorkerMinutes  # a worker running longer than this (active min) with no DONE = stuck (killed)
$FAIL_HALT_THRESHOLD = 3     # this many consecutive empty workers -> halt with resume hint

# Dynamic worker-cap sizing (used when -WorkerCap is 0): auto-size to the machine from
# real RAM + cores (NO fixed numeric ceiling), gate admission on live free RAM, and back
# off if codex pushes back. RAM is the primary limit (each worker runs a browser + python);
# cores are secondary. The live free-RAM gate is the real-time crash guard.
$PER_WORKER_RAM_GB = 2.5   # estimated peak RAM per worker; tune for your sites
$OS_RESERVE_GB     = 4.0   # RAM held back for the OS, orchestrator, OneDrive, disk cache
$MIN_FREE_RAM_GB   = 2.0   # admission gate: do not spawn while live free RAM is below this
$CORE_RESERVE      = 1     # logical cores left for the OS / orchestrator
$CAP_FLOOR         = 1     # always allow at least this many (the upper bound is derived from RAM + cores, below)
$FAST_FAIL_MINUTES = 3     # an empty worker dying faster than this = likely codex rate/concurrency pushback -> back off

# Codex CLI location
$NodeExe = "node"
$CodexJs = "C:\Users\tiwaary\AppData\Roaming\npm\node_modules\@openai\codex\bin\codex.js"
# ============================================================================

$ErrorActionPreference = "Stop"

# Stable run identity (NOT timestamped) so re-runs of the SAME input resume.
$inputName = [System.IO.Path]::GetFileNameWithoutExtension($INPUT_FILE) -replace '[^A-Za-z0-9_]', '_'
$RUN_KEY   = "Run_$inputName$RunTag"
$runTemp   = Join-Path $TEMP_ROOT $RUN_KEY
$runOut    = Join-Path $OUTPUT_ROOT $RUN_KEY
# Aliases so the proven PoC parser / spawn / promote code is reused verbatim:
$batchId   = $RUN_KEY
$batchTemp = $runTemp
$batchOut  = $runOut

$logDir       = Join-Path $runTemp 'logs'
$statusDir    = Join-Path $runTemp 'status'
$stagingDir   = Join-Path $runTemp 'staging'
$attemptsDir  = Join-Path $runTemp 'attempts'        # stashed first-attempt CSVs for the yield-retry gate
$progressFile = Join-Path $runTemp 'progress.jsonl'
$doneIdsFile  = Join-Path $runTemp 'done_iids.txt'
$reviewIdsFile= Join-Path $runTemp 'review_iids.txt' # issuers promoted via low-yield union (flagged for review)
$runStamp     = Get-Date -Format "yyyyMMdd_HHmmss"
$logFile      = Join-Path $logDir "run_$runStamp.log"

foreach ($d in @($runTemp, $runOut, $logDir, $statusDir, $stagingDir, $attemptsDir,
                 (Join-Path $runTemp 'workers'),
                 (Join-Path $runTemp 'exhaustion_proof'),
                 (Join-Path $runTemp 'reject'),
                 (Join-Path $runTemp 'gap'))) {
    New-Item -ItemType Directory -Force -Path $d | Out-Null
}

function Write-Log($msg) {
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] $msg"
    Write-Host $line
    try { Add-Content -LiteralPath $logFile -Value $line -Encoding utf8 } catch { }
}

# Auto-size the parallel worker cap to this machine: cap = min(RAM-bound, core-bound),
# with NO hardcoded numeric ceiling. The live admission gate still checks real-time free
# RAM before each spawn (the actual crash guard), and the cap backs off if codex rejects
# workers. RAM is primary (each worker runs a browser + python); cores are secondary.
function Get-AutoCap {
    try {
        $os       = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        $totalGB  = [math]::Round(($os.TotalVisibleMemorySize * 1KB) / 1GB, 1)
        $usableGB = [math]::Max(0, $totalGB - $OS_RESERVE_GB)
        $cores    = [Environment]::ProcessorCount
        $byRam    = [int][math]::Floor($usableGB / $PER_WORKER_RAM_GB)
        $byCore   = $cores - $CORE_RESERVE
        $cap      = [math]::Min($byRam, $byCore)   # machine-derived ceiling: RAM- and core-bound, no fixed cap
        if ($cap -lt $CAP_FLOOR) { $cap = $CAP_FLOOR }
        Write-Log "Auto-sizing cap: cores=$cores totalRAM=${totalGB}GB usableRAM=${usableGB}GB perWorker=${PER_WORKER_RAM_GB}GB -> byRAM=$byRam byCores=$byCore -> CAP=$cap (floor=$CAP_FLOOR; ceiling=min(byRAM,byCores); live free-RAM gate enforces real-time safety)"
        return [int]$cap
    } catch {
        Write-Log "Auto-sizing failed ($($_.Exception.Message)); falling back to cap=2."
        return 2
    }
}

# Live admission gate: $false when free RAM is below the floor, so the pool waits for
# headroom instead of over-subscribing (which causes OOM-killed workers = wasted tokens).
function Can-Admit-Worker {
    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        $freeGB = [math]::Round(($os.FreePhysicalMemory * 1KB) / 1GB, 1)
        if ($freeGB -lt $MIN_FREE_RAM_GB) {
            Write-Log "  (holding spawn: free RAM ${freeGB}GB < ${MIN_FREE_RAM_GB}GB - waiting for headroom)"
            return $false
        }
        return $true
    } catch { return $true }
}

# Resolve the cap: manual when -WorkerCap > 0, else auto-sized to the machine.
if ($WorkerCap -gt 0) { $WORKER_CAP = [int]$WorkerCap; $capMode = "manual" }
else                  { $WORKER_CAP = Get-AutoCap;     $capMode = "auto"   }
$effectiveCap = $WORKER_CAP   # may be reduced at runtime if codex pushes back

# ---- 1. Prerequisites ------------------------------------------------------
Write-Log "run_batch starting (SCALE TEST: $RUN_LIMIT issuers: >=25% heaviest + remainder random)."

# Keep the machine awake for the whole run so it does not sleep mid-batch (which
# freezes the orchestrator + workers). Released automatically when this process exits.
try {
    Add-Type -Namespace Win32 -Name Power -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError=true)]
public static extern uint SetThreadExecutionState(uint esFlags);
'@ -ErrorAction Stop
    [void][Win32.Power]::SetThreadExecutionState([uint32]2147483649)  # ES_CONTINUOUS(0x80000000) | ES_SYSTEM_REQUIRED(0x1)
    Write-Log "  sleep suppression ON for this run (system kept awake)."
} catch {
    Write-Log "  (could not enable sleep suppression: $($_.Exception.Message); disable sleep manually for long runs)"
}
Write-Log "  Model=$MODEL | Reasoning=$REASONING | WorkerCap=$WORKER_CAP ($capMode)"
Write-Log "  InputFile=$INPUT_FILE"
Write-Log "  MemoryFolder=$MEMORY_FOLDER"
Write-Log "  ScopeDoc=$SCOPE_DOC"
Write-Log "  Output=$OUTPUT_ROOT"
Write-Log "  Temp=$TEMP_ROOT"
Write-Log "  Run key=$RUN_KEY (stable - re-run the same command to resume)"
if (-not (Test-Path -LiteralPath $CodexJs)) { throw "codex.js not found at: $CodexJs" }
if (-not (Test-Path -LiteralPath (Join-Path $MEMORY_FOLDER 'WORKER_PROMPT.md'))) {
    throw "WORKER_PROMPT.md not found in MEMORY_FOLDER: $MEMORY_FOLDER"
}
if (-not (Test-Path -LiteralPath $INPUT_FILE)) { throw "INPUT_FILE not found: $INPUT_FILE" }

# ---- 2. Parse input (proven parser; returns ALL issuers, heaviest-first) ---
$parseScript = Join-Path $batchTemp '_parse_input.py'
@"
import json, sys, traceback, re
from pathlib import Path
try:
    from openpyxl import load_workbook
except Exception as e:
    print(json.dumps({'error': f'openpyxl not available: {e}'})); sys.exit(0)

def norm(s):
    return ''.join(ch.lower() for ch in str(s) if ch.isalnum())

def clip(s, n=60):
    s = '' if s is None else str(s)
    s = ' '.join(s.split())
    return s if len(s) <= n else s[:n] + '...'

ID_KEYS    = ('issuerid', 'iid', 'msciissuerid')
NAME_KEYS  = ('companyname', 'issuername', 'company', 'issuer', 'entityname', 'name')
COUNT_KEYS = ('expectedcount', 'totalassets', 'assetcount', 'expectedassets', 'count')
URL_KEYS   = ('relevanturl', 'relevanturls', 'sourceurl', 'sourceurls', 'companyurl', 'companywebsite', 'website', 'websites', 'weburl', 'homepage', 'webpage', 'url', 'urls', 'link', 'links')
ALL_KEYS   = ID_KEYS + NAME_KEYS + COUNT_KEYS + URL_KEYS

def is_url_col(k):
    # a column is a URL column if its header is a URL alias, optionally suffixed with
    # digits (relevanturl, relevanturl1, url2, website3, ...). This catches BOTH the long
    # layout (one URL column, many rows per issuer) and the wide layout (URL_1, URL_2, ...
    # in a single row). Lookalikes such as 'urlpurpose' / 'urltype' are excluded because
    # their suffix is not numeric.
    for a in URL_KEYS:
        if k.startswith(a):
            rest = k[len(a):]
            if rest == '' or rest.isdigit():
                return True
    return False

def split_urls(cell):
    # one cell may hold several URLs separated by newlines / commas / semicolons / pipes / spaces
    out = []
    for p in re.split(r'[\s,;|]+', str(cell).strip()):
        p = p.strip()
        if p and ('.' in p or p.lower().startswith('http')):
            out.append(p)
    return out

def find_header_row(rows, scan=25):
    best_i, best_score = None, 0
    limit = min(scan, len(rows))
    for i in range(limit):
        r = rows[i]
        if not r: continue
        keys = {norm(c) for c in r if c is not None and str(c).strip() != ''}
        if not keys: continue
        score = sum(1 for k in ALL_KEYS if k in keys)
        has_id = any(k in keys for k in ID_KEYS)
        if has_id and score > best_score:
            best_score, best_i = score, i
    if best_i is not None:
        return best_i
    for i in range(limit):
        if rows[i] and any(c is not None and str(c).strip() != '' for c in rows[i]):
            return i
    return 0

def colmap(header_row):
    h = {}
    for idx, c in enumerate(header_row):
        k = norm(c)
        if k and k not in h:
            h[k] = idx
    def pick(keys):
        for k in keys:
            if k in h: return h[k]
        return None
    return h, pick

try:
    inp = Path(r'''$INPUT_FILE''')
    if not inp.exists():
        print(json.dumps({'error': f'input file does not exist: {inp}'})); sys.exit(0)
    wb = load_workbook(inp, read_only=True, data_only=True)
    sheets = wb.sheetnames

    issuers = {}
    sheet_diag = []
    total_id_rows = 0
    iid_rows = 0
    non_iid_samples = []

    for sname in sheets:
        ws = wb[sname]
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            sheet_diag.append({'sheet': clip(sname, 40), 'header_row': None, 'cols': {}, 'headers': [], 'sample': []})
            continue
        hr = find_header_row(rows)
        header_row = rows[hr] if hr < len(rows) else []
        h, pick = colmap(header_row)
        c_id  = pick(ID_KEYS)
        c_nm  = pick(NAME_KEYS)
        c_ct  = pick(COUNT_KEYS)
        url_cols = sorted(idx for k, idx in h.items() if is_url_col(k))
        headers_disp = [clip(c, 60) for c in header_row][:40]
        sample_row = []
        for r in rows[hr+1:]:
            if r and any(c is not None and str(c).strip() != '' for c in r):
                sample_row = [clip(c, 40) for c in r][:40]; break
        sheet_diag.append({'sheet': clip(sname, 40), 'header_row': hr,
                           'cols': {'id': c_id, 'name': c_nm, 'count': c_ct, 'urlcols': url_cols},
                           'headers': headers_disp, 'sample': sample_row})
        if c_id is None:
            continue
        for r in rows[hr+1:]:
            if not r: continue
            raw_id = r[c_id] if c_id < len(r) else None
            if raw_id is None or str(raw_id).strip() == '': continue
            sid = str(raw_id).strip()
            total_id_rows += 1
            if not sid.startswith('IID'):
                if len(non_iid_samples) < 5: non_iid_samples.append(clip(sid, 40))
                continue
            iid_rows += 1
            if sid not in issuers:
                issuers[sid] = {'name': '', 'count': None, 'urls': []}
            if c_nm is not None and c_nm < len(r) and r[c_nm] not in (None, ''):
                nm = str(r[c_nm]).strip()
                if nm and not issuers[sid]['name']:
                    issuers[sid]['name'] = nm
            if c_ct is not None and c_ct < len(r) and r[c_ct] not in (None, ''):
                try:
                    ct = int(float(str(r[c_ct]).replace(',', '').strip()))
                    issuers[sid]['count'] = ct if issuers[sid]['count'] is None else max(issuers[sid]['count'], ct)
                except: pass
            for ci in url_cols:
                if ci < len(r) and r[ci] not in (None, ''):
                    for url in split_urls(r[ci]):
                        if url not in issuers[sid]['urls']:
                            issuers[sid]['urls'].append(url)

    diag = {'sheets': [clip(s, 40) for s in sheets],
            'per_sheet': sheet_diag,
            'rows_with_id': total_id_rows,
            'iid_rows': iid_rows,
            'non_iid_id_samples': non_iid_samples}

    if not issuers:
        print(json.dumps({'error': 'no IID issuers found', 'diagnostics': diag})); sys.exit(0)

    ordered = sorted(issuers.items(), key=lambda kv: (kv[1]['count'] if kv[1]['count'] is not None else -1), reverse=True)
    out = [{'issuer_id': k, 'issuer_name': v['name'], 'count': v['count'], 'urls': v['urls']} for k, v in ordered]
    print(json.dumps(out))
except Exception as e:
    print(json.dumps({'error': f'{type(e).__name__}: {e}', 'traceback': traceback.format_exc()})); sys.exit(0)
"@ | Set-Content -LiteralPath $parseScript -Encoding UTF8

Write-Log "Parsing input workbook..."

# Find a working Python interpreter (the helper shells out to Python for xlsx parsing).
$pythonCmd = $null
foreach ($cand in @('python', 'py', 'python3')) {
    $resolved = Get-Command $cand -ErrorAction SilentlyContinue
    if ($resolved) { $pythonCmd = $resolved.Source; break }
}
if (-not $pythonCmd) {
    throw "No Python interpreter found on PATH (tried python, py, python3). The parse step needs Python + openpyxl. Install Python, then: pip install openpyxl"
}
Write-Log "  using Python: $pythonCmd"

# --- KB shard bootstrap (one-time; the tool self-skips if KB\ is already populated) ---
# The knowledge base is stored as per-record shards under KB\. On a fresh setup these are
# generated once from KB_DETAIL.md; thereafter the workers write each new learned record
# straight into KB\, so this call self-skips and never regenerates over existing shards.
$shardTool = Join-Path $PSScriptRoot 'Tools\shard_kb.py'
if (Test-Path -LiteralPath $shardTool) {
    Write-Log "  Ensuring KB is sharded (per-record KB\ files)..."
    & $pythonCmd $shardTool 2>&1 | ForEach-Object { Write-Log "    [shard] $_" }
}

# Run the parser, capturing BOTH stdout and stderr so failures are visible.
$stdOutFile = Join-Path $batchTemp '_parse_stdout.txt'
$stdErrFile = Join-Path $batchTemp '_parse_stderr.txt'
$proc = Start-Process -FilePath $pythonCmd -ArgumentList @("`"$parseScript`"") `
        -NoNewWindow -Wait -PassThru `
        -RedirectStandardOutput $stdOutFile -RedirectStandardError $stdErrFile
$parsedJson = if (Test-Path $stdOutFile) { Get-Content -LiteralPath $stdOutFile -Raw } else { "" }
$parseErr   = if (Test-Path $stdErrFile) { Get-Content -LiteralPath $stdErrFile -Raw } else { "" }

if ([string]::IsNullOrWhiteSpace($parsedJson)) {
    $errTail = if ($parseErr) { (($parseErr -split "\r?\n") | Select-Object -Last 40) -join "`n" } else { "(stderr was empty)" }
    Write-Host "Parser produced NO stdout. Last lines of stderr:"
    Write-Host $errTail
    Write-Host "Full stderr saved to: $stdErrFile"
    throw "Parser produced no output (exit code $($proc.ExitCode)). Most likely openpyxl is not installed for this Python. Full stderr at: $stdErrFile"
}

try {
    $parsed = $parsedJson | ConvertFrom-Json
} catch {
    $head = if ($parsedJson.Length -gt 1500) { $parsedJson.Substring(0,1500) + " ...[truncated - see file]" } else { $parsedJson }
    Write-Host "Could not parse the parser's JSON. First 1500 chars of raw output:"
    Write-Host $head
    Write-Host "Full raw parser output saved to: $stdOutFile"
    throw "Could not parse the parser's JSON output. Full raw output at: $stdOutFile"
}

# A parser ERROR is a SINGLE object carrying a non-empty 'error' field.
# A SUCCESS is a JSON array of issuer objects (ConvertFrom-Json unwraps a
# 1-element array to a single object, handled by the @() wrap below). Testing
# `if ($parsed.error)` directly is unsafe: on an array, member-enumeration
# returns one $null per element, and PowerShell treats a multi-element
# collection as truthy -> a false "parse failed" even though parsing worked.
$parserError = ''
if ($parsed -isnot [System.Array]) {
    if (@($parsed.PSObject.Properties.Name) -contains 'error') {
        $parserError = "$($parsed.error)".Trim()
    }
}
if ($parserError -ne '') {
    Write-Host ""
    Write-Host "PARSE FAILED: $parserError"
    if ((@($parsed.PSObject.Properties.Name) -contains 'diagnostics') -and $parsed.diagnostics) {
        Write-Host "--- diagnostics (bounded; safe to paste back) ---"
        $parsed.diagnostics | ConvertTo-Json -Depth 6
        Write-Host "-------------------------------------------------"
    }
    Write-Host "Full raw parser output saved to: $stdOutFile"
    throw "Parse failed: $parserError"
}

# ---- 3. Select the issuer set: >=25% heaviest + random remainder ----------
# Composition (per spec): at least 25% of the run is the heaviest issuers; the
# remaining (up to 75%) is a random sample from the rest of the file. This is a
# more representative test than heaviest-only, which over-favours large locator-
# driven retailers. A draw happens only when no selection exists yet (first run,
# or after -Fresh): it uses a random entropy seed, so each -Fresh = a NEW sample,
# unless -Seed N is passed to reproduce a specific draw. The chosen set is PERSISTED
# to selection_iids.txt, so non-Fresh re-runs reuse the SAME set (resume-safe).
$allRanked = @($parsed)
if ($allRanked.Count -eq 0) {
    throw "Parser returned 0 issuers. Check the input file format / sheet names."
}
$selectionFile = Join-Path $runTemp 'selection_iids.txt'

if ($Fresh) {
    Write-Log "-Fresh specified: clearing previous progress, selection, and ALL prior run artifacts for this run key."
    Remove-Item -LiteralPath $doneIdsFile   -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $progressFile  -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $selectionFile -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $reviewIdsFile -ErrorAction SilentlyContinue
    # Wipe the per-run working state AND the output folder so a fresh run truly RE-EXTRACTS.
    # Without this, leftover DONE flags + staging CSVs from a prior run are promoted instantly
    # (the worker never finishes), making a re-run silently reuse stale results.
    foreach ($d in @($stagingDir, $statusDir, $attemptsDir, $runOut,
                     (Join-Path $runTemp 'workers'),
                     (Join-Path $runTemp 'exhaustion_proof'),
                     (Join-Path $runTemp 'reject'),
                     (Join-Path $runTemp 'gap'))) {
        if (Test-Path -LiteralPath $d) {
            Remove-Item -Path (Join-Path $d '*') -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

$byId = @{}; foreach ($it in $allRanked) { $byId[$it.issuer_id] = $it }

if ($IssuerIds.Count -gt 0) {
    # Explicit override (targeted / validation run): run EXACTLY these ids, bypassing sampling.
    # Neither reads nor writes selection_iids.txt, so any production selection is left untouched.
    $target = @()
    foreach ($wanted in $IssuerIds) {
        $w = "$wanted".Trim()
        if ($w -and $byId.ContainsKey($w)) { $target += $byId[$w] }
        elseif ($w) { Write-Log "  ! requested issuer id not found in input: $w" }
    }
    Write-Log "IssuerIds override: running $($target.Count) explicitly-requested issuer(s); sampling bypassed."
} elseif (Test-Path -LiteralPath $selectionFile) {
    # Resume: reuse the exact set chosen on the first run (order preserved).
    $selIds = @(Get-Content -LiteralPath $selectionFile | ForEach-Object { $_.Trim() } | Where-Object { $_ })
    $target = @($selIds | ForEach-Object { $byId[$_] } | Where-Object { $_ })
    Write-Log "Reusing persisted selection: $($target.Count) issuers (resume-safe)."
} else {
    $takeTotal = [math]::Min($RUN_LIMIT, $allRanked.Count)
    $heavyN    = [int][math]::Ceiling($takeTotal * 0.25)   # at least 25% heaviest
    if ($heavyN -lt 1) { $heavyN = 1 }
    if ($heavyN -gt $takeTotal) { $heavyN = $takeTotal }
    $randomN   = $takeTotal - $heavyN                       # remainder (<= 75%) random
    $heavy = @($allRanked | Select-Object -First $heavyN)
    $rest  = @($allRanked | Select-Object -Skip $heavyN)
    # Seed: -Seed N forces a reproducible draw; otherwise a random entropy seed is
    # used, so each draw (i.e. each -Fresh) yields a NEW sample. The chosen set is
    # persisted below, so non-Fresh re-runs reuse it (resume-safe).
    if ($Seed -gt 0) { $seed = [int]$Seed } else { $seed = Get-Random -Minimum 1 -Maximum 2147483647 }
    $rng = New-Object System.Random($seed)
    $randomPick = @($rest | Sort-Object { $rng.Next() } | Select-Object -First $randomN)
    $target = @($heavy + $randomPick)
    @($target | ForEach-Object { $_.issuer_id }) | Set-Content -LiteralPath $selectionFile -Encoding ascii
    Write-Log "Selected $($target.Count) issuers = $heavyN heaviest + $randomN random (of $($allRanked.Count) in file; seed=$seed)."
}
if ($target.Count -eq 0) { throw "Issuer selection is empty (check selection_iids.txt / input)." }

# done_iids.txt is the authoritative resume signal (pure ASCII; one IID per line)
$doneSet = @{}
if (Test-Path -LiteralPath $doneIdsFile) {
    foreach ($line in (Get-Content -LiteralPath $doneIdsFile)) {
        $id = $line.Trim()
        if ($id) { $doneSet[$id] = $true }
    }
}
$alreadyDone = @($target | Where-Object { $doneSet.ContainsKey($_.issuer_id) })
$queue       = @($target | Where-Object { -not $doneSet.ContainsKey($_.issuer_id) })

Write-Log "Target this run: $($target.Count) (of $($allRanked.Count) in file). Already done: $($alreadyDone.Count). To process now: $($queue.Count)."
if ($queue.Count -eq 0) {
    Write-Log "All $($target.Count) target issuers already completed. Nothing to do."
    Write-Log "Output: $runOut"
    return
}
foreach ($it in ($queue | Select-Object -First 10)) {
    Write-Log "  queued: $($it.issuer_id) | $($it.issuer_name) | target=$($it.count) | urls=$($it.urls.Count)"
}
if ($queue.Count -gt 10) { Write-Log "  ... and $($queue.Count - 10) more" }

# ---- 4. Worker spawn helper (BUGS PRE-FIXED; reused verbatim from the PoC) --
function Spawn-Worker($issuer, $workerId) {
    $iid = $issuer.issuer_id
    $safeName = ($issuer.issuer_name -replace '[\\/:*?"<>|]', '_')
    # A stashed attempt1 CSV means the yield gate is asking for an aggressive retry pass.
    $isRetry  = Test-Path -LiteralPath (Join-Path $attemptsDir "$iid.attempt1.csv")
    $passType = if ($isRetry) { 'rework' } else { 'main' }
    # Clear any stale completion artifacts for this issuer so the orchestrator waits for THIS
    # worker's fresh output rather than promoting leftover staging from an earlier run.
    Remove-Item -LiteralPath (Join-Path $statusDir "${iid}_DONE.flag") -Force -ErrorAction SilentlyContinue
    Get-ChildItem -LiteralPath $stagingDir -Filter "*$iid*.csv" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
    $queueFile = Join-Path $batchTemp "workers\${iid}_queue.md"
    $logFile   = Join-Path $batchTemp "workers\${iid}_worker.log"
    $lastFile  = Join-Path $batchTemp "workers\${iid}_last.txt"

    # Build the worker queue file (exact format from ORCHESTRATOR_PROMPT O-1b)
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine("# Worker Queue - Single Issuer")
    [void]$sb.AppendLine("# Batch: $batchId")
    [void]$sb.AppendLine("# Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') | Pass: $passType")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("From MEMORY_FOLDER, read and execute:")
    [void]$sb.AppendLine("1. prompt.md")
    [void]$sb.AppendLine("2. WORKER_PROMPT.md")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("## PARAMETERS")
    [void]$sb.AppendLine("ISSUER_ID     : $iid")
    [void]$sb.AppendLine("ISSUER_NAME   : $($issuer.issuer_name)")
    [void]$sb.AppendLine("COUNT         : $($issuer.count)")
    [void]$sb.AppendLine("WORKER_ID     : $workerId")
    [void]$sb.AppendLine("MODEL         : $MODEL")
    [void]$sb.AppendLine("REASONING     : $REASONING")
    [void]$sb.AppendLine("MEMORY_FOLDER : $MEMORY_FOLDER")
    [void]$sb.AppendLine("SCOPE_METHODOLOGY : $SCOPE_DOC")
    [void]$sb.AppendLine("BATCH_TEMP    : $batchTemp")
    [void]$sb.AppendLine("BATCH_OUTPUT  : $batchOut")
    [void]$sb.AppendLine("STAGING_DIR   : $(Join-Path $batchTemp 'staging')")
    [void]$sb.AppendLine("STATUS_DIR    : $(Join-Path $batchTemp 'status')")
    [void]$sb.AppendLine("PROOF_DIR     : $(Join-Path $batchTemp 'exhaustion_proof')")
    [void]$sb.AppendLine("REJECT_DIR    : $(Join-Path $batchTemp 'reject')")
    [void]$sb.AppendLine("GAP_DIR       : $(Join-Path $batchTemp 'gap')")
    [void]$sb.AppendLine("BATCH_ID      : $batchId")
    [void]$sb.AppendLine("PASS_TYPE     : $passType")
    if ($isRetry) {
        [void]$sb.AppendLine("RETRY_MODE    : aggressive")
        [void]$sb.AppendLine("# Previous attempt returned a thin result. Re-run with maximum effort:")
        [void]$sb.AppendLine("# repeat hardened locator discovery if no locator was found, then mine")
        [void]$sb.AppendLine("# Tier 3 filings + Tier 4 secondary sources exhaustively (see WORKER_PROMPT.md).")
    }
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("## URLS")
    [void]$sb.AppendLine("| URL | URL_Type | URL_Purpose | Confidence |")
    [void]$sb.AppendLine("|-----|----------|-------------|------------|")
    foreach ($u in $issuer.urls) {
        $cleanU = $u -replace '\|', '%7C'
        [void]$sb.AppendLine("| $cleanU | unknown | Unknown | 0.5 |")
    }
    Set-Content -LiteralPath $queueFile -Value $sb.ToString() -Encoding UTF8

    # Generate a launcher script. BUG FIX #2: ErrorActionPreference=Continue so
    # codex's stderr banner is not treated as a fatal NativeCommandError.
    $launcherFile = Join-Path $batchTemp "workers\${iid}_launch.ps1"
    $launcher = @"
`$ErrorActionPreference = 'Continue'
Get-Content -Raw -LiteralPath '$queueFile' | & '$NodeExe' '$CodexJs' exec - --skip-git-repo-check --dangerously-bypass-approvals-and-sandbox -m '$MODEL' -c 'model_reasoning_effort="$REASONING"' -C '$MEMORY_FOLDER' -o '$lastFile' *> '$logFile'
"@
    Set-Content -LiteralPath $launcherFile -Value $launcher -Encoding UTF8

    # BUG FIX #1: launch with -Command "& '...'" (robust for paths with spaces),
    # not -File (which truncates at the first space in OneDrive paths).
    $argList = @('-NoProfile','-ExecutionPolicy','Bypass','-Command', "& '$launcherFile'")
    $proc = Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -WindowStyle Hidden -PassThru

    # BUG FIX #3: resolve the real node.exe worker PID (not the wrapper PID),
    # by matching the unique _last.txt marker in its command line.
    $marker = "${iid}_last.txt"
    $nodePid = $null
    for ($i = 0; $i -lt 12; $i++) {
        Start-Sleep -Milliseconds 500
        $np = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
              Where-Object { $_.Name -eq 'node.exe' -and $_.CommandLine -like "*$marker*" } |
              Select-Object -First 1
        if ($np) { $nodePid = [int]$np.ProcessId; break }
    }
    Write-Log "  spawned worker $workerId for $iid ($($issuer.issuer_name)) | node pid=$nodePid"
    return [pscustomobject]@{
        issuer_id = $iid; worker_id = $workerId; node_pid = $nodePid
        launcher_pid = $proc.Id; spawned_at = (Get-Date)
    }
}

# ---- 5. Progress + promotion helpers --------------------------------------
function Record-Done($iid, $name, $rows, $flag = '') {
    Add-Content -LiteralPath $doneIdsFile -Value $iid -Encoding ascii
    $rec = [pscustomobject]@{ iid=$iid; name=$name; status='done'; rows=$rows; flag=$flag; ts=(Get-Date -Format 'o') }
    Add-Content -LiteralPath $progressFile -Value ($rec | ConvertTo-Json -Compress) -Encoding utf8
}
function Record-Failed($iid, $name, $why) {
    $rec = [pscustomobject]@{ iid=$iid; name=$name; status='failed'; reason=$why; ts=(Get-Date -Format 'o') }
    Add-Content -LiteralPath $progressFile -Value ($rec | ConvertTo-Json -Compress) -Encoding utf8
}
function Get-StagingCsv($iid) {
    return (Get-ChildItem -LiteralPath $stagingDir -Filter "*$iid*.csv" -ErrorAction SilentlyContinue | Select-Object -First 1)
}
function Count-CsvRows($path) {
    return ((Get-Content -LiteralPath $path | Measure-Object -Line).Lines - 1)
}
# Append an issuer to review_iids.txt (id + reason), de-duplicated by id.
function Flag-Review($iid, $reason) {
    $have = @()
    if (Test-Path -LiteralPath $reviewIdsFile) {
        $have = @(Get-Content -LiteralPath $reviewIdsFile -ErrorAction SilentlyContinue | ForEach-Object { ($_ -split "\s+")[0] })
    }
    if ($have -notcontains $iid) {
        Add-Content -LiteralPath $reviewIdsFile -Value ("{0}`t{1}" -f $iid, $reason) -Encoding ascii
    }
}

# Yield-aware completion handler. Promotes a finished worker's output if it is
# substantial; if it is suspiciously thin it stashes the result and asks for ONE
# retry. If the retry is ALSO thin, it promotes the UNION of both attempts and
# flags the issuer for review. Returns 'promoted' | 'promoted_flagged' | 'retry' | 'failed'.
function Resolve-Completion($iid, $name, $issuer) {
    $cand = Get-StagingCsv $iid
    if (-not $cand) {
        Write-Log "  ! $iid reported DONE but no staging CSV found"
        Record-Failed $iid $name 'done_flag_no_csv'
        return 'failed'
    }
    $rows = Count-CsvRows $cand.FullName
    # Did the worker itself declare a gap (sources do not cover the full universe)?
    $doneFlag = Join-Path $statusDir "${iid}_DONE.flag"
    $isGap = $false
    if (Test-Path -LiteralPath $doneFlag) {
        try { $isGap = [bool](Select-String -LiteralPath $doneFlag -SimpleMatch 'STATUS=gap' -Quiet) } catch { $isGap = $false }
    }
    $ref  = 0; try { $ref = [int]$issuer.count } catch { $ref = 0 }
    $fracThr = 0
    if ($MIN_YIELD_FRACTION -gt 0 -and $ref -gt 0) { $fracThr = [int][math]::Ceiling($MIN_YIELD_FRACTION * $ref) }
    # thin = clearly degenerate (below the floor), OR a small result below the fractional bar.
    # The < YIELD_OK_ABS guard means substantial results are never retried even if COUNT is unreliable.
    $thin = ($rows -lt $MIN_YIELD_FLOOR) -or
            ($fracThr -gt 0 -and $rows -lt $fracThr -and $rows -lt $YIELD_OK_ABS)
    $stash = Join-Path $attemptsDir "$iid.attempt1.csv"

    if (-not $thin) {
        $dest = Join-Path $runOut $cand.Name
        Copy-Item -LiteralPath $cand.FullName -Destination $dest -Force
        if ($isGap) {
            Write-Log "  promoted $iid -> output ($rows rows) - worker declared a GAP, flagged for review"
            Flag-Review $iid 'worker_gap'
        } else {
            Write-Log "  promoted $iid -> output ($rows rows)"
        }
        Record-Done $iid $name $rows $(if ($isGap) { 'WORKER_GAP_REVIEW' } else { '' })
        return 'promoted'
    }

    if (-not (Test-Path -LiteralPath $stash)) {
        # First thin attempt: stash it, clear the DONE flag + staging CSV, re-queue ONE retry.
        Copy-Item -LiteralPath $cand.FullName -Destination $stash -Force
        Remove-Item -LiteralPath $cand.FullName -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath (Join-Path $statusDir "${iid}_DONE.flag") -Force -ErrorAction SilentlyContinue
        Write-Log "  ~ $iid LOW YIELD ($rows rows; ref=$ref) - stashed attempt 1, re-queuing ONE retry"
        return 'retry'
    }

    # Second thin attempt: promote the UNION of both attempts and flag for review.
    $dest = Join-Path $runOut $cand.Name
    $u = $rows
    try {
        $canonTool = Join-Path $PSScriptRoot 'canonicalize_output.py'
        $out = & $pythonCmd $canonTool --union $dest $stash $cand.FullName 2>&1
        $m = ($out | Select-String 'UNION_ROWS=(\d+)' | Select-Object -First 1)
        if ($m) { $u = [int]$m.Matches[0].Groups[1].Value }
        else    { Copy-Item -LiteralPath $cand.FullName -Destination $dest -Force }
    } catch {
        Copy-Item -LiteralPath $cand.FullName -Destination $dest -Force
        Write-Log "    (union step failed: $($_.Exception.Message); promoted attempt 2 alone)"
    }
    Write-Log "  ! $iid LOW YIELD on retry too - promoted UNION of 2 attempts ($u rows) - FLAGGED FOR REVIEW"
    Flag-Review $iid 'low_yield_union'
    Record-Done $iid $name $u 'LOW_YIELD_UNION_REVIEW'
    return 'promoted_flagged'
}

# Update pool counters / re-queue based on a Resolve-Completion result.
function Handle-Result($res, $w) {
    switch ($res) {
        'promoted'         { $script:promotedCount++; $script:consecFails = 0 }
        'promoted_flagged' { $script:promotedCount++; $script:consecFails = 0 }
        'retry'            { $script:queue += $w.issuer; $script:consecFails = 0 }
        'failed'           { $script:failedCount++;   $script:consecFails++ }
    }
}

# ---- 6. Rolling pool: resume + failure-safe + halt-on-stall ----------------
$queueIndex    = 0
$active        = @{}    # iid -> worker info (incl. spawned_at, node_pid, launcher_pid)
$promotedCount = 0
$failedCount   = 0
$consecFails   = 0
$haltStall     = $false
$frozenMin     = 0.0    # cumulative minutes the box was asleep/stalled (so stuck-timers ignore sleep)
$lastTick      = $null  # wall-clock of the previous monitor iteration (to detect a sleep gap)

function Try-Spawn-Next {
    if ($script:queueIndex -lt $script:queue.Count) {
        $it = $script:queue[$script:queueIndex]; $script:queueIndex++
        $w = Spawn-Worker $it ("{0:D2}" -f $script:queueIndex)
        $w | Add-Member -NotePropertyName issuer      -NotePropertyValue $it              -Force
        $w | Add-Member -NotePropertyName frozen_base -NotePropertyValue $script:frozenMin -Force
        $script:active[$it.issuer_id] = $w
    }
}

Write-Log "Starting rolling pool (cap=$effectiveCap, $capMode; spawns gated on live free RAM)..."
while ($active.Count -lt $effectiveCap -and $queueIndex -lt $queue.Count) {
    if (-not (Can-Admit-Worker)) { break }
    Try-Spawn-Next
}

while ($active.Count -gt 0) {
    Start-Sleep -Seconds $POLL_SECONDS
    # Detect a sleep/stall gap: if this iteration took far longer than the poll
    # interval, the box was likely asleep. Credit that time so timeouts ignore it.
    $tick = Get-Date
    if ($lastTick) {
        $gapSec = ($tick - $lastTick).TotalSeconds
        if ($gapSec -gt ($POLL_SECONDS * 3)) {
            $extra = ($gapSec - $POLL_SECONDS) / 60.0
            $frozenMin += $extra
            Write-Log "  (detected ~$([math]::Round($extra,1)) min gap - system sleep/stall; not counting it against worker timeouts)"
        }
    }
    $lastTick = $tick

    $remove = @()
    foreach ($iid in @($active.Keys)) {
        $w = $active[$iid]
        $name = $w.issuer.issuer_name
        $doneFlag = Join-Path $statusDir "${iid}_DONE.flag"

        if (Test-Path -LiteralPath $doneFlag) {
            $res = Resolve-Completion $iid $name $w.issuer
            Handle-Result $res $w
            $remove += $iid
            continue
        }

        # liveness / stuck detection (timeouts use ACTIVE minutes - sleep is not counted)
        $alive = $false
        if ($w.node_pid) { $alive = [bool](Get-Process -Id $w.node_pid -ErrorAction SilentlyContinue) }
        else { $alive = [bool](Get-Process -Id $w.launcher_pid -ErrorAction SilentlyContinue) }
        $mins = (($tick) - $w.spawned_at).TotalMinutes - ($frozenMin - $w.frozen_base)

        if (-not $alive) {
            Start-Sleep -Milliseconds 1500   # grace for a just-finished worker to flush the DONE flag
            if (Test-Path -LiteralPath $doneFlag) {
                $res = Resolve-Completion $iid $name $w.issuer
                Handle-Result $res $w
            } else {
                if ($mins -lt $FAST_FAIL_MINUTES) {
                    Write-Log "  x $iid exited empty after only $([math]::Round($mins,1)) min - likely codex rate / concurrency pushback. See workers\${iid}_worker.log"
                    Record-Failed $iid $name 'fast_empty_fail'
                    if ($effectiveCap -gt $CAP_FLOOR) {
                        $effectiveCap = $effectiveCap - 1
                        Write-Log "  -> backing off: reducing parallel cap to $effectiveCap"
                    }
                } else {
                    Write-Log "  x $iid worker exited with NO DONE flag (crash / usage limit / error). See workers\${iid}_worker.log"
                    Record-Failed $iid $name 'exited_no_output'
                }
                $failedCount++; $consecFails++
            }
            $remove += $iid
            continue
        }

        if ($mins -ge $MAX_WORKER_MINUTES) {
            Write-Log "  x $iid exceeded $MAX_WORKER_MINUTES min active with no DONE - treating as stuck; killing it."
            try { if ($w.node_pid) { Stop-Process -Id $w.node_pid -Force -ErrorAction SilentlyContinue } } catch { }
            try { Stop-Process -Id $w.launcher_pid -Force -ErrorAction SilentlyContinue } catch { }
            Record-Failed $iid $name 'timeout_no_output'
            $failedCount++; $consecFails++
            $remove += $iid
            continue
        }
    }
    foreach ($iid in $remove) { $active.Remove($iid) }

    if ($consecFails -ge $FAIL_HALT_THRESHOLD) { $haltStall = $true; break }

    # refill with fresh workers (up to the current effective cap, if RAM allows)
    while ($active.Count -lt $effectiveCap -and $queueIndex -lt $queue.Count) {
        if (-not (Can-Admit-Worker)) { break }
        Try-Spawn-Next
    }

    $queuedLeft = [Math]::Max(0, $queue.Count - $queueIndex)
    Write-Log "[MONITOR] promoted=$promotedCount | failed=$failedCount | active=$($active.Count)/$effectiveCap (cap=$WORKER_CAP $capMode) | queued=$queuedLeft"
}

if ($haltStall) {
    Write-Log "HALTING: $FAIL_HALT_THRESHOLD workers in a row produced no output."
    Write-Log "This usually means the codex plan usage window (rolling 5h / weekly) was hit, or an environment issue."
    Write-Log "Stopping remaining active workers cleanly..."
    foreach ($iid in @($active.Keys)) {
        $w = $active[$iid]
        try { if ($w.node_pid) { Stop-Process -Id $w.node_pid -Force -ErrorAction SilentlyContinue } } catch { }
        try { Stop-Process -Id $w.launcher_pid -Force -ErrorAction SilentlyContinue } catch { }
    }
    Write-Log "Completed so far: $promotedCount / $($target.Count) target issuers (saved + recorded)."
    Write-Log "RESUME: after the usage window resets, re-run the SAME command - done issuers are skipped automatically."
    Write-Log "Output: $runOut"
    return
}

$totalDone = $promotedCount + $alreadyDone.Count
Write-Log "run_batch pass complete. Promoted this run=$promotedCount | failed this run=$failedCount | total done for target=$totalDone / $($target.Count)."
if ($failedCount -gt 0) {
    Write-Log "$failedCount issuer(s) failed/incomplete. Re-run the SAME command to retry just those (done issuers are skipped)."
}

# ---- Canonicalize promoted output to one stable schema (UNION of all columns;
#      additive - never drops a column - plus whitespace normalize + exact-dedup) ----
try {
    $canonTool = Join-Path $PSScriptRoot 'canonicalize_output.py'
    $anyCsv = @(Get-ChildItem -LiteralPath $runOut -Filter *.csv -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -notlike '_*' })
    if ((Test-Path -LiteralPath $canonTool) -and $anyCsv.Count -gt 0) {
        Write-Log "Canonicalizing output schema ($($anyCsv.Count) files) via $pythonCmd ..."
        & $pythonCmd $canonTool $runOut 2>&1 | ForEach-Object { Write-Log "  [canon] $_" }
    }
} catch {
    Write-Log "  (canonicalize step skipped: $($_.Exception.Message))"
}

Write-Log "Output folder: $runOut"
Write-Log "Logs / staging / status under: $runTemp"
