"""Fold finished batch files (results/batch_*.csv, keyed on FACILITY_ID) into row_queue.csv.
usage: python merge.py row_queue.csv results/   -> rewrites row_queue.csv in place (keeps a .bak)"""
import sys, glob, shutil, pandas as pd
qf, rdir = sys.argv[1:3]
q = pd.read_csv(qf, dtype=str, keep_default_na=False, encoding='utf-8-sig').set_index('FACILITY_ID')
files = sorted(glob.glob(f'{rdir.rstrip("/")}/batch_*.csv'))
b = pd.concat([pd.read_csv(f, dtype=str, keep_default_na=False, encoding='utf-8-sig') for f in files]) if files else pd.DataFrame()
if b.empty: sys.exit('no batch files')
b = b.drop_duplicates('FACILITY_ID', keep='last').set_index('FACILITY_ID')   # later batch wins
unknown = b.index.difference(q.index)
if len(unknown): print('WARNING unknown FACILITY_IDs ignored:', len(unknown))
b = b.loc[b.index.intersection(q.index)]
cols = [c for c in b.columns if c in q.columns]
shutil.copy(qf, qf + '.bak'); q.loc[b.index, cols] = b[cols]
q.reset_index().to_csv(qf, index=False, encoding='utf-8-sig')
print(f'merged {len(b)} rows from {len(files)} files; DONE={int((q.CHECK_STATUS=="DONE").sum())}/{len(q)}')
