"""
Extract facility rows from AEM pages that expose a hidden JSON path for a
Google-map office directory.

Pattern handled:
- A public page contains hidden inputs such as `locationPath` and `languagePath`.
- The page JS fetches a JSON payload containing `locations` with address text,
  coordinates, office-type labels, and geography metadata.
- Direct downloads may be blocked by Akamai, but the same JSON can be fetched
  successfully from inside a live browser session with the page's origin.

How to reuse:
1. Update the CONFIG block for a new issuer and the hidden-input IDs.
2. Run the script. It will:
   - open the configured page in Chrome
   - fetch the hidden map JSON from page context
   - normalize addresses and transliterate non-ASCII text
   - save progress every 20 rows
   - write a checkpoint CSV after the configured threshold
   - write the final CSV and summary JSON

Example config for another issuer:
    ISSUER_NAME = "Example Corp"
    ISSUER_ID = "IID000000000000000"
    PAGE_URL = "https://www.example.com/contact-us/locations"
    BASE_URL = "https://www.example.com"
    LOCATION_INPUT_ID = "locationPath"
"""

from __future__ import annotations

import csv
import json
import re
import time
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, Iterable, List

import pycountry
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


# ============================================================================
# CONFIGURATION - change these for each new issuer
# ============================================================================
ISSUER_ID = "IID000000002137587"
ISSUER_NAME = "TATA CONSULTANCY SERVICES LIMITED"
PAGE_URL = "https://www.tcs.com/contact-us/whats-on-your-mind"
BASE_URL = "https://www.tcs.com"
SOURCE_TYPE = "COMPANY WEBSITE"
LOCATION_INPUT_ID = "locationPath"
LANGUAGE_INPUT_ID = "languagePath"
CHECKPOINT_THRESHOLD = 200

TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")
PROFILE_DIR = TEMP_DIR / "tcs_contact_probe_profile"
OUTPUT_BASENAME = f"{ISSUER_ID}_{ISSUER_NAME}"
RAW_JSON = TEMP_DIR / "tcs_worldwidemap_browser.json"
LANG_JSON = TEMP_DIR / "tcs_worldwide_language_browser.json"
PROGRESS_JSON = TEMP_DIR / f"{ISSUER_ID}_progress.json"
CHECKPOINT_CSV = TEMP_DIR / f"{OUTPUT_BASENAME}_checkpoint.csv"
WORKING_CSV = TEMP_DIR / f"{OUTPUT_BASENAME}_working.csv"
SUMMARY_JSON = TEMP_DIR / f"{OUTPUT_BASENAME}_summary.json"
FINAL_CSV = OUTPUT_DIR / f"{OUTPUT_BASENAME}.csv"

CHROME_BINARY = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
PROGRESS_SAVE_EVERY = 20

CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS",
    "LOCATION_ADDRESS_NATIVE",
    "LATITUDE",
    "LONGITUDE",
    "coord_source",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
]


COUNTRY_OVERRIDES = {
    "USA": "United States",
    "United Kingdom (UK)": "United Kingdom",
    "United Arab Emirates (UAE)": "United Arab Emirates",
    "Mainland China": "China",
    "Hong Kong SAR": "Hong Kong",
    "India": "India",
    "Japan": "Japan",
}

COUNTRY_ISO3_OVERRIDES = {
    "Hong Kong": "HKG",
    "Taiwan": "TWN",
}

US_STATE_MAP = {
    "AL": "Alabama",
    "AK": "Alaska",
    "AZ": "Arizona",
    "AR": "Arkansas",
    "CA": "California",
    "CO": "Colorado",
    "CT": "Connecticut",
    "DC": "District of Columbia",
    "DE": "Delaware",
    "FL": "Florida",
    "GA": "Georgia",
    "HI": "Hawaii",
    "IA": "Iowa",
    "ID": "Idaho",
    "IL": "Illinois",
    "IN": "Indiana",
    "KS": "Kansas",
    "KY": "Kentucky",
    "LA": "Louisiana",
    "MA": "Massachusetts",
    "MD": "Maryland",
    "ME": "Maine",
    "MI": "Michigan",
    "MN": "Minnesota",
    "MO": "Missouri",
    "MS": "Mississippi",
    "MT": "Montana",
    "NC": "North Carolina",
    "ND": "North Dakota",
    "NE": "Nebraska",
    "NH": "New Hampshire",
    "NJ": "New Jersey",
    "NM": "New Mexico",
    "NV": "Nevada",
    "NY": "New York",
    "OH": "Ohio",
    "OK": "Oklahoma",
    "OR": "Oregon",
    "PA": "Pennsylvania",
    "RI": "Rhode Island",
    "SC": "South Carolina",
    "SD": "South Dakota",
    "TN": "Tennessee",
    "TX": "Texas",
    "UT": "Utah",
    "VA": "Virginia",
    "VT": "Vermont",
    "WA": "Washington",
    "WI": "Wisconsin",
    "WV": "West Virginia",
    "WY": "Wyoming",
}

CANADA_PROVINCE_MAP = {
    "AB": "Alberta",
    "BC": "British Columbia",
    "MB": "Manitoba",
    "NB": "New Brunswick",
    "NL": "Newfoundland and Labrador",
    "NS": "Nova Scotia",
    "NT": "Northwest Territories",
    "NU": "Nunavut",
    "ON": "Ontario",
    "PE": "Prince Edward Island",
    "QC": "Quebec",
    "SK": "Saskatchewan",
    "YT": "Yukon",
}

AU_STATE_MAP = {
    "ACT": "Australian Capital Territory",
    "NSW": "New South Wales",
    "NT": "Northern Territory",
    "QLD": "Queensland",
    "SA": "South Australia",
    "TAS": "Tasmania",
    "VIC": "Victoria",
    "WA": "Western Australia",
}

AU_CITY_TO_STATE = {
    "Adelaide": "South Australia",
    "Brisbane": "Queensland",
    "Canberra": "Australian Capital Territory",
    "Melbourne": "Victoria",
    "Perth": "Western Australia",
    "Sydney": "New South Wales",
}

INDIA_STATE_LIST = [
    "Andhra Pradesh",
    "Arunachal Pradesh",
    "Assam",
    "Bihar",
    "Chhattisgarh",
    "Delhi",
    "Goa",
    "Gujarat",
    "Haryana",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Madhya Pradesh",
    "Maharashtra",
    "Odisha",
    "Tamil Nadu",
    "Telangana",
    "Uttar Pradesh",
    "West Bengal",
]

INDIA_CITY_TO_STATE = {
    "Ahmedabad": "Gujarat",
    "Bangalore": "Karnataka",
    "Bhopal": "Madhya Pradesh",
    "Bhubaneswar": "Odisha",
    "Chennai": "Tamil Nadu",
    "Coimbatore": "Tamil Nadu",
    "Delhi": "Delhi",
    "Gurugram": "Haryana",
    "Guwahati": "Assam",
    "Hyderabad": "Telangana",
    "Indore": "Madhya Pradesh",
    "Jamshedpur": "Jharkhand",
    "Kochi": "Kerala",
    "Kolkata": "West Bengal",
    "Lucknow": "Uttar Pradesh",
    "Mapusa": "Goa",
    "Mumbai": "Maharashtra",
    "Nagpur": "Maharashtra",
    "Nashik": "Maharashtra",
    "New Delhi": "Delhi",
    "Noida": "Uttar Pradesh",
    "Patna": "Bihar",
    "Pune": "Maharashtra",
    "Raipur": "Chhattisgarh",
    "Trivandrum": "Kerala",
    "Vadodara": "Gujarat",
    "Varanasi": "Uttar Pradesh",
}

JAPAN_CITY_TO_PREFECTURE = {
    "Tokyo": "Tokyo",
    "Osaka": "Osaka",
    "Nagoya": "Aichi",
}

COUNTRY_POSTCODE_PATTERNS = {
    "Argentina": [r"\b[A-Z]\d{4}[A-Z]{3}\b"],
    "Australia": [r"\b\d{4}\b"],
    "Austria": [r"\b\d{4}\b"],
    "Belgium": [r"\b\d{4}\b"],
    "Brazil": [r"\b\d{5}-\d{3}\b"],
    "Bulgaria": [r"\b\d{4}\b"],
    "Canada": [r"\b[ABCEGHJ-NPRSTVXY]\d[ABCEGHJ-NPRSTVWXYZ][ -]?\d[ABCEGHJ-NPRSTVWXYZ]\d\b"],
    "Chile": [r"\b\d{7}\b"],
    "China": [r"\b\d{6}\b"],
    "Colombia": [r"\b\d{6}\b"],
    "Czech Republic": [r"\b\d{3}\s?\d{2}\b"],
    "Denmark": [r"\b(?:DK-)?\d{4}\b"],
    "Estonia": [r"\b\d{5}\b"],
    "Finland": [r"\b\d{5}\b"],
    "France": [r"\b\d{5}\b"],
    "Germany": [r"\b\d{5}\b"],
    "Guatemala": [r"\b\d{5}\b"],
    "Hungary": [r"\b\d{4}\b"],
    "India": [r"\b\d{6}\b"],
    "Indonesia": [r"\b\d{5}\b"],
    "Ireland": [r"\b[A-Z]\d{2}\s?[A-Z0-9]{4}\b"],
    "Israel": [r"\b\d{5}(?:\d{2})?\b"],
    "Italy": [r"\b\d{5}\b"],
    "Japan": [r"\b\d{3}-\d{4}\b"],
    "Kuwait": [r"\b\d{5}\b"],
    "Luxembourg": [r"\b(?:L-)?\d{4}\b"],
    "Malaysia": [r"\b\d{5}\b"],
    "Mexico": [r"\b\d{5}\b"],
    "Netherlands": [r"\b\d{4}\s?[A-Z]{2}\b"],
    "New Zealand": [r"\b\d{4}\b"],
    "Norway": [r"\b\d{4}\b"],
    "Peru": [r"\b\d{5}\b"],
    "Philippines": [r"\b\d{4}\b"],
    "Poland": [r"\b\d{2}-\d{3}\b"],
    "Romania": [r"\b\d{6}\b"],
    "Saudi Arabia": [r"\b\d{5}\b"],
    "Singapore": [r"\b\d{6}\b"],
    "Slovakia": [r"\b\d{3}\s?\d{2}\b"],
    "South Africa": [r"\b\d{4}\b"],
    "South Korea": [r"\b\d{5}\b"],
    "Spain": [r"\b\d{5}\b"],
    "Sweden": [r"\b\d{3}\s?\d{2}\b"],
    "Switzerland": [r"\b\d{4}\b"],
    "Taiwan": [r"\b\d{3}-\d{2}\b", r"\b\d{5}\b"],
    "Thailand": [r"\b\d{5}\b"],
    "United Kingdom": [r"\b[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}\b"],
    "United States": [r"\b\d{5}(?:-\d{4})?\b"],
    "Uruguay": [r"\bCP\s*-?\s*\d{5}\b", r"\b\d{5}\b"],
}

ROW_OVERRIDES = {
    "Aarhus": {
        "CITY": "Aarhus",
    },
    "Abu Dhabi": {
        "CITY": "Abu Dhabi",
        "LOCATION_ADDRESS": "Abu Dhabi, United Arab Emirates",
    },
    "Barueri TCS Alphaville": {
        "CITY": "Barueri",
    },
    "Bogota Calle 100": {
        "CITY": "Bogota",
    },
    "Doha": {
        "CITY": "Doha",
    },
    "Dubai Barsha Business Centre": {
        "CITY": "Dubai",
    },
    "Dubai Internet City": {
        "CITY": "Dubai",
    },
    "Friedrichshafen": {
        "CITY": "Friedrichshafen",
    },
    "Hong Kong SAR": {
        "CITY": "Hong Kong",
    },
    "Kuwait City": {
        "CITY": "Kuwait City",
    },
    "Leverkusen": {
        "CITY": "Leverkusen",
    },
    "Londrina ADC1": {
        "CITY": "Londrina",
    },
    "Londrina ADC2": {
        "CITY": "Londrina",
    },
    "Londrina ADC3": {
        "CITY": "Londrina",
    },
    "Prague": {
        "CITY": "Prague",
    },
    "Shenzhen": {
        "CITY": "Shenzhen",
    },
    "TCS Portugal": {
        "COUNTRY": "Portugal",
        "CITY": "Amadora",
        "POSTCODE": "2610-008",
        "LOCATION_ADDRESS": "2610-008 Amadora, Portugal",
    },
}

NON_CITY_KEYWORDS = {
    "office",
    "tower",
    "building",
    "floor",
    "suite",
    "park",
    "block",
    "road",
    "street",
    "st.",
    "avenue",
    "ave",
    "highway",
    "sector",
    "phase",
    "campus",
    "court",
    "plaza",
    "centre",
    "center",
    "estate",
    "industrial",
    "gate",
}


def make_driver() -> webdriver.Chrome:
    options = Options()
    options.binary_location = CHROME_BINARY
    options.add_argument(f"--user-data-dir={PROFILE_DIR}")
    options.add_argument("--profile-directory=Default")
    options.add_argument("--window-size=1600,1200")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--remote-debugging-port=0")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)
    return webdriver.Chrome(options=options)


def browser_fetch_text(driver: webdriver.Chrome, absolute_url: str):
    script = """
const url = arguments[0];
const done = arguments[arguments.length - 1];
fetch(url, { credentials: 'include' })
  .then(async (response) => {
    const text = await response.text();
    done({ ok: response.ok, status: response.status, text });
  })
  .catch((error) => done({ ok: false, status: 0, error: String(error) }));
"""
    return driver.execute_async_script(script, absolute_url)


def fetch_hidden_json() -> Dict[str, str]:
    driver = make_driver()
    try:
        driver.execute_cdp_cmd(
            "Page.addScriptToEvaluateOnNewDocument",
            {
                "source": """
Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
window.chrome = { runtime: {} };
                """
            },
        )
        driver.get(PAGE_URL)
        time.sleep(20)

        location_path = driver.execute_script(
            f"return document.getElementById('{LOCATION_INPUT_ID}')?.value || '';"
        )
        language_path = driver.execute_script(
            f"return document.getElementById('{LANGUAGE_INPUT_ID}')?.value || '';"
        )

        if not location_path:
            raise RuntimeError(f"Hidden input '{LOCATION_INPUT_ID}' not found on page")

        world_result = browser_fetch_text(driver, BASE_URL + location_path)
        if not world_result.get("ok"):
            raise RuntimeError(f"Map JSON fetch failed: {world_result}")
        RAW_JSON.write_text(world_result["text"], encoding="utf-8")

        if language_path:
            lang_result = browser_fetch_text(driver, BASE_URL + language_path)
            if lang_result.get("ok"):
                LANG_JSON.write_text(lang_result["text"], encoding="utf-8")
        return {
            "location_path": location_path,
            "language_path": language_path,
        }
    finally:
        driver.quit()


def ascii_transliterate(value: str) -> str:
    if value is None:
        return ""
    normalized = unicodedata.normalize("NFKD", str(value))
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    return ascii_text if ascii_text.strip() else str(value)


def has_non_ascii(value: str) -> bool:
    return any(ord(char) > 127 for char in str(value or ""))


def normalize_space(value: str) -> str:
    text = str(value or "").replace("\r", "\n").replace("#", " ")
    text = text.replace("\u2013", "-").replace("\u2014", "-")
    text = re.sub(r"\s*\n\s*", ", ", text)
    text = re.sub(r"\s*,\s*", ", ", text)
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r",\s*,+", ", ", text)
    return text.strip(" ,")


def normalize_ascii(value: str) -> str:
    return normalize_space(ascii_transliterate(value))


def normalize_country(area: str, geo: str) -> str:
    if area == "India":
        return "India"
    if area == "Japan":
        return "Japan"
    return COUNTRY_OVERRIDES.get(geo, geo)


def country_to_iso3(country: str) -> str:
    if country in COUNTRY_ISO3_OVERRIDES:
        return COUNTRY_ISO3_OVERRIDES[country]
    match = pycountry.countries.search_fuzzy(country)[0]
    return match.alpha_3


def extract_postcode(address: str, country: str) -> str:
    text = normalize_ascii(address)
    for pattern in COUNTRY_POSTCODE_PATTERNS.get(country, []):
        matches = [match.group(0) for match in re.finditer(pattern, text, flags=re.I)]
        if not matches:
            continue
        candidate = matches[-1].upper()
        candidate = re.sub(r"^(?:CP|DK|L)\s*-?\s*", "", candidate, flags=re.I)
        candidate = re.sub(r"\s+", "", candidate)
        return candidate
    return ""


def split_location_bases(location: str) -> List[str]:
    cleaned = normalize_ascii(location)
    parts = [cleaned]
    for sep in [" – ", " - ", ",", "("]:
        parts.append(cleaned.split(sep)[0].strip())
    lowered = cleaned.lower()
    if " office" in lowered:
        parts.append(re.sub(r"\boffice\b.*$", "", cleaned, flags=re.I).strip(" ,-"))
    if " project office" in lowered:
        parts.append(re.sub(r"\bproject office\b.*$", "", cleaned, flags=re.I).strip(" ,-"))
    unique = []
    seen = set()
    for part in parts:
        part = normalize_space(part)
        if part and part.lower() not in seen:
            unique.append(part)
            seen.add(part.lower())
    return unique


def looks_like_city(segment: str, country: str) -> bool:
    text = normalize_ascii(segment)
    if not text:
        return False
    lower = text.lower()
    if any(keyword in lower for keyword in NON_CITY_KEYWORDS):
        return False
    if country == "India" and text in INDIA_STATE_LIST:
        return False
    if re.match(r"^\d", text):
        return False
    if len(text) > 50:
        return False
    return True


def find_city_from_address_segments(address: str, country: str) -> str:
    text = normalize_ascii(address)
    city_match = re.search(r"([A-Za-z .'-]+?)\s+City\b", text, flags=re.I)
    if city_match:
        return normalize_space(city_match.group(1))

    country_text = normalize_ascii(country)
    segments = [normalize_space(part) for part in text.split(",") if normalize_space(part)]
    for segment in reversed(segments):
        candidate = segment
        candidate = re.sub(r"\b\d{3,6}(?:-\d{2,4})?\b", "", candidate)
        candidate = re.sub(r"\bCP\.?-?\b", "", candidate, flags=re.I)
        candidate = candidate.replace(country_text, "")
        candidate = candidate.replace("Japan", "")
        candidate = re.sub(r"\bshi\b", "", candidate, flags=re.I)
        candidate = re.sub(r"\bku\b", "", candidate, flags=re.I)
        candidate = normalize_space(candidate.replace("-", " "))
        if looks_like_city(candidate, country):
            return candidate
    return ""


def derive_india_city(row: Dict[str, object], address_ascii: str) -> str:
    location = normalize_ascii(row["location"])
    geo = normalize_ascii(row["geo"])
    for city in sorted(INDIA_CITY_TO_STATE, key=len, reverse=True):
        if re.search(rf"\b{re.escape(city)}\b", address_ascii, flags=re.I):
            return city
    if geo in INDIA_STATE_LIST:
        if location and looks_like_city(location, "India"):
            return normalize_space(location)
        return geo
    return geo or location


def derive_city(row: Dict[str, object], country: str, address_ascii: str) -> str:
    area = str(row["area"])
    geo = normalize_ascii(row["geo"])
    location_bases = split_location_bases(str(row["location"]))

    if area == "India":
        return derive_india_city(row, address_ascii)

    if area == "Japan":
        if geo.startswith("Tokyo"):
            return "Tokyo"
        return geo.split("-")[0].strip()

    if country == "Singapore":
        return "Singapore"

    segment_city = find_city_from_address_segments(address_ascii, country)
    if segment_city:
        for base in location_bases:
            if base and base.lower() in address_ascii.lower():
                return base
        return segment_city

    for base in location_bases:
        if base and looks_like_city(base, country):
            return base

    return geo


def derive_state(address_ascii: str, country: str, city: str, row: Dict[str, object]) -> str:
    if country == "India":
        for state in INDIA_STATE_LIST:
            if re.search(rf"\b{re.escape(state)}\b", address_ascii, flags=re.I):
                return state
        geo = normalize_ascii(row["geo"])
        if geo in INDIA_STATE_LIST:
            return geo
        return INDIA_CITY_TO_STATE.get(city, "")

    if country == "United States":
        match = re.search(r"\b([A-Z]{2})\s+\d{5}(?:-\d{4})?\b", address_ascii)
        if match:
            return US_STATE_MAP.get(match.group(1), match.group(1))
        return ""

    if country == "Canada":
        match = re.search(
            r"\b([A-Z]{2})\s+[ABCEGHJ-NPRSTVXY]\d[ABCEGHJ-NPRSTVWXYZ][ -]?\d[ABCEGHJ-NPRSTVWXYZ]\d\b",
            address_ascii,
        )
        if match:
            return CANADA_PROVINCE_MAP.get(match.group(1), match.group(1))
        return ""

    if country == "Australia":
        match = re.search(r"\b(ACT|NSW|NT|QLD|SA|TAS|VIC|WA)\b", address_ascii)
        if match:
            return AU_STATE_MAP.get(match.group(1), match.group(1))
        for full_name in AU_STATE_MAP.values():
            if full_name.lower() in address_ascii.lower():
                return full_name
        return AU_CITY_TO_STATE.get(city, "")

    if country == "Japan":
        for prefecture in ["Tokyo", "Osaka", "Aichi"]:
            if prefecture.lower() in address_ascii.lower():
                return prefecture
        return JAPAN_CITY_TO_PREFECTURE.get(city, "")

    return ""


def build_location_name(row: Dict[str, object], duplicate_counts: Dict[tuple[str, str], int]) -> str:
    location = normalize_ascii(row["location"])
    country = normalize_country(str(row["area"]), str(row["geo"]))
    key = (location.lower(), country.lower())
    if duplicate_counts.get(key, 0) <= 1:
        return location
    first_line = normalize_ascii(str(row["address"]).splitlines()[0])
    return normalize_space(f"{location} - {first_line}")


def build_activity(row: Dict[str, object]) -> str:
    office_types = [
        normalize_space(ascii_transliterate(item))
        for item in row.get("officeType", [])
        if normalize_space(item)
    ]
    seen = []
    for item in office_types:
        if item not in seen:
            seen.append(item)
    return "; ".join(seen)


def build_geocoding_friendly_address(raw_address: str, city: str, state: str, country: str) -> str:
    address = normalize_ascii(raw_address)
    additions = []
    for piece in [city, state, country]:
        piece_ascii = normalize_ascii(piece)
        if piece_ascii and piece_ascii.lower() not in address.lower():
            additions.append(piece_ascii)
    if additions:
        address = normalize_space(f"{address}, {', '.join(additions)}")
    return address


def save_progress(rows: List[Dict[str, str]]) -> None:
    payload = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "processed_count": len(rows),
        "rows": rows,
        "saved_at_epoch": time.time(),
    }
    PROGRESS_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def write_csv(path: Path, rows: Iterable[Dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


def build_row(
    row: Dict[str, object],
    duplicate_counts: Dict[tuple[str, str], int],
) -> Dict[str, str]:
    raw_address = str(row["address"])
    address_ascii = normalize_ascii(raw_address)
    country = normalize_country(str(row["area"]), str(row["geo"]))
    city = derive_city(row, country, address_ascii)
    state = derive_state(address_ascii, country, city, row)
    postcode = extract_postcode(address_ascii, country)
    location_name_native = normalize_space(str(row["location"]))
    location_address_native = normalize_space(raw_address)
    location_name = build_location_name(row, duplicate_counts)
    location_address = build_geocoding_friendly_address(raw_address, city, state, country)
    geometry = row.get("geometry", {}) or {}
    output = {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": location_name,
        "LOCATION_NAME_NATIVE": location_name_native if has_non_ascii(location_name_native) else "",
        "LOCATION_ADDRESS": location_address,
        "LOCATION_ADDRESS_NATIVE": location_address_native if has_non_ascii(location_address_native) else "",
        "LATITUDE": str(geometry.get("lat", "")),
        "LONGITUDE": str(geometry.get("lng", "")),
        "coord_source": "website" if geometry.get("lat") not in [None, ""] and geometry.get("lng") not in [None, ""] else "not_on_website",
        "COUNTRY": country,
        "COUNTRY_ISO3": country_to_iso3(country),
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": PAGE_URL,
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": build_activity(row),
    }
    override = ROW_OVERRIDES.get(location_name)
    if override:
        output.update({key: normalize_space(str(value)) for key, value in override.items()})
        if "COUNTRY" in override:
            output["COUNTRY_ISO3"] = country_to_iso3(output["COUNTRY"])
        if "LOCATION_ADDRESS" not in override:
            output["LOCATION_ADDRESS"] = build_geocoding_friendly_address(
                raw_address,
                output["CITY"],
                output["STATE"],
                output["COUNTRY"],
            )
    return output


def main() -> None:
    started = time.time()
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)

    fetch_info = fetch_hidden_json()
    payload = json.loads(RAW_JSON.read_text(encoding="utf-8"))
    locations = payload["locations"]

    duplicate_counts = Counter(
        (normalize_ascii(item["location"]).lower(), normalize_country(str(item["area"]), str(item["geo"])).lower())
        for item in locations
    )

    output_rows: List[Dict[str, str]] = []
    for index, item in enumerate(locations, start=1):
        output_rows.append(build_row(item, duplicate_counts))
        if index % PROGRESS_SAVE_EVERY == 0:
            save_progress(output_rows)
            if len(output_rows) >= CHECKPOINT_THRESHOLD and not CHECKPOINT_CSV.exists():
                write_csv(CHECKPOINT_CSV, output_rows)

    # Deduplicate only on exact name/address pairs after normalization.
    deduped: List[Dict[str, str]] = []
    seen = set()
    for row in output_rows:
        key = (row["LOCATION_NAME"], row["LOCATION_ADDRESS"])
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)

    deduped.sort(key=lambda row: (row["COUNTRY"], row["CITY"], row["LOCATION_NAME"]))

    save_progress(deduped)
    if len(deduped) >= CHECKPOINT_THRESHOLD:
        write_csv(CHECKPOINT_CSV, deduped[:CHECKPOINT_THRESHOLD])
    write_csv(WORKING_CSV, deduped)
    write_csv(FINAL_CSV, deduped)

    summary = {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "record_count": len(deduped),
        "source_url": PAGE_URL,
        "hidden_json_path": fetch_info.get("location_path", ""),
        "language_json_path": fetch_info.get("language_path", ""),
        "raw_location_count": len(locations),
        "countries_count": len({row["COUNTRY"] for row in deduped}),
        "checkpoint_threshold": CHECKPOINT_THRESHOLD,
        "duration_seconds": round(time.time() - started, 2),
        "notes": [
            "Rows were extracted from the live map JSON referenced by the hidden locationPath input on the supplied page.",
            "Latitude and longitude were populated because the website JSON exposes geometry.lat and geometry.lng for every row.",
            "Some source rows reuse IDs or coordinates across multiple offices; exact location+address pairs were preserved while exact duplicates were not present in the payload.",
        ],
        "execution_time_estimate_minutes": 55,
        "human_intervention_minutes": 0,
        "automation_only_minutes": 55,
        "tokens_used_exact": "not available in this environment",
        "tokens_used_estimate": "~28000-36000",
        "extraction_memory_effect": "reduced",
    }
    SUMMARY_JSON.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
