"""
Generalized mirrored sitemap property extractor.

Pattern:
- Cloudflare-protected property sites whose public pages can still be fetched via
  a text mirror such as r.jina.ai.
- A sitemap lists detail pages for properties or assets.
- Detail pages expose plain-text address blocks and often a Google Maps `ll=`
  coordinate link that can be harvested directly from the mirrored output.
- Market listing pages can be used as fallbacks when detail-page addresses omit
  state or postcode information.

How to adapt for another issuer:
1. Update the CONFIGURATION block with the issuer metadata and source URLs.
2. Adjust the property-path filters if the site uses different detail-page
   categories.
3. Tune the activity heuristics if the site uses different wording.

This script writes intermediate artifacts to Temp, saves progress every 20 detail
pages, creates a checkpoint CSV once the threshold is met, and writes the final
CSV to Output.
"""

from __future__ import annotations

import csv
import json
import re
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
from urllib.parse import urlparse

import requests
import urllib3


# ============================================================================
# CONFIGURATION - Change these for each issuer
# ============================================================================
ISSUER_ID = "IID000000002700476"
ISSUER_NAME = "Prologis Property Mexico, S.A de C.V."
BASE_URL = "https://www.prologis.mx"
SITEMAP_URL = "https://www.prologis.mx/sitemap.xml"
OFFICE_LOCATIONS_URL = "https://www.prologis.com/about/office-locations"
CONTACT_URL = "https://www.prologis.mx/en/contact"
MIRROR_PREFIX = "https://r.jina.ai/http://"
SOURCE_TYPE = "COMPANY WEBSITE"
COUNTRY = "Mexico"
COUNTRY_ISO3 = "MEX"
COUNT_THRESHOLD = 105

TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")

# Windows file names cannot safely end with a trailing dot, so the issuer name is
# minimally sanitized for the output file while keeping the exact issuer string in
# the CSV column values.
OUTPUT_BASENAME = f"{ISSUER_ID}_Prologis Property Mexico, S.A de C.V"
FINAL_CSV = OUTPUT_DIR / f"{OUTPUT_BASENAME}.csv"
CHECKPOINT_CSV = TEMP_DIR / f"{OUTPUT_BASENAME}_checkpoint.csv"
PROGRESS_JSON = TEMP_DIR / f"{ISSUER_ID}_progress.json"
PARTIAL_ROWS_JSON = TEMP_DIR / f"{ISSUER_ID}_partial_rows.json"
SUMMARY_JSON = TEMP_DIR / f"{ISSUER_ID}_summary.json"
SITEMAP_TXT = TEMP_DIR / f"{ISSUER_ID}_sitemap_mirror.txt"
MARKET_URLS_JSON = TEMP_DIR / f"{ISSUER_ID}_market_urls.json"
PROPERTY_URLS_JSON = TEMP_DIR / f"{ISSUER_ID}_property_urls.json"
MARKET_CARD_JSON = TEMP_DIR / f"{ISSUER_ID}_market_card_fallbacks.json"
FAILURES_JSON = TEMP_DIR / f"{ISSUER_ID}_failures.json"

REQUEST_TIMEOUT = 90
MAX_RETRIES = 5
REQUEST_SLEEP_SECONDS = 1.0
MARKET_WORKERS = 4
PROPERTY_WORKERS = 1
PROGRESS_SAVE_EVERY = 20

PROPERTY_SEGMENTS = {"building", "spec-building", "build-suit", "land-sale", "land-lease"}

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_NAME_LOCAL",
    "LOCATION_ADDRESS",
    "LOCATION_ADDRESS_LOCAL",
    "LATITUDE",
    "LONGITUDE",
    "coord_source",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
]

STATE_CANONICAL = {
    "baja california": "Baja California",
    "baja california norte": "Baja California",
    "chihuahua": "Chihuahua",
    "coahuila": "Coahuila",
    "coahuila de zaragoza": "Coahuila",
    "estado de mexico": "Estado de Mexico",
    "mexico state": "Estado de Mexico",
    "mexico": "Estado de Mexico",
    "guanajuato": "Guanajuato",
    "jalisco": "Jalisco",
    "nuevo leon": "Nuevo Leon",
    "nle": "Nuevo Leon",
    "queretaro": "Queretaro",
    "queretaro de arteaga": "Queretaro",
    "reynosa": "Tamaulipas",
    "san luis potosi": "San Luis Potosi",
    "s.l.p.": "San Luis Potosi",
    "slp": "San Luis Potosi",
    "sonora": "Sonora",
    "tamaulipas": "Tamaulipas",
    "ciudad de mexico": "Mexico City",
    "cdmx": "Mexico City",
    "d.f": "Mexico City",
    "df": "Mexico City",
    "d f": "Mexico City",
}

CITY_STATE_HINTS = {
    "apodaca": "Nuevo Leon",
    "ciudad juarez": "Chihuahua",
    "cd juarez": "Chihuahua",
    "cuautitlan izcalli": "Estado de Mexico",
    "guadalajara": "Jalisco",
    "hermosillo": "Sonora",
    "irapuato": "Guanajuato",
    "ramos arizpe": "Coahuila",
    "reynosa": "Tamaulipas",
    "silao": "Guanajuato",
    "tijuana": "Baja California",
    "tlaquepaque": "Jalisco",
    "toluca": "Estado de Mexico",
}

COUNTRY_ALIASES = {
    "The Netherlands": "Netherlands",
    "UK": "United Kingdom",
    "UAE": "United Arab Emirates",
}

COUNTRY_ISO3_MAP = {
    "Belgium": "BEL",
    "Brazil": "BRA",
    "Canada": "CAN",
    "China": "CHN",
    "Czech Republic": "CZE",
    "France": "FRA",
    "Germany": "DEU",
    "Hong Kong SAR China": "HKG",
    "Hungary": "HUN",
    "India": "IND",
    "Italy": "ITA",
    "Japan": "JPN",
    "Luxembourg": "LUX",
    "Mexico": "MEX",
    "Netherlands": "NLD",
    "Poland": "POL",
    "Singapore": "SGP",
    "Slovakia": "SVK",
    "Spain": "ESP",
    "Sweden": "SWE",
    "United Arab Emirates": "ARE",
    "United Kingdom": "GBR",
    "United States": "USA",
}

POSTCODE_PATTERNS = [
    re.compile(r"\b[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}\b"),  # UK
    re.compile(r"\b[A-Z]\d[A-Z]\s?\d[A-Z]\d\b"),  # Canada
    re.compile(r"\bL-\d{4}\b"),  # Luxembourg
    re.compile(r"\b\d{4}\s?[A-Z]{2}\b"),  # Netherlands
    re.compile(r"\b\d{3}\s?\d{2}\b"),  # Sweden
    re.compile(r"\b\d{2}-\d{3}\b"),  # Poland
    re.compile(r"\b\d{3}-\d{4}\b"),  # Japan
    re.compile(r"\b\d{5}-\d{3}\b"),  # Brazil
    re.compile(r"\b\d{6}\b"),  # China/India/Singapore
    re.compile(r"\b\d{5}(?:-\d{4})?\b"),  # US/Mexico/France/Germany/etc.
    re.compile(r"\b\d{4}\b"),
    re.compile(r"\b\d{3}\b"),
]


# ============================================================================
# GENERIC EXTRACTION LOGIC BELOW - Do not modify per-issuer
# ============================================================================
def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def write_json(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def ascii_text(value: str) -> str:
    replacements = {
        "\u2018": "'",
        "\u2019": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2013": "-",
        "\u2014": "-",
        "\u00a0": " ",
    }
    for src, dst in replacements.items():
        value = value.replace(src, dst)
    normalized = unicodedata.normalize("NFKD", value)
    return normalized.encode("ascii", "ignore").decode("ascii")


def clean_spaces(value: str) -> str:
    value = re.sub(r"\s+", " ", value.replace("\r", " ").replace("\n", " ")).strip()
    value = value.replace(" ,", ",").replace(" .", ".")
    value = re.sub(r"\s+,", ",", value)
    return value.strip(" ,")


def geocode_friendly_address(value: str) -> str:
    value = value.replace("#", " No. ")
    value = value.replace("S/N", "SN")
    value = clean_spaces(value)
    value = re.sub(r"\bN/A\b", "", value, flags=re.IGNORECASE)
    value = clean_spaces(value)
    return value


def canonicalize_url(url: str) -> str:
    url = url.strip()
    if url.startswith("http://"):
        url = "https://" + url[len("http://") :]
    url = url.split("#", 1)[0].rstrip("/")
    return url


def mirror_url(url: str) -> str:
    stripped = re.sub(r"^https?://", "", url.strip())
    return f"{MIRROR_PREFIX}{stripped}"


def fetch_mirror_text(url: str) -> str:
    last_error: Optional[str] = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = requests.get(
                mirror_url(url),
                timeout=REQUEST_TIMEOUT,
                headers={"User-Agent": "Mozilla/5.0 (compatible; Codex extractor)"},
                verify=False,
            )
            if response.status_code == 429:
                time.sleep(15.0 * attempt)
                last_error = f"attempt {attempt}: 429 Too Many Requests"
                continue
            response.raise_for_status()
            time.sleep(REQUEST_SLEEP_SECONDS)
            return response.text
        except Exception as exc:  # noqa: BLE001 - retried network fetch
            last_error = f"attempt {attempt}: {exc}"
            time.sleep(1.0 * attempt)
    raise RuntimeError(f"Unable to fetch mirror for {url}: {last_error}")


def extract_markdown(raw_text: str) -> str:
    marker = "Markdown Content:"
    if marker in raw_text:
        return raw_text.split(marker, 1)[1].strip()
    return raw_text.strip()


def parse_sitemap_urls(markdown: str) -> Tuple[List[str], List[str]]:
    urls = sorted(
        {
            canonicalize_url(match.group(1))
            for match in re.finditer(r"\((https://www\.prologis\.mx/en/industrial-properties/[^\s)]+)\)", markdown)
        }
    )

    property_urls: List[str] = []
    market_urls: List[str] = []
    for url in urls:
        parts = [part for part in urlparse(url).path.split("/") if part]
        if len(parts) < 3:
            continue
        if parts[0] != "en" or parts[1] != "industrial-properties":
            continue
        if len(parts) >= 4 and parts[2] in PROPERTY_SEGMENTS:
            property_urls.append(url)
        elif len(parts) == 3:
            market_urls.append(url)

    return sorted(set(property_urls)), sorted(set(market_urls))


def clean_address_lines(lines: Iterable[str]) -> List[str]:
    cleaned: List[str] = []
    for raw_line in lines:
        line = raw_line.strip()
        if not line:
            continue
        line = re.sub(r"\s*\*\*.*$", "", line).strip()
        line = line.strip(" *")
        if not line or line.upper() == "N/A":
            continue
        line = clean_spaces(line)
        if not line:
            continue
        cleaned.append(line)
    return cleaned


def build_local_address(lines: Iterable[str]) -> str:
    return clean_spaces(", ".join(clean_address_lines(lines)))


def canonical_state(value: str) -> str:
    key = ascii_text(value).lower().replace(".", " ")
    key = re.sub(r"\s+", " ", key).strip(" ,")
    return STATE_CANONICAL.get(key, clean_spaces(ascii_text(value)))


def choose_better_text(primary: str, fallback: str) -> str:
    return primary if len(primary) >= len(fallback) else fallback


def parse_mexico_address(
    address_lines_local: List[str],
    fallback: Optional[Dict[str, str]] = None,
    heading_fallback: Optional[Dict[str, str]] = None,
) -> Dict[str, str]:
    fallback = fallback or {}
    heading_fallback = heading_fallback or {}
    local_lines = clean_address_lines(address_lines_local)
    local_address = build_local_address(local_lines)
    ascii_address = geocode_friendly_address(ascii_text(local_address))

    lines_wo_country = [line for line in local_lines if ascii_text(line).lower() not in {"mexico", "country: mexico"}]
    postcode = fallback.get("postcode", "") or heading_fallback.get("postcode", "")
    city = fallback.get("city", "") or heading_fallback.get("city", "")
    state = fallback.get("state", "") or heading_fallback.get("state", "")

    candidates: List[str] = []
    if len(lines_wo_country) >= 2:
        candidates.append(clean_spaces(f"{lines_wo_country[-2]} {lines_wo_country[-1]}"))
    if lines_wo_country:
        candidates.append(lines_wo_country[-1])

    for candidate in candidates:
        candidate_ascii = clean_spaces(ascii_text(candidate))
        patterns = [
            re.match(r"(?P<pc>\d{5}),\s*(?P<city>[^,]+?)\s*,\s*(?P<state>[^,]+)$", candidate_ascii),
            re.match(r"(?P<city>[^,]+?),\s*(?P<state>[^,]+?)\s+(?P<pc>\d{5})$", candidate_ascii),
            re.match(r"(?P<city>[^,]+?),\s*(?P<pc>\d{5}),\s*(?P<state>[^,]+)$", candidate_ascii),
            re.match(r"(?P<metro>[^,]+),\s*(?P<city>[^,]+),\s*(?P<state>[^,]+?)\s+(?P<pc>\d{5})$", candidate_ascii),
            re.match(r"[^,]+,\s*\d{1,5},\s*(?P<city>[^,]+),\s*(?P<state>[^,]+)$", candidate_ascii),
        ]
        match = next((m for m in patterns if m), None)
        if match:
            groups = match.groupdict()
            postcode = groups.get("pc", postcode)
            city = groups.get("city", city)
            state = canonical_state(groups.get("state", state))
            break

        single = re.match(r"(?P<pc>\d{5}),\s*(?P<lemma>[^,]+)$", candidate_ascii)
        if single:
            postcode = single.group("pc")
            lemma = single.group("lemma")
            lemma_state = canonical_state(lemma)
            if lemma_state in {"Estado de Mexico", "Mexico City", "Nuevo Leon", "Baja California", "Chihuahua", "Coahuila", "Guanajuato", "Jalisco", "Queretaro", "San Luis Potosi", "Sonora", "Tamaulipas"}:
                state = lemma_state
                if len(lines_wo_country) >= 2:
                    city = ascii_text(lines_wo_country[-2]).strip(" ,")
            else:
                city = lemma
            break

    if not postcode:
        postcode_match = re.search(r"\b(\d{5})\b", ascii_address)
        if postcode_match:
            postcode = postcode_match.group(1)

    if not city and lines_wo_country:
        city = ascii_text(lines_wo_country[-1]).strip(" ,")
        city = re.sub(r"\b\d{5}\b", "", city).strip(" ,")
        city = re.sub(r"\b(?:Estado de )?Mexico\b$", "", city).strip(" ,")

    if not state and heading_fallback.get("state"):
        state = heading_fallback["state"]

    # Cuautitlan Izcalli / Estado de Mexico pages often only show "54713, Mexico".
    if city and not state and postcode and "Cuautitlan Izcalli" in ascii_text(city):
        state = "Estado de Mexico"

    if city and not state:
        hinted = CITY_STATE_HINTS.get(ascii_text(city).lower())
        if hinted:
            state = hinted

    if city and re.search(r"\d", city):
        split_city = [clean_spaces(part) for part in ascii_text(city).split(",") if clean_spaces(part)]
        if len(split_city) >= 2:
            if split_city[0].isdigit():
                city = split_city[1]
                if len(split_city) >= 3 and not state:
                    state = canonical_state(split_city[2])
            else:
                city = split_city[0]
                if len(split_city) >= 2 and not state:
                    state = canonical_state(split_city[1])

    city = clean_spaces(ascii_text(city))
    state = clean_spaces(ascii_text(state))
    postcode = clean_spaces(postcode)

    return {
        "location_address_local": local_address,
        "location_address": ascii_address,
        "postcode": postcode,
        "city": city,
        "state": state,
    }


def extract_coord(markdown: str) -> Tuple[str, str]:
    match = re.search(r"https://maps\.google\.com/maps\?ll=([-\d.]+),([-\d.]+)&", markdown)
    if match:
        return match.group(1), match.group(2)
    fallback = re.search(r"https://www\.google\.com/maps/@([-\d.]+),([-\d.]+),", markdown)
    if fallback:
        return fallback.group(1), fallback.group(2)
    return "", ""


def extract_property_title(markdown: str) -> str:
    match = re.search(r"^#\s+(.+?)(?:\s+\|\s+Prologis Property Search)?$", markdown, flags=re.MULTILINE)
    if not match:
        return ""
    return clean_spaces(match.group(1))


def extract_property_details(markdown: str) -> str:
    match = re.search(
        r"### Property Details\s*\n\n(?:Updated:\s+[^\n]+\n\n)?(?P<body>.*?)(?:\n\n\*\*Features\*\*|\n\n## Contact Us)",
        markdown,
        flags=re.DOTALL,
    )
    if not match:
        return ""
    return clean_spaces(match.group("body"))


def extract_features_block(markdown: str) -> str:
    match = re.search(r"\*\*Features\*\*\n\n(?P<body>.*?)(?:\n\n## Contact Us|\n\n## Unit Details)", markdown, flags=re.DOTALL)
    if not match:
        return ""
    lines = [clean_spaces(line) for line in match.group("body").splitlines() if clean_spaces(line)]
    return " ".join(lines)


def infer_activity(url: str, details: str, features: str) -> str:
    lower_details = details.lower()
    lower_features = features.lower()

    if "/build-suit/" in url or "/land-sale/" in url or "/land-lease/" in url:
        if "truck yard" in lower_features or "outdoor storage" in lower_features:
            return "Build-to-suit industrial land / truck yard / outdoor storage"
        return "Build-to-suit industrial land"

    if "/spec-building/" in url:
        if "industrial warehouse" in lower_details and "distribution" in lower_details:
            return "Spec industrial warehouse / distribution facility"
        if "industrial warehouse" in lower_details:
            return "Spec industrial warehouse"
        if "logistics facility" in lower_details:
            return "Spec logistics facility"
        return "Spec industrial warehouse"

    if "logistics facility" in lower_details and "warehouse" in lower_details:
        return "Industrial warehouse / logistics facility"
    if "industrial warehouse" in lower_details:
        return "Industrial warehouse"
    if "distribution" in lower_details:
        return "Distribution / logistics facility"
    return "Industrial property"


def extract_detail_address_lines(markdown: str) -> List[str]:
    match = re.search(
        r"\n\s*Address\s*\n\n(?P<body>.*?)(?:\n\n\s*Property Contacts\s*\n|\n\n\s*### Property Details\s*\n)",
        markdown,
        flags=re.DOTALL,
    )
    if not match:
        return []
    return clean_address_lines(match.group("body").splitlines())


def parse_market_cards(markdown: str, source_url: str) -> Dict[str, Dict[str, str]]:
    lines = markdown.splitlines()
    fallbacks: Dict[str, Dict[str, str]] = {}
    i = 0
    while i < len(lines):
        current = lines[i].strip()
        heading = re.match(r"### \[(?P<name>.+?)\]\((?P<url>https?://[^)]+)\)", current)
        if not heading:
            i += 1
            continue

        name_local = clean_spaces(heading.group("name"))
        detail_url = canonicalize_url(heading.group("url"))
        i += 1
        address_lines: List[str] = []
        while i < len(lines):
            probe = lines[i].strip()
            if re.match(r"### \[", probe) or probe.startswith("## ") or probe.startswith("[View All"):
                break
            if probe.startswith("*   ["):
                break
            if not probe:
                i += 1
                continue
            probe = re.sub(r"\s*\*\*Total.*$", "", probe).strip()
            if not probe or probe.startswith("Available ") or probe.startswith("Total ") or " SF " in probe and not re.search(r"\b\d{5}\b", probe):
                i += 1
                continue
            address_lines.append(probe)
            i += 1

        parsed = parse_mexico_address(address_lines)
        fallbacks[detail_url] = {
            "name_local": name_local,
            "location_address_local": parsed["location_address_local"],
            "location_address": parsed["location_address"],
            "postcode": parsed["postcode"],
            "city": parsed["city"],
            "state": parsed["state"],
            "market_source_url": source_url,
        }
    return fallbacks


def parse_heading_fallback(name_local: str) -> Dict[str, str]:
    ascii_name = ascii_text(name_local)
    parts = [clean_spaces(part) for part in ascii_name.split(",") if clean_spaces(part)]
    city = ""
    state = ""

    if len(parts) >= 2:
        city = parts[0]
        state = canonical_state(parts[1])

    if ascii_name.startswith("Monterrey, Apodaca"):
        city = "Apodaca"
        state = "Nuevo Leon"
    elif ascii_name.startswith("Mexico City, D.F"):
        city = "Mexico City"
        state = "Mexico City"
    elif ascii_name.startswith("CD Juarez"):
        city = "CD Juarez"
        state = "Chihuahua"

    return {"city": city, "state": state}


def normalize_country(value: str) -> str:
    cleaned = clean_spaces(ascii_text(value.replace("Country:", "")))
    return COUNTRY_ALIASES.get(cleaned, cleaned)


def country_iso3(country: str) -> str:
    return COUNTRY_ISO3_MAP.get(country, "")


def parse_office_heading_fallback(name_local: str, country: str) -> Dict[str, str]:
    ascii_name = clean_spaces(ascii_text(name_local))
    parts = [clean_spaces(part) for part in ascii_name.split(",") if clean_spaces(part)]
    city = parts[0] if parts else ""
    state = ""

    country_tokens = {country.lower()}
    if country == "United Kingdom":
        country_tokens.add("uk")
    if country == "United States":
        country_tokens.add("usa")
    if country == "United Arab Emirates":
        country_tokens.add("uae")
    if country == "Netherlands":
        country_tokens.add("the netherlands")

    for part in parts[1:]:
        if part.lower() in country_tokens:
            continue
        state = canonical_state(part)
        break

    if ascii_name.startswith("Monterrey, Apodaca"):
        city = "Apodaca"
        state = "Nuevo Leon"
    elif ascii_name.startswith("Mexico City, D.F"):
        city = "Mexico City"
        state = "Mexico City"
    elif ascii_name.startswith("CD Juarez"):
        city = "CD Juarez"
        state = "Chihuahua"
    elif ascii_name.startswith("Seattle, WA (Federal Way)"):
        city = "Federal Way"
        state = "WA"
    elif ascii_name.startswith("Hong Kong"):
        city = "Hong Kong"
    elif ascii_name.startswith("Luxembourg"):
        city = "Luxembourg"

    return {"city": city, "state": state}


def extract_postcode_value(lines: List[str]) -> str:
    for line in reversed(lines):
        for pattern in POSTCODE_PATTERNS:
            match = pattern.search(line)
            if match:
                return match.group(0)
    return ""


def strip_country_suffix(value: str, country: str) -> str:
    value = clean_spaces(value.strip(" ,-"))
    country_ascii = ascii_text(country)
    if value.lower().endswith(country_ascii.lower()):
        value = value[: -len(country_ascii)].rstrip(" ,-")
    return clean_spaces(value)


def parse_global_office_address(
    address_lines_local: List[str],
    name_local: str,
    country: str,
) -> Dict[str, str]:
    local_lines = clean_address_lines(address_lines_local)
    if country == "Mexico":
        return parse_mexico_address(local_lines, heading_fallback=parse_office_heading_fallback(name_local, country))

    local_address = build_local_address(local_lines)
    ascii_address = geocode_friendly_address(ascii_text(local_address))
    ascii_lines = [clean_spaces(ascii_text(line)) for line in local_lines]
    heading_fallback = parse_office_heading_fallback(name_local, country)

    postcode = extract_postcode_value(ascii_lines)
    city = ""
    state = ""

    def apply_line_patterns(line: str) -> bool:
        nonlocal city, state, postcode
        patterns = [
            re.match(
                r"^(?P<city>[^,]+),\s*(?P<state>[^,]+)\s+(?P<pc>[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}|[A-Z]\d[A-Z]\s?\d[A-Z]\d|L-\d{4}|\d{4}\s?[A-Z]{2}|\d{3}\s?\d{2}|\d{2}-\d{3}|\d{3}-\d{4}|\d{5}-\d{3}|\d{6}|\d{5}(?:-\d{4})?|\d{4}|\d{3})$",
                line,
            ),
            re.match(
                r"^(?P<city>[^,]+)-(?P<state>[A-Za-z]{2,20})\s+(?P<pc>[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}|[A-Z]\d[A-Z]\s?\d[A-Z]\d|L-\d{4}|\d{4}\s?[A-Z]{2}|\d{3}\s?\d{2}|\d{2}-\d{3}|\d{3}-\d{4}|\d{5}-\d{3}|\d{6}|\d{5}(?:-\d{4})?|\d{4}|\d{3})$",
                line,
            ),
            re.match(
                r"^(?P<city>[^,]+)\s+(?P<state>[A-Za-z]{2,20})\s+(?P<pc>[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}|[A-Z]\d[A-Z]\s?\d[A-Z]\d|L-\d{4}|\d{4}\s?[A-Z]{2}|\d{3}\s?\d{2}|\d{2}-\d{3}|\d{3}-\d{4}|\d{5}-\d{3}|\d{6}|\d{5}(?:-\d{4})?|\d{4}|\d{3})$",
                line,
            ),
            re.match(
                r"^(?P<city>.+?)\s+(?P<pc>[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}|[A-Z]\d[A-Z]\s?\d[A-Z]\d|L-\d{4}|\d{4}\s?[A-Z]{2}|\d{3}\s?\d{2}|\d{2}-\d{3}|\d{3}-\d{4}|\d{5}-\d{3}|\d{6}|\d{5}(?:-\d{4})?|\d{4}|\d{3})$",
                line,
            ),
            re.match(
                r"^(?P<pc>[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}|[A-Z]\d[A-Z]\s?\d[A-Z]\d|L-\d{4}|\d{4}\s?[A-Z]{2}|\d{3}\s?\d{2}|\d{2}-\d{3}|\d{3}-\d{4}|\d{5}-\d{3}|\d{6}|\d{5}(?:-\d{4})?|\d{4}|\d{3})\s*[-,]?\s*(?P<city>.+)$",
                line,
            ),
        ]
        for match in patterns:
            if not match:
                continue
            groups = match.groupdict()
            postcode = groups.get("pc", postcode) or postcode
            city = strip_country_suffix(groups.get("city", ""), country)
            state = clean_spaces(groups.get("state", ""))
            return True
        return False

    candidates = []
    if ascii_lines:
        candidates.append(ascii_lines[-1])
    if len(ascii_lines) >= 2:
        candidates.append(ascii_lines[-2])

    for candidate in candidates:
        if apply_line_patterns(candidate):
            break

    if not city and len(ascii_lines) >= 2 and postcode and postcode in ascii_lines[-2]:
        if ascii_lines[-1] and not any(ch.isdigit() for ch in ascii_lines[-1]):
            city = strip_country_suffix(ascii_lines[-1], country)

    if city and len(ascii_lines) >= 2:
        last_line = ascii_lines[-1]
        if not any(ch.isdigit() for ch in last_line) and clean_spaces(last_line.lower()) != clean_spaces(city.lower()):
            if not state:
                state = strip_country_suffix(last_line, country)

    if not city and ascii_lines:
        tail = strip_country_suffix(ascii_lines[-1], country)
        if tail and not any(ch.isdigit() for ch in tail):
            city = tail

    city = clean_spaces(city or heading_fallback.get("city", ""))
    state = clean_spaces(state or heading_fallback.get("state", ""))

    return {
        "location_address_local": local_address,
        "location_address": ascii_address,
        "postcode": clean_spaces(postcode),
        "state": canonical_state(state),
        "city": clean_spaces(city),
    }


def parse_office_locations(markdown: str, source_url: str) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    if "## Americas" not in markdown:
        return rows

    office_section = markdown.split("## Americas", 1)[1]
    if "## Footer" in office_section:
        office_section = office_section.split("## Footer", 1)[0]

    lines = office_section.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line.startswith("### "):
            i += 1
            continue

        name_local = clean_spaces(line[4:])
        i += 1
        block: List[str] = []
        while i < len(lines):
            probe = lines[i].strip()
            if probe.startswith("### ") or probe.startswith("## ") or probe.startswith("[View All"):
                break
            block.append(probe)
            i += 1

        country_line = next((item for item in block if item.startswith("Country:")), "")
        if not country_line:
            continue
        country = normalize_country(country_line)

        address_lines: List[str] = []
        for item in block:
            if not item:
                continue
            if item.startswith("Country:"):
                break
            if item.startswith("Phone:") or item.startswith("[Learn more"):
                continue
            address_lines.append(item)

        parsed = parse_global_office_address(address_lines, name_local, country)
        rows.append(
            {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": clean_spaces(ascii_text(name_local)),
                "LOCATION_NAME_LOCAL": name_local,
                "LOCATION_ADDRESS": parsed["location_address"],
                "LOCATION_ADDRESS_LOCAL": parsed["location_address_local"],
                "LATITUDE": "",
                "LONGITUDE": "",
                "coord_source": "not_on_website",
                "COUNTRY": country,
                "COUNTRY_ISO3": country_iso3(country),
                "POSTCODE": parsed["postcode"],
                "STATE": parsed["state"],
                "CITY": parsed["city"],
                "SOURCE_URL": canonicalize_url(source_url),
                "SOURCE_TYPE": SOURCE_TYPE,
                "ACTIVITY_AT_ASSET": "Market office",
            }
        )
    return rows


def parse_contact_page(markdown: str, source_url: str) -> Optional[Dict[str, str]]:
    match = re.search(r"##\s+Mexico\s*\n\n(?P<body>.*?)(?:\n\n##\s+LET'S GET STARTED|\Z)", markdown, flags=re.DOTALL)
    if not match:
        return None

    lines = [clean_spaces(line) for line in match.group("body").splitlines() if clean_spaces(line)]
    address_lines: List[str] = []
    for line in lines:
        if line == "Mexico":
            continue
        if line.startswith("+52") or line.startswith("Contact Us"):
            break
        address_lines.append(line)

    parsed = parse_mexico_address(address_lines, heading_fallback={"city": "Mexico City", "state": "Mexico City"})
    if not parsed["location_address"] or not parsed["city"]:
        return None

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": "Prologis Mexico Office",
        "LOCATION_NAME_LOCAL": "Prologis Mexico Office",
        "LOCATION_ADDRESS": parsed["location_address"],
        "LOCATION_ADDRESS_LOCAL": parsed["location_address_local"],
        "LATITUDE": "",
        "LONGITUDE": "",
        "coord_source": "not_on_website",
        "COUNTRY": COUNTRY,
        "COUNTRY_ISO3": COUNTRY_ISO3,
        "POSTCODE": parsed["postcode"],
        "STATE": parsed["state"] or "Mexico City",
        "CITY": parsed["city"] or "Mexico City",
        "SOURCE_URL": canonicalize_url(source_url),
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": "Market office",
    }


def parse_property_page(detail_url: str, markdown: str, fallback: Optional[Dict[str, str]]) -> Dict[str, str]:
    fallback = fallback or {}
    name_local = extract_property_title(markdown) or fallback.get("name_local", "")
    details = extract_property_details(markdown)
    features = extract_features_block(markdown)
    detail_lines = extract_detail_address_lines(markdown)

    detail_fields = parse_mexico_address(detail_lines)
    best_local_address = detail_fields["location_address_local"] or fallback.get("location_address_local", "")
    if not best_local_address:
        best_local_address = fallback.get("location_address_local", "")
    best_ascii_address = geocode_friendly_address(ascii_text(best_local_address))

    postcode = detail_fields["postcode"] or fallback.get("postcode", "")
    city = detail_fields["city"] or fallback.get("city", "")
    state = detail_fields["state"] or fallback.get("state", "")

    latitude, longitude = extract_coord(markdown)
    coord_source = "website" if latitude and longitude else "not_on_website"

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": clean_spaces(ascii_text(name_local)),
        "LOCATION_NAME_LOCAL": name_local,
        "LOCATION_ADDRESS": best_ascii_address,
        "LOCATION_ADDRESS_LOCAL": best_local_address,
        "LATITUDE": latitude,
        "LONGITUDE": longitude,
        "coord_source": coord_source,
        "COUNTRY": COUNTRY,
        "COUNTRY_ISO3": COUNTRY_ISO3,
        "POSTCODE": clean_spaces(postcode),
        "STATE": clean_spaces(ascii_text(state)),
        "CITY": clean_spaces(ascii_text(city)),
        "SOURCE_URL": canonicalize_url(detail_url),
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": infer_activity(detail_url, details, features),
    }


def write_csv(path: Path, rows: List[Dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


def save_progress(
    rows: List[Dict[str, str]],
    failures: List[Dict[str, str]],
    completed: int,
    total: int,
    started_at: float,
) -> None:
    write_json(PARTIAL_ROWS_JSON, rows)
    write_json(FAILURES_JSON, failures)
    write_json(
        PROGRESS_JSON,
        {
            "updated_at": now_iso(),
            "completed_detail_pages": completed,
            "total_detail_pages": total,
            "row_count": len(rows),
            "failure_count": len(failures),
            "elapsed_seconds": round(time.monotonic() - started_at, 2),
        },
    )


def office_duplicate_key(row: Dict[str, str]) -> Tuple[str, str, str]:
    return (
        clean_spaces(row["LOCATION_ADDRESS"].lower()),
        clean_spaces(row["CITY"].lower()),
        clean_spaces(row["STATE"].lower()),
    )


def dedupe_office_rows(existing_rows: List[Dict[str, str]], candidate_rows: List[Dict[str, str]]) -> List[Dict[str, str]]:
    seen = {office_duplicate_key(row) for row in existing_rows if "/industrial-properties/" not in row["SOURCE_URL"]}
    output = list(existing_rows)
    for row in candidate_rows:
        key = office_duplicate_key(row)
        if key in seen:
            continue
        output.append(row)
        seen.add(key)
    return output


def has_matching_office_row(existing_rows: List[Dict[str, str]], candidate: Dict[str, str]) -> bool:
    candidate_city = clean_spaces(candidate["CITY"].lower())
    candidate_state = clean_spaces(candidate["STATE"].lower())
    candidate_postcode = clean_spaces(candidate["POSTCODE"])
    candidate_address = clean_spaces(candidate["LOCATION_ADDRESS"].lower())
    for row in existing_rows:
        if "/industrial-properties/" in row["SOURCE_URL"]:
            continue
        if clean_spaces(row["CITY"].lower()) != candidate_city:
            continue
        if clean_spaces(row["STATE"].lower()) != candidate_state:
            continue
        if clean_spaces(row["POSTCODE"]) == candidate_postcode:
            return True
        if candidate_address and candidate_address in clean_spaces(row["LOCATION_ADDRESS"].lower()):
            return True
    return False


def main() -> None:
    ensure_dir(TEMP_DIR)
    ensure_dir(OUTPUT_DIR)

    started_at = time.monotonic()

    sitemap_raw = fetch_mirror_text(SITEMAP_URL)
    SITEMAP_TXT.write_text(sitemap_raw, encoding="utf-8")
    sitemap_markdown = extract_markdown(sitemap_raw)

    property_urls, market_urls = parse_sitemap_urls(sitemap_markdown)
    write_json(PROPERTY_URLS_JSON, property_urls)
    write_json(MARKET_URLS_JSON, market_urls)

    market_fallbacks: Dict[str, Dict[str, str]] = {}
    for market_url in market_urls:
        try:
            market_markdown = extract_markdown(fetch_mirror_text(market_url))
            market_fallbacks.update(parse_market_cards(market_markdown, market_url))
        except Exception as exc:  # noqa: BLE001 - capture non-fatal market failures
            print(f"MARKET_FETCH_FAILED|{market_url}|{exc}")

    write_json(MARKET_CARD_JSON, market_fallbacks)

    property_rows: List[Dict[str, str]] = []
    failures: List[Dict[str, str]] = []
    checkpoint_written = False

    def worker(detail_url: str) -> Dict[str, str]:
        markdown = extract_markdown(fetch_mirror_text(detail_url))
        return parse_property_page(detail_url, markdown, market_fallbacks.get(detail_url))

    with ThreadPoolExecutor(max_workers=PROPERTY_WORKERS) as pool:
        future_map = {pool.submit(worker, url): url for url in property_urls}
        completed = 0
        total = len(future_map)
        for future in as_completed(future_map):
            detail_url = future_map[future]
            completed += 1
            try:
                row = future.result()
                if not row["LOCATION_ADDRESS"] or not row["CITY"]:
                    raise ValueError("Missing mandatory LOCATION_ADDRESS or CITY")
                property_rows.append(row)
            except Exception as exc:  # noqa: BLE001 - record detail failures for review
                failures.append({"source_url": detail_url, "error": str(exc)})

            if completed % PROGRESS_SAVE_EVERY == 0 or completed == total:
                save_progress(property_rows, failures, completed, total, started_at)

            if not checkpoint_written and len(property_rows) >= COUNT_THRESHOLD:
                write_csv(CHECKPOINT_CSV, sorted(property_rows, key=lambda row: row["SOURCE_URL"]))
                checkpoint_written = True

    office_rows = parse_office_locations(extract_markdown(fetch_mirror_text(OFFICE_LOCATIONS_URL)), OFFICE_LOCATIONS_URL)
    contact_row = parse_contact_page(extract_markdown(fetch_mirror_text(CONTACT_URL)), CONTACT_URL)
    if contact_row and not has_matching_office_row(office_rows, contact_row):
        office_rows = dedupe_office_rows(office_rows, [contact_row])

    final_rows = sorted(property_rows, key=lambda row: row["SOURCE_URL"])
    final_rows = dedupe_office_rows(final_rows, office_rows)

    if not checkpoint_written and len(final_rows) >= COUNT_THRESHOLD:
        write_csv(CHECKPOINT_CSV, final_rows[:COUNT_THRESHOLD])
        checkpoint_written = True

    write_csv(FINAL_CSV, final_rows)

    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "generated_at": now_iso(),
        "property_url_count": len(property_urls),
        "market_url_count": len(market_urls),
        "property_rows_kept": len(property_rows),
        "office_rows_added": len(final_rows) - len(property_rows),
        "final_row_count": len(final_rows),
        "checkpoint_written": checkpoint_written,
        "failure_count": len(failures),
        "rows_with_blank_state": sum(1 for row in final_rows if not row["STATE"]),
        "rows_with_blank_latlon": sum(1 for row in final_rows if not row["LATITUDE"] or not row["LONGITUDE"]),
        "elapsed_seconds": round(time.monotonic() - started_at, 2),
        "final_csv": str(FINAL_CSV),
        "checkpoint_csv": str(CHECKPOINT_CSV) if checkpoint_written else "",
    }
    write_json(SUMMARY_JSON, summary)

    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
