"""
Closeby embed locator extractor with optional supplemental static locations.

Pattern handled:
- Shopify or static pages that embed a Closeby map widget via
  `window.closeby = { mapKey: "...", options: { embed: true } }`
- Optional supplemental static HTML office/store rows from additional issuer
  pages that should be merged into the same final CSV

How to reuse:
1. Update the configuration block for a new issuer.
2. Point `CLOSEBY_PAGE_URL` at the page that embeds the Closeby widget.
3. Set `CLOSEBY_MAP_KEY` to the widget map key or let the page reveal it.
4. Add any supplemental static sources to `SUPPLEMENTAL_SOURCE_URLS`.
5. Run the script. It writes progress every 20 processed rows, creates a
   checkpoint CSV when the threshold is crossed, validates required fields,
   and writes the final issuer CSV plus a local extraction-memory draft.
"""

from __future__ import annotations

import csv
import json
import re
import time
import unicodedata
from html import unescape
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import requests
import urllib3
from bs4 import BeautifulSoup


# ============================================================================
# CONFIGURATION - Change these for each new issuer
# ============================================================================
ISSUER_ID = "IID000000002132728"
ISSUER_NAME = "ANTA SPORTS PRODUCTS LIMITED"
SOURCE_TYPE = "COMPANY WEBSITE"
COUNT_THRESHOLD = 59

CLOSEBY_PAGE_URL = "https://www.anta.ph/pages/store-locator"
CLOSEBY_EMBED_URL = "https://www.closeby.co/embed/c6bb113621af8947189053e90f0ebbe9?embed_version=v1&responsive_mobile_height=true&embed=true"
CLOSEBY_MAP_KEY = "c6bb113621af8947189053e90f0ebbe9"
CLOSEBY_API_BASE = f"https://www.closeby.co/embed/{CLOSEBY_MAP_KEY}"

US_RETAIL_URL = "https://anta.com/pages/retail"
IR_INFO_URL = "https://ir.anta.com/en/about_info.php"

SUPPLEMENTAL_SOURCE_URLS = [US_RETAIL_URL, IR_INFO_URL]

TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")
OUTPUT_BASENAME = f"{ISSUER_ID}_{ISSUER_NAME}"
FINAL_CSV = OUTPUT_DIR / f"{OUTPUT_BASENAME}.csv"
CHECKPOINT_CSV = TEMP_DIR / f"{OUTPUT_BASENAME}_checkpoint.csv"
PROGRESS_JSON = TEMP_DIR / f"{ISSUER_ID}_progress.json"
SUMMARY_JSON = TEMP_DIR / f"{OUTPUT_BASENAME}_summary.json"
MEMORY_DRAFT = TEMP_DIR / f"{ISSUER_ID}_memory_append_draft.md"

PROGRESS_SAVE_EVERY = 20

CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS",
    "LOCATION_ADDRESS_NATIVE",
    "LATITUDE",
    "LONGITUDE",
    "coord_source",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
]

PH_STATE_TOKENS = {
    "Metro Manila",
    "Davao del Sur",
    "Cebu",
    "Laguna",
    "Cavite",
    "Cagayan",
    "Isabela",
    "Camarines Sur",
    "Misamis Oriental",
    "Batangas",
    "Albay",
    "Negros Occidental",
    "Zambales",
    "Davao del Norte",
    "Pampanga",
    "Negros Oriental",
    "Leyte",
    "Rizal",
    "Camarines Norte",
}

PH_BAD_CITY_MARKERS = (
    "ave",
    "avenue",
    "road",
    " rd",
    "street",
    " st",
    "highway",
    " hwy",
    "boulevard",
    " blvd",
    "mall",
    "district",
    "barangay",
    "brgy",
    "village",
    "zone",
    "park",
    "center",
    "centre",
    "wing",
    "floor",
    "area",
)

COUNTRY_META = {
    "Philippines": "PHL",
    "United States": "USA",
    "China": "CHN",
    "Hong Kong": "HKG",
    "Cayman Islands": "CYM",
}

PH_ACTIVITY_MAP = {
    "ANTA": "Retail store",
    "ANTA Basketball": "Basketball retail store",
    "ANTA Kids": "Kids retail store",
    "ANTA Outlet": "Outlet retail store",
    "ANTA Superstore": "Superstore retail store",
}

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


# ============================================================================
# GENERIC EXTRACTION LOGIC BELOW - Do not modify per-issuer
# ============================================================================
def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def ascii_text(value: str | None) -> str:
    if value is None:
        return ""
    value = value.replace("\u00a0", " ").replace("\u2013", "-").replace("\u2014", "-")
    value = unicodedata.normalize("NFKD", value)
    value = value.encode("ascii", "ignore").decode("ascii")
    return clean_text(value)


def clean_text(value: str | None) -> str:
    if value is None:
        return ""
    value = unescape(str(value))
    value = value.replace("\r", " ").replace("\n", " ").replace("\u00a0", " ")
    value = re.sub(r"\s+", " ", value).strip()
    value = value.replace(" ,", ",")
    return value.strip(" ,")


def geocode_friendly(value: str) -> str:
    return clean_text(value.replace("#", ""))


def html_fragment_to_text(value: str | None) -> str:
    if not value:
        return ""
    soup = BeautifulSoup(unescape(value), "html.parser")
    return clean_text(soup.get_text(" ", strip=True))


def normalize_floor_text(value: str) -> str:
    value = clean_text(value)
    replacements = {
        "Florr": "Floor",
        "Flr.": "Floor",
        "Flr": "Floor",
        "1st floor": "1st Floor",
        "2nd floor": "2nd Floor",
        "3rd floor": "3rd Floor",
        "4th floor": "4th Floor",
        "Ground floor": "Ground Floor",
        "Upper ground floor": "Upper Ground Floor",
    }
    for src, dst in replacements.items():
        value = value.replace(src, dst)
    return clean_text(value)


def combined_address(core_address: str, welcome_text: str) -> str:
    core_address = clean_text(core_address)
    welcome_text = normalize_floor_text(welcome_text)
    if welcome_text and welcome_text.lower() not in core_address.lower():
        return clean_text(f"{welcome_text}, {core_address}")
    return core_address


def native_value(original: str, ascii_version: str) -> str:
    original = clean_text(original)
    ascii_version = clean_text(ascii_version)
    return original if original and original != ascii_version else ""


def format_coord(value: object) -> str:
    if value in (None, ""):
        return ""
    try:
        number = float(value)
    except (TypeError, ValueError):
        return ""
    return f"{number:.7f}".rstrip("0").rstrip(".")


def write_json(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def write_csv(path: Path, rows: Sequence[Dict[str, str]]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in CSV_COLUMNS})


def build_session() -> requests.Session:
    session = requests.Session()
    session.headers.update({"User-Agent": "Mozilla/5.0 (compatible; Codex Closeby extractor)"})
    return session


def fetch_text(session: requests.Session, url: str) -> str:
    response = session.get(url, timeout=45, verify=False)
    response.raise_for_status()
    return response.text


def fetch_json(session: requests.Session, url: str, *, params: dict | None = None) -> object:
    response = session.get(url, params=params, timeout=45, verify=False)
    response.raise_for_status()
    return response.json()


def is_bad_city_token(token: str) -> bool:
    lower = token.lower()
    if re.fullmatch(r"[A-Z0-9]{2,}\+[A-Z0-9]{2,}", token, re.I):
        return True
    return any(marker in lower for marker in PH_BAD_CITY_MARKERS)


def normalize_city_token(token: str) -> str:
    token = clean_text(token)
    token = re.sub(r"^City of\s+", "", token, flags=re.I)
    return token


def parse_ph_address(core_address_ascii: str) -> Tuple[str, str, str]:
    parts = [normalize_city_token(part) for part in core_address_ascii.split(",") if clean_text(part)]
    if parts and parts[-1].lower() == "philippines":
        parts.pop()

    postcode = ""
    state = ""

    if parts:
        postcode_state = re.match(r"^(\d{4,5})\s+(.+)$", parts[-1])
        if postcode_state:
            postcode = postcode_state.group(1)
            state = clean_text(postcode_state.group(2))
            parts.pop()
        elif parts[-1] in PH_STATE_TOKENS:
            state = parts.pop()

    city = ""
    for token in reversed(parts):
        candidate = normalize_city_token(token)
        if not is_bad_city_token(candidate):
            city = candidate
            break

    if not city:
        city = state

    return postcode, state, city


def parse_us_address(address_ascii: str) -> Tuple[str, str, str]:
    match = re.match(r"^(.*?),\s*([^,]+),\s*([A-Z]{2})\s+(\d{5}(?:-\d{4})?)$", address_ascii)
    if not match:
        raise ValueError(f"Could not parse US address: {address_ascii}")
    street = clean_text(match.group(1))
    city = clean_text(match.group(2))
    state = clean_text(match.group(3))
    postcode = clean_text(match.group(4))
    return city, state, postcode


def get_ir_lines(session: requests.Session) -> List[str]:
    soup = BeautifulSoup(fetch_text(session, IR_INFO_URL), "html.parser")
    lines = [clean_text(line) for line in soup.get_text("\n", strip=True).splitlines()]
    deduped: List[str] = []
    for line in lines:
        if line and (not deduped or deduped[-1] != line):
            deduped.append(line)
    return deduped


def extract_block(lines: Sequence[str], start_marker: str, stop_markers: Iterable[str]) -> List[str]:
    start_index = lines.index(start_marker)
    block: List[str] = []
    for line in lines[start_index + 1 :]:
        if line in stop_markers:
            break
        block.append(line)
    return block


def join_address_lines(lines: Sequence[str]) -> str:
    joined = clean_text(", ".join(clean_text(line) for line in lines if clean_text(line)))
    joined = re.sub(r",\s*,", ", ", joined)
    return clean_text(joined)


def extract_ir_rows(session: requests.Session) -> List[Dict[str, str]]:
    lines = get_ir_lines(session)

    cayman_address = join_address_lines(
        extract_block(
            lines,
            "Cayman Islands Office",
            {"Principal Place of Business in Hong Kong SAR"},
        )
    )
    hong_kong_address = join_address_lines(
        extract_block(
            lines,
            "Hong Kong SAR Office",
            {"Head offices in Chinese Mainland"},
        )
    )
    jinjiang_address = join_address_lines(
        extract_block(
            lines,
            "Jinjiang Office",
            {"Xiamen Office"},
        )
    )
    xiamen_address = join_address_lines(
        extract_block(
            lines,
            "Xiamen Office",
            {"Share Registrars and Transfer Offices"},
        )
    )

    jinjiang_address = re.sub(r",?\s*Postal code:\s*362212$", "", jinjiang_address, flags=re.I)
    xiamen_address = re.sub(r",?\s*Postal code:\s*361008$", "", xiamen_address, flags=re.I)

    rows = [
        {
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": "Cayman Islands Office",
            "LOCATION_NAME_NATIVE": "",
            "LOCATION_ADDRESS": geocode_friendly(ascii_text(cayman_address)),
            "LOCATION_ADDRESS_NATIVE": native_value(cayman_address, ascii_text(cayman_address)),
            "LATITUDE": "",
            "LONGITUDE": "",
            "coord_source": "not_on_website",
            "COUNTRY": "Cayman Islands",
            "COUNTRY_ISO3": COUNTRY_META["Cayman Islands"],
            "POSTCODE": "KY1-1111",
            "STATE": "",
            "CITY": "Grand Cayman",
            "SOURCE_URL": IR_INFO_URL,
            "SOURCE_TYPE": SOURCE_TYPE,
            "ACTIVITY_AT_ASSET": "Registered office",
        },
        {
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": "Hong Kong SAR Office",
            "LOCATION_NAME_NATIVE": "",
            "LOCATION_ADDRESS": geocode_friendly(ascii_text(hong_kong_address)),
            "LOCATION_ADDRESS_NATIVE": native_value(hong_kong_address, ascii_text(hong_kong_address)),
            "LATITUDE": "",
            "LONGITUDE": "",
            "coord_source": "not_on_website",
            "COUNTRY": "Hong Kong",
            "COUNTRY_ISO3": COUNTRY_META["Hong Kong"],
            "POSTCODE": "",
            "STATE": "Kowloon",
            "CITY": "Kowloon Bay",
            "SOURCE_URL": IR_INFO_URL,
            "SOURCE_TYPE": SOURCE_TYPE,
            "ACTIVITY_AT_ASSET": "Principal place of business",
        },
        {
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": "Jinjiang Office",
            "LOCATION_NAME_NATIVE": "",
            "LOCATION_ADDRESS": geocode_friendly(ascii_text(jinjiang_address)),
            "LOCATION_ADDRESS_NATIVE": native_value(jinjiang_address, ascii_text(jinjiang_address)),
            "LATITUDE": "",
            "LONGITUDE": "",
            "coord_source": "not_on_website",
            "COUNTRY": "China",
            "COUNTRY_ISO3": COUNTRY_META["China"],
            "POSTCODE": "362212",
            "STATE": "Fujian Province",
            "CITY": "Jinjiang City",
            "SOURCE_URL": IR_INFO_URL,
            "SOURCE_TYPE": SOURCE_TYPE,
            "ACTIVITY_AT_ASSET": "Head office",
        },
        {
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": "Xiamen Office",
            "LOCATION_NAME_NATIVE": "",
            "LOCATION_ADDRESS": geocode_friendly(ascii_text(xiamen_address)),
            "LOCATION_ADDRESS_NATIVE": native_value(xiamen_address, ascii_text(xiamen_address)),
            "LATITUDE": "",
            "LONGITUDE": "",
            "coord_source": "not_on_website",
            "COUNTRY": "China",
            "COUNTRY_ISO3": COUNTRY_META["China"],
            "POSTCODE": "361008",
            "STATE": "Fujian Province",
            "CITY": "Xiamen",
            "SOURCE_URL": IR_INFO_URL,
            "SOURCE_TYPE": SOURCE_TYPE,
            "ACTIVITY_AT_ASSET": "Head office",
        },
    ]
    return rows


def extract_us_flagship(session: requests.Session) -> Dict[str, str]:
    soup = BeautifulSoup(fetch_text(session, US_RETAIL_URL), "html.parser")

    heading = ""
    address = ""
    for h2 in soup.find_all("h2"):
        text = clean_text(h2.get_text(" ", strip=True))
        if "Flagship" in text:
            heading = text
            strong = h2.find_next("strong")
            if strong:
                address = clean_text(strong.get_text(", ", strip=True))
            break

    if not heading or not address:
        raise RuntimeError("Could not locate the ANTA Beverly Hills flagship block.")

    heading_ascii = ascii_text(heading)
    address_ascii = geocode_friendly(ascii_text(address))
    city, state, postcode = parse_us_address(address_ascii)
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": heading_ascii,
        "LOCATION_NAME_NATIVE": native_value(heading, heading_ascii),
        "LOCATION_ADDRESS": address_ascii,
        "LOCATION_ADDRESS_NATIVE": native_value(address, address_ascii),
        "LATITUDE": "",
        "LONGITUDE": "",
        "coord_source": "not_on_website",
        "COUNTRY": "United States",
        "COUNTRY_ISO3": COUNTRY_META["United States"],
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": US_RETAIL_URL,
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": "Flagship retail store",
    }


def extract_closeby_rows(session: requests.Session) -> List[Dict[str, str]]:
    payload = fetch_json(session, f"{CLOSEBY_API_BASE}/locations")
    locations = payload["locations"]
    rows: List[Dict[str, str]] = []

    for location in locations:
        name_original = clean_text(location.get("title"))
        address_original = clean_text(location.get("address_full"))
        welcome_original = html_fragment_to_text(location.get("welcome_text"))

        name_ascii = ascii_text(name_original)
        core_address_ascii = geocode_friendly(ascii_text(address_original))
        location_address_ascii = geocode_friendly(combined_address(core_address_ascii, ascii_text(welcome_original)))

        core_address_native = clean_text(address_original)
        welcome_native = html_fragment_to_text(location.get("welcome_text"))
        location_address_native_full = clean_text(combined_address(core_address_native, welcome_native))

        postcode, state, city = parse_ph_address(core_address_ascii)
        categories = location.get("categories") or []
        category = categories[0] if categories else "ANTA"
        activity = PH_ACTIVITY_MAP.get(category, "Retail store")

        rows.append(
            {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": name_ascii,
                "LOCATION_NAME_NATIVE": native_value(name_original, name_ascii),
                "LOCATION_ADDRESS": location_address_ascii,
                "LOCATION_ADDRESS_NATIVE": native_value(location_address_native_full, location_address_ascii),
                "LATITUDE": format_coord(location.get("latitude")),
                "LONGITUDE": format_coord(location.get("longitude")),
                "coord_source": "website" if location.get("latitude") not in (None, "") and location.get("longitude") not in (None, "") else "not_on_website",
                "COUNTRY": "Philippines",
                "COUNTRY_ISO3": COUNTRY_META["Philippines"],
                "POSTCODE": postcode,
                "STATE": state,
                "CITY": city,
                "SOURCE_URL": CLOSEBY_PAGE_URL,
                "SOURCE_TYPE": SOURCE_TYPE,
                "ACTIVITY_AT_ASSET": activity,
            }
        )

    rows.sort(key=lambda row: row["LOCATION_NAME"])
    return rows


def validate_rows(rows: Sequence[Dict[str, str]]) -> Dict[str, object]:
    blank_city = [row["LOCATION_NAME"] for row in rows if not clean_text(row["CITY"])]
    blank_address = [row["LOCATION_NAME"] for row in rows if not clean_text(row["LOCATION_ADDRESS"])]
    hash_rows = [row["LOCATION_NAME"] for row in rows if "#" in row["LOCATION_ADDRESS"]]
    duplicate_keys = sorted(
        {
            key
            for key, count in _count_keys(
                (
                    clean_text(row["LOCATION_NAME"]).lower(),
                    clean_text(row["LOCATION_ADDRESS"]).lower(),
                    clean_text(row["CITY"]).lower(),
                )
                for row in rows
            ).items()
            if count > 1
        }
    )
    return {
        "blank_city_rows": blank_city,
        "blank_address_rows": blank_address,
        "hash_rows": hash_rows,
        "duplicate_keys": duplicate_keys,
    }


def _count_keys(keys: Iterable[Tuple[str, str, str]]) -> Dict[Tuple[str, str, str], int]:
    counts: Dict[Tuple[str, str, str], int] = {}
    for key in keys:
        counts[key] = counts.get(key, 0) + 1
    return counts


def save_progress(processed_rows: Sequence[Dict[str, str]], *, total_expected: int, checkpoint_written: bool) -> None:
    payload = {
        "timestamp": now_iso(),
        "processed_count": len(processed_rows),
        "total_expected": total_expected,
        "checkpoint_written": checkpoint_written,
        "last_location_name": processed_rows[-1]["LOCATION_NAME"] if processed_rows else "",
    }
    write_json(PROGRESS_JSON, payload)


def build_memory_draft(final_count: int, source_counts: Dict[str, int], checkpoint_count: int) -> str:
    return f"""## Pending Extraction Memory Update

> Update the knowledge-base header `Last Updated` date to 2026-04-07 when appending.

### 3.16 Closeby Embed Locator Pages
> **Detection**: Shopify or static pages embed Closeby with `window.closeby = {{ mapKey: "...", options: {{ embed: true }} }}` and load a Closeby iframe such as `/embed/{{mapKey}}?embed=true`.

**Key Characteristics**:
- The public page often contains only the Closeby widget container and map key.
- The iframe shell exposes React props but not the full store list.
- Closeby source maps are public, which reveals the internal locator endpoints.
- Full location data is returned directly by `/embed/{{mapKey}}/locations`.

**Best Approach**:
1. Confirm the page embeds Closeby and capture the `mapKey`.
2. Load the iframe once to confirm the embed shell and map metadata.
3. Call `/embed/{{mapKey}}/locations` for the rich location payload.
4. Use `/embed/{{mapKey}}/location_fixtures` only as a coverage check or fallback.
5. Keep the source page URL in `SOURCE_URL` even when the extraction uses the Closeby JSON endpoint behind the page.

**What Worked**:
- `https://www.closeby.co/embed/{{mapKey}}/locations` returned all 56 ANTA Philippines stores with address, title, categories, phone, email, and website-sourced coordinates.
- The source map for `588-*.js` exposed the `NEARBY_LOCATIONS` endpoint contract immediately.

**What Did Not Add Value**:
- Reverse engineering the minified iframe bundle by hand was unnecessary once the source map was discovered.
- `/location_fixtures` matched coverage but carried a lighter payload than `/locations`.

### 4.X ANTA SPORTS PRODUCTS LIMITED (Apr 2026)

| Source | URL | Records | Method | Script |
|--------|-----|---------|--------|--------|
| Philippines store locator | https://www.anta.ph/pages/store-locator | 56 | Closeby embed API behind Shopify page | `closeby_embed_locator_extractor.py` |
| US retail page | https://anta.com/pages/retail | 1 | Static HTML flagship address parse | `closeby_embed_locator_extractor.py` |
| Investor relations company information | https://ir.anta.com/en/about_info.php | 4 | Static HTML/text office block parse | `closeby_embed_locator_extractor.py` |
| **TOTAL** | | **{final_count}** | | |

**Platform Pattern**: [3.16 Closeby Embed Locator Pages](#316-closeby-embed-locator-pages)

**Key Approach**: Reused the KB reconnaissance workflow, identified the Shopify + Closeby embed pattern on the Philippines page, used the internal Closeby `/locations` endpoint for the store network, then supplemented it with static addresses from the US retail page and the IR company-information page to exceed the 59-record target.

**Approaches Tried** (chronological):
1. Read the knowledge base and checked existing reusable patterns. None matched Closeby directly, but the decision tree correctly pointed to hidden API discovery on a JS-rendered/store-locator page.
2. Fetched the ANTA Philippines HTML and found `window.closeby` plus the Closeby map key in the page source.
3. Loaded the Closeby iframe and then used the public Closeby source maps to recover the exact endpoints: `/embed/{{mapKey}}/locations`, `/embed/{{mapKey}}/location_fixtures`, and `/embed/{{mapKey}}/categories`.
4. Verified `/locations` and `/location_fixtures` both returned 56 stores; kept `/locations` as the main source because it included richer detail fields.
5. Parsed the single Beverly Hills flagship address from the US retail page and the four issuer office addresses from the IR company-information page.

**Key Learnings**:
- ✅ Closeby source maps make endpoint discovery straightforward when the public HTML only shows the iframe shell.
- ✅ `/embed/{{mapKey}}/locations` is the best primary dataset because it includes the detailed location object and website-sourced coordinates.
- ✅ The US retail page only exposed one physical flagship address; the rest of the page content was merchandising and regional-site navigation.
- ❌ The Closeby iframe HTML alone did not contain the store list; the records were loaded by React after mount.
- ❌ The ANTA US region selector JSON exposed country storefront links, not physical facility addresses, so it should not be counted as facilities.

**Script Config**:
```python
ISSUER_ID = "{ISSUER_ID}"
ISSUER_NAME = "{ISSUER_NAME}"
CLOSEBY_PAGE_URL = "{CLOSEBY_PAGE_URL}"
CLOSEBY_MAP_KEY = "{CLOSEBY_MAP_KEY}"
SUPPLEMENTAL_SOURCE_URLS = {SUPPLEMENTAL_SOURCE_URLS!r}
COUNT_THRESHOLD = {COUNT_THRESHOLD}
```

### 9.X File Inventory Row To Append

| `closeby_embed_locator_extractor.py` | ANTA Sports Products Limited (Generic) | Closeby embed locator + static supplement | Closeby source-map endpoint discovery, checkpointing, transliteration-safe export |

### 10.X Lessons Learned

- When a Closeby page is embedded in Shopify, the storefront HTML often contains the map key directly in `window.closeby`; this is enough to reach the iframe and internal JSON endpoints without browser automation.
- After the 59-row threshold is crossed, create a checkpoint CSV first, then continue scanning the provided sources for any remaining static office/store addresses before finalizing the output.
"""


def main() -> None:
    start = time.time()
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    session = build_session()

    closeby_rows = extract_closeby_rows(session)
    us_row = extract_us_flagship(session)
    ir_rows = extract_ir_rows(session)

    ordered_rows: List[Dict[str, str]] = []
    ordered_rows.extend(closeby_rows)
    ordered_rows.append(us_row)
    ordered_rows.extend(ir_rows[:2])
    ordered_rows.extend(ir_rows[2:])

    processed: List[Dict[str, str]] = []
    checkpoint_written = False

    for row in ordered_rows:
        processed.append(row)
        if len(processed) % PROGRESS_SAVE_EVERY == 0:
            save_progress(processed, total_expected=len(ordered_rows), checkpoint_written=checkpoint_written)
        if not checkpoint_written and len(processed) >= COUNT_THRESHOLD:
            write_csv(CHECKPOINT_CSV, processed[:COUNT_THRESHOLD])
            checkpoint_written = True
            save_progress(processed, total_expected=len(ordered_rows), checkpoint_written=checkpoint_written)

    if not checkpoint_written:
        write_csv(CHECKPOINT_CSV, processed)
        checkpoint_written = True

    validation = validate_rows(processed)
    if validation["blank_city_rows"] or validation["blank_address_rows"] or validation["hash_rows"] or validation["duplicate_keys"]:
        raise RuntimeError(f"Validation failed: {json.dumps(validation, ensure_ascii=False)}")

    write_csv(FINAL_CSV, processed)
    save_progress(processed, total_expected=len(ordered_rows), checkpoint_written=checkpoint_written)

    source_counts = {
        CLOSEBY_PAGE_URL: len(closeby_rows),
        US_RETAIL_URL: 1,
        IR_INFO_URL: len(ir_rows),
    }

    memory_draft = build_memory_draft(len(processed), source_counts, COUNT_THRESHOLD)
    MEMORY_DRAFT.write_text(memory_draft, encoding="utf-8")

    elapsed_seconds = round(time.time() - start, 2)
    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "final_count": len(processed),
        "threshold": COUNT_THRESHOLD,
        "checkpoint_count": COUNT_THRESHOLD if len(processed) >= COUNT_THRESHOLD else len(processed),
        "counts_by_source": source_counts,
        "output_csv": str(FINAL_CSV),
        "checkpoint_csv": str(CHECKPOINT_CSV),
        "memory_draft": str(MEMORY_DRAFT),
        "blank_city_rows": 0,
        "blank_address_rows": 0,
        "hash_rows": 0,
        "duplicate_rows": 0,
        "execution_seconds": elapsed_seconds,
        "human_interaction_seconds": 0,
        "token_usage": "not_available_in_runtime",
        "extraction_memory_token_impact": "reduced",
        "created_at": now_iso(),
    }
    write_json(SUMMARY_JSON, summary)


if __name__ == "__main__":
    main()
