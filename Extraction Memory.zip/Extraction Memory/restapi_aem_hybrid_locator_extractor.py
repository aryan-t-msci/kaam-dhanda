"""
Generalized extractor for hybrid location platforms where:
1. A primary brand exposes an open REST list/detail API for facilities.
2. Secondary brands publish Adobe Experience Manager (AEM) location pages discoverable via sitemap XML.

This script is configured for Whitbread PLC, but the extraction logic is intentionally generic and
reusable for similar "REST API + AEM sitemap" locator stacks.

How to adapt for another issuer:
1. Change the configuration block values below.
2. Point `BASE_API_URL`, `HOTELS_LIST_ENDPOINT`, and `HOTEL_DETAIL_ENDPOINT` at the live REST API.
3. Replace `BRAND_SITEMAPS` with the brand-site sitemap URLs that hold `/locations/` pages.
4. Adjust `HOTEL_BRAND_PREFIX` and `BRAND_ACTIVITY` mappings if the API / site naming differs.

Example:
    ISSUER_NAME = "Example Hospitality Group"
    ISSUER_ID = "IID000000000000000"
    BASE_API_URL = "https://restapi.example.com"
    HOTELS_LIST_ENDPOINT = "/locations"
    HOTEL_DETAIL_ENDPOINT = "/locations/{code}"
    BRAND_SITEMAPS = {
        "Example Grill": "https://www.examplegrill.com/sitemap.xml",
        "Example Pub": "https://www.examplepub.com/sitemap.xml",
    }

Usage:
    python restapi_aem_hybrid_locator_extractor.py

Outputs:
    - Temp audit CSV with `_source` and `_code`
    - Final CSV in the configured output folder
    - Progress JSON files for hotel repair and restaurant crawl
"""

from __future__ import annotations

import json
import re
import time
import unicodedata
import warnings
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
from urllib.parse import urlparse

import pandas as pd
import requests
from bs4 import BeautifulSoup


# ============================================================================
# CONFIGURATION — Change these for each issuer using the same platform pattern
# ============================================================================
ISSUER_ID = "IID000000002129162"
ISSUER_NAME = "WHITBREAD PLC"

OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Temp")
FINAL_OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Output")
FINAL_OUTPUT_NAME = f"{ISSUER_ID}_{ISSUER_NAME}.csv"

BASE_API_URL = "https://restapi.premierinn.com"
HOTELS_LIST_ENDPOINT = "/hotels"
HOTEL_DETAIL_ENDPOINT = "/hotels/{code}"
HOTEL_PUBLIC_URL_TEMPLATE = "https://www.premierinn.com/gb/en/hotels/{code_lower}.html"

HOTEL_BRAND_PREFIX = {
    "PI": "Premier Inn",
    "PID": "Premier Inn",
    "HUB": "Hub by Premier Inn",
    "ZIP": "ZIP by Premier Inn",
}

BRAND_SITEMAPS = {
    "Brewers Fayre": "https://www.brewersfayre.co.uk/sitemap.xml",
    "Beefeater": "https://www.beefeater.co.uk/sitemap.xml",
    "Bar+Block": "https://www.barandblock.co.uk/sitemap.xml",
    "Cookhouse & Pub": "https://www.cookhouseandpub.co.uk/sitemap.xml",
    "Table Table": "https://www.tabletable.co.uk/sitemap.xml",
    "Whitbread Inns": "https://www.whitbreadinns.co.uk/sitemap.xml",
}

BRAND_ACTIVITY = {
    "Brewers Fayre": "Restaurant / Pub",
    "Beefeater": "Restaurant / Pub",
    "Bar+Block": "Restaurant / Steakhouse",
    "Cookhouse & Pub": "Restaurant / Pub",
    "Table Table": "Restaurant / Pub",
    "Whitbread Inns": "Pub / Inn",
}

COUNTRY_MAP = {
    "england": "United Kingdom",
    "scotland": "United Kingdom",
    "wales": "United Kingdom",
    "northern ireland": "United Kingdom",
    "united kingdom": "United Kingdom",
    "united kingdom (the)": "United Kingdom",
    "uk": "United Kingdom",
    "germany": "Germany",
    "ireland": "Ireland",
    "republic of ireland": "Ireland",
    "ireland (republic of)": "Ireland",
    "uae": "United Arab Emirates",
    "dubai": "United Arab Emirates",
}

REQUEST_DELAY = 0.15
PROGRESS_SAVE_EVERY = 20
LOCATION_PAGE_TIMEOUT = 4

LIVE_HOTELS_PATH = OUTPUT_DIR / "whitbread_live_hotels.json"
HOTEL_REPAIR_PROGRESS_PATH = OUTPUT_DIR / "whitbread_hotel_repair_progress.json"
RESTAURANT_REFRESH_PROGRESS_PATH = OUTPUT_DIR / "whitbread_restaurant_refresh_progress.json"
AUDIT_OUTPUT_PATH = OUTPUT_DIR / "whitbread_hybrid_refresh_audit.csv"
HOTEL_CHECKPOINT_PATH = OUTPUT_DIR / "whitbread_hotel_checkpoint.csv"
SUMMARY_PATH = OUTPUT_DIR / "whitbread_hybrid_refresh_summary.json"

# Existing same-day artifacts reused where available.
HOTEL_PROGRESS_SOURCE = OUTPUT_DIR / "hotels_progress.json"


# ============================================================================
# GENERIC EXTRACTION LOGIC BELOW — do not modify per issuer unless the pattern
# itself differs.
# ============================================================================

warnings.filterwarnings("ignore")
try:
    import urllib3

    urllib3.disable_warnings()
except Exception:
    pass


HEADERS_HTML = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Accept": "text/html,application/xhtml+xml,*/*",
    "Accept-Language": "en-GB,en;q=0.9",
}

HEADERS_API = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Accept": "application/json",
    "Origin": "https://www.premierinn.com",
    "Referer": "https://www.premierinn.com/",
}

EXCLUDED_LOCATION_SLUGS = {
    "book",
    "menus",
    "menu",
    "offers",
    "gallery",
    "events",
    "rooms",
    "christmas",
    "activities",
    "private-dining",
    "bottomless-brunch",
    "bottomless-cocktails",
    "garden",
}

UK_POSTCODE_RE = re.compile(r"\b([A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2})\b", re.IGNORECASE)
UK_POSTCODE_O_RE = re.compile(r"\b([A-Z]{1,2}\d[A-Z\d]?\s*)O([A-Z]{2})\b", re.IGNORECASE)


def save_json(data: object, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)


def load_json(path: Path, default: object = None) -> object:
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def normalize_space(text: Optional[str]) -> str:
    if not text:
        return ""
    return re.sub(r"\s+", " ", str(text)).strip()


def clean_address(text: str) -> str:
    text = normalize_space(text.replace("#", ""))
    text = re.sub(r"\s+,", ",", text)
    text = re.sub(r",\s*,+", ", ", text)
    return text.strip(", ")


def clean_phone(text: Optional[str]) -> str:
    return re.sub(r"[^\d+\s\-()]", "", normalize_space(text or "")).strip()


def slug_to_title(slug: str) -> str:
    if not slug:
        return ""
    parts = [p for p in slug.replace("_", "-").split("-") if p]
    titled = []
    for part in parts:
        if part.lower() in {"and", "of", "on", "by", "the", "n"}:
            titled.append(part.upper() if part.lower() == "n" else part.lower())
        else:
            titled.append(part.capitalize())
    result = " ".join(titled)
    return result.replace("St ", "St. ")


def transliterate_ascii(text: Optional[str]) -> str:
    if not text:
        return ""
    text = str(text)

    # Handle German characters before generic NFKD normalization so ß becomes ss.
    replacements = {
        "ä": "ae",
        "ö": "oe",
        "ü": "ue",
        "Ä": "Ae",
        "Ö": "Oe",
        "Ü": "Ue",
        "ß": "ss",
        # Defensive replacements for common mojibake if a response is decoded oddly.
        "Ã¤": "ae",
        "Ã¶": "oe",
        "Ã¼": "ue",
        "Ã„": "Ae",
        "Ã–": "Oe",
        "Ãœ": "Ue",
        "ÃŸ": "ss",
    }
    for src, dst in replacements.items():
        text = text.replace(src, dst)

    normalized = unicodedata.normalize("NFKD", text)
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    return normalize_space(ascii_text)


def maybe_keep_local(original: str, ascii_text: str, country: str) -> str:
    if not original:
        return ""
    if country != "United Kingdom":
        return normalize_space(original)
    if normalize_space(original) != ascii_text:
        return normalize_space(original)
    return ""


def request_text(url: str, headers: Dict[str, str], timeout: int) -> str:
    response = requests.get(url, headers=headers, timeout=timeout, verify=False)
    response.raise_for_status()
    return response.text


def request_json(url: str, headers: Dict[str, str], timeout: int) -> Dict:
    response = requests.get(url, headers=headers, timeout=timeout, verify=False)
    response.raise_for_status()
    if not response.text.strip():
        return {}
    return response.json()


def extract_uk_postcode(text: str) -> str:
    text = normalize_space(text.upper())
    match = UK_POSTCODE_RE.search(text)
    if match:
        return normalize_space(match.group(1))
    match = UK_POSTCODE_O_RE.search(text)
    if match:
        return normalize_space(f"{match.group(1)}0{match.group(2)}")
    return ""


def remove_postcode_from_line(line: str, postcode: str) -> str:
    if not postcode:
        return normalize_space(line)
    candidate = re.sub(re.escape(postcode), "", line, flags=re.IGNORECASE)
    candidate = re.sub(re.escape(postcode.replace("0", "O")), "", candidate, flags=re.IGNORECASE)
    return clean_address(candidate)


def get_live_hotel_list() -> List[Dict]:
    url = f"{BASE_API_URL}{HOTELS_LIST_ENDPOINT}"
    data = request_json(url, HEADERS_API, timeout=30)
    save_json(data, LIVE_HOTELS_PATH)
    return data.get("hotels", [])


def load_existing_hotel_records() -> Dict[str, Dict]:
    data = load_json(HOTEL_PROGRESS_SOURCE, default={}) or {}
    records = data.get("records", [])
    by_code: Dict[str, Dict] = {}
    for record in records:
        code = normalize_space(record.get("_code", "")).upper()
        if code:
            by_code[code] = record
    return by_code


def hotel_record_from_detail(detail: Dict, code: str, brand_code: str) -> Optional[Dict]:
    if not detail:
        return None

    address = detail.get("address", {}) or {}
    location = detail.get("location", {}) or {}
    map_info = detail.get("map", {}) or {}
    contact = detail.get("contactDetails", {}) or {}

    original_lines = [
        normalize_space(address.get("addressline1")),
        normalize_space(address.get("addressline2")),
        normalize_space(address.get("addressline3")),
    ]
    original_lines = [line for line in original_lines if line]
    original_address = clean_address(", ".join(original_lines))
    if not original_address:
        return None

    country = COUNTRY_MAP.get(normalize_space(location.get("country")).lower(), "United Kingdom")
    name = normalize_space(detail.get("name") or detail.get("title") or code)
    brand = HOTEL_BRAND_PREFIX.get(brand_code, brand_code or "Hotel")
    original_facility_name = f"{brand} {name}".strip()

    ascii_name = transliterate_ascii(original_facility_name)
    ascii_address = transliterate_ascii(original_address)
    ascii_city = transliterate_ascii(location.get("town"))
    ascii_state = transliterate_ascii(location.get("county"))

    restaurant = detail.get("restaurant", {}) or {}
    restaurant_label = normalize_space(restaurant.get("name") or restaurant.get("brand"))
    activity = f"Hotel with {restaurant_label} Restaurant" if restaurant_label else "Hotel"

    lat = str(map_info.get("latitude", "")).strip() if map_info.get("latitude") is not None else ""
    lng = str(map_info.get("longitude", "")).strip() if map_info.get("longitude") is not None else ""

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "FACILITY_NAME": ascii_name,
        "FACILITY_ADDRESS": ascii_address,
        "CITY": ascii_city,
        "STATE": ascii_state,
        "POSTAL_CODE": normalize_space(address.get("postcode")),
        "FACILITY_REGION": country,
        "LATITUDE": lat,
        "LONGITUDE": lng,
        "FACILITY_CONTACT_NUMBER": clean_phone(contact.get("phone") or contact.get("hotelNationalPhone")),
        "RELEVANT_URL": HOTEL_PUBLIC_URL_TEMPLATE.format(code_lower=code.lower()),
        "ACTIVITY_AT_SOURCE": activity,
        "coord_source": "Website" if lat and lng else "",
        "FACILITY_NAME_LOCAL": maybe_keep_local(original_facility_name, ascii_name, country),
        "FACILITY_ADDRESS_LOCAL": maybe_keep_local(original_address, ascii_address, country),
        "_source": "Premier Inn REST API",
        "_code": code,
    }


def refresh_hotels(live_hotels: List[Dict], existing_records: Dict[str, Dict]) -> List[Dict]:
    live_brand_by_code = {normalize_space(item.get("code")).upper(): item.get("brand", "") for item in live_hotels}

    germany_codes = {
        normalize_space(record.get("_code", "")).upper()
        for record in existing_records.values()
        if normalize_space(record.get("FACILITY_REGION")) == "Germany"
    }
    missing_codes = [code for code in live_brand_by_code if code not in existing_records]
    refresh_codes = sorted(set(missing_codes) | germany_codes)

    progress = load_json(HOTEL_REPAIR_PROGRESS_PATH, default={}) or {}
    repaired = progress.get("records", {})
    done_codes = set(progress.get("done_codes", []))
    empty_codes = set(progress.get("empty_codes", []))

    for index, code in enumerate(refresh_codes, start=1):
        if code in done_codes:
            continue
        detail_url = f"{BASE_API_URL}{HOTEL_DETAIL_ENDPOINT.format(code=code)}"
        try:
            detail = request_json(detail_url, HEADERS_API, timeout=25)
            record = hotel_record_from_detail(detail, code, live_brand_by_code.get(code, ""))
            if record:
                repaired[code] = record
            else:
                empty_codes.add(code)
        except Exception:
            empty_codes.add(code)
        done_codes.add(code)

        if index % PROGRESS_SAVE_EVERY == 0:
            save_json(
                {
                    "done_codes": sorted(done_codes),
                    "empty_codes": sorted(empty_codes),
                    "records": repaired,
                },
                HOTEL_REPAIR_PROGRESS_PATH,
            )
        time.sleep(REQUEST_DELAY)

    save_json(
        {
            "done_codes": sorted(done_codes),
            "empty_codes": sorted(empty_codes),
            "records": repaired,
        },
        HOTEL_REPAIR_PROGRESS_PATH,
    )

    merged = dict(existing_records)
    for code, record in repaired.items():
        merged[code] = record

    # Drop confirmed empty-body / no-address codes only after live recheck.
    for code in empty_codes:
        if code in merged and not clean_address(merged[code].get("FACILITY_ADDRESS", "")):
            merged.pop(code, None)

    final_records = []
    for code in sorted(live_brand_by_code):
        record = merged.get(code)
        if record and clean_address(record.get("FACILITY_ADDRESS", "")):
            final_records.append(record)
    return final_records


def get_brand_location_urls(brand_name: str, sitemap_url: str) -> List[str]:
    text = request_text(sitemap_url, HEADERS_HTML, timeout=20)
    urls = re.findall(r"<loc>(.*?)</loc>", text)
    unique_urls = []
    seen = set()
    for url in urls:
        if "/locations/" not in url:
            continue
        tail = url.rstrip("/").split("/")[-1].lower()
        if tail in EXCLUDED_LOCATION_SLUGS:
            continue
        if url not in seen:
            seen.add(url)
            unique_urls.append(url)
    return unique_urls


def extract_location_path_parts(url: str) -> List[str]:
    parts = [part for part in urlparse(url).path.split("/") if part]
    if "locations" not in parts:
        return []
    idx = parts.index("locations")
    return parts[idx + 1 :]


def parse_restaurant_address(lines: List[str], url: str) -> Tuple[str, str, str]:
    lines = [normalize_space(line) for line in lines if normalize_space(line)]
    if not lines:
        return "", "", ""

    full_text = ", ".join(lines)
    postcode = extract_uk_postcode(full_text)
    body_lines = [remove_postcode_from_line(line, postcode) for line in lines]
    body_lines = [line for line in body_lines if line]

    location_parts = extract_location_path_parts(url)
    state = slug_to_title(location_parts[0]) if len(location_parts) >= 2 else ""

    city = body_lines[-1] if body_lines else ""
    if state and city and transliterate_ascii(city).lower() == transliterate_ascii(state).lower() and len(body_lines) >= 2:
        city = body_lines[-2]

    # If the county/state is already present as the final line, remove it from the geocoding-friendly address.
    if state and body_lines and transliterate_ascii(body_lines[-1]).lower() == transliterate_ascii(state).lower():
        address_lines = body_lines[:-1]
    else:
        address_lines = body_lines

    if not address_lines:
        address_lines = body_lines

    facility_address = clean_address(", ".join(address_lines + ([postcode] if postcode else [])))
    return facility_address, transliterate_ascii(city), transliterate_ascii(state)


def parse_restaurant_location_page(url: str, brand_name: str) -> Optional[Dict]:
    try:
        html = request_text(url, HEADERS_HTML, timeout=LOCATION_PAGE_TIMEOUT)
    except Exception:
        return None

    soup = BeautifulSoup(html, "html.parser")

    header = soup.find("header", class_=re.compile(r"cmp-header"))
    name = ""
    if header:
        name = normalize_space(header.get("data-lname") or header.get("data-ldname"))
    if not name:
        title = soup.find("title")
        if title:
            name = normalize_space(title.get_text()).split("|")[0].strip()
            name = re.sub(rf"^{re.escape(brand_name)}\s*", "", name, flags=re.IGNORECASE).strip(" -")

    loc_details = soup.find(class_=re.compile(r"cmp-locationdetails"))
    address_lines: List[str] = []
    if loc_details:
        addr_tag = loc_details.find("address")
        if addr_tag:
            address_lines = [normalize_space(text) for text in addr_tag.stripped_strings if normalize_space(text)]

    if not address_lines:
        return None

    facility_address, city, state = parse_restaurant_address(address_lines, url)
    if not facility_address:
        return None

    postcode = extract_uk_postcode(facility_address)
    phone = ""
    tel_link = soup.find("a", href=re.compile(r"^tel:", re.IGNORECASE))
    if tel_link:
        phone = clean_phone(tel_link.get("href", "").replace("tel:", ""))

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "FACILITY_NAME": transliterate_ascii(f"{brand_name} - {name}" if name else brand_name),
        "FACILITY_ADDRESS": transliterate_ascii(facility_address),
        "CITY": city,
        "STATE": state,
        "POSTAL_CODE": postcode,
        "FACILITY_REGION": "United Kingdom",
        "LATITUDE": "",
        "LONGITUDE": "",
        "FACILITY_CONTACT_NUMBER": phone,
        "RELEVANT_URL": url,
        "ACTIVITY_AT_SOURCE": BRAND_ACTIVITY.get(brand_name, "Restaurant"),
        "coord_source": "",
        "FACILITY_NAME_LOCAL": "",
        "FACILITY_ADDRESS_LOCAL": "",
        "_source": f"{brand_name} AEM Page",
        "_code": "",
    }


def extract_restaurants_live() -> List[Dict]:
    progress = load_json(RESTAURANT_REFRESH_PROGRESS_PATH, default={}) or {}
    done_urls = set(progress.get("done_urls", []))
    records = progress.get("records", [])

    for brand_name, sitemap_url in BRAND_SITEMAPS.items():
        urls = get_brand_location_urls(brand_name, sitemap_url)
        for index, url in enumerate(urls, start=1):
            if url in done_urls:
                continue
            record = parse_restaurant_location_page(url, brand_name)
            if record:
                records.append(record)
            done_urls.add(url)

            if len(done_urls) % PROGRESS_SAVE_EVERY == 0:
                save_json({"done_urls": sorted(done_urls), "records": records}, RESTAURANT_REFRESH_PROGRESS_PATH)
            time.sleep(REQUEST_DELAY)

    save_json({"done_urls": sorted(done_urls), "records": records}, RESTAURANT_REFRESH_PROGRESS_PATH)
    return records


def dedupe_records(records: Iterable[Dict]) -> List[Dict]:
    seen = set()
    deduped = []
    for record in records:
        key = (
            normalize_space(record.get("FACILITY_NAME")).lower(),
            normalize_space(record.get("FACILITY_ADDRESS")).lower(),
        )
        if not key[0] or not key[1] or key in seen:
            continue
        seen.add(key)
        deduped.append(record)
    return deduped


def export_records(hotel_records: List[Dict], restaurant_records: List[Dict]) -> Tuple[pd.DataFrame, Dict]:
    checkpoint_df = pd.DataFrame(dedupe_records(hotel_records))
    checkpoint_df.to_csv(HOTEL_CHECKPOINT_PATH, index=False, encoding="utf-8-sig")

    combined = dedupe_records(hotel_records + restaurant_records)
    df = pd.DataFrame(combined)

    ordered_cols = [
        "ISSUER_ID",
        "ISSUER_NAME",
        "FACILITY_NAME",
        "FACILITY_ADDRESS",
        "CITY",
        "STATE",
        "POSTAL_CODE",
        "FACILITY_REGION",
        "LATITUDE",
        "LONGITUDE",
        "FACILITY_CONTACT_NUMBER",
        "RELEVANT_URL",
        "ACTIVITY_AT_SOURCE",
        "coord_source",
        "FACILITY_NAME_LOCAL",
        "FACILITY_ADDRESS_LOCAL",
    ]

    for column in ordered_cols + ["_source", "_code"]:
        if column not in df.columns:
            df[column] = ""

    df = df[df["FACILITY_ADDRESS"].fillna("").astype(str).str.strip() != ""].copy()
    df = df[ordered_cols + ["_source", "_code"]]

    df.to_csv(AUDIT_OUTPUT_PATH, index=False, encoding="utf-8-sig")

    final_path = FINAL_OUTPUT_DIR / FINAL_OUTPUT_NAME
    df[ordered_cols].to_csv(final_path, index=False, encoding="utf-8-sig")

    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "checkpoint_hotel_rows": int(len(checkpoint_df)),
        "final_rows": int(len(df)),
        "by_source": df["_source"].value_counts().to_dict(),
        "blank_addresses": int((df["FACILITY_ADDRESS"].fillna("").astype(str).str.strip() == "").sum()),
        "duplicate_name_address": int(df.duplicated(subset=["FACILITY_NAME", "FACILITY_ADDRESS"]).sum()),
        "with_coordinates": int(
            (
                df["LATITUDE"].fillna("").astype(str).str.strip().ne("")
                & df["LONGITUDE"].fillna("").astype(str).str.strip().ne("")
            ).sum()
        ),
        "coord_source_values": df["coord_source"].fillna("").value_counts().to_dict(),
        "output_csv": str(final_path),
        "audit_csv": str(AUDIT_OUTPUT_PATH),
    }
    save_json(summary, SUMMARY_PATH)
    return df, summary


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    FINAL_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    live_hotels = get_live_hotel_list()
    existing_hotels = load_existing_hotel_records()
    hotel_records = refresh_hotels(live_hotels, existing_hotels)
    restaurant_records = extract_restaurants_live()
    _, summary = export_records(hotel_records, restaurant_records)

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
