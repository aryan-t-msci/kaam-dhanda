"""
Migros corporate StoreLocation API extractor.

Pattern handled:
- Official company website store-location API exposed by migroskurumsal.com.

What this script does:
- Pulls the public map feed from GetLocations.
- Pulls the per-city/per-brand detail feed from GetStoresWithDetails.
- Merges both feeds using website coordinates plus normalized name/address.
- Infers province-level city values from the official city/county lookup.
- Writes staging CSV, rejected CSV, QA summary JSON, and progress checkpoints.

Usage:
    python migros_worker_extract.py
"""

from __future__ import annotations

import csv
import json
import math
import io
import re
import time
import unicodedata
from collections import Counter
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import requests
from bs4 import BeautifulSoup
from pypdf import PdfReader


# ═══════════════════════════════════════════════════════════════════════════
# CONFIGURATION - Edit this block for each new issuer
# ═══════════════════════════════════════════════════════════════════════════
ISSUER_ID = "IID000000002175656"
ISSUER_NAME = "MIGROS TICARET ANONIM SIRKETI"
BASE_URL = "https://www.migroskurumsal.com"
STORE_PAGE_URL = "https://www.migroskurumsal.com/en/our-stores"
API_BASE = "https://api.migroskurumsal.com/api/StoreLocation"
CONTACT_URLS = [
    "https://www.migroskurumsal.com/en/contact-us",
    "https://www.migros.com.tr/iletisim",
]
BRAND_IDS = [1, 2, 5, 8, 10, 12, 13, 14]
BRAND_ACTIVITY = {
    "1": "Premium supermarket retail store",
    "2": "Supermarket retail store",
    "5": "Hypermarket retail store",
    "8": "Convenience retail store",
    "10": "Retail kiosk store",
    "12": "Cosmetics retail store",
    "13": "Wholesale retail store",
    "14": "Pet retail store",
}
BRAND_NAME = {
    "1": "Macrocenter",
    "2": "Migros",
    "5": "5M",
    "8": "Mjet",
    "10": "Macrokiosk",
    "12": "Mion",
    "13": "Wholesale",
    "14": "Petimo",
}
WORK_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Run_asset_completeness_ondemand_batch7_8___straive_copy\IID000000002175656_MIGROS TICARET ANONIM SIRKETI"
)
STAGING_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Run_asset_completeness_ondemand_batch7_8___straive_copy\staging"
)
REJECT_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Run_asset_completeness_ondemand_batch7_8___straive_copy\reject"
)


# ═══════════════════════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC - Do not modify per-issuer
# ═══════════════════════════════════════════════════════════════════════════
OUTPUT_NAME = f"{ISSUER_ID}_{ISSUER_NAME}.csv"
REJECT_NAME = f"{ISSUER_ID}_{ISSUER_NAME}_rejected.csv"
PROGRESS_FILE = WORK_DIR / "progress.json"
DETAIL_PROGRESS_FILE = WORK_DIR / "detail_progress.jsonl"
QA_FILE = WORK_DIR / "qa_summary.json"
DEBUG_FILE = WORK_DIR / "extract_debug.json"

STANDARD_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
    "VALIDATION_URL",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS_NATIVE",
]

TURKISH_MAP = str.maketrans(
    {
        "ı": "i",
        "İ": "I",
        "ş": "s",
        "Ş": "S",
        "ğ": "g",
        "Ğ": "G",
        "ü": "u",
        "Ü": "U",
        "ö": "o",
        "Ö": "O",
        "ç": "c",
        "Ç": "C",
    }
)

POSTCODE_RE = re.compile(r"\b\d{5}\b")


def ensure_dirs() -> None:
    WORK_DIR.mkdir(parents=True, exist_ok=True)
    STAGING_DIR.mkdir(parents=True, exist_ok=True)
    REJECT_DIR.mkdir(parents=True, exist_ok=True)


def ascii_text(value: str) -> str:
    value = (value or "").translate(TURKISH_MAP)
    value = unicodedata.normalize("NFKD", value)
    value = value.encode("ascii", "ignore").decode("ascii")
    value = re.sub(r"\s+", " ", value).strip()
    return value


def clean_space(value: str) -> str:
    return re.sub(r"\s+", " ", (value or "").strip())


def normalize_key(value: str) -> str:
    value = ascii_text(value).upper()
    value = re.sub(r"[^A-Z0-9]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def coord_key(lat: object, lng: object) -> Optional[Tuple[float, float]]:
    try:
        # 5dp keeps website-published points stable while collapsing tiny feed-to-feed jitter.
        return (round(float(lat), 5), round(float(lng), 5))
    except (TypeError, ValueError):
        return None


def write_progress(progress: dict) -> None:
    PROGRESS_FILE.write_text(json.dumps(progress, indent=2), encoding="utf-8")


def append_detail_progress(entry: dict) -> None:
    with DETAIL_PROGRESS_FILE.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, ensure_ascii=False) + "\n")


def make_session() -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": "Mozilla/5.0",
            "Origin": BASE_URL,
            "Referer": STORE_PAGE_URL,
            "Content-Type": "application/json",
            "APIKEY": "",
        }
    )
    return session


def post_json(
    session: requests.Session,
    url: str,
    *,
    tries: int = 8,
    sleep_seconds: float = 1.0,
) -> dict:
    last_error = None
    for attempt in range(1, tries + 1):
        try:
            response = session.post(url, timeout=30)
            if response.status_code == 429:
                last_error = RuntimeError("429 rate limited")
                time.sleep(15 * attempt)
                continue
            response.raise_for_status()
            return response.json()
        except Exception as exc:  # noqa: BLE001
            last_error = exc
            time.sleep(sleep_seconds * attempt)
    raise RuntimeError(f"POST failed for {url}: {last_error}") from last_error


def get_text(session: requests.Session, url: str) -> str:
    response = session.get(url, timeout=30)
    response.raise_for_status()
    return response.text


def build_geo_lookup(city_payload: List[dict]) -> Tuple[Dict[str, str], Dict[str, str], Dict[str, str]]:
    county_to_city_native: Dict[str, str] = {}
    county_to_city_ascii: Dict[str, str] = {}
    city_ascii_to_native: Dict[str, str] = {}
    for city in city_payload:
        city_native = clean_space(city["text"])
        city_ascii = normalize_key(city_native)
        city_ascii_to_native[city_ascii] = city_native
        for county in city.get("children") or []:
            county_native = clean_space(county["text"])
            county_ascii = normalize_key(county_native)
            county_to_city_native[county_native] = city_native
            county_to_city_ascii[county_ascii] = city_native
    return county_to_city_native, county_to_city_ascii, city_ascii_to_native


def infer_city_and_state(
    name_native: str,
    address_native: str,
    county_to_city_ascii: Dict[str, str],
    city_ascii_to_native: Dict[str, str],
) -> Tuple[Optional[str], Optional[str], str]:
    name_key = normalize_key(name_native)
    address_key = normalize_key(address_native)
    name_tokens = name_key.split()
    address_tokens = address_key.split()
    bad_after = {"MAH", "MH", "MAHALLESI", "BULVARI", "BULV", "CAD", "CADDE", "SOK", "SOKAK", "PO"}

    for idx, token in enumerate(name_tokens):
        if token in city_ascii_to_native:
            next_token = name_tokens[idx + 1] if idx + 1 < len(name_tokens) else ""
            if next_token not in bad_after:
                return city_ascii_to_native[token], "", "fixed"
        for city_ascii, city_native in sorted(
            city_ascii_to_native.items(),
            key=lambda item: len(item[0]),
            reverse=True,
        ):
            if token.endswith(city_ascii) and len(token) > len(city_ascii) + 2:
                return city_native, "", "fixed"

    for city_ascii, city_native in sorted(
        city_ascii_to_native.items(),
        key=lambda item: len(item[0]),
        reverse=True,
    ):
        if not city_ascii:
            continue
        if address_tokens and address_tokens[-1] == city_ascii:
            return city_native, "", "fixed"

    county_hits = []
    for county_ascii, city_native in county_to_city_ascii.items():
        if len(county_ascii) < 6:
            continue
        if county_ascii in name_key:
            county_hits.append((county_ascii, city_native))

    if not county_hits:
        for county_ascii, city_native in county_to_city_ascii.items():
            if len(county_ascii) < 8:
                continue
            if county_ascii in address_key:
                county_hits.append((county_ascii, city_native))

    if county_hits:
        county_hits.sort(key=lambda item: len(item[0]), reverse=True)
        matched_cities = {city_native for _, city_native in county_hits}
        if len(matched_cities) == 1:
            return next(iter(matched_cities)), "", "CITY"

    return None, None, "CITY"


def activity_for_brand(brand_id: str, brand_label: str, name_native: str) -> str:
    if brand_id in BRAND_ACTIVITY:
        return BRAND_ACTIVITY[brand_id]
    name_key = normalize_key(f"{brand_label} {name_native}")
    if "MION" in name_key:
        return BRAND_ACTIVITY["12"]
    if "PETIMO" in name_key:
        return BRAND_ACTIVITY["14"]
    if "TOPTAN" in name_key or "WHOLESALE" in name_key:
        return BRAND_ACTIVITY["13"]
    if "MACROKIOSK" in name_key:
        return BRAND_ACTIVITY["10"]
    if "MACRO" in name_key:
        return BRAND_ACTIVITY["1"]
    if "MJET" in name_key:
        return BRAND_ACTIVITY["8"]
    if "5M" in name_key:
        return BRAND_ACTIVITY["5"]
    return BRAND_ACTIVITY["2"]


def country_block(country: str, iso3: str) -> Tuple[str, str]:
    return country, iso3


def build_row(
    *,
    name_native: str,
    address_native: str,
    latitude: object,
    longitude: object,
    city: str,
    state: str,
    source_url: str,
    activity: str,
    qa_flag: str,
    country: str = "Turkey",
    iso3: str = "TUR",
    source_type: str = "COMPANY WEBSITE",
) -> dict:
    postcode_match = POSTCODE_RE.search(address_native or "")
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": ascii_text(name_native),
        "LOCATION_ADDRESS": ascii_text(address_native),
        "LATITUDE": f"{float(latitude):.6f}" if latitude not in ("", None) else "",
        "LONGITUDE": f"{float(longitude):.6f}" if longitude not in ("", None) else "",
        "COUNTRY": country,
        "COUNTRY_ISO3": iso3,
        "POSTCODE": postcode_match.group(0) if postcode_match else "",
        "STATE": ascii_text(state),
        "CITY": ascii_text(city),
        "SOURCE_URL": source_url,
        "SOURCE_TYPE": source_type,
        "ACTIVITY_AT_ASSET": activity,
        "coord_source": "website",
        "QA_flag": qa_flag,
        "VALIDATION_URL": "",
        "LOCATION_NAME_NATIVE": clean_space(name_native),
        "LOCATION_ADDRESS_NATIVE": clean_space(address_native),
    }


def extract_contact_rows(session: requests.Session) -> List[dict]:
    rows: List[dict] = []
    seen: set[Tuple[str, str]] = set()
    try:
        html = get_text(session, "https://www.migroskurumsal.com/en/contact-us")
        soup = BeautifulSoup(html, "html.parser")
        text = clean_space(soup.get_text(" ", strip=True))
        patterns = [
            (
                "Migros Ticaret Head Office 1",
                r"Head Office 1 Address (Atatürk Mah\..*?34758 Ataşehir / İstanbul)",
            ),
            (
                "Migros Ticaret Head Office 2",
                r"Head Office 2 Adress: (Barbaros Mah\..*?Ataşehir/İstanbul)",
            ),
        ]
        for name_native, pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if not match:
                continue
            address_native = clean_space(match.group(1))
            key = (normalize_key(name_native), normalize_key(address_native))
            if key in seen:
                continue
            seen.add(key)
            rows.append(
                build_row(
                    name_native=name_native,
                    address_native=address_native,
                    latitude="",
                    longitude="",
                    city="İstanbul",
                    state="",
                    source_url="https://www.migroskurumsal.com/en/contact-us",
                    activity="Corporate headquarters",
                    qa_flag="fixed",
                )
            )
    except Exception:
        pass

    try:
        html = get_text(session, "https://ramstore.com.mk/kontakt/?lang=en")
        soup = BeautifulSoup(html, "html.parser")
        text = clean_space(soup.get_text(" ", strip=True))
        match = re.search(
            r"Address:\s*SS Cyril and Methodius Street, No\. 13 \(contact address (str\.[^)]+, Skopje)\)",
            text,
            re.IGNORECASE,
        )
        if match:
            name_native = "Ramstore Contact Office"
            address_native = clean_space(match.group(1))
            key = (normalize_key(name_native), normalize_key(address_native))
            if key not in seen:
                seen.add(key)
                rows.append(
                    build_row(
                        name_native=name_native,
                        address_native=address_native,
                        latitude="",
                        longitude="",
                        city="Skopje",
                        state="",
                        source_url="https://ramstore.com.mk/kontakt/?lang=en",
                        activity="Retail subsidiary corporate office",
                        qa_flag="fixed",
                        country="North Macedonia",
                        iso3="MKD",
                    )
                )
    except Exception:
        pass

    try:
        pdf_url = "https://moneypay.com.tr/pdf/moneypay-faaliyet-raporu-2021.pdf"
        content = session.get(pdf_url, timeout=30).content
        text = "\n".join(
            (PdfReader(io.BytesIO(content)).pages[i].extract_text() or "")
            for i in range(min(8, len(PdfReader(io.BytesIO(content)).pages)))
        )
        match = re.search(
            r"Merkez adresi\s+(Atatürk Mh\.\s*Turgut Özal Blv\.\s*N\.7\s*34758\s*Ataşehir\s*İstanbul)",
            text,
            re.IGNORECASE,
        )
        if match:
            name_native = "MoneyPay Headquarters"
            address_native = clean_space(match.group(1))
            key = (normalize_key(name_native), normalize_key(address_native))
            if key not in seen:
                seen.add(key)
                rows.append(
                    build_row(
                        name_native=name_native,
                        address_native=address_native,
                        latitude="",
                        longitude="",
                        city="İstanbul",
                        state="",
                        source_url=pdf_url,
                        activity="Digital payments corporate office",
                        qa_flag="fixed",
                        source_type="COMPANY REPORT",
                    )
                )
    except Exception:
        pass
    return rows


def validate_row(row: dict) -> Tuple[bool, Optional[str]]:
    mandatory = [
        "LOCATION_NAME",
        "LOCATION_ADDRESS",
        "COUNTRY",
        "COUNTRY_ISO3",
        "CITY",
        "ACTIVITY_AT_ASSET",
        "SOURCE_URL",
        "SOURCE_TYPE",
        "coord_source",
    ]
    for column in mandatory:
        if not clean_space(str(row.get(column, ""))):
            return False, f"missing_{column.lower()}"
    if row["coord_source"] not in {"website", "Not from website"}:
        return False, "invalid_coord_source"
    return True, None


def qa_rank(value: str) -> int:
    if value == "":
        return 0
    if value == "fixed":
        return 1
    return 2


def row_score(row: dict) -> Tuple[int, int, int]:
    source_rank = 0 if "GetStoresWithDetails" in row["SOURCE_URL"] else 1
    return (
        qa_rank(row["QA_flag"]),
        source_rank,
        -len(row["LOCATION_ADDRESS"]),
    )


def rows_are_same_store(left: dict, right: dict) -> bool:
    if left["LOCATION_NAME"] != right["LOCATION_NAME"] or left["CITY"] != right["CITY"]:
        return False

    if left["LOCATION_ADDRESS"] == right["LOCATION_ADDRESS"]:
        return True

    left_addr = normalize_key(left["LOCATION_ADDRESS"])
    right_addr = normalize_key(right["LOCATION_ADDRESS"])
    if left_addr and right_addr and (left_addr in right_addr or right_addr in left_addr):
        return True

    try:
        left_lat = float(left["LATITUDE"])
        left_lng = float(left["LONGITUDE"])
        right_lat = float(right["LATITUDE"])
        right_lng = float(right["LONGITUDE"])
    except (TypeError, ValueError):
        return False

    return abs(left_lat - right_lat) <= 0.0002 and abs(left_lng - right_lng) <= 0.0002


def dedupe_final_rows(rows: List[dict]) -> List[dict]:
    # If the exact location name exists both as a clean detail row and as a flagged
    # map-only inference, keep the clean detail row and drop the weaker duplicate.
    by_name: Dict[str, List[dict]] = {}
    for row in rows:
        by_name.setdefault(row["LOCATION_NAME"], []).append(row)

    prefiltered: List[dict] = []
    for _, bucket in by_name.items():
        clean_bucket = [row for row in bucket if row["QA_flag"] == ""]
        if clean_bucket:
            prefiltered.extend(clean_bucket)
        else:
            prefiltered.extend(bucket)

    grouped: Dict[Tuple[str, str], List[dict]] = {}
    for row in prefiltered:
        grouped.setdefault((row["LOCATION_NAME"], row["CITY"]), []).append(row)

    deduped: List[dict] = []
    for _, bucket in grouped.items():
        merged: List[dict] = []
        for row in bucket:
            placed = False
            for idx, existing in enumerate(merged):
                if rows_are_same_store(existing, row):
                    merged[idx] = min([existing, row], key=row_score)
                    placed = True
                    break
            if not placed:
                merged.append(row)
        deduped.extend(merged)
    return deduped


def write_csv(path: Path, rows: Iterable[dict], *, extra_columns: Optional[List[str]] = None) -> None:
    fieldnames = STANDARD_COLUMNS.copy()
    if extra_columns:
        fieldnames.extend(extra_columns)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def main() -> None:
    ensure_dirs()
    started = time.time()
    session = make_session()

    city_payload = post_json(session, f"{API_BASE}/GetCityAndCounties")["data"]
    county_to_city_native, county_to_city_ascii, city_ascii_to_native = build_geo_lookup(city_payload)

    detail_rows = []
    completed_calls = 0
    for brand_id in BRAND_IDS:
        for city in city_payload:
            city_id = str(city["value"])
            city_name = city["text"]
            url = f"{API_BASE}/GetStoresWithDetails?cityId={city_id}&countyId=0&brandId={brand_id}"
            try:
                payload = post_json(session, url)
            except RuntimeError:
                time.sleep(60)
                payload = post_json(session, url)
            rows = payload.get("data") or []
            detail_rows.extend(rows)
            completed_calls += 1
            time.sleep(0.25)
            if completed_calls % 20 == 0:
                write_progress(
                    {
                        "phase": "detail_fetch",
                        "completed_calls": completed_calls,
                        "detail_rows": len(detail_rows),
                        "last_city": city_name,
                        "last_brand_id": brand_id,
                    }
                )
                append_detail_progress(
                    {
                        "completed_calls": completed_calls,
                        "detail_rows": len(detail_rows),
                        "city_id": city_id,
                        "city_name": city_name,
                        "brand_id": brand_id,
                        "rows_returned": len(rows),
                    }
                )

    map_payload = post_json(session, f"{API_BASE}/GetLocations")["data"]
    write_progress(
        {
            "phase": "merge",
            "completed_calls": completed_calls,
            "detail_rows": len(detail_rows),
            "map_rows": len(map_payload),
        }
    )

    merged_by_coord: Dict[Tuple[float, float], dict] = {}
    merged_by_name_addr: Dict[Tuple[str, str], dict] = {}

    for item in detail_rows:
        name_native = clean_space(item.get("name", ""))
        address_native = clean_space(item.get("address", ""))
        if not name_native or not address_native:
            continue
        brand_id = str(item.get("brandId", "") or "")
        brand_label = clean_space(item.get("brand", "")) or BRAND_NAME.get(brand_id, "")
        source_url = (
            f"{API_BASE}/GetStoresWithDetails?cityId={item.get('cityId')}"
            f"&countyId=0&brandId={brand_id}"
        )
        row = build_row(
            name_native=name_native,
            address_native=address_native,
            latitude=item.get("lat"),
            longitude=item.get("lng"),
            city=clean_space(item.get("city", "")),
            state="",
            source_url=source_url,
            activity=activity_for_brand(brand_id, brand_label, name_native),
            qa_flag="",
        )
        key_coord = coord_key(item.get("lat"), item.get("lng"))
        key_name_addr = (normalize_key(name_native), normalize_key(address_native))
        if key_coord:
            merged_by_coord[key_coord] = row
        merged_by_name_addr[key_name_addr] = row

    map_only_added = 0
    for item in map_payload:
        name_native = clean_space(item.get("name", ""))
        address_native = clean_space(item.get("address", ""))
        if not name_native or not address_native:
            continue
        key_coord = coord_key(item.get("lat"), item.get("lng"))
        key_name_addr = (normalize_key(name_native), normalize_key(address_native))
        if key_coord and key_coord in merged_by_coord:
            continue
        if key_name_addr in merged_by_name_addr:
            continue

        city, state, qa_flag = infer_city_and_state(
            name_native,
            address_native,
            county_to_city_ascii,
            city_ascii_to_native,
        )
        if not city:
            continue

        brand_code = clean_space(item.get("brandCode", "")).lower()
        brand_id = ""
        if brand_code == "macro":
            brand_id = "1"
        elif brand_code == "migros":
            brand_id = "2"
        elif brand_code == "5m":
            brand_id = "5"
        elif brand_code == "mjet":
            brand_id = "8"
        elif brand_code == "macrokiosk":
            brand_id = "10"
        brand_label = clean_space(item.get("brand", "")) or BRAND_NAME.get(brand_id, "")

        row = build_row(
            name_native=name_native,
            address_native=address_native,
            latitude=item.get("lat"),
            longitude=item.get("lng"),
            city=city,
            state=state or "",
            source_url=f"{API_BASE}/GetLocations",
            activity=activity_for_brand(brand_id, brand_label, name_native),
            qa_flag=qa_flag,
        )
        if key_coord:
            merged_by_coord[key_coord] = row
        merged_by_name_addr[key_name_addr] = row
        map_only_added += 1

    contact_rows = extract_contact_rows(session)
    for row in contact_rows:
        key_name_addr = (normalize_key(row["LOCATION_NAME_NATIVE"]), normalize_key(row["LOCATION_ADDRESS_NATIVE"]))
        if key_name_addr not in merged_by_name_addr:
            merged_by_name_addr[key_name_addr] = row

    final_rows = dedupe_final_rows(list(merged_by_name_addr.values()))
    final_rows.sort(key=lambda row: (row["COUNTRY"], row["CITY"], row["LOCATION_NAME"]))

    validated_rows: List[dict] = []
    rejected_rows: List[dict] = []
    qa_counts = Counter()

    for row in final_rows:
        ok, reason = validate_row(row)
        if ok:
            qa_counts["validated"] += 1
            if row["QA_flag"] == "":
                qa_counts["clean"] += 1
            elif row["QA_flag"] == "fixed":
                qa_counts["tier_a_fixed"] += 1
            else:
                qa_counts["tier_b_flagged"] += 1
            validated_rows.append(row)
        else:
            rejected = dict(row)
            rejected["rejection_reason"] = reason or "validation_failed"
            rejected["rejected_by"] = "worker_qa"
            rejected_rows.append(rejected)
            qa_counts["tier_c_rejected"] += 1

    write_csv(STAGING_DIR / OUTPUT_NAME, validated_rows)
    if rejected_rows:
        write_csv(
            REJECT_DIR / REJECT_NAME,
            rejected_rows,
            extra_columns=["rejection_reason", "rejected_by"],
        )

    inspect_count = max(1, math.ceil(len(validated_rows) * 0.10))
    qa_summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "rows_total": len(validated_rows),
        "rows_inspected": inspect_count,
        "method": "standard 10%",
        "clean": qa_counts["clean"],
        "tier_a_fixed": qa_counts["tier_a_fixed"],
        "tier_b_flagged": qa_counts["tier_b_flagged"],
        "tier_c_rejected": qa_counts["tier_c_rejected"],
        "detail_rows_raw": len(detail_rows),
        "map_rows_raw": len(map_payload),
        "map_only_added": map_only_added,
        "contact_rows_added": len(contact_rows),
        "duration_seconds": round(time.time() - started, 2),
    }
    QA_FILE.write_text(json.dumps(qa_summary, indent=2, ensure_ascii=False), encoding="utf-8")
    DEBUG_FILE.write_text(
        json.dumps(
            {
                "brand_counts_detail_raw": Counter(str(x.get("brandId", "")) for x in detail_rows),
                "brand_counts_map_raw": Counter(clean_space(x.get("brandCode", "")).lower() for x in map_payload),
                "qa_summary": qa_summary,
            },
            indent=2,
            ensure_ascii=False,
            default=lambda value: dict(value),
        ),
        encoding="utf-8",
    )

    print(json.dumps(qa_summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
