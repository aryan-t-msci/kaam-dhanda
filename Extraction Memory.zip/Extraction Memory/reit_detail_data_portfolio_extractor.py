"""
Generic extractor for REIT portfolio sites backed by:
- a public detail-data.json payload
- a public map.xml marker feed
- a static portfolio index table with published locality text

Configure the URLs and issuer constants in the block below, then run:
    python reit_detail_data_portfolio_extractor.py

The script writes a CSV with the standard batch schema and returns the
count plus a small reconciliation summary in stdout.
"""

from __future__ import annotations

import csv
import json
import re
from pathlib import Path
from typing import Dict, List, Tuple

import requests
from bs4 import BeautifulSoup


# ============================================================
# CONFIGURATION - Edit this block for each new issuer
# ============================================================
ISSUER_ID = "IID000000002655749"
ISSUER_NAME = "GLP J-REIT"
DETAIL_DATA_EN_URL = "https://www.glpjreit.com/en/portfolio/detail-data.json"
DETAIL_DATA_JA_URL = "https://www.glpjreit.com/ja/portfolio/detail-data.json"
MAP_XML_URL = "https://www.glpjreit.com/en/portfolio/map.xml"
PORTFOLIO_INDEX_URL = "https://www.glpjreit.com/en/portfolio/index.html"
SOURCE_URL = "https://www.glpjreit.com/en/portfolio/detail-data.json"
SOURCE_TYPE = "COMPANY WEBSITE"
COUNTRY = "Japan"
COUNTRY_ISO3 = "JPN"
OUTPUT_CSV = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Extraction_Batch_Chat5.4_odbatch9_10_output_for_straive_20260601_112949\staging\IID000000002655749_GLP J-REIT.csv"

# ============================================================
# GENERIC EXTRACTION LOGIC - Do not modify per issuer
# ============================================================
CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS",
    "LOCATION_ADDRESS_NATIVE",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
]


def build_session() -> requests.Session:
    session = requests.Session()
    session.headers.update({"User-Agent": "Mozilla/5.0 (compatible; Codex extractor)"})
    return session


def fetch_text(session: requests.Session, url: str) -> str:
    response = session.get(url, timeout=45)
    response.raise_for_status()
    response.encoding = "utf-8"
    return response.text


def fetch_json(session: requests.Session, url: str) -> dict:
    response = session.get(url, timeout=45)
    response.raise_for_status()
    return response.json()


def clean_spaces(value: str) -> str:
    return re.sub(r"\s+", " ", value.replace("\r", " ").replace("\n", " ")).strip()


def split_address_lines(value: str) -> List[str]:
    value = value.replace("\r\n", "\n").replace("\r", "\n").strip()
    parts = [line.strip() for line in value.split("\n") if line.strip()]
    return parts or [value]


def normalize_address(value: str) -> str:
    lines = [clean_spaces(line) for line in split_address_lines(value)]
    return "; ".join(lines)


def parse_locality(value: str) -> Tuple[str, str]:
    match = re.match(r"^(.*?),\s*([A-Za-z .'-]+)\s+[a-z]+", value)
    if match:
        return clean_spaces(match.group(1)), clean_spaces(match.group(2))
    parts = [clean_spaces(part) for part in value.split(",") if clean_spaces(part)]
    if len(parts) >= 2:
        return parts[0], parts[1]
    return clean_spaces(value), ""


def derive_activity(property_text: str) -> str:
    text = clean_spaces(property_text).lower()
    if "medical product distribution" in text:
        return "Medical product distribution hub"
    if "freezer and refrigerated logistics facility" in text:
        return "Freezer and refrigerated logistics facility"
    if "refrigerated" in text or "temperature" in text or "cold storage" in text:
        return "Temperature-controlled logistics facility"
    if "distribution hub" in text:
        return "Distribution hub"
    if "modern logistics facility" in text:
        return "Modern logistics facility"
    if "multi-tenant" in text:
        return "Multi-tenant logistics facility"
    return "Logistics facility"


def parse_index_localities(session: requests.Session) -> Dict[str, Dict[str, str]]:
    soup = BeautifulSoup(fetch_text(session, PORTFOLIO_INDEX_URL), "html.parser")
    tables = soup.find_all("table")
    if not tables:
        raise RuntimeError("Portfolio index table not found")
    mapping: Dict[str, Dict[str, str]] = {}
    for tr in tables[0].find_all("tr"):
        cells = [clean_spaces(cell.get_text(" ", strip=True)) for cell in tr.find_all(["th", "td"])]
        if not cells or not re.match(r"^\d", cells[0]):
            continue
        name = cells[1].strip()
        city, state = parse_locality(cells[2])
        mapping[name.rstrip()] = {"city": city, "state": state}
    return mapping


def parse_positions(session: requests.Session) -> Dict[str, Tuple[str, str]]:
    soup = BeautifulSoup(fetch_text(session, MAP_XML_URL), "xml")
    mapping: Dict[str, Tuple[str, str]] = {}
    for item in soup.find_all("item"):
        id_node = item.find("id")
        position_node = item.find("position")
        item_id = id_node.get_text(strip=True) if id_node else ""
        position = position_node.get_text(strip=True) if position_node else ""
        bits = [bit.strip() for bit in position.split(",")]
        if item_id and len(bits) >= 2 and bits[0] and bits[1]:
            mapping[item_id] = (bits[0], bits[1])
    return mapping


def build_rows() -> Tuple[List[dict], dict]:
    session = build_session()
    en_data = fetch_json(session, DETAIL_DATA_EN_URL)
    ja_data = fetch_json(session, DETAIL_DATA_JA_URL)
    localities = parse_index_localities(session)
    positions = parse_positions(session)
    rows: List[dict] = []
    dropped_keys: List[str] = []

    for key, en_entry in en_data.items():
        if not isinstance(en_entry, dict) or not en_entry.get("name") or not en_entry.get("address"):
            dropped_keys.append(key)
            continue
        ja_entry = ja_data.get(key, {})
        locality = localities.get(en_entry["name"].rstrip(), localities.get(en_entry["name"].strip(), {}))
        lat, lng = positions.get(key, ("", ""))
        rows.append(
            {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": clean_spaces(en_entry["name"]),
                "LOCATION_NAME_NATIVE": clean_spaces(ja_entry.get("name", "")),
                "LOCATION_ADDRESS": normalize_address(en_entry["address"]),
                "LOCATION_ADDRESS_NATIVE": normalize_address(ja_entry.get("address", "")),
                "LATITUDE": lat,
                "LONGITUDE": lng,
                "COUNTRY": COUNTRY,
                "COUNTRY_ISO3": COUNTRY_ISO3,
                "POSTCODE": "",
                "STATE": locality.get("state", ""),
                "CITY": locality.get("city", ""),
                "SOURCE_URL": SOURCE_URL,
                "SOURCE_TYPE": SOURCE_TYPE,
                "ACTIVITY_AT_ASSET": derive_activity(en_entry.get("property", "")),
                "coord_source": "website" if lat and lng else "Not from website",
                "QA_flag": "",
            }
        )

    rows.sort(key=lambda row: row["LOCATION_NAME"])
    summary = {
        "en_records_total": len(en_data),
        "asset_rows_written": len(rows),
        "dropped_keys": dropped_keys,
        "map_positions": len(positions),
        "table_localities": len(localities),
    }
    return rows, summary


def write_csv(rows: List[dict]) -> None:
    output_path = Path(OUTPUT_CSV)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    rows, summary = build_rows()
    write_csv(rows)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
