"""
Config-driven exporter for annual-report distribution center tables.

This script is intended for issuer extractions where:
1. The primary source is an annual report PDF that lists facilities in a compact
   table with grouped counts.
2. The report may mention additional facilities elsewhere in narrative text.
3. The task requires a checkpoint export once the threshold count is reached,
   followed by a second pass to append any extra facilities found in the same
   source.

How to adapt for a new issuer:
- Update the CONFIG block only.
- Keep the helper functions, validation, checkpoint export, and memory-draft
  generation unchanged.

Usage:
    python annual_report_distribution_center_exporter.py
"""

from __future__ import annotations

import csv
import json
import time
import unicodedata
from datetime import datetime
from pathlib import Path


# ============================================================================
# CONFIGURATION
# ============================================================================
ISSUER_ID = "IID000000002147475"
ISSUER_NAME = "Wal-Mart de Mexico, S.A.B. de C.V."
SOURCE_URL = "https://files.walmex.mx/upload/files/2024/EN/Annual/Walmex_Annual_Report_MSE_2024.pdf"
SOURCE_TYPE = "annual_report_pdf"
EXPECTED_MIN_COUNT = 32
CHECKPOINT_COUNT = 32
COORD_SOURCE_DEFAULT = "not_on_website"

TEMP_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp"
)
OUTPUT_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output"
)

SCRIPT_NAME = "annual_report_distribution_center_exporter.py"
CHECKPOINT_PATH = TEMP_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_checkpoint.csv"
WORKING_PATH = TEMP_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_working.csv"
FINAL_OUTPUT_PATH = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
SUMMARY_PATH = TEMP_DIR / f"{ISSUER_ID}_summary.json"
MEMORY_DRAFT_PATH = TEMP_DIR / f"{ISSUER_ID}_memory_append_draft.md"

EXPORT_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS",
    "LOCATION_ADDRESS_NATIVE",
    "LATITUDE",
    "LONGITUDE",
    "coord_source",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
]

# Primary and corroborating official-source URLs used while normalizing
# localities and understanding grouped-count rows.
SUPPORTING_URLS = [
    SOURCE_URL,
    "https://www.walmartmexico.com/proveedores/logistica",
    "https://www.walmartmexico.com/sala-de-prensa/2019/05/06/walmart-de-mexico-y-centroamerica-inauguro-un-nuevo-centro-de-distribucion-para-ecommerce-en-guadalajara",
    "https://www.walmartmexico.com/content/walmart-mexico/es_mx/sala-de-prensa/2019/07/10/inversion-de-mas-de-180-millones-de-pesos-en-nuevo-centro-de-distribucion-en-monterrey.html",
    "https://www.walmartmexico.com/sala-de-prensa/2020/09/24/walmart-de-mexico-y-centroamerica-inaugura-oficialmente-elprimer-cedis-omnicanal-a-nivel-nacional",
    "https://www.walmartmexico.com/sala-de-prensa/2020/09/17/walmart-de-mexico-y-centroamerica-expande-su-red-logistica-al-noroeste-del-pais",
    "https://www.walmartmexico.com/sala-de-prensa/2021/12/08/fortalece-walmart-de-mexico-y-centroamerica-su-red-logistica-omnicanal-en-la-region-noroeste-con-la-apertura-del-cedis-mexicali",
    "https://www.walmartmexico.com/sala-de-prensa/2022/08/23/celebra-walmart-de-mexico-y-centroamerica-la-inauguracion-de-su-centro-de-distribucion-numero-32-en-la-region-ubicado-en-villahermosa-tabasco",
    "https://www.walmartmexico.com/sala-de-prensa/2024/10/anuncia-walmart-de-mexico-y-centroamerica-la-construccion-de-su-",
]


def clean_text(value: str) -> str:
    if value is None:
        return ""
    text = str(value)
    replacements = {
        "#": " ",
        "–": "-",
        "—": "-",
        "’": "'",
        "“": '"',
        "”": '"',
    }
    for src, dst in replacements.items():
        text = text.replace(src, dst)
    return " ".join(text.split()).strip(" ,;")


def ascii_text(value: str) -> str:
    text = clean_text(value)
    normalized = unicodedata.normalize("NFKD", text)
    ascii_value = normalized.encode("ascii", "ignore").decode("ascii")
    return clean_text(ascii_value)


def englishize_address(value: str) -> str:
    text = clean_text(value)
    replacements = {
        "Estado de México": "State of Mexico",
        "Ciudad de México": "Mexico City",
        "México": "Mexico",
        "Nuevo León": "Nuevo Leon",
        "Yucatán": "Yucatan",
        "Cortés": "Cortes",
        "Francisco Morazán": "Francisco Morazan",
    }
    for src, dst in replacements.items():
        text = text.replace(src, dst)
    return ascii_text(text)


def englishize_name(value: str) -> str:
    text = clean_text(value)
    replacements = {
        "Ciudad de México": "Mexico City",
        "Secos": "Dry",
        "Perecederos": "Perishables",
        "Frescos": "Fresh",
        "Omnicanal": "Omnichannel",
        "Bajío": "Bajio",
    }
    if text.startswith("Centro de Distribución "):
        rest = text[len("Centro de Distribución ") :]
        for src, dst in replacements.items():
            rest = rest.replace(src, dst)
        rest = ascii_text(rest)
        if rest.startswith("Omnichannel "):
            rest = f"{rest[len('Omnichannel '):]} Omnichannel"
        if rest.startswith("Bajio "):
            rest = f"{rest[len('Bajio '):]} Bajio"
        return clean_text(f"{rest} Distribution Center")
    if text.startswith("Centro de Fulfillment "):
        rest = text[len("Centro de Fulfillment ") :]
        for src, dst in replacements.items():
            rest = rest.replace(src, dst)
        rest = ascii_text(rest)
        return clean_text(f"{rest} Fulfillment Center")
    return ascii_text(text)


def make_row(
    *,
    name_native: str,
    address_native: str,
    country: str,
    country_iso3: str,
    state: str,
    city: str,
    activity: str,
    postcode: str = "",
    source_url: str = SOURCE_URL,
    source_type: str = SOURCE_TYPE,
) -> dict[str, str]:
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": englishize_name(name_native),
        "LOCATION_NAME_NATIVE": clean_text(name_native),
        "LOCATION_ADDRESS": englishize_address(address_native),
        "LOCATION_ADDRESS_NATIVE": clean_text(address_native),
        "LATITUDE": "",
        "LONGITUDE": "",
        "coord_source": COORD_SOURCE_DEFAULT,
        "COUNTRY": clean_text(country),
        "COUNTRY_ISO3": clean_text(country_iso3),
        "POSTCODE": clean_text(postcode),
        "STATE": clean_text(state),
        "CITY": clean_text(city),
        "SOURCE_URL": clean_text(source_url),
        "SOURCE_TYPE": clean_text(source_type),
        "ACTIVITY_AT_ASSET": clean_text(activity),
    }


CHECKPOINT_ROWS = [
    make_row(
        name_native="Centro de Distribución Cuautitlán",
        address_native="Cuautitlán Izcalli, Estado de México, México",
        country="Mexico",
        country_iso3="MEX",
        state="State of Mexico",
        city="Cuautitlan Izcalli",
        activity="Distribution center - dry goods / meat plant",
    ),
    make_row(
        name_native="Centro de Distribución San Martín Obispo 1",
        address_native="San Martín Obispo, Cuautitlán Izcalli, Estado de México, México",
        country="Mexico",
        country_iso3="MEX",
        state="State of Mexico",
        city="Cuautitlan Izcalli",
        activity="Distribution center - dry goods / perishables",
    ),
    make_row(
        name_native="Centro de Distribución San Martín Obispo 2",
        address_native="San Martín Obispo, Cuautitlán Izcalli, Estado de México, México",
        country="Mexico",
        country_iso3="MEX",
        state="State of Mexico",
        city="Cuautitlan Izcalli",
        activity="Distribution center - dry goods / perishables",
    ),
    make_row(
        name_native="Centro de Distribución Santa Bárbara",
        address_native="Santa Bárbara, Cuautitlán Izcalli, Estado de México, México",
        country="Mexico",
        country_iso3="MEX",
        state="State of Mexico",
        city="Cuautitlan Izcalli",
        activity="Distribution center - dry goods",
    ),
    make_row(
        name_native="Centro de Distribución Chalco 1",
        address_native="Chalco, Estado de México, México",
        country="Mexico",
        country_iso3="MEX",
        state="State of Mexico",
        city="Chalco",
        activity="Distribution center - dry goods / perishables",
    ),
    make_row(
        name_native="Centro de Distribución Chalco 2",
        address_native="Chalco, Estado de México, México",
        country="Mexico",
        country_iso3="MEX",
        state="State of Mexico",
        city="Chalco",
        activity="Distribution center - dry goods / perishables",
    ),
    make_row(
        name_native="Centro de Fulfillment Ciudad de México",
        address_native="Ciudad de México, México",
        country="Mexico",
        country_iso3="MEX",
        state="Mexico City",
        city="Mexico City",
        activity="Fulfillment center - eCommerce",
    ),
    make_row(
        name_native="Centro de Distribución Monterrey Secos",
        address_native="Monterrey, Nuevo León, México",
        country="Mexico",
        country_iso3="MEX",
        state="Nuevo Leon",
        city="Monterrey",
        activity="Distribution center - dry goods",
    ),
    make_row(
        name_native="Centro de Distribución Monterrey Perecederos",
        address_native="Monterrey, Nuevo León, México",
        country="Mexico",
        country_iso3="MEX",
        state="Nuevo Leon",
        city="Monterrey",
        activity="Distribution center - perishables / meat plant",
    ),
    make_row(
        name_native="Centro de Fulfillment Monterrey",
        address_native="Monterrey, Nuevo León, México",
        country="Mexico",
        country_iso3="MEX",
        state="Nuevo Leon",
        city="Monterrey",
        activity="Fulfillment center - eCommerce",
    ),
    make_row(
        name_native="Centro de Distribución Guadalajara Secos",
        address_native="Guadalajara, Jalisco, México",
        country="Mexico",
        country_iso3="MEX",
        state="Jalisco",
        city="Guadalajara",
        activity="Distribution center - dry goods",
    ),
    make_row(
        name_native="Centro de Distribución Guadalajara Perecederos",
        address_native="Guadalajara, Jalisco, México",
        country="Mexico",
        country_iso3="MEX",
        state="Jalisco",
        city="Guadalajara",
        activity="Distribution center - perishables",
    ),
    make_row(
        name_native="Centro de Fulfillment Guadalajara",
        address_native="Guadalajara, Jalisco, México",
        country="Mexico",
        country_iso3="MEX",
        state="Jalisco",
        city="Guadalajara",
        activity="Fulfillment center - eCommerce",
    ),
    make_row(
        name_native="Centro de Distribución Villahermosa Secos",
        address_native="Villahermosa, Tabasco, México",
        country="Mexico",
        country_iso3="MEX",
        state="Tabasco",
        city="Villahermosa",
        activity="Distribution center - dry goods",
    ),
    make_row(
        name_native="Centro de Distribución Villahermosa Perecederos",
        address_native="Villahermosa, Tabasco, México",
        country="Mexico",
        country_iso3="MEX",
        state="Tabasco",
        city="Villahermosa",
        activity="Distribution center - perishables",
    ),
    make_row(
        name_native="Centro de Distribución Villahermosa Frescos",
        address_native="Villahermosa, Tabasco, México",
        country="Mexico",
        country_iso3="MEX",
        state="Tabasco",
        city="Villahermosa",
        activity="Distribution center - fresh",
    ),
    make_row(
        name_native="Centro de Distribución Culiacán Secos",
        address_native="Culiacán, Sinaloa, México",
        country="Mexico",
        country_iso3="MEX",
        state="Sinaloa",
        city="Culiacan",
        activity="Distribution center - dry goods",
    ),
    make_row(
        name_native="Centro de Distribución Culiacán Perecederos",
        address_native="Culiacán, Sinaloa, México",
        country="Mexico",
        country_iso3="MEX",
        state="Sinaloa",
        city="Culiacan",
        activity="Distribution center - perishables",
    ),
    make_row(
        name_native="Centro de Distribución Omnicanal Mérida",
        address_native="Mérida, Yucatán, México",
        country="Mexico",
        country_iso3="MEX",
        state="Yucatan",
        city="Merida",
        activity="Distribution center - omnichannel",
    ),
    make_row(
        name_native="Centro de Distribución Omnicanal Chihuahua",
        address_native="Chihuahua, Chihuahua, México",
        country="Mexico",
        country_iso3="MEX",
        state="Chihuahua",
        city="Chihuahua",
        activity="Distribution center - omnichannel",
    ),
    make_row(
        name_native="Centro de Distribución Omnicanal Mexicali Santo Niño",
        address_native="Santo Niño, Mexicali, Baja California, México",
        country="Mexico",
        country_iso3="MEX",
        state="Baja California",
        city="Mexicali",
        activity="Distribution center - omnichannel",
    ),
    make_row(
        name_native="Centro de Distribución Amatitlán",
        address_native="Amatitlán, Guatemala, Guatemala",
        country="Guatemala",
        country_iso3="GTM",
        state="Guatemala Department",
        city="Amatitlan",
        activity="Distribution center - dry goods",
    ),
    make_row(
        name_native="Centro de Distribución Bárcenas 1",
        address_native="Bárcenas, Guatemala, Guatemala",
        country="Guatemala",
        country_iso3="GTM",
        state="Guatemala Department",
        city="Barcenas",
        activity="Distribution center - dry goods / perishables",
    ),
    make_row(
        name_native="Centro de Distribución Bárcenas 2",
        address_native="Bárcenas, Guatemala, Guatemala",
        country="Guatemala",
        country_iso3="GTM",
        state="Guatemala Department",
        city="Barcenas",
        activity="Distribution center - dry goods / perishables",
    ),
    make_row(
        name_native="Centro de Distribución Apopa",
        address_native="Apopa, San Salvador, El Salvador",
        country="El Salvador",
        country_iso3="SLV",
        state="San Salvador Department",
        city="Apopa",
        activity="Distribution center - dry goods",
    ),
    make_row(
        name_native="Centro de Distribución San Juan Opico",
        address_native="San Juan Opico, La Libertad, El Salvador",
        country="El Salvador",
        country_iso3="SLV",
        state="La Libertad Department",
        city="San Juan Opico",
        activity="Distribution center - dry goods",
    ),
    make_row(
        name_native="Centro de Distribución San Pedro Sula 1",
        address_native="San Pedro Sula, Cortés, Honduras",
        country="Honduras",
        country_iso3="HND",
        state="Cortes Department",
        city="San Pedro Sula",
        activity="Distribution center - dry goods",
    ),
    make_row(
        name_native="Centro de Distribución San Pedro Sula 2",
        address_native="San Pedro Sula, Cortés, Honduras",
        country="Honduras",
        country_iso3="HND",
        state="Cortes Department",
        city="San Pedro Sula",
        activity="Distribution center - dry goods",
    ),
    make_row(
        name_native="Centro de Distribución Tegucigalpa",
        address_native="Tegucigalpa, Francisco Morazán, Honduras",
        country="Honduras",
        country_iso3="HND",
        state="Francisco Morazan Department",
        city="Tegucigalpa",
        activity="Distribution center - dry goods / perishables",
    ),
    make_row(
        name_native="Centro de Distribución Mateare",
        address_native="Mateare, Managua, Nicaragua",
        country="Nicaragua",
        country_iso3="NIC",
        state="Managua Department",
        city="Mateare",
        activity="Distribution center - dry goods / perishables",
    ),
    make_row(
        name_native="Centro de Distribución Coyol",
        address_native="Coyol, Alajuela, Costa Rica",
        country="Costa Rica",
        country_iso3="CRI",
        state="Alajuela Province",
        city="Coyol",
        activity="Distribution center - dry goods / perishables",
    ),
    make_row(
        name_native="Centro de Distribución Coris",
        address_native="Coris, Cartago, Costa Rica",
        country="Costa Rica",
        country_iso3="CRI",
        state="Cartago Province",
        city="Coris",
        activity="Distribution center - dry goods",
    ),
]

APPEND_ROWS = [
    make_row(
        name_native="Centro de Distribución Bajío Silao",
        address_native="Silao, Guanajuato, México",
        country="Mexico",
        country_iso3="MEX",
        state="Guanajuato",
        city="Silao",
        activity="Distribution center under construction - robotic warehouse automation / AI-enabled logistics",
    ),
]


def validate_rows(rows: list[dict[str, str]]) -> None:
    for index, row in enumerate(rows, start=1):
        address = row["LOCATION_ADDRESS"]
        city = row["CITY"]
        if not address:
            raise ValueError(f"Row {index} has blank LOCATION_ADDRESS")
        if not city:
            raise ValueError(f"Row {index} has blank CITY")
        if "#" in address:
            raise ValueError(f"Row {index} LOCATION_ADDRESS contains #")
        if row["LATITUDE"] or row["LONGITUDE"]:
            raise ValueError(f"Row {index} unexpectedly has coordinates")
        if row["coord_source"] != COORD_SOURCE_DEFAULT:
            raise ValueError(f"Row {index} has unexpected coord_source")


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=EXPORT_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in EXPORT_COLUMNS})


def build_memory_draft(checkpoint_rows: list[dict[str, str]], final_rows: list[dict[str, str]]) -> str:
    total_records = len(final_rows)
    checkpoint_records = len(checkpoint_rows)
    return f"""### 4.X WAL-MART DE MEXICO, S.A.B. DE C.V. (Apr 2026)

| Source | URL | Records | Method | Script |
|--------|-----|---------|--------|--------|
| Walmex Annual Report 2024 | {SOURCE_URL} | 32 table rows + 1 narrative facility = {total_records} | Annual-report table parse with grouped-count expansion and narrative append | `{SCRIPT_NAME}` |
| **TOTAL** | | **{total_records}** | | |

**Platform Pattern**: Annual report distribution center table with grouped counts and narrative facility mentions.

**Key Approach**: The annual report PDF exposes the core facility inventory as a compact table with grouped counts such as `(2)`, so the working method was to normalize those grouped rows into one output row per facility, export a checkpoint at {checkpoint_records} rows, and then append the extra Silao facility mentioned elsewhere in the same report narrative.

**Approaches Tried** (chronological):
1. Read the extraction memory and matched the task to the annual-report / tabular-PDF family rather than a web locator API pattern.
2. Parsed the annual report table and reconstructed the Mexico rows by reading cross-page word positions because plain text extraction collapsed the table layout.
3. Corroborated locality names with Walmart's official logistics and press pages to normalize city/state fields without inferring website coordinates.
4. Final working approach: build a config-driven exporter with explicit row configs, write the 32-row checkpoint CSV, then append the Silao Bajio distribution center from the same annual report's narrative section.

**Key Learnings**:
- Worked: word-position inspection on the PDF pages was enough to recover the grouped-count distribution-center table when plain extracted text merged columns.
- Worked: locality-level addresses are acceptable when the annual report provides only place names, as long as `LOCATION_ADDRESS` and `CITY` remain non-blank and geocoding-friendly.
- Worked: the 32-row threshold maps to 21 Mexico distribution centers plus 11 Central America distribution centers, and the same report also mentions one additional Silao facility under construction.
- Failed: raw PDF text alone was not reliable for the cross-page Mexico table because the `City / Name / Service` columns collapsed during extraction.
- Failed: no website-published latitude or longitude values were found, so all rows must keep blank coordinates with `coord_source=not_on_website`.

**Script Config**:
```python
ISSUER_ID = "{ISSUER_ID}"
ISSUER_NAME = "{ISSUER_NAME}"
SOURCE_URL = "{SOURCE_URL}"
EXPECTED_MIN_COUNT = {EXPECTED_MIN_COUNT}
CHECKPOINT_COUNT = {CHECKPOINT_COUNT}
```

### 9.X File Inventory Addendum (2026-04-08 - Walmex)

| File | Issuer | Pattern | Key Technique |
|------|--------|---------|---------------|
| `{SCRIPT_NAME}` | WAL-MART DE MEXICO, S.A.B. DE C.V. (Generic) | Annual report distribution-center table export | Grouped-count expansion, cross-page PDF table reconstruction, checkpoint CSV creation, narrative facility append |

### 10.X Walmex Lessons (2026-04-08)

- If an annual report table uses grouped counts like `(2)` without separate sub-facility labels, emit one row per counted facility and keep the shared locality/activity wording rather than inventing unsupported street details.
- When the threshold is met from the main table, create the checkpoint file immediately and only then scan the rest of the report for additional narrative facilities.
- If the report does not publish facility coordinates, leave `LATITUDE` and `LONGITUDE` blank and set `coord_source=not_on_website`.

**Supporting official-source URLs consulted during normalization**:
{chr(10).join(f"- {url}" for url in SUPPORTING_URLS)}
"""


def main() -> None:
    started = time.time()
    checkpoint_rows = CHECKPOINT_ROWS[:]
    final_rows = CHECKPOINT_ROWS + APPEND_ROWS

    if len(checkpoint_rows) != CHECKPOINT_COUNT:
        raise ValueError(
            f"Checkpoint row count mismatch: expected {CHECKPOINT_COUNT}, got {len(checkpoint_rows)}"
        )
    if len(final_rows) < EXPECTED_MIN_COUNT:
        raise ValueError(
            f"Final row count {len(final_rows)} is below expected minimum {EXPECTED_MIN_COUNT}"
        )

    validate_rows(checkpoint_rows)
    validate_rows(final_rows)

    write_csv(CHECKPOINT_PATH, checkpoint_rows)
    write_csv(WORKING_PATH, final_rows)
    write_csv(FINAL_OUTPUT_PATH, final_rows)

    MEMORY_DRAFT_PATH.write_text(
        build_memory_draft(checkpoint_rows, final_rows),
        encoding="utf-8",
    )

    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "checkpoint_count": len(checkpoint_rows),
        "final_count": len(final_rows),
        "extra_rows_after_checkpoint": len(final_rows) - len(checkpoint_rows),
        "checkpoint_path": str(CHECKPOINT_PATH),
        "working_path": str(WORKING_PATH),
        "final_output_path": str(FINAL_OUTPUT_PATH),
        "memory_draft_path": str(MEMORY_DRAFT_PATH),
        "coord_source": COORD_SOURCE_DEFAULT,
        "lat_lng_rows_present": 0,
        "execution_seconds": round(time.time() - started, 2),
        "completed_at": datetime.now().isoformat(timespec="seconds"),
        "source_url": SOURCE_URL,
    }
    SUMMARY_PATH.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
