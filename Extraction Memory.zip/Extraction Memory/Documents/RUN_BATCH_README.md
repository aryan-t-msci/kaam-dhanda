# run_batch.ps1 - 50-issuer scale test

Purpose: run the proven `codex exec` per-issuer loop across a larger slice of the
universe (default 50: >=25% heaviest + the remainder randomly sampled from the file) to confirm it holds at scale before
committing to the full ~500. Same fresh-context-per-worker mechanism as
`run_batch_poc.ps1`; this adds the resilience a multi-hour unattended run needs.

## TL;DR

```
powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch.ps1"
```

That processes 50 issuers (>=25% heaviest + the remainder random; the chosen set is
persisted so re-runs are reproducible and resume-safe). If the run stops part
way (usually a usage-window limit), just run the SAME command again - it resumes.

## What is different from the PoC

1. RESUME-SKIP. State lives in `done_iids.txt` (one issuer ID per line). On every
   start, issuers already completed are skipped. The run identity is stable per input
   file (folder `Run_<inputname>`), so re-running the same input continues where it
   left off instead of starting over.
2. FAILURE-SAFE POOL. A worker that dies or hits a usage limit with no output does NOT
   crash the run. It is logged, recorded as failed, and left for the next re-run to
   retry (only `done` issuers are skipped; failed ones come back).
3. HALT-ON-STALL. If 3 workers in a row finish with no output (the signature of a
   usage-window block or an environment problem), the run stops cleanly, kills any
   active workers, and prints a resume hint - instead of burning the plan window on
   failing workers.
4. PER-RUN LOG. Everything Write-Log prints is also saved to
   `Run_<inputname>\logs\run_<timestamp>.log`.
5. PINNED ENCODING on every file the orchestrator writes (the recurring bug class).
6. DYNAMIC WORKER CAP. The parallel worker count is auto-sized to the machine (RAM +
   cores) instead of a fixed 3, gated on live free RAM, and reduced if codex starts
   rejecting workers. See "Dynamic worker cap" below.

## NO GEOCODING (workflow change)

The extraction workflow was changed to forbid geocoding entirely (prompt.md section 5c
+ WORKER_PROMPT.md QA step):

- LATITUDE / LONGITUDE are populated ONLY when the coordinates are already present in
  the source you extracted the location from - page text, embedded JSON / store-locator
  API responses, a page data layer, or map embeds (`data-lat`/`data-lng`, Google Maps
  `!2d`/`!3d`).
- No geocoding service or library is ever called (Bing, Nominatim, Google geocoding,
  Naver, Kakao, OpenStreetMap/Photon, MapMyIndia, ...). No exception.
- If the source has no coordinates, LATITUDE and LONGITUDE stay blank and
  `coord_source` = `Not from website`.
- Safety net: if a row still arrives with geocoded/estimated coordinates, QA blanks the
  coordinates and sets `coord_source` = `Not from website`.

This affects EVERY worker (PoC and scaled), because it lives in the shared prompts.

## How to run

Bare run (all defaults: 50 issuers, cap 3, default input):
```
powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch.ps1"
```

Override pieces as needed:
```
powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch.ps1" -Limit 50               # cap auto-sized
powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch.ps1" -WorkerCap 4             # force a fixed cap of 4
powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch.ps1" -InputFile "C:\path\to\file.xlsx"
powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch.ps1" -Model "gpt-5.4" -Reasoning "high"
```

Force a clean start (wipe progress for this input and redo all 50):
```
powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch.ps1" -Fresh
```

Parameters: `-Model` (default gpt-5.4), `-Reasoning` (default high), `-InputFile`,
`-Limit` (default 50), `-WorkerCap` (default 0 = auto-size to the machine; a positive value
forces a fixed cap), `-Fresh` (switch).

## Dynamic worker cap

`-WorkerCap 0` (the default) auto-sizes the number of parallel workers to your machine:
`cap = min(usable_RAM / per-worker-RAM, cores - reserve)`, clamped to a floor and a
ceiling. A positive `-WorkerCap N` forces a fixed cap instead.

Two things matter here:

- RAM is the real machine limit (each worker runs a headless browser + Python, peaking
  at a couple of GB). The script also re-checks LIVE free RAM before every spawn and
  holds off when memory is tight, so it will not over-subscribe and cause OOM-killed
  workers (which waste codex tokens).
- The codex plan limit (rolling 5h / weekly budget) is the constraint that actually
  caps total throughput, and it CANNOT be queried. More parallel workers do not get
  more issuers done per window - they just burn the budget faster. So the cap has a
  deliberate ceiling, and if a worker dies empty very fast (the signature of a rate /
  concurrency rejection), the script backs the cap off by one. If failures persist,
  halt-on-stall stops the run with a resume hint.

Tune in the CONFIG block: `PER_WORKER_RAM_GB`, `OS_RESERVE_GB`, `MIN_FREE_RAM_GB`,
`CORE_RESERVE`, `CAP_CEILING`, `CAP_FLOOR`, `FAST_FAIL_MINUTES`. The chosen cap and the
inputs behind it are printed at startup.

## Realistic runtime and the resume loop

At roughly 20-40 minutes per issuer and a handful in parallel (auto-sized to your machine),
50 issuers is several hours of
wall-clock and will very likely hit the rolling 5-hour (and/or weekly) codex plan
window before finishing. That is expected and handled:

- The run keeps going until ~3 workers in a row come back empty, then HALTS with:
  "RESUME: after the usage window resets, re-run the SAME command ..."
- Wait for the window to reset, run the same command again. It reads `done_iids.txt`,
  skips everything already promoted, and continues. Repeat until all 50 are done.

Keep the machine awake while a run is active.

## What success looks like

- Console / log shows: parse -> "To process now: N" -> spawned workers -> a
  `promoted <IID> -> output (R rows)` line per issuer -> a final "pass complete" line.
- Promoted CSVs land in the output folder (one `<IID>_<NAME>.csv` per issuer).
- `done_iids.txt` lists every completed issuer; `progress.jsonl` is the audit trail
  (one JSON line per issuer with status / rows / timestamp).

## Where things are

For input file X, with the configured roots:
- Output CSVs : `<OUTPUT_ROOT>\Run_X\`
- Work area   : `<TEMP_ROOT>\Run_X\`  (workers\, staging\, status\, logs\,
  done_iids.txt, progress.jsonl, reject\, gap\, exhaustion_proof\)

Paths are set in the CONFIG block at the top of the script.

TIP: for large runs, point TEMP_ROOT and OUTPUT_ROOT at a LOCAL (non-OneDrive) folder
to avoid OneDrive "automatic file downloads" popups and sync contention. MEMORY_FOLDER
can stay on OneDrive (keep it pinned / always-available locally).

## Troubleshooting

- "codex.js not found" / "WORKER_PROMPT.md not found" / "INPUT_FILE not found": fix the
  paths in CONFIG (or pass -InputFile).
- "No Python interpreter found": the parse step needs Python + openpyxl
  (`pip install openpyxl`).
- "PARSE FAILED ...": the input workbook header / sheets were not recognised. Bounded
  diagnostics print to console; full raw parser output is saved to
  `Run_X\_parse_stdout.txt`.
- A worker shows "exited with NO DONE flag": open `Run_X\workers\<IID>_worker.log`
  (it is UTF-16) to see why. If several do this in a row, it is almost certainly the
  usage window - wait and re-run.
- Re-running does nothing / "All target issuers already completed": the 50 are done.
  Use `-Fresh` to redo them, or raise `-Limit` to take in more issuers.

## Deliberately NOT in this scale test (still on the production list)

Canonical-schema normalization at promotion (workers still emit slightly different
trailing columns), URL classification step, rework tiers (3/4/5), orchestrator scrub +
reject consolidation, KB-draft consolidation, and the full ~500 run. Per-issuer worker
logic is unchanged from the PoC except for the no-geocoding rule above.
