# Extraction Memory — README
**Version:** 2.0 | **Last Updated:** 2026-04-29

This folder is the persistent knowledge and tooling store for the MSCI GSAI
facility extraction workflow. It survives across tasks, conversations, and devices.
Do not save intermediate or task-specific files here — see §File Organisation below.

---

## Architecture Overview

The extraction system uses a **two-tier multi-agent architecture**:

```
User trigger (one message)
        │
        ▼
┌─────────────────────────┐
│   ORCHESTRATOR AGENT    │  ← reads ORCHESTRATOR_PROMPT.md
│   - Parses input Excel  │
│   - Divides issuers     │
│   - Spawns 6 workers    │
│   - Monitors + merges   │
└────────────┬────────────┘
             │ spawns
    ┌────────┴────────┐
    ▼                 ▼
[Worker 1]  ...  [Worker 6]   ← each reads WORKER_PROMPT.md
 - Rolling queue               - Independent extraction
 - Adaptive concurrency        - Shared audit/KB files
 - Gap recovery                - Flag-based signalling
 - KB updates
```

**Agent cap note:** Codex Desktop (as of April 2026) enforces a hard limit of
6 simultaneous active agents. The system uses 1 orchestrator + 6 workers = 7,
which works because the orchestrator enters a lightweight monitoring state
(releasing its active reasoning slot) while workers execute. If the platform
cap increases in future versions, `WORKER_COUNT` in `ORCHESTRATOR_PROMPT.md`
can be raised accordingly.

---

## Quick Start

**Batch run (multi-agent, recommended):**
```
From MEMORY_FOLDER, read and execute:
1. prompt.md
2. ORCHESTRATOR_PROMPT.md

MEMORY_FOLDER : <path to this folder>
INPUT_FILE    : <path to input xlsx>
TEMP_FOLDER   : <path to Temp folder>
OUTPUT_FOLDER : <path to Output folder>
WORKER_COUNT  : 6
```

**Single issuer run:**
```
From MEMORY_FOLDER, read and execute:
1. prompt.md
2. TASK_PROMPT_TEMPLATE.md

MEMORY_FOLDER : <path to this folder>
ISSUER_ID     : IID000000000000000
ISSUER_NAME   : Company Name
COUNT         : 0
TEMP_FOLDER   : <path to Temp folder>
OUTPUT_FOLDER : <path to Output folder>

URLS
https://...
```

---

## File Inventory

### Core Instructions

| File | Role | Status |
|------|------|--------|
| `prompt.md` | Standing rules — applies to every task (single and batch) | ✅ Current (v3.1) |
| `ORCHESTRATOR_PROMPT.md` | Parent agent — divides work, spawns workers, merges results | ✅ Current (v1.0) |
| `WORKER_PROMPT.md` | Worker agent — extraction pipeline for assigned issuers | ✅ Current (v1.0) |
| `TASK_PROMPT_TEMPLATE.md` | Single-issuer trigger template | ✅ Current |
| `TASK_PROMPT_TEMPLATE_BATCH.md` | Old single-agent batch template | ⚠️ Superseded — kept as fallback |

### Knowledge Base

| File | Role | Status |
|------|------|--------|
| `KB_INDEX.md` | Fast-read entry point — read every task (~2 min) | ✅ Current (v5.1) |
| `KB/` (per-record files) | Full patterns, records, utilities — jump to sections only | ✅ Current (v5.1) |
| `extraction_approach_v2.md` | Legacy KB — read-only fallback | ✅ Retained (superseded) |

### Documentation

| File | Role |
|------|------|
| `README.md` | This file — system overview and quick start |
| `BATCH_REPORT_README.md` | Documents `batch_report.py`, `batch_audit.jsonl`, `batch_qa.jsonl` |
| `EXTRACTION_SYSTEM_PROMPT (old).md` | Grandparent prompt — historical reference only |

### Python Scripts (~98 files)

Generalized platform extractors, utility modules, and company-specific scripts.
All Category A and B scripts are listed in `KB_INDEX.md §4 Script Inventory`.
See `KB_INDEX.md` for the full catalogue.

---

## File Organisation Rules

| What | Where | Never here |
|------|-------|-----------|
| Reusable extraction scripts (Cat A/B) | This folder | Temp outputs, debug logs |
| Utility modules | This folder | Progress JSON files |
| KB drafts | `Temp\Extraction_Batch_*\{ISSUER_ID}\` | Intermediate scripts |
| Final output CSVs | `Output\Extraction_Batch_*\` | |
| Audit/QA logs | `Temp\Extraction_Batch_*\` | |
| Worker queue files | `Temp\Extraction_Batch_*\workers\` | |

---

## Shared File Protocols (Multi-Agent)

When multiple workers run concurrently, three files require serialised access:

| File | Lock | Stale threshold |
|------|------|----------------|
| `KB_INDEX.md` + `KB/` (per-record files) | `KB_WRITE.lock` in this folder | 10 minutes |
| `batch_audit.jsonl` | `AUDIT_WRITE.lock` in batch temp | 2 minutes |
| `batch_qa.jsonl` | `AUDIT_WRITE.lock` (same lock, bundled) | 2 minutes |

Never write to KB files or audit files without acquiring the appropriate lock first.

---

## Platform Compatibility

All `.md` files in this folder are plain UTF-8 markdown — readable by any AI model
on any platform (Codex, Claude Code, Cursor, Gemini, ChatGPT, VS Code Copilot, etc.).

If the agent has filesystem access: it reads files directly by path.
If not (web-based): paste file contents into the conversation — the agent
treats pasted content as if read from the indicated path.

All paths are relative to `MEMORY_FOLDER` provided in the trigger — no hardcoded paths.

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 3.0 | 2026-05-04 | One-worker-per-issuer architecture; dynamic cap probe; rework pass; staging layer; exhaustion proof gate; atomic flags; model inheritance; pre-validation |
| 2.0 | 2026-04-29 | Multi-agent architecture — ORCHESTRATOR_PROMPT + WORKER_PROMPT added |
| 1.x | 2026-04 | Single-agent batch with rolling queue, adaptive concurrency, QA validation |
| 1.0 | 2026-03 | Initial system — KB split (INDEX+DETAIL), prompt.md, batch template |
