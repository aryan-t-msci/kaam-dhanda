"""
Static HTML Contact List + Detail Page Coordinate Extractor
============================================================
Platform Pattern: Static HTML listing page (section 3.5) with per-location detail pages
                  that embed Google Maps coordinates via a data-markers JSON attribute.

Detected on: CEZ (cez.cz) — Czech energy utility contact locations page.
             Page structure: <section data-is="ContactList"> containing
             <a class="contacts-list__grid-item"> cards with city, type, address.
             Each card links to a detail page with:
             <section data-is="GoogleMap" data-markers='[{"lat":...,"lng":...}]'>

How to configure for a new issuer:
   1. Change the CONFIGURATION block below.
   2. Adjust CARD_SELECTOR, CITY_SELECTOR, TYPE_PARA_IDX, ADDR_PARA_IDX if the card
      HTML structure differs.
   3. Adjust DETAIL_COORD_SELECTOR if the coordinates are in a different data attribute.
   4. Update ACTIVITY_MAP with the site's location type labels → standardized activities.

Usage:
   python static_html_detail_page_extractor.py

Dependencies:
   pip install requests beautifulsoup4 pandas unicodedata
"""

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_ID   = "IID000000002125056"
ISSUER_NAME = "CEZ, a.s."
BASE_URL    = "https://www.cez.cz"
LISTING_URL = "https://www.cez.cz/cs/kontakty/kontaktni-mista-cez"
COUNTRY     = "Czechia"
COUNTRY_ISO3 = "CZE"
SOURCE_TYPE  = "COMPANY WEBSITE"

# HTML structure selectors for the listing page
CARD_SELECTOR      = "a.contacts-list__grid-item"
CITY_SELECTOR      = "h3.contacts-list__item-headline"
TYPE_PARA_IDX      = 0   # index of <p> tag that has location type
ADDR_PARA_IDX      = 1   # index of <p> tag that has address

# Selector for the detail page map section with coordinates
DETAIL_COORD_SELECTOR = "[data-is='GoogleMap']"
DETAIL_COORD_ATTR     = "data-markers"  # JSON string: [{"lat":..., "lng":...}]

# Map location types (Czech) to standardized activity
ACTIVITY_MAP = {
    "zákaznické centrum": "Customer Service Centre",
    "kontaktní místo - česká pošta": "Customer Contact Point / Post Office",
    "kontaktní místo": "Customer Contact Point",
}

OUTPUT_DIR   = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp"
FINAL_OUTPUT = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output"
PROGRESS_FILE = rf"{OUTPUT_DIR}\cez_progress.json"

# Request delay between detail pages (seconds)
REQUEST_DELAY = 0.4

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC BELOW — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════

import sys, os, re, json, time, ssl, unicodedata
sys.stdout.reconfigure(encoding='utf-8')

import urllib.request
from urllib.parse import urljoin
from bs4 import BeautifulSoup
import pandas as pd
from pathlib import Path

# ── Czech-specific transliteration map ──────────────────────
# Czech has diacritics that need careful mapping to preserve meaning
CZECH_CHAR_MAP = {
    'á': 'a', 'č': 'c', 'ď': 'd', 'é': 'e', 'ě': 'e',
    'í': 'i', 'ň': 'n', 'ó': 'o', 'ř': 'r', 'š': 's',
    'ť': 't', 'ú': 'u', 'ů': 'u', 'ý': 'y', 'ž': 'z',
    'Á': 'A', 'Č': 'C', 'Ď': 'D', 'É': 'E', 'Ě': 'E',
    'Í': 'I', 'Ň': 'N', 'Ó': 'O', 'Ř': 'R', 'Š': 'S',
    'Ť': 'T', 'Ú': 'U', 'Ů': 'U', 'Ý': 'Y', 'Ž': 'Z',
}

def transliterate_czech(text: str) -> str:
    """Transliterate Czech diacritics to ASCII equivalents, preserving meaning."""
    if not text:
        return text
    result = []
    for ch in text:
        result.append(CZECH_CHAR_MAP.get(ch, ch))
    # Also apply NFKD normalization for any remaining non-ASCII
    normalized = ''.join(result)
    ascii_result = unicodedata.normalize('NFKD', normalized)
    ascii_result = ''.join(c for c in ascii_result if unicodedata.category(c) != 'Mn' or ord(c) < 128)
    # Final cleanup: remove any non-ASCII that slipped through
    ascii_result = ascii_result.encode('ascii', errors='ignore').decode('ascii')
    return ascii_result.strip()


def clean_address(addr: str) -> str:
    """Remove geocoding-unfriendly characters from address."""
    if not addr:
        return addr
    addr = addr.replace('#', '').replace('  ', ' ').strip()
    return addr


def make_ssl_context():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def fetch_url(url: str, ctx, retries: int = 3) -> str:
    """Fetch a URL with browser-like headers, return decoded text or empty string."""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'cs,en;q=0.8',
    }
    req = urllib.request.Request(url, headers=headers)
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(req, context=ctx, timeout=20) as resp:
                return resp.read().decode('utf-8', errors='replace')
        except Exception as e:
            print(f"  Attempt {attempt+1} failed for {url}: {e}")
            time.sleep(1.5)
    return ''


def extract_coords_from_detail(detail_html: str) -> tuple:
    """
    Extract (lat, lng) from a detail page with data-markers attribute.
    Returns (lat, lng) as floats, or ('', '') if not found.
    """
    if not detail_html:
        return '', ''
    soup = BeautifulSoup(detail_html, 'html.parser')
    map_section = soup.find(attrs={'data-is': 'GoogleMap'})
    if not map_section:
        return '', ''
    markers_str = map_section.get(DETAIL_COORD_ATTR, '')
    if not markers_str:
        return '', ''
    try:
        markers = json.loads(markers_str)
        if markers and isinstance(markers, list):
            lat = markers[0].get('lat', '')
            lng = markers[0].get('lng', '')
            return lat, lng
    except json.JSONDecodeError:
        pass
    return '', ''


def extract_city_postcode(address_czech: str) -> tuple:
    """
    Parse Czech address format: "Street Number, POSTCODE City"
    Returns (city_czech, postcode)
    Czech postal codes are 5 digits written as 'XXX XX'.
    """
    # Czech pattern: "Ulice 123/45, 123 45 Město"
    # Postcode is 5 digits (sometimes written with space: "256 01")
    postcode = ''
    city_czech = ''

    # Find Czech postal code pattern: 3 digits space 2 digits
    pc_match = re.search(r'\b(\d{3}\s?\d{2})\b\s+(.+?)$', address_czech)
    if pc_match:
        postcode = pc_match.group(1).replace(' ', '')  # normalize to 5-digit
        city_czech = pc_match.group(2).strip().rstrip(',').strip()
    return city_czech, postcode


def get_activity(location_type_czech: str) -> str:
    """Map Czech location type to standardized activity."""
    lt_lower = location_type_czech.lower().strip()
    for key, value in ACTIVITY_MAP.items():
        if key in lt_lower:
            return value
    return "Customer Contact Point"


def load_progress():
    if Path(PROGRESS_FILE).exists():
        with open(PROGRESS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}


def save_progress(records: list, done_urls: set):
    data = {'records': records, 'done_urls': list(done_urls)}
    with open(PROGRESS_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(FINAL_OUTPUT, exist_ok=True)
    ctx = make_ssl_context()

    print(f"=== CEZ Contact Location Extractor ===")
    print(f"Fetching listing page: {LISTING_URL}")
    listing_html = fetch_url(LISTING_URL, ctx)
    if not listing_html:
        print("ERROR: Could not fetch listing page")
        return

    soup = BeautifulSoup(listing_html, 'html.parser')
    cards = soup.find_all('a', class_='contacts-list__grid-item')
    print(f"Found {len(cards)} location cards on listing page")

    # Load progress if exists
    progress = load_progress()
    records = progress.get('records', [])
    done_urls = set(progress.get('done_urls', []))
    print(f"Resuming: {len(done_urls)} already done, {len(records)} records in progress")

    for i, card in enumerate(cards):
        relative_href = card.get('href', '')
        detail_url = urljoin(BASE_URL, relative_href)

        if detail_url in done_urls:
            print(f"  [{i+1}/{len(cards)}] SKIP (already done): {detail_url}")
            continue

        # Extract city (Czech native form for LOCATION_NAME_NATIVE)
        city_elem = card.find('h3', class_='contacts-list__item-headline')
        city_native = city_elem.get_text(strip=True) if city_elem else ''

        paras = card.find_all('p')
        location_type_czech = paras[TYPE_PARA_IDX].get_text(strip=True) if len(paras) > TYPE_PARA_IDX else ''
        address_native = paras[ADDR_PARA_IDX].get_text(strip=True) if len(paras) > ADDR_PARA_IDX else ''

        # Transliterate
        city_en = transliterate_czech(city_native)
        address_en = transliterate_czech(address_native)
        location_type_en = transliterate_czech(location_type_czech)

        # Parse city and postcode from address
        city_from_addr, postcode = extract_city_postcode(address_native)
        city_en_parsed = transliterate_czech(city_from_addr) if city_from_addr else city_en

        # Clean address (geocoding-friendly)
        address_clean = clean_address(address_en)

        # Get coordinates from detail page
        print(f"  [{i+1}/{len(cards)}] Fetching: {detail_url}")
        detail_html = fetch_url(detail_url, ctx)
        lat, lng = extract_coords_from_detail(detail_html)
        coord_source = 'website' if lat != '' and lng != '' else ''

        # Determine activity
        activity = get_activity(location_type_czech)

        # Location name = city + type in English (transliterated)
        location_name = f"{city_en} - {location_type_en}"

        record = {
            'ISSUER_ID': ISSUER_ID,
            'ISSUER_NAME': ISSUER_NAME,
            'LOCATION_NAME': location_name,
            'LOCATION_NAME_NATIVE': f"{city_native} - {location_type_czech}",
            'LOCATION_ADDRESS': address_clean,
            'LOCATION_ADDRESS_NATIVE': address_native,
            'LATITUDE': lat,
            'LONGITUDE': lng,
            'COUNTRY': COUNTRY,
            'COUNTRY_ISO3': COUNTRY_ISO3,
            'POSTCODE': postcode,
            'STATE': '',   # Czech addresses don't have states; will use region from city lookup if needed
            'CITY': city_en_parsed,
            'SOURCE_URL': detail_url,
            'SOURCE_TYPE': SOURCE_TYPE,
            'ACTIVITY_AT_ASSET': activity,
            'coord_source': coord_source,
        }
        records.append(record)
        done_urls.add(detail_url)

        # Save progress every 20 items
        if len(done_urls) % 20 == 0:
            save_progress(records, done_urls)
            print(f"  Progress saved: {len(records)} records")

        time.sleep(REQUEST_DELAY)

    print(f"\nExtraction complete: {len(records)} total records")

    # Build dataframe and export
    df = pd.DataFrame(records)

    # Final cleanup pass
    df['LOCATION_ADDRESS'] = df['LOCATION_ADDRESS'].str.replace('#', '', regex=False).str.strip()
    df['CITY'] = df['CITY'].str.strip()

    # Checkpoint CSV in Temp
    checkpoint_path = Path(OUTPUT_DIR) / f"{ISSUER_ID}_{ISSUER_NAME}_checkpoint.csv"
    df.to_csv(checkpoint_path, index=False, encoding='utf-8-sig')
    print(f"Checkpoint saved: {checkpoint_path}")

    # Final CSV in Output
    final_name = f"{ISSUER_ID}_{ISSUER_NAME}.csv"
    final_path = Path(FINAL_OUTPUT) / final_name
    df.to_csv(final_path, index=False, encoding='utf-8-sig')
    print(f"Final CSV saved: {final_path}")
    print(f"Total records: {len(df)}")
    print(f"Records with coordinates: {(df['LATITUDE'] != '').sum()}")
    print(f"Blank CITY: {(df['CITY'] == '').sum()}")
    print(f"Blank LOCATION_ADDRESS: {(df['LOCATION_ADDRESS'] == '').sum()}")
    print("\nSample output:")
    print(df[['LOCATION_NAME', 'LOCATION_ADDRESS', 'CITY', 'POSTCODE', 'LATITUDE', 'LONGITUDE', 'ACTIVITY_AT_ASSET']].head(5).to_string())

    # Cleanup progress file
    if Path(PROGRESS_FILE).exists():
        os.remove(PROGRESS_FILE)

    return df


if __name__ == '__main__':
    main()
