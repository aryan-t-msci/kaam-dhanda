"""
Extract facility rows from static HTML location-map pages that publish one or more
company cards inside map markers with `data-lat` / `data-lng` attributes.

This pattern was observed on Dermapharm's TYPO3 location map, where each
`.map__location` wrapper holds website-published coordinates and one or more
`.location__company` cards with company names, optional descriptions, and address
paragraphs.

To reuse for another issuer, update only the configuration block below.

Usage:
    python static_html_map_location_company_extractor.py
"""

from __future__ import annotations

import csv
import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
from urllib.parse import parse_qs, unquote, urlparse

import requests
from bs4 import BeautifulSoup, Tag


# ============================================================
# CONFIGURATION - Edit this block for each new issuer
# ============================================================
ISSUER_ID = "IID000000002834226"
ISSUER_NAME = "Dermapharm Holding SE"
SOURCE_URL = "https://dermapharm.com/de-de/unternehmensgruppe/unternehmensstandorte/"
STAGING_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Extraction_Batch_Chat5.4_odbatch9_10_output_for_straive_20260601_112949\staging"
)
TEMP_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Extraction_Batch_Chat5.4_odbatch9_10_output_for_straive_20260601_112949\IID000000002834226_Dermapharm Holding SE"
)
OUTPUT_NAME = f"{ISSUER_ID}_{ISSUER_NAME}.csv"


# ============================================================
# GENERIC EXTRACTION LOGIC - Do not modify per-issuer
# ============================================================
COUNTRY_MAP = {
    "Österreich": ("Austria", "AUT"),
    "Niederlande": ("Netherlands", "NLD"),
    "Deutschland": ("Germany", "DEU"),
    "Schweden": ("Sweden", "SWE"),
    "Vereinigte Staaten": ("United States", "USA"),
    "Spanien": ("Spain", "ESP"),
    "Vietnam": ("Vietnam", "VNM"),
    "Italien": ("Italy", "ITA"),
    "Frankreich": ("France", "FRA"),
    "Indien": ("India", "IND"),
    "Volksrepublik China": ("China", "CHN"),
    "Schweiz": ("Switzerland", "CHE"),
    "Ukraine": ("Ukraine", "UKR"),
    "Portugal": ("Portugal", "PRT"),
    "Polen": ("Poland", "POL"),
    "Griechenland": ("Greece", "GRC"),
    "Tschechien": ("Czech Republic", "CZE"),
    "Belgien": ("Belgium", "BEL"),
    "Japan": ("Japan", "JPN"),
    "Kroatien": ("Croatia", "HRV"),
}

CITY_ALIAS = {
    "Aldorf": "Alsdorf",
    "Bozen": "Bozen",
    "Den Haag": "The Hague",
    "Hongkong": "Hong Kong",
    "Kiew": "Kyiv",
    "Lissabon": "Lisbon",
    "Mailand": "Milan",
    "Muenchen": "Munich",
    "München": "Munich",
    "Peking": "Beijing",
    "Tokio": "Tokyo",
    "Wien": "Vienna",
}

STATE_ALIAS = {
    "PA": "Pennsylvania",
    "TX": "Texas",
}

LABEL_PREFIXES = ("tel", "telefon", "fax", "e-mail", "email", "internet")
ADDRESS_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
]


@dataclass
class ParsedLocation:
    location_name: str
    location_address: str
    latitude: str
    longitude: str
    country: str
    country_iso3: str
    postcode: str
    state: str
    city: str
    activity: str


def normalize_space(value: str) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


def transliterate_ascii(value: str) -> str:
    if not value:
        return ""
    replacements = {
        "ß": "ss",
        "ä": "ae",
        "ö": "oe",
        "ü": "ue",
        "Ä": "Ae",
        "Ö": "Oe",
        "Ü": "Ue",
        "Đ": "D",
        "đ": "d",
        "Ł": "L",
        "ł": "l",
        "Ś": "S",
        "ś": "s",
        "Ż": "Z",
        "ż": "z",
        "Ź": "Z",
        "ź": "z",
        "Ć": "C",
        "ć": "c",
        "Ń": "N",
        "ń": "n",
        "Ó": "O",
        "ó": "o",
        "Ą": "A",
        "ą": "a",
        "Ę": "E",
        "ę": "e",
        "’": "'",
        "–": "-",
        "—": "-",
        "\xa0": " ",
    }
    for src, target in replacements.items():
        value = value.replace(src, target)
    value = unicodedata.normalize("NFKD", value)
    value = value.encode("ascii", "ignore").decode("ascii")
    return normalize_space(value)


def extract_daddr(route_href: str) -> str:
    if not route_href:
        return ""
    query = parse_qs(urlparse(route_href).query)
    daddr = query.get("daddr", [""])[0]
    return normalize_space(unquote(daddr))


def is_label_line(text: str) -> bool:
    lowered = normalize_space(text).lower()
    return any(lowered.startswith(prefix) for prefix in LABEL_PREFIXES)


def split_address_lines(address_block: Tag) -> tuple[list[str], list[str]]:
    lines: list[str] = []
    descriptions: list[str] = []
    for paragraph in address_block.find_all("p", recursive=False):
        text = normalize_space(paragraph.get_text(" ", strip=True))
        if not text:
            continue
        paragraph_lines = [normalize_space(x) for x in paragraph.get_text("\n", strip=True).split("\n")]
        paragraph_lines = [line for line in paragraph_lines if line]
        has_breaks = "<br" in str(paragraph).lower()
        if has_breaks and not is_label_line(paragraph_lines[0]) and not lines:
            # Keep only the leading address lines; later contact lines sometimes share the
            # same paragraph element on this template.
            for line in paragraph_lines:
                if is_label_line(line):
                    break
                lines.append(line)
        elif not is_label_line(text):
            descriptions.append(text)
    return lines, descriptions


def first_in_title_case(slug: str) -> str:
    slug = slug.replace("-", " ").strip()
    return " ".join(part.capitalize() for part in slug.split())


def normalize_postcode(country: str, postcode: str) -> str:
    postcode = normalize_space(postcode)
    if not postcode:
        return ""
    if country == "Netherlands":
        match = re.match(r"^(\d{4})\s*([A-Z]{2})$", postcode)
        if match:
            return f"{match.group(1)} {match.group(2)}"
    if country == "Japan":
        digits = re.sub(r"\D", "", postcode)
        return digits if len(digits) == 7 else postcode
    if country == "France" and re.fullmatch(r"\d{4}", postcode):
        return postcode.zfill(5)
    if country == "China" and re.fullmatch(r"\d{6}", postcode):
        return postcode
    return postcode


def normalize_city(city: str) -> str:
    city = normalize_space(city.strip(","))
    return CITY_ALIAS.get(city, city)


def parse_city_state_postcode(
    country: str,
    city_line: str,
    street_lines: list[str],
    data_location: str,
    route_daddr: str,
) -> tuple[str, str, str]:
    city_line = normalize_space(city_line)
    data_city = normalize_city(first_in_title_case(data_location))
    postcode = ""
    state = ""
    city = ""

    if country in {"Germany", "Austria", "Switzerland", "Spain", "Belgium", "Croatia"}:
        match = re.match(r"^(\d{4,5})\s+(.+)$", city_line)
        if match:
            postcode, city = match.groups()
    elif country == "Sweden":
        match = re.match(r"^(\d{3}\s?\d{2})\s+(.+)$", city_line)
        if match:
            postcode, city = match.groups()
    elif country == "Czech Republic":
        match = re.match(r"^(\d{3}\s?\d{2})\s+(.+)$", city_line)
        if match:
            postcode, city = match.groups()
    elif country == "Netherlands":
        match = re.match(r"^(\d{4}\s?[A-Z]{2})\s+(.+)$", city_line)
        if match:
            postcode, city = match.groups()
    elif country == "Poland":
        match = re.match(r"^(\d{2}-\d{3})\s+(.+)$", city_line)
        if match:
            postcode, city = match.groups()
    elif country == "Portugal":
        match = re.match(r"^(\d{4}-\d{3})\s+(.+)$", city_line)
        if match:
            postcode, city = match.groups()
    elif country == "France":
        match = re.match(r"^(\d{4,5})\s+(.+)$", city_line)
        if match:
            postcode, city = match.groups()
    elif country == "Italy":
        match = re.match(r"^(\d{5})\s+(.+?)(?:\s+([A-Z]{2}))?$", city_line)
        if match:
            postcode = match.group(1)
            city = match.group(2)
            state = match.group(3) or ""
    elif country == "India":
        match = re.match(r"^(\d{5,6})\s+(.+)$", city_line)
        if match:
            postcode, city = match.groups()
    elif country == "United States":
        if match := re.match(r"^(\d{5})\s+([^,]+),\s*(.+)$", city_line):
            postcode, city, state = match.groups()
        elif match := re.match(r"^([A-Za-z .'-]+)\s+([A-Z]{2})\s+(\d{5})$", city_line):
            city, state, postcode = match.groups()
        elif match := re.match(r"^(\d{5})\s+(.+)$", city_line):
            postcode = match.group(1)
            state = match.group(2)
            city = data_city if data_city and data_city.lower() != state.lower() else ""
    elif country == "Vietnam":
        state = city_line
        if "," in street_lines[-1]:
            city = normalize_space(street_lines[-1].split(",")[-1])
        else:
            city = data_city
    elif country == "China":
        if match := re.match(r"^(\d{6})\s+(.+)$", city_line):
            postcode, city = match.groups()
        else:
            city = data_city
        if "Hong Kong" in data_city or "Hongkong" in city_line:
            city = "Hong Kong"
            state = "Kowloon" if "Kowloon" in " ".join(street_lines) else ""
            postcode = ""
    elif country == "Ukraine":
        if match := re.match(r"^(\d{4,5}),?\s*g\.\s+(.+)$", city_line, re.I):
            postcode, city = match.groups()
        else:
            city = data_city
        if postcode and len(re.sub(r"\D", "", postcode)) == 4:
            postcode = f"0{re.sub(r'\\D', '', postcode)}"
    elif country == "Japan":
        if match := re.match(r"^(.+?)\s+(\d{3}-?\d{4})$", city_line):
            city, postcode = match.groups()
        else:
            city = data_city
        if not state and "Chuo City" in " ".join(street_lines):
            state = "Chuo City"
    elif country == "Greece":
        if match := re.match(r"^(\d{5})\s+(.+)$", city_line):
            postcode, city = match.groups()

    city = normalize_city(city)
    state = STATE_ALIAS.get(state, normalize_city(state))

    # Route-planning URLs are a good fallback when the human-readable city line is weak.
    if not city and route_daddr:
        tail = [part.strip() for part in route_daddr.split(",") if part.strip()]
        if tail:
            city = normalize_city(tail[-1])
    if not city and not (country == "United States" and data_city.lower() == state.lower()):
        city = data_city

    return normalize_postcode(country, postcode), state, city


def infer_activity(name: str, descriptions: Iterable[str]) -> str:
    desc = normalize_space(" ".join(descriptions))
    if desc:
        return desc

    lowered = name.lower()
    if any(token in lowered for token in ("holding", "beteiligungs", "verwaltungs", "topco")):
        return "Pharmaceutical holding and corporate office"
    if any(token in lowered for token in ("logistik", "logistics")):
        return "Pharmaceutical logistics operations"
    if any(token in lowered for token in ("research", "forschungs", "entwicklung", "r&d")):
        return "Pharmaceutical research and development"
    if any(token in lowered for token in ("digital hub", "healthtech")):
        return "Digital health operations"
    if any(token in lowered for token in ("vertrieb", "distribution", "service")):
        return "Pharmaceutical sales and support operations"
    return "Pharmaceutical operations"


def build_location_address(street_lines: list[str], postcode: str, city: str, state: str, country: str) -> str:
    locality = " ".join(part for part in [postcode, city] if part).strip()
    if state and state not in locality:
        locality = f"{locality}, {state}" if locality else state
    parts = [transliterate_ascii(line.rstrip(",")) for line in street_lines]
    if locality:
        parts.append(transliterate_ascii(locality))
    parts.append(country)
    return ", ".join(part for part in parts if part)


def extract_rows() -> list[dict[str, str]]:
    response = requests.get(
        SOURCE_URL,
        headers={"User-Agent": "Mozilla/5.0"},
        timeout=30,
        verify=False,
    )
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    rows: list[dict[str, str]] = []

    for marker in soup.select(".map__location"):
        lat = normalize_space(marker.get("data-lat", ""))
        lng = normalize_space(marker.get("data-lng", ""))
        data_location = marker.get("data-location", "")

        for company in marker.select(":scope > .location__company"):
            address_block = company.select_one(".company__address")
            name_tag = address_block.find("h5") if address_block else None
            if not address_block or not name_tag:
                continue

            address_lines, descriptions = split_address_lines(address_block)
            if len(address_lines) < 2:
                continue

            route_link = company.select_one(".route-planning")
            route_daddr = extract_daddr(route_link.get("href", "") if route_link else "")

            raw_country = address_lines[-1]
            country, iso3 = COUNTRY_MAP.get(raw_country, (transliterate_ascii(raw_country), ""))
            city_line = address_lines[-2]
            street_lines = address_lines[:-2] or [address_lines[0]]

            postcode, state, city = parse_city_state_postcode(
                country=country,
                city_line=city_line,
                street_lines=street_lines,
                data_location=data_location,
                route_daddr=route_daddr,
            )
            location_address = build_location_address(street_lines, postcode, city, state, country)
            activity = transliterate_ascii(infer_activity(name_tag.get_text(" ", strip=True), descriptions))

            parsed = ParsedLocation(
                location_name=transliterate_ascii(name_tag.get_text(" ", strip=True)),
                location_address=location_address,
                latitude=lat,
                longitude=lng,
                country=country,
                country_iso3=iso3,
                postcode=transliterate_ascii(postcode),
                state=transliterate_ascii(state),
                city=transliterate_ascii(city),
                activity=activity,
            )

            rows.append(
                {
                    "ISSUER_ID": ISSUER_ID,
                    "ISSUER_NAME": ISSUER_NAME,
                    "LOCATION_NAME": parsed.location_name,
                    "LOCATION_ADDRESS": parsed.location_address,
                    "LATITUDE": parsed.latitude,
                    "LONGITUDE": parsed.longitude,
                    "COUNTRY": parsed.country,
                    "COUNTRY_ISO3": parsed.country_iso3,
                    "POSTCODE": parsed.postcode,
                    "STATE": parsed.state,
                    "CITY": parsed.city,
                    "SOURCE_URL": SOURCE_URL,
                    "SOURCE_TYPE": "COMPANY WEBSITE",
                    "ACTIVITY_AT_ASSET": parsed.activity,
                    "coord_source": "website" if lat and lng else "Not from website",
                    "QA_flag": "",
                }
            )

    return rows


def write_csv(rows: list[dict[str, str]]) -> Path:
    STAGING_DIR.mkdir(parents=True, exist_ok=True)
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    output_path = STAGING_DIR / OUTPUT_NAME
    with output_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=ADDRESS_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)
    return output_path


def main() -> None:
    rows = extract_rows()
    output_path = write_csv(rows)
    print(f"Extracted {len(rows)} rows -> {output_path}")


if __name__ == "__main__":
    main()
