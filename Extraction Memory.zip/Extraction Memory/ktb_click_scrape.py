"""
KTB Branch Scraper — Click-based Approach with Response Interception
Instead of calling the API directly, we:
1. Select each province from the dropdown
2. Click the Search button
3. Intercept the network response to capture the JSON data

This avoids the CSRF token issue entirely since the browser handles form submission naturally.

Platform: POST API with browser session (Section 3.8) — click-based variant
"""
import asyncio
import json
import re
import sys
from pathlib import Path
from playwright.async_api import async_playwright

sys.stdout.reconfigure(encoding='utf-8')

# ═══════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════
BASE_URL       = "https://krungthai.com"
LOCATION_URL   = f"{BASE_URL}/en/contact-us/ktb-location"
SERVICE_TYPES  = [1, 4]   # 1=branches, 4=business offices

TEMP_DIR       = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Temp")
RAW_JSON_PATH  = TEMP_DIR / "ktb_fresh_raw.json"
PROGRESS_PATH  = TEMP_DIR / "ktb_click_progress.json"


def clean_address(addr_html: str) -> str:
    clean = re.sub(r'<[^>]+>', ' ', addr_html)
    clean = re.sub(r'\s+', ' ', clean).strip()
    return clean.rstrip(', ').strip()


def parse_record(item: dict, service_type: int, province_name: str) -> dict:
    addr_html = item.get('Address', '')
    full_address = clean_address(addr_html)
    if 'Remark :' in full_address:
        full_address = full_address[:full_address.index('Remark :')].strip().rstrip(',').strip()

    parts = [p.strip() for p in full_address.split(',') if p.strip()]
    city = state = postal_code = ''
    if parts:
        for i in range(len(parts) - 1, -1, -1):
            if re.match(r'^\d{4,6}$', parts[i].strip()):
                postal_code = parts[i].strip()
                if i > 0:
                    state = parts[i-1].strip()
                    city = state
                break
    if not state and province_name:
        state = province_name
        city = province_name

    lat_str = item.get('STR_SERVICE_POINT_MAP_X', '').strip()
    lon_str = item.get('STR_SERVICE_POINT_MAP_Y', '').strip()
    try:
        lat = float(lat_str) if lat_str else None
        lon = float(lon_str) if lon_str else None
    except ValueError:
        lat = lon = None

    phones = item.get('lstConnectPhone', []) or []
    phone = ''
    for ph in phones:
        if not ph.get('isFax', False) and ph.get('Title'):
            phone = ph['Title']
            break

    relevant_url = f"https://maps.google.com/maps?q={lat},{lon}" if (lat and lon) else LOCATION_URL
    activity = {1: 'Banking', 4: 'Banking'}.get(service_type, 'Banking')

    bc_str = item.get('BranchCode', '')
    m = re.search(r'\d+', bc_str or '')
    branch_code = m.group(0) if m else ''

    return {
        'FACILITY_NAME': item.get('Branch', '').strip(),
        'BRANCH_CODE': branch_code,
        'FACILITY_ADDRESS': full_address,
        'CITY': city,
        'STATE': state,
        'POSTAL_CODE': postal_code,
        'FACILITY_REGION': 'Thailand',
        'LATITUDE': lat,
        'LONGITUDE': lon,
        'FACILITY_CONTACT_NUMBER': phone,
        'RELEVANT_URL': relevant_url,
        'BUSINESS_ACTIVITY': activity,
        'SERVICE_TYPE': service_type,
        '_id': item.get('INT_SERVICE_POINT_MAIN_ID'),
        '_province': province_name,
    }


def save_progress(all_records, completed_combos):
    with open(PROGRESS_PATH, 'w', encoding='utf-8') as f:
        json.dump({
            'records': all_records,
            'completed': list(list(c) for c in completed_combos)
        }, f, ensure_ascii=False, default=str)


async def main():
    TEMP_DIR.mkdir(exist_ok=True)

    # Load progress
    all_records = []
    seen_ids = set()
    completed_combos = set()
    if PROGRESS_PATH.exists():
        with open(PROGRESS_PATH, encoding='utf-8') as f:
            prog = json.load(f)
        all_records = prog.get('records', [])
        completed_combos = set(tuple(x) for x in prog.get('completed', []))
        seen_ids = {r['_id'] for r in all_records if r.get('_id')}
        print(f"Resuming: {len(all_records)} records, {len(completed_combos)} combos done")

    print("=" * 70)
    print("KTB Branch Scraper — Click-based + Response Interception")
    print("=" * 70)

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True, channel='msedge')
        context = await browser.new_context(
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0',
            extra_http_headers={'Accept-Language': 'en-US,en;q=0.9'}
        )
        page = await context.new_page()

        print(f"Loading {LOCATION_URL}...")
        await page.goto(LOCATION_URL, timeout=45000, wait_until='networkidle')
        await asyncio.sleep(3)

        # Accept cookies if banner present
        try:
            accept_btn = await page.query_selector('#onetrust-accept-btn-handler')
            if accept_btn:
                await accept_btn.click()
                await asyncio.sleep(1)
        except Exception:
            pass

        # Get province list
        provinces = await page.evaluate("""
            () => {
                const sel = document.getElementById('selectval3');
                if (!sel) return [];
                return Array.from(sel.options)
                    .filter(o => o.value && o.value !== '0' && o.value !== '')
                    .map(o => ({id: parseInt(o.value), name: o.text.trim()}));
            }
        """)
        print(f"Found {len(provinces)} provinces")

        # Get service type select (selectval1)
        service_type_options = await page.evaluate("""
            () => {
                const sel = document.getElementById('selectval1');
                if (!sel) return [];
                return Array.from(sel.options).map(o => ({value: o.value, text: o.text.trim()}));
            }
        """)
        print(f"Service type options: {service_type_options}")

        iteration = 0
        total = len(provinces) * len(SERVICE_TYPES)

        for service_type in SERVICE_TYPES:
            type_name = {1: 'Branches', 4: 'Business Offices'}.get(service_type, str(service_type))
            print(f"\n{'='*60}")
            print(f"Service Type {service_type}: {type_name}")
            print(f"{'='*60}")

            for i, prov in enumerate(provinces):
                combo_key = (prov['id'], service_type)
                if combo_key in completed_combos:
                    iteration += 1
                    continue

                prov_id = prov['id']
                prov_name = prov['name']
                iteration += 1

                # Set up response capture for this request
                api_response_data = {'data': None, 'event': asyncio.Event()}

                async def handle_response(response):
                    if 'getservicelocationresult' in response.url:
                        try:
                            body = await response.body()
                            text = body.decode('utf-8', errors='replace')
                            if text.strip().startswith('{') or text.strip().startswith('['):
                                api_response_data['data'] = json.loads(text)
                        except Exception as e:
                            api_response_data['data'] = {'error': str(e)}
                        api_response_data['event'].set()

                page.on("response", handle_response)

                try:
                    # Select service type
                    await page.select_option('#selectval1', str(service_type))
                    await asyncio.sleep(0.3)

                    # Select province
                    await page.select_option('#selectval3', str(prov_id))
                    await asyncio.sleep(0.5)

                    # Click search
                    await page.click('#btnSearch')

                    # Wait for the API response (max 10s)
                    try:
                        await asyncio.wait_for(api_response_data['event'].wait(), timeout=10)
                    except asyncio.TimeoutError:
                        pass

                finally:
                    page.remove_listener("response", handle_response)

                data = api_response_data.get('data')
                if not data or 'error' in data:
                    print(f"  [{i+1}/{len(provinces)}] {prov_name} (type={service_type}): NO DATA - {data}")
                    continue

                items = data.get('ListItems', [])
                new_count = 0
                for item in items:
                    uid = item.get('INT_SERVICE_POINT_MAIN_ID')
                    if uid and uid not in seen_ids:
                        seen_ids.add(uid)
                        record = parse_record(item, service_type, prov_name)
                        all_records.append(record)
                        new_count += 1

                completed_combos.add(combo_key)
                total_api = data.get('TotalItems', len(items))
                print(f"  [{i+1}/{len(provinces)}] {prov_name} (type={service_type}): {total_api} found, {new_count} new → total={len(all_records)}")

                # Save progress every 20 iterations
                if iteration % 20 == 0:
                    save_progress(all_records, completed_combos)
                    print(f"  [PROGRESS SAVED — {len(all_records)} records]")

                await asyncio.sleep(0.5)

        await browser.close()

    # Final save
    save_progress(all_records, completed_combos)
    with open(RAW_JSON_PATH, 'w', encoding='utf-8') as f:
        json.dump(all_records, f, ensure_ascii=False, indent=2, default=str)

    print(f"\n{'='*70}")
    print(f"SCRAPE COMPLETE")
    print(f"  Total unique records: {len(all_records)}")
    print(f"  Raw JSON: {RAW_JSON_PATH}")
    has_lat = sum(1 for r in all_records if r.get('LATITUDE'))
    print(f"  Has lat/lon: {has_lat}/{len(all_records)}")

    from collections import Counter
    by_prov = Counter(r['_province'] for r in all_records)
    print(f"\nTop provinces:")
    for prov, cnt in by_prov.most_common(15):
        print(f"    {prov}: {cnt}")


if __name__ == "__main__":
    asyncio.run(main())
