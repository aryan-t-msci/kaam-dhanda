# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Edit this block for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_ID = "IID000000002839417"
ISSUER_NAME = "IPCOM"
COMPANY_NAME = "IPCOM"
BASE_URL = "https://www.ipcom.be"
SEED_URLS = [
    "https://www.ipcom.be/our-companies",
    "https://www.ipcom.be/our-companies/isolteam",
    "https://www.ipcom.be/isobuild",
]
SITEMAP_URL = "https://www.ipcom.be/sitemap.xml"
# Company detail pages linked from the directory. Each page can carry a
# multi-value branch geofield that the parent map does not fully repeat.
FOLLOW_PATH_PREFIXES = ["/our-companies/"]
OUTPUT_DIR = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Barclays2 CQ\Assets to Add"
TEMP_DIR = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Barclays2 CQ\Assets to Add\_temp"
REQUEST_TIMEOUT = 30
# Include the sitewide headquarters block when the directory page publishes it.
INCLUDE_FOOTER_HQ = True

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════
"""Drupal Geofield Google Map extractor.

Platform: Drupal pages that render a Geofield Google Map
(``div.geofield-google-map``) and embed the marker FeatureCollection in
``drupalSettings`` (``script[data-drupal-selector=drupal-settings-json]``
→ ``geofield_google_map``).

Each feature description is Drupal address-field HTML
(``span.address-line1``, ``span.locality``, ``span.postal-code``,
``span.country``, optional ``span.organization``). Geometry coordinates
are GeoJSON order: ``[longitude, latitude]``. A multi-value geofield
repeats the same ``entity_id`` for every branch, so dedupe on
name + street + postal + city, not on entity id.

Configure the block above. The script fetches the seed pages, optionally
follows same-site links under FOLLOW_PATH_PREFIXES (and matching sitemap
URLs), and writes the standard facility CSV.
"""

import csv
import json
import re
import time
import unicodedata
from html import unescape
from pathlib import Path
from typing import Optional
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

COLUMNS = [
    "ISSUER_ID",
    "COMPANY_NAME",
    "FACILITY_NAME",
    "FACILITY_ADDRESS",
    "CITY",
    "STATE",
    "POSTAL_CODE",
    "FACILITY_REGION",
    "COUNTRY_ISO3",
    "LATITUDE",
    "LONGITUDE",
    "coord_source",
    "ACTIVITY_AT_ASSET",
    "FACILITY_CONTACT_NUMBER",
    "SCOPE",
    "SCOPE_REASON",
    "RELEVANT_URL",
    "SOURCE_TYPE",
    "VALIDATION_URL",
    "VALIDATION_SOURCE_TYPE",
    "QA_flag",
    "FACILITY_NAME_NATIVE",
    "FACILITY_ADDRESS_NATIVE",
]

# English country label as published on the site → (standard name, ISO3).
COUNTRY_MAP = {
    "austria": ("Austria", "AUT"),
    "belgium": ("Belgium", "BEL"),
    "canada": ("Canada", "CAN"),
    "croatia": ("Croatia", "HRV"),
    "czechia": ("Czechia", "CZE"),
    "czech republic": ("Czechia", "CZE"),
    "denmark": ("Denmark", "DNK"),
    "finland": ("Finland", "FIN"),
    "france": ("France", "FRA"),
    "germany": ("Germany", "DEU"),
    "greece": ("Greece", "GRC"),
    "hungary": ("Hungary", "HUN"),
    "ireland": ("Ireland", "IRL"),
    "poland": ("Poland", "POL"),
    "portugal": ("Portugal", "PRT"),
    "italy": ("Italy", "ITA"),
    "netherlands": ("Netherlands", "NLD"),
    "the netherlands": ("Netherlands", "NLD"),
    "norway": ("Norway", "NOR"),
    "romania": ("Romania", "ROU"),
    "spain": ("Spain", "ESP"),
    "sweden": ("Sweden", "SWE"),
    "switzerland": ("Switzerland", "CHE"),
    "united kingdom": (
        "United Kingdom of Great Britain and Northern Ireland (the)",
        "GBR",
    ),
    "uk": ("United Kingdom of Great Britain and Northern Ireland (the)", "GBR"),
    "great britain": (
        "United Kingdom of Great Britain and Northern Ireland (the)",
        "GBR",
    ),
}

POSTAL_PATTERNS = {
    "NLD": re.compile(r"^\d{4}\s?[A-Z]{2}$", re.I),
    "BEL": re.compile(r"^\d{4}$"),
    "AUT": re.compile(r"^\d{4}$"),
    "CHE": re.compile(r"^\d{4}$"),
    "DNK": re.compile(r"^\d{4}$"),
    "NOR": re.compile(r"^\d{4}$"),
    "HUN": re.compile(r"^\d{4}$"),
    "FRA": re.compile(r"^\d{5}$"),
    "DEU": re.compile(r"^\d{5}$"),
    "ESP": re.compile(r"^\d{5}$"),
    "ITA": re.compile(r"^\d{5}$"),
    "FIN": re.compile(r"^\d{5}$"),
    "HRV": re.compile(r"^\d{5}$"),
    "SWE": re.compile(r"^\d{3}\s?\d{2}$"),
    "GRC": re.compile(r"^\d{3}\s?\d{2}$"),
    "ROU": re.compile(r"^\d{6}$"),
    "CAN": re.compile(r"^[A-Z]\d[A-Z]\s?\d[A-Z]\d$", re.I),
    "GBR": re.compile(r"^[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}$", re.I),
    "IRL": re.compile(r"^[A-Z]\d{2}\s?[A-Z0-9]{4}$", re.I),
    "POL": re.compile(r"^\d{2}-\d{3}$"),
    "PRT": re.compile(r"^\d{4}-\d{3}$"),
    "CZE": re.compile(r"^\d{3}\s?\d{2}$"),
}

# Borough / "City of" labels that are not the city itself.
LOCALITY_TO_CITY = {
    ("anjou", "CAN"): ("Montreal", "Quebec", "Anjou"),
}

CANTONS = {
    "BE": "Bern",
    "ZH": "Zurich",
    "GE": "Geneva",
    "VD": "Vaud",
    "LU": "Lucerne",
    "BS": "Basel-Stadt",
    "BL": "Basel-Landschaft",
    "SG": "St. Gallen",
    "AG": "Aargau",
    "TI": "Ticino",
    "VS": "Valais",
    "NE": "Neuchatel",
    "ZG": "Zug",
}

PAREN_REGIONS = {
    "madrid",
    "barcelona",
    "athens",
    "vizcaya",
    "biscay",
    "attica",
    "catalonia",
    "ilfov",
}

# Locality values that are counties or regions, not towns. The town is in the street line.
UK_COUNTIES = {
    "kent",
    "cheshire",
    "tyne & wear",
    "tyne and wear",
    "essex",
    "surrey",
    "hampshire",
    "lancashire",
    "west midlands",
    "greater manchester",
    "merseyside",
    "staffordshire",
    "derbyshire",
    "nottinghamshire",
}

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
    )
}


def to_ascii(text: str) -> str:
    if not text:
        return ""
    for dash in ("\u2010", "\u2011", "\u2012", "\u2013", "\u2014", "\u2212"):
        text = text.replace(dash, "-")
    repl = {
        "ß": "ss",
        "ä": "ae",
        "ö": "oe",
        "ü": "ue",
        "Ä": "Ae",
        "Ö": "Oe",
        "Ü": "Ue",
        "æ": "ae",
        "Æ": "Ae",
        "ø": "o",
        "Ø": "O",
        "å": "a",
        "Å": "A",
        "ł": "l",
        "Ł": "L",
        "đ": "d",
        "Đ": "D",
    }
    for src, dst in repl.items():
        text = text.replace(src, dst)
    try:
        from unidecode import unidecode

        text = unidecode(text)
    except ImportError:
        text = unicodedata.normalize("NFKD", text)
        text = "".join(ch for ch in text if not unicodedata.combining(ch))
        text = text.encode("ascii", "ignore").decode("ascii")
    text = text.replace("#", " ")
    text = re.sub(r"\s+", " ", text).strip(" ,;")
    return text


def clean_ws(text: str) -> str:
    return re.sub(r"\s+", " ", unescape(text or "")).strip()


def abs_url(url: str) -> str:
    url = url.strip()
    if url.startswith("http://www.ipcom.be"):
        url = "https://www.ipcom.be" + url[len("http://www.ipcom.be") :]
    if url.startswith("/"):
        url = urljoin(BASE_URL, url)
    return url.split("#")[0].rstrip("/") or BASE_URL


def fetch(session: requests.Session, url: str) -> str:
    last_error = None
    for attempt in range(2):
        try:
            response = session.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
            response.encoding = response.encoding or "utf-8"
            return response.text
        except requests.RequestException as exc:
            last_error = exc
            time.sleep(1.5)
    raise RuntimeError(f"fetch failed {url}: {last_error}")


def drupal_settings(html: str) -> dict:
    match = re.search(
        r'<script type="application/json" data-drupal-selector="drupal-settings-json">(.*?)</script>',
        html,
    )
    if not match:
        return {}
    return json.loads(match.group(1))


def span_text(soup: BeautifulSoup, class_name: str) -> str:
    node = soup.select_one(f"span.{class_name}")
    return clean_ws(node.get_text(" ", strip=True)) if node else ""


def parse_description(html_fragment: str) -> dict:
    soup = BeautifulSoup(html_fragment or "", "html.parser")
    phone = ""
    tel = soup.select_one("a[href^='tel:']")
    if tel:
        phone = clean_ws(tel.get_text(" ", strip=True))
    alt = ""
    image = soup.find("img")
    if image and image.get("alt"):
        alt = clean_ws(image["alt"])
        alt = re.sub(r"\s+logo$", "", alt, flags=re.I).strip()
    return {
        "organization": span_text(soup, "organization"),
        "line1": span_text(soup, "address-line1"),
        "line2": span_text(soup, "address-line2"),
        "postal": span_text(soup, "postal-code"),
        "city": span_text(soup, "locality"),
        "state": span_text(soup, "administrative-area"),
        "country": span_text(soup, "country"),
        "phone": phone,
        "alt": alt,
    }


def link_text(html_fragment: str) -> str:
    soup = BeautifulSoup(html_fragment or "", "html.parser")
    anchor = soup.find("a")
    if anchor:
        return clean_ws(anchor.get_text(" ", strip=True))
    return clean_ws(soup.get_text(" ", strip=True))


def page_activity(soup: BeautifulSoup) -> str:
    labels = []
    for node in soup.select(".field--name-field-expertise .field--name-name"):
        label = clean_ws(node.get_text(" ", strip=True))
        if label and label not in labels:
            labels.append(label)
    if labels:
        return "; ".join(labels)
    banner = soup.select_one(".banner__body h4")
    if banner:
        text = clean_ws(banner.get_text(" ", strip=True))
        if text:
            return text
    teaser = soup.select_one(".banner__body p")
    if teaser:
        text = clean_ws(teaser.get_text(" ", strip=True))
        if text and len(text) < 240:
            return text
    return ""


def grid_activities(soup: BeautifulSoup) -> dict:
    """Slug → activity from the directory teaser cards."""
    found = {}
    for teaser in soup.select(".teaser"):
        anchor = teaser.select_one("h3 a[href]")
        if not anchor:
            continue
        labels = []
        for node in teaser.select(".field--name-field-expertise .field--name-name"):
            label = clean_ws(node.get_text(" ", strip=True))
            if label and label not in labels:
                labels.append(label)
        activity = "; ".join(labels)
        if not activity:
            body = teaser.select_one(".teaser__body")
            activity = clean_ws(body.get_text(" ", strip=True)) if body else ""
        found[abs_url(anchor["href"])] = activity
    return found


def iter_features(settings: dict):
    maps = settings.get("geofield_google_map") or {}
    for map_id, payload in maps.items():
        features = ((payload or {}).get("data") or {}).get("features") or []
        for feature in features:
            yield map_id, feature


def country_fields(raw_country: str) -> tuple[str, str]:
    key = clean_ws(raw_country).lower()
    if key in COUNTRY_MAP:
        return COUNTRY_MAP[key]
    if key:
        return (to_ascii(raw_country), "")
    return ("", "")


def build_address(parts: dict, region: str) -> str:
    street = ", ".join(p for p in [parts["line1"], parts["line2"]] if p)
    locality = " ".join(p for p in [parts["postal"], parts["city"]] if p)
    if parts["state"]:
        locality = f"{locality}, {parts['state']}" if locality else parts["state"]
    chunks = [street, locality, region or parts["country"]]
    address = ", ".join(chunk for chunk in chunks if chunk)
    address = address.replace("#", " ")
    address = re.sub(r"\s+", " ", address).strip(" ,")
    return address


def fmt_coord(value) -> str:
    if value is None or value == "":
        return ""
    number = float(value)
    rendered = f"{number:.7f}".rstrip("0").rstrip(".")
    return rendered


def norm_key(value: str) -> str:
    value = to_ascii(value).lower()
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def discover_urls(session: requests.Session, seed_html: dict) -> list[str]:
    urls = []
    seen = set()

    def add(url: str) -> None:
        if not url:
            return
        full = abs_url(url)
        parsed = urlparse(full)
        if parsed.netloc not in {"www.ipcom.be", "ipcom.be"}:
            return
        path = parsed.path or "/"
        if full in seen:
            return
        if any(path.startswith(prefix.rstrip("/")) or path.startswith(prefix) for prefix in FOLLOW_PATH_PREFIXES):
            # The directory itself is a seed, not a company detail page.
            if path.rstrip("/") in {"/our-companies"}:
                return
            seen.add(full)
            urls.append(full)

    for html in seed_html.values():
        soup = BeautifulSoup(html, "html.parser")
        for anchor in soup.select("a[href]"):
            add(anchor.get("href", ""))
    try:
        sitemap = fetch(session, SITEMAP_URL)
        for loc in re.findall(r"<loc>(.*?)</loc>", sitemap):
            add(loc)
    except RuntimeError as exc:
        print("sitemap skip", exc)
    return urls


def choose_name(tooltip: str, organization: str, title: str, alt: str, page_name: str) -> tuple:
    """Return (name, source). Organization beats the directory tooltip when both exist."""
    if organization:
        return organization, "organization"
    if tooltip:
        return tooltip, "tooltip"
    if title:
        return title, "title"
    if page_name:
        return page_name, "page_h1"
    if alt:
        return alt, "alt"
    return "Facility", "fallback"


def record_from_feature(
    feature: dict, page_url: str, activity: str, map_id: str, page_name: str = ""
) -> Optional[dict]:
    props = feature.get("properties") or {}
    data = props.get("data") or {}
    parsed = parse_description(props.get("description") or data.get("nothing") or "")
    title = link_text(data.get("title") or "")
    tooltip = clean_ws(props.get("tooltip") or "")
    name, name_source = choose_name(tooltip, parsed["organization"], title, parsed["alt"], page_name)
    geometry = (feature.get("geometry") or {}).get("coordinates") or []
    lon = geometry[0] if len(geometry) > 0 else ""
    lat = geometry[1] if len(geometry) > 1 else ""
    region, iso3 = country_fields(parsed["country"])
    native_address = build_address(parsed, parsed["country"])
    return {
        "name_native": name,
        "line1": parsed["line1"],
        "line2": parsed["line2"],
        "postal": parsed["postal"],
        "city_native": parsed["city"],
        "state_native": parsed["state"],
        "country_native": parsed["country"],
        "region": region,
        "iso3": iso3,
        "phone": parsed["phone"],
        "lat": lat,
        "lon": lon,
        "activity": activity,
        "page_url": page_url,
        "map_id": map_id,
        "entity_id": str(props.get("entity_id") or ""),
        "native_address": native_address,
        "detail": "/our-companies/" in urlparse(page_url).path and urlparse(page_url).path.rstrip("/") != "/our-companies",
        "name_source": name_source,
    }


def footer_hq(html: str, page_url: str) -> Optional[dict]:
    soup = BeautifulSoup(html, "html.parser")
    for block in soup.select(".field--name-body"):
        heading = block.find(["h4", "h3", "h2"])
        if not heading or "HQ" not in heading.get_text(" ", strip=True).upper():
            continue
        paragraph = block.find("p")
        if not paragraph:
            continue
        lines = [clean_ws(part) for part in paragraph.get_text("\n", strip=True).split("\n")]
        lines = [line for line in lines if line]
        if len(lines) < 2:
            continue
        street = lines[0].replace(" - ", " ")
        postal_city = lines[1]
        match = re.match(r"^(\d{4})\s+(.+)$", postal_city)
        postal = match.group(1) if match else ""
        city = match.group(2) if match else postal_city
        name = clean_ws(heading.get_text(" ", strip=True))
        return {
            "name_native": name,
            "line1": street,
            "line2": "",
            "postal": postal,
            "city_native": city,
            "state_native": "",
            "country_native": "Belgium",
            "region": "Belgium",
            "iso3": "BEL",
            "phone": "",
            "lat": "",
            "lon": "",
            "activity": "Group headquarters",
            "page_url": page_url,
            "map_id": "footer-hq",
            "entity_id": "footer-hq",
            "native_address": f"{street}, {postal_city}, Belgium",
            "detail": True,
            "name_source": "tooltip",
        }
    return None


def smart_title(text: str) -> str:
    small = {"sur", "de", "du", "la", "le", "les", "des", "of"}
    pieces = re.split(r"(\s+|-)", text.lower())
    out = []
    word_index = 0
    for piece in pieces:
        if piece in {" ", "-"} or piece.isspace():
            out.append(piece)
            continue
        if piece in small and word_index > 0:
            out.append(piece)
        else:
            out.append(piece.capitalize())
        word_index += 1
    return "".join(out)


def split_city(city: str, state: str) -> tuple:
    changed = False
    city = clean_ws(city)
    state = clean_ws(state)
    match = re.match(r"^(.+?)\s*/\s*Jud\.?\s*(.+)$", city, flags=re.I)
    if match:
        city, state = match.group(1).strip(), match.group(2).strip()
        changed = True
    match = re.match(r"^(.+?)\s*/\s*([A-Z]{2})$", city)
    if match and match.group(2) in CANTONS:
        city, state = match.group(1).strip(), CANTONS[match.group(2)]
        changed = True
    match = re.match(r"^(.+?)\s*\((.+)\)\s*$", city)
    if match:
        main, extra = match.group(1).strip(), match.group(2).strip()
        if "," in extra:
            state = extra.split(",")[-1].strip()
        elif extra.lower() in PAREN_REGIONS:
            state = extra
        city = main
        changed = True
    if "," in city and not state:
        left, right = [part.strip() for part in city.split(",", 1)]
        if left and right and not re.search(r"\d", right) and len(right) <= 40:
            city, state = left, right
            changed = True
    compact = city.upper().replace(" ", "")
    if compact in {"IVRY/SEINE", "IVRY-SUR-SEINE"}:
        city = "Ivry-sur-Seine"
        changed = True
    elif city.isupper() and re.search(r"[A-Z]", city):
        city = smart_title(city)
        changed = True
    if city.lower().startswith("city of "):
        city = city[8:].strip()
        changed = True
    return city, state, changed


def normalize_postal(postal: str, iso3: str) -> tuple:
    raw = clean_ws(postal).upper()
    original = raw
    if iso3 == "FRA":
        compact = raw.replace(" ", "")
        if re.fullmatch(r"\d{5}", compact):
            raw = compact
    elif iso3 == "CAN":
        compact = raw.replace(" ", "")
        if re.fullmatch(r"[A-Z]\d[A-Z]\d[A-Z]\d", compact):
            raw = f"{compact[:3]} {compact[3:]}"
    elif iso3 == "IRL":
        compact = raw.replace(" ", "")
        if re.fullmatch(r"[A-Z]\d{2}[A-Z0-9]{4}", compact):
            raw = f"{compact[:3]} {compact[3:]}"
    elif iso3 == "CZE":
        compact = raw.replace(" ", "")
        if re.fullmatch(r"\d{5}", compact):
            raw = f"{compact[:3]} {compact[3:]}"
    elif iso3 in {"SWE", "GRC"}:
        compact = raw.replace(" ", "")
        if re.fullmatch(r"\d{5}", compact):
            raw = f"{compact[:3]} {compact[3:]}"
    elif iso3 == "NLD":
        compact = raw.replace(" ", "")
        if re.fullmatch(r"\d{4}[A-Z]{2}", compact):
            raw = f"{compact[:4]} {compact[4:]}"
    elif iso3 == "GBR":
        compact = raw.replace(" ", "")
        if re.fullmatch(r"[A-Z]{1,2}\d[A-Z\d]?\d[A-Z]{2}", compact):
            raw = f"{compact[:-3]} {compact[-3:]}"
    return raw, raw != original


def town_from_street(line1: str) -> str:
    parts = [part.strip(" -") for part in line1.split(",") if part.strip()]
    if not parts:
        return ""
    candidate = parts[-1]
    if " - " in candidate:
        candidate = candidate.split(" - ")[-1].strip()
    road_words = ("road", "street", "lane", "way", "close", "park", "estate", "unit", "avenue", "drive")
    if any(word in candidate.lower() for word in road_words) and len(parts) > 1:
        candidate = parts[-2].strip()
        if " - " in candidate:
            candidate = candidate.split(" - ")[-1].strip()
    if any(word in candidate.lower() for word in road_words):
        return ""
    return candidate


def prepare_locality(rows: list[dict]) -> None:
    for row in rows:
        city, state, changed = split_city(row["city_native"], row["state_native"])
        county_keys = {norm_key(name) for name in UK_COUNTIES}
        if row["iso3"] == "GBR" and norm_key(city) in county_keys:
            town = ""
            line2 = row["line2"]
            road_words = ("road", "street", "lane", "way", "close", "park", "estate", "unit", "avenue", "drive")
            if " - " in line2:
                town = line2.split(" - ")[-1].strip()
                row["line2"] = line2.split(" - ")[0].strip()
            elif line2 and not any(word in line2.lower() for word in road_words):
                town = line2
                row["line2"] = ""
            if not town:
                town = town_from_street(", ".join(part for part in [row["line1"], row["line2"]] if part))
            if town:
                state = city
                city = town
                changed = True
        mapped = LOCALITY_TO_CITY.get((norm_key(city), row["iso3"]))
        if mapped:
            new_city, new_state, qualifier = mapped
            if qualifier and norm_key(qualifier) not in norm_key(row["line1"]):
                row["line2"] = ", ".join(part for part in [row["line2"], qualifier] if part)
            city, state = new_city, new_state
            changed = True
        if row["iso3"] == "CAN" and norm_key(city) == "quebec" and not state:
            state = "Quebec"
            changed = True
        postal, postal_changed = normalize_postal(row["postal"], row["iso3"])
        row["city_native"] = city
        row["state_native"] = state
        row["postal"] = postal
        row["qa_fixed"] = changed or postal_changed


LEGAL_TOKENS = re.compile(
    r"\b(gmbh|srl|spa|sl|bv|oy|kft|ltd|llc|inc|ag|as|ab|nv|sarl|sas|sa|plc|co|kg)\b"
)


def name_stem(name: str) -> str:
    stem = LEGAL_TOKENS.sub(" ", norm_key(name))
    stem = re.sub(r"\b(building supplies|headquarters|group)\b", " ", stem)
    return re.sub(r"\s+", " ", stem).strip()


def same_entity(left: str, right: str) -> bool:
    left_stem, right_stem = name_stem(left), name_stem(right)
    if not left_stem or not right_stem:
        return False
    if left_stem == right_stem or left_stem in right_stem or right_stem in left_stem:
        return True
    left_tokens = {token for token in left_stem.split() if len(token) > 2}
    right_tokens = {token for token in right_stem.split() if len(token) > 2}
    if not left_tokens or not right_tokens:
        return False
    overlap = left_tokens & right_tokens
    smaller = min(len(left_tokens), len(right_tokens))
    return bool(overlap) and (len(overlap) / smaller) >= 0.6


def prefer_row(current: dict, new: dict) -> dict:
    """Keep one facility record and fill gaps from the other."""
    left_stem, right_stem = name_stem(current["name_native"]), name_stem(new["name_native"])
    rank = {"organization": 5, "tooltip": 4, "title": 3, "page_h1": 2, "alt": 1, "fallback": 0}
    if left_stem and right_stem and left_stem != right_stem and (
        left_stem in right_stem or right_stem in left_stem
    ):
        winner = new if len(right_stem) > len(left_stem) else current
        other = current if winner is new else new
    else:
        current_score = (
            rank.get(current.get("name_source"), 0),
            len(norm_key(current["line1"])),
            len(current["name_native"]),
        )
        new_score = (
            rank.get(new.get("name_source"), 0),
            len(norm_key(new["line1"])),
            len(new["name_native"]),
        )
        winner = new if new_score > current_score else current
        other = current if winner is new else new
    if len(norm_key(other["line1"])) > len(norm_key(winner["line1"])):
        winner["line1"] = other["line1"]
        winner["native_address"] = other["native_address"] or winner["native_address"]
    if other.get("line2") and not winner.get("line2"):
        winner["line2"] = other["line2"]
    if not winner.get("phone") and other.get("phone"):
        winner["phone"] = other["phone"]
    if winner.get("lat") == "" and other.get("lat") != "":
        winner["lat"] = other["lat"]
        winner["lon"] = other["lon"]
    return winner


def collapse_duplicates(rows: list[dict]) -> list[dict]:
    """Collapse a company pin and its branch row when they are the same site."""
    kept: list[dict] = []
    for row in rows:
        merged = False
        for index, existing in enumerate(kept):
            same_url = existing["page_url"] == row["page_url"]
            addr_current = (norm_key(existing["line1"]), norm_key(existing["postal"]), norm_key(existing["city_native"]))
            addr_new = (norm_key(row["line1"]), norm_key(row["postal"]), norm_key(row["city_native"]))
            same_address = bool(addr_new[0]) and addr_current == addr_new
            same_coord = False
            if existing["lat"] != "" and row["lat"] != "":
                same_coord = (
                    round(float(existing["lat"]), 5) == round(float(row["lat"]), 5)
                    and round(float(existing["lon"]), 5) == round(float(row["lon"]), 5)
                )
            should_merge = False
            if same_address and same_url:
                should_merge = True
            elif same_address and same_entity(existing["name_native"], row["name_native"]):
                should_merge = True
            elif same_coord and same_entity(existing["name_native"], row["name_native"]):
                should_merge = True
            if should_merge:
                kept[index] = prefer_row(existing, row)
                merged = True
                break
        if not merged:
            kept.append(row)
    return kept


def disambiguate(rows: list[dict]) -> None:
    counts: dict[str, int] = {}
    for row in rows:
        counts[norm_key(row["name_native"])] = counts.get(norm_key(row["name_native"]), 0) + 1
    for row in rows:
        if counts[norm_key(row["name_native"])] < 2:
            continue
        city = row["city_native"]
        if city and norm_key(city) not in norm_key(row["name_native"]):
            row["name_native"] = f"{row['name_native']} - {city}"
    # Same name and city: append the street.
    counts2: dict[str, int] = {}
    for row in rows:
        counts2[norm_key(row["name_native"])] = counts2.get(norm_key(row["name_native"]), 0) + 1
    for row in rows:
        if counts2[norm_key(row["name_native"])] < 2:
            continue
        street = row["line1"]
        if street and norm_key(street) not in norm_key(row["name_native"]):
            row["name_native"] = f"{row['name_native']} - {street}"


def dedupe(rows: list[dict]) -> list[dict]:
    """Prefer a company-detail row over the same asset repeated on a rollup map."""
    chosen: dict[tuple, dict] = {}
    order: list[tuple] = []
    for row in rows:
        key = (
            norm_key(row["name_native"]),
            norm_key(row["line1"]),
            norm_key(row["postal"]),
            norm_key(row["city_native"]),
        )
        if key not in chosen:
            chosen[key] = row
            order.append(key)
            continue
        current = chosen[key]
        # Prefer coordinates, a detail page, a second address line, and the
        # legal organization name over a directory tooltip for the same site.
        def score(item: dict) -> tuple:
            return (
                bool(item["lat"] != ""),
                bool(item["detail"]),
                bool(item.get("line2")),
                1 if item.get("name_source") == "organization" else 0,
                bool(item.get("phone")),
            )

        if score(row) > score(current):
            chosen[key] = row
    return [chosen[key] for key in order]


def finalize(row: dict) -> tuple[dict, list[str]]:
    notes = []
    name_native = clean_ws(row["name_native"])
    city_native = clean_ws(row["city_native"])
    state_native = clean_ws(row["state_native"])
    address_native = clean_ws(row["native_address"])
    name = to_ascii(name_native)
    city = to_ascii(city_native)
    state = to_ascii(state_native)
    region = row["region"] or to_ascii(row["country_native"])
    postal = clean_ws(row["postal"]).upper()
    address = to_ascii(build_address(
        {
            "line1": row["line1"],
            "line2": row["line2"],
            "postal": postal,
            "city": city,
            "state": state,
            "country": row["country_native"],
        },
        region,
    ))
    activity = to_ascii(row["activity"]) or "Insulation and climate-control products and services"
    if not row["activity"]:
        notes.append("activity_fallback_sector")
    iso3 = row["iso3"]
    pattern = POSTAL_PATTERNS.get(iso3)
    if postal and pattern and not pattern.match(postal):
        notes.append("postal_format")
    lat = fmt_coord(row["lat"]) if row["lat"] != "" else ""
    lon = fmt_coord(row["lon"]) if row["lon"] != "" else ""
    coord_source = "website" if lat and lon else "Not from website"
    qa_parts = []
    if row.get("qa_fixed"):
        qa_parts.append("fixed")
        notes.append("locality_or_postal_normalized")
    if "activity_fallback_sector" in notes:
        qa_parts.append("ACTIVITY_AT_ASSET")
    if "postal_format" in notes:
        qa_parts.append("POSTAL_CODE")
    qa = "|".join(qa_parts)
    has_native = any(ord(ch) > 127 for ch in f"{name_native} {address_native} {city_native}")
    out = {
        "ISSUER_ID": ISSUER_ID,
        "COMPANY_NAME": COMPANY_NAME,
        "FACILITY_NAME": name,
        "FACILITY_ADDRESS": address,
        "CITY": city,
        "STATE": state,
        "POSTAL_CODE": postal,
        "FACILITY_REGION": region,
        "COUNTRY_ISO3": iso3,
        "LATITUDE": lat,
        "LONGITUDE": lon,
        "coord_source": coord_source,
        "ACTIVITY_AT_ASSET": activity,
        "FACILITY_CONTACT_NUMBER": to_ascii(row["phone"]),
        "SCOPE": "In-Scope",
        "SCOPE_REASON": (
            f"In-scope: operational site: {name} is an IPCOM group company location published on the official website"
            if row["map_id"] != "footer-hq"
            else "In-scope: operational site: IPCOM NV headquarters address published in the site footer"
        ),
        "RELEVANT_URL": row["page_url"],
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "VALIDATION_URL": "",
        "VALIDATION_SOURCE_TYPE": "",
        "QA_flag": qa,
        "FACILITY_NAME_NATIVE": name_native if has_native else "",
        "FACILITY_ADDRESS_NATIVE": address_native if has_native else "",
    }
    return out, notes


def reject_reason(row: dict) -> str:
    if not row["FACILITY_ADDRESS"] or len(row["FACILITY_ADDRESS"]) < 8:
        return "address missing or too short"
    if not row["CITY"]:
        return "city missing"
    if not row["FACILITY_REGION"] or not row["COUNTRY_ISO3"]:
        return "country missing"
    if not row["FACILITY_NAME"]:
        return "name missing"
    if re.fullmatch(r"[\d\s+\-().]+", row["FACILITY_ADDRESS"]):
        return "address is phone only"
    return ""


def main() -> None:
    temp = Path(TEMP_DIR)
    temp.mkdir(parents=True, exist_ok=True)
    output = Path(OUTPUT_DIR) / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
    session = requests.Session()
    seed_html = {}
    for url in SEED_URLS:
        print("seed", url)
        seed_html[url] = fetch(session, url)
        time.sleep(0.2)

    activities = {}
    for html in seed_html.values():
        activities.update(grid_activities(BeautifulSoup(html, "html.parser")))

    detail_urls = discover_urls(session, seed_html)
    print("detail urls", len(detail_urls))
    page_html = dict(seed_html)
    progress_path = temp / "ipcom_crawl_progress.json"
    done = []
    if progress_path.exists():
        saved = json.loads(progress_path.read_text(encoding="utf-8"))
        done = saved.get("done", [])
        for url in done:
            cache = temp / "ipcom_pages" / (re.sub(r"[^a-z0-9]+", "_", url.lower()).strip("_") + ".html")
            if cache.exists():
                page_html[url] = cache.read_text(encoding="utf-8")

    page_dir = temp / "ipcom_pages"
    page_dir.mkdir(parents=True, exist_ok=True)
    for index, url in enumerate(detail_urls, start=1):
        if url in page_html:
            continue
        print(f"page {index}/{len(detail_urls)} {url}")
        try:
            html = fetch(session, url)
        except RuntimeError as exc:
            print(" ", exc)
            continue
        page_html[url] = html
        cache = page_dir / (re.sub(r"[^a-z0-9]+", "_", url.lower()).strip("_") + ".html")
        cache.write_text(html, encoding="utf-8")
        done.append(url)
        if index % 20 == 0:
            progress_path.write_text(
                json.dumps({"done": done}, indent=2),
                encoding="utf-8",
            )
            print(" checkpoint", len(done))
        time.sleep(0.25)
    progress_path.write_text(json.dumps({"done": done}, indent=2), encoding="utf-8")

    for url, html in page_html.items():
        if url in activities and activities[url]:
            continue
        activity = page_activity(BeautifulSoup(html, "html.parser"))
        if activity:
            activities[url] = activity

    page_names = {}
    for url, html in page_html.items():
        if "/our-companies/" not in urlparse(url).path:
            continue
        heading = BeautifulSoup(html, "html.parser").select_one("h1")
        page_names[url] = clean_ws(heading.get_text(" ", strip=True)) if heading else ""

    raw_rows = []
    for url, html in page_html.items():
        settings = drupal_settings(html)
        activity = activities.get(url, "")
        # Detail pages know their own activity; rollup markers borrow the linked company page.
        for map_id, feature in iter_features(settings):
            row = record_from_feature(feature, url, activity, map_id, page_names.get(url, ""))
            if row is None:
                continue
            title_href = ""
            data = (feature.get("properties") or {}).get("data") or {}
            soup = BeautifulSoup(data.get("title") or "", "html.parser")
            anchor = soup.find("a")
            if anchor and anchor.get("href"):
                title_href = abs_url(anchor["href"])
            if not row["activity"]:
                row["activity"] = activities.get(title_href, "")
            if title_href and title_href in activities and url.rstrip("/").endswith("/our-companies"):
                row["activity"] = activities[title_href]
                row["page_url"] = title_href
                row["detail"] = True
            raw_rows.append(row)

    if INCLUDE_FOOTER_HQ:
        hq = footer_hq(seed_html[SEED_URLS[0]], SEED_URLS[0])
        if hq:
            raw_rows.append(hq)

    print("raw features", len(raw_rows))
    merged = dedupe(raw_rows)
    merged = collapse_duplicates(merged)
    prepare_locality(merged)
    disambiguate(merged)
    print("after dedupe", len(merged))

    accepted = []
    rejected = []
    qa_notes = []
    for row in merged:
        final, notes = finalize(row)
        reason = reject_reason(final)
        if reason:
            rejected.append({**final, "rejection_reason": reason})
            continue
        accepted.append(final)
        if notes or final["QA_flag"]:
            qa_notes.append({"name": final["FACILITY_NAME"], "notes": notes, "qa": final["QA_flag"], "url": final["RELEVANT_URL"]})

    with output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=COLUMNS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(accepted)

    reject_path = temp / f"{ISSUER_ID}_{ISSUER_NAME}_rejected.csv"
    if rejected:
        with reject_path.open("w", encoding="utf-8", newline="") as handle:
            fields = COLUMNS + ["rejection_reason"]
            writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rejected)
    elif reject_path.exists():
        reject_path.unlink()

    qa_path = temp / f"{ISSUER_ID}_{ISSUER_NAME}_qa.json"
    qa_path.write_text(
        json.dumps(
            {
                "raw_features": len(raw_rows),
                "deduped": len(merged),
                "accepted": len(accepted),
                "rejected": len(rejected),
                "flagged": qa_notes,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print("wrote", output, "rows", len(accepted), "rejected", len(rejected))


if __name__ == "__main__":
    main()
