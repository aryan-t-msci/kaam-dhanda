"""
Kotak Mahindra Bank Subsidiaries — Final Gap Extractor (Append Mode)
====================================================================
This script APPENDS to the existing gap CSV:

1. Kotak Securities / KotakNeo:  1,000 branches via Strapi GraphQL API
   - API: POST https://cug-cms.kotakneo.com/graphql
   - Query: branchLists_connection with pagination

2. Kotak Mahindra Prime: 43 branches (already extracted in gap CSV — verify no extras)
   Note: cityList API returns full city objects with 1 branch each = 43 unique branches

3. Kotak AMC: ISC/office locator permanently blocked by Radware WAF + hCAPTCHA
   - Cannot extract programmatically; page moved (404)
   - Already have HQ record in gap CSV

4. BSS Microfinance: Website DNS failure + no public data APIs available
   - Already have HQ record

5. Sonata Finance: Website DNS failure
   - Already have HQ record

ISSUER_ID   = IID000000002173037
ISSUER_NAME = KOTAK MAHINDRA BANK LIMITED
"""

import csv
import httpx
import sys
import re
import json
import time
from pathlib import Path
from collections import Counter

sys.stdout.reconfigure(encoding='utf-8')

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
ISSUER_ID   = "IID000000002173037"
ISSUER_NAME = "KOTAK MAHINDRA BANK LIMITED"
OUTPUT_DIR  = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Gap Output")
OUTPUT_FILE = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_Gap.csv"

COLUMNS = [
    "ISSUER_ID", "ISSUER_NAME", "FACILITY_NAME", "FACILITY_ADDRESS",
    "CITY", "STATE", "POSTAL_CODE", "FACILITY_REGION",
    "LATITUDE", "LONGITUDE", "FACILITY_CONTACT_NUMBER",
    "RELEVANT_URL", "BUSINESS_ACTIVITY"
]

HEADERS_HTTP = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Accept-Language": "en-IN,en;q=0.9",
    "Content-Type": "application/json",
}

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# ═══════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════
INDIAN_STATES = {
    'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chandigarh',
    'Chhattisgarh', 'Delhi', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh',
    'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra',
    'Meghalaya', 'Nagaland', 'Odisha', 'Puducherry', 'Punjab', 'Rajasthan',
    'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand',
    'West Bengal', 'Jammu & Kashmir', 'Jammu and Kashmir', 'Sikkim',
    'Manipur', 'Mizoram', 'Lakshadweep', 'Andaman and Nicobar Islands',
    'Dadra and Nagar Haveli', 'Daman and Diu',
}

def make_record(facility_name, facility_address, city, state, postal_code,
                region, lat, lon, contact, url, activity):
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "FACILITY_NAME": str(facility_name or '').strip(),
        "FACILITY_ADDRESS": str(facility_address or '').strip(),
        "CITY": str(city or '').strip(),
        "STATE": str(state or '').strip(),
        "POSTAL_CODE": str(postal_code or '').strip(),
        "FACILITY_REGION": str(region or '').strip(),
        "LATITUDE": str(lat or '').strip(),
        "LONGITUDE": str(lon or '').strip(),
        "FACILITY_CONTACT_NUMBER": str(contact or '').strip(),
        "RELEVANT_URL": str(url or '').strip(),
        "BUSINESS_ACTIVITY": str(activity or '').strip(),
    }

def extract_postal(text):
    m = re.search(r'\b(\d{6})\b', text)
    return m.group(1) if m else ""

def extract_state_from_address(address):
    for st in sorted(INDIAN_STATES, key=len, reverse=True):
        if st.lower() in address.lower():
            return st
    # Common abbreviations in addresses
    abbr_map = {
        'U.P.': 'Uttar Pradesh', 'UP': 'Uttar Pradesh',
        'M.P.': 'Madhya Pradesh', 'MP': 'Madhya Pradesh',
        'J&K': 'Jammu & Kashmir',
        'A.P.': 'Andhra Pradesh', 'AP': 'Andhra Pradesh',
        'W.B.': 'West Bengal', 'WB': 'West Bengal',
        'H.P.': 'Himachal Pradesh', 'HP': 'Himachal Pradesh',
        'T.N.': 'Tamil Nadu', 'TN': 'Tamil Nadu',
    }
    for abbr, full in abbr_map.items():
        if re.search(r'\b' + re.escape(abbr) + r'\b', address):
            return full
    return ""

# City → State mapping for postal lookup fallback
CITY_STATE = {
    'delhi': 'Delhi', 'new delhi': 'Delhi', 'gurugram': 'Haryana', 'gurgaon': 'Haryana',
    'noida': 'Uttar Pradesh', 'faridabad': 'Haryana', 'ghaziabad': 'Uttar Pradesh',
    'mumbai': 'Maharashtra', 'pune': 'Maharashtra', 'nagpur': 'Maharashtra',
    'nashik': 'Maharashtra', 'nasik': 'Maharashtra', 'aurangabad': 'Maharashtra',
    'navi mumbai': 'Maharashtra', 'thane': 'Maharashtra', 'kolhapur': 'Maharashtra',
    'bangalore': 'Karnataka', 'bengaluru': 'Karnataka', 'mysore': 'Karnataka',
    'mysuru': 'Karnataka', 'hubli': 'Karnataka', 'mangalore': 'Karnataka',
    'chennai': 'Tamil Nadu', 'coimbatore': 'Tamil Nadu', 'madurai': 'Tamil Nadu',
    'hyderabad': 'Telangana', 'secunderabad': 'Telangana', 'visakhapatnam': 'Andhra Pradesh',
    'vijayawada': 'Andhra Pradesh', 'kolkata': 'West Bengal', 'ahmedabad': 'Gujarat',
    'surat': 'Gujarat', 'baroda': 'Gujarat', 'vadodara': 'Gujarat', 'rajkot': 'Gujarat',
    'jaipur': 'Rajasthan', 'jodhpur': 'Rajasthan', 'udaipur': 'Rajasthan',
    'lucknow': 'Uttar Pradesh', 'kanpur': 'Uttar Pradesh', 'agra': 'Uttar Pradesh',
    'chandigarh': 'Chandigarh', 'ludhiana': 'Punjab', 'amritsar': 'Punjab',
    'indore': 'Madhya Pradesh', 'bhopal': 'Madhya Pradesh', 'jabalpur': 'Madhya Pradesh',
    'bhubaneswar': 'Odisha', 'patna': 'Bihar', 'ranchi': 'Jharkhand',
    'dehradun': 'Uttarakhand', 'kochi': 'Kerala', 'cochin': 'Kerala',
    'thiruvananthapuram': 'Kerala', 'trivandrum': 'Kerala', 'kozhikode': 'Kerala',
    'calicut': 'Kerala', 'thrissur': 'Kerala', 'kottayam': 'Kerala',
    'guwahati': 'Assam', 'raipur': 'Chhattisgarh',
    'thiruvalla': 'Kerala', 'nellore': 'Andhra Pradesh', 'kakinada': 'Andhra Pradesh',
    'rajahmundry': 'Andhra Pradesh', 'tirupati': 'Andhra Pradesh',
    'salem': 'Tamil Nadu', 'trichy': 'Tamil Nadu', 'tiruchirappalli': 'Tamil Nadu',
    'tirunelveli': 'Tamil Nadu', 'erode': 'Tamil Nadu', 'vellore': 'Tamil Nadu',
    'warangal': 'Telangana', 'nizamabad': 'Telangana',
}

def get_state_from_city(city_name):
    return CITY_STATE.get(city_name.lower().strip(), '')

# ═══════════════════════════════════════════════════════════
# PART 1: KOTAK SECURITIES via GraphQL API (cug-cms.kotakneo.com)
# ═══════════════════════════════════════════════════════════
print("=== KOTAK SECURITIES: GraphQL Extraction ===")
print("Endpoint: https://cug-cms.kotakneo.com/graphql")

GQL_ENDPOINT = "https://cug-cms.kotakneo.com/graphql"

GQL_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Content-Type": "application/json",
    "Origin": "https://www.kotakneo.com",
    "Referer": "https://www.kotakneo.com/contact-us/branch-locator/",
}

BRANCH_QUERY = """
query ($pagination: PaginationArg, $filter: BranchListFiltersInput) {
  branchLists_connection(
    pagination: $pagination
    filters: $filter
    status: PUBLISHED
    sort: "branchType:ASC"
  ) {
    pageInfo {
      total
      page
      pageSize
      pageCount
    }
    nodes {
      label
      branchType
      telephone
      email
      directionLink {
        url
      }
      address {
        metaDetails
        city {
          name
        }
      }
    }
  }
}
"""

STATE_QUERY = """
query {
  stateLists(status: PUBLISHED, pagination: {limit: -1}) {
    name
    cities (pagination: {limit:-1}) {
      name
    }
  }
}
"""

def fetch_all_kotak_securities():
    """Fetch all branches from KotakNeo GraphQL API with pagination"""
    all_branches = []
    page = 1
    page_size = 100
    total_pages = 1
    
    print(f"  Starting pagination...")
    
    while page <= total_pages:
        payload = {
            "query": BRANCH_QUERY,
            "variables": {
                "pagination": {"page": page, "pageSize": page_size},
                "filter": {}
            }
        }
        try:
            r = httpx.post(GQL_ENDPOINT, json=payload, headers=GQL_HEADERS, 
                          timeout=20, verify=False, follow_redirects=True)
            data = r.json()
            conn = data.get('data', {}).get('branchLists_connection', {})
            page_info = conn.get('pageInfo', {})
            nodes = conn.get('nodes', [])
            
            total = page_info.get('total', 0)
            total_pages = page_info.get('pageCount', 1)
            
            print(f"  Page {page}/{total_pages}: {len(nodes)} branches (total: {total})")
            all_branches.extend(nodes)
            
            page += 1
            time.sleep(0.2)
            
        except Exception as e:
            print(f"  ERROR on page {page}: {e}")
            break
    
    print(f"  Total fetched: {len(all_branches)}")
    return all_branches

# Fetch state list for state lookup
try:
    r_states = httpx.post(GQL_ENDPOINT, json={"query": STATE_QUERY},
                          headers=GQL_HEADERS, timeout=15, verify=False)
    states_data = r_states.json()
    # Build city→state mapping from GraphQL data
    city_to_state = {}
    for state_obj in states_data.get('data', {}).get('stateLists', []):
        state_name = state_obj.get('name', '').strip()
        for city_obj in state_obj.get('cities', []):
            city_name = city_obj.get('name', '').strip()
            if city_name:
                city_to_state[city_name.lower()] = state_name
    print(f"  Built city→state mapping with {len(city_to_state)} entries")
except Exception as e:
    city_to_state = {}
    print(f"  ERROR fetching states: {e}")

raw_branches = fetch_all_kotak_securities()

securities_records = []
for b in raw_branches:
    addr_obj = b.get('address') or {}
    meta = (addr_obj.get('metaDetails') or '').strip()
    city_obj = addr_obj.get('city') or {}
    city_name = (city_obj.get('name') or '').strip()
    
    phone = (b.get('telephone') or '').strip()
    branch_type = (b.get('branchType') or 'Branch').strip()
    direction_url = (b.get('directionLink') or {}).get('url', '') or ''
    
    # Get state: try GraphQL state list first, then address parsing, then city lookup
    state = city_to_state.get(city_name.lower(), '')
    if not state:
        state = extract_state_from_address(meta)
    if not state:
        state = get_state_from_city(city_name)
    
    postal = extract_postal(meta)
    
    # Determine activity based on branch type
    if branch_type == 'Branch':
        activity = "Broking - Kotak Neo/Securities Branch Office (Full Service)"
    else:
        activity = "Broking - Kotak Neo/Securities Franchise Office"
    
    # Determine Google Maps link as relevant URL
    relevant_url = direction_url if direction_url and direction_url.startswith('http') else "https://www.kotakneo.com/contact-us/branch-locator/"
    
    securities_records.append(make_record(
        f"Kotak Neo ({branch_type}) - {city_name}",
        meta,
        city_name, state, postal,
        "Asia",
        "", "",  # No lat/lon in GraphQL response
        phone,
        relevant_url,
        activity
    ))

print(f"  Processed {len(securities_records)} Kotak Securities records")

# ═══════════════════════════════════════════════════════════
# PART 2: READ EXISTING CSV AND REMOVE PLACEHOLDER HQ ROWS
# ═══════════════════════════════════════════════════════════
print("\n=== READING EXISTING GAP CSV ===")

existing_records = []
with open(OUTPUT_FILE, 'r', encoding='utf-8-sig', newline='') as f:
    reader = csv.DictReader(f)
    existing_records = list(reader)

print(f"  Existing records: {len(existing_records)}")

# Remove the placeholder Kotak Securities rows (they were HQ-only placeholders)
# and keep everything else
placeholder_names = {
    "Kotak Securities Limited - Registered Office (27BKC)",
    "Kotak Securities Limited - Corporate Office (Kotak Towers, Malad)",
}
filtered = [r for r in existing_records if r['FACILITY_NAME'] not in placeholder_names]
removed = len(existing_records) - len(filtered)
print(f"  Removed {removed} placeholder Kotak Securities HQ records (replacing with full network)")

# ═══════════════════════════════════════════════════════════
# PART 3: COMBINE AND EXPORT
# ═══════════════════════════════════════════════════════════
all_new_records = filtered + securities_records

print(f"\n=== FINAL STATISTICS ===")
print(f"  Existing records (minus placeholders): {len(filtered)}")
print(f"  Kotak Securities new records: {len(securities_records)}")
print(f"  Total: {len(all_new_records)}")

# Write output
with open(OUTPUT_FILE, 'w', newline='', encoding='utf-8-sig') as f:
    writer = csv.DictWriter(f, fieldnames=COLUMNS)
    writer.writeheader()
    writer.writerows(all_new_records)

print(f"\nExported to: {OUTPUT_FILE}")

# Summary
print("\n=== SUMMARY BY ACTIVITY ===")
counts = Counter(r['BUSINESS_ACTIVITY'].split(' - ')[0] for r in all_new_records)
for act, cnt in sorted(counts.items(), key=lambda x: -x[1]):
    print(f"  {act}: {cnt}")

print("\n=== COVERAGE STATS ===")
with_lat = [r for r in all_new_records if r['LATITUDE'] and r['LATITUDE'] not in ('', '0.0', '0')]
with_city = [r for r in all_new_records if r['CITY']]
with_state = [r for r in all_new_records if r['STATE']]
with_postal = [r for r in all_new_records if r['POSTAL_CODE']]
print(f"  With lat/lon: {len(with_lat)}/{len(all_new_records)}")
print(f"  With city: {len(with_city)}/{len(all_new_records)}")
print(f"  With state: {len(with_state)}/{len(all_new_records)}")
print(f"  With postal: {len(with_postal)}/{len(all_new_records)}")
