# Extraction Agent — Standing Instructions (prompt.md)
**Version:** 3.1 | **Last Updated:** 2026-04-11

> These instructions are **mandatory and permanent**. They apply to every extraction task
> without exception. The task prompt you receive alongside this file contains only the
> company-specific parameters — everything else is governed here.
>
> Read this file completely before reading the task prompt.

**Platform note:** If you have filesystem access, read all referenced files directly using
their paths. If not, the user will paste file contents — treat pasted content as if read
from the indicated path. All paths in this file are relative to `MEMORY_FOLDER` provided
in the task prompt. Derive all file paths as `{MEMORY_FOLDER}\{filename}` — never
hardcode any absolute path. Resolve this once at task start and proceed immediately.

---

## CONTENTS

| Section | What it covers |
|---------|---------------|
| [§1 — Memory Folder](#1--memory-folder) | What belongs, what does not |
| [§2 — KB Read Protocol](#2--kb-read-protocol-mandatory-first-step) | How to read the KB + the required KB CHECK block |
| [§3 — Script Design Rules](#3--script-design-rules) | Config blocks, naming, reuse, documentation |
| [§4 — Extraction Execution](#4--extraction-execution) | The extraction pipeline |
| [§5 — Data Standards](#5--data-standards) | Column schema, address rules, coordinates, transliteration |
| [§5f — Data Validation and QA](#5f--data-validation-and-qa) | Validators, rectification tiers, QA spot-check |
| [§6 — KB Update Protocol](#6--kb-update-protocol) | Draft → lock → permission → write; where to append |
| [§7 — File Saving Rules](#7--file-saving-rules) | Temp vs Output folder rules |
| [§8 — Execution Summary](#8--execution-summary) | Required end-of-task report format |
| [§9 — Quality Checklist](#9--quality-checklist) | Final gate before declaring complete |

---

## 1 — Memory Folder

`MEMORY_FOLDER` is provided in the task prompt. All knowledge base files, scripts, and
lock files live here. Derive every path in this file as `{MEMORY_FOLDER}\{filename}`.

**Belongs here:**
- `KB_INDEX.md` (the lookup index) and the `KB/` folder (one file per record) — the active knowledge base
- `extraction_approach_v2.md` — legacy KB, SUPERSEDED by `KB_INDEX.md` + the `KB/` shards. Do NOT read it and do NOT append to it; never load this (or any other large monolithic KB file) into context — everything you need is the index plus the specific `KB/<id>.md` records.
- All reusable / generalized extraction scripts
- Utility modules (address parsers, geocoding helpers, country mappings)

**Does NOT belong here:**
- Intermediate files, debug logs, raw HTML dumps, test scripts
- Output CSV/XLSX data files
- One-off exploration scripts with no reuse value

---

## 2 — KB Read Protocol (Mandatory First Step)

The knowledge base is an INDEX plus a folder of per-record files. Read the index, then open
ONLY the specific record files you need. NEVER read the whole knowledge base into context.

### Step 2a — Read `KB_INDEX.md` (every task, ~2 min)

This is the fast-read entry point. It contains:
- **§1 Decision Tree** — which approach to start with
- **§2 Platform Pattern Catalogue** — 26+ patterns with detection signals and scripts
- **§3 Site Record Lookup** — has this company or platform been extracted before?
- **§4 Script Inventory** — which script to reuse
- **§5 Quick-Reference Rules** — top priority rules and known time wasters

### Step 2b — Open ONLY the record files you need, from the `KB/` folder

Each platform pattern, company record, and utility is its own small file under `KB/`
(e.g. `KB/P-05.md`, `KB/R-63.md`, `KB/U-06.md`). Open only the 1–3 the index pointed you to.
- Identified a pattern? Open `KB/P-XX.md` for full implementation details.
- Company extracted before? Open `KB/R-XX.md` for approaches tried and failures.
- Need a utility function? Open `KB/U-XX.md` for the code block.

⚠️ There is no single large KB file to read. Do **not** `cat` / `Get-Content` the whole
knowledge base or any monolithic KB file — open the exact `KB/<id>.md` files the index named.
Pulling in more than the records you need wastes time and tokens on every turn, because the
context is re-sent on each step.

### Step 2c — Output the KB CHECK Block (required before any work begins)

**Before writing any code, fetching any URL, or doing any task work**, output this block.
This is not optional. It confirms the KB was read and sets your extraction strategy.

```
═══════════════════════════════════════════════════════════
KB CHECK
═══════════════════════════════════════════════════════════
Platform pattern match : [P-XX — Pattern Name]
  Reason              : [1 sentence — what signal identified this pattern]

Prior company record  : [Yes → R-XX (Company, Month Year) | No]
Prior platform record : [Yes → P-XX used for [Company] | No]

Script to reuse       : [`script_name.py` | None — will write new]
  Reason              : [why this script / why no match]

Known failures to avoid (from KB):
  ❌ [Failure 1 relevant to this pattern or company]
  ❌ [Failure 2 relevant to this pattern or company]

Extraction plan       : [2–3 sentences describing the approach]
═══════════════════════════════════════════════════════════
```

If the KB files cannot be read (file missing, path error), **stop and report immediately**.
Do not proceed without the KB.

---

## 3 — Script Design Rules

### A. Build for the Platform, Not the Company

- **DO:** Write a scraper for "AEM Sling API branch locators" or "SingleInterface store locators"
- **DON'T:** Write a scraper hardcoded to one company's CSS classes, URL paths, or field names

One generalized script should work for any issuer using the same platform pattern, with only
the config block changing.

### B. Config Block — Always at the Top

Every script saved to the Memory Folder must start with this structure:

```python
# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Edit this block for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_ID      = "IID000000000000000"
ISSUER_NAME    = "COMPANY NAME"
BASE_URL       = "https://www.example.com"
LOCATION_PATH  = "/en/locations"

# Platform-specific params (examples — adapt per pattern)
STATE_CITY_API = "/api/getStateCityList"
BRANCH_TYPES   = [2]
OUTPUT_DIR     = r"C:\...\Temp"

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════
```

### C. Reuse Existing Utility Functions

Before writing any utility, check the utility records `KB/U-*.md`:

| Need | Utility (open KB/U-XX.md) |
|------|---------------------|
| Remove CJK from mixed text | U-01 `strip_cjk()` / `is_english_text()` |
| Filter contact persons from facility data | U-02 `is_person_name()` |
| Extract `var info = [...]` from JS | U-03 `extract_json_array()` |
| Progress saving for long runs | U-04 |
| Playwright anti-bot setup | U-05 |
| Country-specific address parsers | U-06 |
| Indian pincode → state mapping | U-07 |
| Geocoding (Bing, Nominatim, GPS from Gatsby page-data) | U-08 |
| Deduplication strategies | U-09 |
| External data sources (DART, PeeringDB, CNPJ, etc.) | U-12 |
| MapMyIndia token-gated locator | U-13 |

### D. Script Naming — By Platform Pattern

```
# Wrong — company-specific names
kotak_mahindra_bank_extract.py
bajaj_nearme_extractor.py

# Correct — platform-pattern names
aem_sling_branch_extractor.py
singleinterface_store_extractor.py
static_html_rowspan_table_extractor.py
```

Exception: truly unique one-off logic → name descriptively: `post_api_province_extractor.py`.

### E. Every Saved Script Must Be Self-Documenting

Scripts saved to the Memory Folder must include:
- **Module-level docstring** — platform pattern handled, what it extracts, how to configure
  for a new issuer, usage example
- **Inline comments** on any non-obvious logic (why a selector, why a timeout value, etc.)
- **No hardcoded secrets or machine-specific paths** in the generic logic section (only in config)

### F. Full-Page Text Scraping — Elevated QA Required

Any script that uses `soup.get_text()` or equivalent full-page text extraction combined with
regex parsing (rather than targeted CSS selectors) is **high-risk for contamination** — it
captures navigation text, cookie banners, product comparison strings, and UI junk alongside
real facility data.

**Rule:** If your extraction script uses full-page text scraping, the QA spot-check threshold
for that issuer is elevated to **20% of rows minimum** (instead of the standard 10%).
Document this in the QA output block.

---

## 4 — Extraction Execution

Follow the decision tree in `KB_INDEX.md §1`. The standard pipeline:

1. **Reconnaissance** — fetch raw HTML with `httpx`/`requests`. Check page size, structure,
   technology stack. Do not launch Playwright until static/API approaches are confirmed to fail.
2. **Pattern identification** — use the decision tree and platform catalogue from KB_INDEX.md.
3. **Check prior records** — look up company and platform in KB_INDEX.md §3. Reuse the
   approach and explicitly avoid all documented ❌ failures.
4. **Data discovery** — find APIs, embedded JSON, hidden DOM content, structured data.
5. **Extract** — adjust the config block of the matching generalized script. Write a new
   script only if no template matches.
6. **Post-process** — clean, validate, apply data standards from §5, run validation and
   QA from §5f, export CSV.

**Escalate, do not settle.** Steps 4–5 are a ladder, not a single attempt. If the primary
locator/API yields far fewer facilities than the issuer plausibly operates, do not stop:
first harden locator discovery (sniff the store-finder XHR endpoint, probe common locator
paths, enumerate per-region/brand sub-locators, deep-crawl the sitemap, parse JSON-LD /
embedded JSON), then fall back to official filings and PDFs (annual-report property schedules,
10-K Item 2 Properties, 20-F PP&E, Japanese Yuho facility tables). A handful of rows for an
issuer that clearly has hundreds is a failure, not a result. The worker approach ladder in
`WORKER_PROMPT.md` (Tiers 1–5) implements this; this section is the governing policy.

**Accumulate, never replace.** The tiers are cumulative: rows from the website/locator and rows
from filings/secondary sources are ADDED into one growing set, and the final output is the
de-duplicated UNION of everything found — never just the last source worked. This matters most
for REITs / property & holding companies, whose website portfolio (often city-level) and annual
report (often street-level) are complementary; ship both, combined, not one instead of the other.

**No placeholder rows.** Every emitted row must carry a real locator — a name, an address, or
coordinates. A row with only a country/city and nothing else is padding; drop it rather than
inflate the count (this is the city-centroid failure mode we reject in vendor data).

**Two mandatory execution rules:**
- **Progress saving:** required for >50 iterations. Save state every 20 items. See U-04.
- **Timeout:** use 3–4s for pages that may have no data. Never leave the default 8s.

---

## 5 — Data Standards

These rules apply to every extraction task without exception.

### 5a — Output Column Schema

Every output CSV must contain these columns, in this order:

| Column | Mandatory | Rules |
|--------|-----------|-------|
| `ISSUER_ID` | ✅ | Constant value from task prompt — same for all rows |
| `COMPANY_NAME` | ✅ | Constant value from task prompt — same for all rows |
| `FACILITY_NAME` | ✅ | Facility name as shown on website; ASCII-transliterated. Cannot be blank — if no published name exists, derive a descriptive label from the address (e.g., `"Warehouse — Mumbai, Maharashtra"`). |
| `FACILITY_ADDRESS` | ✅ | Full address string; see §5b. Cannot be blank. |
| `CITY` | ✅ | Cannot be blank — see §5b |
| `STATE` | conditional | State / province / region |
| `POSTAL_CODE` | conditional | Country-aware format; see §5d |
| `FACILITY_REGION` | ✅ | Standardized full country name (see KB/U-10.md). Cannot be blank. (Header renamed from COUNTRY; the value is still the country name.) |
| `COUNTRY_ISO3` | ✅ | ISO 3166-1 alpha-3 code (e.g., `IND`, `GBR`, `SAU`). Cannot be blank. |
| `LATITUDE` | conditional | Numeric; blank if not on website — see §5c |
| `LONGITUDE` | conditional | Numeric; blank if not on website — see §5c |
| `coord_source` | ✅ | Exactly one of two values only: `website` or `Not from website`. No other values permitted. |
| `ACTIVITY_AT_ASSET` | ✅ | Business activity of the facility as described on the source page. **Cannot be blank.** Derive from facility name, page context, or issuer sector if not explicitly stated. |
| `FACILITY_CONTACT_NUMBER` | conditional | Facility phone/contact number if published on the source page; otherwise blank. May be blank for all rows. |
| `SCOPE` | ✅ | `In-Scope` or `Out-of-Scope`, decided per the scope methodology (default `SCOPE_METHODOLOGY.md`, or the run's override). Cannot be blank. See §5g. |
| `SCOPE_REASON` | ✅ | `<bucket phrase>: <free text>` — a controlled bucket label from the scope methodology, a colon, then a short row-specific reason (e.g. `Out-of-scope: franchise/third-party: locator marks store as franchisee-operated`). Cannot be blank. See §5g. |
| `RELEVANT_URL` | ✅ | The **first-party or second-party (official) URL that covers/mentions this asset** — the company's own site/document/report, or an official/legal/regulator/exchange filing. EVERY exported asset MUST have a 1P/2P RELEVANT_URL (see §5g). If the detail was found on a third-party page, that page goes in `VALIDATION_URL`, never here — a 3rd-party URL is never a valid RELEVANT_URL. |
| `SOURCE_TYPE` | ✅ | Type of the (official) RELEVANT_URL — first/second-party values ONLY: `COMPANY WEBSITE` (official company domain page), `COMPANY REPORT` (any `.pdf` from the company — annual/sustainability report, filing), `REGULATORY FILING` (stock-exchange filing, central-bank registry, SEC EDGAR, BSE/NSE, etc.), `SECTOR REGISTRY` (central-bank branch list, FDA facility register, telecom licence database). Use `COMPANY REPORT` for any company `.pdf` regardless of host. No third-party value exists here — third-party sources live in VALIDATION_URL / VALIDATION_SOURCE_TYPE. |
| `VALIDATION_URL` | conditional | The **third-party enrichment URL** where extra attribute detail was found (news, directory, map, professional network, job portal). Blank when no third-party source was used. A third-party source may only ENRICH an asset already covered by a 1P/2P RELEVANT_URL — it can never justify inclusion on its own. |
| `VALIDATION_SOURCE_TYPE` | conditional | Type of VALIDATION_URL, formatted `Third party - <subtype>`: e.g. `Third party - News`, `Third party - Business Directory`, `Third party - Map Service`, `Third party - Professional Network`, `Third party - Job Portal`. Blank when VALIDATION_URL is blank. |
| `QA_flag` | ✅ column | Column must be present in every output CSV. **The value may be blank** — blank `""` is correct for clean rows. See §5f for all valid values. |

**Mandatory columns (✅):** a blank value in any ✅ column is a hard validation failure
and the row must be rectified or rejected before export — **except `QA_flag`**, which uses
✅ to mean the column must always be present, not that the value must be non-blank.
Blank `""` is the correct `QA_flag` value for a clean row. See §5f.

**For foreign-language data, also add:**

| Column | Rules |
|--------|-------|
| `FACILITY_NAME_NATIVE` | Original name in native script (CJK, Arabic, Thai, etc.) |
| `FACILITY_ADDRESS_NATIVE` | Original address in native script |

Added automatically whenever source data contains non-ASCII text.

**Column consistency rules:**
- `QA_flag`, `SCOPE`, `SCOPE_REASON`, and `FACILITY_CONTACT_NUMBER` are present in every output
  CSV for every issuer, always (`FACILITY_CONTACT_NUMBER` may be blank in every row).
- `VALIDATION_URL` + `VALIDATION_SOURCE_TYPE` (as a pair) and the native columns — if any row in
  the CSV needs them, all rows have the column (blank where not applicable). Do not have the
  column present for some issuers and absent for others within the same batch.

### 5g — Source provenance, ownership, and scope (REQUIRED for every asset)

**Provenance — what may be included:**
- Every exported asset MUST be covered or mentioned by a **first-party** URL (the company's own
  website, documents, or reports) OR a **second-party** URL (official / legal / regulator /
  exchange filings). Put that official URL in `RELEVANT_URL` and its type in `SOURCE_TYPE`.
- **Third-party sources (news, business directories, maps, professional networks, job portals)
  may only ENRICH attributes** of an asset that already has a 1P/2P `RELEVANT_URL`. A third-party
  source can NEVER be the basis for including an asset. When one is used, record it in
  `VALIDATION_URL` and set `VALIDATION_SOURCE_TYPE = "Third party - <subtype>"`.
- If an asset is attested ONLY by a third-party source (no 1P/2P URL mentions it), DO NOT export
  it; note it in the run summary as dropped for "no first/second-party coverage."

**Ownership + scope — apply the scope methodology:**
- Read the scope methodology: the default is `SCOPE_METHODOLOGY.md` in this folder, UNLESS the
  task/queue provides a `SCOPE_METHODOLOGY` override (a path or URL), in which case read that.
- Apply it to every candidate asset:
  1. **Ownership (Part A):** confirm the asset belongs to the issuer (owned / operated / leased /
     controlled). DROP assets that clearly belong to an unrelated third party merely mentioned on
     the page (registrar, transfer agent, auditor, supplier, customer, or a landlord that is not
     the issuer) — do not export them; note the drop. If ownership is genuinely uncertain, KEEP
     the row and set `QA_flag = ownership_unverified`.
  2. **Scope (Part B):** tag every kept asset `SCOPE = In-Scope` or `Out-of-Scope`, and write
     `SCOPE_REASON = "<bucket phrase>: <free text>"` using the exact bucket phrases from the
     methodology. Out-of-scope assets STAY in the sheet (labelled) — they are not dropped.
- `SCOPE` and `SCOPE_REASON` are mandatory and never blank.

### 5b — Address and City Rules

- `FACILITY_ADDRESS` and `CITY` **cannot be blank**.
- `FACILITY_ADDRESS` must be **geocoding-friendly**:
  - No `#` characters
  - No phone numbers, email addresses, or opening-hours text
  - No directions text ("Take exit 3...", "Located near...", "Opposite to...")
  - Normalize whitespace; remove double spaces
- `CITY` must be the actual city name — not a road name, neighbourhood label, floor
  number, suite number, or county name.
  - For Athens branches: map neighbourhood names to "Athens"
  - For Attica entries: city = "Athens"
- Keep the full address in `FACILITY_ADDRESS` — do not truncate to street only.

### 5c — Coordinates Policy

- Populate `LATITUDE` and `LONGITUDE` **only if explicitly present on the source website**
  (HTML, JSON, map embeds, `data-lat`/`data-lng` attributes).
- **Do not geocode** to produce lat/lon unless the task prompt explicitly requests it.
- `coord_source` must be exactly `website` or `Not from website` — no other values.
- Google Maps embed coordinates count as website coordinates:
  ```python
  lon = re.search(r'2d([\d.]+)', iframe_src)
  lat = re.search(r'3d([\d.]+)', iframe_src)
  ```

### 5d — Postal Code Validation

Do not apply a single `^\d{4,6}$` regex to all countries. Key formats:

| Country | Format | Example |
|---------|--------|---------|
| Japan | 7 digits | `1008111` |
| Netherlands | `XXXX AA` | `6716 AH` |
| UK | Alphanumeric | `CV23 0WB` |
| Canada | `A1A 1A1` | `K1A 0B1` |
| Taiwan (old) | 3 digits | `202` |
| Taiwan (new) | 6 digits | `202001` |
| Poland | `XX-XXX` | `55-010` |
| Hong Kong | None | — |

Full country list in KB/U-06.md.

### 5e — Transliteration Rules

- Transliterate all output field values to ASCII/Latin characters.
- Context and meaning must be preserved — do not just strip non-ASCII characters.
- Native-script values retained in `FACILITY_NAME_NATIVE` and `FACILITY_ADDRESS_NATIVE`.
- For mixed bilingual text, use `strip_cjk()` (U-01). Never drop the entire text node.
- German umlauts: pre-replace before NFKD: `ß→ss, ä→ae, ö→oe, ü→ue`.

### 5f — Data Validation and QA

This section governs row-level validation, auto-rectification, and the mandatory QA
spot-check. It applies to every extraction task — single-issuer and batch alike.

---

#### Validation Pass (run before QA spot-check, after extraction)

Run these checks on every row before it enters the output CSV.

**Structural checks — mandatory fields (value must be non-blank):**
- `FACILITY_NAME`, `FACILITY_ADDRESS`, `FACILITY_REGION`, `COUNTRY_ISO3`, `CITY`,
  `ACTIVITY_AT_ASSET`, `RELEVANT_URL`, `SOURCE_TYPE`, `coord_source`
  must all be non-blank. Any blank value triggers rectification (see below).
- `QA_flag` must be **present as a column** but its value may be blank — blank is correct
  for clean rows. Do not trigger rectification on a blank QA_flag value.

**Enum check:**
- `coord_source` must be exactly `website` or `Not from website`.
  Any other value (blank, "geocoded", "estimated", "N/A", "Bing Maps") → rectify to
  correct value based on whether LATITUDE/LONGITUDE are populated.

**Semantic checks — flag these patterns:**

| Check | Pattern | Flag code |
|-------|---------|-----------|
| City is digits-only or starts with digits | `^\d` | `CITY_SUSPICIOUS` |
| City contains floor/suite/level/unit | "Floor", "Suite", "Level", "Unit", "#" | `CITY_SUSPICIOUS` |
| City contains PO Box | "PO Box", "P.O. Box", "GPO Box" | `CITY_SUSPICIOUS` |
| City contains time/hours patterns | "am", "pm", "Mon", "Tue", opening hours | `CITY_SUSPICIOUS` |
| City is a country name | matches FACILITY_REGION or COUNTRY_ISO3 | `CITY_IS_COUNTRY` |
| City length < 2 or > 60 chars | — | `CITY_SUSPICIOUS` |
| ACTIVITY_AT_ASSET contains UI/nav junk | "Compare", "Add to", "Shop Now", "Click here", "Menu", "Search", breadcrumb patterns | `ACTIVITY_JUNK` |
| ACTIVITY_AT_ASSET contains support/hours text | "Mon–Fri", "9am–5pm", "support", "helpdesk" | `ACTIVITY_JUNK` |
| FACILITY_ADDRESS is hours/phone only | No street component, only hours or phone text | hard reject |
| FACILITY_ADDRESS contains nav/UI text | "Compare up to", "grades", cookie consent phrases | hard reject |
| Row has no recoverable address at all | FACILITY_ADDRESS + CITY both empty/junk | hard reject |

---

#### Rectification Tiers

**Tier A — High-confidence auto-rectification (fix silently):**
Apply automatically. Set `QA_flag = "fixed"`. Log full detail in QA JSON.

| Problem | Fix |
|---------|-----|
| ACTIVITY_AT_ASSET contains UI junk | Re-derive from FACILITY_NAME, facility type keywords, or issuer sector |
| CITY contains floor/suite/level pattern | Extract actual city from FACILITY_ADDRESS context |
| CITY is a country name | Move value to FACILITY_REGION (if FACILITY_REGION is blank), derive city from address |
| FACILITY_NAME is blank | Build descriptive label: `"{type} — {city}, {state}"` |
| `coord_source` has invalid value | Correct to `website` if lat/lon populated, else `Not from website` |
| FACILITY_REGION or COUNTRY_ISO3 blank but derivable | Derive from address string or RELEVANT_URL domain |

**Tier B — Low-confidence rectification (attempt fix, flag for review):**
Attempt the fix. Set `QA_flag` to pipe-separated list of columns that need human review
(e.g., `"CITY"` or `"CITY|FACILITY_ADDRESS"`). Log full detail in QA JSON.

| Problem | Fix attempt | Flag |
|---------|-------------|------|
| CITY contains digits but may be valid (e.g., district codes) | Extract city from FACILITY_ADDRESS full context; keep best guess | `CITY` |
| FACILITY_ADDRESS has hours text mixed with real address | Strip time/hours patterns using regex; keep remainder | `FACILITY_ADDRESS` |
| ACTIVITY_AT_ASSET re-derived with low confidence | Use derived value but mark uncertain | `ACTIVITY_AT_ASSET` |
| ACTIVITY_AT_ASSET blank, no context available | Set to issuer sector as fallback (e.g., "Banking") | `ACTIVITY_AT_ASSET` |

**Tier C — Hard reject (do not include in output CSV):**
Write the row to `{ISSUER_ID}_rejected.csv` in BATCH_TEMP (or TEMP_FOLDER for single-issuer).
Log in QA JSON with rejection reason.

| Condition |
|-----------|
| FACILITY_ADDRESS is entirely hours text or phone number with no address component |
| FACILITY_ADDRESS contains navigation/UI contamination with no recoverable address |
| FACILITY_NAME, FACILITY_ADDRESS, CITY, FACILITY_REGION all blank or unresolvable |
| Row is clearly a contact/support entry with no physical facility (e.g., "Call us: Mon–Fri") |

---

#### QA Spot-Check (mandatory, runs after validation pass)

Before marking any issuer complete, inspect a sample of the output rows visually.

**Sample size rules:**
| Row count | Sample size |
|-----------|-------------|
| < 5 rows | Inspect all rows |
| 5 – 50 rows | Inspect minimum 5 rows |
| > 50 rows | Inspect minimum 10% of rows |
| Any count — soup.get_text() script used | Inspect minimum 20% of rows |

**What to check in each sampled row:**
- FACILITY_ADDRESS looks like a real physical address (has street component)
- CITY is a recognisable city name (not a floor, suite, phone number, or country name)
- ACTIVITY_AT_ASSET is a business activity, not UI text or hours
- FACILITY_NAME makes sense for the facility type
- coord_source is exactly `website` or `Not from website`
- QA_flag value is correct for the row's condition

**Output the spot-check block** (to UI for single-issuer; to QA JSON for batch):

For single-issuer runs, output to UI:
```
QA SPOT-CHECK — {ISSUER_NAME}
  Rows inspected : {N} of {TOTAL} ({PCT}%)
  Method         : [standard 10% | full sample | elevated 20% — soup.get_text() script]
  Clean rows     : {N}
  Tier A fixed   : {N}
  Tier B flagged : {N} — columns: {list}
  Tier C rejected: {N} — see {ISSUER_ID}_rejected.csv
  Result         : [PASS — proceeding | FAIL — {N} rows need review]
```

For batch runs, write this data to `batch_qa.jsonl` (see batch template §QA-REPORT for full schema).

**If spot-check finds new issues not caught by the validation pass:**
Fix them following the same tier rules, then re-run the spot-check on the affected rows
before proceeding.

---

#### QA_flag Values Reference

| Value | Meaning |
|-------|---------|
| `""` (blank) | Row is clean — no issues found or fixed |
| `"fixed"` | Row was auto-rectified at Tier A (high confidence). Detail in QA JSON. |
| `"CITY"` | Tier B: CITY was fixed with low confidence — review recommended |
| `"FACILITY_ADDRESS"` | Tier B: FACILITY_ADDRESS was fixed with low confidence |
| `"ACTIVITY_AT_ASSET"` | Tier B: ACTIVITY_AT_ASSET was re-derived with low confidence |
| `"CITY\|FACILITY_ADDRESS"` | Tier B: multiple columns need review (pipe-separated) |
| `"CITY_SUSPICIOUS"` | Semantic flag: city value failed a semantic check — not auto-fixable |
| `"CITY_IS_COUNTRY"` | Semantic flag: city value appears to be a country name |
| `"ACTIVITY_JUNK"` | Semantic flag: activity value contains UI/nav/support text |

Multiple flags are pipe-separated: `"CITY_SUSPICIOUS|ACTIVITY_JUNK"`

---

### 5g — Count Threshold and Checkpoint

> ⚠️ **COUNT IS A REFERENCE ESTIMATE, NOT A STOPPING TARGET.**
> The `COUNT` in the task prompt is only an approximate expectation of how many facilities
> the issuer may have. It is NOT a quota to hit and stop at, and NOT a cap. The real goal is
> to extract the MAXIMUM number of real, valid facilities discoverable from the provided
> sources — which may be more, fewer, or exactly COUNT.

**When COUNT is met or exceeded — DO NOT STOP. Checkpoint, then keep going:**
1. **Create a checkpoint CSV immediately** — save the rows extracted so far. This is a
   recovery safeguard: if the run is interrupted, the work to this point is preserved.
2. **Then CONTINUE to exhaustively search ALL provided sources** for as many additional
   valid facilities as exist — every page, region, category, store/branch family,
   pagination set, and sub-listing across all supplied URLs. Re-checkpoint as you find more.
3. Only stop once every applicable source is genuinely and fully exhausted — never merely
   because the number reached COUNT. Finding more than COUNT is a success; stopping at
   exactly COUNT without verifying the sources are exhausted is a failure of this rule.

**When COUNT cannot be reached:** exhaust all approaches/sources (per §1 decision tree and
the full method ladder), then provide a structured gap explanation (see §8). The exhaustion
bar is the same in both cases — above or below COUNT, you stop only when sources are spent.

- Never stop at exactly the threshold count without checking for remaining facilities.

---

## 6 — KB Update Protocol

### 6a — Draft First, Never Write Directly

After completing the extraction, prepare KB updates as a **local draft file** in the Temp folder:

```
{TEMP_FOLDER}\KB_APPEND_{ISSUER_ID}_{YYYYMMDD}.md
```

This draft contains everything to be written to the KB — the new company record (R-XX),
any new pattern (P-XX), any new script rows, and any new utility. Each record becomes its own
small file under `KB/` (e.g. `KB/R-151.md`), and `KB_INDEX.md` gets one new row per record.

Format the draft using the templates in `KB/_FRONTMATTER.md § APPENDING NEW KNOWLEDGE`.

**For issuers that already have a prior KB record (R-XX exists):**
Do not create a new duplicate record. Instead, edit the existing `KB/R-XX.md` file and append a
correction/update note inside it:
```markdown
> [!NOTE]
> **Update (YYYY-MM-DD):** Re-extracted in batch {BATCH_ID}.
> New learnings: [list any new ✅ or ❌ findings]
> Count achieved: {N} / {TARGET}
> Script used: `{script_name.py}`
```
Add any genuinely new ✅/❌ learnings that weren't in the original record. Do not repeat
existing content.

### 6b — Writing Record Files + The Index Lock

Record files are per-record, so they cannot collide: **write your new `KB/<id>.md` files
directly** (a fresh `KB/R-151.md` cannot conflict with another worker's `KB/R-150.md`). If you
are UPDATING an existing record, edit only that one `KB/<id>.md` file.

The only shared file is `KB_INDEX.md` (you add one row per new record), so the write lock
applies to it alone:

1. **Check** for `KB_WRITE.lock` in `{MEMORY_FOLDER}`.
2. **Stale lock check:** If the lock exists, read its timestamp. If older than **10 minutes**,
   treat as stale (crash recovery): log a warning, delete it, proceed to acquire a fresh lock.
3. **If a fresh lock exists:** wait 30 seconds, retry up to 10 times.
   After 10 retries: report and wait for human guidance.
4. **Acquire lock** — create `KB_WRITE.lock` with:
   ```
   LOCKED BY: {ISSUER_NAME}
   LOCKED AT: {datetime}
   ```
5. **Re-read** `KB_INDEX.md` to get the current latest version. It now contains every row
   earlier workers have committed (if worker X added a row before you locked, you will see it).
6. **Append your new index row(s) to the END of the freshly re-read content.**
   ⚠️ **CRITICAL — append, never overwrite:** add your row(s) onto the current index. Do NOT
   write a prepared copy that contains only your additions — that would erase other workers'
   rows. Always: read current → append yours → save.
7. **Write atomically:** write to `KB_INDEX.md.tmp`, then rename over the original. Rename is
   atomic, so any worker reading the index sees either the old or the new complete file.
8. **Delete** `KB_WRITE.lock` immediately after writing completes.

Your `KB/<id>.md` record files are written outside the lock (unique filenames never collide).
Never leave the lock file in place. Never skip the lock check for the index.

### 6c — Request Permission Before Writing

> **Batch runs only:** This permission gate is replaced by the auto-write protocol in
> `TASK_PROMPT_TEMPLATE_BATCH.md § BATCH-KB`. For batch tasks, follow that section instead.
> For single-issuer tasks, follow this section as written.

After creating the draft file:
1. Inform the user: *"KB draft is ready at `{path}`. May I append it to the knowledge base?"*
2. Wait for explicit approval.
3. On approval: write your `KB/<id>.md` record file(s), then add the index row(s) under the lock (§6b).

### 6d — What to Append and Where

| What you learned | File | Where |
|-----------------|------|-------|
| New company extraction record | `KB/R-XX.md` | New file (next free R number) |
| New row for site lookup table | `KB_INDEX.md` | In §3 Site Record Lookup table |
| New platform pattern | `KB/P-XX.md` | New file (next free P number) |
| New row for pattern catalogue | `KB_INDEX.md` | In §2 Platform Pattern Catalogue table |
| New reusable utility | `KB/U-XX.md` | New file (next free U number) |
| New script | `KB_INDEX.md` | In §4 Script Inventory table |
| New priority rule | `KB_INDEX.md` | In §5 Quick-Reference Rules |

**Negative learnings must be earned.** Do not record a source as barren, "showcase-only", or
exhausted-empty unless you fully worked it and it genuinely returned nothing. If the pass was
thin or ended in a gap, that means the extraction fell short — not that the source lacks data;
note what was left unfinished instead, so a later run still tries it.

### 6e — Append-Only Rule

**Never delete or modify existing KB content.** If something is wrong or outdated:
```markdown
> [!NOTE]
> **Correction (YYYY-MM-DD):** [reason]. Updated approach: [new approach].
```

Update the `Last Updated` date in the header of `KB_INDEX.md`.

---

## 7 — File Saving Rules

### Temp Folder (from task prompt: `TEMP_FOLDER`)
Save here during execution:
- All intermediate scripts written during the task
- Progress/checkpoint JSON files
- Raw HTML dumps (if saved for debugging)
- The KB draft append file (`KB_APPEND_{ISSUER_ID}_{YYYYMMDD}.md`)
- `{ISSUER_ID}_rejected.csv` — rows that failed Tier C validation
- Any test or exploration outputs

### Output Folder (from task prompt: `OUTPUT_FOLDER`)
Save here only:
- The final output CSV: `{ISSUER_ID}_{ISSUER_NAME}.csv`
- Nothing else

### Memory Folder
Save here after task completion (with permission):
- Any new generalized/reusable extraction script (see reusability rule below)
- Any new utility module

Do not save to the Memory Folder during task execution.

### Script Reusability Rule

Before finishing, classify every script written during the task:

**Category A — Reusable: save to Memory Folder**
Works for a different issuer by changing only the config block. Must always be saved.

**Category B — Refactor then save**
Has issuer-specific logic that could be parameterised. Refactor and save. If time is short,
save as-is with:
`# TODO: Parameterise [specific lines] before reusing for a different issuer.`

**Category C — Do not save**
Genuinely one-off (e.g., hardcoded gap fill unique to this company). Document reason in KB draft:
`Script not saved — hardcoded gap data specific to {ISSUER_NAME}, no reuse potential.`

**Default when in doubt: treat as Category B.**

---

## 8 — Execution Summary

At the end of every task, output this summary block before the quality checklist.

```
═══════════════════════════════════════════════════════════
EXECUTION SUMMARY
═══════════════════════════════════════════════════════════
Issuer            : {ISSUER_NAME} ({ISSUER_ID})
Final row count   : {N} rows in output CSV
Rejected rows     : {N} — see {ISSUER_ID}_rejected.csv (or "none")

QA summary        :
  Rows inspected  : {N} of {TOTAL} ({PCT}%)
  Clean           : {N}
  Tier A fixed    : {N}
  Tier B flagged  : {N}
  Tier C rejected : {N}

KB effectiveness  :
  Token usage     : [Reduced / No effect / Increased]
  Reason          : [1 sentence]
  Script reused   : [`script_name.py` | None]
  New script saved: [`script_name.py` | None]

Time breakdown    :
  Total wall time          : {X} min
  Human interaction time   : {X} min
  Autonomous execution time: {X} min

Gaps / shortfalls :
  Target count    : {N}
  Achieved count  : {N}
  Gap             : {N}
  Reason          : [What was missing and why]
  One-line summary: [Single sentence for the record]

KB draft location : {TEMP_FOLDER}\KB_APPEND_{ISSUER_ID}_{YYYYMMDD}.md
Awaiting permission to append to knowledge base.
═══════════════════════════════════════════════════════════
```

---

## 9 — Quality Checklist

Run through this before declaring the task complete. Every item must be checked off.

**KB Read and Strategy**
- [ ] Read `KB_INDEX.md` fully at task start
- [ ] Output the KB CHECK block before any work began
- [ ] Identified the correct platform pattern (P-XX)
- [ ] Checked Site Record Lookup for prior company and platform records
- [ ] Documented and avoided all relevant ❌ failures from KB

**Extraction Quality**
- [ ] URLs verified before building scripts (no 404s accepted without checking navigation)
- [ ] Raw HTML inspected before assuming JavaScript rendering was needed
- [ ] API approach tried before HTML scraping
- [ ] Existing script reused where a pattern match existed
- [ ] Progress saving implemented (if >50 iterations)
- [ ] Sources exhausted for maximum facilities (checkpointed if COUNT met, kept searching) OR gap explanation provided

**Data Validation**
- [ ] All mandatory columns non-blank: FACILITY_NAME, FACILITY_ADDRESS, FACILITY_REGION,
      COUNTRY_ISO3, CITY, ACTIVITY_AT_ASSET, RELEVANT_URL, SOURCE_TYPE, coord_source
- [ ] QA_flag column present in output CSV (blank `""` is correct for clean rows)
- [ ] No `#` characters in FACILITY_ADDRESS
- [ ] coord_source is exactly `website` or `Not from website` for every row
- [ ] Semantic validators run — city, activity, address junk checks completed
- [ ] Tier A auto-rectifications applied and logged
- [ ] Tier B flags populated in QA_flag column
- [ ] Tier C rejected rows written to `{ISSUER_ID}_rejected.csv`
- [ ] Native-language columns added wherever non-ASCII source data was present
- [ ] Postal codes validated per country format

**QA Spot-Check**
- [ ] Correct sample size used (all rows if <5; min 5 if 5-50; min 10% if >50; min 20% if soup.get_text())
- [ ] QA spot-check block output (to UI for single-issuer)
- [ ] Any issues found in spot-check were fixed and re-checked

**Files**
- [ ] Final CSV saved to `OUTPUT_FOLDER` as `{ISSUER_ID}_{ISSUER_NAME}.csv`
- [ ] `{ISSUER_ID}_rejected.csv` in TEMP_FOLDER (if any Tier C rows existed)
- [ ] No junk files saved to Memory Folder
- [ ] Every script classified as Category A, B, or C
- [ ] Category A and B scripts saved to Memory Folder
- [ ] Category C scripts: reason documented in KB draft

**KB Update**
- [ ] KB draft created at `{TEMP_FOLDER}\KB_APPEND_{ISSUER_ID}_{YYYYMMDD}.md`
- [ ] If prior R-XX record exists: correction/update note appended, not a new duplicate record
- [ ] Draft formatted using templates from `KB/_FRONTMATTER.md § APPENDING NEW KNOWLEDGE`
- [ ] Execution Summary output
- [ ] Awaiting permission to write to KB (do not write without explicit approval)
