"""
Whitbread PLC Async Extractor — uses asyncio + httpx for fast hotel detail fetching
with controlled concurrency to avoid rate limiting.
"""
import io
import sys
import os

LOG_FILE = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Temp\whitbread_log.txt"
log_fh = open(LOG_FILE, 'w', encoding='utf-8', buffering=1)

class Tee:
    def __init__(self, *streams):
        self.streams = streams
    def write(self, data):
        for s in self.streams:
            try: s.write(data); s.flush()
            except Exception: pass
    def flush(self):
        for s in self.streams:
            try: s.flush()
            except Exception: pass

sys.stdout = Tee(sys.stdout, log_fh)
sys.stderr = Tee(sys.stderr, log_fh)

print("Starting async extractor...", flush=True)

# ═══════════════════════════════════════════════════════════
ISSUER_ID   = "IID000000002129162"
ISSUER_NAME = "WHITBREAD PLC"

BASE_API_URL = "https://restapi.premierinn.com"
OUTPUT_DIR = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Temp"
FINAL_OUTPUT_DIR = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Output"

BRAND_SITEMAPS = {
    "Brewers Fayre":     "https://www.brewersfayre.co.uk/sitemap.xml",
    "Beefeater":         "https://www.beefeater.co.uk/sitemap.xml",
    "Bar+Block":         "https://www.barandblock.co.uk/sitemap.xml",
    "Cookhouse & Pub":   "https://www.cookhouseandpub.co.uk/sitemap.xml",
    "Table Table":       "https://www.tabletable.co.uk/sitemap.xml",
    "Whitbread Inns":    "https://www.whitbreadinns.co.uk/sitemap.xml",
}

CONCURRENCY = 5   # Max concurrent requests (conservative to avoid rate limiting)
PROGRESS_SAVE_EVERY = 50
# ═══════════════════════════════════════════════════════════

import asyncio
import json
import time
import re
import unicodedata
import warnings
import requests
from pathlib import Path
from bs4 import BeautifulSoup
import pandas as pd

warnings.filterwarnings('ignore')
try:
    import urllib3
    urllib3.disable_warnings()
except Exception: pass

try:
    import httpx as httpx_async
    HAS_HTTPX = True
except Exception:
    HAS_HTTPX = False

print(f"httpx available: {HAS_HTTPX}", flush=True)

HEADERS_HTML = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept': 'text/html,application/xhtml+xml,*/*',
    'Accept-Language': 'en-GB,en;q=0.9',
}
HEADERS_API = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept': 'application/json',
    'Origin': 'https://www.premierinn.com',
    'Referer': 'https://www.premierinn.com/',
}

# ─── Utilities ────────────────────────────────────────────

def to_ascii(text):
    if not text: return ""
    try:
        normalized = unicodedata.normalize('NFKD', str(text))
        ascii_text = normalized.encode('ascii', 'ignore').decode('ascii')
        return re.sub(r'\s+', ' ', ascii_text).strip()
    except Exception: return str(text)

def clean_address(addr):
    if not addr: return ""
    addr = str(addr).replace('#', '').strip()
    return re.sub(r'\s+', ' ', addr).strip(', ').strip()

def clean_phone(phone):
    if not phone: return ""
    return re.sub(r'[^\d+\s\-()]', '', str(phone)).strip()

def save_json(data, path):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def load_json(path):
    if Path(path).exists():
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return None

# ─── Async Hotel Extraction ───────────────────────────────

async def fetch_hotel_detail_async(client, code, semaphore):
    """Async fetch of hotel detail."""
    async with semaphore:
        url = f"{BASE_API_URL}/hotels/{code}"
        try:
            r = await client.get(url, headers=HEADERS_API, timeout=25)
            if r.status_code == 200:
                return code, r.json()
            else:
                return code, None
        except Exception as e:
            print(f"  WARN {code}: {type(e).__name__}", flush=True)
            return code, None

def parse_hotel_to_record(hotel_data, code, brand):
    if not hotel_data: return None
    addr = hotel_data.get('address', {})
    lines = [addr.get('addressline1',''), addr.get('addressline2',''), addr.get('addressline3','')]
    address_str = clean_address(', '.join([l for l in lines if l.strip()]))
    if not address_str: return None

    location = hotel_data.get('location', {})
    town = location.get('town', '').title()
    county = location.get('county', '').title()
    postcode = addr.get('postcode', '').strip()
    country_raw = location.get('country', '').lower()

    COUNTRY_MAP = {
        'england': 'United Kingdom', 'scotland': 'United Kingdom',
        'wales': 'United Kingdom', 'northern ireland': 'United Kingdom',
        'united kingdom (the)': 'United Kingdom', 'uk': 'United Kingdom',
        'germany': 'Germany', 'uae': 'United Arab Emirates',
        'dubai': 'United Arab Emirates', 'ireland': 'Ireland',
        'ireland (republic of)': 'Ireland', 'republic of ireland': 'Ireland',
    }
    country_region = COUNTRY_MAP.get(country_raw, 'United Kingdom')

    map_data = hotel_data.get('map', {})
    lat = str(map_data.get('latitude', '')) if map_data.get('latitude') else ''
    lng = str(map_data.get('longitude', '')) if map_data.get('longitude') else ''
    coord_source = 'Website' if lat and lng else ''

    contact = hotel_data.get('contactDetails', {})
    phone = clean_phone(contact.get('phone', '') or contact.get('hotelNationalPhone', ''))

    name = hotel_data.get('name') or hotel_data.get('title', code)
    BRAND_NAME_MAP = {'PI': 'Premier Inn', 'PID': 'Premier Inn', 'ZIP': 'ZIP by Premier Inn', 'HUB': 'Hub by Premier Inn'}
    brand_clean = BRAND_NAME_MAP.get(brand, brand)
    facility_name = f"{brand_clean} {name}".strip()

    restaurant = hotel_data.get('restaurant', {})
    rest_brand = restaurant.get('brand', '')
    rest_name = restaurant.get('name', '')
    if rest_brand:
        activity = f'Hotel with {rest_name or rest_brand} Restaurant'
    else:
        activity = 'Hotel'

    return {
        'ISSUER_ID': ISSUER_ID, 'ISSUER_NAME': ISSUER_NAME,
        'FACILITY_NAME': to_ascii(facility_name),
        'FACILITY_ADDRESS': to_ascii(address_str),
        'CITY': to_ascii(town), 'STATE': to_ascii(county),
        'POSTAL_CODE': postcode, 'FACILITY_REGION': country_region,
        'LATITUDE': lat, 'LONGITUDE': lng,
        'FACILITY_CONTACT_NUMBER': phone,
        'RELEVANT_URL': f"https://www.premierinn.com/gb/en/hotels/{code.lower()}.html",
        'ACTIVITY_AT_SOURCE': activity, 'coord_source': coord_source,
        'FACILITY_NAME_LOCAL': '', 'FACILITY_ADDRESS_LOCAL': '',
        '_source': 'Premier Inn REST API', '_code': code,
    }

async def extract_hotels_async():
    print("\n" + "="*60, flush=True)
    print("SOURCE 1: Premier Inn REST API (Async)", flush=True)
    print("="*60, flush=True)

    # Load hotel list from cache
    cached = load_json(f"{OUTPUT_DIR}\\raw_hotels.json")
    if not cached:
        print("ERROR: raw_hotels.json not found!", flush=True)
        return []
    hotels_list = cached.get('hotels', [])
    print(f"Hotel list: {len(hotels_list)} hotels", flush=True)

    # Load progress
    prog_file = f"{OUTPUT_DIR}\\hotels_progress.json"
    progress = load_json(prog_file) or {}
    done_codes = set(progress.get('done_codes', []))
    records = progress.get('records', [])
    print(f"Resuming: {len(done_codes)} done, {len(records)} records", flush=True)

    # Filter remaining codes
    remaining = [h for h in hotels_list if h['code'] not in done_codes]
    print(f"Remaining: {len(remaining)} hotels to fetch", flush=True)

    if not remaining:
        print("All hotels already fetched!", flush=True)
        return records

    # Process in batches using httpx async
    semaphore = asyncio.Semaphore(CONCURRENCY)
    batch_size = 50

    async with httpx_async.AsyncClient(verify=False, timeout=25) as client:
        for batch_start in range(0, len(remaining), batch_size):
            batch = remaining[batch_start:batch_start + batch_size]
            tasks = [fetch_hotel_detail_async(client, h['code'], semaphore) for h in batch]
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for h, result in zip(batch, results):
                code = h['code']
                brand = h.get('brand', 'PI')
                if isinstance(result, Exception):
                    print(f"  ERROR {code}: {result}", flush=True)
                    done_codes.add(code)
                    continue
                _, hotel_data = result
                if hotel_data:
                    record = parse_hotel_to_record(hotel_data, code, brand)
                    if record:
                        records.append(record)
                done_codes.add(code)
            
            # Save progress after each batch
            save_json({'done_codes': list(done_codes), 'records': records}, prog_file)
            print(f"  Batch {batch_start//batch_size + 1}: {len(done_codes)}/{len(hotels_list)} done | {len(records)} records", flush=True)
            
            # Small delay between batches
            if batch_start + batch_size < len(remaining):
                await asyncio.sleep(2)  # 2s between batches

    print(f"COMPLETE: {len(records)} hotel records", flush=True)
    return records

# ─── Sync Restaurant Extraction ───────────────────────────

def get_brand_location_urls(brand_name, sitemap_url):
    print(f"  Fetching sitemap: {brand_name}", flush=True)
    s = requests.Session()
    s.verify = False
    try:
        r = s.get(sitemap_url, headers=HEADERS_HTML, timeout=20)
        s.close()
        all_urls = re.findall(r'<loc>(.*?)</loc>', r.text)
        excluded = {'book', 'menus', 'bottomless-brunch', 'garden', 'menu',
                    'events', 'offers', 'gallery', 'rooms', 'private-dining',
                    'christmas', 'activities', 'bottomless-cocktails'}
        loc_urls = []
        for url in all_urls:
            if '/locations/' not in url: continue
            parts = [p for p in url.split('/') if p]
            if len(parts) >= 2 and parts[-1] not in excluded:
                loc_urls.append(url)
        loc_urls = list(set(loc_urls))
        print(f"    {len(loc_urls)} unique location pages", flush=True)
        return loc_urls
    except Exception as e:
        print(f"    ERROR: {e}", flush=True)
        return []

def parse_restaurant_location_page(url, brand_name):
    s = requests.Session()
    s.verify = False
    try:
        r = s.get(url, headers=HEADERS_HTML, allow_redirects=True, timeout=15)
        s.close()
        if r.status_code != 200: return None
        soup = BeautifulSoup(r.text, 'html.parser')

        name = ''
        header = soup.find('header', class_='cmp-header')
        if header:
            name = (header.get('data-lname', '') or header.get('data-ldname', '')).strip()
        if not name:
            title = soup.find('title')
            if title:
                name = title.get_text(strip=True).split('|')[0].strip().split('-')[0].strip()

        address_parts = []
        postcode = ''
        loc_details = soup.find(class_=re.compile(r'cmp-locationdetails'))
        if loc_details:
            addr_tag = loc_details.find('address')
            if addr_tag:
                addr_texts = [p.get_text(strip=True) for p in addr_tag.find_all('p') if p.get_text(strip=True)]
                for text in addr_texts:
                    if re.match(r'^[A-Z]{1,2}\d{1,2}[A-Z]?\s*\d[A-Z]{2}$', text.strip()):
                        postcode = text.strip()
                    else:
                        address_parts.append(text)

        if not address_parts and not postcode: return None
        facility_address = clean_address(', '.join(address_parts + ([postcode] if postcode else [])))
        if not facility_address: return None

        city = address_parts[-1] if address_parts else ''
        county = address_parts[-2] if len(address_parts) > 1 else ''

        phone = ''
        phone_link = soup.find('a', href=re.compile(r'^tel:'))
        if phone_link:
            phone = clean_phone(phone_link.get('href', '').replace('tel:', ''))

        lat, lng, coord_source = '', '', ''
        lat_m = re.search(r'latitude["\s:=]+(-?\d+\.\d{4,})', r.text, re.IGNORECASE)
        lng_m = re.search(r'longitude["\s:=]+(-?\d+\.\d{4,})', r.text, re.IGNORECASE)
        if lat_m and lng_m:
            lat, lng, coord_source = lat_m.group(1), lng_m.group(1), 'Website'

        BRAND_ACTIVITY = {
            'Brewers Fayre': 'Restaurant / Pub', 'Beefeater': 'Restaurant / Pub',
            'Bar+Block': 'Restaurant / Steakhouse', 'Cookhouse & Pub': 'Restaurant / Pub',
            'Table Table': 'Restaurant / Pub', 'Whitbread Inns': 'Pub / Inn',
        }
        return {
            'ISSUER_ID': ISSUER_ID, 'ISSUER_NAME': ISSUER_NAME,
            'FACILITY_NAME': to_ascii(f"{brand_name} - {name}" if name else brand_name),
            'FACILITY_ADDRESS': to_ascii(facility_address),
            'CITY': to_ascii(city), 'STATE': to_ascii(county),
            'POSTAL_CODE': postcode, 'FACILITY_REGION': 'United Kingdom',
            'LATITUDE': lat, 'LONGITUDE': lng,
            'FACILITY_CONTACT_NUMBER': phone, 'RELEVANT_URL': url,
            'ACTIVITY_AT_SOURCE': BRAND_ACTIVITY.get(brand_name, 'Restaurant'),
            'coord_source': coord_source,
            'FACILITY_NAME_LOCAL': '', 'FACILITY_ADDRESS_LOCAL': '',
            '_source': f'{brand_name} AEM Page', '_code': '',
        }
    except Exception as e:
        print(f"  ERROR {url[:50]}: {e}", flush=True)
        return None
    finally:
        try: s.close()
        except Exception: pass

def extract_restaurants():
    print("\n" + "="*60, flush=True)
    print("SOURCE 2: Restaurant Brand AEM Pages", flush=True)
    print("="*60, flush=True)

    prog_file = f"{OUTPUT_DIR}\\restaurants_progress.json"
    progress = load_json(prog_file) or {}
    done_urls = set(progress.get('done_urls', []))
    all_records = progress.get('records', [])
    print(f"Resuming: {len(done_urls)} done, {len(all_records)} records", flush=True)

    for brand_name, sitemap_url in BRAND_SITEMAPS.items():
        location_urls = get_brand_location_urls(brand_name, sitemap_url)
        brand_count = 0

        for url in location_urls:
            if url in done_urls: continue
            record = parse_restaurant_location_page(url, brand_name)
            if record:
                all_records.append(record)
                brand_count += 1
            done_urls.add(url)

            if len(done_urls) % PROGRESS_SAVE_EVERY == 0:
                save_json({'done_urls': list(done_urls), 'records': all_records}, prog_file)
                print(f"  {len(done_urls)} URLs | {len(all_records)} records", flush=True)
            time.sleep(0.3)

        print(f"  {brand_name}: {brand_count} new records", flush=True)

    save_json({'done_urls': list(done_urls), 'records': all_records}, prog_file)
    print(f"COMPLETE: {len(all_records)} restaurant records", flush=True)
    return all_records

# ─── Main ─────────────────────────────────────────────────

async def main_async():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(FINAL_OUTPUT_DIR, exist_ok=True)

    print(f"\n{'='*60}", flush=True)
    print(f"WHITBREAD PLC EXTRACTOR (Async)", flush=True)
    print(f"Issuer: {ISSUER_NAME} ({ISSUER_ID})", flush=True)
    print(f"{'='*60}", flush=True)

    # Phase 1: Hotels (async)
    hotel_records = await extract_hotels_async()

    # Phase 2: Restaurants (sync)
    restaurant_records = extract_restaurants()

    # Combine
    all_records = hotel_records + restaurant_records
    print(f"\nTotal records: {len(all_records)}", flush=True)

    # Deduplicate
    seen = set()
    deduped = []
    for r in all_records:
        key = (r.get('FACILITY_NAME','').lower().strip(), r.get('FACILITY_ADDRESS','').lower().strip())
        if key not in seen:
            seen.add(key)
            deduped.append(r)
    print(f"After dedup: {len(deduped)}", flush=True)

    # Build DataFrame
    columns = [
        'ISSUER_ID', 'ISSUER_NAME', 'FACILITY_NAME', 'FACILITY_ADDRESS',
        'CITY', 'STATE', 'POSTAL_CODE', 'FACILITY_REGION',
        'LATITUDE', 'LONGITUDE', 'FACILITY_CONTACT_NUMBER',
        'RELEVANT_URL', 'ACTIVITY_AT_SOURCE', 'coord_source',
        'FACILITY_NAME_LOCAL', 'FACILITY_ADDRESS_LOCAL',
    ]
    df = pd.DataFrame(deduped)
    for col in columns:
        if col not in df.columns: df[col] = ''
    df = df[[c for c in columns + ['_source'] if c in df.columns]]
    df = df[df['FACILITY_ADDRESS'].str.strip() != '']
    print(f"Final (valid addresses): {len(df)}", flush=True)

    # Save interim
    interim_path = f"{OUTPUT_DIR}\\whitbread_interim.csv"
    df.to_csv(interim_path, index=False, encoding='utf-8-sig')
    print(f"Interim saved: {interim_path}", flush=True)

    print("\n=== BY SOURCE ===", flush=True)
    print(df['_source'].value_counts().to_string(), flush=True)

    return df

if __name__ == '__main__':
    try:
        df = asyncio.run(main_async())
        print(f"\nDone! {len(df)} records", flush=True)
    except Exception as e:
        import traceback
        print(f"\nFATAL ERROR: {e}", flush=True)
        traceback.print_exc()
    finally:
        log_fh.close()
