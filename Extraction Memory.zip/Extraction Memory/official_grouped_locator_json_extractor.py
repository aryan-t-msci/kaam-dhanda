"""
Extract facility rows from an official bank locator JSON that groups branches and
ATMs under top-level lists.

Configure the constants below for a new issuer. The generic logic expects rows
with a nested address object containing street, city, province, postcode, and
coordinates. Usage:
    python unicaja_official_json_locator_extractor.py
"""

from __future__ import annotations

import csv
import json
import re
import unicodedata
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import requests


# ============================================================
# CONFIGURATION - Edit this block for each new issuer
# ============================================================
ISSUER_ID = "IID000000002642403"
ISSUER_NAME = "Unicaja Banco, S.A."
LOCATOR_PAGE = "https://www.unicajabanco.es/es/mapa-de-oficinas-y-cajeros"
JSON_URL = "https://www.unicaja.es/cajeofi/CajerosOficinas.json"
SOURCE_TYPE = "COMPANY WEBSITE"
COUNTRY = "Spain"
COUNTRY_ISO3 = "ESP"
OUTPUT_CSV = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Extraction_Batch_20260529_145243\staging\IID000000002642403_Unicaja Banco, S.A..csv"
)
TEMP_FOLDER = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Extraction_Batch_20260529_145243\IID000000002642403_Unicaja Banco_ S.A."
)
REJECTED_CSV = TEMP_FOLDER / f"{ISSUER_ID}_rejected.csv"
CHECKPOINT_CSV = TEMP_FOLDER / f"{ISSUER_ID}_checkpoint.csv"

TOP_LEVEL_GROUPS = {
    "Oficinas": {
        "location_type": "Branch",
        "activity": "Bank branch",
        "name_prefix": "Unicaja branch",
    },
    "Cajeros": {
        "location_type": "ATM",
        "activity": "ATM banking service",
        "name_prefix": "Unicaja ATM",
    },
}

ADDRESS_FIELDS = {
    "street": "Domicilio",
    "city": "Localidad",
    "state": "Provincia",
    "postcode": "CodigoPostal",
    "coordinates": "Coordenadas",
    "lat": "Latitud",
    "lon": "Longitud",
}

OUTPUT_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
]


# ============================================================
# GENERIC EXTRACTION LOGIC - Do not modify per-issuer
# ============================================================
def ascii_clean(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    text = text.replace("ß", "ss").replace("ä", "ae").replace("ö", "oe").replace("ü", "ue")
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def clean_address(*parts: Any) -> str:
    text = ", ".join(ascii_clean(part) for part in parts if ascii_clean(part))
    text = text.replace("#", "")
    text = re.sub(r"\b(?:Tel|Telefono|Phone)\.?:?\s*[\d +().-]+", "", text, flags=re.I)
    text = re.sub(r"\s*,\s*", ", ", text)
    text = re.sub(r"(,\s*){2,}", ", ", text)
    return text.strip(" ,")


def decimal_string(value: Any) -> str:
    text = ascii_clean(value)
    if not text:
        return ""
    try:
        return f"{float(text):.10f}".rstrip("0").rstrip(".")
    except ValueError:
        return ""


def row_key(row: dict[str, str]) -> tuple[str, str, str]:
    return (
        row["_SOURCE_GROUP"],
        row["_SOURCE_ID"],
        row["_SOURCE_CODE"],
    )


@dataclass
class QaResult:
    inspected: int
    total: int
    clean: int
    tier_a_fixed: int
    tier_b_flagged: int
    tier_c_rejected: int
    fixes: list[dict[str, Any]]
    rejected: list[dict[str, Any]]


def build_row(group_name: str, item: dict[str, Any]) -> dict[str, str]:
    group = TOP_LEVEL_GROUPS[group_name]
    address = item.get("Direccion") or {}
    coords = address.get(ADDRESS_FIELDS["coordinates"]) or {}

    street = ascii_clean(address.get(ADDRESS_FIELDS["street"]))
    city = ascii_clean(address.get(ADDRESS_FIELDS["city"]))
    state = ascii_clean(address.get(ADDRESS_FIELDS["state"]))
    postcode = ascii_clean(address.get(ADDRESS_FIELDS["postcode"]))
    lat = decimal_string(coords.get(ADDRESS_FIELDS["lat"]))
    lon = decimal_string(coords.get(ADDRESS_FIELDS["lon"]))

    source_name = ascii_clean(item.get("Nombre"))
    branch_id = ascii_clean(item.get("IdSucursal"))
    terminal_code = ascii_clean(item.get("Codigo"))
    code = " ".join(part for part in [branch_id, terminal_code] if part)
    if source_name:
        location_name = f"{group['name_prefix']} {code} - {source_name}" if code else f"{group['name_prefix']} - {source_name}"
    elif city and street:
        location_name = f"{group['name_prefix']} {code} - {city}, {street}" if code else f"{group['name_prefix']} - {city}, {street}"
    elif city:
        location_name = f"{group['name_prefix']} {code} - {city}" if code else f"{group['name_prefix']} - {city}"
    else:
        location_name = f"{group['name_prefix']} - {code}"

    return {
        "_SOURCE_GROUP": group_name,
        "_SOURCE_ID": branch_id or f"{city}|{street}|{lat}|{lon}",
        "_SOURCE_CODE": terminal_code,
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": ascii_clean(location_name),
        "LOCATION_ADDRESS": clean_address(street, postcode, city, state, COUNTRY),
        "LATITUDE": lat,
        "LONGITUDE": lon,
        "COUNTRY": COUNTRY,
        "COUNTRY_ISO3": COUNTRY_ISO3,
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": JSON_URL,
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": group["activity"],
        "coord_source": "website" if lat and lon else "Not from website",
        "QA_flag": "",
    }


def validate_rows(rows: list[dict[str, str]]) -> QaResult:
    mandatory = [
        "LOCATION_NAME",
        "LOCATION_ADDRESS",
        "COUNTRY",
        "COUNTRY_ISO3",
        "CITY",
        "ACTIVITY_AT_ASSET",
        "SOURCE_URL",
        "SOURCE_TYPE",
        "coord_source",
    ]
    fixes: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []

    for row in rows:
        row["LOCATION_ADDRESS"] = clean_address(row["LOCATION_ADDRESS"])
        if row["coord_source"] not in {"website", "Not from website"}:
            row["coord_source"] = "website" if row["LATITUDE"] and row["LONGITUDE"] else "Not from website"
            row["QA_flag"] = "fixed"
            fixes.append({"row": row["LOCATION_NAME"], "field": "coord_source"})

        if re.match(r"^\d", row["CITY"]) or len(row["CITY"]) < 2:
            row["QA_flag"] = "CITY_SUSPICIOUS"

        if not all(row.get(col, "").strip() for col in mandatory):
            rejected.append({"row": row, "reason": "mandatory field blank"})

    # Standard 10% spot-check; for deterministic batch QA inspect evenly spaced rows.
    total = len(rows)
    sample_size = max(5, int(total * 0.10 + 0.999)) if total > 50 else min(total, 5)
    if total:
        step = max(1, total // sample_size)
        sample = rows[0:total:step][:sample_size]
    else:
        sample = []

    spot_issues = 0
    for row in sample:
        address_ok = bool(re.search(r"\d|CALLE|AV|PLAZA|PASEO|CARRETERA|CL|C/", row["LOCATION_ADDRESS"], re.I))
        city_ok = bool(row["CITY"]) and not re.match(r"^\d", row["CITY"])
        activity_ok = row["ACTIVITY_AT_ASSET"] in {"Bank branch", "ATM banking service"}
        coord_ok = row["coord_source"] in {"website", "Not from website"}
        if not (address_ok and city_ok and activity_ok and coord_ok):
            spot_issues += 1
            if not row["QA_flag"]:
                row["QA_flag"] = "LOCATION_ADDRESS" if not address_ok else "CITY"

    return QaResult(
        inspected=len(sample),
        total=total,
        clean=sum(1 for row in sample if not row["QA_flag"]),
        tier_a_fixed=sum(1 for row in rows if row["QA_flag"] == "fixed"),
        tier_b_flagged=sum(1 for row in rows if row["QA_flag"] not in {"", "fixed"}),
        tier_c_rejected=len(rejected),
        fixes=fixes + ([{"spot_check_issues": spot_issues}] if spot_issues else []),
        rejected=rejected,
    )


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=OUTPUT_COLUMNS)
        writer.writeheader()
        writer.writerows([{col: row.get(col, "") for col in OUTPUT_COLUMNS} for row in rows])


def main() -> None:
    TEMP_FOLDER.mkdir(parents=True, exist_ok=True)
    session = requests.Session()
    response = session.get(
        JSON_URL,
        headers={"User-Agent": "Mozilla/5.0", "Referer": LOCATOR_PAGE},
        timeout=60,
    )
    response.raise_for_status()
    data = response.json()

    rows: list[dict[str, str]] = []
    for group_name in TOP_LEVEL_GROUPS:
        for item in data.get(group_name, []):
            rows.append(build_row(group_name, item))

    deduped: list[dict[str, str]] = []
    seen: set[tuple[str, str, str]] = set()
    for row in rows:
        key = row_key(row)
        if key not in seen:
            seen.add(key)
            deduped.append(row)

    if len(deduped) >= 3450:
        write_csv(CHECKPOINT_CSV, deduped)

    qa = validate_rows(deduped)
    rejected_rows = [entry["row"] for entry in qa.rejected]
    final_rows = [row for row in deduped if row not in rejected_rows]

    write_csv(OUTPUT_CSV, final_rows)
    if rejected_rows:
        write_csv(REJECTED_CSV, rejected_rows)

    qa_payload = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source_url": JSON_URL,
        "raw_counts": {key: len(data.get(key, [])) for key in TOP_LEVEL_GROUPS},
        "rows_before_dedupe": len(rows),
        "rows_after_dedupe": len(deduped),
        "rows_written": len(final_rows),
        "qa": qa.__dict__,
    }
    (TEMP_FOLDER / f"{ISSUER_ID}_qa_details.json").write_text(
        json.dumps(qa_payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(qa_payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
