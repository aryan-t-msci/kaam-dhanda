"""
static_html_country_panel_contact_extractor.py
==============================================

Generic extractor for corporate "global distributors / contact us" pages that
publish address-bearing location blocks in static HTML country panels plus
simple supporting contact pages.

Platform Pattern:
- Static HTML country/distributor accordion panels (`div.panel.panel-default`)
- Repeated contact blocks composed of plain `<p>` tags rather than a clean card
  model, often with inconsistent field labels (`Tel`, `Te l`, `E-mail`, etc.)
- Supplemental contact pages with simple structured lists

Configured for:
- Gree Electric Appliances, Inc. of Zhuhai
- Global distributors directory + Canada contact page + Zhuhai contact page

Usage:
    python static_html_country_panel_contact_extractor.py
"""

from __future__ import annotations

import csv
import io
import json
import re
import sys
import time
import unicodedata
from collections import defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import pycountry
import requests
import urllib3
from bs4 import BeautifulSoup
from unidecode import unidecode

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

# =============================================================================
# CONFIGURATION - Change these for each new issuer
# =============================================================================

ISSUER_ID = "IID000000002168285"
ISSUER_NAME = "Gree Electric Appliances, Inc. of Zhuhai"
SOURCE_TYPE = "COMPANY WEBSITE"

GLOBAL_DISTRIBUTOR_URL = "https://global.gree.com/channels/140.html"
USA_SELECTOR_URL = "https://global.gree.com/usa/channels/782.html"
CANADA_CONTACT_URL = "https://www.gree.ca/pages/contact-us"
HQ_CONTACT_URL = "https://global.gree.com/usa/channels/770.html#Contact%20Us"

WORK_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")

FINAL_CSV = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
CHECKPOINT_CSV = WORK_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_checkpoint.csv"
PROGRESS_JSON = WORK_DIR / f"{ISSUER_ID}_progress.json"
RAW_RECORDS_JSON = WORK_DIR / f"{ISSUER_ID}_raw_records.json"
GEOCODE_CACHE_JSON = WORK_DIR / f"{ISSUER_ID}_geocode_cache.json"
SUMMARY_JSON = WORK_DIR / f"{ISSUER_ID}_run_summary.json"
MEMORY_DRAFT_MD = WORK_DIR / f"{ISSUER_ID}_extraction_memory_note.md"

CHECKPOINT_THRESHOLD = 60
PROGRESS_EVERY = 20
HTTP_TIMEOUT = 30
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
NOMINATIM_SLEEP_SECONDS = 1.0

FIELD_ORDER = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "coord_source",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS_NATIVE",
]

ASCII_PUNCT_MAP = str.maketrans(
    {
        "【": "[",
        "】": "]",
        "（": "(",
        "）": ")",
        "：": ":",
        "，": ",",
        "、": ",",
        "；": ";",
        "“": '"',
        "”": '"',
        "‘": "'",
        "’": "'",
        "–": "-",
        "—": "-",
        "‐": "-",
        "−": "-",
        "·": ".",
        "°": " degrees ",
        "\u00A0": " ",
    }
)

COUNTRY_ALIASES = {
    "usa": "United States",
    "u.s.a": "United States",
    "us": "United States",
    "u.s.": "United States",
    "uk": "United Kingdom",
    "u.k.": "United Kingdom",
    "uae": "United Arab Emirates",
    "viet nam": "Vietnam",
    "lao peoples democratic republic": "Laos",
    "kingdom of cambodia": "Cambodia",
    "slovak republic": "Slovakia",
    "ivory coast": "Cote d'Ivoire",
    "st.maarten": "Sint Maarten",
    "st maarten": "Sint Maarten",
    "bahrein islands tosot": "Bahrain",
    "macedonia": "North Macedonia",
    "palestine": "Palestine",
    "curacao": "Curacao",
    "timor lester": "Timor-Leste",
    "timor-lester": "Timor-Leste",
    "democratic republic of timor-leste": "Timor-Leste",
    "tahiti": "French Polynesia",
}

PYCOUNTRY_FALLBACKS = {
    "United States": "USA",
    "United Kingdom": "GBR",
    "United Arab Emirates": "ARE",
    "Vietnam": "VNM",
    "Laos": "LAO",
    "Cambodia": "KHM",
    "Slovakia": "SVK",
    "Cote d'Ivoire": "CIV",
    "Sint Maarten": "SXM",
    "Bahrain": "BHR",
    "North Macedonia": "MKD",
    "Palestine": "PSE",
    "Curacao": "CUW",
    "Timor-Leste": "TLS",
    "French Polynesia": "PYF",
    "Hong Kong": "HKG",
    "Macao": "MAC",
    "Taiwan": "TWN",
}

STOPWORDS = {
    "gree",
    "tosot",
    "the",
    "and",
    "for",
    "of",
    "co",
    "company",
    "corp",
    "corporation",
    "inc",
    "limited",
    "ltd",
    "llc",
    "wll",
    "pty",
    "sa",
    "sarl",
    "spa",
    "srl",
    "doo",
    "kft",
    "bv",
    "pte",
    "private",
    "general",
    "trading",
    "electric",
    "appliances",
    "products",
    "office",
    "distribution",
    "center",
    "centre",
    "distributor",
    "building",
    "supply",
    "group",
}

MANUAL_OVERRIDES: dict[str, dict[str, str]] = {
    "jianbuzhaiwangguojinbianshimoniwangdadao783d": {
        "LOCATION_ADDRESS": "Monivong Boulevard 783D, Phnom Penh, Cambodia",
        "COUNTRY": "Cambodia",
        "COUNTRY_ISO3": "KHM",
        "STATE": "Phnom Penh",
        "CITY": "Phnom Penh",
        "POSTCODE": "",
    },
    "3122bernardpilonstmathieudebeloeilquebecj3g4s5canada": {
        "LOCATION_ADDRESS": "3122 Rue Bernard-Pilon, Saint-Mathieu-de-Beloeil, Quebec J3G 4S5, Canada",
        "COUNTRY": "Canada",
        "COUNTRY_ISO3": "CAN",
        "STATE": "Quebec",
        "CITY": "Saint-Mathieu-de-Beloeil",
        "POSTCODE": "J3G 4S5",
    },
    "3122ruebernardpilonsaintmathieudebeloeilquebecj3g4s5canada": {
        "LOCATION_ADDRESS": "3122 Rue Bernard-Pilon, Saint-Mathieu-de-Beloeil, Quebec J3G 4S5, Canada",
        "COUNTRY": "Canada",
        "COUNTRY_ISO3": "CAN",
        "STATE": "Quebec",
        "CITY": "Saint-Mathieu-de-Beloeil",
        "POSTCODE": "J3G 4S5",
    },
    "avenida3eranillointernoesquinaavlasallenrobolivia": {
        "LOCATION_ADDRESS": "3er Anillo Interno esquina Av. La Salle, Santa Cruz de la Sierra, Santa Cruz, Bolivia",
        "COUNTRY": "Bolivia",
        "COUNTRY_ISO3": "BOL",
        "STATE": "Santa Cruz",
        "CITY": "Santa Cruz de la Sierra",
        "POSTCODE": "",
    },
    "88cheminvicinaldepatutoabp1728pappetetahiti98713frenchpolinesia": {
        "LOCATION_ADDRESS": "88 Chemin Vicinal de Patutoa, BP 1728, Papeete, Tahiti 98713, French Polynesia",
        "COUNTRY": "French Polynesia",
        "COUNTRY_ISO3": "PYF",
        "STATE": "French Polynesia",
        "CITY": "Papeete",
        "POSTCODE": "98713",
    },
    "landmarkpluittowerbunit1lt5jlpluitselatanrayajakartautara14450": {
        "LOCATION_ADDRESS": "Landmark Pluit Tower B Unit 1 Lt. 5, Jl. Pluit Selatan Raya, Jakarta Utara 14450, Indonesia",
        "COUNTRY": "Indonesia",
        "COUNTRY_ISO3": "IDN",
        "STATE": "Jakarta",
        "CITY": "North Jakarta",
        "POSTCODE": "14450",
    },
    "163greenbuildingkingabdallah2street": {
        "LOCATION_ADDRESS": "163 Green Building, King Abdallah II Street, Amman, Jordan",
        "COUNTRY": "Jordan",
        "COUNTRY_ISO3": "JOR",
        "STATE": "Amman",
        "CITY": "Amman",
        "POSTCODE": "",
    },
    "991alexandaroad0102asingapore119964": {
        "LOCATION_ADDRESS": "991 Alexandra Road, 01-02A, Singapore 119964",
        "COUNTRY": "Singapore",
        "COUNTRY_ISO3": "SGP",
        "STATE": "Singapore",
        "CITY": "Singapore",
        "POSTCODE": "119964",
    },
    "plot109ntindaroadpobox27287kampalauganda": {
        "LOCATION_ADDRESS": "Plot 109 Ntinda Road, PO Box 27287, Kampala, Uganda",
        "COUNTRY": "Uganda",
        "COUNTRY_ISO3": "UGA",
        "STATE": "Kampala",
        "CITY": "Kampala",
        "POSTCODE": "",
    },
    "westjinjirdqianshanzhuhai519070": {
        "LOCATION_ADDRESS": "West Jinji Rd, Qianshan, Zhuhai, Guangdong 519070, China",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "STATE": "Guangdong",
        "CITY": "Zhuhai",
        "POSTCODE": "519070",
    },
    "pobox60880": {
        "COUNTRY": "Bahrain",
        "COUNTRY_ISO3": "BHR",
        "STATE": "",
        "CITY": "Hidd",
        "POSTCODE": "60880",
        "LOCATION_ADDRESS": "PO Box 60880, Hidd, Bahrain",
    },
}


@dataclass
class RawRecord:
    location_name_raw: str
    location_address_raw: str
    country_hint: str
    source_url: str
    activity_hint: str
    source_priority: int
    location_name_native: str = ""
    location_address_native: str = ""


def now_ts() -> float:
    return time.time()


def build_session() -> requests.Session:
    session = requests.Session()
    session.headers.update({"User-Agent": USER_AGENT})
    return session


def fetch_soup(session: requests.Session, url: str) -> BeautifulSoup:
    response = session.get(url, timeout=HTTP_TIMEOUT, verify=False)
    response.raise_for_status()
    return BeautifulSoup(response.content, "html.parser")


def normalize_space(text: str) -> str:
    text = text.translate(ASCII_PUNCT_MAP)
    text = unicodedata.normalize("NFKC", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def has_non_ascii(text: str) -> bool:
    return any(ord(ch) > 127 for ch in text)


def clean_ascii_text(text: str) -> str:
    text = normalize_space(text)
    text = unidecode(text)
    text = text.replace("`", "'")
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\s+([,.;:])", r"\1", text)
    return text.strip(" ,;")


def clean_location_name(text: str) -> tuple[str, str]:
    raw = normalize_space(text)
    native = raw if has_non_ascii(raw) else ""
    cleaned = clean_ascii_text(raw)
    cleaned = cleaned.replace("[ ", "[").replace(" ]", "]")
    return cleaned, native


def clean_location_address(text: str) -> tuple[str, str]:
    raw = normalize_space(text)
    native = raw if has_non_ascii(raw) else ""
    cleaned = clean_ascii_text(raw)
    cleaned = cleaned.replace("#", " ")
    cleaned = cleaned.replace("Company website", "")
    cleaned = cleaned.replace("Website", "")
    cleaned = re.sub(r"\(postcode:\s*([A-Za-z0-9 -]+)\)", r" \1", cleaned, flags=re.I)
    cleaned = re.sub(r"\bpostcode\b[: ]*", "", cleaned, flags=re.I)
    cleaned = cleaned.replace("PO.BOX", "PO Box")
    cleaned = cleaned.replace("P.O.BOX", "PO Box")
    cleaned = cleaned.replace("P.O. BOX", "PO Box")
    cleaned = cleaned.replace("P.O BOX", "PO Box")
    cleaned = cleaned.replace("C.P.", "CP")
    cleaned = cleaned.replace(" ,", ",")
    cleaned = cleaned.replace(" - ", ", ")
    cleaned = re.sub(r"\s*;\s*", ", ", cleaned)
    cleaned = re.sub(r",\s*,+", ", ", cleaned)
    cleaned = re.sub(r"\s{2,}", " ", cleaned).strip(" ,;")
    return cleaned, native


def normalize_country_name(name: str) -> str:
    if not name:
        return ""
    cleaned = clean_ascii_text(name)
    key = cleaned.lower()
    if key in COUNTRY_ALIASES:
        cleaned = COUNTRY_ALIASES[key]
    try:
        return pycountry.countries.lookup(cleaned).name
    except LookupError:
        return cleaned


def country_to_iso3(name: str) -> str:
    if not name:
        return ""
    if name in PYCOUNTRY_FALLBACKS:
        return PYCOUNTRY_FALLBACKS[name]
    try:
        return pycountry.countries.lookup(name).alpha_3
    except LookupError:
        alias = COUNTRY_ALIASES.get(name.lower())
        if alias:
            return country_to_iso3(alias)
        return ""


def normalized_field_label(text: str) -> str:
    text = normalize_space(text)
    match = re.match(r"^\s*([A-Za-z \-/.]+?)\s*[:：]", text)
    if not match:
        return ""
    label = re.sub(r"[^a-z]", "", match.group(1).lower())
    return label


def is_field_line(text: str) -> bool:
    label = normalized_field_label(text)
    return label in {
        "tel",
        "telephone",
        "fax",
        "email",
        "website",
        "companywebsite",
        "mobile",
        "mob",
        "phone",
        "region",
        "whatsapp",
        "hotline",
        "address",
    }


def extract_field_value(line: str) -> tuple[str, str]:
    normalized = normalize_space(line)
    if ":" not in normalized:
        return "", normalized
    label, value = normalized.split(":", 1)
    return normalized_field_label(label + ":"), value.strip()


def address_slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", clean_ascii_text(text).lower())


def name_tokens(name: str) -> set[str]:
    tokens = set(re.findall(r"[a-z0-9]+", clean_ascii_text(name).lower()))
    return {token for token in tokens if token not in STOPWORDS and len(token) > 2}


def raw_record_key(record: RawRecord) -> tuple[str, str]:
    return (
        re.sub(r"[^a-z0-9]+", "", clean_ascii_text(record.location_name_raw).lower()),
        address_slug(record.location_address_raw),
    )


def serialize_progress(data: dict[str, Any]) -> None:
    PROGRESS_JSON.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def load_progress() -> dict[str, Any]:
    if PROGRESS_JSON.exists():
        return json.loads(PROGRESS_JSON.read_text(encoding="utf-8"))
    return {
        "completed_global_panels": [],
        "raw_records": [],
        "checkpoint_written": False,
    }


def save_raw_records(records: list[RawRecord]) -> None:
    RAW_RECORDS_JSON.write_text(
        json.dumps([asdict(record) for record in records], ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def load_geocode_cache() -> dict[str, Any]:
    if GEOCODE_CACHE_JSON.exists():
        return json.loads(GEOCODE_CACHE_JSON.read_text(encoding="utf-8"))
    return {}


def save_geocode_cache(cache: dict[str, Any]) -> None:
    GEOCODE_CACHE_JSON.write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding="utf-8")


def extract_global_distributor_blocks(
    session: requests.Session,
    state: dict[str, Any],
) -> list[RawRecord]:
    soup = fetch_soup(session, GLOBAL_DISTRIBUTOR_URL)
    panels = soup.select("div.panel.panel-default.panel-distributor")
    completed = {int(i) for i in state.get("completed_global_panels", [])}
    raw_records = [RawRecord(**item) for item in state.get("raw_records", [])]
    seen_keys = {raw_record_key(record) for record in raw_records}

    for index, panel in enumerate(panels):
        if index in completed:
            continue

        heading = panel.select_one("h4.panel-title")
        body = panel.select_one("div.panel-body")
        if not heading or not body:
            completed.add(index)
            continue

        country_hint = normalize_space(heading.get_text(" ", strip=True))
        current_name = ""
        current_fields: list[str] = []

        def commit_block() -> None:
            nonlocal current_name, current_fields, raw_records, seen_keys
            if not current_fields:
                current_name = ""
                current_fields = []
                return
            address_value = ""
            for line in current_fields:
                label, value = extract_field_value(line)
                if label == "address":
                    address_value = value
                    break
            if not address_value:
                current_name = ""
                current_fields = []
                return

            location_name = current_name or "Distributor"
            activity = "VRF Distributor" if "vrf distributor" in location_name.lower() else "Distributor"
            record = RawRecord(
                location_name_raw=location_name,
                location_address_raw=address_value,
                country_hint=country_hint,
                source_url=GLOBAL_DISTRIBUTOR_URL,
                activity_hint=activity,
                source_priority=1,
                location_name_native=location_name if has_non_ascii(location_name) else "",
                location_address_native=address_value if has_non_ascii(address_value) else "",
            )
            key = raw_record_key(record)
            if key not in seen_keys:
                raw_records.append(record)
                seen_keys.add(key)
            current_name = ""
            current_fields = []

        for p_tag in body.find_all("p", recursive=False):
            text = normalize_space(p_tag.get_text(" ", strip=True))
            if not text:
                continue
            if is_field_line(text):
                current_fields.append(text)
                continue
            if current_name or current_fields:
                commit_block()
            current_name = text

        if current_name or current_fields:
            commit_block()

        completed.add(index)
        state["completed_global_panels"] = sorted(completed)
        state["raw_records"] = [asdict(record) for record in raw_records]
        if len(completed) % PROGRESS_EVERY == 0:
            serialize_progress(state)

    state["completed_global_panels"] = sorted(completed)
    state["raw_records"] = [asdict(record) for record in raw_records]
    serialize_progress(state)
    return raw_records


def extract_canada_contact_records(session: requests.Session) -> list[RawRecord]:
    soup = fetch_soup(session, CANADA_CONTACT_URL)
    records: list[RawRecord] = []
    for item in soup.select("li.contact__address-item"):
        heading = item.find("h4")
        address = item.find("p")
        if not heading or not address:
            continue
        name = normalize_space(heading.get_text(" ", strip=True))
        addr = normalize_space(address.get_text(" ", strip=True))
        activity = "Distribution Center" if "distribution center" in name.lower() else "Office"
        records.append(
            RawRecord(
                location_name_raw=name,
                location_address_raw=addr,
                country_hint="Canada",
                source_url=CANADA_CONTACT_URL,
                activity_hint=activity,
                source_priority=3,
                location_name_native=name if has_non_ascii(name) else "",
                location_address_native=addr if has_non_ascii(addr) else "",
            )
        )
    return records


def extract_hq_contact_record(session: requests.Session) -> list[RawRecord]:
    soup = fetch_soup(session, HQ_CONTACT_URL.split("#", 1)[0])
    text = normalize_space(soup.get_text(" ", strip=True))
    match = re.search(
        r"GREE ELECTRIC APPLIANCES, INC\. OF ZHUHAI\s+Add:\s*(.+?)\s+Overseas Sales Inquiry Service",
        text,
        flags=re.I,
    )
    if not match:
        return []
    address = match.group(1).strip()
    return [
        RawRecord(
            location_name_raw="GREE ELECTRIC APPLIANCES, INC. OF ZHUHAI",
            location_address_raw=address,
            country_hint="China",
            source_url=HQ_CONTACT_URL,
            activity_hint="Corporate Office",
            source_priority=3,
        )
    ]


def choose_better_record(existing: RawRecord, candidate: RawRecord) -> RawRecord:
    if candidate.source_priority != existing.source_priority:
        return candidate if candidate.source_priority > existing.source_priority else existing
    if len(candidate.location_address_raw) > len(existing.location_address_raw):
        return candidate
    return existing


def collapse_records(records: list[RawRecord]) -> list[RawRecord]:
    exact: dict[tuple[str, str], RawRecord] = {}
    for record in records:
        key = raw_record_key(record)
        if key in exact:
            exact[key] = choose_better_record(exact[key], record)
        else:
            exact[key] = record

    grouped_by_address: dict[str, list[RawRecord]] = defaultdict(list)
    for record in exact.values():
        grouped_by_address[address_slug(record.location_address_raw)].append(record)

    collapsed: list[RawRecord] = []
    for group in grouped_by_address.values():
        if len(group) == 1:
            collapsed.extend(group)
            continue

        used = [False] * len(group)
        for i, record in enumerate(group):
            if used[i]:
                continue
            winner = record
            winner_tokens = name_tokens(record.location_name_raw)
            for j in range(i + 1, len(group)):
                if used[j]:
                    continue
                other = group[j]
                same_country_hint = normalize_country_name(record.country_hint) == normalize_country_name(other.country_hint)
                overlap = winner_tokens & name_tokens(other.location_name_raw)
                if overlap or same_country_hint:
                    winner = choose_better_record(winner, other)
                    used[j] = True
            used[i] = True
            collapsed.append(winner)

    unique_final: dict[tuple[str, str], RawRecord] = {}
    for record in collapsed:
        key = raw_record_key(record)
        unique_final[key] = choose_better_record(unique_final[key], record) if key in unique_final else record
    return list(unique_final.values())


def build_geocode_query(record: RawRecord, cleaned_address: str) -> str:
    if record.location_address_native and re.search(r"[\u4e00-\u9fff]", record.location_address_native):
        return f"{record.location_address_native}, {record.country_hint}"
    if record.country_hint and record.country_hint.lower() not in cleaned_address.lower():
        return f"{cleaned_address}, {record.country_hint}"
    return cleaned_address


def geocode_query(
    session: requests.Session,
    query: str,
    cache: dict[str, Any],
) -> dict[str, Any] | None:
    cache_key = query.strip()
    if cache_key in cache:
        return cache[cache_key]

    response = session.get(
        "https://nominatim.openstreetmap.org/search",
        params={
            "q": query,
            "format": "jsonv2",
            "addressdetails": 1,
            "limit": 1,
        },
        headers={"Accept-Language": "en"},
        timeout=HTTP_TIMEOUT,
        verify=False,
    )
    response.raise_for_status()
    payload = response.json()
    value = payload[0] if payload else None
    cache[cache_key] = value
    save_geocode_cache(cache)
    time.sleep(NOMINATIM_SLEEP_SECONDS)
    return value


def pick_city(address: dict[str, Any]) -> str:
    for key in ("city", "town", "municipality", "village", "hamlet", "suburb", "county"):
        if address.get(key):
            return address[key]
    return ""


def pick_state(address: dict[str, Any]) -> str:
    for key in ("state", "province", "region", "state_district", "county"):
        if address.get(key):
            return address[key]
    return ""


def extract_postcode_fallback(address: str) -> str:
    patterns = [
        r"\b\d{5}(?:-\d{4})?\b",
        r"\b[A-Z]\d[A-Z]\s?\d[A-Z]\d\b",
        r"\b\d{3}-\d{4}\b",
        r"\b\d{4,8}\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, address, flags=re.I)
        if match:
            return match.group(0)
    return ""


def fallback_city_state(cleaned_address: str, country: str) -> tuple[str, str]:
    parts = [part.strip() for part in re.split(r",|/| - ", cleaned_address) if part.strip()]
    city = ""
    state = ""

    if country == "United States":
        match = re.search(r"\b([A-Z]{2})\s+(\d{5}(?:-\d{4})?)\b", cleaned_address)
        if match and parts:
            state = match.group(1)
            city = parts[-2] if len(parts) >= 2 else ""
            return city, state

    if country == "Canada":
        match = re.search(r"\b([A-Z]{2})\s+[A-Z]\d[A-Z]\s?\d[A-Z]\d\b", cleaned_address, flags=re.I)
        if match and parts:
            state = match.group(1).upper()
            city = parts[-2] if len(parts) >= 2 else ""
            return city, state

    if len(parts) >= 2:
        city = parts[-2]
    if len(parts) >= 3:
        state = parts[-3]
    return city, state


def apply_manual_override(record: dict[str, str]) -> dict[str, str]:
    slug = address_slug(record["LOCATION_ADDRESS"])
    if slug in MANUAL_OVERRIDES:
        record.update(MANUAL_OVERRIDES[slug])
    return record


def finalize_record(
    session: requests.Session,
    cache: dict[str, Any],
    record: RawRecord,
) -> dict[str, str]:
    location_name, native_name = clean_location_name(record.location_name_raw)
    location_address, native_address = clean_location_address(record.location_address_raw)

    geocode_result = None
    try:
        geocode_query_text = build_geocode_query(record, location_address)
        geocode_result = geocode_query(session, geocode_query_text, cache)
    except Exception:
        geocode_result = None

    geo_address = geocode_result.get("address", {}) if geocode_result else {}
    country_value = normalize_country_name(geo_address.get("country", "") or record.country_hint)
    country_iso3 = country_to_iso3(country_value)
    postcode = clean_ascii_text(extract_postcode_fallback(location_address) or geo_address.get("postcode", ""))
    state = clean_ascii_text(pick_state(geo_address))
    city = clean_ascii_text(pick_city(geo_address))

    if not city or not state:
        fallback_city, fallback_state = fallback_city_state(location_address, country_value)
        city = city or clean_ascii_text(fallback_city)
        state = state or clean_ascii_text(fallback_state)

    output = {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": location_name,
        "LOCATION_ADDRESS": location_address,
        "LATITUDE": "",
        "LONGITUDE": "",
        "coord_source": "not_on_website",
        "COUNTRY": country_value,
        "COUNTRY_ISO3": country_iso3,
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": record.source_url,
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": record.activity_hint,
        "LOCATION_NAME_NATIVE": native_name or record.location_name_native,
        "LOCATION_ADDRESS_NATIVE": native_address or record.location_address_native,
    }
    output = apply_manual_override(output)

    output["LOCATION_NAME"] = clean_ascii_text(output["LOCATION_NAME"])
    output["LOCATION_ADDRESS"] = clean_ascii_text(output["LOCATION_ADDRESS"]).replace("#", " ")
    output["COUNTRY"] = normalize_country_name(output["COUNTRY"])
    output["COUNTRY_ISO3"] = output["COUNTRY_ISO3"] or country_to_iso3(output["COUNTRY"])
    output["POSTCODE"] = clean_ascii_text(output["POSTCODE"])
    output["STATE"] = clean_ascii_text(output["STATE"])
    output["CITY"] = clean_ascii_text(output["CITY"])
    output["ACTIVITY_AT_ASSET"] = clean_ascii_text(output["ACTIVITY_AT_ASSET"])

    return output


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELD_ORDER)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in FIELD_ORDER})


def validate_rows(rows: list[dict[str, str]]) -> list[str]:
    issues: list[str] = []
    for idx, row in enumerate(rows, start=1):
        if not row["LOCATION_ADDRESS"]:
            issues.append(f"Row {idx}: LOCATION_ADDRESS blank")
        if not row["CITY"]:
            issues.append(f"Row {idx}: CITY blank ({row['LOCATION_NAME']} | {row['LOCATION_ADDRESS']})")
        if "#" in row["LOCATION_ADDRESS"]:
            issues.append(f"Row {idx}: LOCATION_ADDRESS contains #")
    return issues


def sort_rows(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    return sorted(
        rows,
        key=lambda row: (
            row.get("COUNTRY", ""),
            row.get("CITY", ""),
            row.get("LOCATION_NAME", ""),
            row.get("LOCATION_ADDRESS", ""),
        ),
    )


def build_memory_draft(final_rows: list[dict[str, str]], canada_rows: int, hq_rows: int) -> None:
    draft = f"""### 4.X GREE ELECTRIC APPLIANCES, INC. OF ZHUHAI (Apr 2026)

| Source | URL | Records | Method | Script |
|--------|-----|---------|--------|--------|
| Global distributors directory | {GLOBAL_DISTRIBUTOR_URL} | {len([row for row in final_rows if row["SOURCE_URL"] == GLOBAL_DISTRIBUTOR_URL])} | Static HTML country-panel parse with repeated `<p>` contact blocks | `static_html_country_panel_contact_extractor.py` |
| Canada contact page | {CANADA_CONTACT_URL} | {canada_rows} | Static contact list parse | `static_html_country_panel_contact_extractor.py` |
| Zhuhai contact page | {HQ_CONTACT_URL} | {hq_rows} | Static text extraction from contact page | `static_html_country_panel_contact_extractor.py` |
| USA country selector | {USA_SELECTOR_URL} | 0 | Recon only; navigation page without address-bearing rows | `static_html_country_panel_contact_extractor.py` |
| **TOTAL** | | **{len(final_rows)}** | | |

**Platform Pattern**: Section 3.5 Static HTML Card-Based Layouts + Section 3.7 Direct Contact Page Scraping

**Key Approach**: The global Gree distributor page is a fully server-rendered country-panel directory where each facility block is stored as an inconsistent sequence of `<p>` tags. The working path was to parse those blocks generically, deduplicate reused distributor addresses across market tabs, then supplement the set with the Canada contact page and the Zhuhai corporate contact page.

**Approaches Tried** (chronological):
1. Read the extraction memory and matched the site to the static HTML/contact-directory family instead of an API or JS locator.
2. Fetched the provided URLs directly and confirmed that `{USA_SELECTOR_URL}` is only a country/region selector that links outward; it does not itself expose address rows.
3. Parsed `{GLOBAL_DISTRIBUTOR_URL}` and found 100 country panels plus 112 raw address-bearing distributor blocks, but the HTML used inconsistent field labels (`Tel`, `Te l`, `E-mail`, `Website`) and a mix of plain `<p>` tags / `panel-body-title` blocks.
4. Normalized field labels and grouped direct-child `<p>` blocks into name/address records, then removed repeated physical addresses reused across country tabs (for example Panama/Curacao and multi-market European/African distributors).
5. Supplemented the base set with the Canada contact page and Zhuhai contact page, retaining the more specific Canada office/distribution-center records where they overlapped the global distributor page.
6. Final working approach: static HTML parse + dedupe + website-only lat/lng policy + Nominatim-only admin-field enrichment for `CITY`/`STATE`/`POSTCODE`, while keeping `LATITUDE`/`LONGITUDE` blank with `coord_source=not_on_website`.

**Key Learnings**:
- Worked: parsing from response bytes instead of `requests.text` avoided mojibake caused by the incorrect ISO-8859-1 response header on `global.gree.com`.
- Worked: a generic field-label normalizer handled malformed labels like `Te l`, `E-mail`, `Company Website`, and full-width colons without custom per-country code.
- Worked: the 60-row checkpoint can be triggered safely during the country-panel sweep because the static directory yields deterministic row order.
- Worked: `{CANADA_CONTACT_URL}` adds one real extra facility (`Sunrise Tradex Distribution Center`) beyond the global distributor page.
- Failed: `{USA_SELECTOR_URL}` does not publish location rows and should be treated only as a navigation page.
- Failed: relying on the country panel heading as the physical country is unsafe because some market tabs reuse a distributor address in another jurisdiction (for example Curacao -> Panama, Iraq -> Jordan).

**Script Config**:
```python
ISSUER_ID = "{ISSUER_ID}"
ISSUER_NAME = "{ISSUER_NAME}"
GLOBAL_DISTRIBUTOR_URL = "{GLOBAL_DISTRIBUTOR_URL}"
CANADA_CONTACT_URL = "{CANADA_CONTACT_URL}"
HQ_CONTACT_URL = "{HQ_CONTACT_URL}"
CHECKPOINT_THRESHOLD = {CHECKPOINT_THRESHOLD}
PROGRESS_EVERY = {PROGRESS_EVERY}
```

> [!NOTE]
> **Run (2026-04-08):** {len(final_rows)} unique address-bearing rows extracted from the provided URLs after collapsing cross-market duplicates. The 60-row threshold was exceeded, a checkpoint CSV was written to Temp, and the final CSV retained blank `LATITUDE` / `LONGITUDE` for all rows because the website did not publish coordinates.
"""
    MEMORY_DRAFT_MD.write_text(draft, encoding="utf-8")


def main() -> None:
    started_at = now_ts()
    session = build_session()
    state = load_progress()
    geocode_cache = load_geocode_cache()

    global_raw = extract_global_distributor_blocks(session, state)
    canada_raw = extract_canada_contact_records(session)
    hq_raw = extract_hq_contact_record(session)

    combined_raw = global_raw + canada_raw + hq_raw
    collapsed_raw = collapse_records(combined_raw)
    save_raw_records(collapsed_raw)

    checkpoint_written = bool(state.get("checkpoint_written"))
    if not checkpoint_written and len(collapsed_raw) >= CHECKPOINT_THRESHOLD:
        checkpoint_rows = sort_rows(
            [finalize_record(session, geocode_cache, record) for record in collapsed_raw[:CHECKPOINT_THRESHOLD]]
        )
        checkpoint_issues = validate_rows(checkpoint_rows)
        if checkpoint_issues:
            raise RuntimeError("Checkpoint validation failed: " + " | ".join(checkpoint_issues[:10]))
        write_csv(CHECKPOINT_CSV, checkpoint_rows)
        state["checkpoint_written"] = True
        serialize_progress(state)

    final_rows = sort_rows([finalize_record(session, geocode_cache, record) for record in collapsed_raw])
    issues = validate_rows(final_rows)
    if issues:
        raise RuntimeError("Final validation failed: " + " | ".join(issues[:20]))

    write_csv(FINAL_CSV, final_rows)
    build_memory_draft(
        final_rows=final_rows,
        canada_rows=len([row for row in final_rows if row["SOURCE_URL"] == CANADA_CONTACT_URL]),
        hq_rows=len([row for row in final_rows if row["SOURCE_URL"] == HQ_CONTACT_URL]),
    )

    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "pattern_match": [
            "3.5 Static HTML Card-Based Layouts",
            "3.7 Direct Contact Page Scraping",
        ],
        "source_urls": [
            GLOBAL_DISTRIBUTOR_URL,
            USA_SELECTOR_URL,
            CANADA_CONTACT_URL,
            HQ_CONTACT_URL,
        ],
        "raw_global_records": len(global_raw),
        "final_record_count": len(final_rows),
        "checkpoint_threshold": CHECKPOINT_THRESHOLD,
        "checkpoint_written": CHECKPOINT_CSV.exists(),
        "final_csv": str(FINAL_CSV),
        "checkpoint_csv": str(CHECKPOINT_CSV) if CHECKPOINT_CSV.exists() else "",
        "memory_draft": str(MEMORY_DRAFT_MD),
        "duration_seconds": round(now_ts() - started_at, 2),
        "usa_selector_rows": 0,
        "notes": [
            "All LATITUDE/LONGITUDE values are blank because the website did not publish coordinates.",
            "coord_source is 'not_on_website' for every row.",
            "Main extraction memory markdown was not updated; draft note saved locally in Temp per task instruction.",
        ],
    }
    SUMMARY_JSON.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
