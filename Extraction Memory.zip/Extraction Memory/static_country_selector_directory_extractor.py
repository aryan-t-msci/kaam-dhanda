"""
Static Country-Selector Directory Extractor
===========================================

Platform pattern:
    Static corporate directory pages where a country <select> element links to
    country-specific detail pages. Each page contains one content block with
    repeated company headings (<h3>) followed by contact/activity/address markup.

What this script extracts:
    - One facility row per company entry in the country pages.
    - A checkpoint CSV once the configured threshold is reached.
    - A final CSV following the standard extraction schema.

How to configure for a new issuer:
    1. Update the CONFIGURATION block.
    2. Confirm the index page selector in COUNTRY_OPTION_SELECTOR.
    3. Confirm the per-entry wrapper selectors in COUNTRY_HEADING_SELECTOR and
       ORG_BLOCK_SELECTOR.
    4. Adjust SUPPLEMENTAL_ROWS / ROW_OVERRIDES only when the source directory
       omits a mandatory field such as a full address or city.

Usage:
    python static_country_selector_directory_extractor.py
"""

# ============================================================
# CONFIGURATION - Edit this block for each new issuer
# ============================================================
ISSUER_ID = "IID000000002124595"
ISSUER_NAME = "China National Building Material Company Limited"
INDEX_URL = "https://www.cnbm.com.cn/EN/000000160003/"
HQ_URL = "https://www.cnbm.com.cn/EN/0000001600070002/"
CHECKPOINT_THRESHOLD = 19

TEMP_DIR = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp"
OUTPUT_DIR = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output"

COUNTRY_OPTION_SELECTOR = "select.selector option[url]"
COUNTRY_HEADING_SELECTOR = "div.countries h1"
ORG_BLOCK_SELECTOR = "div.org"

# Optional normalization repairs for source text that is visibly corrupted.
NAME_FIXES = {
    "М?нхийн баян гал ХХК": "Мөнхийн баян гал ХХК",
}

# Official website supplements used only where the CNBM directory omits the
# full street address or a mandatory city field.
SUPPLEMENTAL_ROWS = {
    "AVANCIS GmbH": {
        "source_url": "https://www.avancis.de/en/imprint",
        "location_address": "Solarstraße 3, 04860 Torgau, Germany",
        "city": "Torgau",
        "state": "",
        "postcode": "04860",
        "country": "Germany",
        "country_iso3": "DEU",
    },
    "Jushi Egypt for Fiberglass Industry S.A.E": {
        "source_url": "https://www.jushi.com/en/overseas.html",
        "location_address": "3rd Sector of North-West Gulf of Suez, Economic Zone, Ain Sokhna, Suez, Egypt",
        "city": "Ain Sokhna",
        "state": "Suez",
        "postcode": "",
        "country": "Egypt",
        "country_iso3": "EGY",
    },
    "China jushi USA Corporation": {
        "source_url": "https://www.jushi.com/en/overseas.html",
        "location_address": "3130 Bluff RD, Suite B, Columbia, SC 29209, USA",
        "city": "Columbia",
        "state": "South Carolina",
        "postcode": "29209",
        "country": "United States of America",
        "country_iso3": "USA",
    },
}

# Targeted row-level cleanup where heuristics need help.
ROW_OVERRIDES = {
    "Мөнхийн баян гал ХХК": {
        "location_name_ascii": "Monkhiin Bayan Gal KhKhK",
        "location_name_native": "Мөнхийн баян гал ХХК",
        "city": "Ulan Bator",
        "state": "",
        "country": "Mongolia",
        "country_iso3": "MNG",
        "location_address": "Ulan Bator, Mongolia",
    },
    "LNV Technology Pvt Ltd": {
        "city": "Chennai",
        "state": "Tamil Nadu",
        "postcode": "600008",
        "country": "India",
        "country_iso3": "IND",
    },
    "SINOI GmbH": {
        "city": "Nordhausen",
        "state": "",
        "postcode": "99734",
        "country": "Germany",
        "country_iso3": "DEU",
        "location_address": "Kohnsteinbrücke 10, 99734 Nordhausen, Germany",
    },
    "CTF Solar GmbH": {
        "city": "Kelkheim",
        "state": "",
        "postcode": "65779",
        "country": "Germany",
        "country_iso3": "DEU",
        "location_address": "Industriestraße 2, 65779 Kelkheim, Germany",
    },
    "HAZEMAG & EPR GmbH": {
        "city": "Dülmen",
        "state": "",
        "postcode": "48249",
        "country": "Germany",
        "country_iso3": "DEU",
        "location_address": "Brokweg 75, 48249 Dülmen, Germany",
    },
    "China National Building Material Group FZE": {
        "city": "Dubai",
        "state": "Dubai",
        "country": "United Arab Emirates",
        "country_iso3": "ARE",
        "location_address": "Plot No. S30408, Jafza South, Jebel Ali Free Zone, Dubai, United Arab Emirates",
        "activity": "Wood & Timber; Steel; Scaffolding & Formwork; Machinery; Concrete & Cement; MEP; Hardware",
    },
    "CNBMI TANZANIA LIMITED": {
        "city": "Dar es Salaam",
        "state": "Dar es Salaam",
        "country": "Tanzania",
        "country_iso3": "TZA",
        "location_address": "Dar es Salaam, Tanzania",
    },
    "Beijing New Building Materials(Tanzania) Co.,Ltd.": {
        "city": "Dar es Salaam",
        "state": "Dar es Salaam",
        "country": "Tanzania",
        "country_iso3": "TZA",
    },
    "WILCO LIMITED": {
        "city": "Port Vila",
        "state": "",
        "country": "Vanuatu",
        "country_iso3": "VUT",
        "location_address": "Port Vila, Vanuatu",
    },
    "BNBM PNG LTD": {
        "country": "Papua New Guinea",
        "country_iso3": "PNG",
        "location_address": "Port Moresby, Papua New Guinea",
    },
    "Sinoma Cargo International Nigeria Ltd.": {
        "city": "Lagos",
        "state": "Lagos",
        "country": "Nigeria",
        "country_iso3": "NGA",
    },
    "Mpande Limestone Limited": {
        "city": "Lusaka",
        "state": "Lusaka",
        "country": "Zambia",
        "country_iso3": "ZMB",
    },
    "CNBMI ZAMBIA LIMITED": {
        "city": "Lusaka",
        "state": "Lusaka",
        "country": "Zambia",
        "country_iso3": "ZMB",
    },
    "Sinoma energy conservation (Philippines) waste heat recovery co,. Ltd.": {
        "city": "Antipolo City",
        "state": "Rizal",
        "postcode": "",
        "country": "Philippines",
        "country_iso3": "PHL",
        "location_address": "Sitio Tagbac, Brgy. San Jose, Antipolo City, Rizal, Philippines",
    },
    "Sinoma energy conservation (Cebu) waste heat recovery co,. Ltd.": {
        "city": "Naga",
        "state": "Cebu",
        "postcode": "6037",
        "country": "Philippines",
        "country_iso3": "PHL",
        "location_address": "APO Cement, Brgy. Tina-an, City of Naga, Cebu 6037, Philippines",
    },
    "Jushi Egypt for Fiberglass Industry S.A.E": {
        "activity": "glass fiber manufacturing",
    },
    "China jushi USA Corporation": {
        "activity": "glass fiber manufacturing",
    },
}

# ============================================================
# GENERIC EXTRACTION LOGIC - Do not modify per issuer
# ============================================================

import csv
import html
import os
import re
import unicodedata
from pathlib import Path
from typing import Dict, Iterable, List, Tuple
from urllib.parse import urljoin

import pycountry
import requests
from bs4 import BeautifulSoup, NavigableString, Tag
from unidecode import unidecode


COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS",
    "LOCATION_ADDRESS_NATIVE",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
]

COUNTRY_ALIASES = {
    "USA": "United States of America",
    "US": "United States of America",
    "P.R.C.": "China",
    "PRC": "China",
    "PNG": "Papua New Guinea",
    "Deutschland": "Germany",
    "UAE": "United Arab Emirates",
    "Tanzania": "Tanzania",
}

ISO_SPECIAL = {
    "United States of America": "USA",
    "United Arab Emirates": "ARE",
    "Papua New Guinea": "PNG",
    "Tanzania": "TZA",
}

GERMAN_REPLACEMENTS = {
    "ß": "ss",
    "ẞ": "SS",
    "ä": "ae",
    "Ä": "Ae",
    "ö": "oe",
    "Ö": "Oe",
    "ü": "ue",
    "Ü": "Ue",
}

ENTRY_RE = re.compile(r"<h3[^>]*>(.*?)</h3>(.*?)(?=<h3[^>]*>|$)", re.I | re.S)
PHONE_EMAIL_RE = re.compile(r"^(Phone|Fax|Email|E-mail|Website|Contact Person)\b", re.I)


def make_session() -> requests.Session:
    session = requests.Session()
    session.headers.update({"User-Agent": "Mozilla/5.0"})
    return session


SESSION = make_session()


def norm(text: str) -> str:
    if not text:
        return ""
    text = html.unescape(text).replace("\xa0", " ")
    text = unicodedata.normalize("NFKC", text)
    return re.sub(r"\s+", " ", text).strip()


def ascii_text(text: str) -> str:
    text = norm(text)
    for old, new in GERMAN_REPLACEMENTS.items():
        text = text.replace(old, new)
    text = unidecode(text)
    text = text.replace("?", "")
    return re.sub(r"\s+", " ", text).strip(" ,;")


def native_value(original: str, ascii_value: str) -> str:
    original = norm(original)
    if not original:
        return ""
    return original if any(ord(ch) > 127 for ch in original) and original != ascii_value else ""


def fetch_html(url: str) -> str:
    response = SESSION.get(url, timeout=30, verify=False)
    response.raise_for_status()
    return response.content.decode("utf-8", errors="replace")


def clean_address(text: str) -> str:
    text = norm(text)
    text = re.sub(r"\b(?:Phone|Fax|Email|E-mail|Website|Contact Person)\b.*", "", text, flags=re.I)
    text = text.replace("#", "")
    text = text.replace("，", ", ")
    text = text.replace(" – ", ", ")
    text = text.replace("-India", ", India")
    text = text.replace("Philippines", ", Philippines") if "Cebu 6037 Philippines" in text else text
    text = text.replace("SC 29209", "SC 29209")
    text = text.replace("Industriestra?e", "Industriestrasse")
    text = text.replace("Dülmen", "Duelmen")
    text = text.replace("Kohnsteinbrücke", "Kohnsteinbruecke")
    text = text.replace("Solarstraße", "Solarstrasse")
    text = text.replace("Deutschland", "Germany")
    text = text.replace("P.R.C.", "China")
    text = re.sub(r"\s+,", ",", text)
    text = re.sub(r",\s*,", ", ", text)
    text = re.sub(r"\s{2,}", " ", text)
    return text.strip(" ,;.")


def country_from_text(*values: str) -> str:
    haystacks = [norm(v) for v in values if v]
    for hay in haystacks:
        for alias, country in COUNTRY_ALIASES.items():
            if re.search(rf"(?<![A-Za-z]){re.escape(alias)}(?![A-Za-z])", hay, re.I):
                return country
        for country in pycountry.countries:
            if re.search(rf"(?<![A-Za-z]){re.escape(country.name)}(?![A-Za-z])", hay, re.I):
                return country.name
            official_name = getattr(country, "official_name", "")
            if official_name and re.search(rf"(?<![A-Za-z]){re.escape(official_name)}(?![A-Za-z])", hay, re.I):
                return country.name
    return ""


def iso3(country: str) -> str:
    if not country:
        return ""
    if country in ISO_SPECIAL:
        return ISO_SPECIAL[country]
    found = pycountry.countries.get(name=country)
    if not found:
        found = pycountry.countries.get(official_name=country)
    return getattr(found, "alpha_3", "")


def split_entry_blocks(con_html: str) -> List[str]:
    soup = BeautifulSoup(con_html, "html.parser")
    con = soup.find("div", class_="con") or soup
    blocks: List[str] = []
    for child in con.children:
        if isinstance(child, NavigableString):
            text = norm(str(child))
        elif isinstance(child, Tag):
            text = norm(child.get_text(" ", strip=True))
        else:
            text = ""
        if not text:
            continue
        if PHONE_EMAIL_RE.match(text):
            continue
        text = re.sub(r"^(Phone|Fax|Email|E-mail|Website|Contact Person)\s*[:：].*$", "", text, flags=re.I)
        text = norm(text)
        if text:
            blocks.append(text)
    return blocks


def parse_components(address: str, country_hint: str) -> Tuple[str, str, str, str]:
    address = clean_address(address)
    country = country_from_text(address, country_hint) or country_hint
    postcode = ""
    state = ""
    city = ""

    if country in {"United States of America", "United States"}:
        m = re.search(r"\b([A-Z]{2})\s+(\d{5})(?:-\d{4})?\b", address)
        if m:
            state_map = {
                "SC": "South Carolina",
            }
            state = state_map.get(m.group(1), m.group(1))
            postcode = m.group(2)
        city_match = re.search(r",\s*([A-Za-z .'-]+),\s*[A-Z]{2}\s+\d{5}", address)
        if city_match:
            city = city_match.group(1).strip()
        country = "United States of America"
    elif country == "Germany":
        m = re.search(r"\b(\d{5})\s+([A-Za-zA-ZäöüÄÖÜß?]+(?:\s+[A-Za-zA-ZäöüÄÖÜß?]+)*)", address)
        if m:
            postcode = m.group(1)
            city = ascii_text(m.group(2))
    elif country == "India":
        m = re.search(r"\b(\d{3}\s?\d{3})\b", address)
        if m:
            postcode = m.group(1).replace(" ", "")
        m = re.search(r",\s*([A-Za-z .'-]+),\s*(Tamil Nadu|Karnataka|Maharashtra|Delhi|Telangana|Andhra Pradesh)", address)
        if m:
            city = norm(m.group(1))
            state = norm(m.group(2))
    elif country == "Philippines":
        m = re.search(r"(Antipolo City),\s*([A-Za-z ]+),\s*Philippines", address)
        if m:
            city, state = norm(m.group(1)), norm(m.group(2))
        m = re.search(r"(City of Naga),\s*([A-Za-z ]+)\s+(\d{4})", address)
        if m:
            city, state, postcode = "Naga", norm(m.group(2)), m.group(3)
    elif country == "United Arab Emirates":
        if "Jebel Ali" in address or "Jafza" in address:
            city = "Dubai"
            state = "Dubai"
    elif country == "Papua New Guinea":
        city = "Port Moresby" if "Port Moresby" in address else ""
    elif country == "Vanuatu":
        city = "Port Vila" if "Vila" in address else ""
    elif country == "China":
        m = re.search(r"\b(\d{6})\b", address)
        if m:
            postcode = m.group(1)
        if "Beijing" in address:
            city = "Beijing"
            state = "Beijing"
    elif country == "Tanzania, United Republic of":
        if "Dar es Salaam" in address or "Dar-es-Salaam" in address:
            city = "Dar es Salaam"
            state = "Dar es Salaam"
    elif country == "Egypt":
        if "Ain Sokhna" in address:
            city = "Ain Sokhna"
        if "Suez" in address:
            state = "Suez"

    if not city:
        tokens = [tok.strip(" .") for tok in address.split(",") if tok.strip(" .")]
        if tokens:
            tail = tokens[-1]
            if country and tail.lower() == country.lower() and len(tokens) >= 2:
                city = tokens[-2]
            elif country == "Papua New Guinea" and tail.upper() == "PNG" and len(tokens) >= 2:
                city = tokens[-2]
            elif len(tokens) >= 2:
                city = tokens[-2] if country else tokens[-1]
            else:
                city = tokens[-1]

    city = norm(city)
    state = norm(state)
    postcode = norm(postcode)

    if city == "South Carolina":
        city = ""
    if city == "Lagos":
        state = state or "Lagos"
    if city == "Lusaka":
        state = state or "Lusaka"
    if country == "Papua New Guinea" and city == "PNG":
        city = "Port Moresby"
    if country == "Tanzania, United Republic of" and city == "Dar-es-Salaam":
        city = "Dar es Salaam"

    return address, city, state, postcode


def parse_country_page(url: str) -> List[Dict[str, str]]:
    html_text = fetch_html(url)
    soup = BeautifulSoup(html_text, "html.parser")
    country_heading = norm((soup.select_one(COUNTRY_HEADING_SELECTOR) or {}).get_text(" ", strip=True) if soup.select_one(COUNTRY_HEADING_SELECTOR) else "")
    org = soup.select_one(ORG_BLOCK_SELECTOR)
    if not org:
        return []

    rows: List[Dict[str, str]] = []
    for match in ENTRY_RE.finditer(org.decode_contents()):
        raw_name = norm(BeautifulSoup(match.group(1), "html.parser").get_text(" ", strip=True))
        raw_name = NAME_FIXES.get(raw_name, raw_name)
        blocks = split_entry_blocks(match.group(2))
        if not raw_name:
            continue

        activity = ""
        address = ""
        if len(blocks) >= 2:
            activity = norm(" ".join(blocks[:-1]))
            address = clean_address(blocks[-1])
        elif len(blocks) == 1:
            text = blocks[0]
            if re.search(r"\d|,|USA|Germany|Philippines|Egypt|Nigeria|Zambia|Vanuatu|PNG|Tanzania|Arab Emirates|Mongolia|India", text, re.I):
                address = clean_address(text)
            else:
                activity = norm(text)

        row = {
            "raw_name": raw_name,
            "raw_address": address,
            "country_hint": country_heading,
            "source_url": url,
            "activity": activity,
        }
        address_country = country_from_text(address)
        heading_country = COUNTRY_ALIASES.get(country_heading, country_heading)
        if address_country and heading_country and address_country != heading_country:
            continue
        rows.append(row)
    return rows


def build_hq_row() -> Dict[str, str]:
    row = {
        "raw_name": "CNBM Headquarters",
        "raw_address": "19th (22nd, 23rd) Floor, 2nd Building, Guohai Plaza, No. 17 Fuxing Road, Haidian District, Beijing, P.R.C.",
        "country_hint": "China",
        "source_url": HQ_URL,
        "activity": "Headquarters office",
        "postcode": "100036",
        "city": "Beijing",
        "state": "Beijing",
        "country": "China",
        "country_iso3": "CHN",
    }
    return row


def finalize_row(item: Dict[str, str]) -> Dict[str, str]:
    raw_name = item["raw_name"]
    raw_address = item.get("raw_address", "")
    source_url = item.get("source_url", "")
    activity = item.get("activity", "")
    country_hint = item.get("country_hint", "")

    supplement = SUPPLEMENTAL_ROWS.get(raw_name, {})
    override = ROW_OVERRIDES.get(raw_name, {})

    if supplement.get("location_address"):
        raw_address = supplement["location_address"]
        source_url = supplement.get("source_url", source_url)

    address, city, state, postcode = parse_components(raw_address, supplement.get("country", country_hint))
    country = supplement.get("country") or country_from_text(address, country_hint) or country_hint
    country = COUNTRY_ALIASES.get(country, country)

    if supplement.get("city") is not None:
        city = supplement["city"]
    if supplement.get("state") is not None:
        state = supplement["state"]
    if supplement.get("postcode") is not None:
        postcode = supplement["postcode"]
    if supplement.get("country_iso3") is not None:
        country_iso = supplement["country_iso3"]
    else:
        country_iso = item.get("country_iso3") or iso3(country)

    if item.get("postcode"):
        postcode = item["postcode"]
    if item.get("city"):
        city = item["city"]
    if item.get("state"):
        state = item["state"]
    if item.get("country"):
        country = item["country"]

    if override.get("location_address"):
        address = clean_address(override["location_address"])
    if override.get("city") is not None:
        city = override["city"]
    if override.get("state") is not None:
        state = override["state"]
    if override.get("country") is not None:
        country = override["country"]
    if override.get("country_iso3") is not None:
        country_iso = override["country_iso3"]
    if override.get("postcode") is not None:
        postcode = override["postcode"]
    if override.get("activity"):
        activity = override["activity"]

    name_ascii = override.get("location_name_ascii") or ascii_text(raw_name)
    address_ascii = ascii_text(address)
    city_ascii = ascii_text(city)
    state_ascii = ascii_text(state)
    native_name_value = override.get("location_name_native") or native_value(raw_name, name_ascii)

    if not city_ascii:
        raise ValueError(f"Blank CITY after parsing: {raw_name} | {address}")
    if not address_ascii:
        raise ValueError(f"Blank LOCATION_ADDRESS after parsing: {raw_name}")

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": name_ascii,
        "LOCATION_NAME_NATIVE": native_name_value,
        "LOCATION_ADDRESS": address_ascii,
        "LOCATION_ADDRESS_NATIVE": native_value(address, address_ascii),
        "LATITUDE": "",
        "LONGITUDE": "",
        "COUNTRY": country,
        "COUNTRY_ISO3": country_iso,
        "POSTCODE": postcode,
        "STATE": state_ascii,
        "CITY": city_ascii,
        "SOURCE_URL": source_url,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": norm(activity),
        "coord_source": "Not from website",
    }


def write_csv(path: Path, rows: Iterable[Dict[str, str]]) -> None:
    rows = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


def dedupe_rows(rows: List[Dict[str, str]]) -> List[Dict[str, str]]:
    seen = set()
    result = []
    for row in rows:
        key = (
            row["LOCATION_NAME"].lower(),
            row["LOCATION_ADDRESS"].lower(),
        )
        if key in seen:
            continue
        seen.add(key)
        result.append(row)
    return result


def main() -> None:
    temp_dir = Path(TEMP_DIR)
    output_dir = Path(OUTPUT_DIR)
    checkpoint_csv = temp_dir / f"{ISSUER_ID}_{ISSUER_NAME}_checkpoint.csv"
    final_csv = output_dir / f"{ISSUER_ID}_{ISSUER_NAME}.csv"

    index_html = fetch_html(INDEX_URL)
    index_soup = BeautifulSoup(index_html, "html.parser")
    country_urls: List[str] = []
    for opt in index_soup.select(COUNTRY_OPTION_SELECTOR):
        url = norm(opt.get("url", ""))
        if not url or url.endswith("/EN/000000160003/"):
            continue
        full = url if url.startswith("http") else urljoin(INDEX_URL, url)
        if full not in country_urls:
            country_urls.append(full)

    raw_rows: List[Dict[str, str]] = []
    checkpoint_written = False

    for url in country_urls:
        raw_rows.extend(parse_country_page(url))

    raw_rows.append(build_hq_row())

    finalized: List[Dict[str, str]] = []
    for item in raw_rows:
        finalized.append(finalize_row(item))
        deduped = dedupe_rows(finalized)
        if not checkpoint_written and len(deduped) >= CHECKPOINT_THRESHOLD:
            write_csv(checkpoint_csv, deduped)
            checkpoint_written = True

    final_rows = dedupe_rows(finalized)
    write_csv(final_csv, final_rows)

    if not checkpoint_written:
        write_csv(checkpoint_csv, final_rows)

    print(f"Checkpoint CSV: {checkpoint_csv}")
    print(f"Final CSV:      {final_csv}")
    print(f"Rows:           {len(final_rows)}")


if __name__ == "__main__":
    requests.packages.urllib3.disable_warnings()  # type: ignore[attr-defined]
    main()
