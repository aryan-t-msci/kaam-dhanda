"""
drupal_callajax_branch_extractor.py
====================================
Generic branch extractor for Drupal 10 sites using the /callajax POST endpoint pattern.

PLATFORM PATTERN: Drupal 10 /callajax Branch Locator (Section 3.13)

Detection:
  - <meta name="Generator" content="Drupal 10"> in page HTML
  - Inline script: $.post("/callajax", {action:'get_branch_list', state:..., dist:..., location:...})
  - Returns HTML fragments (not JSON)

Data sources:
  - POST /callajax {action:'get_all_states'}           → <option> list of states
  - POST /callajax {action:'get_branch_list', state:X} → first 10 branches as HTML table
  - POST /callajax {action:'get_more_branch_list', state:X, offset:N} → next 10 branches

How to adapt for a new issuer:
  1. Update CONFIGURATION block below with the new issuer's details
  2. Verify the /callajax endpoint is present (check branch-locator page inline scripts)
  3. Adjust PUDUCHERRY_KEYWORDS if needed for other union territories

Example config for reuse:
    ISSUER_ID    = "IID000000002618636"
    ISSUER_NAME  = "MUTHOOT FINANCE LIMITED"
    BASE_URL     = "https://www.muthootfinance.com"

Usage:
    python drupal_callajax_branch_extractor.py
"""

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_ID    = "IID000000002618636"
ISSUER_NAME  = "MUTHOOT FINANCE LIMITED"
BASE_URL     = "https://www.muthootfinance.com"
CALLAJAX_PATH = "/callajax"  # The Drupal custom AJAX endpoint path
BRANCH_LOCATOR_PATH = "/branch-locator"

OUTPUT_DIR   = "output"

# States to scrape (empty = scrape all from get_all_states)
# If specific states needed, list them here (e.g. ['Kerala', 'Tamilnadu'])
STATES_FILTER = []

# Keywords to identify Puducherry/UT branches misclassified under another state
# These branches will have their STATE overridden to 'Puducherry'
PUDUCHERRY_KEYWORDS = ['pondicherry', 'puducherry', 'karikal', 'mahe', 'yanam']
PUDUCHERRY_HOST_STATE = 'Tamilnadu'  # State under which UT branches appear in API

BRANCH_LOCATOR_URL = f"{BASE_URL}/branch-locator"
# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC BELOW — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════

import re, json, csv, time, urllib.request, urllib.parse, ssl, os
from pathlib import Path
from bs4 import BeautifulSoup

CALLAJAX_URL = f"{BASE_URL}{CALLAJAX_PATH}"
OUTPUT_PATH  = Path(OUTPUT_DIR)
OUTPUT_PATH.mkdir(exist_ok=True)
PROGRESS_FILE = OUTPUT_PATH / "progress.json"

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Referer': BRANCH_LOCATOR_URL,
    'Origin': BASE_URL,
}

COLS = ['ISSUER_ID','ISSUER_NAME','FACILITY_NAME','FACILITY_ADDRESS','CITY','STATE',
        'POSTAL_CODE','FACILITY_REGION','LATITUDE','LONGITUDE',
        'FACILITY_CONTACT_NUMBER','RELEVANT_URL','BUSINESS_ACTIVITY']


def post_callajax(action, extra_params='', timeout=20):
    """POST to the Drupal /callajax endpoint and return HTML content."""
    data = f'action={action}'
    if extra_params:
        data += f'&{extra_params}'
    req = urllib.request.Request(CALLAJAX_URL, data=data.encode(), headers=HEADERS, method='POST')
    try:
        with urllib.request.urlopen(req, context=ctx, timeout=timeout) as r:
            return r.read().decode('utf-8', errors='ignore'), r.status
    except Exception as e:
        print(f"  ERROR posting {action}: {e}")
        return '', 0


def get_states():
    """Get all valid state values from the API."""
    html, status = post_callajax('get_all_states')
    if not html:
        return []
    states = re.findall(r'<option value="([^"]+)">', html)
    return [s for s in states if s]  # filter empty


def parse_branches_html(html, state_name):
    """Parse branch rows from a /callajax HTML table response."""
    branches = []
    soup = BeautifulSoup(html, 'html.parser')
    rows = soup.find_all('tr')
    
    for row in rows:
        cells = row.find_all('td')
        if len(cells) < 2:
            continue

        # Cell 0: branch name + code + status
        cell0_text = cells[0].get_text(separator=' ', strip=True)
        name_tag = cells[0].find('strong')
        name = name_tag.get_text(strip=True) if name_tag else ''
        code_m = re.search(r'Branch Code:\s*(\d+)', cell0_text)
        status_m = re.search(r'Branch Status:\s*(\w+)', cell0_text)
        status = status_m.group(1) if status_m else 'OPEN'

        if not name or status != 'OPEN':
            continue  # skip header row or closed branches

        # Cell 1: address
        addr = cells[1].get_text(separator=' ', strip=True)
        addr = re.sub(r'\s+', ' ', addr).strip()

        # Cell 2: contact number
        contact = ''
        if len(cells) >= 3:
            tel = cells[2].find('a', href=re.compile(r'^tel:'))
            if tel:
                contact = tel.get_text(strip=True)

        # Cell 3: Google Maps link with coordinates
        lat, lng = '', ''
        if len(cells) >= 4:
            coord_m = re.search(r'CurrentLocation/(-?[\d.]+),(-?[\d.]+)', str(cells[3]))
            if coord_m:
                lat, lng = coord_m.group(1), coord_m.group(2)

        branches.append({
            'name': name,
            'code': code_m.group(1) if code_m else '',
            'address': addr,
            'contact': contact,
            'lat': lat,
            'lng': lng,
            'state': state_name,
        })
    return branches


def scrape_state(state_name):
    """Scrape all branches for a given state using offset-based pagination."""
    all_branches = []
    offset = 0

    while True:
        if offset == 0:
            html, status = post_callajax('get_branch_list', f'state={urllib.parse.quote(state_name)}')
        else:
            html, status = post_callajax(
                'get_more_branch_list',
                f'state={urllib.parse.quote(state_name)}&dist=&location=&offset={offset}'
            )

        if status != 200 or not html:
            break

        parsed = parse_branches_html(html, state_name)
        if not parsed:
            break  # No more data

        all_branches.extend(parsed)
        offset += 10
        time.sleep(0.3)

    return all_branches


def branch_to_record(branch):
    """Convert a raw branch dict to standardized output record."""
    addr = branch['address']
    state = branch['state']

    # Extract postal code
    pincode_m = re.search(r'\b(\d{6})\b', addr)
    postal = pincode_m.group(1) if pincode_m else ''

    # Simple city extraction: last non-numeric part of address
    parts = [p.strip() for p in re.split(r',\s*', addr) if p.strip()]
    city = ''
    for part in reversed(parts[-3:]):
        part_clean = re.sub(r'\b\d{6}\b', '', part).strip()
        part_clean = re.sub(r'[^a-zA-Z\s\-]', '', part_clean).strip()
        if len(part_clean) > 2:
            city = part_clean[:50]
            break

    # Override state for Puducherry branches
    if state == PUDUCHERRY_HOST_STATE:
        if any(kw in addr.lower() for kw in PUDUCHERRY_KEYWORDS):
            state = 'Puducherry'

    return {
        'ISSUER_ID': ISSUER_ID,
        'ISSUER_NAME': ISSUER_NAME,
        'FACILITY_NAME': f"{ISSUER_NAME} - {branch['name']} Branch",
        'FACILITY_ADDRESS': addr,
        'CITY': city,
        'STATE': state,
        'POSTAL_CODE': postal,
        'FACILITY_REGION': 'India',
        'LATITUDE': branch['lat'],
        'LONGITUDE': branch['lng'],
        'FACILITY_CONTACT_NUMBER': branch.get('contact', ''),
        'RELEVANT_URL': BRANCH_LOCATOR_URL,
        'BUSINESS_ACTIVITY': 'Branch',
    }


def save_progress(records, done_states):
    """Save progress every 20 iterations for resumability."""
    with open(PROGRESS_FILE, 'w', encoding='utf-8') as f:
        json.dump({'records': records, 'done_states': done_states}, f, ensure_ascii=False)


def load_progress():
    """Load saved progress if it exists."""
    if PROGRESS_FILE.exists():
        with open(PROGRESS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data.get('records', []), set(data.get('done_states', []))
    return [], set()


def main():
    print(f"Drupal /callajax Branch Extractor")
    print(f"Issuer: {ISSUER_NAME} ({ISSUER_ID})")
    print(f"Endpoint: {CALLAJAX_URL}\n")

    # Resume if progress exists
    all_records, done_states = load_progress()
    if done_states:
        print(f"Resuming from progress: {len(done_states)} states done, {len(all_records)} records so far")

    # Get state list
    states = STATES_FILTER or get_states()
    print(f"States to scrape: {len(states)}")
    states_todo = [s for s in states if s not in done_states]
    print(f"States remaining: {len(states_todo)}\n")

    for i, state in enumerate(states_todo):
        print(f"[{i+1}/{len(states_todo)}] Scraping {state}...")
        branches = scrape_state(state)
        print(f"  Found {len(branches)} branches")

        for b in branches:
            all_records.append(branch_to_record(b))

        done_states.add(state)

        # Save progress every 20 states
        if (i + 1) % 20 == 0:
            save_progress(all_records, list(done_states))
            print(f"  Progress saved ({len(all_records)} records total)")

    # Write final CSV
    output_file = OUTPUT_PATH / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
    with open(output_file, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=COLS)
        writer.writeheader()
        writer.writerows(all_records)

    print(f"\nComplete! {len(all_records)} records written to {output_file}")

    # Clean up progress file
    if PROGRESS_FILE.exists():
        PROGRESS_FILE.unlink()


if __name__ == '__main__':
    main()
