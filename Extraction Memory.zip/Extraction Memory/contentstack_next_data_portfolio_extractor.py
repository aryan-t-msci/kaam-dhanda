"""Contentstack Next.js portfolio extractor.

Platform: a Next.js site whose page HTML contains
``<script id="__NEXT_DATA__">`` with a Contentstack payload. Project
facilities live in a list of objects with latitude/longitude, and
optional office records live in a second list. Case-study entries are
narrative pages that point at projects already in the list; they enrich
RELEVANT_URL and are not emitted as extra facilities.

No geocoding is performed. Coordinates are taken only from the payload.

Usage:
    python contentstack_next_data_portfolio_extractor.py
"""

from __future__ import annotations

import csv
import json
import re
import unicodedata
from pathlib import Path

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Edit this block for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_ID = "IID000000002391586"
ISSUER_NAME = "INVENERGY RENEWABLES LLC"
COMPANY_NAME = "INVENERGY RENEWABLES LLC"
BASE_URL = "https://wwww.invenergy.com"
PROJECTS_PAGE = "/projects/our-projects"
CASE_STUDIES_PAGE = "/projects/case-studies"
HTML_PATH = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Barclays2 CQ\Assets to Add\_temp\invenergy_proj.html"
)
CASE_HTML_PATH = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Barclays2 CQ\Assets to Add\_temp\invenergy_case.html"
)
OUTPUT_CSV = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Barclays2 CQ\Assets to Add"
) / "IID000000002391586_INVENERGY RENEWABLES LLC.csv"
TEMP_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Barclays2 CQ\Assets to Add\_temp"
)
REJECT_CSV = TEMP_DIR / "NOT_PROVIDED_Invenergy_rejected.csv"
QA_JSON = TEMP_DIR / "NOT_PROVIDED_Invenergy_qa.json"

PROJECTS_KEY = "projects"
OFFICES_KEY = "offices"
CASE_STUDIES_KEY = "caseStudies"

ACTIVITY_LABELS = {
    "Wind": "Wind power generation",
    "Solar": "Solar power generation",
    "Storage": "Battery energy storage",
    "Natural Gas": "Natural gas power generation",
}
OWNED_VALUES = {"invenergy"}
THIRD_PARTY_VALUES = {"third-party", "third party"}
OPERATING_STATUSES = {"cod achieved"}
CONSTRUCTION_STATUSES = {"in construction", "contracted"}
# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════

COLUMNS = [
    "ISSUER_ID",
    "COMPANY_NAME",
    "FACILITY_NAME",
    "FACILITY_ADDRESS",
    "CITY",
    "STATE",
    "POSTAL_CODE",
    "FACILITY_REGION",
    "COUNTRY_ISO3",
    "LATITUDE",
    "LONGITUDE",
    "coord_source",
    "ACTIVITY_AT_ASSET",
    "FACILITY_CONTACT_NUMBER",
    "SCOPE",
    "SCOPE_REASON",
    "RELEVANT_URL",
    "SOURCE_TYPE",
    "VALIDATION_URL",
    "VALIDATION_SOURCE_TYPE",
    "QA_flag",
]

US_ABBREV = {
    "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas",
    "CA": "California", "CO": "Colorado", "CT": "Connecticut", "DE": "Delaware",
    "FL": "Florida", "GA": "Georgia", "HI": "Hawaii", "ID": "Idaho",
    "IL": "Illinois", "IN": "Indiana", "IA": "Iowa", "KS": "Kansas",
    "KY": "Kentucky", "LA": "Louisiana", "ME": "Maine", "MD": "Maryland",
    "MA": "Massachusetts", "MI": "Michigan", "MN": "Minnesota", "MS": "Mississippi",
    "MO": "Missouri", "MT": "Montana", "NE": "Nebraska", "NV": "Nevada",
    "NH": "New Hampshire", "NJ": "New Jersey", "NM": "New Mexico", "NY": "New York",
    "NC": "North Carolina", "ND": "North Dakota", "OH": "Ohio", "OK": "Oklahoma",
    "OR": "Oregon", "PA": "Pennsylvania", "RI": "Rhode Island", "SC": "South Carolina",
    "SD": "South Dakota", "TN": "Tennessee", "TX": "Texas", "UT": "Utah",
    "VT": "Vermont", "VA": "Virginia", "WA": "Washington", "WV": "West Virginia",
    "WI": "Wisconsin", "WY": "Wyoming", "DC": "District of Columbia",
}
CA_ABBREV = {
    "ON": "Ontario", "QC": "Quebec", "SK": "Saskatchewan", "AB": "Alberta",
    "BC": "British Columbia", "MB": "Manitoba", "NB": "New Brunswick",
    "NS": "Nova Scotia", "PE": "Prince Edward Island", "NL": "Newfoundland and Labrador",
    "NT": "Northwest Territories", "YT": "Yukon", "NU": "Nunavut",
}
BR_ABBREV = {"RN": "Rio Grande do Norte", "SP": "Sao Paulo"}

# long UN name, ISO3, short name used inside FACILITY_ADDRESS
COUNTRY_MAP = {
    "u.s.": ("United States of America (the)", "USA", "United States"),
    "u.s": ("United States of America (the)", "USA", "United States"),
    "us": ("United States of America (the)", "USA", "United States"),
    "usa": ("United States of America (the)", "USA", "United States"),
    "united states": ("United States of America (the)", "USA", "United States"),
    "united states of america": ("United States of America (the)", "USA", "United States"),
    "canada": ("Canada", "CAN", "Canada"),
    "mexico": ("Mexico", "MEX", "Mexico"),
    "poland": ("Poland", "POL", "Poland"),
    "japan": ("Japan", "JPN", "Japan"),
    "uruguay": ("Uruguay", "URY", "Uruguay"),
    "united kingdom": (
        "United Kingdom of Great Britain and Northern Ireland (the)",
        "GBR",
        "United Kingdom",
    ),
    "uk": (
        "United Kingdom of Great Britain and Northern Ireland (the)",
        "GBR",
        "United Kingdom",
    ),
    "scotland": (
        "United Kingdom of Great Britain and Northern Ireland (the)",
        "GBR",
        "United Kingdom",
    ),
    "el salvador": ("El Salvador", "SLV", "El Salvador"),
    "brazil": ("Brazil", "BRA", "Brazil"),
    "spain": ("Spain", "ESP", "Spain"),
}

REGION_WORDS = (
    "county", "counties", "couty", "couties", "parish", "voivodeship",
    "department", "prefecture", "council area",
)
TYPO_FIXES = (
    (re.compile(r"\bCouties\b", re.I), "Counties"),
    (re.compile(r"\bCouty\b", re.I), "County"),
)
HASH_RE = re.compile(r"#")
COMPANY_LINE_RE = re.compile(r"\b(Sp\.\s*z\s*o\.o\.|LLC|L\.L\.C\.|Inc\.|Ltd\.?)\b", re.I)
PHONE_RE = re.compile(r"(\+?\d[\d\s().-]{6,}\d)")
US_ZIP_RE = re.compile(r"\b(\d{5})(?:-\d{4})?\b")
CA_POSTAL_RE = re.compile(r"\b([A-Z]\d[A-Z])\s?(\d[A-Z]\d)\b", re.I)
UK_POSTAL_RE = re.compile(r"\b([A-Z]{1,2}\d[A-Z\d]?)\s*(\d[A-Z]{2})\b", re.I)
PL_POSTAL_RE = re.compile(r"\b(\d{2})-(\d{3})\b")
JP_POSTAL_RE = re.compile(r"\b(\d{3})-(\d{4})\b")
BR_POSTAL_RE = re.compile(r"\b(\d{5})-(\d{3})\b")
GENERIC_POSTAL_RE = re.compile(r"\b(\d{5})\b")


def ascii_text(value: str) -> str:
    text = value or ""
    text = (
        text.replace("ß", "ss")
        .replace("ä", "ae")
        .replace("ö", "oe")
        .replace("ü", "ue")
        .replace("Ä", "Ae")
        .replace("Ö", "Oe")
        .replace("Ü", "Ue")
        .replace("\u00ba", "o")
        .replace("\u00b0", "")
    )
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = re.sub(r"(\d)o\b", r"\1", text)
    text = HASH_RE.sub("", text)
    text = re.sub(r"\s+", " ", text).strip(" ,")
    return text


def clean(value: str) -> str:
    return ascii_text(value or "")


def fix_typos(value: str) -> str:
    text = value
    for pattern, repl in TYPO_FIXES:
        text = pattern.sub(repl, text)
    return text


def fmt_coord(value) -> str:
    if value is None or value == "":
        return ""
    number = float(value)
    if not (-90 <= number <= 90 or abs(number) <= 180):
        pass
    rendered = f"{number:.7f}".rstrip("0").rstrip(".")
    return rendered


def country_tuple(raw: str) -> tuple[str, str, str] | None:
    key = clean(raw).lower().rstrip(".")
    if key in COUNTRY_MAP:
        return COUNTRY_MAP[key]
    key2 = clean(raw).lower()
    return COUNTRY_MAP.get(key2)


def expand_state(raw: str, iso3: str) -> str:
    token = clean(raw)
    if not token:
        return ""
    upper = token.upper()
    if iso3 == "USA" and upper in US_ABBREV:
        return US_ABBREV[upper]
    if iso3 == "CAN" and upper in CA_ABBREV:
        return CA_ABBREV[upper]
    if iso3 == "BRA" and upper in BR_ABBREV:
        return BR_ABBREV[upper]
    return token


def is_region_phrase(text: str) -> bool:
    low = text.lower()
    return any(word in low for word in REGION_WORDS)


def load_next(path: Path) -> dict:
    html = path.read_text(encoding="utf-8", errors="replace")
    match = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', html)
    if not match:
        raise SystemExit(f"No __NEXT_DATA__ in {path}")
    return json.loads(match.group(1))


def walk_text(node, out: list[str]) -> None:
    if isinstance(node, dict):
        if isinstance(node.get("text"), str):
            out.append(node["text"])
        for value in node.values():
            walk_text(value, out)
    elif isinstance(node, list):
        for value in node:
            walk_text(value, out)


def rich_text(node) -> str:
    parts: list[str] = []
    walk_text(node, parts)
    return clean(" ".join(parts))


def rich_lines(node) -> list[str]:
    """Split a Contentstack rich-text address into non-empty lines."""
    lines: list[str] = []

    def walk(n):
        if isinstance(n, dict):
            if n.get("type") in {"p", "li"} or "children" in n and n.get("type") not in {None, "doc"}:
                bits: list[str] = []
                walk_text(n.get("children"), bits)
                line = clean(" ".join(bits))
                if line:
                    lines.append(line)
                return
            for value in n.values():
                walk(value)
        elif isinstance(n, list):
            for value in n:
                walk(value)

    walk(node)
    # The walker above can duplicate nested children. Fall back to a
    # paragraph split of the flattened text when that happens.
    if len(lines) > 12:
        text = rich_text(node)
        lines = [clean(part) for part in re.split(r"\s{2,}", text) if clean(part)]
    # De-duplicate while preserving order.
    seen = set()
    unique = []
    for line in lines:
        if line not in seen:
            seen.add(line)
            unique.append(line)
    return unique


def phone_from(content_node) -> str:
    text = rich_text(content_node)
    text = re.split(r"\bFax\b", text, maxsplit=1, flags=re.I)[0]
    text = re.sub(r"\bMain:\s*", "", text).strip()
    match = re.search(r"(\+?\s*\d[\d\s().-]{6,}\d)", text)
    if not match:
        return ""
    phone = clean(match.group(1))
    return re.sub(r"\+\s+", "+", phone)


def activity_for(types) -> str:
    if isinstance(types, str):
        types = [types]
    labels = []
    for item in types or []:
        label = ACTIVITY_LABELS.get(item, clean(item))
        if label and label not in labels:
            labels.append(label)
    return "; ".join(labels) or "Power generation"


def scope_for(name: str, status: str, ownership: str, activity: str) -> tuple[str, str]:
    status_key = (status or "").strip().lower()
    own_key = (ownership or "").strip().lower()
    detail = name or "facility"
    if status_key in CONSTRUCTION_STATUSES:
        label = status or "not yet operating"
        return (
            "Out-of-Scope",
            f"Out-of-scope: unconfirmed construction: {detail} is marked {label} on the Invenergy project portfolio",
        )
    if own_key in THIRD_PARTY_VALUES:
        return (
            "Out-of-Scope",
            f"Out-of-scope: completed project not owned: {detail} is marked Third-Party ownership on the Invenergy project portfolio",
        )
    kind = activity or "power"
    if own_key in OWNED_VALUES:
        return (
            "In-Scope",
            f"In-scope: operational site: {detail} is an operating {kind} asset marked Invenergy-owned on the project portfolio",
        )
    return (
        "In-Scope",
        f"In-scope: operational site: {detail} is listed as an operating {kind} asset on the Invenergy project portfolio",
    )


def project_place(loc: dict, iso3: str, short_country: str) -> tuple[str, str, list[str], list[str]]:
    """Return city, state, qa flags, qa notes."""
    notes: list[str] = []
    flags: list[str] = []
    raw_cc = loc.get("city_county") or ""
    fixed = fix_typos(clean(raw_cc))
    if fixed != clean(raw_cc):
        flags.append("fixed")
        notes.append(f"Corrected locality typo '{clean(raw_cc)}' to '{fixed}'")

    parts = [part.strip() for part in fixed.split(",") if part.strip()]
    country_aliases = set(COUNTRY_MAP) | {short_country.lower(), "scotland", "u.s"}
    parts = [part for part in parts if part.lower().rstrip(".") not in country_aliases]

    state_cms = expand_state(loc.get("state") or "", iso3)
    joined = ", ".join(parts)

    city = ""
    state_name = state_cms

    # A leading town plus one admin area ("Cumnock, East Ayrshire Council area").
    # Do not split a multi-county list ("Garfield, Kingfisher & Major Counties").
    if (
        len(parts) >= 2
        and not is_region_phrase(parts[0])
        and is_region_phrase(parts[-1])
        and not re.search(r"count|parish", parts[-1], re.I)
    ):
        city = parts[0]
        state_name = re.sub(r"\s+Council area$", "", parts[-1], flags=re.I).strip() or state_cms
    elif parts and is_region_phrase(joined):
        state_raw = (loc.get("state") or "").strip()
        non_state = [
            part for part in parts
            if part.lower() != (state_cms or "").lower() and part.upper() != state_raw.upper()
        ]
        city = ", ".join(non_state) if non_state else joined
        flags.append("CITY")
        notes.append(f"CITY '{city}' is a county, parish, or region rather than a city")
        if state_cms and state_cms.lower() not in joined.lower() and len(state_cms) > 2:
            # CMS state disagrees with the published region. Keep the region.
            if not (iso3 == "USA" and (loc.get("state") or "").upper() in US_ABBREV):
                region = parts[0]
                if region and not is_region_phrase(state_cms):
                    state_name = region
                    notes.append(
                        f"STATE '{state_cms}' conflicts with published region '{region}'; kept the published region"
                    )
                    flags.append("STATE")
        if iso3 == "USA" and (loc.get("state") or "").upper() in US_ABBREV:
            state_name = state_cms
    elif parts and state_cms and parts[0].lower() == state_cms.lower():
        city = parts[0]
        flags.append("CITY")
        notes.append(f"CITY '{city}' matches the state and no city was published")
    elif (
        parts
        and state_cms
        and state_cms.lower() not in joined.lower()
        and len((loc.get("state") or "")) > 2
        and not is_region_phrase(state_cms)
        and (loc.get("state") or "").upper() not in US_ABBREV
    ):
        # CMS put the city in the state field and the admin area in city_county.
        city = state_cms
        state_name = parts[0]
        flags.append("fixed")
        notes.append(
            f"Swapped CMS fields: city '{city}' was in the state field and '{state_name}' was in city_county"
        )
    elif parts:
        city = parts[0]
        if len(parts) >= 2 and not state_name:
            state_name = parts[-1]
        if is_region_phrase(city):
            flags.append("CITY")
            notes.append(f"CITY '{city}' is a county, parish, or region rather than a city")
    else:
        city = state_name
        flags.append("CITY")
        notes.append("No locality published; CITY set to the state")

    if city.lower() == short_country.lower():
        if "CITY_IS_COUNTRY" not in flags:
            flags.append("CITY_IS_COUNTRY")
            notes.append(f"CITY '{city}' matches the country name")

    return clean(city), clean(state_name), flags, notes


def compose_project_address(loc: dict, city: str, state_name: str, short_country: str) -> str:
    locality = fix_typos(clean(loc.get("city_county") or ""))
    locality = re.sub(r"\s+Council area\b", "", locality, flags=re.I)
    # Drop a trailing country token; it is re-added in the short English form.
    locality = re.sub(
        r",?\s*(U\.S\.A?\.?|United States|Canada|Mexico|Poland|Japan|Uruguay|"
        r"United Kingdom|Scotland|El Salvador|Brazil|Spain)\s*$",
        "",
        locality,
        flags=re.I,
    ).strip(" ,")
    address = locality
    if city and city.lower() not in address.lower():
        address = f"{city}, {address}" if address else city
    if state_name and state_name.lower() not in address.lower():
        abbrev = next((code for code, full in US_ABBREV.items() if full == state_name), "")
        if not abbrev or re.search(rf"\b{abbrev}\b", address) is None:
            address = f"{address}, {state_name}" if address else state_name
    if not re.search(rf",\s*{re.escape(short_country)}\s*$", address, flags=re.I):
        address = f"{address}, {short_country}" if address else short_country
    return clean(address)


def case_url_index(case_payload: dict) -> dict[str, str]:
    """Map case-study uid and url slug to an absolute case-study URL."""
    index: dict[str, str] = {}
    studies = case_payload["props"]["pageProps"].get(CASE_STUDIES_KEY) or []
    for study in studies:
        slug = study.get("url") or ""
        if not slug:
            continue
        absolute = BASE_URL + CASE_STUDIES_PAGE + (slug if slug.startswith("/") else "/" + slug)
        index[study.get("uid") or ""] = absolute
        index[slug] = absolute
        title = clean(study.get("title") or "")
        if title:
            index[title.lower()] = absolute
            # "Rusutsu Wind Farm" also matches a project titled "Rusutsu".
            for suffix in (
                " wind farm",
                " energy center",
                " wind and storage",
                " solar energy center",
            ):
                if title.lower().endswith(suffix):
                    short = title.lower()[: -len(suffix)].strip()
                    if short and short not in index:
                        index[short] = absolute
    return index


def relevant_url(project: dict, url_index: dict[str, str]) -> str:
    case = project.get("case_study") or {}
    if isinstance(case, dict):
        uid = case.get("uid") or ""
        slug = case.get("url") or ""
        if uid and uid in url_index:
            return url_index[uid]
        if slug and slug in url_index:
            return url_index[slug]
        if slug:
            return BASE_URL + CASE_STUDIES_PAGE + (slug if slug.startswith("/") else "/" + slug)
    title_key = clean(project.get("title") or "").lower()
    if title_key in url_index:
        return url_index[title_key]
    return BASE_URL + PROJECTS_PAGE


def build_project_row(project: dict, url_index: dict[str, str]) -> tuple[dict | None, dict | None, dict]:
    name = clean(project.get("title") or "")
    loc = project.get("location") or {}
    country_raw = loc.get("country") or ""
    mapped = country_tuple(country_raw)
    notes: list[str] = []
    flags: list[str] = []
    if not mapped:
        return None, {
            "FACILITY_NAME": name,
            "FACILITY_ADDRESS": loc.get("city_county") or "",
            "rejection_reason": f"Unrecognized country '{country_raw}'",
        }, {}
    region, iso3, short_country = mapped
    city, state_name, place_flags, place_notes = project_place(loc, iso3, short_country)
    flags.extend(place_flags)
    notes.extend(place_notes)
    address = compose_project_address(loc, city, state_name, short_country)
    lat = fmt_coord(loc.get("latitude"))
    lng = fmt_coord(loc.get("longitude"))
    try:
        lat_n = float(lat)
        lng_n = float(lng)
        if not (-90 <= lat_n <= 90 and -180 <= lng_n <= 180):
            raise ValueError
    except ValueError:
        return None, {
            "FACILITY_NAME": name,
            "FACILITY_ADDRESS": address,
            "LATITUDE": lat,
            "LONGITUDE": lng,
            "rejection_reason": "Coordinates missing or out of range",
        }, {}
    if not name or not address or not city:
        return None, {
            "FACILITY_NAME": name,
            "FACILITY_ADDRESS": address,
            "rejection_reason": "Name, address, or city missing",
        }, {}

    energy = ((project.get("energy_type") or {}).get("type")) or []
    activity = activity_for(energy)
    status = ((project.get("status") or {}).get("status")) or ""
    ownership = ((project.get("project_ownership") or {}).get("project_ownership")) or ""
    scope, reason = scope_for(name, status, ownership, activity)
    year = (project.get("statistics") or {}).get("operational_since")
    if status.strip().lower() in CONSTRUCTION_STATUSES and year:
        reason = f"{reason}; commercial operation date shown as {year}"

    row = {
        "ISSUER_ID": ISSUER_ID,
        "COMPANY_NAME": COMPANY_NAME,
        "FACILITY_NAME": name,
        "FACILITY_ADDRESS": address,
        "CITY": city,
        "STATE": state_name,
        "POSTAL_CODE": "",
        "FACILITY_REGION": region,
        "COUNTRY_ISO3": iso3,
        "LATITUDE": lat,
        "LONGITUDE": lng,
        "coord_source": "website",
        "ACTIVITY_AT_ASSET": activity,
        "FACILITY_CONTACT_NUMBER": "",
        "SCOPE": scope,
        "SCOPE_REASON": reason,
        "RELEVANT_URL": relevant_url(project, url_index),
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "VALIDATION_URL": "",
        "VALIDATION_SOURCE_TYPE": "",
        "QA_flag": "|".join(dict.fromkeys(flags)),
    }
    meta = {
        "uid": project.get("uid"),
        "status": status,
        "ownership": ownership,
        "notes": notes,
        "source": "project",
    }
    return row, None, meta


def parse_postal(text: str, iso3: str) -> str:
    if iso3 == "USA":
        match = US_ZIP_RE.search(text)
        return match.group(1) if match else ""
    if iso3 == "CAN":
        match = CA_POSTAL_RE.search(text)
        return f"{match.group(1).upper()} {match.group(2).upper()}" if match else ""
    if iso3 == "GBR":
        match = UK_POSTAL_RE.search(text)
        return f"{match.group(1).upper()} {match.group(2).upper()}" if match else ""
    if iso3 == "POL":
        match = PL_POSTAL_RE.search(text)
        return f"{match.group(1)}-{match.group(2)}" if match else ""
    if iso3 == "JPN":
        match = JP_POSTAL_RE.search(text)
        return f"{match.group(1)}{match.group(2)}" if match else ""
    if iso3 == "BRA":
        match = BR_POSTAL_RE.search(text)
        return f"{match.group(1)}-{match.group(2)}" if match else ""
    if iso3 in {"MEX", "ESP"}:
        match = GENERIC_POSTAL_RE.search(text)
        return match.group(1) if match else ""
    return ""


def office_activity(label: str) -> str:
    low = label.lower()
    if "headquarter" in low:
        return "Corporate headquarters"
    if "service" in low:
        return "Energy services office"
    return "Regional office"


def build_office_row(office: dict) -> tuple[dict | None, dict | None, dict]:
    title = clean(office.get("title") or office.get("name") or "")
    label = clean(office.get("label") or "Office")
    if label.lower() in title.lower():
        name = title
    else:
        name = clean(f"{title} {label}")
    country_raw = office.get("country") or ""
    mapped = country_tuple(country_raw)
    if not mapped:
        return None, {
            "FACILITY_NAME": name,
            "rejection_reason": f"Unrecognized office country '{country_raw}'",
        }, {}
    region, iso3, short_country = mapped
    lines = [line for line in rich_lines(office.get("address")) if not COMPANY_LINE_RE.search(line)]
    blob = ", ".join(lines)
    postal = parse_postal(blob, iso3)
    coords = office.get("coordinates") or {}
    lat = fmt_coord(coords.get("latitude"))
    lng = fmt_coord(coords.get("longitude"))
    city = ""
    state_name = ""
    flags: list[str] = []
    notes: list[str] = []

    # US-style "City, ST ZIP" on the last locality line.
    locality_line = ""
    for line in reversed(lines):
        if re.search(r",\s*[A-Z]{2}\b", line) or re.search(r"\b[A-Z]\d[A-Z]\s?\d[A-Z]\d\b", line, re.I):
            locality_line = line
            break
    if not locality_line and lines:
        locality_line = lines[-1]

    us_match = re.search(r"([A-Za-z .'-]+),\s*([A-Z]{2})\b", locality_line)
    if iso3 == "USA" and re.search(r"Washington,?\s*D\.?\s*C\.?", blob, re.I):
        city = "Washington"
        state_name = "District of Columbia"
    elif iso3 == "USA" and us_match:
        city = clean(us_match.group(1))
        state_name = expand_state(us_match.group(2), iso3)
    elif iso3 == "CAN":
        can_match = re.search(r"([A-Za-z .'-]+),\s*([A-Z]{2})\b", blob)
        if can_match:
            city = clean(can_match.group(1))
            state_name = expand_state(can_match.group(2), iso3)
        elif "Toronto" in blob:
            city, state_name = "Toronto", "Ontario"
        elif "Montreal" in blob:
            city, state_name = "Montreal", "Quebec"
    elif iso3 == "MEX":
        city = "Ciudad de Mexico"
        state_name = "Ciudad de Mexico"
    elif iso3 == "BRA":
        if "Natal" in blob:
            city, state_name = "Natal", "Rio Grande do Norte"
        else:
            city, state_name = "Sao Paulo", "Sao Paulo"
            if "Bareuri" in blob:
                flags.append("CITY")
                notes.append("Published locality 'Bareuri' with Sao Paulo; CITY kept as Sao Paulo")
    elif iso3 == "ESP":
        if "Somozas" in blob:
            city, state_name = "As Somozas", "A Coruna"
        else:
            city, state_name = "Madrid", "Madrid"
    elif iso3 == "GBR":
        city, state_name = "Edinburgh", "Scotland"
    elif iso3 == "POL":
        city, state_name = "Warsaw", "Mazowieckie"
    elif iso3 == "JPN":
        city, state_name = "Tokyo", "Tokyo"

    if city.lower() in {"chiyoda-ku", "chiyoda"}:
        city = "Tokyo"
        flags.append("fixed")
        notes.append("Ward name replaced with Tokyo")

    country_only = {
        short_country.lower(), "united states", "brazil", "spain", "japan",
        "poland", "canada", "mexico", "scotland", "united kingdom",
    }
    kept_lines = []
    for line in lines:
        if line.lower() in country_only:
            continue
        if COMPANY_LINE_RE.search(line) or re.search(r"\bz\s*o\.?\s*o\.?\b", line, re.I):
            continue
        kept_lines.append(line)
    address = ", ".join(kept_lines)
    if iso3 == "USA":
        for code, full in US_ABBREV.items():
            address = re.sub(rf",\s*{code}(?=\s+\d{{5}}\b|\s*,|\s*$)", f", {full}", address)
    if iso3 == "CAN":
        for code, full in CA_ABBREV.items():
            address = re.sub(
                rf",\s*{code}(?=\s+[A-Z]\d[A-Z]|\s*,|\s*$)",
                f", {full}",
                address,
            )
    if iso3 == "BRA":
        address = re.sub(r"\bRN\b", "Rio Grande do Norte", address)
    if city and city.lower() not in address.lower():
        address = f"{address}, {city}" if address else city
    if postal and postal.replace(" ", "").replace("-", "") not in address.replace(" ", "").replace("-", ""):
        address = f"{address} {postal}".strip()
    if state_name == "District of Columbia" and re.search(r"D\.?\s*C\.?", address):
        pass
    elif state_name and state_name.lower() not in address.lower() and iso3 in {"USA", "CAN", "BRA"}:
        address = f"{address}, {state_name}"
    if re.search(rf"\b{re.escape(short_country)}\s*$", address, flags=re.I):
        address = re.sub(
            rf"\s*,?\s*{re.escape(short_country)}\s*$",
            f", {short_country}",
            address,
            count=1,
            flags=re.I,
        )
    else:
        address = f"{address}, {short_country}" if address else short_country
    address = re.sub(
        rf"(?:,\s*{re.escape(short_country)}){{2,}}\s*$",
        f", {short_country}",
        address,
        flags=re.I,
    )
    address = clean(address)

    try:
        lat_n = float(lat)
        lng_n = float(lng)
        if not (-90 <= lat_n <= 90 and -180 <= lng_n <= 180):
            raise ValueError
    except ValueError:
        return None, {
            "FACILITY_NAME": name,
            "FACILITY_ADDRESS": address,
            "LATITUDE": lat,
            "LONGITUDE": lng,
            "rejection_reason": "Office coordinates missing or out of range",
        }, {}
    if not name or len(address) < 10 or not city:
        return None, {
            "FACILITY_NAME": name,
            "FACILITY_ADDRESS": address,
            "rejection_reason": "Office name, address, or city missing",
        }, {}

    activity = office_activity(label)
    row = {
        "ISSUER_ID": ISSUER_ID,
        "COMPANY_NAME": COMPANY_NAME,
        "FACILITY_NAME": name,
        "FACILITY_ADDRESS": address,
        "CITY": city,
        "STATE": state_name,
        "POSTAL_CODE": postal,
        "FACILITY_REGION": region,
        "COUNTRY_ISO3": iso3,
        "LATITUDE": lat,
        "LONGITUDE": lng,
        "coord_source": "website",
        "ACTIVITY_AT_ASSET": activity,
        "FACILITY_CONTACT_NUMBER": phone_from(office.get("content")),
        "SCOPE": "In-Scope",
        "SCOPE_REASON": f"In-scope: operational site: {name} is an Invenergy {activity.lower()} published on the projects page",
        "RELEVANT_URL": BASE_URL + PROJECTS_PAGE,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "VALIDATION_URL": "",
        "VALIDATION_SOURCE_TYPE": "",
        "QA_flag": "|".join(dict.fromkeys(flags)),
    }
    return row, None, {"notes": notes, "source": "office", "raw_lines": lines}


def validate_row(row: dict) -> list[str]:
    problems = []
    for column in (
        "FACILITY_NAME", "FACILITY_ADDRESS", "FACILITY_REGION", "COUNTRY_ISO3",
        "CITY", "ACTIVITY_AT_ASSET", "RELEVANT_URL", "SOURCE_TYPE", "coord_source",
        "SCOPE", "SCOPE_REASON",
    ):
        if not str(row.get(column) or "").strip():
            problems.append(f"blank {column}")
    if row["coord_source"] not in {"website", "Not from website"}:
        problems.append("bad coord_source")
    if "#" in row["FACILITY_ADDRESS"]:
        problems.append("hash in address")
    if re.search(r"approximately|located near|miles\b", row["FACILITY_ADDRESS"], re.I):
        problems.append("directions in address")
    if row["SCOPE"] not in {"In-Scope", "Out-of-Scope"}:
        problems.append("bad scope")
    return problems


def main() -> None:
    project_payload = load_next(HTML_PATH)
    case_payload = load_next(CASE_HTML_PATH)
    page_props = project_payload["props"]["pageProps"]
    projects = page_props[PROJECTS_KEY]
    offices = page_props.get(OFFICES_KEY) or []
    url_index = case_url_index(case_payload)

    kept = []
    rejected = []
    qa_rows = []
    seen = set()
    for project in projects:
        row, reject, meta = build_project_row(project, url_index)
        if reject:
            rejected.append(reject)
            continue
        key = (row["FACILITY_NAME"].lower(), row["LATITUDE"], row["LONGITUDE"], row["ACTIVITY_AT_ASSET"])
        if key in seen:
            rejected.append({**row, "rejection_reason": "Duplicate name and coordinates"})
            continue
        seen.add(key)
        problems = validate_row(row)
        if problems:
            rejected.append({**row, "rejection_reason": "; ".join(problems)})
            continue
        kept.append(row)
        qa_rows.append({"row": row, "meta": meta})

    for office in offices:
        row, reject, meta = build_office_row(office)
        if reject:
            rejected.append(reject)
            continue
        problems = validate_row(row)
        if problems:
            rejected.append({**row, "rejection_reason": "; ".join(problems)})
            continue
        kept.append(row)
        qa_rows.append({"row": row, "meta": meta})

    kept.sort(key=lambda row: (row["FACILITY_REGION"], row["STATE"], row["FACILITY_NAME"]))
    OUTPUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=COLUMNS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(kept)

    if rejected:
        with REJECT_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
            fields = sorted({key for item in rejected for key in item})
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rejected)
    elif REJECT_CSV.exists():
        REJECT_CSV.unlink()

    studies = case_payload["props"]["pageProps"].get(CASE_STUDIES_KEY) or []
    linked = 0
    for study in studies:
        url = url_index.get(study.get("uid") or "")
        if any(row["RELEVANT_URL"] == url for row in kept):
            linked += 1

    flag_counts: dict[str, int] = {}
    scope_counts: dict[str, int] = {}
    for row in kept:
        scope_counts[row["SCOPE"]] = scope_counts.get(row["SCOPE"], 0) + 1
        for flag in (row["QA_flag"] or "").split("|"):
            if flag:
                flag_counts[flag] = flag_counts.get(flag, 0) + 1

    sample_ids = set()
    samples = []
    def take(predicate):
        for item in qa_rows:
            row = item["row"]
            if id(row) in sample_ids:
                continue
            if predicate(row, item["meta"]):
                sample_ids.add(id(row))
                samples.append(item)
                return

    take(lambda row, meta: meta.get("source") == "project" and row["COUNTRY_ISO3"] == "USA")
    take(lambda row, meta: row["COUNTRY_ISO3"] == "CAN" and meta.get("source") == "project")
    take(lambda row, meta: row["COUNTRY_ISO3"] == "MEX" and meta.get("source") == "project")
    take(lambda row, meta: row["COUNTRY_ISO3"] == "POL")
    take(lambda row, meta: row["COUNTRY_ISO3"] == "JPN" and meta.get("source") == "project")
    take(lambda row, meta: row["COUNTRY_ISO3"] == "GBR" and meta.get("source") == "project")
    take(lambda row, meta: row["COUNTRY_ISO3"] == "SLV")
    take(lambda row, meta: row["COUNTRY_ISO3"] == "URY")
    take(lambda row, meta: "Third-Party" in row["SCOPE_REASON"])
    take(lambda row, meta: "unconfirmed construction" in row["SCOPE_REASON"] and "Contracted" in row["SCOPE_REASON"])
    take(lambda row, meta: "In Construction" in row["SCOPE_REASON"])
    take(lambda row, meta: "case-studies" in row["RELEVANT_URL"])
    take(lambda row, meta: ";" in row["ACTIVITY_AT_ASSET"])
    take(lambda row, meta: "CITY" in (row["QA_flag"] or ""))
    take(lambda row, meta: row["QA_flag"] == "CITY_IS_COUNTRY" or "CITY_IS_COUNTRY" in (row["QA_flag"] or ""))
    take(lambda row, meta: meta.get("source") == "office" and row["COUNTRY_ISO3"] == "USA")
    take(lambda row, meta: meta.get("source") == "office" and row["COUNTRY_ISO3"] == "BRA")
    take(lambda row, meta: meta.get("source") == "office" and row["COUNTRY_ISO3"] == "JPN")
    take(lambda row, meta: meta.get("source") == "office" and row["COUNTRY_ISO3"] == "POL")
    take(lambda row, meta: meta.get("source") == "office" and row["COUNTRY_ISO3"] == "ESP")
    take(lambda row, meta: meta.get("source") == "office" and row["COUNTRY_ISO3"] == "MEX")
    take(lambda row, meta: meta.get("source") == "office" and row["COUNTRY_ISO3"] == "GBR")
    take(lambda row, meta: meta.get("source") == "office" and row["CITY"] == "Orchard Park")
    take(lambda row, meta: "Guadalupe" in row["FACILITY_NAME"] or row["CITY"] == "Guadalupe")
    sample_target = max(5, (len(kept) * 10 + 99) // 100)
    while len(samples) < sample_target:
        for item in qa_rows:
            if id(item["row"]) not in sample_ids:
                sample_ids.add(id(item["row"]))
                samples.append(item)
                break
        else:
            break

    qa = {
        "issuer": ISSUER_NAME,
        "rows": len(kept),
        "rejected": len(rejected),
        "projects_in_payload": len(projects),
        "offices_in_payload": len(offices),
        "case_studies": len(studies),
        "case_studies_linked_to_a_row": linked,
        "scope_counts": scope_counts,
        "flag_counts": flag_counts,
        "sample_size": len(samples),
        "samples": [
            {
                "name": item["row"]["FACILITY_NAME"],
                "address": item["row"]["FACILITY_ADDRESS"],
                "city": item["row"]["CITY"],
                "state": item["row"]["STATE"],
                "country": item["row"]["COUNTRY_ISO3"],
                "activity": item["row"]["ACTIVITY_AT_ASSET"],
                "scope": item["row"]["SCOPE"],
                "qa_flag": item["row"]["QA_flag"],
                "url": item["row"]["RELEVANT_URL"],
                "lat": item["row"]["LATITUDE"],
                "lng": item["row"]["LONGITUDE"],
                "notes": item["meta"].get("notes"),
                "source": item["meta"].get("source"),
            }
            for item in samples
        ],
    }
    QA_JSON.write_text(json.dumps(qa, indent=2), encoding="utf-8")
    print(f"rows {len(kept)} rejected {len(rejected)} case_studies {len(studies)} linked {linked}")
    print("scope", scope_counts)
    print("flags", flag_counts)
    print("output", OUTPUT_CSV)


if __name__ == "__main__":
    main()
