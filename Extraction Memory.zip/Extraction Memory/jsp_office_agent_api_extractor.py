"""
Pattern: JSP Office/Agent Directory API + Companion Map JSON

This extractor handles sites where:
- an index page calls a servlet to list countries/regions,
- each country page calls the same servlet to return office/agent JSON, and
- a companion JSON file carries Google Maps embed URLs for some locations.

It also supports an optional corporate contact page with card-style building data.

Example reuse:
    ISSUER_NAME = "EXAMPLE SHIPPING COMPANY"
    COUNTRY_LIST_ACTION = "getContinentCtryList"
    COUNTRY_INFO_ACTION = "getLocOfficeInfo"
    TARGET_CONTINENT = "ASIA"
    ADDITIONAL_COUNTRY_CODES = ["AR"]

Usage:
    python jsp_office_agent_api_extractor.py
"""

from __future__ import annotations

import csv
import html
import json
import re
import ssl
import unicodedata
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

from bs4 import BeautifulSoup


# ============================================================
# CONFIGURATION - issuer-specific values only
# ============================================================
ISSUER_ID = "IID000000002165840"
ISSUER_NAME = "EVERGREEN MARINE CORP. (TAIWAN) LTD."

TARGET_CONTINENT = "ASIA"
ADDITIONAL_COUNTRY_CODES = ["AR"]
EXPECTED_MIN_COUNT = 126

BASE_URL = "https://www.evergreen-line.com"
CONTINENT_INDEX_URL = (
    "https://www.evergreen-line.com/officesagents/jsp/OFCAG_Index.jsp?continents=ASIA"
)
COUNTRY_PAGE_TEMPLATE = (
    "https://www.evergreen-line.com/officesagents/jsp/OFCAG_CountryInfo.jsp?countryCode={country_code}"
)
OFFICE_API_URL = "https://www.evergreen-line.com/servlet/OFCAG_OfficeAgentController.do"
MAP_JSON_URL = "https://www.evergreen-line.com/officesagents/json/OFCAG_LocOfficeImgInfo.json"
CONTACT_INFO_URL = (
    "https://www.evergreen-marine.com/emc/aboutevergreen/jsp/EMC_ContactInformation.jsp?lang=en"
)
CSR_URL = "https://csr.evergreen-marine.com/csr/jsp/CSR_AboutEvergreen.jsp"
NEWS_DETAIL_URL = (
    "https://www.evergreen-marine.com/emc/latestnews/jsp/EMC_NewsDetail.jsp"
    "?lang=en&newsId=NEWS2023081400016397"
)

TEMP_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp"
)
OUTPUT_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output"
)
FINAL_FILENAME = f"{ISSUER_ID}_{ISSUER_NAME}.csv"


FIELDNAMES = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS",
    "LOCATION_ADDRESS_NATIVE",
    "LATITUDE",
    "LONGITUDE",
    "coord_source",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
]


COUNTRY_ISO3 = {
    "AM": "ARM",
    "AR": "ARG",
    "AZ": "AZE",
    "BD": "BGD",
    "BH": "BHR",
    "BN": "BRN",
    "CN": "CHN",
    "GE": "GEO",
    "HK": "HKG",
    "ID": "IDN",
    "IL": "ISR",
    "IN": "IND",
    "IQ": "IRQ",
    "JO": "JOR",
    "JP": "JPN",
    "KH": "KHM",
    "KR": "KOR",
    "KW": "KWT",
    "LB": "LBN",
    "LK": "LKA",
    "MO": "MAC",
    "MY": "MYS",
    "OM": "OMN",
    "PH": "PHL",
    "PK": "PAK",
    "QA": "QAT",
    "SA": "SAU",
    "SG": "SGP",
    "TH": "THA",
    "TW": "TWN",
    "AE": "ARE",
    "VN": "VNM",
    "YE": "YEM",
}


POSTCODE_PATTERNS = [
    re.compile(r"\b[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}\b", re.I),  # UK style
    re.compile(r"\b[A-Z]\d[A-Z]\s?\d[A-Z]\d\b", re.I),  # Canada style
    re.compile(r"\b\d{3}-\d{4}\b"),  # Japan style
    re.compile(r"\b\d{5}(?:-\d{4})?\b"),
    re.compile(r"\b\d{6}\b"),
    re.compile(r"\b\d{4}\b"),
    re.compile(r"\b[A-Z0-9]{3,10}\b", re.I),
]


def build_ssl_context() -> ssl.SSLContext:
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


SSL_CONTEXT = build_ssl_context()


def fetch_text(url: str, data: Optional[dict] = None) -> str:
    encoded = None
    headers = {"User-Agent": "Mozilla/5.0"}
    if data is not None:
        encoded = urllib.parse.urlencode(data).encode("utf-8")
        headers["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8"
    request = urllib.request.Request(url, data=encoded, headers=headers)
    with urllib.request.urlopen(request, context=SSL_CONTEXT, timeout=60) as response:
        return response.read().decode("utf-8", "ignore")


def fetch_json(url: str, data: Optional[dict] = None) -> dict:
    return json.loads(fetch_text(url, data))


def normalize_whitespace(text: str) -> str:
    text = html.unescape(text or "")
    text = text.replace("\xa0", " ")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def clean_native(text: str) -> str:
    return normalize_whitespace(text)


def transliterate_ascii(text: str) -> str:
    text = clean_native(text)
    # Replace hash markers with a geocoding-friendly "No." when used as a number prefix.
    text = re.sub(r"#\s*([A-Za-z0-9-]+)", r"No. \1", text)
    text = text.replace("#", "")
    text = text.replace("：", ":")
    text = unicodedata.normalize("NFKD", text)
    text = text.encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\s+,", ",", text)
    return text.strip(" ,")


def parse_coords_from_map_src(map_src: str) -> Tuple[str, str]:
    if not map_src:
        return "", ""

    patterns = [
        re.compile(r"!2d(?P<lng>-?\d+(?:\.\d+)?)!3d(?P<lat>-?\d+(?:\.\d+)?)"),
        re.compile(r"!3d(?P<lat>-?\d+(?:\.\d+)?)!4d(?P<lng>-?\d+(?:\.\d+)?)"),
    ]
    for pattern in patterns:
        match = pattern.search(map_src)
        if match:
            lat = match.group("lat")
            lng = match.group("lng")
            return lat, lng
    return "", ""


def extract_postcode(address: str) -> str:
    cleaned = transliterate_ascii(address)
    tokens = [token.strip(" ,.;") for token in cleaned.split(",") if token.strip()]
    candidates = list(reversed(tokens)) if tokens else [cleaned]
    for candidate in candidates:
        for pattern in POSTCODE_PATTERNS:
            matches = pattern.findall(candidate)
            if matches:
                # Avoid returning plain city/country text from the generic pattern.
                value = matches[-1]
                if any(char.isdigit() for char in value):
                    return value.upper()
    return ""


def infer_city(raw_city: str, loc_name: str, address: str) -> str:
    def strip_postcode(candidate: str) -> str:
        candidate = transliterate_ascii(candidate)
        candidate = re.sub(r"\b\d{3}-\d{4}\b", "", candidate)
        candidate = re.sub(r"\b\d{3,6}(?:-\d{4})?\b", "", candidate)
        candidate = re.sub(r"\s+", " ", candidate)
        return candidate.strip(" ,")

    city = transliterate_ascii(raw_city)
    if city and city not in {"-", "--"}:
        return strip_postcode(city)

    loc_city = transliterate_ascii(loc_name)
    if loc_city:
        return strip_postcode(loc_city)

    parts = [transliterate_ascii(part) for part in address.split(",") if part.strip()]
    if parts:
        candidate = parts[-2] if len(parts) >= 2 else parts[-1]
        return strip_postcode(candidate)
    return ""


def infer_state(address: str, city: str, country: str) -> str:
    parts = [transliterate_ascii(part) for part in address.split(",") if part.strip()]
    if len(parts) < 2:
        return ""

    # Look for the segment immediately after the city if the address contains both city and region.
    city_upper = city.upper()
    country_upper = country.upper()
    for idx, part in enumerate(parts):
        if part.upper() == city_upper and idx + 1 < len(parts):
            next_part = parts[idx + 1]
            next_upper = next_part.upper()
            if next_upper == city_upper:
                return ""
            if "BOX" in next_upper:
                return ""
            if next_upper != country_upper and extract_postcode(next_part) != next_part:
                return next_part
    return ""


def activity_from_office_type(ofc_type: str) -> str:
    mapping = {
        "Q": "Shipping headquarters / container shipping office",
        "H": "Shipping head office / container shipping office",
        "A": "Shipping agent / container shipping office",
        "S": "Shipping sub-agent / container shipping office",
        "P": "Port agency / container shipping office",
    }
    return mapping.get(ofc_type, "Container shipping office")


def make_dedupe_key(record: dict) -> str:
    parts = [
        transliterate_ascii(record["LOCATION_NAME"]).upper(),
        transliterate_ascii(record["LOCATION_ADDRESS"]).upper(),
        record["COUNTRY_ISO3"].upper(),
    ]
    return "|".join(parts)


def save_csv(records: Iterable[dict], path: Path) -> None:
    rows = list(records)
    rows.sort(key=lambda row: (row["COUNTRY"], row["CITY"], row["LOCATION_NAME"], row["LOCATION_ADDRESS"]))
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDNAMES, quoting=csv.QUOTE_ALL)
        writer.writeheader()
        writer.writerows(rows)


def add_record(records_by_key: Dict[str, dict], record: dict) -> bool:
    if not record["LOCATION_ADDRESS"] or not record["CITY"]:
        return False
    key = make_dedupe_key(record)
    if key in records_by_key:
        return False
    records_by_key[key] = record
    return True


def country_page_url(country_code: str) -> str:
    return COUNTRY_PAGE_TEMPLATE.format(country_code=country_code)


def get_relevant_countries() -> List[Tuple[str, str]]:
    payload = fetch_json(OFFICE_API_URL, {"action": "getContinentCtryList"})
    all_country_map: Dict[str, str] = {}
    relevant: List[Tuple[str, str]] = []

    for continent in payload.get("data", []):
        for country in continent.get("countryList", []):
            all_country_map[country["countryCode"]] = country["countryName"]
        if continent.get("continentName") == TARGET_CONTINENT:
            relevant.extend(
                (country["countryCode"], country["countryName"])
                for country in continent.get("countryList", [])
            )

    for country_code in ADDITIONAL_COUNTRY_CODES:
        if country_code not in {code for code, _ in relevant} and country_code in all_country_map:
            relevant.append((country_code, all_country_map[country_code]))

    return relevant


def get_map_lookup() -> Dict[Tuple[str, str], Tuple[str, str]]:
    lookup: Dict[Tuple[str, str], Tuple[str, str]] = {}
    payload = fetch_json(MAP_JSON_URL)
    for country in payload.get("data", []):
        country_code = country.get("ctryCode", "")
        for item in country.get("locOfficeImgInfo", []):
            loc_code = item.get("locCode", "")
            lat, lng = parse_coords_from_map_src(item.get("mapSrc", ""))
            if country_code and loc_code and lat and lng:
                lookup[(country_code, loc_code)] = (lat, lng)
    return lookup


def build_api_record(
    country_code: str,
    country_name: str,
    loc_code: str,
    loc_name: str,
    office: dict,
    coords_lookup: Dict[Tuple[str, str], Tuple[str, str]],
) -> dict:
    name_native = clean_native(office.get("bascEName") or office.get("ofcName") or loc_name)
    address_native = clean_native(office.get("bascEAdrs", ""))
    city = infer_city(office.get("bascECity", ""), loc_name, address_native)
    lat, lng = coords_lookup.get((country_code, loc_code), ("", ""))

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": transliterate_ascii(name_native),
        "LOCATION_NAME_NATIVE": name_native,
        "LOCATION_ADDRESS": transliterate_ascii(address_native),
        "LOCATION_ADDRESS_NATIVE": address_native,
        "LATITUDE": lat,
        "LONGITUDE": lng,
        "coord_source": "website" if lat and lng else "not_on_website",
        "COUNTRY": country_name,
        "COUNTRY_ISO3": COUNTRY_ISO3[country_code],
        "POSTCODE": extract_postcode(address_native),
        "STATE": infer_state(address_native, city, country_name),
        "CITY": city,
        "SOURCE_URL": country_page_url(country_code),
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": activity_from_office_type(office.get("ofcType", "")),
    }


def extract_contact_records() -> List[dict]:
    html_text = fetch_text(CONTACT_INFO_URL)
    soup = BeautifulSoup(html_text, "html.parser")
    records: List[dict] = []

    for iframe in soup.select('iframe[title*="Building"]'):
        card = iframe.find_parent("div", class_="card")
        if not card:
            continue

        title_tag = card.find("h4")
        building_name = clean_native(title_tag.get_text(" ", strip=True) if title_tag else iframe.get("title", ""))

        address_native = ""
        for text_node in card.stripped_strings:
            text = clean_native(text_node)
            if text.startswith("Address:") or text.startswith("Address："):
                address_native = text.split(":", 1)[-1].strip() if ":" in text else text.split("：", 1)[-1].strip()
                break

        lat, lng = parse_coords_from_map_src(iframe.get("src", ""))
        country_name = "Taiwan"
        record = {
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": transliterate_ascii(building_name),
            "LOCATION_NAME_NATIVE": building_name,
            "LOCATION_ADDRESS": transliterate_ascii(address_native),
            "LOCATION_ADDRESS_NATIVE": address_native,
            "LATITUDE": lat,
            "LONGITUDE": lng,
            "coord_source": "website" if lat and lng else "not_on_website",
            "COUNTRY": country_name,
            "COUNTRY_ISO3": "TWN",
            "POSTCODE": extract_postcode(address_native),
            "STATE": "",
            "CITY": infer_city("", "", address_native),
            "SOURCE_URL": CONTACT_INFO_URL,
            "SOURCE_TYPE": "COMPANY WEBSITE",
            "ACTIVITY_AT_ASSET": "Corporate office",
        }
        records.append(record)

    return records


def extract_csr_confirmation() -> List[dict]:
    html_text = fetch_text(CSR_URL)
    soup = BeautifulSoup(html_text, "html.parser")
    rows: List[dict] = []
    for tr in soup.select("tr"):
        cells = [clean_native(td.get_text(" ", strip=True)) for td in tr.select("td")]
        if len(cells) != 2:
            continue
        if cells[0] == "Headquarters Location":
            address_native = cells[1]
            rows.append(
                {
                    "ISSUER_ID": ISSUER_ID,
                    "ISSUER_NAME": ISSUER_NAME,
                    "LOCATION_NAME": "Headquarters Location",
                    "LOCATION_NAME_NATIVE": "Headquarters Location",
                    "LOCATION_ADDRESS": transliterate_ascii(address_native),
                    "LOCATION_ADDRESS_NATIVE": address_native,
                    "LATITUDE": "",
                    "LONGITUDE": "",
                    "coord_source": "not_on_website",
                    "COUNTRY": "Taiwan",
                    "COUNTRY_ISO3": "TWN",
                    "POSTCODE": extract_postcode(address_native),
                    "STATE": "",
                    "CITY": infer_city("", "", address_native),
                    "SOURCE_URL": CSR_URL,
                    "SOURCE_TYPE": "COMPANY WEBSITE",
                    "ACTIVITY_AT_ASSET": "Corporate office",
                }
            )
    return rows


def extract_news_exclusion_note() -> str:
    html_text = fetch_text(
        "https://www.evergreen-marine.com/emc/servlet/LN_LatestNewsController.do",
        {
            "action": "getNewsDetail",
            "newsId": "NEWS2023081400016397",
            "langCode": "en",
        },
    )
    payload = json.loads(html_text)
    items = payload.get("data", [])
    if not items:
        return "News detail page returned no extractable facility content."

    title = clean_native(items[0].get("newsTitle", ""))
    content_text = BeautifulSoup(items[0].get("newsContent", ""), "html.parser").get_text(" ", strip=True)
    if "Terminal 7 at Kaohsiung Port" in content_text or "Terminal 7" in title:
        return (
            "Supplied news page describes Terminal 7 at Kaohsiung Port and other dedicated terminals, "
            "but it does not provide street-level addresses suitable for the required non-blank address field; "
            "those facilities were therefore not added to the CSV."
        )
    return "News detail page did not add any unique addressable facility beyond the office/contact sources."


def main() -> None:
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    relevant_countries = get_relevant_countries()
    coords_lookup = get_map_lookup()

    records_by_key: Dict[str, dict] = {}
    progress_path = TEMP_DIR / f"{ISSUER_ID}_progress.csv"
    checkpoint_path = TEMP_DIR / f"{ISSUER_ID}_checkpoint_{EXPECTED_MIN_COUNT}.csv"
    final_temp_path = TEMP_DIR / FINAL_FILENAME
    final_output_path = OUTPUT_DIR / FINAL_FILENAME

    checkpoint_written = False
    processed_count = 0

    for country_code, country_name in relevant_countries:
        payload = fetch_json(
            OFFICE_API_URL,
            {"action": "getLocOfficeInfo", "ctry": country_code},
        )
        country_data = payload.get("data", {})
        for loc in country_data.get("LocOfficeInfo", []) or []:
            loc_code = loc.get("locCode", "")
            loc_name = clean_native(loc.get("locName", ""))
            for office in loc.get("officeList", []) or []:
                record = build_api_record(
                    country_code=country_code,
                    country_name=country_name,
                    loc_code=loc_code,
                    loc_name=loc_name,
                    office=office,
                    coords_lookup=coords_lookup,
                )
                if add_record(records_by_key, record):
                    processed_count += 1
                    if processed_count % 20 == 0:
                        save_csv(records_by_key.values(), progress_path)
                    if processed_count >= EXPECTED_MIN_COUNT and not checkpoint_written:
                        save_csv(records_by_key.values(), checkpoint_path)
                        checkpoint_written = True

    for record in extract_contact_records():
        if add_record(records_by_key, record):
            processed_count += 1
            if processed_count % 20 == 0:
                save_csv(records_by_key.values(), progress_path)

    for record in extract_csr_confirmation():
        if add_record(records_by_key, record):
            processed_count += 1

    save_csv(records_by_key.values(), final_temp_path)
    save_csv(records_by_key.values(), final_output_path)

    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "target_continent": TARGET_CONTINENT,
        "additional_country_codes": ADDITIONAL_COUNTRY_CODES,
        "country_count": len(relevant_countries),
        "final_record_count": len(records_by_key),
        "expected_min_count": EXPECTED_MIN_COUNT,
        "checkpoint_written": checkpoint_written,
        "final_temp_csv": str(final_temp_path),
        "final_output_csv": str(final_output_path),
        "news_gap_note": extract_news_exclusion_note(),
    }
    (TEMP_DIR / f"{ISSUER_ID}_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
