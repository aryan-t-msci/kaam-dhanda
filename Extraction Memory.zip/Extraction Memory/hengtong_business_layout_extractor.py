"""
Hengtong business-layout extractor.

Parses the official Hengtong business-layout page and expands bundled address
blocks into one row per facility. Category B reusable script.
"""

from __future__ import annotations

import csv
import re
from pathlib import Path

import requests
from bs4 import BeautifulSoup


ISSUER_ID = "IID000000002171890"
ISSUER_NAME = "Hengtong Optic-Electric CO.,LTD"
SOURCE_URL = "https://www.hengtonggroup.com/en/home/company/business.html"
OUTPUT_DIR = Path(".")
OUTPUT_CSV = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"

HEADERS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
]


def parse_blocks() -> list[dict]:
    html = requests.get(SOURCE_URL, timeout=30, verify=False, headers={"User-Agent": "Mozilla/5.0"}).text
    soup = BeautifulSoup(html, "html.parser")
    text = soup.get_text("\n", strip=True)
    blocks = re.findall(r"Add:\s*(.+?)(?=Add:|$)", text, re.S)
    rows: list[dict] = []
    for block in blocks:
        normalized = " ".join(block.split())
        if "Headquarters:" in normalized and "PMB Plant:" in normalized:
            parts = re.findall(r"(Headquarters|PMB Plant|PE Plant):\s*(.*?)(?=(?:Headquarters|PMB Plant|PE Plant):|$)", normalized)
            for label, addr in parts:
                rows.append(make_row(label, addr))
        elif "Factory and Operational Office:" in normalized:
            parts = re.findall(r"(Factory and Operational Office|Executive Office):\s*(.*?)(?=(?:Factory and Operational Office|Executive Office):|$)", normalized)
            for label, addr in parts:
                rows.append(make_row(label, addr))
        else:
            rows.append(make_row("Business Layout Facility", normalized))
    return rows


def make_row(name: str, address: str) -> dict:
    country = ""
    iso3 = ""
    state = ""
    city = ""
    if "South Africa" in address or "Germiston" in address or "Pietermaritzburg" in address or "Gqeberha" in address:
        country, iso3 = "South Africa", "ZAF"
    elif "Indonesia" in address or "Jakarta" in address or "Bogor" in address:
        country, iso3 = "Indonesia", "IDN"
    elif "Mexico" in address:
        country, iso3 = "Mexico", "MEX"
    elif "Spain" in address:
        country, iso3 = "Spain", "ESP"
    city_match = re.search(r"(Germiston|Pietermaritzburg|Gqeberha|Bogor|Jakarta|Madrid|Queretaro)", address)
    if city_match:
        city = city_match.group(1)
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": name,
        "LOCATION_ADDRESS": address,
        "LATITUDE": "",
        "LONGITUDE": "",
        "COUNTRY": country,
        "COUNTRY_ISO3": iso3,
        "POSTCODE": "",
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": SOURCE_URL,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Business layout location",
        "coord_source": "Not from website",
    }


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    rows = parse_blocks()
    with OUTPUT_CSV.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=HEADERS)
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()
