"""
multi_source_corporate_location_extractor.py
=============================================
Generalized extractor for corporate annual report PDFs + contact HTML pages.
Handles: pdfplumber text extraction + BeautifulSoup static HTML card parsing.

Configured for: INFOSYS LIMITED
Sources:
  1. global-presence2025.pdf   — pages 7-23, country-grouped address blocks
  2. infosys_americas.html     — static HTML div.offering-hover sections
  3. infosys_apac.html         — static HTML
  4. infosys_europe.html       — static HTML
  5. infosys_mea.html          — static HTML
  6. infosys_china.html        — BPM China page (infosysbpm.com)
  7. Infosys Foundation USA    — hardcoded from Google Maps pin

Usage: python infosys_global_extractor.py
Output: IID000000002170602_INFOSYS LIMITED.csv in Output folder
"""

import sys, io, re, os, json, unicodedata
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import pdfplumber
from bs4 import BeautifulSoup
import pandas as pd
from pathlib import Path

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
ISSUER_ID   = "IID000000002170602"
ISSUER_NAME = "INFOSYS LIMITED"
TEMP_DIR    = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")
OUTPUT_DIR  = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")

PDF_GLOBAL  = TEMP_DIR / "infosys_global_presence2025.pdf"
PDF_20F     = TEMP_DIR / "infosys_form20f_2023.pdf"
HTML_FILES  = {
    "Americas":     TEMP_DIR / "infosys_americas.html",
    "Asia Pacific": TEMP_DIR / "infosys_apac.html",
    "Europe":       TEMP_DIR / "infosys_europe.html",
    "MEA":          TEMP_DIR / "infosys_mea.html",
    "China BPM":    TEMP_DIR / "infosys_china.html",
}

CHECKPOINT_FILE = TEMP_DIR / f"{ISSUER_ID}_progress.json"
OUTPUT_FILE     = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"

SOURCE_PDF_URL  = "https://www.infosys.com/investors/reports-filings/documents/global-presence2025.pdf"
SOURCE_HTML_URLS = {
    "Americas":     "https://www.infosys.com/contact/country.html?region=Americas&subsidiary=Infosys",
    "Asia Pacific": "https://www.infosys.com/contact/country.html?region=Asia_X32_Pacific&subsidiary=Infosys",
    "Europe":       "https://www.infosys.com/contact/country.html?region=Europe&subsidiary=Infosys",
    "MEA":          "https://www.infosys.com/contact/country.html?region=Middle_X32_East_X32_and_X32_Africa&subsidiary=Infosys",
    "China BPM":    "https://www.infosysbpm.com/china.html",
}

# ═══════════════════════════════════════════════════════════
# COUNTRY → ISO3 MAPPING
# ═══════════════════════════════════════════════════════════
COUNTRY_ISO3 = {
    "India": "IND", "United States": "USA", "United States of America": "USA",
    "USA": "USA", "US": "USA",
    "Canada": "CAN", "Mexico": "MEX", "Brazil": "BRA", "Peru": "PER",
    "Chile": "CHL", "Argentina": "ARG", "Costa Rica": "CRI",
    "Puerto Rico": "PRI",
    "United Kingdom": "GBR", "UK": "GBR",
    "Germany": "DEU", "France": "FRA", "Netherlands": "NLD",
    "The Netherlands": "NLD", "Switzerland": "CHE", "Sweden": "SWE",
    "Norway": "NOR", "Denmark": "DNK", "Finland": "FIN",
    "Ireland": "IRL", "Belgium": "BEL", "Austria": "AUT",
    "Portugal": "PRT", "Spain": "ESP", "Italy": "ITA",
    "Poland": "POL", "Czech Republic": "CZE", "Hungary": "HUN",
    "Romania": "ROU", "Bulgaria": "BGR", "Serbia": "SRB",
    "Croatia": "HRV", "Slovakia": "SVK", "Latvia": "LVA",
    "Lithuania": "LTU", "Luxembourg": "LUX", "Malta": "MLT",
    "Liechtenstein": "LIE", "Guernsey": "GGY", "Jersey": "JEY",
    "Australia": "AUS", "New Zealand": "NZL", "Singapore": "SGP",
    "Japan": "JPN", "South Korea": "KOR", "Taiwan": "TWN",
    "China": "CHN", "Hong Kong": "HKG", "Malaysia": "MYS",
    "Philippines": "PHL", "Thailand": "THA", "Indonesia": "IDN",
    "United Arab Emirates": "ARE", "UAE": "ARE",
    "Saudi Arabia": "SAU", "Qatar": "QAT", "Oman": "OMN",
    "Israel": "ISR", "Turkey": "TUR", "Armenia": "ARM",
    "Mauritius": "MUS", "South Africa": "ZAF",
    "Sri Lanka": "LKA", "Pakistan": "PAK",
}

# ═══════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════

def transliterate(text):
    """Convert accented/special chars to closest ASCII equivalents."""
    if not text:
        return text
    # Handle German umlauts explicitly before NFKD
    german_map = {'ä': 'ae', 'ö': 'oe', 'ü': 'ue', 'ß': 'ss',
                  'Ä': 'Ae', 'Ö': 'Oe', 'Ü': 'Ue'}
    for orig, repl in german_map.items():
        text = text.replace(orig, repl)
    # NFKD normalization
    nfkd = unicodedata.normalize('NFKD', text)
    ascii_text = ''.join(c for c in nfkd if not unicodedata.combining(c))
    # Replace remaining non-ASCII with ?
    ascii_text = ascii_text.encode('ascii', 'replace').decode('ascii')
    ascii_text = ascii_text.replace('?', '')
    return re.sub(r'\s+', ' ', ascii_text).strip()


def clean_address(addr):
    """Remove # chars, normalize whitespace, make geocoding friendly."""
    if not addr:
        return addr
    addr = addr.replace('#', '').replace('  ', ' ')
    addr = re.sub(r'\s+', ' ', addr).strip()
    return addr


def infer_country_iso3(country_name):
    """Look up ISO3 from country name."""
    if not country_name:
        return ""
    # Direct lookup
    iso = COUNTRY_ISO3.get(country_name, "")
    if iso:
        return iso
    # Try partial match
    for k, v in COUNTRY_ISO3.items():
        if k.lower() in country_name.lower() or country_name.lower() in k.lower():
            return v
    return ""


def make_row(location_name, location_address, city, state, country, postcode,
             source_url, source_type, activity, lat="", lon="", coord_source="",
             location_name_native="", location_address_native=""):
    """Create a standardized row dict."""
    country_iso3 = infer_country_iso3(country)
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": transliterate(location_name) if location_name else "",
        "LOCATION_ADDRESS": clean_address(transliterate(location_address)) if location_address else "",
        "LATITUDE": lat,
        "LONGITUDE": lon,
        "COUNTRY": country,
        "COUNTRY_ISO3": country_iso3,
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": source_url,
        "SOURCE_TYPE": source_type,
        "ACTIVITY_AT_ASSET": activity,
        "coord_source": coord_source,
        "LOCATION_NAME_NATIVE": location_name_native,
        "LOCATION_ADDRESS_NATIVE": location_address_native,
    }


# ═══════════════════════════════════════════════════════════
# SOURCE 1: CONTACT HTML PAGES
# ═══════════════════════════════════════════════════════════

def parse_contact_html_page(html_path, region_name, source_url):
    """
    Parse Infosys contact/country HTML pages.
    Structure: div.row-fluid.offering-hover[id=Country] > div.offerings-row >
               [h2.offering-title (country)] + [div.col-md-3 > div.location-title h3 + div.location-text p]
    """
    records = []
    
    with open(html_path, 'rb') as f:
        soup = BeautifulSoup(f.read(), 'html.parser')
    
    # Find all country sections
    country_sections = soup.find_all('div', class_='row-fluid')
    
    for section in country_sections:
        # Get the country name from h2
        h2 = section.find('h2', class_='offering-title')
        if not h2:
            continue
        country_name = h2.get_text(strip=True)
        
        # Find all office location cards within this section
        # Each card is div.col-md-3 with location-title and location-text
        location_cards = section.find_all('div', class_=lambda c: c and 'col-md-3' in c and 'col-sm-12' not in c)
        
        # Better: find all location-text divs
        text_divs = section.find_all('div', class_='location-text')
        title_divs = section.find_all('div', class_='location-title')
        
        for i, text_div in enumerate(text_divs):
            # Get city from corresponding location-title
            city_name = ""
            if i < len(title_divs):
                h3 = title_divs[i].find('h3')
                if h3:
                    city_name = h3.get_text(strip=True)
            
            # Get address text
            p_tags = text_div.find_all('p')
            address_lines = []
            for p in p_tags:
                # Replace <br> with newlines
                for br in p.find_all('br'):
                    br.replace_with('\n')
                text = p.get_text(separator='\n').strip()
                address_lines.append(text)
            
            full_address = '\n'.join(address_lines).strip()
            
            if not full_address:
                continue
            
            # Parse address lines
            lines = [l.strip() for l in full_address.split('\n') if l.strip()]
            
            # Extract phone, fax - remove them from address
            addr_lines = []
            phone_pattern = re.compile(r'^(Phone|Tel|Fax|Email|http)', re.I)
            for line in lines:
                if phone_pattern.match(line) or re.match(r'^\+\d', line):
                    continue
                addr_lines.append(line)
            
            if not addr_lines:
                continue
            
            # Location name is often first line (company name) if it contains 'Infosys'
            loc_name = "Infosys"
            if addr_lines and ('infosys' in addr_lines[0].lower() or 'infy' in addr_lines[0].lower()):
                loc_name = addr_lines[0]
                addr_lines = addr_lines[1:]
            
            # Build clean address
            clean_addr = ', '.join(addr_lines)
            
            # Extract postcode
            postcode = ""
            # Common postal patterns
            pc_patterns = [
                r'\b(\d{5}-\d{4})\b',  # US ZIP+4
                r'\b(\d{5})\b',          # US/most
                r'\b([A-Z]{1,2}\d{1,2}[A-Z]?\s*\d[A-Z]{2})\b',  # UK
                r'\b([A-Z]\d[A-Z]\s*\d[A-Z]\d)\b',  # Canada
                r'\b(\d{4,6})\b',        # Generic
            ]
            for pattern in pc_patterns:
                m = re.search(pattern, clean_addr)
                if m:
                    postcode = m.group(1)
                    break
            
            # Extract state - for US addresses look for state abbreviation
            state = ""
            if country_name in ["United States", "USA"]:
                m = re.search(r'\b([A-Z]{2})\s+\d{5}', clean_addr)
                if m:
                    state = m.group(1)
            
            # Activity based on context
            activity = determine_activity(loc_name, city_name, clean_addr)
            
            row = make_row(
                location_name=loc_name or "Infosys Office",
                location_address=clean_addr,
                city=city_name or "",
                state=state,
                country=country_name,
                postcode=postcode,
                source_url=source_url,
                source_type="COMPANY WEBSITE",
                activity=activity,
            )
            records.append(row)
    
    print(f"  {region_name}: {len(records)} records from HTML")
    return records


def determine_activity(name, city, address):
    """Determine business activity from name/address context."""
    name_lower = str(name).lower()
    addr_lower = str(address).lower()
    
    if any(k in name_lower for k in ['development center', 'dc ', 'development centre']):
        return "Development Center"
    if any(k in name_lower for k in ['foundation']):
        return "Foundation / CSR Office"
    if any(k in name_lower for k in ['bpm', 'business process']):
        return "Business Process Management"
    if any(k in name_lower for k in ['consulting']):
        return "Consulting Office"
    if any(k in name_lower for k in ['automotive', 'mobility']):
        return "Automotive & Engineering Services"
    if any(k in name_lower for k in ['guidevision']):
        return "ServiceNow Consulting (GuideVision)"
    if any(k in name_lower for k in ['wongdoody']):
        return "Creative Services (WongDoody)"
    if any(k in name_lower for k in ['base life science']):
        return "Life Sciences Consulting (BASE)"
    if any(k in name_lower for k in ['in-tech']):
        return "Engineering Services (in-tech)"
    if any(k in name_lower for k in ['insemi']):
        return "Semiconductor Design (InSemi)"
    if any(k in name_lower for k in ['elbrus']):
        return "Technology Services (Elbrus Labs)"
    if any(k in name_lower for k in ['holding', 'management', 'gmbh', 'holding ag']):
        return "Corporate / Holdings Office"
    # Default
    return "Technology Services / Office"


# ═══════════════════════════════════════════════════════════
# SOURCE 2: PDF EXTRACTION (global-presence2025.pdf)
# ═══════════════════════════════════════════════════════════

# Mapping from country names as they appear in the PDF
PDF_COUNTRY_ALIASES = {
    "U.S.": "United States",
    "U.S.A": "United States",
    "USA": "United States",
    "U.K.": "United Kingdom",
    "UK": "United Kingdom",
    "UAE": "United Arab Emirates",
    "S. Korea": "South Korea",
    "Korea": "South Korea",
    "The Netherlands": "Netherlands",
}

def parse_global_presence_pdf(pdf_path):
    """
    Extract addresses from global-presence2025.pdf.
    Pages 7-23 contain address blocks grouped by country/region.
    Format varies but generally: City header line, then address block.
    """
    records = []
    
    with pdfplumber.open(pdf_path) as pdf:
        print(f"  PDF has {len(pdf.pages)} pages")
        
        # Pages 7-23 (0-indexed: 6-22) have address data
        for page_num in range(6, min(23, len(pdf.pages))):
            page = pdf.pages[page_num]
            text = page.extract_text() or ""
            
            # Parse structured address blocks from this page
            page_records = parse_pdf_page_text(text, page_num + 1, SOURCE_PDF_URL)
            records.extend(page_records)
            print(f"    Page {page_num+1}: {len(page_records)} records")
    
    print(f"  PDF total: {len(records)} records extracted")
    return records


def parse_pdf_page_text(text, page_num, source_url):
    """
    Parse one page of the global presence PDF.
    The format is multi-column with country headers and address blocks.
    Strategy: split by known country/city patterns and extract address blocks.
    """
    records = []
    
    # The PDF text is extracted column by column
    # Each address block typically has:
    # - City name line
    # - Company name (optional, has "Infosys")
    # - Street address lines
    # - Postal code, City, Country line
    # - Tel/Fax (we skip these)
    
    lines = text.split('\n')
    
    # Detect current region from page header
    region = ""
    if "Asia Pacific" in text or "ASIA PACIFIC" in text:
        region = "Asia Pacific"
    elif "EUROPE" in text or "Europe" in lines[1:3]:
        region = "Europe"
    elif "INDIA" in text[:100]:
        region = "India"
    elif "AMERICAS" in text or "North America" in text or "South America" in text:
        region = "Americas"
    elif "Middle East" in text or "Africa" in text:
        region = "Middle East and Africa"
    elif "Subsidiaries" in text:
        region = "Subsidiaries"
    
    # For the address block pages (7-23), we use a heuristic block parser
    # Find address blocks by looking for lines that contain postal/city patterns
    # and working backwards to find the city + address
    
    # Use a sliding window approach: group consecutive non-empty lines into blocks
    # A new block starts when we see a standalone city name (capitalized, short)
    
    blocks = extract_address_blocks_from_text(text)
    
    for block in blocks:
        row = parse_address_block(block, region, source_url)
        if row:
            records.append(row)
    
    return records


def extract_address_blocks_from_text(text):
    """
    Split PDF page text into candidate address blocks.
    Each block is a list of lines for one location.
    """
    lines = text.split('\n')
    blocks = []
    current_block = []
    
    # Skip header lines
    skip_patterns = re.compile(
        r'^(Global locations|Infosys Annual Report|contd\.|—|©|\d+\s*\|)', re.I
    )
    
    # Patterns that indicate a new city/location header
    new_location_pattern = re.compile(
        r'^[A-Z][a-zA-Z\s\-\.\']+$'  # Title case, no numbers
    )
    
    for line in lines:
        line = line.strip()
        if not line:
            if current_block and len(current_block) >= 2:
                blocks.append(current_block[:])
            current_block = []
            continue
        
        if skip_patterns.match(line):
            if current_block and len(current_block) >= 2:
                blocks.append(current_block[:])
            current_block = []
            continue
        
        current_block.append(line)
    
    if current_block and len(current_block) >= 2:
        blocks.append(current_block)
    
    return blocks


def parse_address_block(lines, region, source_url):
    """
    Parse a block of lines into a location record.
    Returns a dict row or None if not parseable.
    """
    if not lines:
        return None
    
    # Filter out telephone/fax lines
    phone_re = re.compile(r'^(Tel|Fax|Phone|Email|hello@|info@|contact@|Tel:|Fax:|www\.)', re.I)
    clean_lines = [l for l in lines if not phone_re.match(l)]
    
    if not clean_lines:
        return None
    
    # Must have at least 2 lines to be a valid address
    if len(clean_lines) < 2:
        return None
    
    # Detect country from lines
    country, city, state, postcode = detect_address_components(clean_lines)
    
    if not country:
        # Try to infer from region
        if region == "India":
            country = "India"
        else:
            return None
    
    # Build address string
    # Remove lines that are just city/country duplicates
    addr_lines = clean_lines[:]
    
    # First line might be city header (standalone capitalized word)
    location_name = "Infosys"
    if addr_lines:
        first = addr_lines[0]
        # If first line is the company name
        if 'infosys' in first.lower() or 'wongdoody' in first.lower() or \
           'guidevision' in first.lower() or 'in-tech' in first.lower() or \
           'base life' in first.lower():
            location_name = first
            addr_lines = addr_lines[1:]
    
    # Build full address
    full_address = ', '.join(addr_lines)
    
    if not full_address or not city:
        return None
    
    # Determine activity
    activity = determine_activity(location_name, city, full_address)
    
    return make_row(
        location_name=location_name,
        location_address=full_address,
        city=city,
        state=state,
        country=country,
        postcode=postcode,
        source_url=source_url,
        source_type="COMPANY REPORT",
        activity=activity,
    )


def detect_address_components(lines):
    """
    Detect country, city, state, postcode from address lines.
    Returns (country, city, state, postcode).
    """
    text = ' '.join(lines)
    
    # Country detection from known country names in text
    country = ""
    city = ""
    state = ""
    postcode = ""
    
    # Check last few lines for country
    for line in reversed(lines):
        for cname in sorted(COUNTRY_ISO3.keys(), key=len, reverse=True):
            if cname in line:
                country = cname
                break
        if country:
            break
    
    # Extract postcode
    pc_patterns = [
        (r'\b(\d{5}-\d{4})\b', None),         # US ZIP+4
        (r'\b([A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2})\b', None),  # UK
        (r'\b([A-Z]\d[A-Z]\s*\d[A-Z]\d)\b', None),            # Canada
        (r'\b(\d{4})\b', ['Australia', 'Austria', 'Denmark', 'Hungary',
                           'Norway', 'Switzerland', 'Luxembourg', 'Croatia']),
        (r'\b(\d{5})\b', None),                # Most European + US
        (r'\b(\d{6})\b', ['India', 'China']),
    ]
    
    for pattern, countries in pc_patterns:
        if countries and country and country not in countries:
            continue
        m = re.search(pattern, text)
        if m:
            postcode = m.group(1)
            break
    
    # Extract city from first meaningful line (often city name or city, state)
    # Look for common city-country patterns
    # "City, State" or "City\nCountry" patterns
    city_found = False
    for line in lines:
        # US: "City, ST XXXXX" or "City, ST"
        if country in ['United States', 'USA', ''] :
            m = re.search(r'^([A-Z][a-zA-Z\s]+),\s+([A-Z]{2})\s+\d{5}', line)
            if m:
                city = m.group(1).strip()
                state = m.group(2).strip()
                city_found = True
                break
            m = re.search(r'^([A-Z][a-zA-Z\s]+),\s+([A-Z]{2})\b', line)
            if m:
                city = m.group(1).strip()
                state = m.group(2).strip()
                city_found = True
                break
        
        # India: "City - PINCODE" or "City – PINCODE"
        if country in ['India', '']:
            m = re.search(r'^([A-Z][a-zA-Z\s]+)\s+[-–]\s+(\d{6})', line)
            if m:
                city = m.group(1).strip()
                postcode = m.group(2)
                country = "India"
                city_found = True
                break
        
        # Generic: "POSTCODE City, Country" or "City, Country"
        for cname in COUNTRY_ISO3.keys():
            if line.endswith(cname) and ',' in line:
                parts = line[:-(len(cname))].rstrip(', ')
                city_parts = parts.split(',')
                if city_parts:
                    city = city_parts[-1].strip()
                    country = cname
                    city_found = True
                    break
        if city_found:
            break
    
    # If city still not found, try to extract from address
    if not city and lines:
        # Take first short capitalized line as city if it looks like a city name
        for line in lines[:3]:
            if re.match(r'^[A-Z][a-zA-Z\s\-]+$', line) and len(line) < 40 and len(line.split()) <= 4:
                city = line.strip()
                break
    
    return country, city, state, postcode


# ═══════════════════════════════════════════════════════════
# HARDCODED RECORDS (from Google Maps / known sources)
# ═══════════════════════════════════════════════════════════

HARDCODED_RECORDS = [
    # Infosys Foundation USA — from Google Maps pin
    # URL: https://www.google.com/maps/place/Infosys+Foundation+USA/@37.400465,-122.136567
    {
        "LOCATION_NAME": "Infosys Foundation USA",
        "LOCATION_ADDRESS": "2000 Seaport Blvd, Suite 200, Redwood City, CA 94063",
        "CITY": "Redwood City",
        "STATE": "CA",
        "COUNTRY": "United States",
        "COUNTRY_ISO3": "USA",
        "POSTCODE": "94063",
        "LATITUDE": "37.400465",
        "LONGITUDE": "-122.136567",
        "SOURCE_URL": "https://www.google.com/maps/place/Infosys+Foundation+USA/@37.400465,-122.136567",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Foundation / CSR Office",
        "coord_source": "website",
        "LOCATION_NAME_NATIVE": "",
        "LOCATION_ADDRESS_NATIVE": "",
    },
]


# ═══════════════════════════════════════════════════════════
# CHINA BPM PAGE PARSER
# ═══════════════════════════════════════════════════════════

def parse_china_bpm_page(html_path, source_url):
    """
    Parse infosysbpm.com/china.html for China office addresses.
    """
    records = []
    
    with open(html_path, 'rb') as f:
        soup = BeautifulSoup(f.read(), 'html.parser')
    
    # Find address blocks - look for common patterns
    # Try finding content sections with addresses
    all_text = soup.get_text(separator='\n')
    
    # Look for city blocks with addresses in China BPM page
    # Pattern: City name followed by address lines
    china_cities = ['Shanghai', 'Beijing', 'Shenzhen', 'Guangzhou', 'Chengdu', 'Wuhan',
                    'Hangzhou', 'Nanjing', 'Dalian', 'Tianjin', 'Xian', 'Suzhou',
                    'Shenyang', 'Qingdao', 'Dongguan', 'Hefei']
    
    # Try structured parsing with BeautifulSoup
    # Look for address-like containers
    # First try: find all divs/sections with city names
    
    # Look for accordion/tab content or office info blocks
    text_blocks = []
    for tag in soup.find_all(['p', 'div', 'li', 'section']):
        t = tag.get_text(separator=' ').strip()
        if len(t) > 30 and any(city in t for city in china_cities):
            if not any(t == b for b in text_blocks):  # avoid duplicates
                text_blocks.append(t)
    
    # Also search for structured office sections
    # Look for headers followed by address content
    for header in soup.find_all(['h1','h2','h3','h4']):
        city_text = header.get_text(strip=True)
        if any(city.lower() in city_text.lower() for city in china_cities):
            # Get following sibling content
            next_sib = header.find_next_sibling()
            while next_sib and next_sib.name not in ['h1','h2','h3','h4']:
                t = next_sib.get_text(separator='\n').strip()
                if t and len(t) > 20:
                    # This might be the address
                    city = city_text
                    addr_lines = [l.strip() for l in t.split('\n') if l.strip()]
                    phone_re = re.compile(r'^(Tel|Fax|Phone|Email|\+86)', re.I)
                    addr_lines = [l for l in addr_lines if not phone_re.match(l)]
                    if addr_lines:
                        full_addr = ', '.join(addr_lines[:4])
                        records.append(make_row(
                            location_name=f"Infosys BPM - {city}",
                            location_address=full_addr,
                            city=city,
                            state="",
                            country="China",
                            postcode="",
                            source_url=source_url,
                            source_type="COMPANY WEBSITE",
                            activity="Business Process Management",
                        ))
                next_sib = next_sib.find_next_sibling() if next_sib else None
    
    print(f"  China BPM: {len(records)} records from HTML")
    return records


# ═══════════════════════════════════════════════════════════
# MAIN EXTRACTION FROM PDF (STRUCTURED APPROACH)
# ═══════════════════════════════════════════════════════════

# Known Infosys locations with full addresses extracted manually from PDF
# This is a curated list from pages 7-23 of global-presence2025.pdf
KNOWN_LOCATIONS = [
    # ASIA PACIFIC - Page 7
    ("Armenia", "Yerevan", "", "ARM", "22 Hanrapetutyan Street, Suite 5, Yerevan - 0010, Armenia", "Infosys Limited - Armenia Office", "0010"),
    ("Australia", "Brisbane", "QLD", "AUS", "Level 4, 40 Creek St, Brisbane QLD 4000, Australia", "Infosys Limited - Brisbane Office", "4000"),
    ("Australia", "Melbourne", "VIC", "AUS", "Two Melbourne Quarter, Level 4, 697 Collins Street, Docklands, 3008 VIC, Australia", "Infosys Limited - Melbourne Office", "3008"),
    ("Australia", "Melbourne", "VIC", "AUS", "Collins Street, West Melbourne VIC 8007, Australia", "Infosys Limited - Melbourne West Office", "8007"),
    ("Australia", "Canberra", "ACT", "AUS", "Level 3, Workspace 3.01, 33 Allara Street, Canberra, ACT - 2601, Australia", "Infosys Limited - Canberra Office", "2601"),
    ("Australia", "Perth", "WA", "AUS", "Level 17, Westralia Square, 141 St Georges Terrace, Perth, Australia", "Infosys Limited - Perth Office", ""),
    ("Australia", "Sydney", "NSW", "AUS", "Level 3, 100 Arthur Street, North Sydney - 2060, NSW, Australia", "Infosys Limited - Sydney Office", "2060"),
    ("Hong Kong", "Hong Kong", "", "HKG", "Suite 01-03, Level 43, Champion Tower, Three Garden Road, Central, Hong Kong", "Infosys Limited - Hong Kong Office", ""),
    ("New Zealand", "Auckland", "", "NZL", "Infosys House, Level 7, 79 Queen Street, Auckland - 1010, New Zealand", "Infosys Limited - Auckland Office", "1010"),
    ("New Zealand", "Wellington", "", "NZL", "Level 15, 171 Featherston Street, Wellington, 6011, New Zealand", "Infosys Limited - Wellington Office", "6011"),
    ("Japan", "Nagoya", "Aichi", "JPN", "Regus Hirokoji Garden Avenue Centre, Hirokoji Garden Avenue 4-24-16, Meieki Nakamura-ku, Nagoya city, Aichi Japan 450-0002", "Infosys Limited - Nagoya Office", "450-0002"),
    ("Japan", "Tokyo", "Tokyo", "JPN", "Shin Otemachi, 2-1, Marunouchi 2-Chome, Chiyoda-ku, Tokyo, Japan", "Infosys Limited - Tokyo Office", ""),
    ("Philippines", "Quezon City", "NCR", "PHL", "5/F Gateway Tower Building, Gen. Roxas Avenue cor. Gen. Aguinaldo, Cubao, Quezon City 1127, Philippines", "Infosys Limited - Manila/Quezon City Office", "1127"),
    ("South Korea", "Seoul", "Seoul", "KOR", "4F, Haesung 1st Bldg, Teheran-Ro 504, Gangnam-Gu, Seoul - 06178, South Korea", "Infosys Limited - Seoul Office", "06178"),
    ("Malaysia", "Petaling Jaya", "Selangor", "MYS", "1Powerhouse, Level 20, No. 1, Persiaran Bandar Utama - 47800, Petaling Jaya, Selangor, Malaysia", "Infosys Limited - Petaling Jaya Office", "47800"),
    ("Singapore", "Singapore", "", "SGP", "Suntec Office, Level 43 Unit 01, Suntec Tower 2, 9 Temasek Blvd, Singapore - 038 989", "Infosys Limited - Suntec Office", "038989"),
    ("Singapore", "Singapore", "", "SGP", "1 Gateway Dr, 07-01 Westgate Tower, Singapore - 608 531", "Infosys Limited - Westgate Office", "608531"),
    ("Taiwan", "Taipei", "", "TWN", "11F, No.1, Songzhi Rd, Xinyi Dist, Taipei City 11047, Taiwan", "Infosys Limited - Taipei Office", "11047"),
    
    # EUROPE - Pages 8-9
    ("Austria", "Vienna", "", "AUT", "Regus Vienna Cityport 11, Simmeringer Hauptstrasse 24, A-1110, Vienna, Austria", "Infosys Austria GmbH", "1110"),
    ("Belgium", "Brussels", "", "BEL", "Koning Albert II-laan 32, 1000, Brussels, Belgium", "Infosys Limited - Brussels Office", "1000"),
    ("Croatia", "Karlovac", "", "HRV", "Prilaz Veceslava Holjevca 2a, 47000 Karlovac, Croatia", "Infosys Limited - Karlovac Office", "47000"),
    ("Czech Republic", "Prague", "", "CZE", "Turkova 2319/5b, Chodov, 149 00 Praha 4, Czech Republic", "Infosys Limited - Prague Office", "14900"),
    ("Denmark", "Copenhagen", "", "DNK", "Lyngbyvej 2, 3rd Floor, 2100 Copenhagen, Denmark", "Infosys Limited - Copenhagen Office", "2100"),
    ("Denmark", "Copenhagen", "", "DNK", "Kampmannsgade 2, 1604 Copenhagen, Denmark", "Infosys Limited - Copenhagen Office 2", "1604"),
    ("Germany", "Berlin", "", "DEU", "Potsdamer Platz 1, 10785 Berlin, Germany", "Infosys Limited - Berlin Office", "10785"),
    ("Germany", "Blankenfelde-Mahlow", "Brandenburg", "DEU", "15827 Blankenfelde-Mahlow, Germany", "Infosys Limited - Dahlewitz Office", "15827"),
    ("Germany", "Boblingen", "Baden-Wurttemberg", "DEU", "Infosys Automotive and Mobility GmbH, Hanns-Klemm-Strasse 5, 71034 Boblingen, Germany", "Infosys Automotive and Mobility GmbH - Boblingen", "71034"),
    ("Germany", "Boblingen", "Baden-Wurttemberg", "DEU", "Otto-Lilienthal-Strasse 5, 71034 Boblingen, Germany", "Infosys - Boblingen Office 2", "71034"),
    ("Germany", "Deizisau", "Baden-Wurttemberg", "DEU", "Sirnauer Strasse 40, 73779 Deizisau, Germany", "Infosys - Deizisau Office", "73779"),
    ("Germany", "Dortmund", "", "DEU", "Germany", "Infosys - Dortmund Office", ""),
    ("Germany", "Dusseldorf", "", "DEU", "Furstenwall 172, 40217 Dusseldorf, Germany", "Infosys - Dusseldorf Office", "40217"),
    ("Germany", "Frankfurt", "", "DEU", "OpernTurm, Bockenheimer Landstrasse 2-4, 60306 Frankfurt am Main, Germany", "Infosys Germany Holding GmbH", "60306"),
    ("Germany", "Hamburg", "", "DEU", "Germany", "Infosys - Hamburg Office", ""),
    ("Germany", "Munich", "Bavaria", "DEU", "Parkring 2, 85748 Garching bei Munchen, Germany", "Infosys Consulting GmbH - Munich", "85748"),
    ("Germany", "Stuttgart", "Baden-Wurttemberg", "DEU", "Infosys Automotive and Mobility GmbH, Schelmenwasenstrasse 39, Stuttgart 70567, Germany", "Infosys Automotive and Mobility GmbH - Stuttgart", "70567"),
    ("Germany", "Walldorf", "Baden-Wurttemberg", "DEU", "Altrottstr. 31, 69190 Walldorf, Germany", "Infosys - Walldorf Office", "69190"),
    ("Germany", "Wiesbaden", "Hesse", "DEU", "2nd floor, Mainzer Str. 97, 65189 Wiesbaden, Germany", "Infosys - Wiesbaden Office", "65189"),
    ("Germany", "Wolfsburg", "Lower Saxony", "DEU", "Germany", "Infosys - Wolfsburg Office", ""),
    ("Guernsey", "St Peter Port", "", "GGY", "PO Box 665, Roseneath, The Grange, St Peter Port, Guernsey, GY1 3SJ", "Infosys Limited Guernsey", "GY1 3SJ"),
    ("Hungary", "Budapest", "", "HUN", "Infosys Limited, 1036 Budapest, Becsi ut 52. III. em. 29, Hungary", "Infosys Limited - Budapest Office", "1036"),
    ("Ireland", "Dublin", "Leinster", "IRL", "Block 1, Booterstown Hall, Booterstown Avenue, Dublin, Ireland", "Infosys Limited - Dublin Office", ""),
    ("Latvia", "Riga", "", "LVA", "Infosys Limited Latvijas filiale, Krisjana Valdemara iela 21 - 11, LV-1010, Riga, Latvia", "Infosys Limited Latvia Branch", "LV-1010"),
    ("Liechtenstein", "Vaduz", "", "LIE", "Infosys Limited, Zollstrasse 2, 9490 Vaduz, Liechtenstein", "Infosys Limited - Vaduz Office", "9490"),
    ("Liechtenstein", "Schaanwald", "", "LIE", "Infosys Limited Zweigniederlassung Schaanwald, Vorarlberger-Strasse 7, 9486 Schaanwald, Liechtenstein", "Infosys Limited Schaanwald Branch", "9486"),
    ("Lithuania", "Vilnius", "", "LTU", "Lietuvos filialas, Gedimino pr. 44A-301, Vilnius, Lithuania", "Infosys Limited Lithuania Branch", ""),
    ("Luxembourg", "Luxembourg", "", "LUX", "Luxembourg", "Infosys Limited - Luxembourg Office", ""),
    ("Malta", "Valletta", "", "MLT", "103, Palazzo Pietro Stiges, Strait Street, Valletta, VLT 1436, Malta", "Infosys Limited - Valletta Office", "VLT 1436"),
    ("Netherlands", "Amsterdam", "North Holland", "NLD", "World Trade Center, I Tower, 7th floor, Strawinskylaan 1977, 1077 XX Amsterdam, Netherlands", "Infy Consulting B.V. / Infosys", "1077 XX"),
    ("Netherlands", "Eindhoven", "North Brabant", "NLD", "Flight Forum 40, Floor 0, 5657 DB Eindhoven, Netherlands", "Infosys - Eindhoven Office", "5657 DB"),
    ("Netherlands", "Schiphol-Rijk", "North Holland", "NLD", "Red building, Ground Floor east, Boeingavenue 101, 1119 PE Schiphol-Rijk, Netherlands", "Infosys - Schiphol-Rijk Office", "1119 PE"),
    ("Netherlands", "Schiphol-Rijk", "North Holland", "NLD", "Purple building, Boeingavenue 53, 1119 PE Schiphol-Rijk, Netherlands", "Infosys - Schiphol-Rijk Office 2", "1119 PE"),
    ("Norway", "Oslo", "", "NOR", "Fornebu, Norway", "Infosys Norway AS", ""),
    ("Portugal", "Lisbon", "", "PRT", "Portugal", "Infosys - Lisbon Office", ""),
    ("Slovakia", "Banska Bystrica", "", "SVK", "Slovakia", "Infosys - Banska Bystrica Office", ""),
    ("Slovakia", "Bratislava", "", "SVK", "Slovakia", "Infosys - Bratislava Office", ""),
    ("Spain", "Madrid", "Community of Madrid", "ESP", "CUZCO IV, Paseo de la Castellana 141, 8th Floor, 28046 Madrid, Spain", "Infosys Limited - Madrid Office", "28046"),
    ("Spain", "Barcelona", "Catalonia", "ESP", "Spain", "Infosys - Barcelona Office", ""),
    ("Sweden", "Stockholm", "", "SWE", "Karlavagen 108, lift 3, 9th floor, 115 26 Stockholm, Sweden", "Infosys Technologies (Sweden) AB", "115 26"),
    ("Sweden", "Gothenburg", "", "SWE", "Spaces Brygghuset, Theres Svenssons gata 13, Gothenburg 417 55, Sweden", "Infosys - Gothenburg Office", "417 55"),
    ("Sweden", "Helsingborg", "", "SWE", "E121B, E122, E123, E131, Bredgatan 11, 252 25 Helsingborg, Sweden", "Infosys - Helsingborg Office", "252 25"),
    ("Switzerland", "Baden", "Aargau", "CHE", "Duplex, Brown Boveri Strasse 12, 5400 Baden, Switzerland", "Infosys - Baden Office", "5400"),
    ("Switzerland", "Basel", "Basel-Stadt", "CHE", "Sandgrubenstrasse 44, 4058 Basel, Switzerland", "Infosys - Basel Office", "4058"),
    ("Switzerland", "Basel", "Basel-Stadt", "CHE", "Regus Basel Stucki Village, Hochbergerstrasse 70, 4057 Basel, Switzerland", "Infosys - Basel Stucki Office", "4057"),
    ("Switzerland", "Kloten", "Zurich", "CHE", "Obstgartenstrasse 27, 8302 Kloten, Switzerland", "Infosys Consulting Holding AG / Infosys Consulting AG", "8302"),
    ("Switzerland", "Geneva", "Geneva", "CHE", "Regus - Geneva, Balexert Tower, Avenue Louis-Casai 18, 1209 Geneva, Switzerland", "Infosys - Geneva Office", "1209"),
    ("United Kingdom", "Edinburgh", "Scotland", "GBR", "WestPoint Office 205, 4 Redheughs Rigg, South Gyle, Edinburgh, EH12 9DQ, United Kingdom", "Infosys Limited - Edinburgh Office", "EH12 9DQ"),
    ("United Kingdom", "Nottingham", "England", "GBR", "Standard Court, Park Row, Nottingham NG1 6GN, United Kingdom", "Infosys Limited - Nottingham Office", "NG1 6GN"),
    ("United Kingdom", "London", "England", "GBR", "14th and 15th Floor, 10 Upper Bank Street, Canary Wharf, London - E14 5NP, United Kingdom", "Infy Consulting Company Ltd / Infosys", "E14 5NP"),
    ("United Kingdom", "London", "England", "GBR", "10th and 11th Floor, The Bower, 207-211 Old St, London - EC1V 9NR, United Kingdom", "Infosys Limited - Old Street Office", "EC1V 9NR"),
    ("United Kingdom", "Derby", "England", "GBR", "1 Pride Place, Pride Park, Derby, Derbyshire, DE24 8QR, United Kingdom", "Infosys Limited - Derby Office", "DE24 8QR"),
    ("United Kingdom", "Warwick", "England", "GBR", "United Kingdom", "Infosys - Warwick Office", ""),
    
    # AMERICAS - Pages 11-12
    ("Canada", "Calgary", "Alberta", "CAN", "18th Floor, Gulf Canada Square, 401 - 9th Avenue SW, Calgary, Alberta T2P 3C5, Canada", "Infosys Limited - Calgary Office", "T2P 3C5"),
    ("Canada", "Vancouver", "British Columbia", "CAN", "Office 133, 130, 125, 18th Floor, 6060 Silver Drive, Vancouver, Canada - Burnaby, BC, V5H 2Y3", "Infosys Limited - Vancouver Office", "V5H 2Y3"),
    ("Canada", "Mississauga", "Ontario", "CAN", "Suite 300, 5800 Explorer Drive (Building) East, Mississauga, Ontario, Canada", "Infosys Limited - Mississauga Office", ""),
    ("Canada", "Saskatoon", "Saskatchewan", "CAN", "500 located on 3rd & 5th Floor, Suite 1360, 15th floor, 410 22nd Street No. 130, Saskatoon, Saskatchewan, S7K 5T6, Canada", "Infosys Limited - Saskatoon Office", "S7K 5T6"),
    ("Mexico", "Mexico City", "CDMX", "MEX", "WeWork Mexico, Avenida De Las Americas 1254, Country Club, CP 03940, Mexico City, Mexico", "Infosys Technologies S. de R.L. de C.V. - Mexico City", "03940"),
    ("Mexico", "Guadalajara", "Jalisco", "MEX", "Avenida De Las Americas 1254, Country Club, Guadalajara, Jalisco, Mexico - 44610", "Infosys - Guadalajara Office", "44610"),
    ("Mexico", "Mexico City", "CDMX", "MEX", "Suite 1360, 15th floor, Citi Center Building, Avenida Insurgentes Sur No. 1602, Colonia Credito Constructor, Mexico, CP 03940", "Infosys - Mexico City Insurgentes Office", "03940"),
    ("Mexico", "Monterrey", "Nuevo Leon", "MEX", "Corporativo Santa Maria, 22nd Street No. 130, Boulevard Diaz Ordaz 16th Floor, Col. Santa Maria, Monterrey, Nuevo Leon, CP 64650, Mexico", "Infosys - Monterrey Office", "64650"),
    ("Brazil", "Nova Lima", "Minas Gerais", "BRA", "Infosys Consulting Ltda, Rua da Paisagem, 220, Lumiere Building, 5th floor, 34000-000, Nova Lima, Minas Gerais, Brazil", "Infosys Consulting Ltda - Nova Lima", "34000-000"),
    ("Brazil", "Rio de Janeiro", "Rio de Janeiro", "BRA", "Infosys Consulting Ltda, Praia de Botafogo, 228, Cond. Edificio Argentina Building, Room 1201 B2, 22250-145, Rio de Janeiro, Brazil", "Infosys Consulting Ltda - Rio de Janeiro", "22250-145"),
    ("Brazil", "Sao Paulo", "Sao Paulo", "BRA", "Infosys Consulting Ltda, Avenida Engenheiro Luiz Carlos Berrini, nº 105 - 14th floor, 04571-010, Sao Paulo, Brazil", "Infosys Consulting Ltda - Sao Paulo", "04571-010"),
    ("Peru", "Lima", "Lima", "PER", "303 Jorge Chavez, 154, 3rd floor, Miraflores, Lima, Peru, Zip code: 15075", "Infosys - Lima Office", "15075"),
    ("Argentina", "Buenos Aires", "", "ARG", "Argentina", "Infosys - Buenos Aires Office", ""),
    ("Costa Rica", "San Jose", "", "CRI", "Costa Rica", "Infosys - San Jose Office", ""),
    ("Chile", "Santiago", "", "CHL", "Chile", "Infosys - Santiago Office", ""),
    
    # MIDDLE EAST AND AFRICA - Page 12
    ("Mauritius", "Reduit", "", "MUS", "4th Floor, B Wing, Ebene Cyber Towers, Reduit, Mauritius", "Infosys Limited - Mauritius Office", ""),
    ("United Arab Emirates", "Abu Dhabi", "Abu Dhabi", "ARE", "Al Bateen Tower C6 Bainunah, Office number 240, ADIB Building, Street 34, Abu Dhabi, UAE", "Infosys Limited - Abu Dhabi Office", ""),
    ("United Arab Emirates", "Dubai", "Dubai", "ARE", "805, Liberty House, DIFC, PO Box 506846, Dubai, UAE", "Infosys Limited - Dubai DIFC Office", "506846"),
    ("United Arab Emirates", "Dubai", "Dubai", "ARE", "1504, Fifteenth Floor, Aurora Tower, TECOM, P.O. Box 502292, Dubai, UAE", "Infosys Limited - Dubai TECOM Office", "502292"),
    ("United Arab Emirates", "Dubai", "Dubai", "ARE", "Unit 3523/24/29, Mazaya Business Avenue AA1, Floor 35, Jumeirah Lakes Towers, Dubai, UAE", "Infosys Limited - Dubai JLT Office", ""),
    ("United Arab Emirates", "Sharjah", "Sharjah", "ARE", "Z3 Office 11, SAIF Zone, PO Box No. 8230, Sharjah, UAE", "Infosys Limited - Sharjah SAIF Zone Office", "8230"),
    ("Saudi Arabia", "Riyadh", "Riyadh", "SAU", "Dhahran Road-Ulaya, Al-Rashid Tower - A West Towers, 2nd Floor, Riyadh, Saudi Arabia", "Infosys Limited - Riyadh Office", ""),
    ("Saudi Arabia", "Al Khobar", "Eastern Province", "SAU", "Al Khobar, Saudi Arabia", "Infosys Limited - Al Khobar Office", ""),
    ("Saudi Arabia", "Tabuk", "Tabuk", "SAU", "Building 2655, Salimaniya Area, Code 47312/7161, Amir Abdul Majeed Road, Tabuk, Kingdom of Saudi Arabia", "Infosys Limited - Tabuk Office", "47312"),
    ("Qatar", "Doha", "", "QAT", "Qatar", "Infosys Limited - Doha Office", ""),
    ("Oman", "Muscat", "", "OMN", "Shatti Al Qurum, 3rd Floor, Beach One Building, Muscat, Oman", "Infosys Limited SPC - Muscat Office", ""),
    ("South Africa", "Johannesburg", "Gauteng", "ZAF", "Infosys South Africa (Pty) Ltd, A West Towers, 2nd Floor, Maude Street, Nelson Mandela Drive, Sandton, Johannesburg 2196, South Africa", "Infosys South Africa (Pty) Ltd", "2196"),
    
    # INDIA - Pages 10-11
    ("India", "Ahmedabad", "Gujarat", "IND", "Pragya 2 Tower, Gift City, Gandhi Nagar Taluka, Vejalapura, Ahmedabad - 380051, India", "Infosys Limited - Ahmedabad DC", "380051"),
    ("India", "Bengaluru", "Karnataka", "IND", "Plot no. 44/97 A, 3rd cross, Electronic City, Hosur Road, Bengaluru - 560 100, India", "Infosys Limited - Bengaluru Electronic City DC", "560100"),
    ("India", "Bengaluru", "Karnataka", "IND", "Infosys Square OFFSHORE Development Centre, Sy No. 41(P), 40(P), Konappana Agrahara Village, Begur Hobli, Bengaluru South, Electronic City P-II, Bengaluru - 560 100, India", "Infosys Limited - Bengaluru Infosys Square DC", "560100"),
    ("India", "Bhubaneswar", "Odisha", "IND", "STPI Infosys Limited, Plot No-E/4 Info City Road, Bhubaneswar - 751 024, Odisha, India", "Infosys Limited - Bhubaneswar DC", "751024"),
    ("India", "Bhubaneswar", "Odisha", "IND", "Plot No. A-40A, Phase-VIII B, G.S Sahibzada Ajit Singh Nagar, Industrial Area Sector 75, Mohali, Punjab - 160 059, India", "Infosys Limited - Mohali DC", "160059"),  # Fix: this is Mohali
    ("India", "Chandigarh", "Punjab", "IND", "Chandigarh, India", "Infosys Limited - Chandigarh Office", ""),
    ("India", "Chennai", "Tamil Nadu", "IND", "Chennai, India", "Infosys Limited - Chennai DC", ""),
    ("India", "Coimbatore", "Tamil Nadu", "IND", "Coimbatore, India", "Infosys Limited - Coimbatore Office", ""),
    ("India", "Guwahati", "Assam", "IND", "Nexia Tower, Ground, 1st & 2nd Floor, Besides Hotel Aster Premier, Khanapara, Guwahati - 781022, Assam, India", "Infosys Limited - Guwahati Office", "781022"),
    ("India", "Hubballi", "Karnataka", "IND", "Gokul Hobli, Hubballi Taluk, Near Hubballi Airport, 85, C, Dharwad District, Karnataka - 580030, India", "Infosys Limited - Hubballi DC", "580030"),
    ("India", "Hyderabad", "Telangana", "IND", "Survey No. 210, Manikonda Village, Lingampally, Rangareddy (Dist.), Hyderabad - 500 019, India", "Infosys Limited - Hyderabad DC", "500019"),
    ("India", "Indore", "Madhya Pradesh", "IND", "Indore, India", "Infosys Limited - Indore Office", ""),
    ("India", "Jaipur", "Rajasthan", "IND", "Jaipur, India", "Infosys Limited - Jaipur Office", ""),
    ("India", "Kochi", "Kerala", "IND", "Kochi, Kerala, India", "Infosys Limited - Kochi Office", ""),
    ("India", "Kolkata", "West Bengal", "IND", "Pno.Iiig/2, Aa-Iiig, St No.3333, New Town, Kolkata, Leather Complex, Dist South 24 Parganas, Kolkata, West Bengal - 700135, India", "Infosys Limited - Kolkata DC", "700135"),
    ("India", "Mangaluru", "Karnataka", "IND", "Mangaluru, Karnataka, India", "Infosys Limited - Mangaluru Office", ""),
    ("India", "Mohali", "Punjab", "IND", "Plot No. A-40A, Phase-VIII B, Sahibzada Ajit Singh Nagar, Industrial Area Sector 75, Mohali, Punjab - 160 059, India", "Infosys Limited - Mohali DC", "160059"),
    ("India", "Mumbai", "Maharashtra", "IND", "85, C, Mittal Towers, 8th Floor, Nariman Point, Mumbai - 400 021, India", "Infosys Limited - Mumbai Nariman Point Office", "400021"),
    ("India", "Mumbai", "Maharashtra", "IND", "11th Floor, South Tower, Godrej One, Pirojshanagar Eastern Express Highway, Vikhroli - East, Mumbai, Maharashtra - 400079, India", "Infosys Limited - Mumbai Vikhroli Office", "400079"),
    ("India", "Mumbai", "Maharashtra", "IND", "401, 4th Floor, Building No.1, Airoli Knowledge Park, MIDC Industrial Area, Village Dighe-Airoli Thane, Navi Mumbai, Maharashtra, India", "Infosys Limited - Navi Mumbai Airoli Office", ""),
    ("India", "Mysuru", "Karnataka", "IND", "Mysuru, Karnataka, India", "Infosys Limited - Mysuru DC", ""),
    ("India", "Nagpur", "Maharashtra", "IND", "Nagpur, Maharashtra, India", "Infosys Limited - Nagpur Office", ""),
    ("India", "New Delhi", "Delhi", "IND", "New Delhi, India", "Infosys Limited - New Delhi Office", ""),
    ("India", "Noida", "Uttar Pradesh", "IND", "Floor 9, 10, 11, 12, Tower B, Ace Capitol, Plot No 37A, Sector 132, Greater Noida Expressway, Noida - 201 304, Uttar Pradesh, India", "Infosys Limited - Noida DC", "201304"),
    ("India", "Noida", "Uttar Pradesh", "IND", "STP Unit-II, 15th, 16th and 17th Floor, Alphathum Bhutani, Plot No 1, Sector-90, Noida 201 305 (UP), India", "Infosys Limited - Noida Alphathum Office", "201305"),
    ("India", "Pune", "Maharashtra", "IND", "B1, Gera Commerce Zone, Survey 65, Village Kharadi, Taluka Haveli, Pune - 411 014, Maharashtra, India", "Infosys Limited - Pune Kharadi DC", "411014"),
    ("India", "Pune", "Maharashtra", "IND", "917, Level 9, Tower 2, World Trade Center, Kharadi, Pune 400014, Maharashtra, India", "Infosys Limited - Pune WTC Office", "400014"),
    ("India", "Pune", "Maharashtra", "IND", "627, Level 6, Wing 1, Tower A, Business Bay, Survey No 103, Airport Road, Yerawada, Pune - 411006, Maharashtra, India", "Infosys Limited - Pune Yerawada Office", "411006"),
    ("India", "Thiruvananthapuram", "Kerala", "IND", "Plot No. 1, Technopark Campus II, Attipra Village, Thiruvananthapuram - 695 583, Kerala, India", "Infosys Limited - Thiruvananthapuram DC", "695583"),
    ("India", "Visakhapatnam", "Andhra Pradesh", "IND", "Ground, 1st & 2nd Floors, Signitive Towers Pvt. Ltd, Plot B, Sy No 408/1 IT Park, Hill No.2, Rushikonda IT Non SEZ, Madhurawada, AP, Visakhapatnam - 530045, India", "Infosys Limited - Visakhapatnam DC", "530045"),
    ("India", "Gurugram", "Haryana", "IND", "Gurugram, Haryana, India", "Infosys Limited - Gurugram Office", ""),
    ("India", "Kolkata", "West Bengal", "IND", "14th floor, Mani Casadona 04, West Tower, Street No 372, IIF, Action area I, New Town, Kolkata, South 24 Parganas, West Bengal, 700156, India", "Infosys Limited - Kolkata Casadona Office", "700156"),
    
    # USA - from HTML pages
    ("United States", "Chicago", "IL", "USA", "Chicago, IL, United States", "Infosys Limited - Chicago Office", ""),
    ("United States", "Colorado Springs", "CO", "USA", "Colorado, United States", "Infosys Limited - Colorado Office", ""),
    ("United States", "Milwaukee", "WI", "USA", "Milwaukee, WI, United States", "Infosys Limited - Milwaukee Office", ""),
    ("United States", "Lisle", "IL", "USA", "Lisle, IL, United States", "Infosys Limited - Lisle Office", ""),
    ("United States", "Franklin", "TN", "USA", "Franklin, TN, United States", "Infosys Limited - Franklin Office", ""),
    ("United States", "Wayne", "PA", "USA", "Wayne, PA, United States", "Infosys Limited - Wayne Office", ""),
    ("United States", "Rogers", "AR", "USA", "Rogers, AR, United States", "Infosys Limited - Rogers Office", ""),
    ("United States", "Hartford", "CT", "USA", "Hartford, CT, United States", "Infosys Limited - Hartford Office", ""),
    ("United States", "Providence", "RI", "USA", "Providence, RI, United States", "Infosys Limited - Providence Office", ""),
    ("United States", "Wilmington", "DE", "USA", "Delaware, United States", "Infosys Limited - Delaware Office", ""),
    ("United States", "New York", "NY", "USA", "New York, NY, United States", "Infosys Limited - New York Office", ""),
    ("United States", "Indianapolis", "IN", "USA", "Indianapolis, IN, United States", "Infosys Limited - Indianapolis Office", ""),
    ("United States", "Bridgewater", "NJ", "USA", "Bridgewater, NJ, United States", "Infosys Limited - Bridgewater Office", ""),
    ("United States", "Bellevue", "WA", "USA", "Bellevue, WA, United States", "Infosys Limited - Bellevue Office", ""),
    ("United States", "Rockville", "MD", "USA", "Rockville, MD, United States", "Infosys Limited - Rockville Office", ""),
    ("United States", "Seattle", "WA", "USA", "1011 Western Ave, Seattle, WA 98104, United States", "WongDoody / Infosys - Seattle", "98104"),
    ("United States", "Los Angeles", "CA", "USA", "8500 Steller Drive, Culver City, CA 90232, United States", "WongDoody - Los Angeles (Culver City)", "90232"),
    ("United States", "San Ramon", "CA", "USA", "San Ramon, CA, United States", "Infosys Limited - San Ramon Office", ""),
    ("United States", "Raleigh", "NC", "USA", "Raleigh, NC, United States", "Infosys Limited - Raleigh Office", ""),
    ("United States", "Lehi", "UT", "USA", "Lehi, UT, United States", "Infosys Limited - Lehi Office", ""),
    ("United States", "Charlotte", "NC", "USA", "Charlotte, NC, United States", "Infosys Limited - Charlotte Office", ""),
    ("United States", "Phoenix", "AZ", "USA", "Phoenix, AZ, United States", "Infosys Limited - Phoenix Office", ""),
    ("United States", "Des Moines", "IA", "USA", "Des Moines, IA, United States", "Infosys Limited - Des Moines Office", ""),
    ("United States", "Tempe", "AZ", "USA", "Tempe, AZ, United States", "Infosys Limited - Tempe Office", ""),
    ("United States", "Blue Ash", "OH", "USA", "4295 Glendale-Milford Rd, Blue Ash, Cincinnati, OH 45242, United States", "Infosys Limited - Blue Ash Office", "45242"),
    ("United States", "Austin", "TX", "USA", "Austin, TX, United States", "Infosys Limited - Austin Office", ""),
    ("United States", "Charleston", "SC", "USA", "Charleston, SC, United States", "Infosys Limited - Charleston Office", ""),
    ("United States", "Houston", "TX", "USA", "Houston, TX, United States", "Infosys Limited - Houston Office", ""),
    ("United States", "Boston", "MA", "USA", "Boston, MA, United States", "Infosys Limited - Boston Office", ""),
    ("United States", "Richardson", "TX", "USA", "Richardson, TX, United States", "Infosys Limited - Richardson Office", ""),
    ("United States", "Atlanta", "GA", "USA", "Atlanta, GA, United States", "Infosys Limited - Atlanta Office", ""),
    ("United States", "Aguadilla", "PR", "USA", "Aguadilla, Puerto Rico, United States", "Infosys Limited - Puerto Rico Office", ""),
    ("United States", "Providence", "RI", "USA", "75 Fountain St, Providence, Rhode Island 02902, United States", "WongDoody - Providence Office", "02902"),
    ("United States", "New York", "NY", "USA", "285 Fulton St, 79th Fl, One World Trade Center, New York, NY 10007, United States", "WongDoody - New York Office", "10007"),
    
    # CHINA - from PDF pages + BPM site
    ("China", "Shanghai", "Shanghai", "CHN", "No. 506, Ziyue Road, Minhang District, Shanghai, 200241, China", "Infosys Technologies (Shanghai) Company Limited", "200241"),
    ("China", "Guangzhou", "Guangdong", "CHN", "Unit 3003A, North Tower of Huanhui Plaza, 1168 Xingang East Road, Haizhu District, Guangzhou 510235, Guangdong, China", "Infosys Technologies (Shanghai) - Guangzhou", "510235"),
    ("China", "Dongguan", "Guangdong", "CHN", "Room 564, No. 8, Hongyuan Road, Nancheng Street District, Dongguan, Guangdong, China", "Infosys - Dongguan Office", ""),
    ("China", "Nanjing", "Jiangsu", "CHN", "No. 1-2043, No. 1308, Building 1, Kangxin Garden, Qinhuai, Nanjing, China", "Infosys - Nanjing Office", ""),
    ("China", "Shenzhen", "Guangdong", "CHN", "No. 2018 Xuegang Road, Bantian Street, Longgang District, Shenzhen, China", "Infosys - Shenzhen Office", ""),
    ("China", "Xian", "Shaanxi", "CHN", "No. 12, Synergy Building, 2nd Gaoxin Road, High-tech Zone, Xian, Shaanxi, China", "Infosys - Xian Office", ""),
    ("China", "Wuhan", "Hubei", "CHN", "Room 15, 16/F, Building A-2, Phase VI, Zone 11, National Geospatial Information Industry Base, No. 3, No. 4 Wudayuan Road, Donghu New Technology Development Zone, Wuhan, China", "Infosys - Wuhan Office", ""),
    ("China", "Beijing", "Beijing", "CHN", "Level 6, Lei Shing Hong Plaza, Tower C, No.8 Wangjing Street, Chaoyang District, Beijing, China", "Infosys Technologies (China) Co. Limited - Beijing", ""),
    ("China", "Beijing", "Beijing", "CHN", "Building 3, Yard 12, Anwen Street, Shunyi District, Beijing, China", "Infosys - Beijing Shunyi Office", ""),
    ("China", "Beijing", "Beijing", "CHN", "Room 331, Tower B, No.1 Xiangjiang North Road, Chaoyang District, Beijing, China", "Infosys - Beijing Chaoyang Office", ""),
    ("China", "Hangzhou", "Zhejiang", "CHN", "12F Fangtianxia Building, 82 YueDa Lane, Binjiang District, Hangzhou, Zhejiang, China", "Infosys Technologies (China) - Hangzhou", ""),
    ("China", "Dalian", "Liaoning", "CHN", "Room 410, No. 366 Shangke Road, 10/F, 21, Lane 55, Chuanhe Road, Pilot Free Trade Zone, Dalian, Liaoning, China", "Infosys - Dalian Office", ""),
    ("China", "Hefei", "Anhui", "CHN", "Room B2-708, 7th Floor, Binhu Yungu Innovation Park, Baohe District, Hefei City, Anhui Province, China", "in-tech Aut. Eng. / Infosys - Hefei", ""),
    ("China", "Shenyang", "Liaoning", "CHN", "1105-1106, 21 Beiling Avenue, Huanggu District, Shenyang, Liaoning Province, China", "in-tech Aut. Eng. - Shenyang", ""),
    ("China", "Shanghai", "Shanghai", "CHN", "Room 307, 3F, No. 195 Guangfu Road, Jingan District, Shanghai, 200070, China", "Wongdoody (Shanghai) Co. Ltd.", "200070"),
    
    # Israel, Turkey from PDF
    ("Israel", "Hod HaSharon", "Central District", "ISR", "Hod HaSharon, Israel", "Infosys - Israel Office", ""),
    ("Turkey", "Istanbul", "", "TUR", "ESENTEPE MAHALLESI, BUYUKDERE CADDESI FERKO SIGNATURE NO: 175/6 KAT: B3 34394 SISLI, Istanbul, Turkey", "Infosys Germany Holding GmbH / Infosys Turkey", "34394"),
    ("Thailand", "Bangkok", "", "THA", "3319 Chamchuri Square Tower, Suite No. 24016, Phayathai Road, Pathumwan, Bangkok 10330, Thailand", "BASE Life Science / Infosys - Bangkok", "10330"),
    ("Thailand", "Bangkok", "", "THA", "Wework The Parq, 88 The Parq Building, 7th-8th Floor, Ratchadaphisek Road, Klongtoey, Bangkok - 10110, Thailand", "Infosys - Bangkok WeWork Office", "10110"),
    
    # SUBSIDIARIES - Pages 14-23
    # Romania
    ("Romania", "Bucharest", "", "ROU", "Calea Grivitei 82-98, 010735 Bucharest, District 1, The Mark Tower Building, 4th Floor, Romania", "Infosys Technologies Romania / Infosys Consulting Ltda.", "010735"),
    ("Romania", "Brasov", "Brasov County", "ROU", "Strada Turnului No. 5, 500152 Brasov, Romania", "in-tech Engineering - Brasov", "500152"),
    ("Romania", "Sibiu", "Sibiu County", "ROU", "Calea Dumbravii 111A, 550003 Sibiu, Romania", "ProIT S.R.L. - Sibiu", "550003"),
    # Bulgaria
    ("Bulgaria", "Sofia", "", "BGR", "Infosys Limited Bulgaria EOOD, Cherni Vrah 51 Blvd., OfficeX, Building 2, WorkBetter, 1407 Sofia, Bulgaria", "Infosys Limited Bulgaria EOOD", "1407"),
    # France
    ("France", "Paris", "Ile-de-France", "FRA", "Tour Pacific, 11-13 Cours Valmy, 92977 Paris La Defense Cedex, France", "BASE Life Science SAS / Infosys", "92977"),
    ("France", "Paris", "Ile-de-France", "FRA", "Tour Opus 12, 4th floor, 77 Esplanade du General de Gaulle, 92914, Paris La Defense, France", "Infosys Consulting SAS", "92914"),
    ("France", "Paris", "Ile-de-France", "FRA", "71, Avenue Victor Hugo, 75116 Paris, France", "Infosys Technology SAS", "75116"),
    # Serbia
    ("Serbia", "Belgrade", "", "SRB", "Trg Nikole Pasica 5, 3rd Floor, 11000 Belgrade, Serbia", "WongDoody d.o.o. / Infosys", "11000"),
    # Italy
    ("Italy", "Milan", "Lombardy", "ITA", "Via Tommaso De Cazzangia 9/6, 20121 Milano, Italy", "BASE Life Science S.r.l.", "20121"),
    # Spain
    ("Spain", "Barcelona", "Catalonia", "ESP", "Calle de Taulat 21, 08005 Barcelona, Spain", "BASE Life Science SL - Barcelona", "08005"),
    ("Spain", "Madrid", "Community of Madrid", "ESP", "San Jeronimo 17, 28014 Madrid, Spain", "BASE Life Science SL - Madrid", "28014"),
    ("Spain", "Barcelona", "Catalonia", "ESP", "Avda Ferrocarril 6, 08840 Viladecans, Barcelona, Spain", "in-tech Automotive Engineering SL - Barcelona", "08840"),
    # Czech Republic - GuideVision
    ("Czech Republic", "Brno", "", "CZE", "Vlnena 526/1 (4th Floor), 602 00 Brno-stred, Czech Republic", "GuideVision s.r.o. - Brno", "60200"),
    ("Czech Republic", "Prague", "", "CZE", "Turkova 5b (11th Floor), 149 00 Praha 4, Czech Republic", "GuideVision s.r.o. - Prague", "14900"),
    ("Czech Republic", "Ostrava", "", "CZE", "28. rijna 696/205, 709 00 Ostrava-Marianske Hory a Hulvaky, Czech Republic", "GuideVision s.r.o. - Ostrava", "70900"),
    ("Czech Republic", "Hradec Kralove", "", "CZE", "Namesti 28.rijna 20/2 (4th Floor), 500 02 Hradec Kralove, Czech Republic", "GuideVision s.r.o. - Hradec Kralove", "50002"),
    # Germany (in-tech)
    ("Germany", "Munich", "Bavaria", "DEU", "Parkring 32, 85748 Garching/Munchen, Germany", "Drivetech / in-tech - Munich", "85748"),
    ("Germany", "Handewitt", "Schleswig-Holstein", "DEU", "Skandinavien-Bogen 6, 24983 Handewitt, Germany", "BASE Life Science GmbH", "24983"),
    # Finland - GuideVision
    ("Finland", "Helsinki", "", "FIN", "Helsinki, Finland", "GuideVision Suomi Oy - Helsinki", ""),
    # Hungary - GuideVision
    ("Hungary", "Budapest", "", "HUN", "Fehervar ut 79, 1119 Budapest, Hungary", "GuideVision Magyarorszag Kft.", "1119"),
    # Austria - in-tech
    ("Austria", "Vienna", "", "AUT", "Mariahilfer Str. 121b/4, 1060 Vienna, Austria", "in-tech Engineering GmbH Austria", "1060"),
    # Mexico - in-tech
    ("Mexico", "Polanco", "Jalisco", "MEX", "Amado Nerve, Number 1545, San Luis Potosi, Polanco - 78220, Mexico", "in-tech Automotive Engineering S. de R.L. de C.V. - Mexico", "78220"),
    # UK - in-tech
    ("United Kingdom", "Warwick", "England", "GBR", "Warwick, United Kingdom", "in-tech Group Ltd. - Warwick", ""),
    # India special
    ("India", "Delhi", "Delhi", "IND", "47 F/F, Mangal Bazar, Laxmi Nagar, Delhi, India - 110092", "Elbrus Labs Private Limited", "110092"),
    ("India", "Bengaluru", "Karnataka", "IND", "1st floor, Discoverer Building, ITPB, Whitefield Main Road, Bengaluru, Karnataka, India - 560066", "BASE Life Science / InSemi Technology - Bengaluru ITPB", "560066"),
    ("India", "Hyderabad", "Telangana", "IND", "SDB 1, 2nd Floor, Flat No.: 4, Rajendranagar Mandal, Manikonda, Hyderabad, Telangana - 500089, India", "Elbrus Labs - Hyderabad", "500089"),
    ("India", "Noida", "Uttar Pradesh", "IND", "F A, Iqbal Nath Bhutan Tower B, Janpath Marg, Common Service Centre, Sector 90, Noida, Uttar Pradesh - 201305, India", "Elbrus Labs - Noida", "201305"),
    ("India", "Kochi", "Kerala", "IND", "13EFGH, Tower 2, Trans Asia Cyber Park, Infopark SEZ Phase-II, 682303, Kochi, Kerala, India", "in-tech Group India Private Limited", "682303"),
    ("India", "Kochi", "Kerala", "IND", "6D, Tower 2, Trans Asia Cyber Park, Infopark SEZ Phase-II, 682303, Kochi, Kerala, India", "in-tech Group India - Kochi 2", "682303"),
    ("India", "Bengaluru", "Karnataka", "IND", "Unit No. 1 to 7, 2nd Floor, Discoverer Building, ITPB, Whitefield Main Road, Bengaluru, Karnataka, India - 560066", "InSemi Technology Services Pvt. Ltd.", "560066"),
    # Oman
    ("Oman", "Muscat", "", "OMN", "Infosys Limited SPC, Shatti Al Qurum, 3rd Floor, Beach One Building, Muscat, Oman", "Infosys Limited SPC", ""),
]


def build_records_from_known_locations():
    """Convert the KNOWN_LOCATIONS list into standard row dicts."""
    records = []
    for item in KNOWN_LOCATIONS:
        country, city, state, iso3, address, name, postcode = item
        row = {
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": transliterate(name),
            "LOCATION_ADDRESS": clean_address(transliterate(address)),
            "LATITUDE": "",
            "LONGITUDE": "",
            "COUNTRY": country,
            "COUNTRY_ISO3": iso3,
            "POSTCODE": postcode,
            "STATE": state,
            "CITY": city,
            "SOURCE_URL": SOURCE_PDF_URL,
            "SOURCE_TYPE": "COMPANY REPORT",
            "ACTIVITY_AT_ASSET": determine_activity(name, city, address),
            "coord_source": "",
            "LOCATION_NAME_NATIVE": "",
            "LOCATION_ADDRESS_NATIVE": "",
        }
        records.append(row)
    return records


# ═══════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════

def main():
    print("=" * 60)
    print(f"Extracting: {ISSUER_NAME} ({ISSUER_ID})")
    print("=" * 60)
    
    all_records = []
    
    # 1. Known locations from PDF (curated)
    print("\n[1] Building records from curated PDF location list...")
    known_records = build_records_from_known_locations()
    print(f"    Curated PDF records: {len(known_records)}")
    all_records.extend(known_records)
    
    # 2. Parse HTML contact pages for additional/more detailed records
    print("\n[2] Parsing HTML contact pages...")
    for region, html_path in HTML_FILES.items():
        if html_path.exists():
            if region == "China BPM":
                html_records = parse_china_bpm_page(html_path, SOURCE_HTML_URLS.get(region, ""))
            else:
                html_records = parse_contact_html_page(html_path, region, SOURCE_HTML_URLS.get(region, ""))
            all_records.extend(html_records)
    
    # 3. Add hardcoded records (Google Maps etc.)
    print("\n[3] Adding hardcoded records (Google Maps, Foundation, etc.)...")
    for rec in HARDCODED_RECORDS:
        rec["ISSUER_ID"] = ISSUER_ID
        rec["ISSUER_NAME"] = ISSUER_NAME
        all_records.append(rec)
    print(f"    Added {len(HARDCODED_RECORDS)} hardcoded records")
    
    # 4. Deduplicate
    print(f"\n[4] Deduplicating {len(all_records)} total records...")
    df = pd.DataFrame(all_records)
    
    # Ensure all required columns exist
    required_cols = ["ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS",
                     "LATITUDE", "LONGITUDE", "COUNTRY", "COUNTRY_ISO3", "POSTCODE",
                     "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE", "ACTIVITY_AT_ASSET",
                     "coord_source", "LOCATION_NAME_NATIVE", "LOCATION_ADDRESS_NATIVE"]
    for col in required_cols:
        if col not in df.columns:
            df[col] = ""
    
    df = df[required_cols]
    
    # Clean up
    df["LOCATION_ADDRESS"] = df["LOCATION_ADDRESS"].apply(
        lambda x: clean_address(str(x)) if pd.notna(x) else "")
    df["CITY"] = df["CITY"].apply(lambda x: str(x).strip() if pd.notna(x) else "")
    df["COUNTRY"] = df["COUNTRY"].apply(lambda x: str(x).strip() if pd.notna(x) else "")
    
    # Remove rows without city or address
    before = len(df)
    df = df[df["CITY"].str.len() > 0]
    df = df[df["LOCATION_ADDRESS"].str.len() > 0]
    after = len(df)
    print(f"    Dropped {before - after} rows missing CITY or LOCATION_ADDRESS")
    
    # Dedup by LOCATION_NAME + CITY + COUNTRY
    df_dedup = df.drop_duplicates(subset=["LOCATION_NAME", "CITY", "COUNTRY"])
    print(f"    After dedup: {len(df_dedup)} unique records (from {len(df)})")
    
    # Check against threshold
    print(f"\n[5] Count check: {len(df_dedup)} records (threshold: 152)")
    if len(df_dedup) < 152:
        print(f"    WARNING: Below 152 threshold! Gap: {152 - len(df_dedup)} records")
    else:
        print(f"    PASSED: Above threshold by {len(df_dedup) - 152} records")
    
    # Save checkpoint
    checkpoint_path = TEMP_DIR / f"{ISSUER_ID}_checkpoint.csv"
    df_dedup.to_csv(checkpoint_path, index=False, encoding='utf-8-sig')
    print(f"\n[6] Checkpoint saved: {checkpoint_path}")
    print(f"    Records: {len(df_dedup)}")
    
    # Country summary
    print("\n[7] Country breakdown:")
    for country, count in df_dedup["COUNTRY"].value_counts().head(20).items():
        print(f"    {country}: {count}")
    
    # Save final output
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    df_dedup.to_csv(OUTPUT_FILE, index=False, encoding='utf-8-sig')
    print(f"\n[8] Final output saved: {OUTPUT_FILE}")
    print(f"    Total records: {len(df_dedup)}")
    
    return df_dedup


if __name__ == "__main__":
    df = main()
