"""
Generic extractor for issuers that publish named assets in official reports or
presentations, but do not publish a full address directory on their own site.

How to use:
1. Edit the configuration block for the issuer constants, output paths, and
   OFFICIAL_ASSETS list.
2. Run:
       python official_named_asset_map_validation_extractor.py
3. The script queries Nominatim/OpenStreetMap for address resolution, keeps
   only results that match the expected locality/country, and writes:
   - the validated staging CSV
   - a reject CSV for unresolved or ambiguous assets
   - a JSON resolution log for QA/debugging

This pattern is reusable for report-first portfolio issuers where the official
source names facilities and a map service is needed only to recover the exact
postal address.
"""

from __future__ import annotations

import csv
import json
import re
import time
import urllib.parse
from collections import OrderedDict
from pathlib import Path
from typing import Any

import requests


# ============================================================
# CONFIGURATION - Edit this block for each new issuer
# ============================================================
ISSUER_ID = "IID000000002138332"
ISSUER_NAME = "PRIMARY HEALTH PROPERTIES PLC"
COUNT_THRESHOLD = 4225

STAGING_CSV = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Run_asset_completeness_ondemand_batch7_8___straive_copy\staging\IID000000002138332_PRIMARY HEALTH PROPERTIES PLC.csv"
REJECT_CSV = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Run_asset_completeness_ondemand_batch7_8___straive_copy\reject\IID000000002138332_PRIMARY HEALTH PROPERTIES PLC_rejected.csv"
RESOLUTION_LOG = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Run_asset_completeness_ondemand_batch7_8___straive_copy\IID000000002138332_PRIMARY HEALTH PROPERTIES PLC\resolution_log.json"

NOMINATIM_SEARCH_URL = "https://nominatim.openstreetmap.org/search"
REQUEST_DELAY_SECONDS = 0.8

ASSURA_REPORT_2025 = "https://www.phpgroup.co.uk/media/ou0p0ize/assura_annual-report-2025_web.pdf"
PHP_ANNUAL_RESULTS_2024 = "https://www.phpgroup.co.uk/media/mvbcloed/annual_results_presentation_fy24_including_merger_slide.pdf"
PHP_CAPITAL_MARKETS_2024 = "https://www.phpgroup.co.uk/media/egtpduiz/php_capital_markets_day_-_16_october_2024.pdf"
PHP_YEAR_END_2025 = "https://www.phpgroup.co.uk/media/q4fncu13/php_-_year_end_results_presentation_vf.pdf"
PHP_PORTFOLIO_PAGE = "https://www.phpgroup.co.uk/portfolio"
PHP_IRISH_PRESENTATION_2018 = "https://www.phpgroup.co.uk/media/j3lptgen/2018_irish_capital_markets_day_final.pdf"

OFFICIAL_ASSETS = [
    {"name": "79 Harley Street", "locality": "Marylebone", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "city_override": "London"},
    {"name": "Ashfields Health Centre", "locality": "Sandbach", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Aspen Centre", "locality": "Gloucester", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Beam Street Medical Centre", "locality": "Nantwich", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "BMI Duchy Hospital", "locality": "Harrogate", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "queries": ["Duchy Hospital Harrogate"]},
    {"name": "Bonnyrigg Medical Centre", "locality": "Bonnyrigg", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Buckshaw Treatment Centre", "locality": "Buckshaw Village", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Cancer Centre London", "locality": "Wimbledon", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "city_override": "London"},
    {"name": "Castlebar Primary Care Centre", "locality": "Castlebar", "country_hint": "IRL", "validation_url": ASSURA_REPORT_2025},
    {"name": "Centre for Diagnostics, Oncology & Wellbeing", "locality": "Bristol", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Centre for Diagnostics, Oncology & Wellbeing", "locality": "Windsor", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Church View Medical Centre", "locality": "South Kirkby", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "queries": ["Church View Medical Centre South Kirkby"], "city_override": "South Kirkby"},
    {"name": "Claremont Hospital", "locality": "Sheffield", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Coldharbour Works", "locality": "Brixton", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Crompton Health Centre", "locality": "Bolton", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Dean Street", "locality": "Soho", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "queries": ["Dean Street Soho health"], "city_override": "London"},
    {"name": "Dene Drive Primary Care Centre", "locality": "Winsford", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Durham Diagnostic Treatment Centre", "locality": "Belmont", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "city_override": "Belmont"},
    {"name": "Eagle Bridge Health & Wellbeing Centre", "locality": "Crewe", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Eccles Specialist Education", "locality": "Norwich", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Edgbaston Hospital", "locality": "Edgbaston", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Fleetwood Health & Wellbeing Centre", "locality": "Fleetwood", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "city_override": "Fleetwood"},
    {"name": "Freshney Green Primary Care Centre", "locality": "Grimsby", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Frome Medical Centre", "locality": "Frome", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Centre for Oncology", "locality": "Guildford", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "queries": ["centre for oncology guildford uk"]},
    {"name": "Gyle Square", "locality": "Edinburgh", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "city_override": "Edinburgh"},
    {"name": "Highgate Hospital", "locality": "London", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "city_override": "London"},
    {"name": "Hillside Primary Care Centre", "locality": "London", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Holly Hospital", "locality": "Buckhurst Hill", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "city_override": "Buckhurst Hill"},
    {"name": "Kettering Health Facility", "locality": "Glendon Lodge", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Malmesbury Primary Care Centre", "locality": "Malmesbury", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "city_override": "Malmesbury"},
    {"name": "Market Drayton Primary Care Centre", "locality": "Market Drayton", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Moor Park Health & Leisure Centre", "locality": "Blackpool", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "queries": ["Moor Park Health and Leisure Centre Blackpool"], "city_override": "Blackpool"},
    {"name": "North Ormesby Health Village", "locality": "North Ormesby", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Nuffield Health Woking Hospital", "locality": "Woking", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "One Life Building", "locality": "Middlesbrough", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Parkside Hospital", "locality": "London", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "city_override": "London"},
    {"name": "Priory Health Park", "locality": "Wells", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Prospect View Medical Centre", "locality": "Malvern", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Ridge Medical Centre", "locality": "Bradford", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Severn Fields Health Village", "locality": "Harlescott", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Sheridan Specialist Education", "locality": "Thetford", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "South Bar House", "locality": "Banbury", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Spire Cheshire Hospital", "locality": "Stretton", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "St Paul's Medical Centre", "locality": "Cheltenham", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Stratford Healthcare Centre", "locality": "Stratford Upon Avon", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Sudbury Community Health Centre", "locality": "Sudbury", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "city_override": "Sudbury"},
    {"name": "Tees Valley Treatment Centre", "locality": "Middlesbrough", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "The Cavell Hospital", "locality": "Enfield", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "city_override": "London"},
    {"name": "The Huddersfield Hospital", "locality": "Huddersfield", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "The Lincoln Hospital", "locality": "Lincoln", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "The St Edmunds Hospital", "locality": "Bury St Edmunds", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "force_reject_reason": "Map result resolved only to a road-level address near the site, not a confirmed hospital listing"},
    {"name": "Todmorden Medical Centre", "locality": "Todmorden", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Turnpike House Medical Centre", "locality": "Worcester", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Wantage Health Centre", "locality": "Wantage", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025, "city_override": "Wantage"},
    {"name": "Waters Green Medical Centre", "locality": "Macclesfield", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Wheatbridge Health Centre", "locality": "Chesterfield", "country_hint": "GBR", "validation_url": ASSURA_REPORT_2025},
    {"name": "Wicklow Primary Healthcare Centre", "locality": "Knockrobin", "country_hint": "IRL", "validation_url": ASSURA_REPORT_2025},
    {"name": "South Petherton Medical Centre", "locality": "South Petherton", "country_hint": "GBR", "validation_url": PHP_ANNUAL_RESULTS_2024, "city_override": "South Petherton"},
    {"name": "Primrose Lane Medical Centre", "locality": "Rosyth", "country_hint": "GBR", "validation_url": PHP_ANNUAL_RESULTS_2024},
    {"name": "East Park Medical Centre", "locality": "Leeds", "country_hint": "GBR", "validation_url": PHP_ANNUAL_RESULTS_2024},
    {"name": "Youghal Primary Care Centre", "locality": "Youghal", "country_hint": "IRL", "validation_url": PHP_ANNUAL_RESULTS_2024},
    {"name": "Enniscorthy Primary Care Centre", "locality": "Enniscorthy", "country_hint": "IRL", "validation_url": PHP_CAPITAL_MARKETS_2024},
    {"name": "Enniscorthy Enhanced Community Care Centre", "locality": "Enniscorthy", "country_hint": "IRL", "validation_url": PHP_ANNUAL_RESULTS_2024},
    {"name": "Donnybrook Primary Care Centre", "locality": "Donnybrook", "country_hint": "IRL", "validation_url": PHP_ANNUAL_RESULTS_2024},
    {"name": "Peel Precinct Health Centre", "locality": "South Kilburn", "country_hint": "GBR", "validation_url": PHP_ANNUAL_RESULTS_2024},
    {"name": "Laya Health and Wellbeing Clinic", "locality": "Cork", "country_hint": "IRL", "validation_url": PHP_ANNUAL_RESULTS_2024},
    {"name": "Chiswick Medical Centre", "locality": "London", "country_hint": "GBR", "validation_url": PHP_CAPITAL_MARKETS_2024, "city_override": "London"},
    {"name": "Westfield Integrated Care Centre", "locality": "Ballincollig", "country_hint": "IRL", "validation_url": PHP_PORTFOLIO_PAGE, "city_override": "Ballincollig"},
    {"name": "Westfield Integrated Primary Care Centre", "locality": "Ballincollig", "country_hint": "IRL", "validation_url": PHP_CAPITAL_MARKETS_2024},
    {"name": "St Catherine's Health Centre", "locality": "Birkenhead", "country_hint": "GBR", "validation_url": PHP_CAPITAL_MARKETS_2024, "queries": ["St Catherines Health Centre Birkenhead"]},
    {"name": "Victoria Medical Centre", "locality": "Eastbourne", "country_hint": "GBR", "validation_url": PHP_CAPITAL_MARKETS_2024},
    {"name": "SA1 Medical Centre", "locality": "Swansea", "country_hint": "GBR", "validation_url": PHP_CAPITAL_MARKETS_2024},
    {"name": "Kilburn Park Medical Centre", "locality": "London", "country_hint": "GBR", "validation_url": PHP_YEAR_END_2025, "city_override": "London"},
    {"name": "Station Medical Centre", "locality": "Hereford", "country_hint": "GBR", "validation_url": PHP_YEAR_END_2025},
    {"name": "Stourside Hospital", "locality": "Stourbridge", "country_hint": "GBR", "validation_url": PHP_YEAR_END_2025, "city_override": "Stourbridge"},
    {"name": "Hadrian Health Centre", "locality": "Wallsend", "country_hint": "GBR", "validation_url": PHP_YEAR_END_2025, "city_override": "Wallsend"},
    {"name": "Sprowston Medical Centre", "locality": "Norwich", "country_hint": "GBR", "validation_url": PHP_YEAR_END_2025},
    {"name": "Ryalls Park Medical Centre", "locality": "Yeovil", "country_hint": "GBR", "validation_url": PHP_YEAR_END_2025},
    {"name": "Ballybay Primary Care Centre", "locality": "Ballybay", "country_hint": "IRL", "validation_url": PHP_YEAR_END_2025},
    {"name": "Bearwood Medical Centre", "locality": "Poole", "country_hint": "GBR", "validation_url": PHP_YEAR_END_2025},
    {"name": "St Clement's Surgery", "locality": "Winchester", "country_hint": "GBR", "validation_url": PHP_YEAR_END_2025, "queries": ["St Clements Surgery Winchester"]},
    {"name": "Eastergate Medical Centre", "locality": "Eastergate", "country_hint": "GBR", "validation_url": PHP_PORTFOLIO_PAGE, "city_override": "Eastergate"},
    {"name": "Bray Primary Care Centre", "locality": "Bray", "country_hint": "IRL", "validation_url": PHP_IRISH_PRESENTATION_2018},
    {"name": "Tipperary Primary Care Centre", "locality": "Tipperary", "country_hint": "IRL", "validation_url": PHP_IRISH_PRESENTATION_2018},
    {"name": "Carrigaline Primary Care Centre", "locality": "Carrigaline", "country_hint": "IRL", "validation_url": PHP_IRISH_PRESENTATION_2018},
    {"name": "Celbridge Primary Care Centre", "locality": "Celbridge", "country_hint": "IRL", "validation_url": PHP_IRISH_PRESENTATION_2018},
    {"name": "Navan Road Primary Care Centre", "locality": "Dublin", "country_hint": "IRL", "validation_url": PHP_IRISH_PRESENTATION_2018},
]


# ============================================================
# GENERIC EXTRACTION LOGIC - Do not modify per issuer
# ============================================================
CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
    "VALIDATION_URL",
]

REJECT_COLUMNS = CSV_COLUMNS + ["rejection_reason", "rejected_by"]

COUNTRY_CODE_TO_NAME = {
    "gb": ("United Kingdom", "GBR"),
    "ie": ("Ireland", "IRL"),
}


def build_session() -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": "Mozilla/5.0 (compatible; Codex named-asset extractor)",
            "Accept": "application/json",
        }
    )
    return session


def normalize_text(value: str) -> str:
    value = value.replace("\u2019", "'").replace("\u2013", "-").replace("\u2014", "-")
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def slug(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", normalize_text(value).lower()).strip()


def build_queries(asset: dict[str, Any]) -> list[str]:
    queries: list[str] = []
    name = asset["name"]
    locality = asset["locality"]
    custom = asset.get("queries", [])
    queries.extend(custom)
    queries.extend(
        [
            f"{name}, {locality}",
            f"{name} {locality}",
            name,
        ]
    )
    deduped: list[str] = []
    seen: set[str] = set()
    for query in queries:
        key = slug(query)
        if key and key not in seen:
            seen.add(key)
            deduped.append(query)
    return deduped


def fetch_nominatim(session: requests.Session, query: str) -> tuple[str, list[dict[str, Any]]]:
    params = {"format": "jsonv2", "limit": 3, "addressdetails": 1, "q": query}
    source_url = NOMINATIM_SEARCH_URL + "?" + urllib.parse.urlencode(params)
    response = session.get(NOMINATIM_SEARCH_URL, params=params, timeout=45)
    response.raise_for_status()
    time.sleep(REQUEST_DELAY_SECONDS)
    return source_url, response.json()


def locality_matches(asset: dict[str, Any], result: dict[str, Any]) -> bool:
    expected = slug(asset["locality"])
    haystacks = [
        slug(result.get("display_name", "")),
        slug(" ".join(str(v) for v in result.get("address", {}).values())),
    ]
    return any(expected and expected in hay for hay in haystacks)


def country_matches(asset: dict[str, Any], result: dict[str, Any]) -> bool:
    expected_iso3 = asset["country_hint"]
    address = result.get("address", {})
    country_code = str(address.get("country_code", "")).lower()
    mapping = COUNTRY_CODE_TO_NAME.get(country_code)
    return bool(mapping and mapping[1] == expected_iso3)


def significant_name_matches(asset: dict[str, Any], result: dict[str, Any]) -> bool:
    display = slug(result.get("display_name", ""))
    tokens = [token for token in slug(asset["name"]).split() if len(token) >= 5 and token not in {"centre", "center", "medical", "health", "primary", "care", "hospital"}]
    if not tokens:
        return True
    return any(token in display for token in tokens)


def required_display_tokens_match(asset: dict[str, Any], result: dict[str, Any]) -> bool:
    tokens = [slug(token) for token in asset.get("required_display_tokens", []) if slug(token)]
    if not tokens:
        return True
    display = slug(result.get("display_name", ""))
    return all(token in display for token in tokens)


def choose_result(asset: dict[str, Any], result_rows: list[dict[str, Any]]) -> dict[str, Any] | None:
    for result in result_rows:
        if (
            locality_matches(asset, result)
            and country_matches(asset, result)
            and significant_name_matches(asset, result)
            and required_display_tokens_match(asset, result)
        ):
            return result
    return None


def clean_component(value: str) -> str:
    value = normalize_text(value)
    return value.strip(",")


def build_address(result: dict[str, Any]) -> str:
    address = result.get("address", {})
    ordered_fields = [
        "house_number",
        "road",
        "pedestrian",
        "footway",
        "suburb",
        "city_district",
        "neighbourhood",
        "village",
        "town",
        "city",
        "county",
        "postcode",
        "country",
    ]
    pieces: list[str] = []
    seen: set[str] = set()
    for field in ordered_fields:
        value = clean_component(str(address.get(field, "")))
        key = slug(value)
        if value and key and key not in seen:
            pieces.append(value)
            seen.add(key)
    if not pieces:
        pieces.append(clean_component(result.get("display_name", "")))
    address_line = ", ".join(pieces)
    address_line = address_line.replace("#", "").replace("  ", " ").strip(" ,")
    return address_line


def derive_city(asset: dict[str, Any], result: dict[str, Any]) -> str:
    if asset.get("city_override"):
        return asset["city_override"]
    address = result.get("address", {})
    for field in ("city", "town", "village", "municipality", "suburb"):
        value = clean_component(str(address.get(field, "")))
        if value:
            return value
    return asset["locality"]


def derive_state(result: dict[str, Any]) -> str:
    address = result.get("address", {})
    for field in ("state", "county", "state_district", "region"):
        value = clean_component(str(address.get(field, "")))
        if value:
            return value
    return ""


def derive_postcode(result: dict[str, Any]) -> str:
    return clean_component(str(result.get("address", {}).get("postcode", "")))


def derive_country(result: dict[str, Any]) -> tuple[str, str]:
    address = result.get("address", {})
    code = str(address.get("country_code", "")).lower()
    if code in COUNTRY_CODE_TO_NAME:
        return COUNTRY_CODE_TO_NAME[code]
    return clean_component(str(address.get("country", ""))), ""


def derive_activity(location_name: str) -> str:
    name = slug(location_name)
    if "hospital" in name:
        return "Private hospital"
    if "oncology" in name or "diagnostic" in name or "treatment" in name:
        return "Diagnostic and treatment centre"
    if "clinic" in name:
        return "Healthcare clinic"
    if "surgery" in name:
        return "Primary healthcare surgery"
    if "specialist education" in name:
        return "Specialist education facility"
    if "health village" in name:
        return "Primary healthcare village"
    if "health park" in name:
        return "Healthcare campus"
    if "health centre" in name or "medical centre" in name or "primary care centre" in name or "integrated care centre" in name:
        return "Primary healthcare centre"
    return "Healthcare facility"


def make_row(asset: dict[str, Any], source_url: str, result: dict[str, Any]) -> dict[str, str]:
    country_name, country_iso3 = derive_country(result)
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": asset["name"],
        "LOCATION_ADDRESS": build_address(result),
        "LATITUDE": "",
        "LONGITUDE": "",
        "COUNTRY": country_name,
        "COUNTRY_ISO3": country_iso3,
        "POSTCODE": derive_postcode(result),
        "STATE": derive_state(result),
        "CITY": derive_city(asset, result),
        "SOURCE_URL": source_url,
        "SOURCE_TYPE": "MAP SERVICE",
        "ACTIVITY_AT_ASSET": derive_activity(asset["name"]),
        "coord_source": "Not from website",
        "QA_flag": "",
        "VALIDATION_URL": asset["validation_url"],
    }


def resolve_assets() -> tuple[list[dict[str, str]], list[dict[str, str]], list[dict[str, Any]]]:
    session = build_session()
    resolved_rows: list[dict[str, str]] = []
    rejected_rows: list[dict[str, str]] = []
    resolution_log: list[dict[str, Any]] = []
    seen_row_keys: set[tuple[str, str]] = set()

    for asset in OFFICIAL_ASSETS:
        asset_log: OrderedDict[str, Any] = OrderedDict()
        asset_log["name"] = asset["name"]
        asset_log["locality"] = asset["locality"]
        asset_log["validation_url"] = asset["validation_url"]
        asset_log["attempts"] = []
        accepted_result: dict[str, Any] | None = None
        accepted_source_url = ""

        for query in build_queries(asset):
            try:
                source_url, result_rows = fetch_nominatim(session, query)
            except Exception as exc:
                asset_log["attempts"].append({"query": query, "error": repr(exc)})
                continue
            asset_log["attempts"].append({"query": query, "results": [row.get("display_name", "") for row in result_rows[:3]]})
            accepted_result = choose_result(asset, result_rows)
            if accepted_result:
                accepted_source_url = source_url
                break

        if accepted_result is None:
            rejected_rows.append(
                {
                    "ISSUER_ID": ISSUER_ID,
                    "ISSUER_NAME": ISSUER_NAME,
                    "LOCATION_NAME": asset["name"],
                    "LOCATION_ADDRESS": "",
                    "LATITUDE": "",
                    "LONGITUDE": "",
                    "COUNTRY": "Ireland" if asset["country_hint"] == "IRL" else "United Kingdom",
                    "COUNTRY_ISO3": asset["country_hint"],
                    "POSTCODE": "",
                    "STATE": "",
                    "CITY": asset["locality"],
                    "SOURCE_URL": "",
                    "SOURCE_TYPE": "MAP SERVICE",
                    "ACTIVITY_AT_ASSET": derive_activity(asset["name"]),
                    "coord_source": "Not from website",
                    "QA_flag": "",
                    "VALIDATION_URL": asset["validation_url"],
                    "rejection_reason": "Unable to resolve a locality-matching address from map service",
                    "rejected_by": "worker_qa",
                }
            )
            asset_log["status"] = "rejected"
            resolution_log.append(asset_log)
            continue

        if asset.get("force_reject_reason"):
            rejected_rows.append(
                {
                    "ISSUER_ID": ISSUER_ID,
                    "ISSUER_NAME": ISSUER_NAME,
                    "LOCATION_NAME": asset["name"],
                    "LOCATION_ADDRESS": build_address(accepted_result),
                    "LATITUDE": "",
                    "LONGITUDE": "",
                    "COUNTRY": derive_country(accepted_result)[0],
                    "COUNTRY_ISO3": derive_country(accepted_result)[1],
                    "POSTCODE": derive_postcode(accepted_result),
                    "STATE": derive_state(accepted_result),
                    "CITY": derive_city(asset, accepted_result),
                    "SOURCE_URL": accepted_source_url,
                    "SOURCE_TYPE": "MAP SERVICE",
                    "ACTIVITY_AT_ASSET": derive_activity(asset["name"]),
                    "coord_source": "Not from website",
                    "QA_flag": "",
                    "VALIDATION_URL": asset["validation_url"],
                    "rejection_reason": asset["force_reject_reason"],
                    "rejected_by": "worker_qa",
                }
            )
            asset_log["status"] = "rejected"
            asset_log["accepted_display_name"] = accepted_result.get("display_name", "")
            resolution_log.append(asset_log)
            continue

        row = make_row(asset, accepted_source_url, accepted_result)
        row_key = (slug(row["LOCATION_NAME"]), slug(row["LOCATION_ADDRESS"]))
        if row_key in seen_row_keys:
            asset_log["status"] = "deduped"
            asset_log["accepted_display_name"] = accepted_result.get("display_name", "")
            resolution_log.append(asset_log)
            continue

        seen_row_keys.add(row_key)
        asset_log["status"] = "accepted"
        asset_log["accepted_display_name"] = accepted_result.get("display_name", "")
        asset_log["source_url"] = accepted_source_url
        resolution_log.append(asset_log)
        resolved_rows.append(row)

    resolved_rows.sort(key=lambda row: (row["COUNTRY_ISO3"], row["CITY"], row["LOCATION_NAME"]))
    rejected_rows.sort(key=lambda row: (row["COUNTRY_ISO3"], row["CITY"], row["LOCATION_NAME"]))
    return resolved_rows, rejected_rows, resolution_log


def write_csv(path_str: str, rows: list[dict[str, str]], fieldnames: list[str]) -> None:
    path = Path(path_str)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def write_json(path_str: str, payload: Any) -> None:
    path = Path(path_str)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def main() -> None:
    rows, rejected_rows, resolution_log = resolve_assets()
    write_csv(STAGING_CSV, rows, CSV_COLUMNS)
    if rejected_rows:
        write_csv(REJECT_CSV, rejected_rows, REJECT_COLUMNS)
    write_json(
        RESOLUTION_LOG,
        {
            "issuer_id": ISSUER_ID,
            "issuer_name": ISSUER_NAME,
            "target_count": COUNT_THRESHOLD,
            "accepted_rows": len(rows),
            "rejected_rows": len(rejected_rows),
            "resolution_log": resolution_log,
        },
    )
    print(
        json.dumps(
            {
                "accepted_rows": len(rows),
                "rejected_rows": len(rejected_rows),
                "staging_csv": STAGING_CSV,
                "reject_csv": REJECT_CSV if rejected_rows else None,
                "resolution_log": RESOLUTION_LOG,
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
