from __future__ import annotations

import csv
from io import BytesIO
from pathlib import Path

import requests
from pypdf import PdfReader


ISSUER_ID = "IID000000002183294"
ISSUER_NAME = "Shandong Gold Mining Co., Ltd."
OUTPUT_CSV = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output\Extraction_Batch_20260410_123343\IID000000002183294_Shandong Gold Mining Co., Ltd..csv"
)

HEADERS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
]

WRAPPER_IDS = [
    4170,
    4171,
    4172,
    4173,
    4174,
    4175,
    4650,
    4652,
    5254,
    5255,
    5256,
    5257,
    5258,
    5259,
    5260,
    5261,
]

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "Mozilla/5.0"})


def wrapper_url(page_id: int) -> str:
    return f"https://www.sd-gold.com/cmscontent/{page_id}.html"


def after_colon(text: str) -> str:
    for sep in ("：", ":"):
        if sep in text:
            return text.split(sep, 1)[1].strip()
    return text.strip()


def clean_name(text: str) -> str:
    value = after_colon(text)
    for token in ("简称", "简 称"):
        if token in value:
            value = value.split(token, 1)[0].strip()
    return value


def clean_block(text: str) -> str:
    value = after_colon(text)
    for token in (
        "邮政编码",
        "二、公司简介",
        "二、",
        "二.公司简介",
        "二.",
        "经营范围",
        "4.经营范围",
        "4、经营范围",
    ):
        if token in value:
            value = value.split(token, 1)[0].strip()
    return value.rstrip("。").strip()


def extract_block(lines: list[str], prefixes: tuple[str, ...], stop_prefixes: tuple[str, ...], cleaner) -> str:
    for i, line in enumerate(lines):
        if any(line.startswith(prefix) for prefix in prefixes):
            parts = [line]
            for nxt in lines[i + 1 :]:
                if any(nxt.startswith(stop) for stop in stop_prefixes):
                    break
                parts.append(nxt)
            joined = "".join(parts)
            return cleaner(joined)
    return ""


def extract_postcode(lines: list[str]) -> str:
    for line in lines:
        if line.startswith("邮政编码"):
            return after_colon(line)
    return ""


def parse_state_city(address: str) -> tuple[str, str]:
    municipalities = ("北京市", "天津市", "上海市", "重庆市")
    for municipality in municipalities:
        if address.startswith(municipality):
            return municipality, municipality

    state = ""
    city = ""

    if "自治区" in address:
        state = address.split("自治区", 1)[0] + "自治区"
        remainder = address.split("自治区", 1)[1]
        for token in ("盟", "州", "市"):
            if token in remainder:
                city = remainder.split(token, 1)[0] + token
                break
        return state, city

    if "省" in address:
        state = address.split("省", 1)[0] + "省"
        remainder = address.split("省", 1)[1]
        for token in ("市", "州"):
            if token in remainder:
                city = remainder.split(token, 1)[0] + token
                break
        return state, city

    for token in ("市", "州", "盟"):
        if token in address:
            city = address.split(token, 1)[0] + token
            break
    return state, city


def fetch_pdf_url(page_id: int) -> str:
    url = wrapper_url(page_id)
    html = SESSION.get(url, timeout=30, verify=False).text
    marker = "https://video.ceultimate.com/"
    start = html.find(marker)
    if start == -1:
        raise ValueError(f"No attachment link found for {url}")
    end = html.find(".pdf", start)
    if end == -1:
        raise ValueError(f"No PDF attachment found for {url}")
    return html[start : end + 4]


def fetch_lines(page_id: int) -> list[str]:
    pdf_url = fetch_pdf_url(page_id)
    response = SESSION.get(
        pdf_url,
        timeout=60,
        verify=False,
        headers={"Referer": wrapper_url(page_id)},
    )
    response.raise_for_status()
    reader = PdfReader(BytesIO(response.content))
    text = "\n".join((page.extract_text() or "") for page in reader.pages[:8])
    return [line.strip() for line in text.splitlines() if line.strip()]


def build_row(page_id: int) -> dict[str, str]:
    lines = fetch_lines(page_id)
    name = extract_block(lines, ("1.", "1、"), ("简称", "简 称", "2.", "2、"), clean_name)
    reg = extract_block(lines, ("3.", "3、"), ("4.", "4、", "5.", "5、"), clean_block)
    office = extract_block(lines, ("5.", "5、"), ("邮政编码", "6.", "6、", "二、", "二."), clean_block)
    postcode = extract_postcode(lines)
    address = office or reg
    state, city = parse_state_city(address)

    if not name or not address:
        raise ValueError(f"Missing parsed name/address for {page_id}")

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": name,
        "LOCATION_ADDRESS": address,
        "LATITUDE": "",
        "LONGITUDE": "",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": wrapper_url(page_id),
        "SOURCE_TYPE": "COMPANY REPORT",
        "ACTIVITY_AT_ASSET": "Subsidiary company office",
        "coord_source": "Not from website",
    }


def main() -> None:
    rows = [build_row(page_id) for page_id in WRAPPER_IDS]
    OUTPUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT_CSV.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=HEADERS)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {len(rows)} rows to {OUTPUT_CSV}")


if __name__ == "__main__":
    main()
