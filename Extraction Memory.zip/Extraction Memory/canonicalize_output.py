#!/usr/bin/env python3
"""
canonicalize_output.py  -  normalize the promoted issuer CSVs to ONE stable schema.

What it does (idempotent, safe to re-run):
  1. CANONICAL SCHEMA = the UNION of every column seen across all issuer files,
     written in a fixed order. This only ever ADDS a missing column (left blank)
     to a file that lacked it - it NEVER drops a column. Any column that is not in
     the known list is appended at the end (still never dropped), so a future field
     added by the extractor survives untouched.
  2. WHITESPACE NORMALIZATION - trim each cell and collapse internal runs of
     whitespace/newlines to a single space. Native-script text is preserved.
  3. EXACT-DUPLICATE removal - drop rows that are identical across ALL columns
     (keep the first). Genuine multi-unit rows that merely share an address are
     KEPT and only reported (never deleted). Disable with --no-dedup.
  4. QUALITY FLOOR - drop rows that carry no usable locator at all: no name, no
     address (native or latin), and no coordinates. These are placeholder / padding
     rows (e.g. a bare city) that are unusable downstream. Disable with --keep-empty.

Every output CSV ends up with identical columns in identical order, so the full
set concatenates cleanly and hands off cleanly to the geocoding service.

Usage:
    python canonicalize_output.py <dir> [--no-dedup] [--keep-empty]

Writes <dir>/_canonicalize_report.txt with a per-file before/after summary and an
explicit "columns dropped = 0" assertion.
"""
import csv, glob, os, re, sys

csv.field_size_limit(10 ** 7)

# Fixed logical order for the columns we know about. Always emitted (blank if a
# given batch never produced one) so every batch has an identical contract.
KNOWN_ORDER = [
    "ISSUER_ID", "COMPANY_NAME",
    "FACILITY_NAME", "FACILITY_NAME_NATIVE",
    "FACILITY_ADDRESS", "FACILITY_ADDRESS_NATIVE",
    "CITY", "STATE", "POSTAL_CODE", "FACILITY_REGION", "COUNTRY_ISO3",
    "LATITUDE", "LONGITUDE", "coord_source",
    "ACTIVITY_AT_ASSET",
    "FACILITY_CONTACT_NUMBER",
    "SCOPE", "SCOPE_REASON",
    "RELEVANT_URL", "SOURCE_TYPE",
    "VALIDATION_URL", "VALIDATION_SOURCE_TYPE",
    "QA_flag",
]

# Legacy -> current header names. Applied when reading each file so older outputs
# (written under the previous names) conform to the current schema instead of being
# dropped or duplicated as "extra" columns.
RENAME_MAP = {
    "ISSUER_NAME": "COMPANY_NAME",
    "LOCATION_NAME": "FACILITY_NAME",
    "LOCATION_NAME_NATIVE": "FACILITY_NAME_NATIVE",
    "LOCATION_ADDRESS": "FACILITY_ADDRESS",
    "LOCATION_ADDRESS_NATIVE": "FACILITY_ADDRESS_NATIVE",
    "POSTCODE": "POSTAL_CODE",
    "POSTALCODE": "POSTAL_CODE",
    "COUNTRY": "FACILITY_REGION",
    "SOURCE_URL": "RELEVANT_URL",
}

_ws = re.compile(r"\s+")


def norm(v):
    if v is None:
        return ""
    return _ws.sub(" ", str(v)).strip()


def read_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as fh:
        r = csv.reader(fh)
        rows = list(r)
    if not rows:
        return [], []
    return rows[0], rows[1:]


def union_csv(dest, inputs):
    """Union the rows of several CSVs (header union, exact-duplicate removal)."""
    union, extra, rowsets = set(), [], []
    for p in inputs:
        hdr, data = read_csv(p)
        hdr = [RENAME_MAP.get(c, c) for c in hdr]
        rowsets.append((hdr, data))
        for c in hdr:
            if c not in union:
                union.add(c)
                if c not in KNOWN_ORDER:
                    extra.append(c)
    cols = [c for c in KNOWN_ORDER if c in union] + extra
    seen, out = set(), []
    for hdr, data in rowsets:
        idx = {c: i for i, c in enumerate(hdr)}
        for row in data:
            vals = [norm(row[idx[c]]) if c in idx and idx[c] < len(row) else "" for c in cols]
            key = tuple(vals)
            if key in seen:
                continue
            seen.add(key)
            out.append(vals)
    with open(dest, "w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh, quoting=csv.QUOTE_MINIMAL)
        w.writerow(cols)
        w.writerows(out)
    return len(out)


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    flags = [a for a in sys.argv[1:] if a.startswith("--")]
    if "--union" in flags:
        if len(args) < 2:
            print("usage: python canonicalize_output.py --union <dest> <in1> [in2 ...]")
            return 2
        n = union_csv(args[0], args[1:])
        print(f"UNION_ROWS={n}")
        return 0
    if not args:
        print("usage: python canonicalize_output.py <dir> [--no-dedup]")
        return 2
    target_dir = args[0]
    do_dedup = "--no-dedup" not in flags
    drop_empty = "--keep-empty" not in flags   # drop rows with no name/address/coords (placeholder padding)

    files = sorted(
        f for f in glob.glob(os.path.join(target_dir, "*.csv"))
        if not os.path.basename(f).startswith("_")
    )
    if not files:
        print(f"no issuer CSVs found in {target_dir}")
        return 0

    # ---- pass 1: build the canonical (union) schema -------------------------
    union, extra_order = set(), []
    headers = {}
    for f in files:
        hdr, _ = read_csv(f)
        hdr = [RENAME_MAP.get(c, c) for c in hdr]
        headers[f] = hdr
        for c in hdr:
            if c not in union:
                union.add(c)
                if c not in KNOWN_ORDER:
                    extra_order.append(c)
    canonical = [c for c in KNOWN_ORDER] + extra_order   # known (always) + any extras
    # safety: the canonical schema must be a SUPERSET of every file's columns
    for f in files:
        missing = [c for c in headers[f] if c not in canonical]
        assert not missing, f"BUG: would drop {missing} from {os.path.basename(f)}"

    # column indices used by the quality floor (computed once; canonical is fixed)
    def _ci(c): return canonical.index(c) if c in canonical else -1
    _i_name, _i_namen = _ci("FACILITY_NAME"), _ci("FACILITY_NAME_NATIVE")
    _i_addr, _i_addren = _ci("FACILITY_ADDRESS"), _ci("FACILITY_ADDRESS_NATIVE")
    _i_lat, _i_lon = _ci("LATITUDE"), _ci("LONGITUDE")
    def _is_empty(vals):
        g = lambda i: (vals[i] if 0 <= i < len(vals) else "")
        has_name  = bool(g(_i_name) or g(_i_namen))
        has_addr  = bool(g(_i_addr) or g(_i_addren))
        has_coord = bool(g(_i_lat) and g(_i_lon))
        return not (has_name or has_addr or has_coord)

    # ---- pass 2: rewrite each file to the canonical schema ------------------
    report, tot_in, tot_out, tot_dups, tot_collide, tot_empty = [], 0, 0, 0, 0, 0
    for f in files:
        hdr, data = read_csv(f)
        hdr = [RENAME_MAP.get(c, c) for c in hdr]
        idx = {c: i for i, c in enumerate(hdr)}
        seen, out_rows, dups, empties = set(), [], 0, 0
        addr_names = {}
        for row in data:
            vals = [norm(row[idx[c]]) if c in idx and idx[c] < len(row) else "" for c in canonical]
            if drop_empty and _is_empty(vals):
                empties += 1
                continue
            key = tuple(vals)
            if do_dedup and key in seen:
                dups += 1
                continue
            seen.add(key)
            out_rows.append(vals)
            a = vals[canonical.index("FACILITY_ADDRESS")] if "FACILITY_ADDRESS" in canonical else ""
            n = vals[canonical.index("FACILITY_NAME")] if "FACILITY_NAME" in canonical else ""
            if a:
                addr_names.setdefault(a, set()).add(n)
        collisions = sum(1 for a, ns in addr_names.items() if len(ns) > 1)
        with open(f, "w", encoding="utf-8", newline="") as fh:
            w = csv.writer(fh, quoting=csv.QUOTE_MINIMAL)
            w.writerow(canonical)
            w.writerows(out_rows)
        tot_in += len(data); tot_out += len(out_rows); tot_dups += dups; tot_collide += collisions; tot_empty += empties
        report.append((os.path.basename(f), len(hdr), len(canonical), len(data), len(out_rows), dups, empties, collisions))

    # ---- report -------------------------------------------------------------
    lines = []
    lines.append("CANONICALIZE REPORT")
    lines.append("=" * 60)
    lines.append(f"files processed : {len(files)}")
    lines.append(f"canonical cols  : {len(canonical)}  (known={len(KNOWN_ORDER)}, extra-appended={len(extra_order)})")
    lines.append(f"columns dropped : 0  (schema is the UNION of all files; only additive)")
    if extra_order:
        lines.append(f"extra cols kept : {extra_order}")
    lines.append(f"dedup           : {'ON' if do_dedup else 'OFF'}")
    lines.append(f"rows in/out     : {tot_in} -> {tot_out}   (exact dups removed: {tot_dups}; empty dropped: {tot_empty})")
    lines.append(f"empty rows      : {tot_empty}  (no name/address/coords - dropped as unusable; disable with --keep-empty)")
    lines.append(f"addr collisions : {tot_collide}  (same address, different name/unit - KEPT, not removed)")
    lines.append("")
    lines.append("canonical column order:")
    for i, c in enumerate(canonical):
        lines.append(f"  {i+1:2d}. {c}")
    lines.append("")
    lines.append(f"{'file':<46}{'cols(in->canon)':>17}{'rows(in->out)':>15}{'dups':>6}{'empty':>7}{'collide':>9}")
    for nm, ci, cc, ri, ro, d, e, col in report:
        lines.append(f"{nm[:44]:<46}{(str(ci)+'->'+str(cc)):>17}{(str(ri)+'->'+str(ro)):>15}{d:>6}{e:>7}{col:>9}")
    out = os.path.join(target_dir, "_canonicalize_report.txt")
    with open(out, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    print("\n".join(lines[:9]))
    print(f"\nfull report -> {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
