"""
Extract travel-agency records from TUI's official cloud travel-agency-finder API.

Pattern handled:
  TUI cloud travel-agency-finder API exposed by country retail pages such as:
    - https://www.tui.com/reisebuero/
    - https://www.tui.at/reisebuero/
    - https://www.tui.ch/de/reisebuero/

How to reuse:
  1. Edit the CONFIGURATION block only.
  2. Add or remove country source configs as needed.
  3. Run the script with Python 3. It writes a CSV in the standard output schema.

Usage:
  python cloud_tui_travel_agency_finder_extractor.py
"""

from __future__ import annotations

import csv
import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import requests


# ============================================================
# CONFIGURATION - Edit this block for each new issuer
# ============================================================
ISSUER_ID = "IID000000002185975"
ISSUER_NAME = "TUI AG"
OUTPUT_CSV = Path(r"C:\temp\IID000000002185975_TUI_AG.csv")


@dataclass(frozen=True)
class SourceConfig:
    code: str
    locale: str
    api_country: str
    lat: float
    lng: float
    types: str
    country_name: str
    country_iso3: str
    source_page: str


SOURCES = [
    SourceConfig(
        code="DE",
        locale="de",
        api_country="de",
        lat=51.163375,
        lng=10.447683,
        types="",
        country_name="Germany",
        country_iso3="DEU",
        source_page="https://www.tui.com/reisebuero/",
    ),
    SourceConfig(
        code="AT",
        locale="de",
        api_country="at",
        lat=47.516231,
        lng=14.550072,
        types="FN,FL",
        country_name="Austria",
        country_iso3="AUT",
        source_page="https://www.tui.at/reisebuero/",
    ),
    SourceConfig(
        code="CH",
        locale="de",
        api_country="ch",
        lat=46.818188,
        lng=8.227512,
        types="",
        country_name="Switzerland",
        country_iso3="CHE",
        source_page="https://www.tui.ch/de/reisebuero/",
    ),
]


# ============================================================
# GENERIC EXTRACTION LOGIC - Do not modify per issuer
# ============================================================
PAGE_SIZE = 50
HTTP_HEADERS = {"User-Agent": "Mozilla/5.0"}
FIELDNAMES = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS_NATIVE",
]


def has_non_ascii(value: str) -> bool:
    return any(ord(ch) > 127 for ch in (value or ""))


def transliterate(value: str) -> str:
    text = unicodedata.normalize("NFC", value or "")
    replacements = {
        "\u00df": "ss",
        "\u1e9e": "SS",
        "\u00e4": "ae",
        "\u00c4": "Ae",
        "\u00f6": "oe",
        "\u00d6": "Oe",
        "\u00fc": "ue",
        "\u00dc": "Ue",
    }
    for src, dst in replacements.items():
        text = text.replace(src, dst)
    text = unicodedata.normalize("NFKD", text)
    text = text.encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def api_url(source: SourceConfig, page_num: int) -> str:
    return (
        f"https://api.cloud.tui.com/travel-agency-finder/{source.locale}/agencies/{source.api_country}"
        f"?lat={source.lat}&lng={source.lng}&page={page_num}&sort=distance&types={source.types}"
    )


def build_native_address(agency: dict) -> str:
    parts = []
    street = (agency.get("street") or "").strip()
    zip_code = (agency.get("zip") or "").strip()
    town = (agency.get("town") or "").strip()
    region = (agency.get("region") or "").strip()
    country = (agency.get("country") or "").strip()
    if street:
        parts.append(street)
    city_part = " ".join(part for part in [zip_code, town] if part)
    if city_part:
        parts.append(city_part)
    if region:
        parts.append(region)
    if country:
        parts.append(country)
    return ", ".join(parts)


def build_native_name(agency: dict) -> str:
    name = (agency.get("name") or "").strip()
    town = (agency.get("town") or "").strip()
    if town and town.lower() not in name.lower():
        return f"{name} - {town}"
    return name


def fetch_source(source: SourceConfig) -> list[dict]:
    session = requests.Session()
    page_num = 0
    agencies: list[dict] = []
    while True:
        url = api_url(source, page_num)
        response = session.get(url, headers=HTTP_HEADERS, timeout=30)
        response.raise_for_status()
        payload = response.json()
        page_rows = payload.get("agencies", [])
        for agency in page_rows:
            agency["_source_api_url"] = url
            agencies.append(agency)
        if not page_rows:
            break
        count = payload.get("count", len(page_rows))
        offset = payload.get("offset", page_num * PAGE_SIZE)
        if offset + count >= payload.get("totalCount", 0):
            break
        page_num += 1
    return agencies


def normalize_rows() -> Iterable[dict]:
    seen: set[str] = set()
    for source in SOURCES:
        for agency in fetch_source(source):
            native_name = build_native_name(agency)
            native_address = build_native_address(agency)
            dedupe_key = agency.get("detailLink") or (
                f"{source.code}|{agency.get('zip','')}|{agency.get('town','')}|"
                f"{agency.get('street','')}|{agency.get('name','')}"
            )
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)
            yield {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": transliterate(native_name),
                "LOCATION_ADDRESS": transliterate(native_address),
                "LATITUDE": agency.get("lat", ""),
                "LONGITUDE": agency.get("lng", ""),
                "COUNTRY": source.country_name,
                "COUNTRY_ISO3": source.country_iso3,
                "POSTCODE": transliterate((agency.get("zip") or "").strip()),
                "STATE": transliterate((agency.get("region") or "").strip()),
                "CITY": transliterate((agency.get("town") or "").strip()),
                "SOURCE_URL": agency["_source_api_url"],
                "SOURCE_TYPE": "COMPANY WEBSITE",
                "ACTIVITY_AT_ASSET": "Travel Agency",
                "coord_source": "website" if agency.get("lat") and agency.get("lng") else "Not from website",
                "QA_flag": "",
                "LOCATION_NAME_NATIVE": native_name if has_non_ascii(native_name) else "",
                "LOCATION_ADDRESS_NATIVE": native_address if has_non_ascii(native_address) else "",
            }


def main() -> None:
    OUTPUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT_CSV.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDNAMES)
        writer.writeheader()
        for row in normalize_rows():
            writer.writerow(row)
    print(f"Wrote {OUTPUT_CSV}")


if __name__ == "__main__":
    main()
