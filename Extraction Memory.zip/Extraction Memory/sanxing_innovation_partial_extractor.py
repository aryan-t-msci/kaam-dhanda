"""
Sanxing innovation-page extractor.

Captures the exact R&D center addresses plus the manufacturing-base entries
whose city-level location text is still usable from the official innovation
page. This produces a defensible partial output for the gap case.
"""

from __future__ import annotations

import csv
from pathlib import Path

import requests
from bs4 import BeautifulSoup


ISSUER_ID = "IID000000002620187"
ISSUER_NAME = "NINGBO SANXING MEDICAL ELECTRIC Co.,Ltd."
INNOVATION_URL = "https://www.sanxingelectric.com/innovation/"
NANSEN_CONTACT_URL = "https://nansen.com.br/contato/"
KENYA_NEWS_URL = "https://www.sanxingelectric.com/company/media/news/1792.html"
OUTPUT_CSV = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output\Extraction_Batch_20260410_123343\IID000000002620187_NINGBO SANXING MEDICAL ELECTRIC Co.,Ltd..csv"
)

HEADERS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
]


def build_row(
    name: str,
    address: str,
    country: str,
    iso3: str,
    state: str,
    city: str,
    postcode: str,
    activity: str,
    source_url: str,
) -> dict:
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": name,
        "LOCATION_ADDRESS": address,
        "LATITUDE": "",
        "LONGITUDE": "",
        "COUNTRY": country,
        "COUNTRY_ISO3": iso3,
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": source_url,
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": activity,
        "coord_source": "Not from website",
    }


def fetch_rows() -> list[dict]:
    html = requests.get(
        INNOVATION_URL,
        timeout=30,
        verify=False,
        headers={"User-Agent": "Mozilla/5.0"},
    ).text
    soup = BeautifulSoup(html, "html.parser")
    rows: list[dict] = []

    for item in soup.select(".icru-li"):
        name = " ".join(item.select_one(".icru-li-tit p").stripped_strings)
        address = " ".join(item.select_one(".icru-li-info").stripped_strings).replace("Located in ", "").strip().rstrip(".")
        country, iso3, state, city, postcode = parse_rd(address)
        rows.append(
            build_row(
                name,
                address,
                country,
                iso3,
                state,
                city,
                postcode,
                "R&D center",
                INNOVATION_URL,
            )
        )

    for item in soup.select(".iibu-li"):
        name = " ".join(item.select_one(".iwhb-tit").stripped_strings)
        address = " ".join(item.select_one(".iwhb-info").stripped_strings).strip()
        normalized = (
            address.replace("·", " ")
            .replace("Â", "")
            .replace("Ā", " ")
            .replace("  ", " ")
            .strip()
        )
        if (
            "Minas Gerais" in normalized
            or "Jalisco state" in normalized
            or normalized == "Kenya"
        ):
            continue
        country, iso3, state, city = parse_base(normalized)
        rows.append(
            build_row(
                name,
                normalized,
                country,
                iso3,
                state,
                city,
                "",
                "Manufacturing base",
                INNOVATION_URL,
            )
        )
    rows.extend(recovered_rows())
    return rows


def recovered_rows() -> list[dict]:
    return [
        build_row(
            "Brazil",
            "Av. Dr. Antonio Chagas Diniz, 1500, Cidade Industrial, Contagem, Minas Gerais 32210-160, Brazil",
            "Brazil",
            "BRA",
            "Minas Gerais",
            "Contagem",
            "32210-160",
            "Manufacturing base",
            NANSEN_CONTACT_URL,
        ),
        build_row(
            "Mexico",
            "Avenida Del Carmen 230, La Llave, 45610 San Pedro Tlaquepaque, Jalisco, Mexico",
            "Mexico",
            "MEX",
            "Jalisco",
            "San Pedro Tlaquepaque",
            "45610",
            "Manufacturing base",
            NANSEN_CONTACT_URL,
        ),
        build_row(
            "Kenya",
            "Nairobi, Kenya",
            "Kenya",
            "KEN",
            "Nairobi County",
            "Nairobi",
            "",
            "Manufacturing base",
            KENYA_NEWS_URL,
        ),
    ]


def parse_rd(address: str) -> tuple[str, str, str, str, str]:
    if "Ningbo" in address:
        return "China", "CHN", "Zhejiang", "Ningbo", "315034"
    if "Shenzhen" in address:
        return "China", "CHN", "Guangdong", "Shenzhen", ""
    if "Hangzhou" in address:
        return "China", "CHN", "Zhejiang", "Hangzhou", ""
    if "Qingdao" in address:
        return "China", "CHN", "Shandong", "Qingdao", ""
    raise ValueError(address)


def parse_base(address: str) -> tuple[str, str, str, str]:
    if "Ningbo" in address:
        return "China", "CHN", "Zhejiang", "Ningbo"
    if "Serang" in address:
        return "Indonesia", "IDN", "Banten", "Serang"
    if "Poland" in address:
        return "Poland", "POL", "", "Swidnica"
    if "Germany" in address or "German" in address:
        return "Germany", "DEU", "North Rhine-Westphalia", "Bielefeld"
    raise ValueError(address)


def main() -> None:
    rows = fetch_rows()
    OUTPUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT_CSV.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=HEADERS)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {len(rows)} rows to {OUTPUT_CSV}")


if __name__ == "__main__":
    main()
