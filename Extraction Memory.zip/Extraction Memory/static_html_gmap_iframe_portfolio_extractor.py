"""
Static HTML portfolio gallery + Google Maps iframe extractor.

This variant handles sites where:
- listing pages are static HTML grids of detail links
- detail pages expose `iframe#gmap_canvas` with website-sourced coordinates
- the page does not print a clean structured street address
"""

from __future__ import annotations

import csv
import json
import math
import re
import time
import unicodedata
from pathlib import Path
from typing import Dict, List, Tuple
from urllib.parse import unquote, urljoin

import requests
import urllib3
from bs4 import BeautifulSoup


ISSUER_ID = "IID000000002615109"
ISSUER_NAME = "Fibra Uno Administracion S.C."
COUNTRY = "Mexico"
COUNTRY_ISO3 = "MEX"
SOURCE_TYPE = "COMPANY WEBSITE"
COUNT_THRESHOLD = 161

LISTINGS = [
    ("Retail", "https://funo.mx/propiedades/portafolio-comercial", "/propiedades/portafolio-comercial/", "Retail / shopping center"),
    ("Industrial", "https://funo.mx/propiedades/portafolio-industrial", "/propiedades/portafolio-industrial/", "Industrial property"),
    ("Office", "https://funo.mx/propiedades/portafolio-oficinas", "/propiedades/portafolio-oficinas/", "Office property"),
    ("Mixed Use", "https://funo.mx/propiedades/portafolio-uso-mixto", "/propiedades/portafolio-mixtos/", "Mixed-use property"),
]
CONTACT_URL = "https://funo.mx/contacto"

TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")
OUTPUT_BASENAME = f"{ISSUER_ID}_Fibra Uno Administracion S.C"
FINAL_CSV = OUTPUT_DIR / f"{OUTPUT_BASENAME}.csv"
CHECKPOINT_CSV = TEMP_DIR / f"{OUTPUT_BASENAME}_checkpoint.csv"
PROGRESS_JSON = TEMP_DIR / f"{ISSUER_ID}_progress.json"
URLS_JSON = TEMP_DIR / f"{ISSUER_ID}_detail_urls.json"
GEOCODE_JSON = TEMP_DIR / f"{ISSUER_ID}_geocode_cache.json"
SUMMARY_JSON = TEMP_DIR / f"{ISSUER_ID}_summary.json"
MEMORY_DRAFT = TEMP_DIR / f"{ISSUER_ID}_memory_append_draft.md"

CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS",
    "LOCATION_ADDRESS_NATIVE",
    "LATITUDE",
    "LONGITUDE",
    "coord_source",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
]

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def ascii_text(value: str) -> str:
    value = value.replace("\u00a0", " ").replace("\u2013", "-").replace("\u2014", "-")
    return unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")


def clean(value: str) -> str:
    value = re.sub(r"\s+", " ", value.replace("\r", " ").replace("\n", " ")).strip()
    return value.replace(" ,", ",").strip(" ,")


def geocode_friendly(value: str) -> str:
    return clean(value.replace("#", ""))


def write_json(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def load_json(path: Path, default):
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else default


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 6371.0 * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def build_session() -> requests.Session:
    s = requests.Session()
    s.headers.update({"User-Agent": "Mozilla/5.0 (compatible; Codex extractor)"})
    return s


def fetch(session: requests.Session, url: str, **kwargs) -> str:
    r = session.get(url, timeout=45, verify=False, **kwargs)
    r.raise_for_status()
    return r.text


def collect_targets(session: requests.Session) -> List[dict]:
    targets, seen = [], set()
    for label, listing_url, prefix, activity in LISTINGS:
        soup = BeautifulSoup(fetch(session, listing_url), "html.parser")
        for a in soup.find_all("a", href=True):
            detail_url = urljoin(listing_url, a["href"]).split("#", 1)[0].rstrip("/")
            if prefix not in detail_url or detail_url in seen:
                continue
            seen.add(detail_url)
            targets.append({"category": label, "listing_url": listing_url, "detail_url": detail_url, "activity": activity})
    return sorted(targets, key=lambda x: (x["category"], x["detail_url"]))


def extract_title(soup: BeautifulSoup) -> str:
    node = soup.select_one("h1.breadcrumb-title")
    if node:
        return clean(node.get_text(" ", strip=True))
    for h1 in soup.find_all("h1"):
        text = clean(h1.get_text(" ", strip=True))
        if text and text not in {"EMPRESA", "PORTAFOLIO", "SOSTENIBILIDAD", "CONTACTO"}:
            return text
    return ""


def extract_map_data(soup: BeautifulSoup) -> Tuple[str, str, str]:
    iframe = soup.select_one("iframe#gmap_canvas") or soup.find("iframe", src=re.compile(r"google\.com/maps/embed", re.I))
    src = iframe.get("src", "") if iframe else ""
    decoded = unquote(src)
    coords = re.search(r"!2d(-?\d+(?:\.\d+)?)!3d(-?\d+(?:\.\d+)?)", decoded)
    place = re.search(r"!2s([^!]+)!", decoded)
    lat = coords.group(2) if coords else ""
    lon = coords.group(1) if coords else ""
    place_name = clean(place.group(1)) if place else ""
    return lat, lon, place_name


def osm_components(address: Dict[str, str], display_name: str) -> Tuple[str, str, str, str]:
    def take(*keys: str) -> str:
        for key in keys:
            if address.get(key):
                value = clean(address[key])
                value = re.sub(r"^(Municipio de |Delegacion |Delegación |Alcaldia |Alcaldía )", "", value, flags=re.I)
                return value
        return ""

    line1 = " ".join(x for x in [take("road"), take("house_number")] if x).strip()
    if not line1:
        line1 = " ".join(x for x in [take("building"), take("amenity"), take("shop"), take("retail"), take("office"), take("tourism"), take("hospital")] if x).strip()
    city = take("city", "town", "village", "municipality", "county", "borough", "city_district", "suburb")
    state = take("state", "region")
    postcode = take("postcode")
    extra = [take("neighbourhood"), take("suburb"), take("borough"), city, state, postcode]
    parts, seen = [], set()
    for part in [line1] + extra:
        key = ascii_text(part).lower()
        if part and key not in seen:
            seen.add(key)
            parts.append(part)
    native_address = geocode_friendly(", ".join(parts)) if parts else geocode_friendly(display_name)
    return native_address, city, state, postcode


def geocode_reverse(lat: str, lon: str, cache: Dict[str, object]) -> dict:
    key = f"reverse|{lat}|{lon}"
    if key not in cache:
        time.sleep(1.0)
        cache[key] = requests.get(
            "https://nominatim.openstreetmap.org/reverse",
            params={"format": "jsonv2", "lat": lat, "lon": lon, "zoom": 18, "addressdetails": 1, "accept-language": "es"},
            headers={"User-Agent": "Codex FUNO extractor/1.0"},
            timeout=45,
        ).json()
    return cache[key]


def geocode_search(query: str, cache: Dict[str, object]) -> List[dict]:
    key = f"search|{clean(query)}"
    if key not in cache:
        time.sleep(1.0)
        cache[key] = requests.get(
            "https://nominatim.openstreetmap.org/search",
            params={"q": clean(query), "format": "jsonv2", "limit": 5, "addressdetails": 1, "accept-language": "es"},
            headers={"User-Agent": "Codex FUNO extractor/1.0"},
            timeout=45,
        ).json()
    return cache[key]


def choose_geo(native_name: str, place_name: str, lat: str, lon: str, cache: Dict[str, object]) -> Tuple[str, str, str, str]:
    reverse = geocode_reverse(lat, lon, cache)
    native_address, city, state, postcode = osm_components(reverse.get("address", {}), str(reverse.get("display_name", "")))
    reverse_score = sum(bool(x) for x in [native_address, city, state, postcode])
    best = (native_address, city, state, postcode, reverse_score)
    fallback_search = None
    try:
        lat_f, lon_f = float(lat), float(lon)
    except ValueError:
        return native_address, city, state, postcode

    for query in [f"{native_name}, Mexico", f"{place_name}, Mexico" if place_name and clean(place_name).lower() != clean(native_name).lower() else ""]:
        if not query:
            continue
        for item in geocode_search(query, cache):
            cand_address, cand_city, cand_state, cand_postcode = osm_components(item.get("address", {}), str(item.get("display_name", "")))
            cand_score = sum(bool(x) for x in [cand_address, cand_city, cand_state, cand_postcode])
            if fallback_search is None or cand_score > fallback_search[4]:
                fallback_search = (cand_address, cand_city, cand_state, cand_postcode, cand_score)
            try:
                distance = haversine_km(lat_f, lon_f, float(item["lat"]), float(item["lon"]))
            except Exception:
                continue
            if distance > 5.0:
                continue
            if cand_score >= best[4]:
                best = (cand_address, cand_city, cand_state, cand_postcode, cand_score)
                break
    if best[4] <= 2 and fallback_search and fallback_search[4] > best[4]:
        best = fallback_search
    return best[0], best[1], best[2], best[3]


def infer_activity(category: str, native_name: str, default_activity: str) -> str:
    slug = ascii_text(native_name).lower()
    if category == "Retail":
        return "Outlet mall" if "outlet" in slug else ("Retail center / hypermarket" if "walmart" in slug else default_activity)
    if category == "Industrial":
        return "Industrial park" if "park" in slug else default_activity
    if category == "Office":
        return "Office tower" if "torre" in slug else ("Corporate office" if "corporativo" in slug else default_activity)
    if category == "Mixed Use":
        if "hilton" in slug or "hotel" in slug:
            return "Hotel"
        if "hospital" in slug:
            return "Hospital"
        if "universidad" in slug or "uvm" in slug or "icel" in slug:
            return "University / education campus"
        if "gayosso" in slug:
            return "Funeral home"
        if "consultorios" in slug:
            return "Medical office building"
        if "santander" in slug:
            return "Bank branch / office"
    return default_activity


def build_row(target: dict, html: str, cache: Dict[str, object]) -> Dict[str, str]:
    soup = BeautifulSoup(html, "html.parser")
    native_name = extract_title(soup) or clean(Path(target["detail_url"]).name.replace("-", " ").title())
    lat, lon, place_name = extract_map_data(soup)
    native_address = city = state = postcode = ""
    if lat and lon:
        native_address, city, state, postcode = choose_geo(native_name, place_name, lat, lon, cache)
    if not native_address:
        native_address = geocode_friendly(", ".join(x for x in [place_name or native_name, city, state, postcode, "Mexico"] if x))
    if not city:
        city = state or "Mexico"
    row = {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": clean(ascii_text(native_name)),
        "LOCATION_NAME_NATIVE": native_name,
        "LOCATION_ADDRESS": geocode_friendly(ascii_text(native_address)),
        "LOCATION_ADDRESS_NATIVE": native_address,
        "LATITUDE": lat,
        "LONGITUDE": lon,
        "coord_source": "website" if lat and lon else "not_on_website",
        "COUNTRY": COUNTRY,
        "COUNTRY_ISO3": COUNTRY_ISO3,
        "POSTCODE": clean(ascii_text(postcode)),
        "STATE": clean(ascii_text(state)),
        "CITY": clean(ascii_text(city)),
        "SOURCE_URL": target["detail_url"],
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": infer_activity(target["category"], native_name, target["activity"]),
    }
    if not row["LOCATION_ADDRESS"] or not row["CITY"]:
        raise ValueError(f"Mandatory field missing for {target['detail_url']}")
    return row


def contact_row(session: requests.Session) -> Dict[str, str]:
    soup = BeautifulSoup(fetch(session, CONTACT_URL), "html.parser")
    native_address = ""
    for p in soup.find_all("p"):
        text = clean(p.get_text(" ", strip=True))
        if "Antonio Dovali Jaime" in text:
            native_address = text.replace("Piso 11 Santa Fe", "Piso 11, Santa Fe")
            break
    native_address = native_address or "Antonio Dovali Jaime 70, Samara, Torre B, Piso 11, Santa Fe, CDMX 01219"
    postcode = re.search(r"\b(\d{5})\b", native_address)
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": "Corporate Office",
        "LOCATION_NAME_NATIVE": "Oficina Corporativa",
        "LOCATION_ADDRESS": geocode_friendly(ascii_text(native_address)),
        "LOCATION_ADDRESS_NATIVE": native_address,
        "LATITUDE": "",
        "LONGITUDE": "",
        "coord_source": "not_on_website",
        "COUNTRY": COUNTRY,
        "COUNTRY_ISO3": COUNTRY_ISO3,
        "POSTCODE": postcode.group(1) if postcode else "01219",
        "STATE": "Ciudad de Mexico",
        "CITY": "Ciudad de Mexico",
        "SOURCE_URL": CONTACT_URL,
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": "Corporate office",
    }


def write_csv(path: Path, rows: List[Dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


def memory_draft(rows: List[Dict[str, str]]) -> str:
    script_name = Path(__file__).name
    counts = {
        "Retail": sum(1 for r in rows if "/propiedades/portafolio-comercial/" in r["SOURCE_URL"]),
        "Industrial": sum(1 for r in rows if "/propiedades/portafolio-industrial/" in r["SOURCE_URL"]),
        "Office": sum(1 for r in rows if "/propiedades/portafolio-oficinas/" in r["SOURCE_URL"]),
        "Mixed": sum(1 for r in rows if "/propiedades/portafolio-mixtos/" in r["SOURCE_URL"]),
        "Contact": sum(1 for r in rows if r["SOURCE_URL"] == CONTACT_URL),
    }
    return "\n".join(
        [
            "> [!NOTE]",
            "> Header update pending on approval: change `Last Updated` in `extraction_approach_v2.md` to `2026-04-07` before appending the sections below.",
            "",
            "### 3.15 Static HTML Portfolio Gallery with Google Maps Embed Coordinates",
            "> **Detection**: Static portfolio listing pages link to detail pages where `iframe#gmap_canvas` holds website-sourced coordinates, but the page does not print a clean text address.",
            "",
            "**Best Approach**:",
            "1. Parse the static listing anchors directly.",
            "2. Extract `h1.breadcrumb-title` and the Google Maps embed coordinates from each detail page.",
            "3. Reverse geocode those website coordinates to keep `LOCATION_ADDRESS` and `CITY` non-blank.",
            "4. Save native name/address columns alongside transliterated ASCII output.",
            "",
            f"> **Reference Script**: `{script_name}` - static detail discovery + iframe coordinate parsing + Nominatim enrichment.",
            "",
            "---",
            "",
            "### 4.21 FIBRA UNO ADMINISTRACION S.C. (Apr 2026)",
            "",
            "| Source | URL | Records | Method | Script |",
            "|--------|-----|---------|--------|--------|",
            f"| Retail Portfolio | funo.mx/propiedades/portafolio-comercial | {counts['Retail']} | Static HTML listing + detail page map iframe coords + reverse geocoding | `{script_name}` |",
            f"| Industrial Portfolio | funo.mx/propiedades/portafolio-industrial | {counts['Industrial']} | Static HTML listing + detail page map iframe coords + reverse geocoding | `{script_name}` |",
            f"| Office Portfolio | funo.mx/propiedades/portafolio-oficinas | {counts['Office']} | Static HTML listing + detail page map iframe coords + reverse geocoding | `{script_name}` |",
            f"| Mixed-Use Portfolio | funo.mx/propiedades/portafolio-uso-mixto | {counts['Mixed']} | Static HTML listing + detail page map iframe coords + reverse geocoding | `{script_name}` |",
            f"| Contact Page | funo.mx/contacto | {counts['Contact']} | Footer address parse | `{script_name}` |",
            f"| **TOTAL** | | **{len(rows)}** | | |",
            "",
            "**Key Learnings**:",
            "- FUNO retail coverage is only complete on `/propiedades/portafolio-comercial`; the user-provided English retail URL is a single detail page.",
            "- The detail pages expose coordinates in the Google Maps iframe, not in printed address text or JSON.",
            "- Reverse geocoding is the practical fallback when the website gives coordinates but not a structured address.",
            "",
            "---",
            "",
            "### 9.X File Inventory Addendum (2026-04-07 - FUNO)",
            "",
            "| File | Issuer | Pattern | Key Technique |",
            "|------|--------|---------|---------------|",
            f"| `{script_name}` | Fibra Uno Administracion S.C. (Generic) | Static HTML portfolio gallery + Google Maps iframe coords | Anchor discovery, iframe coord parsing, checkpointing, Nominatim enrichment |",
            "",
            "### 10.X FUNO Lessons (2026-04-07)",
            "",
            "- Check the portfolio detail page map iframe before concluding that a site lacks location data.",
            "- When a listing page only exposes names, the map coordinates can still support a complete address workflow.",
            "- Do not stop at `https://funo.mx/properties/portfolio-retail/antea`; it is one retail asset, not the full retail portfolio.",
            "",
        ]
    )


def main() -> None:
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    session = build_session()
    targets = collect_targets(session)
    write_json(URLS_JSON, targets)

    progress = load_json(PROGRESS_JSON, {})
    cache = load_json(GEOCODE_JSON, {})
    processed = set(progress.get("processed_urls", []))
    rows_by_url = {row["SOURCE_URL"]: row for row in progress.get("rows", [])}
    checkpoint_written = bool(progress.get("checkpoint_written"))

    for idx, target in enumerate(targets, start=1):
        if target["detail_url"] in processed and target["detail_url"] in rows_by_url:
            continue
        row = build_row(target, fetch(session, target["detail_url"]), cache)
        rows_by_url[target["detail_url"]] = row
        processed.add(target["detail_url"])
        ordered = [rows_by_url[url] for url in sorted(rows_by_url)]
        if not checkpoint_written and len(ordered) >= COUNT_THRESHOLD:
            write_csv(CHECKPOINT_CSV, ordered)
            checkpoint_written = True
        if idx % 20 == 0 or len(processed) == len(targets):
            write_json(PROGRESS_JSON, {"processed_urls": sorted(processed), "rows": ordered, "checkpoint_written": checkpoint_written})
            write_json(GEOCODE_JSON, cache)
        time.sleep(0.2)

    rows = [rows_by_url[url] for url in sorted(rows_by_url)]
    rows.append(contact_row(session))
    rows = sorted(rows, key=lambda r: (r["ACTIVITY_AT_ASSET"], r["LOCATION_NAME"]))
    if any(not r["LOCATION_ADDRESS"] for r in rows) or any(not r["CITY"] for r in rows):
        raise ValueError("Validation failed: blank LOCATION_ADDRESS or CITY")
    if not checkpoint_written and len(rows) >= COUNT_THRESHOLD:
        write_csv(CHECKPOINT_CSV, rows)
    write_csv(FINAL_CSV, rows)
    MEMORY_DRAFT.write_text(memory_draft(rows), encoding="utf-8")
    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "generated_at": now_iso(),
        "detail_page_count": len(targets),
        "final_row_count": len(rows),
        "rows_with_coords": sum(1 for r in rows if r["LATITUDE"] and r["LONGITUDE"]),
        "rows_without_coords": sum(1 for r in rows if not r["LATITUDE"] or not r["LONGITUDE"]),
        "checkpoint_csv": str(CHECKPOINT_CSV),
        "final_csv": str(FINAL_CSV),
        "memory_draft": str(MEMORY_DRAFT),
        "elapsed_seconds": round(time.monotonic() - started, 2),
    }
    write_json(SUMMARY_JSON, summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
