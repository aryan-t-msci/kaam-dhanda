"""
Bank of Nanjing Co., Ltd. - Main Branch Extraction Script
Platform Pattern: Chinese Banking Portal - eBank POST API (orgInfoList JSON)

This script extracts branch data from:
1. Primary: eBank branch locator API (291 branches across 16 cities)
2. Subsidiary: Nanyin Wealth (南银理财) - 1 office
3. Subsidiary: BONCFC (南京银行消费金融) - 1 office
4. Subsidiary: XYAMC (鑫元基金/兴业资管) - 1 office

Usage:
    python njcb_main_extractor.py

Configuration:
    See CONFIG block below. Change ISSUER_NAME, ISSUER_ID for a different issuer.
"""

import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

import requests
import urllib3
import json
import csv
import re
import os
import time
from pathlib import Path

urllib3.disable_warnings()

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_NAME = "BANK OF NANJING CO., LTD."
ISSUER_ID   = "IID000000002159087"

EBANK_BASE_URL  = "https://ebank.njcb.com.cn"
EBANK_BRANCH_API = "/perbank/PB00000200orderBookQryQueue.do"
EBANK_PAGE_URL   = "https://ebank.njcb.com.cn/perbank/PB00000200.do"

TEMP_DIR   = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Temp"
OUTPUT_DIR = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Output"
PROGRESS_FILE = Path(TEMP_DIR) / "njcb_progress.json"

# City codes from the eBank dropdown
CITY_CODES = {
    '110100': '北京市',
    '320400': '常州市',
    '330100': '杭州市',
    '320800': '淮安市',
    '320700': '连云港市',
    '320100': '南京市',
    '320600': '南通市',
    '310100': '上海市',
    '320500': '苏州市',
    '321300': '宿迁市',
    '321200': '泰州市',
    '320200': '无锡市',
    '320300': '徐州市',
    '320900': '盐城市',
    '321000': '扬州市',
    '321100': '镇江市',
}

# City code to city name in English
CITY_EN = {
    '110100': 'Beijing',
    '320400': 'Changzhou',
    '330100': 'Hangzhou',
    '320800': 'Huaian',
    '320700': 'Lianyungang',
    '320100': 'Nanjing',
    '320600': 'Nantong',
    '310100': 'Shanghai',
    '320500': 'Suzhou',
    '321300': 'Suqian',
    '321200': 'Taizhou',
    '320200': 'Wuxi',
    '320300': 'Xuzhou',
    '320900': 'Yancheng',
    '321000': 'Yangzhou',
    '321100': 'Zhenjiang',
}

# City code to province in English
CITY_PROVINCE = {
    '110100': 'Beijing',
    '320400': 'Jiangsu',
    '330100': 'Zhejiang',
    '320800': 'Jiangsu',
    '320700': 'Jiangsu',
    '320100': 'Jiangsu',
    '320600': 'Jiangsu',
    '310100': 'Shanghai',
    '320500': 'Jiangsu',
    '321300': 'Jiangsu',
    '321200': 'Jiangsu',
    '320200': 'Jiangsu',
    '320300': 'Jiangsu',
    '320900': 'Jiangsu',
    '321000': 'Jiangsu',
    '321100': 'Jiangsu',
}

# ═══════════════════════════════════════════════════════════
# HEADERS
# ═══════════════════════════════════════════════════════════
EBANK_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Referer': EBANK_PAGE_URL,
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'X-Requested-With': 'XMLHttpRequest',
}

WEB_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
}

# ═══════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════

try:
    from pypinyin import lazy_pinyin, Style
    HAS_PYPINYIN = True
except ImportError:
    HAS_PYPINYIN = False
    print("Warning: pypinyin not installed. Install with: pip install pypinyin")

def chinese_to_pinyin(text):
    """Convert Chinese characters to pinyin romanization."""
    if not text:
        return text
    if HAS_PYPINYIN:
        # Convert character by character, keeping non-Chinese as-is
        result = []
        i = 0
        while i < len(text):
            char = text[i]
            if '\u4e00' <= char <= '\u9fff' or '\u3400' <= char <= '\u4dbf':
                # Chinese character - convert to pinyin
                pinyin = lazy_pinyin(char, style=Style.NORMAL)
                result.append(pinyin[0].capitalize() if pinyin else char)
            else:
                result.append(char)
            i += 1
        # Merge and clean
        merged = ''.join(result)
        # Clean up spacing
        merged = re.sub(r'\s+', ' ', merged).strip()
        return merged
    else:
        # Fallback: just return the original
        return text

def transliterate_address(chinese_addr):
    """
    Transliterate a Chinese address to English.
    Handles common Chinese address components with known translations.
    """
    if not chinese_addr:
        return chinese_addr
    
    # Common Chinese address terms → English
    replacements = {
        # Administrative divisions
        '省': ' Province',
        '市': ' City',
        '县': ' County',
        '区': ' District',
        '镇': ' Town',
        '乡': ' Township',
        '街道': ' Subdistrict',
        '村': ' Village',
        '路': ' Road',
        '街': ' Street',
        '大道': ' Avenue',
        '大街': ' Boulevard',
        '巷': ' Lane',
        '弄': ' Alley',
        '号': '',
        '幢': ' Building',
        '栋': ' Block',
        '楼': 'F',
        '层': 'F',
        '室': ' Room',
        '单元': ' Unit',
        '东': 'East ',
        '西': 'West ',
        '南': 'South ',
        '北': 'North ',
        # Common city-specific
        '玄武区': 'Xuanwu District',
        '秦淮区': 'Qinhuai District',
        '建邺区': 'Jianye District',
        '鼓楼区': 'Gulou District',
        '雨花台区': 'Yuhuatai District',
        '栖霞区': 'Qixia District',
        '浦口区': 'Pukou District',
        '六合区': 'Liuhe District',
        '溧水区': 'Lishui District',
        '高淳区': 'Gaochun District',
        '江宁区': 'Jiangning District',
        '静安区': 'Jing\'an District',
        '长宁区': 'Changning District',
        '徐汇区': 'Xuhui District',
        '浦东新区': 'Pudong New Area',
        '东城区': 'Dongcheng District',
        '西城区': 'Xicheng District',
        '朝阳区': 'Chaoyang District',
        '海淀区': 'Haidian District',
        '丰台区': 'Fengtai District',
        '上城区': 'Shangcheng District',
        '下城区': 'Xiacheng District',
        '拱墅区': 'Gongshu District',
        '萧山区': 'Xiaoshan District',
        '余杭区': 'Yuhang District',
        '南京市': 'Nanjing City',
        '北京市': 'Beijing City',
        '上海市': 'Shanghai City',
        '苏州市': 'Suzhou City',
        '无锡市': 'Wuxi City',
        '杭州市': 'Hangzhou City',
        '常州市': 'Changzhou City',
        '南通市': 'Nantong City',
        '扬州市': 'Yangzhou City',
        '镇江市': 'Zhenjiang City',
        '泰州市': 'Taizhou City',
        '淮安市': "Huai'an City",
        '盐城市': 'Yancheng City',
        '宿迁市': 'Suqian City',
        '连云港市': 'Lianyungang City',
        '徐州市': 'Xuzhou City',
        '江苏省': 'Jiangsu Province',
        '浙江省': 'Zhejiang Province',
        '江苏': 'Jiangsu',
        '浙江': 'Zhejiang',
    }
    
    result = chinese_addr
    for cn, en in replacements.items():
        result = result.replace(cn, en)
    
    # Convert remaining Chinese with pypinyin
    result = chinese_to_pinyin(result)
    
    # Clean up
    result = re.sub(r'\s+', ' ', result).strip()
    result = result.replace('#', 'No.')
    
    return result

def transliterate_name(chinese_name):
    """Transliterate a Chinese branch name to English."""
    if not chinese_name:
        return chinese_name
    
    # Common branch name components
    replacements = {
        '营业部': 'Business Department',
        '营业厅': 'Business Hall',
        '支行': 'Branch',
        '分行': 'Branch',
        '支店': 'Branch Office',
        '储蓄所': 'Savings Office',
        '储蓄部': 'Savings Department',
        '分理处': 'Sub-branch',
        '信用社': 'Credit Union',
        '贷款中心': 'Loan Center',
        '中心支行': 'Center Branch',
        '副中心支行': 'Sub-Center Branch',
        '网点': 'Service Point',
        '办事处': 'Representative Office',
        '代表处': 'Representative Office',
        '南京分行': 'Nanjing Branch',
        '北京分行': 'Beijing Branch',
        '上海分行': 'Shanghai Branch',
        '苏州分行': 'Suzhou Branch',
        '无锡分行': 'Wuxi Branch',
        '杭州分行': 'Hangzhou Branch',
        '常州分行': 'Changzhou Branch',
        '南通分行': 'Nantong Branch',
        '扬州分行': 'Yangzhou Branch',
        '镇江分行': 'Zhenjiang Branch',
        '泰州分行': 'Taizhou Branch',
        '淮安分行': "Huai'an Branch",
        '盐城分行': 'Yancheng Branch',
        '宿迁分行': 'Suqian Branch',
        '连云港分行': 'Lianyungang Branch',
        '徐州分行': 'Xuzhou Branch',
        '南京银行': 'Bank of Nanjing',
        '江宁': 'Jiangning',
        '城东': 'East City',
        '城南': 'South City',
        '城西': 'West City',
        '城北': 'North City',
        '紫金': 'Zijin',
        '金融城': 'Financial City',
        '热河': 'Rehe',
        '紫东': 'Zidong',
        '高淳': 'Gaochun',
        '溧水': 'Lishui',
    }
    
    result = chinese_name
    for cn, en in replacements.items():
        result = result.replace(cn, en)
    
    # Convert any remaining Chinese
    result = chinese_to_pinyin(result)
    result = re.sub(r'\s+', ' ', result).strip()
    
    return result

def parse_coordinate(coord_str):
    """Parse 'longitude,latitude' coordinate string."""
    if not coord_str:
        return None, None
    try:
        parts = coord_str.split(',')
        if len(parts) == 2:
            lng = float(parts[0].strip())
            lat = float(parts[1].strip())
            return lat, lng
    except:
        pass
    return None, None

def clean_phone(phone):
    """Clean phone number - remove excessive whitespace."""
    if not phone:
        return ''
    phone = re.sub(r'\s+', ' ', str(phone)).strip()
    return phone

def determine_activity(org_name_cn):
    """Determine business activity from Chinese branch name."""
    if not org_name_cn:
        return 'Banking Branch'
    if '营业部' in org_name_cn:
        return 'Banking Branch / Operations Department'
    elif '营业厅' in org_name_cn:
        return 'Banking Branch / Business Hall'
    elif '储蓄' in org_name_cn:
        return 'Banking Branch / Savings Office'
    elif '贷款' in org_name_cn:
        return 'Loan Center'
    elif '支行' in org_name_cn or '分理处' in org_name_cn:
        return 'Banking Branch'
    elif '分行' in org_name_cn and '支行' not in org_name_cn:
        return 'Regional Banking Branch'
    elif '办事处' in org_name_cn or '代表处' in org_name_cn:
        return 'Representative Office'
    elif '消费金融' in org_name_cn:
        return 'Consumer Finance'
    elif '理财' in org_name_cn:
        return 'Wealth Management'
    elif '基金' in org_name_cn or '资管' in org_name_cn:
        return 'Asset Management'
    return 'Banking Branch'

def save_progress(records, done_cities):
    """Save progress to file for resumability."""
    progress = {
        'records': records,
        'done_cities': list(done_cities),
    }
    with open(PROGRESS_FILE, 'w', encoding='utf-8') as f:
        json.dump(progress, f, ensure_ascii=False, indent=2)
    print(f"  [Progress saved: {len(records)} records, {len(done_cities)} cities done]")

def load_progress():
    """Load progress from file."""
    if PROGRESS_FILE.exists():
        with open(PROGRESS_FILE, encoding='utf-8') as f:
            progress = json.load(f)
        return progress.get('records', []), set(progress.get('done_cities', []))
    return [], set()

# ═══════════════════════════════════════════════════════════
# EXTRACTION FUNCTIONS
# ═══════════════════════════════════════════════════════════

def fetch_city_branches(city_code, city_en, province_en):
    """Fetch all branches for a given city code via eBank API."""
    try:
        r = requests.post(
            EBANK_BASE_URL + EBANK_BRANCH_API,
            data={'faId': city_code, 'turnPageBeginPos': '0'},
            headers=EBANK_HEADERS,
            verify=False,
            timeout=25
        )
        if r.status_code != 200:
            print(f"  HTTP {r.status_code} for city {city_code}")
            return []
        
        data = json.loads(r.text.strip())
        org_list = data.get('orgInfoList', [])
        if not org_list:
            return []
        
        branches = []
        for org in org_list:
            org_name_cn = org.get('orgNameForOrg', '') or ''
            address_cn = org.get('address', '') or ''
            coordinate = org.get('coordinate', '') or ''
            phone1 = org.get('phone1', '') or ''
            phone2 = org.get('phone2', '') or ''
            org_code = org.get('orgCode', '') or ''
            
            # Skip virtual/clearing/external management orgs
            skip_keywords = ['清算中心', '外围', '虚拟', '外挂', '管理机构']
            if any(kw in org_name_cn for kw in skip_keywords):
                continue
            
            # Skip if no address
            if not address_cn.strip():
                continue
            
            # Parse coordinates
            lat, lng = parse_coordinate(coordinate)
            
            # Transliterate
            name_en = transliterate_name(org_name_cn)
            addr_en = transliterate_address(address_cn)
            
            # Clean phone
            phone_str = phone1.strip()
            if phone2.strip() and phone2.strip() != phone1.strip():
                phone_str = f"{phone1.strip()} / {phone2.strip()}"
            phone_str = clean_phone(phone_str)
            
            # Determine activity
            activity = determine_activity(org_name_cn)
            
            # Determine postal code from address (Chinese 6-digit)
            postal_match = re.search(r'\b(\d{6})\b', address_cn)
            postal_code = postal_match.group(1) if postal_match else ''
            
            branch = {
                'ISSUER_ID': ISSUER_ID,
                'ISSUER_NAME': ISSUER_NAME,
                'FACILITY_NAME': name_en,
                'FACILITY_NAME_LOCAL': org_name_cn,
                'FACILITY_ADDRESS': addr_en,
                'FACILITY_ADDRESS_LOCAL': address_cn,
                'CITY': city_en,
                'STATE': province_en,
                'POSTAL_CODE': postal_code,
                'FACILITY_REGION': 'China',
                'LATITUDE': lat if lat else '',
                'LONGITUDE': lng if lng else '',
                'coord_source': 'website' if lat else '',
                'FACILITY_CONTACT_NUMBER': phone_str,
                'RELEVANT_URL': EBANK_PAGE_URL,
                'ACTIVITY_AT_SOURCE': activity,
                '_org_code': org_code,
                '_city_code': city_code,
            }
            branches.append(branch)
        
        return branches
    
    except Exception as e:
        print(f"  ERROR fetching city {city_code}: {e}")
        return []

def extract_ebank_branches():
    """Extract all branches from the eBank API across all cities."""
    print("\n" + "="*60)
    print("EXTRACTING BRANCHES FROM eBANK API")
    print("="*60)
    
    # Check for existing progress
    records, done_cities = load_progress()
    if records:
        print(f"Resuming from progress: {len(records)} records, {len(done_cities)} cities done")
    
    for city_code, city_cn in CITY_CODES.items():
        if city_code in done_cities:
            print(f"  Skipping {city_cn} ({city_code}) - already done")
            continue
        
        city_en = CITY_EN.get(city_code, city_cn)
        province_en = CITY_PROVINCE.get(city_code, 'China')
        
        branches = fetch_city_branches(city_code, city_en, province_en)
        
        # Filter out ATMs (they should not be in the eBank branch system, but double-check)
        non_atm_branches = [b for b in branches if 'ATM' not in b.get('FACILITY_NAME', '').upper()]
        
        print(f"  {city_cn} ({city_code}): {len(branches)} branches (non-ATM: {len(non_atm_branches)})")
        records.extend(non_atm_branches)
        done_cities.add(city_code)
        
        # Save progress every 5 cities (since we only have 16)
        if len(done_cities) % 5 == 0:
            save_progress(records, done_cities)
        
        time.sleep(0.3)  # Be polite
    
    # Final save
    save_progress(records, done_cities)
    print(f"\nTotal eBank branches extracted: {len(records)}")
    return records

def get_subsidiary_records():
    """Manually curated subsidiary offices from the provided URLs."""
    print("\n" + "="*60)
    print("ADDING SUBSIDIARY OFFICES")
    print("="*60)
    
    subsidiaries = []
    
    # 1. Nanyin Wealth (南银理财有限责任公司)
    # Source: https://www.nanyinwealth.com/ - address in footer
    # 地址：中国南京市鼓楼区中央路242号2号楼14-16层 邮编：210008
    nanyin = {
        'ISSUER_ID': ISSUER_ID,
        'ISSUER_NAME': ISSUER_NAME,
        'FACILITY_NAME': 'Nanyin Wealth Management Co., Ltd.',
        'FACILITY_NAME_LOCAL': '南银理财有限责任公司',
        'FACILITY_ADDRESS': 'Building 2, 14-16F, 242 Zhongyang Road, Gulou District, Nanjing City, Jiangsu Province',
        'FACILITY_ADDRESS_LOCAL': '南京市鼓楼区中央路242号2号楼14-16层',
        'CITY': 'Nanjing',
        'STATE': 'Jiangsu',
        'POSTAL_CODE': '210008',
        'FACILITY_REGION': 'China',
        'LATITUDE': '',
        'LONGITUDE': '',
        'coord_source': '',
        'FACILITY_CONTACT_NUMBER': '4001195302',
        'RELEVANT_URL': 'https://www.nanyinwealth.com/',
        'ACTIVITY_AT_SOURCE': 'Wealth Management',
        '_org_code': 'NANYIN',
        '_city_code': 'SUB',
    }
    subsidiaries.append(nanyin)
    print(f"  Added: {nanyin['FACILITY_NAME']}")
    
    # 2. BONCFC (南京银行消费金融有限公司)
    # Source: https://boncfc.com/ - address in footer
    # 办公地址：江苏省南京市秦淮区长白街588号 电话：40018-95302
    boncfc = {
        'ISSUER_ID': ISSUER_ID,
        'ISSUER_NAME': ISSUER_NAME,
        'FACILITY_NAME': 'Bank of Nanjing Consumer Finance Co., Ltd.',
        'FACILITY_NAME_LOCAL': '南京银行消费金融有限公司',
        'FACILITY_ADDRESS': '588 Changbai Street, Qinhuai District, Nanjing City, Jiangsu Province',
        'FACILITY_ADDRESS_LOCAL': '江苏省南京市秦淮区长白街588号',
        'CITY': 'Nanjing',
        'STATE': 'Jiangsu',
        'POSTAL_CODE': '',
        'FACILITY_REGION': 'China',
        'LATITUDE': '',
        'LONGITUDE': '',
        'coord_source': '',
        'FACILITY_CONTACT_NUMBER': '40018-95302',
        'RELEVANT_URL': 'https://boncfc.com/',
        'ACTIVITY_AT_SOURCE': 'Consumer Finance',
        '_org_code': 'BONCFC',
        '_city_code': 'SUB',
    }
    subsidiaries.append(boncfc)
    print(f"  Added: {boncfc['FACILITY_NAME']}")
    
    # 3. XYAMC (鑫沅资产管理有限公司) - subsidiary of Bank of Nanjing
    # Source: https://www.xyamc.com/ - address: 上海市静安区中山北路909号12层
    xyamc = {
        'ISSUER_ID': ISSUER_ID,
        'ISSUER_NAME': ISSUER_NAME,
        'FACILITY_NAME': 'Xinyuan Asset Management Co., Ltd.',
        'FACILITY_NAME_LOCAL': '鑫沅资产管理有限公司',
        'FACILITY_ADDRESS': '12F, 909 Zhongshan North Road, Jing\'an District, Shanghai',
        'FACILITY_ADDRESS_LOCAL': '上海市静安区中山北路909号12层',
        'CITY': 'Shanghai',
        'STATE': 'Shanghai',
        'POSTAL_CODE': '',
        'FACILITY_REGION': 'China',
        'LATITUDE': '',
        'LONGITUDE': '',
        'coord_source': '',
        'FACILITY_CONTACT_NUMBER': '',
        'RELEVANT_URL': 'https://www.xyamc.com/',
        'ACTIVITY_AT_SOURCE': 'Asset Management',
        '_org_code': 'XYAMC',
        '_city_code': 'SUB',
    }
    subsidiaries.append(xyamc)
    print(f"  Added: {xyamc['FACILITY_NAME']}")
    
    return subsidiaries

def deduplicate(records):
    """Remove duplicate records based on name+address combination."""
    seen = set()
    unique = []
    for rec in records:
        key = (rec['FACILITY_NAME_LOCAL'].strip(), rec['FACILITY_ADDRESS_LOCAL'].strip())
        if key not in seen and key != ('', ''):
            seen.add(key)
            unique.append(rec)
    return unique

def build_csv(all_records, csv_path):
    """Build and save the output CSV."""
    columns = [
        'ISSUER_ID', 'ISSUER_NAME', 'FACILITY_NAME', 'FACILITY_NAME_LOCAL',
        'FACILITY_ADDRESS', 'FACILITY_ADDRESS_LOCAL', 'CITY', 'STATE',
        'POSTAL_CODE', 'FACILITY_REGION', 'LATITUDE', 'LONGITUDE',
        'coord_source', 'FACILITY_CONTACT_NUMBER', 'RELEVANT_URL',
        'ACTIVITY_AT_SOURCE'
    ]
    
    with open(csv_path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction='ignore')
        writer.writeheader()
        for rec in all_records:
            writer.writerow(rec)
    
    print(f"\nCSV saved: {csv_path}")
    print(f"Total records: {len(all_records)}")

# ═══════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════

if __name__ == '__main__':
    print(f"\n{'='*60}")
    print(f"BANK OF NANJING CO., LTD. - Branch Extraction")
    print(f"Issuer ID: {ISSUER_ID}")
    print(f"{'='*60}")
    
    os.makedirs(TEMP_DIR, exist_ok=True)
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # Step 1: Extract eBank branches
    ebank_records = extract_ebank_branches()
    
    # Step 2: Get subsidiary offices
    sub_records = get_subsidiary_records()
    
    # Step 3: Combine and deduplicate
    all_records = ebank_records + sub_records
    all_records = deduplicate(all_records)
    
    print(f"\nTotal after dedup: {len(all_records)}")
    
    # Step 4: Checkpoint - save initial CSV
    output_filename = f"{ISSUER_ID}_{ISSUER_NAME.replace('/', '-')}.csv"
    checkpoint_path = Path(TEMP_DIR) / f"checkpoint_{output_filename}"
    build_csv(all_records, checkpoint_path)
    
    # Step 5: Check if we've met the target count
    non_sub_count = len(ebank_records)
    print(f"\nCheckpoint Summary:")
    print(f"  eBank branches: {non_sub_count}")
    print(f"  Subsidiary offices: {len(sub_records)}")
    print(f"  Total: {len(all_records)}")
    print(f"  Target (min): 290 non-ATM")
    
    if non_sub_count >= 290:
        print(f"  ✓ TARGET MET! {non_sub_count} >= 290")
    else:
        print(f"  ✗ Target not met: {non_sub_count} < 290")
    
    # Step 6: Save final output
    final_path = Path(OUTPUT_DIR) / output_filename
    build_csv(all_records, final_path)
    
    print(f"\n{'='*60}")
    print(f"EXTRACTION COMPLETE")
    print(f"Output: {final_path}")
    print(f"{'='*60}")
