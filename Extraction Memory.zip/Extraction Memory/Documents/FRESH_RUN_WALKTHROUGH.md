# Fresh run walkthrough — you choose model, reasoning, input, output, temp

A "fresh run" extracts a chosen set of issuers from scratch: `-Fresh` clears any previous
progress, selection, and artifacts for that run key, then processes everything you ask for.
This guide shows how to control every knob from the command line.

> Run the copy of `run_batch.ps1` that lives in your optimized folder (the one with the `KB/`
> shards and `Tools\shard_kb.py`). `MemoryFolder` now defaults to *the folder the script lives
> in*, so the system always uses the prompts + KB sitting next to `run_batch.ps1`. The startup
> log prints `MemoryFolder=...`, `Output=...`, `Temp=...` so you can confirm what's active.

---

## 1. What you choose, and the flag for each

| You want to set        | Flag              | Default                              |
|------------------------|-------------------|--------------------------------------|
| Model                  | `-Model`          | `gpt-5.4`                            |
| Reasoning level        | `-Reasoning`      | `high`                               |
| Input workbook         | `-InputFile`      | the batch7&8 file                    |
| Output folder (root)   | `-OutputRoot`     | `...\Test - ACWI IMI Straive\Output` |
| Temp / logs folder     | `-TempRoot`       | `...\Test - ACWI IMI Straive\Temp`   |
| (rarely) prompts+KB    | `-MemoryFolder`   | the folder `run_batch.ps1` lives in  |
| (opt.) scope method.   | `-ScopeDoc`       | blank = bundled SCOPE_METHODOLOGY.md |
| How many issuers       | `-Limit`          | `50` (sampled)                       |
| Exact issuers          | `-IssuerIds`      | none (use sampling)                  |
| Parallel workers       | `-WorkerCap`      | `0` = auto-size to the machine       |
| Reproducible sample    | `-Seed`           | `0` = new random draw each time      |
| Isolate this run       | `-RunTag`         | none                                 |
| Start clean            | `-Fresh`          | off (omit to resume instead)         |

The run also creates one output sub-folder per run, named from the input file (plus `-RunTag`
if you set one): `<OutputRoot>\Run_<inputname><tag>\`.

---

## 2. Copy-paste template (edit the five values, then run)

```powershell
cd "C:\Users\tiwaary\OneDrive - MSCI Office 365\Extraction Memory New"

powershell -NoProfile -ExecutionPolicy Bypass -File ".\run_batch.ps1" `
  -InputFile  "C:\path\to\your_issuers.xlsx" `
  -OutputRoot "C:\path\to\output" `
  -TempRoot   "C:\path\to\temp" `
  -Model      "gpt-5.4" `
  -Reasoning  "high" `
  -Limit      100000 `
  -Fresh
```

That command runs **the whole input file** (`-Limit 100000` is just a number larger than any
issuer count) on gpt-5.4 / high, sending output and logs where you pointed them. Drop or change
any line to use its default.

---

## 3. Choosing the scope (whole file / sample / specific issuers)

- **Whole file:** set `-Limit` to a big number (e.g. `100000`). Every issuer is processed.
- **A sample:** set `-Limit 50` (or any N). The run picks `>=25% heaviest + the rest random`.
  Add `-Seed 12345` to reproduce the exact same sample on a later `-Fresh` run.
- **Exact issuers:** `-IssuerIds IID000000002244210,IID000000005538588` — sampling is bypassed and
  only those are run. Good for re-checking specific companies. Pair with `-RunTag "_spotcheck"`
  to keep their output in a separate folder.

---

## 4. Model and reasoning notes

- `-Model` takes the Codex model string you want to run on (default `gpt-5.4`). Workers run on the
  same model you pass here.
- `-Reasoning` is passed through as the model's reasoning effort. Common values are `low`,
  `medium`, `high`; `high` is the default and is what the validation runs used. Use a value your
  chosen model supports. Higher reasoning = more thorough (and more tokens/time) per worker; lower
  = cheaper/faster but can miss harder sources.

---

## 5. Workers (parallelism)

- `-WorkerCap 0` (default) auto-sizes to your machine — it reads cores and free RAM and picks a
  safe cap (your box auto-sized to ~21), with a live free-RAM gate before each spawn.
- `-WorkerCap 4` forces a fixed number. Use a small fixed cap when you want a gentle, predictable
  run; leave it on auto for full throughput.

---

## 6. Where the results land, and how to read them

After the pass, the script canonicalizes the per-issuer CSVs to the 19-column union schema and
prints a report. Look under:

- **Output:** `<OutputRoot>\Run_<inputname><tag>\` — one CSV per issuer, plus
  `_canonicalize_report.txt` (rows in/out, empties dropped, address collisions kept).
- **Review list:** issuers whose worker declared a GAP (couldn't reach the target from the
  supplied sources) are flagged for review — check the run folder's review list / the
  `... - worker declared a GAP, flagged for review` lines in the log. A GAP is the system being
  honest that the available sources only expose so much, not a failure.
- **Logs / staging / status:** `<TempRoot>\Run_<inputname><tag>\` (including per-worker logs under
  `workers\`).

---

## 7. Monitoring while it runs

The console prints a heartbeat every ~20s:

```
[MONITOR] promoted=1 | failed=0 | active=2/21 (cap=21 auto) | queued=0
```

`active` = workers running now, `promoted` = finished and written to output, `queued` = waiting
for a free slot. When `promoted` reaches the target and `active=0`, the pass is complete.

If the first fresh run needs to build the KB shards you'll see a one-time `[shard]` line at
startup; on every run after that it self-skips silently.

---

## 8. Resume vs fresh

- **Resume:** re-run the *exact same command without `-Fresh`*. The run key is stable, so it
  picks up where it left off and only processes issuers not yet done.
- **Fresh:** add `-Fresh` to wipe that run key's prior progress/selection/artifacts and start over.

---

## 9. Running it on Codex Desktop instead (orchestrator)

The agent-native path is the multi-agent orchestrator (see `Documents/PROMPTS.md`). Open a Codex
Desktop conversation with this folder accessible and send the block that reads `prompt.md` +
`ORCHESTRATOR_PROMPT.md` with your `MEMORY_FOLDER` / `INPUT_FILE` / `TEMP_FOLDER` / `OUTPUT_FOLDER`
filled in.

Key difference for your knobs: on Desktop you **pick the model and reasoning by choosing them for
that Desktop conversation** — the orchestrator makes every worker match the conversation's tier
(there is no `-Model` / `-Reasoning` flag on this path). Input/output/temp are the PARAMETERS in
the prompt. Desktop runs ~5 workers in parallel (agent cap); for the full universe the CLI loop
above is faster. The shards bootstrap automatically as Step O-0.

---

## 10. Quick gotchas

- Run the `run_batch.ps1` inside your optimized folder; confirm the `MemoryFolder=...` startup
  line points where you expect (this avoids accidentally using an older copy's prompts/KB).
- For large runs, point `-TempRoot` and `-OutputRoot` at a **local (non-OneDrive)** folder to
  avoid OneDrive download popups and sync contention; `MemoryFolder` can stay on OneDrive.
- "Finished in under a minute" almost always means it resumed (nothing left to do) — add `-Fresh`
  if you meant to start over.
