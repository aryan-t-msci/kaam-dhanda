"""Build the formula-driven report workbook from the completed row_queue.csv.
usage: python build_report.py row_queue.csv sec_master_20260828.parquet OUT.xlsx
Then recalculate (Excel recalculates on open; in the Claude sandbox run the xlsx skill's recalc.py)."""
import sys, pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter as L
from openpyxl.worksheet.datavalidation import DataValidation
import helpers as H
qf, smf, out = sys.argv[1:4]
H.load(smf)
q = pd.read_csv(qf, dtype=str, keep_default_na=False, encoding='utf-8-sig')
VERD=['CORRECT','URL_CORRECTION_ONLY','CORRECT_BETTER_MATCH','WRONG_REMAP','WRONG_OWNER_NOT_IN_DMX','OUT_OF_SCOPE_DROP','LIFECYCLE_DIVESTED','RECOLLECT']
NOTE_VALS=['CONSISTENT','PARTIALLY_RIGHT','FALSE_PASS','CORRECT_SIBLING_FLAG','UNDERCONFIRMED','CORRECTLY_UNCONFIRMED','FLAG_OK']
STAT=['PERFECT','PARTIAL','GICS_MISMATCH','FLAGGED']; UCH=['PASS_OWN_URL','PASS_HIERARCHY','NOT_IN_SECMASTER','URL_SIBLING_OF_GROUP','URL_BELONGS_TO_OTHER']
MEAN={'CORRECT':'Assigned issuer is right','URL_CORRECTION_ONLY':'Issuer right; RELEVANT_URL must be replaced (CORRECTED_URL)','CORRECT_BETTER_MATCH':'Right group, more accurate DMX entity exists (error in strict accuracy)','WRONG_REMAP':'Wrong issuer; correct owner is in DMX','WRONG_OWNER_NOT_IN_DMX':'Wrong issuer; owner absent from DMX - closest URL-bearing ancestor suggested','OUT_OF_SCOPE_DROP':'Out of scope per M3','LIFECYCLE_DIVESTED':'Asset divested/closed - buyer in reason','RECOLLECT':'Issuer cannot be confirmed from the source'}
FH=Font(name='Arial',size=10,bold=True,color='FFFFFF'); FB=Font(name='Arial',size=10,bold=True); FT=Font(name='Arial',size=11,bold=True)
HDR=PatternFill('solid',fgColor='1F3864'); INP=PatternFill('solid',fgColor='FFF2CC')
# ---- derived flags (deterministic, from secmaster) ----
sp={i:H.same_url_parent(i) for i in q.ISSUER_ID.unique()}
q['FLAG_SAME_URL_AS_PARENT']=q.ISSUER_ID.map(lambda i:'Y' if sp[i] else '')
q['PREFERRED_PARENT']=q.ISSUER_ID.map(lambda i:f'{H.climb_same_url(i)} {H.name(H.climb_same_url(i))}' if sp[i] else '')
anc={i:H.url_bearing_ancestor(i) for i in q.ISSUER_ID.unique()}
def n6(r):
    if r.EVAL_VERDICT in ('CORRECT','URL_CORRECTION_ONLY','RECOLLECT') and not H.url_of(r.ISSUER_ID):
        a=anc[r.ISSUER_ID]; return f'Strict M3 N6 (DMX URL field only) would move this to {a} {H.name(a)}; not applied' if a else 'Strict M3 N6: no URL-bearing ancestor'
    return ''
q['NOTE_STRICT_N6']=q.apply(n6,axis=1)
q['GICS_CATEGORY']=q.STATUS.eq('GICS_MISMATCH').map({True:'GICS_MISMATCH',False:''})
keep=['SRC_ROW','FACILITY_ID','ISSUER_ID','SECMASTER_NAME','HIERARCHY_ROLE','SECMASTER_PARENT_ID','SECMASTER_ULTIMATE_PARENT','DMX_RELATIONSHIP','MISSING_DMX_LINK','FACILITY_NAME','ASSET_COUNTRY','BUSINESS_ACTIVITY','RELEVANT_URL','URL_DOMAIN','URL_CHECK','STATUS','GICS_CATEGORY','NOTES','CHECK_STATUS','URL_ACCESS','FACILITY_ON_PAGE','OWNER_OPERATOR_FOUND','EVAL_VERDICT','*ISSUER_CORRECT','*GROUP_CORRECT','EVAL_SUGGESTED_ISSUER_ID','EVAL_SUGGESTED_ISSUER_NAME','EVAL_CONFIDENCE','EVAL_REASON','RULE_REF','CORRECTED_URL','EVIDENCE_URL','EVIDENCE_EXTRACT','*NOTES_ASSESSMENT','CORRECTED_NAME','FLAG_SAME_URL_AS_PARENT','PREFERRED_PARENT','NOTE_STRICT_N6','M3_MISS','JV_HIERARCHY_CO','JV_PARTNERS','LIFECYCLE_WATCH','DMX_ISSUE','BASELINE_BASIS','BASELINE_VERDICT','BASELINE_SUGG_ID','*CHANGED_VS_BASELINE','CHECKED_AT']
Hd=[c.lstrip('*') for c in keep]; CL={c:L(i+1) for i,c in enumerate(Hd)}
wb=Workbook(); ws=wb.active; ws.title='EVAL'; ws.append(Hd); last=len(q)+1
for k,(_,r) in enumerate(q.iterrows(),start=2):
    V=f'{CL["EVAL_VERDICT"]}{k}'; Uc=f'{CL["URL_CHECK"]}{k}'
    f={'ISSUER_CORRECT':f'=IF(OR({V}="CORRECT",{V}="URL_CORRECTION_ONLY"),1,0)','GROUP_CORRECT':f'=IF(OR({CL["ISSUER_CORRECT"]}{k}=1,{V}="CORRECT_BETTER_MATCH"),1,0)',
       'NOTES_ASSESSMENT':(f'=IF({V}="","",IF(LEFT({Uc},4)="PASS",IF({V}="CORRECT","CONSISTENT",IF({V}="CORRECT_BETTER_MATCH","PARTIALLY_RIGHT","FALSE_PASS")),'
                f'IF({Uc}="URL_SIBLING_OF_GROUP",IF(OR({V}="WRONG_REMAP",{V}="WRONG_OWNER_NOT_IN_DMX"),"CORRECT_SIBLING_FLAG",IF(LEFT({V},7)="CORRECT","UNDERCONFIRMED","FLAG_OK")),'
                f'IF(OR({V}="CORRECT",{V}="CORRECT_BETTER_MATCH",{V}="URL_CORRECTION_ONLY"),"UNDERCONFIRMED","CORRECTLY_UNCONFIRMED"))))'),
       'CHANGED_VS_BASELINE':f'=IF({V}="","",IF({V}<>{CL["BASELINE_VERDICT"]}{k},1,0))'}
    ws.append([f[c] if c in f else r.get(c,'') for c in Hd])
dv=DataValidation(type='list',formula1='=LISTS!$A$2:$A$9'); ws.add_data_validation(dv); dv.add(f'{CL["EVAL_VERDICT"]}2:{CL["EVAL_VERDICT"]}{last}')
for c in ws[1]: c.font=FH; c.fill=HDR; c.alignment=Alignment(wrap_text=True,vertical='top')
for col in ['EVAL_VERDICT','EVAL_SUGGESTED_ISSUER_ID','EVAL_REASON','CORRECTED_URL']:
    for rr in range(2,last+1): ws[f'{CL[col]}{rr}'].fill=INP
ws.freeze_panes='C2'; ws.auto_filter.ref=f'A1:{L(len(Hd))}{last}'
R=lambda c: f"EVAL!${CL[c]}$2:${CL[c]}${last}"
ls=wb.create_sheet('LISTS'); ls.append(['VERDICT','MEANING']); [ls.append([v,MEAN[v]]) for v in VERD]
def hdr(sh,r,cs):
    for j,t in enumerate(cs,1): c=sh.cell(r,j,t); c.font=FH; c.fill=HDR
def cc(crit): return ''.join(f',{a},"{b}"' for a,b in crit)
def report(name,crit,title):
    sh=wb.create_sheet(name[:31]); sh.cell(1,1,title).font=FT; hdr(sh,2,['Verdict','Rows','% rows'])
    for i,v in enumerate(VERD):
        rr=3+i; sh.cell(rr,1,v); sh.cell(rr,2,f'=COUNTIFS({R("EVAL_VERDICT")},$A{rr}{cc(crit)})'); sh.cell(rr,3,f'=IFERROR(B{rr}/B${3+len(VERD)},0)'); sh.cell(rr,3).number_format='0.0%'
    tr=3+len(VERD); sh.cell(tr,1,'TOTAL checked').font=FB; sh.cell(tr,2,f'=SUM(B3:B{tr-1})')
    sh.cell(tr+1,1,'Strict accuracy').font=FB; sh.cell(tr+1,2,f'=IFERROR((B3+B4)/B{tr},0)'); sh.cell(tr+2,1,'Group-level accuracy').font=FB; sh.cell(tr+2,2,f'=IFERROR((B3+B4+B5)/B{tr},0)')
    for x in (tr+1,tr+2): sh.cell(x,2).number_format='0.0%'
    r0=tr+4; sh.cell(r0,1,'NOTES column assessment').font=FT; hdr(sh,r0+1,['Value','Rows'])
    for i,v in enumerate(NOTE_VALS): sh.cell(r0+2+i,1,v); sh.cell(r0+2+i,2,f'=COUNTIFS({R("NOTES_ASSESSMENT")},$A{r0+2+i}{cc(crit)})')
    r0=r0+3+len(NOTE_VALS); sh.cell(r0,1,'Flags / categories').font=FT; hdr(sh,r0+1,['Flag','Rows'])
    items=[('Same URL as parent (not wrong; parent preferred)','FLAG_SAME_URL_AS_PARENT','Y'),('Strict-N6 note (not applied)','NOTE_STRICT_N6','<>'),('M3 miss documented','M3_MISS','<>'),('JV partner recorded','JV_PARTNERS','<>'),('Lifecycle watch','LIFECYCLE_WATCH','<>'),('DMX issue recorded','DMX_ISSUE','<>'),('Name fix','CORRECTED_NAME','<>'),('GICS_MISMATCH category','GICS_CATEGORY','GICS_MISMATCH'),('Changed vs baseline','CHANGED_VS_BASELINE','1'),('URL not accessible','URL_ACCESS','BLOCKED'),('Dead URL','URL_ACCESS','DEAD')]
    for i,(lab,col,c) in enumerate(items): sh.cell(r0+2+i,1,lab); sh.cell(r0+2+i,2,f'=COUNTIFS({R(col)},"{c}"{cc(crit)})')
    r0=r0+3+len(items); sh.cell(r0,1,'Baseline verdict (rows) x new verdict (columns)').font=FT; hdr(sh,r0+1,['Baseline \\ New']+VERD)
    for i,b in enumerate(VERD):
        rr=r0+2+i; sh.cell(rr,1,b)
        for j,v in enumerate(VERD,2): sh.cell(rr,j,f'=COUNTIFS({R("BASELINE_VERDICT")},$A{rr},{R("EVAL_VERDICT")},"{v}"{cc(crit)})')
    sh.column_dimensions['A'].width=52
    for j in range(2,11): sh.column_dimensions[L(j)].width=15
s=wb.create_sheet('SUMMARY',0); s['A1']='Issuer attribution audit - row-by-row (Cowork) - all figures are formulas over EVAL'; s['A1'].font=Font(name='Arial',size=12,bold=True)
groups=[('ALL',[])]+[(x,[(R('STATUS'),x)]) for x in STAT]+[(x,[(R('URL_CHECK'),x)]) for x in UCH]
hdr(s,3,['Metric']+[g for g,_ in groups])
mets=[('Rows in file','*rows'),('Rows checked (CHECK_STATUS=DONE)','*done')]+[(v,v) for v in VERD]
for i,(lab,v) in enumerate(mets):
    rr=4+i; s.cell(rr,1,lab)
    for j,(g,crit) in enumerate(groups,2):
        if v=='*rows': s.cell(rr,j,f'=COUNTA({R("FACILITY_ID")})' if not crit else f'=COUNTIFS({crit[0][0]},"{crit[0][1]}")')
        elif v=='*done': s.cell(rr,j,f'=COUNTIFS({R("CHECK_STATUS")},"DONE"{cc(crit)})')
        else: s.cell(rr,j,f'=COUNTIFS({R("EVAL_VERDICT")},"{v}"{cc(crit)})')
rr=4+len(mets)
for lab,num in [('Strict accuracy (of checked)','ISSUER_CORRECT'),('Group-level accuracy (of checked)','GROUP_CORRECT')]:
    s.cell(rr,1,lab).font=FB
    for j,(g,crit) in enumerate(groups,2):
        den='+'.join(f'COUNTIFS({R("EVAL_VERDICT")},"{v}"{cc(crit)})' for v in VERD)
        s.cell(rr,j,f'=IFERROR(SUMIFS({R(num)}{cc(crit)})/({den}),0)' if crit else f'=IFERROR(SUM({R(num)})/({den}),0)'); s.cell(rr,j).number_format='0.0%'
    rr+=1
s.column_dimensions['A'].width=40
for j in range(2,12): s.column_dimensions[L(j)].width=17
report('REPORT_ALL',[],'All rows')
for x in STAT: report(f'REPORT_{x}',[(R('STATUS'),x)],f'STATUS = {x}')
for x in UCH: report(f'RPT_{x}',[(R('URL_CHECK'),x)],f'URL_CHECK = {x}')
ib=wb.create_sheet('ISSUER_BREAKDOWN'); iss=q.groupby(['ISSUER_ID','SECMASTER_NAME']).size().reset_index(name='n').sort_values('n',ascending=False)
hdr(ib,1,['ISSUER_ID','ISSUER_NAME','Rows','Checked','Strict correct','Wrong','Out of scope','Recollect','Strict accuracy']); I=R('ISSUER_ID'); Vv=R('EVAL_VERDICT')
for k,(_,x) in enumerate(iss.iterrows(),start=2):
    ib.cell(k,1,x.ISSUER_ID); ib.cell(k,2,x.SECMASTER_NAME); ib.cell(k,3,f'=COUNTIF({I},$A{k})'); ib.cell(k,4,f'=COUNTIFS({I},$A{k},{R("CHECK_STATUS")},"DONE")')
    ib.cell(k,5,f'=SUMIFS({R("ISSUER_CORRECT")},{I},$A{k})'); ib.cell(k,6,f'=COUNTIFS({I},$A{k},{Vv},"WRONG_REMAP")+COUNTIFS({I},$A{k},{Vv},"WRONG_OWNER_NOT_IN_DMX")')
    ib.cell(k,7,f'=COUNTIFS({I},$A{k},{Vv},"OUT_OF_SCOPE_DROP")'); ib.cell(k,8,f'=COUNTIFS({I},$A{k},{Vv},"RECOLLECT")'); ib.cell(k,9,f'=IFERROR(E{k}/D{k},0)'); ib.cell(k,9).number_format='0.0%'
ib.freeze_panes='C2'; ib.column_dimensions['B'].width=45
nf=wb.create_sheet('NAME_FIXES'); hdr(nf,1,['FACILITY_ID','ISSUER_ID','ORIGINAL_NAME','CORRECTED_NAME','COMMENTS'])
for k,(_,r) in enumerate(q[q.CORRECTED_NAME!=''].iterrows(),start=2):
    for j,c in enumerate(['FACILITY_ID','ISSUER_ID','FACILITY_NAME','CORRECTED_NAME','NAME_FIX_COMMENT'],1): nf.cell(k,j,r[c])
dm=wb.create_sheet('DMX_UPDATES'); hdr(dm,1,['ISSUER_ID','ISSUER_NAME','DMX_ISSUE (as recorded on rows)','ROWS'])
d=q[q.DMX_ISSUE!=''].groupby(['ISSUER_ID','SECMASTER_NAME','DMX_ISSUE']).size().reset_index()
for k,(_,r) in enumerate(d.iterrows(),start=2): dm.cell(k,1,r.ISSUER_ID); dm.cell(k,2,r.SECMASTER_NAME); dm.cell(k,3,r.DMX_ISSUE); dm.cell(k,4,f'=COUNTIFS({I},A{k},{R("DMX_ISSUE")},C{k})')
for w_ in wb.worksheets:
    for row in w_.iter_rows():
        for c in row:
            if c.font.name!='Arial': c.font=Font(name='Arial',size=c.font.size or 10,bold=c.font.bold,color=c.font.color,italic=c.font.italic)
wb.save(out); print('saved',out,len(q))
