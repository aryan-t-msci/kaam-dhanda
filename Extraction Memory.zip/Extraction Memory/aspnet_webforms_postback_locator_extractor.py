"""
ASP.NET WebForms postback locator extractor.

This script handles locator pages where an ASP.NET WebForms form updates
state/district/category search results through server postbacks. Configure the
selectors and categories below for a new issuer, then run:

    python aspnet_webforms_postback_locator_extractor.py

It writes raw normalized rows, progress JSON, and threshold checkpoints into the
configured issuer temp directory. Final schema validation and batch audit are
handled by the worker post-processing step.
"""

# ============================================================
# CONFIGURATION - edit this block for each new issuer
# ============================================================
ISSUER_ID = "IID000000002184431"
ISSUER_NAME = "THE SOUTH INDIAN BANK LIMITED"
BASE_URL = "https://www.southindianbank.bank.in"
LOCATOR_URL = "https://www.southindianbank.bank.in/help-desk/branch-locator"

ISSUER_TEMP = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Extraction_Batch_20260504_165656\IID000000002184431_THE SOUTH INDIAN BANK LIMITED"
TARGET_COUNT = 2267

STATE_SELECT = "#ctl00_Cphmaincommon_ddlState"
DISTRICT_SELECT = "#ctl00_Cphmaincommon_ddlDistrict"
SEARCH_BUTTON = "#ctl00_Cphmaincommon_btnsearchbycity"
CATEGORY_RADIO_NAME = "ctl00$Cphmaincommon$abc"

CATEGORIES = [
    {"id": "rbbranch", "label": "BRANCH", "section": "#ctl00_Cphmaincommon_branch", "activity": "Bank branch"},
    {"id": "rbatm", "label": "ATM", "section": "#ctl00_Cphmaincommon_atm", "activity": "Automated teller machine"},
    {"id": "rbcdm", "label": "CDM", "section": "#ctl00_Cphmaincommon_atm", "activity": "Cash deposit machine"},
]

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0"
)

# ============================================================
# GENERIC EXTRACTION LOGIC - do not modify per issuer
# ============================================================
import asyncio
import csv
import json
import re
import time
import unicodedata
from pathlib import Path
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from playwright.async_api import async_playwright


OUT_DIR = Path(ISSUER_TEMP)
RAW_CSV = OUT_DIR / f"{ISSUER_ID}_locator_raw.csv"
PROGRESS_JSON = OUT_DIR / f"{ISSUER_ID}_locator_progress.json"
CHECKPOINT_CSV = OUT_DIR / f"{ISSUER_ID}_checkpoint_at_target.csv"

RAW_COLUMNS = [
    "issuer_id",
    "issuer_name",
    "category",
    "location_name",
    "address",
    "postcode",
    "state",
    "state_value",
    "branch_code",
    "ifsc_code",
    "swift_code",
    "terminal_id",
    "phone",
    "detail_url",
    "source_url",
    "activity",
]


def ascii_clean(text: str) -> str:
    text = "" if text is None else str(text)
    replacements = {
        "\u2019": "'",
        "\u2018": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2013": "-",
        "\u2014": "-",
        "\u00a0": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def clean_address(text: str) -> str:
    text = ascii_clean(text)
    text = text.replace("#", "No.")
    text = re.sub(r"\b(PIN|Pincode)\s*[-:]?\s*", "", text, flags=re.I)
    text = re.sub(r"\s*,\s*", ", ", text)
    text = re.sub(r"\s*-\s*", "-", text)
    text = re.sub(r"\s+", " ", text).strip(" ,;-")
    return text


def text_of(node) -> str:
    if not node:
        return ""
    return ascii_clean(node.get_text(" ", strip=True))


def extract_detail_boxes(card) -> dict:
    details = {}
    for box in card.select(".detilbox"):
        label = text_of(box.find("p")).rstrip(":")
        value = text_of(box.find("span"))
        if label:
            details[label] = value
    return details


def parse_cards(html: str, category: dict, state_value: str, state_name: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    rows = []
    section = soup.select_one(category["section"])
    if not section:
        return rows

    for card in section.select(".branch-detils-box"):
        name = text_of(card.select_one(".branch-name h5"))
        details = extract_detail_boxes(card)
        address = clean_address(details.get("Address", ""))
        if not name or not address:
            continue
        link = card.select_one(".detil-btn a[href]")
        detail_url = urljoin(BASE_URL, link.get("href")) if link else ""
        rows.append(
            {
                "issuer_id": ISSUER_ID,
                "issuer_name": ISSUER_NAME,
                "category": category["label"],
                "location_name": name,
                "address": address,
                "postcode": ascii_clean(details.get("Pincode", "")) or extract_postcode(address),
                "state": state_name,
                "state_value": state_value,
                "branch_code": ascii_clean(details.get("Branch Code", "")),
                "ifsc_code": ascii_clean(details.get("IFSC Code", "")),
                "swift_code": ascii_clean(details.get("Swift Code", "")),
                "terminal_id": ascii_clean(details.get("Terminal ID", "")),
                "phone": ascii_clean(details.get("Phone Number", "")),
                "detail_url": detail_url,
                "source_url": LOCATOR_URL,
                "activity": category["activity"],
            }
        )
    return rows


def extract_postcode(address: str) -> str:
    match = re.search(r"\b(\d{6})\b", address)
    if match:
        return match.group(1)
    spaced = re.search(r"\b(\d{3})\s+(\d{3})\b", address)
    return "".join(spaced.groups()) if spaced else ""


def row_key(row: dict) -> tuple:
    if row["category"] == "BRANCH" and row.get("branch_code"):
        return (row["category"], row["branch_code"])
    if row["category"] in {"ATM", "CDM"} and row.get("terminal_id"):
        return (row["category"], row["terminal_id"])
    return (
        row["category"],
        row["location_name"].lower(),
        re.sub(r"\W+", "", row["address"].lower()),
    )


def write_rows(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=RAW_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


def save_progress(iteration: int, state: dict, category: dict, rows: list[dict], counts: dict, checkpointed: bool) -> None:
    payload = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "iteration": iteration,
        "last_state": state,
        "last_category": category["label"],
        "row_count": len(rows),
        "counts": counts,
        "checkpoint_written": checkpointed,
        "updated_at_epoch": time.time(),
    }
    PROGRESS_JSON.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    write_rows(RAW_CSV, rows)


async def wait_sib_post(page, action, timeout=60000) -> None:
    try:
        async with page.expect_response(
            lambda r: r.request.method == "POST" and r.url.startswith(LOCATOR_URL),
            timeout=timeout,
        ) as response_info:
            await action()
        response = await response_info.value
        if response.status >= 400:
            raise RuntimeError(f"Postback failed with HTTP {response.status}")
    except Exception:
        await action()
        await page.wait_for_timeout(3000)
    await page.wait_for_timeout(1000)


async def select_state(page, state_value: str) -> None:
    current = await page.eval_on_selector(STATE_SELECT, "el => el.value")
    if current == state_value:
        return

    async def action():
        await page.select_option(STATE_SELECT, state_value)

    await wait_sib_post(page, action)


async def search_category(page, state_value: str, category_id: str) -> None:
    # WebForms retains the selected district after state changes; force all districts.
    await page.select_option(DISTRICT_SELECT, "0")
    await page.evaluate(
        """([radioName, categoryId]) => {
            document.querySelectorAll(`input[name="${radioName}"]`).forEach(el => {
                el.checked = (el.id === categoryId);
            });
            const selected = document.querySelector("#" + categoryId);
            selected && selected.dispatchEvent(new Event("change", {bubbles: true}));
        }""",
        [CATEGORY_RADIO_NAME, category_id],
    )

    async def action():
        await page.evaluate(f"document.querySelector('{SEARCH_BUTTON}').click()")

    await wait_sib_post(page, action)


async def safe_page_content(page, attempts: int = 5) -> str:
    last_error = None
    for _ in range(attempts):
        try:
            return await page.content()
        except Exception as exc:
            last_error = exc
            await page.wait_for_timeout(1500)
    raise RuntimeError(f"Unable to read page content after {attempts} attempts: {last_error}")


async def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    all_rows = []
    seen = set()
    counts = {}
    checkpointed = False
    iteration = 0

    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(
            channel="msedge",
            headless=True,
            args=["--disable-blink-features=AutomationControlled"],
        )
        context = await browser.new_context(
            locale="en-US",
            timezone_id="Asia/Calcutta",
            viewport={"width": 1366, "height": 768},
            user_agent=USER_AGENT,
        )
        await context.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        page = await context.new_page()
        page.set_default_timeout(60000)

        await page.goto(LOCATOR_URL, wait_until="domcontentloaded", timeout=60000)
        await page.wait_for_timeout(3000)
        title = await page.title()
        if "Cloudflare" in title or "Attention Required" in title:
            raise RuntimeError(f"Cloudflare challenge page loaded: {title}")

        states = await page.locator(f"{STATE_SELECT} option").evaluate_all(
            "(opts) => opts.map(o => ({value: o.value, text: o.textContent.trim()})).filter(o => o.value !== '0')"
        )

        for state in states:
            await select_state(page, state["value"])
            for category in CATEGORIES:
                iteration += 1
                await search_category(page, state["value"], category["id"])
                html = await safe_page_content(page)
                rows = parse_cards(html, category, state["value"], state["text"])
                counts[f"{state['text']}|{category['label']}"] = len(rows)

                added = 0
                for row in rows:
                    key = row_key(row)
                    if key in seen:
                        continue
                    seen.add(key)
                    all_rows.append(row)
                    added += 1

                print(
                    f"{iteration:03d} {state['text']} {category['label']}: "
                    f"{len(rows)} rows, {added} new, total {len(all_rows)}",
                    flush=True,
                )

                if len(all_rows) >= TARGET_COUNT and not checkpointed:
                    write_rows(CHECKPOINT_CSV, all_rows)
                    checkpointed = True
                if iteration % 20 == 0:
                    save_progress(iteration, state, category, all_rows, counts, checkpointed)

        await browser.close()

    save_progress(iteration, {"value": "", "text": "COMPLETE"}, {"label": "COMPLETE"}, all_rows, counts, checkpointed)
    if checkpointed and not CHECKPOINT_CSV.exists():
        write_rows(CHECKPOINT_CSV, all_rows)
    print(f"COMPLETE rows={len(all_rows)} states_categories={iteration} checkpointed={checkpointed}")


if __name__ == "__main__":
    asyncio.run(main())
