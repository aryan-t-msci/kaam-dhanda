"""
Kotak AMC ISC Final Extractor
==============================
DISCOVERED API:
  Backend: https://vlbapiprodtest.kotakmf.com
  Endpoint: GET /kotakapi/contactus/user/getcontacts/ISC
  Auth: No auth required (public endpoint)
  WAF: Radware on kotakmf.com but NOT on the direct backend
  Response: JSON with contactList[] containing full ISC records with lat/lon

Also try other contact types by appending type to the path.
"""

import csv
import json
import re
import sys
import time
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

import httpx

ISSUER_ID    = "IID000000002173037"
ISSUER_NAME  = "KOTAK MAHINDRA BANK LIMITED"

BACKEND_URL  = "https://vlbapiprodtest.kotakmf.com"
ISC_ENDPOINT = "/kotakapi/contactus/user/getcontacts/ISC"

OUTPUT_DIR   = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Geo Analysts\Gap Output")
OUTPUT_CSV   = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_Gap.csv"
RAW_JSON     = Path(r"C:\Temp\kotakmf_isc_raw.json")

CSV_COLUMNS = [
    "ISSUER_ID", "ISSUER_NAME", "FACILITY_NAME", "FACILITY_ADDRESS",
    "CITY", "STATE", "POSTAL_CODE", "FACILITY_REGION",
    "LATITUDE", "LONGITUDE", "FACILITY_CONTACT_NUMBER",
    "RELEVANT_URL", "BUSINESS_ACTIVITY",
]

IOS_UA = (
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) "
    "Version/17.4 Mobile/15E148 Safari/604.1"
)

CITY_STATE = {
    "delhi": "Delhi", "new delhi": "Delhi", "gurugram": "Haryana", "gurgaon": "Haryana",
    "noida": "Uttar Pradesh", "faridabad": "Haryana", "ghaziabad": "Uttar Pradesh",
    "mumbai": "Maharashtra", "pune": "Maharashtra", "nagpur": "Maharashtra",
    "nashik": "Maharashtra", "navi mumbai": "Maharashtra", "thane": "Maharashtra",
    "bangalore": "Karnataka", "bengaluru": "Karnataka", "mysore": "Karnataka",
    "mysuru": "Karnataka", "hubli": "Karnataka", "mangalore": "Karnataka",
    "mangaluru": "Karnataka", "belgaum": "Karnataka", "belagavi": "Karnataka",
    "chennai": "Tamil Nadu", "coimbatore": "Tamil Nadu", "madurai": "Tamil Nadu",
    "hyderabad": "Telangana", "secunderabad": "Telangana",
    "visakhapatnam": "Andhra Pradesh", "vizag": "Andhra Pradesh",
    "vijayawada": "Andhra Pradesh", "kolkata": "West Bengal", "ahmedabad": "Gujarat",
    "surat": "Gujarat", "vadodara": "Gujarat", "baroda": "Gujarat", "rajkot": "Gujarat",
    "jaipur": "Rajasthan", "jodhpur": "Rajasthan", "udaipur": "Rajasthan",
    "kota": "Rajasthan", "ajmer": "Rajasthan", "bikaner": "Rajasthan",
    "lucknow": "Uttar Pradesh", "kanpur": "Uttar Pradesh", "agra": "Uttar Pradesh",
    "varanasi": "Uttar Pradesh", "prayagraj": "Uttar Pradesh",
    "chandigarh": "Chandigarh", "ludhiana": "Punjab", "amritsar": "Punjab",
    "indore": "Madhya Pradesh", "bhopal": "Madhya Pradesh",
    "bhubaneswar": "Odisha", "cuttack": "Odisha",
    "patna": "Bihar", "ranchi": "Jharkhand", "jamshedpur": "Jharkhand",
    "dehradun": "Uttarakhand", "kochi": "Kerala", "thiruvananthapuram": "Kerala",
    "trivandrum": "Kerala", "kozhikode": "Kerala", "thrissur": "Kerala",
    "ernakulam": "Kerala", "guwahati": "Assam", "raipur": "Chhattisgarh",
    "panaji": "Goa", "panjim": "Goa", "shimla": "Himachal Pradesh",
    "pondicherry": "Puducherry", "puducherry": "Puducherry",
    "jammu": "Jammu & Kashmir", "srinagar": "Jammu & Kashmir",
    "aurangabad": "Maharashtra", "kolhapur": "Maharashtra", "solapur": "Maharashtra",
    "jalgaon": "Maharashtra", "amravati": "Maharashtra", "ahmednagar": "Maharashtra",
    "warangal": "Telangana", "nizamabad": "Telangana", "karimnagar": "Telangana",
    "nellore": "Andhra Pradesh", "kakinada": "Andhra Pradesh",
    "salem": "Tamil Nadu", "trichy": "Tamil Nadu", "tiruchirappalli": "Tamil Nadu",
    "tirunelveli": "Tamil Nadu", "erode": "Tamil Nadu", "vellore": "Tamil Nadu",
    "gwalior": "Madhya Pradesh", "jabalpur": "Madhya Pradesh",
    "rohtak": "Haryana", "hisar": "Haryana", "panipat": "Haryana",
    "meerut": "Uttar Pradesh", "bareilly": "Uttar Pradesh", "gorakhpur": "Uttar Pradesh",
    "moradabad": "Uttar Pradesh", "saharanpur": "Uttar Pradesh",
    "allahabad": "Uttar Pradesh",
}

POSTAL_STATE = {
    "11": "Delhi", "12": "Haryana", "13": "Haryana", "14": "Punjab",
    "15": "Punjab", "16": "Chandigarh", "17": "Himachal Pradesh",
    "18": "Jammu & Kashmir", "19": "Jammu & Kashmir",
    "20": "Uttar Pradesh", "21": "Uttar Pradesh", "22": "Uttar Pradesh",
    "23": "Uttar Pradesh", "24": "Uttar Pradesh", "25": "Uttar Pradesh",
    "26": "Uttarakhand", "27": "Uttar Pradesh", "28": "Uttar Pradesh",
    "30": "Rajasthan", "31": "Rajasthan", "32": "Rajasthan",
    "33": "Rajasthan", "34": "Rajasthan", "35": "Rajasthan",
    "36": "Gujarat", "37": "Gujarat", "38": "Gujarat", "39": "Gujarat",
    "40": "Maharashtra", "41": "Maharashtra", "42": "Maharashtra",
    "43": "Maharashtra", "44": "Maharashtra",
    "45": "Madhya Pradesh", "46": "Madhya Pradesh", "47": "Madhya Pradesh",
    "48": "Madhya Pradesh", "49": "Chhattisgarh",
    "50": "Telangana", "51": "Andhra Pradesh", "52": "Andhra Pradesh",
    "53": "Andhra Pradesh", "56": "Karnataka", "57": "Karnataka",
    "58": "Karnataka", "59": "Karnataka",
    "60": "Tamil Nadu", "61": "Tamil Nadu", "62": "Tamil Nadu",
    "63": "Tamil Nadu", "64": "Tamil Nadu", "65": "Tamil Nadu",
    "67": "Kerala", "68": "Kerala", "69": "Kerala",
    "70": "West Bengal", "71": "West Bengal", "72": "West Bengal",
    "73": "West Bengal", "74": "West Bengal",
    "75": "Odisha", "76": "Odisha", "77": "Odisha",
    "78": "Assam", "79": "Assam",
    "80": "Bihar", "81": "Bihar", "82": "Jharkhand", "83": "Jharkhand",
    "84": "Bihar", "85": "Bihar", "90": "Goa",
}


def extract_postal(text):
    m = re.search(r"\b(\d{6})\b", text)
    return m.group(1) if m else ""


def get_state(city, address):
    st = CITY_STATE.get(city.lower().strip(), "")
    if st:
        return st
    # Try partial match on address
    for s in sorted(set(CITY_STATE.values()), key=len, reverse=True):
        if s.lower() in address.lower():
            return s
    postal = extract_postal(address)
    if postal:
        return POSTAL_STATE.get(postal[:2], "")
    return ""


def extract_city_from_address(address):
    """Try to extract city from address string."""
    # Pattern: "City - State" or "City, State" or last part before pincode
    lines = [l.strip() for l in re.split(r'[\n,]', address) if l.strip()]
    for line in lines:
        if any(city in line.lower() for city in CITY_STATE):
            for city in sorted(CITY_STATE.keys(), key=len, reverse=True):
                if city in line.lower():
                    return city.title()
    return ""


print("=" * 65)
print("KOTAK AMC ISC FINAL EXTRACTOR")
print("=" * 65)
print(f"API: {BACKEND_URL}{ISC_ENDPOINT}")
print()

# ── Step 1: Fetch ISC data ─────────────────────────────────
print("=== FETCHING ISC DATA ===")

contact_types = ["ISC"]  # Primary type

all_records = []
all_types_seen = set()

with httpx.Client(
    headers={
        "User-Agent": IOS_UA,
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-IN,en;q=0.9",
        "Origin": "https://www.kotakmf.com",
        "Referer": "https://www.kotakmf.com/Information/contact-us",
    },
    verify=False,
    follow_redirects=True,
    timeout=30,
) as c:
    # First fetch ISC type
    for ctype in contact_types:
        url = f"{BACKEND_URL}/kotakapi/contactus/user/getcontacts/{ctype}"
        print(f"\nFetching: GET {url}")
        try:
            r = c.get(url)
            print(f"  Status: {r.status_code}  Size: {len(r.content):,}B  CT: {r.headers.get('content-type','?')}")

            if r.status_code == 200:
                data = r.json()
                print(f"  Keys: {list(data.keys()) if isinstance(data, dict) else 'list'}")

                if isinstance(data, dict):
                    status = data.get("status", "")
                    msg = data.get("statusMessage", "")
                    print(f"  Status msg: {status} — {msg}")

                    contacts = data.get("contactList", data.get("data", data.get("results", [])))
                    if isinstance(contacts, list):
                        print(f"  Records: {len(contacts)}")
                        if contacts:
                            print(f"  First record keys: {list(contacts[0].keys()) if isinstance(contacts[0], dict) else '?'}")
                            print(f"  First record:\n{json.dumps(contacts[0], indent=2, ensure_ascii=False)[:600]}")
                        all_records.extend([(rec, ctype) for rec in contacts])

                        # Get distinct types in the data
                        for rec in contacts:
                            t = rec.get("type", rec.get("contactType", rec.get("contacttype", "")))
                            if t:
                                all_types_seen.add(t)

                elif isinstance(data, list):
                    print(f"  List records: {len(data)}")
                    all_records.extend([(rec, ctype) for rec in data])

        except Exception as e:
            print(f"  ERROR: {e}")
        time.sleep(0.5)

    # Try to discover other contact types from the first batch
    if all_types_seen:
        print(f"\nDiscovered contact types: {all_types_seen}")
        for ctype in all_types_seen:
            if ctype not in contact_types:
                url = f"{BACKEND_URL}/kotakapi/contactus/user/getcontacts/{ctype}"
                print(f"\nFetching type '{ctype}'...")
                try:
                    r = c.get(url)
                    if r.status_code == 200:
                        data = r.json()
                        contacts = data.get("contactList", data.get("data", []))
                        if isinstance(contacts, list):
                            print(f"  {ctype}: {len(contacts)} records")
                            all_records.extend([(rec, ctype) for rec in contacts])
                except Exception as e:
                    print(f"  ERROR: {e}")

    # Also try without the type suffix to see if it returns all
    print(f"\nTrying without type suffix (all records)...")
    try:
        r = c.get(f"{BACKEND_URL}/kotakapi/contactus/user/getcontacts")
        if r.status_code == 200:
            data = r.json()
            contacts = data.get("contactList", data.get("data", []))
            if isinstance(contacts, list):
                print(f"  All contacts (no type): {len(contacts)} records")
    except Exception as e:
        print(f"  ERROR: {e}")

    # Try other type values
    for extra_type in ["BRANCH", "CORPORATE", "HO", "RO", "ZO", "AMC", "OFFICE", "ALL", "all"]:
        url = f"{BACKEND_URL}/kotakapi/contactus/user/getcontacts/{extra_type}"
        try:
            r = c.get(url)
            if r.status_code == 200:
                data = r.json()
                contacts = data.get("contactList", data.get("data", []))
                if isinstance(contacts, list) and len(contacts) > 0:
                    print(f"  Type '{extra_type}': {len(contacts)} records")
                    # Avoid duplicates
                    existing_ids = {rec.get("id") for rec, _ in all_records}
                    new = [(rec, extra_type) for rec in contacts if rec.get("id") not in existing_ids]
                    all_records.extend(new)
                    print(f"    Added {len(new)} new records")
        except Exception:
            pass

# ── Step 2: Save raw JSON ─────────────────────────────────
print(f"\n=== TOTAL RECORDS: {len(all_records)} ===")

raw_data = [rec for rec, _ in all_records]
with open(RAW_JSON, "w", encoding="utf-8") as f:
    json.dump(raw_data, f, indent=2, ensure_ascii=False)
print(f"Raw JSON saved: {RAW_JSON}")

if not all_records:
    print("No records found. Exiting.")
    sys.exit(1)

# Show sample
print(f"\nSample record:")
print(json.dumps(all_records[0][0], indent=2, ensure_ascii=False)[:600])

# ── Step 3: Process into CSV rows ─────────────────────────
print(f"\n=== PROCESSING {len(all_records)} RECORDS ===")

rows = []
seen_ids = set()

for rec, ctype in all_records:
    rec_id = rec.get("id", "")
    if rec_id and rec_id in seen_ids:
        continue
    if rec_id:
        seen_ids.add(rec_id)

    # Field extraction
    def g(*keys):
        for k in keys:
            v = rec.get(k)
            if v is not None and str(v).strip() not in ("", "null", "None", "0", "0.0"):
                return str(v).strip()
        return ""

    address = g("address", "Address", "ADDRESS", "fullAddress")
    address = re.sub(r'\s+', ' ', address.replace('\n', ', ')).strip()

    city    = g("city", "City", "CITY", "cityName")
    state   = g("state", "State", "STATE", "stateName")
    pincode = g("pincode", "Pincode", "PINCODE", "pin", "pin_code")
    lat     = g("latitude", "lat", "LAT", "LATITUDE")
    lon     = g("longitude", "lng", "LON", "LONGITUDE", "lng", "long")
    phone   = g("phone", "Phone", "PHONE", "contact", "contactNo", "mobileNo", "phoneNo", "telephone")
    name    = g("name", "Name", "officeName", "branchName", "label", "title")

    # Extract city from address if not provided
    if not city:
        city = extract_city_from_address(address)

    # Derive state
    if not state:
        state = get_state(city, address)

    # Derive pincode
    if not pincode:
        pincode = extract_postal(address)

    # Build facility name
    if not name:
        name = f"Kotak MF ISC - {city}" if city else f"Kotak MF ISC #{rec_id}"

    # Determine activity based on type
    activity = "Asset Management - Kotak MF Investor Service Centre (ISC)"

    rows.append({
        "ISSUER_ID":               ISSUER_ID,
        "ISSUER_NAME":             ISSUER_NAME,
        "FACILITY_NAME":           name,
        "FACILITY_ADDRESS":        address,
        "CITY":                    city,
        "STATE":                   state,
        "POSTAL_CODE":             pincode,
        "FACILITY_REGION":         "Asia",
        "LATITUDE":                lat,
        "LONGITUDE":               lon,
        "FACILITY_CONTACT_NUMBER": phone,
        "RELEVANT_URL":            "https://www.kotakmf.com/Information/contact-us",
        "BUSINESS_ACTIVITY":       activity,
    })

print(f"Processed {len(rows)} unique rows")
with_lat   = sum(1 for r in rows if r["LATITUDE"])
with_state = sum(1 for r in rows if r["STATE"])
with_city  = sum(1 for r in rows if r["CITY"])
print(f"  With lat/lon: {with_lat}/{len(rows)}")
print(f"  With state:   {with_state}/{len(rows)}")
print(f"  With city:    {with_city}/{len(rows)}")

# Sample output
print(f"\nSample rows:")
for row in rows[:3]:
    print(f"  {row['FACILITY_NAME']} | {row['CITY']}, {row['STATE']} | {row['POSTAL_CODE']}")
    print(f"  Addr: {row['FACILITY_ADDRESS'][:100]}")
    print(f"  Lat: {row['LATITUDE']}  Lon: {row['LONGITUDE']}")
    print()

# ── Step 4: Update gap CSV ─────────────────────────────────
print("=== UPDATING GAP CSV ===")

if not OUTPUT_CSV.exists():
    print(f"ERROR: {OUTPUT_CSV} not found")
    sys.exit(1)

with open(OUTPUT_CSV, encoding="utf-8-sig", newline="") as f:
    existing = list(csv.DictReader(f))

cams_rows  = [r for r in existing if "CAMS Investor Service Centre" in r.get("BUSINESS_ACTIVITY", "")]
other_rows = [r for r in existing if "CAMS Investor Service Centre" not in r.get("BUSINESS_ACTIVITY", "")]

print(f"  Existing: {len(existing)}  CAMS fallback: {len(cams_rows)}  Other: {len(other_rows)}")
print(f"  New ISC rows: {len(rows)}")

# Replace CAMS fallback with real ISC data (even if fewer — it's more accurate)
if len(rows) >= 50:
    print(f"  Replacing {len(cams_rows)} CAMS rows with {len(rows)} direct Kotak ISC rows")
    all_rows = other_rows + rows
else:
    print(f"  Appending {len(rows)} rows to existing")
    all_rows = existing + rows

with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
    writer.writeheader()
    writer.writerows(all_rows)

print(f"  FINAL total: {len(all_rows)} rows")
print(f"  Saved: {OUTPUT_CSV}")
print()
print("Done!")
