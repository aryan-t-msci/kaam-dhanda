from __future__ import annotations

import csv
import re
from pathlib import Path

import pandas as pd


ISSUER_ID = "IID000000002235890"
ISSUER_NAME = "COAL INDIA LTD"
OUTPUT_CSV = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output\Extraction_Batch_20260410_123343\IID000000002235890_COAL INDIA LTD.csv"
)

HEADERS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
]

PAGE_URLS = {
    "page0": "https://www.coalcontroller.gov.in/coal-washeries",
    "page1": "https://www.coalcontroller.gov.in/coal-washeries?page=1",
    "page2": "https://www.coalcontroller.gov.in/coal-washeries?page=2",
}

RELEVANT_URLS = {
    "ccl": "https://www.coalindia.in/departments/pmd/coking-coal-washery/",
    "bccl": "https://bcclweb.in/?page_id=27665",
}

TARGETS = [
    {
        "page": "page0",
        "raw_name": "CCL, Rajrappa washery",
        "name": "Rajrappa washery",
        "state": "Jharkhand",
        "city": "Ramgarh",
        "relevant_url": RELEVANT_URLS["ccl"],
    },
    {
        "page": "page0",
        "raw_name": "CCL,Kedla Washery",
        "name": "Kedla Washery",
        "state": "Jharkhand",
        "city": "Ramgarh",
        "relevant_url": RELEVANT_URLS["ccl"],
    },
    {
        "page": "page0",
        "raw_name": "CCL,Sawang Washery",
        "name": "Sawang Washery",
        "state": "Jharkhand",
        "city": "Bokaro",
        "relevant_url": RELEVANT_URLS["ccl"],
    },
    {
        "page": "page0",
        "raw_name": "CCL,Kathara Washery",
        "name": "Kathara Washery",
        "state": "Jharkhand",
        "city": "Bokaro",
        "relevant_url": RELEVANT_URLS["ccl"],
    },
    {
        "page": "page1",
        "raw_name": "BCCL ,Mohuda Washery",
        "name": "Mohuda Washery",
        "state": "Jharkhand",
        "city": "Baghmara",
        "relevant_url": RELEVANT_URLS["bccl"],
    },
    {
        "page": "page1",
        "raw_name": "BCCL ,Madhuband 5MTPA Washery",
        "name": "Madhuband 5MTPA Washery",
        "state": "Jharkhand",
        "city": "Dhanbad",
        "relevant_url": RELEVANT_URLS["bccl"],
    },
    {
        "page": "page1",
        "raw_name": "BCCL ,Madhuban (old) Washery",
        "name": "Madhuban (old) Washery",
        "state": "Jharkhand",
        "city": "Dhanbad",
        "relevant_url": RELEVANT_URLS["bccl"],
    },
    {
        "page": "page1",
        "raw_name": "BCCL ,Patherdih old-washery",
        "name": "Patherdih old-washery",
        "state": "Jharkhand",
        "city": "Dhanbad",
        "relevant_url": RELEVANT_URLS["bccl"],
    },
    {
        "page": "page2",
        "raw_name": "BCCL ,Dahibari Washery",
        "name": "Dahibari Washery",
        "state": "Jharkhand",
        "city": "Chirkunda",
        "relevant_url": RELEVANT_URLS["bccl"],
    },
    {
        "page": "page2",
        "raw_name": "BCCL ,Moonidih Washery",
        "name": "Moonidih Washery",
        "state": "Jharkhand",
        "city": "Dhanbad",
        "relevant_url": RELEVANT_URLS["bccl"],
    },
    {
        "page": "page2",
        "raw_name": "BCCL ,Dugda washery",
        "name": "Dugda washery",
        "state": "Jharkhand",
        "city": "Bokaro",
        "relevant_url": RELEVANT_URLS["bccl"],
    },
    {
        "page": "page2",
        "raw_name": "BCCL ,Bhojudih Washery",
        "name": "Bhojudih Washery",
        "state": "West Bengal",
        "city": "Purulia",
        "relevant_url": RELEVANT_URLS["bccl"],
    },
]


def load_tables() -> dict[str, pd.DataFrame]:
    return {key: pd.read_html(url)[0] for key, url in PAGE_URLS.items()}


def extract_postcode(address: str) -> str:
    match = re.search(r"(\d{6})", address)
    return match.group(1) if match else ""


def clean_address(address: str) -> str:
    return address.replace(",,", ", ").replace("PO:", "PO ").replace("PO-", "PO ").strip()


def build_rows() -> list[dict[str, str]]:
    tables = load_tables()
    rows: list[dict[str, str]] = []

    for target in TARGETS:
        table = tables[target["page"]]
        match = table.loc[table["Name of Washeries"] == target["raw_name"]]
        if match.empty:
            raise ValueError(f"Could not find row for {target['raw_name']}")

        record = match.iloc[0]
        address = clean_address(str(record["Address"]))
        rows.append(
            {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": target["name"],
                "LOCATION_ADDRESS": address,
                "LATITUDE": "",
                "LONGITUDE": "",
                "COUNTRY": "India",
                "COUNTRY_ISO3": "IND",
                "POSTCODE": extract_postcode(address),
                "STATE": target["state"],
                "CITY": target["city"],
                "SOURCE_URL": target["relevant_url"],
                "SOURCE_TYPE": "COMPANY WEBSITE",
                "ACTIVITY_AT_ASSET": "Coking coal washery",
                "coord_source": "Not from website",
            }
        )

    return rows


def main() -> None:
    rows = build_rows()
    OUTPUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT_CSV.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=HEADERS)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {len(rows)} rows to {OUTPUT_CSV}")


if __name__ == "__main__":
    main()
