# Token & efficiency optimization — how it works and why

This explains the changes that cut the cost of a run by ~70% with zero change to output.
It sits alongside `KB_SHARDING.md` (the migration/validation note); this file is the *why*.

![KB access pattern: before vs after sharding](kb_access_pattern.svg)

---

## 1. The one idea everything rests on: you pay for context *per turn*, not per read

A `codex exec` worker is a single conversation that grows turn by turn. On every turn the model
is sent the **entire conversation so far** — every instruction, every file it has read, every
tool result — and replies with a small amount of new text. The resent input is almost always the
bulk of the cost; the output is tiny by comparison.

The consequence drives every decision below: **anything a worker loads early stays in its context
and is re-sent on every later turn.** A file is not paid for once when it is read — it is paid for
roughly once per remaining turn. A 91K-token file read on turn 3 of a 118-turn session is billed
about 115 more times.

Your own data shows it: Cofinimmo's pre-sharding worker ran 118 turns and consumed 16.6M input
tokens to produce 139 rows. The rows are not what cost money — the repeatedly resent context is.

> Caching softens this (Codex discounts cached input, which is why the "cached" column is large),
> but it does not erase it: the first read of a big block is full price, sheer volume still drives
> the bill, and more turns also mean more reasoning and output. The proof that caching was not
> hiding the waste: cost fell 70% in near-lockstep with the 71% token cut.

---

## 2. The problem: the KB monolith

`KB_DETAIL.md` held every learned extraction record in one file — R-09 (Al Rajhi, Sitecore),
the P-07 image-pattern playbook, every script note, all 219 records — about **356 KB / ~91,000
tokens**.

Under the old protocol a worker that wanted to check "have we handled a company like this before?"
ran `Get-Content KB_DETAIL.md` and pulled all ~91K tokens into context. To *use* one record like
R-09 (~380 tokens) it loaded all 219 records — ~99.6% irrelevant to that issuer — and that bulk
then sat in context for the rest of the session. Cofinimmo's worker did this **7 separate times**,
so ~640K tokens of KB piled up in one conversation. That single behavior is most of why that
worker cost $7.73.

---

## 3. The fix: sharding — load the row, not the table

The oldest trick in databases and search: don't read the whole table to get one row.

```
BEFORE                              AFTER
KB_DETAIL.md  (~91,000 tok)         KB_INDEX.md   (~12,000 tok)  <- lean lookup, read once
  +-- all 219 records in one file   KB/R-09.md    (~380 tok)     <- opened only when needed
                                    KB/P-07.md    (~420 tok)
Worker reads the WHOLE thing        KB/...        (219 small files)
to use any single record            Worker reads index, opens the 1-2 records it needs
```

`KB_INDEX.md` is the routing layer. One row reads, in effect: *Al Rajhi -> pattern P-09 Sitecore
-> reuse script `alrajhi_final_clean.py` -> record R-09.* A worker scans that lean index once,
sees it needs R-09, and opens only `KB/R-09.md`. The KB cost of a lookup drops from ~91K tokens to
the index plus a couple of small shards — **and** the 91K monolith is no longer sitting in context
being resent on each of those turns.

That structural change is the whole win (see the measured results in section 9).

---

## 4. Why the split is lossless (and why that mattered)

`shard_kb.py` does not parse-and-rewrite records (that could corrupt them). It splits on record
boundaries using a byte-preserving round-trip, then **asserts that concatenating all the shards
back together reproduces the original file byte-for-byte** before writing anything. If that check
fails, it aborts.

This is not ceremony. The KB contains encoded/mojibake characters and Korean / Chinese / Japanese
addresses; a careless text split could silently mangle a byte. The lossless guarantee is what
makes "zero quality loss" a fact rather than a hope. It also forced the tool to handle real edge
cases — revision records (e.g. R-06b), records living after the "appending" block, the D-series —
and to prove none were dropped.

---

## 5. The write side: the KB still grows, without the monolith

Reading was only half of it. When a worker learns something new it must *write* a record. The old
way appended a block to the one giant `KB_DETAIL.md` — taking a write-lock on a 91K file plus a
fragile "append without colliding" dance whenever two workers finished at once.

Now a worker writes a brand-new file, `KB/R-172.md` (a unique name — no collision possible), and
appends a single line to `KB_INDEX.md` under a brief lock. The only shared contention left is a
one-line append to the index, not a rewrite of a huge file. Cheaper, and far less likely to
corrupt the KB when 20 workers run at once.

---

## 6. The smaller levers (always-resident cost)

Both target what is resent every turn, so every token saved is multiplied across the whole session.

- **Dead anchor-slugs stripped from `KB_INDEX.md`.** Record pointers used to be markdown links like
  `[-> R-09](#r-09-al-rajhi-banking)`. The `#...` targets used to live inside the monolith and are
  now gone, so they were dead links — and the slug text just repeated the company name already in
  the same row. Removing 205 of them took ~1,540 tokens (~11%) off the index. The live
  table-of-contents anchors (which point at real sections) were kept.

- **An 89K-token landmine closed.** Another old file, `extraction_approach_v2.md` (~89K tok), was
  labeled "legacy KB — read-only, do not append." It forbade *appending* but never said *don't
  read* — the same ambiguity that let workers wholesale-read the KB monolith. `prompt.md` now
  explicitly forbids reading it, so a worker can't decide to "just check the legacy file" and
  balloon its context.

---

## 7. Making it part of the workflow, not a chore

`shard_kb.py` is **self-skipping**: it builds shards only when `KB/` is empty, and does nothing
once shards exist — because from then on the workers maintain `KB/` directly. It is wired into
`run_batch.ps1` startup and the orchestrator's setup step (Phase O-0), so the first run bootstraps
it and every run after is a silent no-op. It refuses to re-shard a populated `KB/` without
`--force`, because re-sharding from the now-frozen monolith would *delete* any record the workers
learned after the freeze — a slow quality leak the guard prevents.

---

## 8. What was deliberately left alone — the honest part

Not everything that looks trimmable is worth trimming.

- **The index itself (~12K) is already lean** — a decision tree, a pattern catalogue, and a tight
  one-row-per-record table where every column (company, IID, pattern, reused-script name, record
  id) is a routing signal, with detail delegated to the shards. Cutting further removes routing
  precision: a quality cost for a token saving.
- **The behavioral prompts (`prompt.md`, `WORKER_PROMPT.md`) are the extraction spec.** Trimming
  them to save tokens risks changing what the workers do, which violates the zero-quality-loss bar.
- **Re-encoding the index's mojibake to clean UTF-8** would have saved only a few hundred tokens,
  the file's encoding turned out to be *mixed* (not cleanly reversible), and changing the encoding
  of a working file that can't be runtime-tested here is exactly the fragile move worth refusing.

---

## 9. Measured results (same 3 issuers, identical output: 19,078 / 1,454 / 139)

| Metric          | Pre-sharding (monolith) | Post-sharding (shards) | Reduction |
|-----------------|-------------------------|------------------------|-----------|
| Input tokens    | 26,540,003              | 7,558,955              | -71.5%    |
| Output tokens   | 179,661                 | 53,797                 | -70.1%    |
| Reasoning tokens| 60,461                  | 18,433                 | -69.5%    |
| Cost (USD)      | $12.39                  | $3.66                  | -70.5%    |
| Turns           | 207                     | 76                     | -63.3%    |
| Wall clock      | ~2h26m                  | ~14m                   | ~10x faster |

Clearest single-worker evidence — Cofinimmo, the worker that pre-sharding read the 91K monolith
7 times: **$7.73 -> $1.72 (-78%), 16.6M -> 3.9M input tokens (-77%), 118 -> 33 turns (-72%)**,
same 139-row result either way.

---

## TL;DR

The win came almost entirely from one structural insight — stop holding ~91K tokens of mostly
irrelevant KB in context across a long session — plus a few cheap, safe trims on whatever else is
resent every turn, and the discipline of *not* touching things where the token saving would cost
quality.
