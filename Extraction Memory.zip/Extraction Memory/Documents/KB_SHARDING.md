# KB sharding — I/O / token optimization

## The problem (measured, from real worker logs)

Workers were reading the whole knowledge base into context. In one validation run, a single
worker ran `Get-Content KB_DETAIL.md` **7 times** — and `KB_DETAIL.md` is **364 KB / ~91,000
tokens**. Because an agent's context is re-sent on every tool-call turn, a 91K-token file read
early in a run is paid for again on every subsequent step. That single habit dominated the token
bill, with no quality benefit (a worker needs 1–2 records, not all 219).

## The fix

`KB_DETAIL.md` is split into **one small file per record** under `KB/` (e.g. `KB/R-63.md`,
`KB/P-05.md`, `KB/U-06.md`, `KB/D-24.md`). `KB_INDEX.md` stays as the lean lookup. A worker now
reads the index, then opens only the 1–3 records it actually needs.

| | Old | New |
|---|---|---|
| KB read per task | up to ~91,000 tok (whole monolith) | ~760 tok (1–2 record shards) |
| Re-sent each turn | the whole monolith | only the few small records |
| New-record write | append to the shared monolith (collision-prone lock dance) | write a new `KB/<id>.md` file (no collision); one index row under lock |

Shards: **219 records** (P=30, U=14, R=171, D=4). The split is **byte-lossless** (records
concatenated in original order reproduce `KB_DETAIL.md` exactly).

## Sharding is automatic — you don't run it every time

Sharding is wired into the run itself and is **self-skipping**:

- `run_batch.ps1` runs `Tools\shard_kb.py` at startup, and the Codex Desktop orchestrator does
  the same as Step O-0. On a fresh setup this builds `KB\` once from `KB_DETAIL.md`; on every run
  after that the tool sees `KB\` is already populated and does nothing.
- During a run the workers maintain `KB\` directly — each new learned record is written straight
  into `KB\<id>.md` plus a one-line row in `KB_INDEX.md`. The monolith is never appended to again.

So you do **not** re-shard between runs, and you should **not** re-run it manually in normal use.
`shard_kb.py` refuses to clobber an existing `KB\` unless you pass `--force` (a deliberate
re-bootstrap that wipes `KB\` and rebuilds from `KB_DETAIL.md` — only safe when the monolith is
the complete source of truth, which it is NOT once workers have started writing shards).

**The one manual step, once:** the shards in this bundle were built from my copy of
`KB_DETAIL.md`, which lags yours (your recent runs appended newer records, e.g. R-165). Before
your first run, drop your current `KB_DETAIL.md` into the folder and either delete the bundled
`KB\` (so the first run rebuilds it) or run `py Tools\shard_kb.py --force` once. After that it is
fully automatic.

The prompt files are already rewired to use `KB\`: `prompt.md` (§2 read, §6 write), `WORKER_PROMPT.md`,
`TASK_PROMPT_TEMPLATE_BATCH.md` (BATCH-KB), `ORCHESTRATOR_PROMPT.md` (Step O-0 bootstrap), and
`KB_INDEX.md` (its pointers now reference the shards).

## How to validate (before a full run)

```bat
powershell -NoProfile -ExecutionPolicy Bypass -File ".\validate_prompts.ps1"
```

Then confirm, in the worker logs under `...\Temp\<run>\workers\`:

1. **No more monolith reads** — search the logs for `Get-Content KB_DETAIL` (or `cat KB_DETAIL`).
   There should be **none**; instead you'll see `Get-Content KB\R-*.md` / `KB\P-*.md`.
2. **Writes land as shards** — a newly learned issuer should produce a new `KB\R-XXX.md` file
   plus one new row in `KB_INDEX.md` (not an appended block in `KB_DETAIL.md`).
3. **Row counts unchanged** — the three validation issuers should still match their baselines
   (no quality regression).

## After validating

Once the logs confirm workers read/write shards, you can **retire `KB_DETAIL.md`** (move it to
`Archive\`). It's superseded by `KB\` + `KB_INDEX.md`. This is safe with the auto-bootstrap: the
per-run shard call checks `KB\` first and skips cleanly even when the monolith is gone (it only
needs `KB_DETAIL.md` for a from-scratch rebuild). Keep the archived copy as a backup; to rebuild
`KB\` from scratch later you'd restore it and run `--force`.

## What did NOT change (deliberately)

- The 129 reusable extractor scripts stay at the root, where workers load them by name. Moving
  them would be tidiness with reuse-breakage risk and **no token benefit** (a worker reads a
  script by name regardless of folder). The token win here is the KB, not the scripts.
- `KB_INDEX.md` is still read in full each task — by design. It is the routing map (decision
  tree + pattern catalogue + the one-row-per-record lookup + script inventory + rules), and the
  worker reads it once to choose an approach before opening any shard. Its largest section, the
  Site Record Lookup (~6.6K tok), is an irreducible table where every column is a routing/reuse
  signal (company, IID, pattern, the reused-script name, the record id). There is no redundant
  prose left to remove there; the per-record detail already lives in the shards.

## Follow-up I/O hardening (applied in the same pass)

Two further always-resident-cost reductions, both verified lossless:

1. **Stripped 200 dead anchor-slugs from `KB_INDEX.md`.** The record/pattern pointers used to be
   markdown links like `[→ R-09](#r-09-al-rajhi-banking)`, whose `#…` targets were the detail
   headings that have since moved into the shards — so the anchors were dead, and the slug text
   just repeated the company name already in the row. They are now plain `→ R-09`. Workers
   navigate by reading the id and opening `KB\<id>.md` (per `prompt.md` §2b), never by the anchor,
   so this is zero-quality-loss. Verified: all 479 record-id references preserved (set-equal), the
   5 live table-of-contents anchors kept, only anchor-lines changed. **`KB_INDEX.md`: 55,809 →
   49,643 bytes (~1,540 tok off every turn, ~11% of the index).**

2. **Closed an 89K-token landmine in `prompt.md`.** `extraction_approach_v2.md` (~349 KB / ~89K
   tok) was described only as "legacy KB (read-only; do not append)" — which forbade *appending*
   but not *reading*, the exact ambiguity that let workers wholesale-read the old `KB_DETAIL.md`.
   The line now explicitly forbids **reading** the legacy monolith (and any other large monolithic
   KB file). The file itself is untouched and remains available as reference; only the accidental
   whole-file load is prevented.

Net effect after this pass: the dominant per-lookup cost (the ~91K monolith) is gone, the single
largest always-resident file (`KB_INDEX.md`) is ~11% lighter on every turn, and the largest latent
whole-file-read risk (the 89K legacy KB) is fenced off.
