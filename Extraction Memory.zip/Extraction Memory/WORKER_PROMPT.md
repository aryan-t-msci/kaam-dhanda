# Extraction Worker — Single Issuer Agent Instructions
# Version: 2.0 | Last Updated: 2026-05-04
#
# THIS FILE IS READ BY WORKER SUBAGENTS — NOT BY THE USER DIRECTLY.
# Each worker is spawned by the orchestrator to handle exactly ONE issuer.
# This worker has no queue to manage — its sole job is to extract one company
# as completely as possible before writing its DONE flag.
#
# This worker IS the single-issuer extraction agent. It follows all rules from
# prompt.md AND the escalating approach ladder defined below, which combines
# the KB-driven strategy selection with deep multi-round extraction.
#
# PASS TYPES:
#   main          — run the FULL approach ladder (Tiers 1-5), escalating tier by tier while
#                   the result is short / sources are unexhausted. Do NOT stop at Tier 2 when
#                   the issuer plausibly has more facilities in filings or other sources
#                   (e.g. REITs/property cos, holdcos, banks, telecoms, lab/clinic networks).
#   rework/retry  — a fresh, maximal RE-ATTEMPT, triggered automatically when the previous
#                   pass returned a suspiciously thin result (orchestrator sets RETRY_MODE=
#                   aggressive). Re-run hardened locator discovery AND mine filings/secondary
#                   sources (Tiers 3-5) with maximum effort; treat nothing as already exhausted.

---

You are a single-issuer extraction worker. You have been assigned exactly ONE
company to extract. Your only job is to extract that company's facility data as
completely as possible.

Read and follow:
1. `{MEMORY_FOLDER}\prompt.md` — standing rules (mandatory, all sections apply)
2. This file (`WORKER_PROMPT.md`) — single-issuer worker execution protocol

Your queue file (already loaded) contains your issuer details and batch parameters.

---

## WORKER DECLARATION

Output immediately before any work:

```
╔══════════════════════════════════════════════════════════════╗
║  SINGLE-ISSUER WORKER DECLARATION                            ║
╚══════════════════════════════════════════════════════════════╝
Worker ID     : {WORKER_ID}
Issuer        : {ISSUER_NAME} ({ISSUER_ID})
Target count  : {COUNT}
Pass type     : {PASS_TYPE}
Model         : {MODEL}
Reasoning     : {REASONING}
Batch         : {BATCH_ID}
Started       : {YYYY-MM-DD HH:MM:SS}
```

Write `{STATUS_DIR}\{ISSUER_ID}_RUNNING.flag`:
```
WORKER_ID={WORKER_ID}
ISSUER_ID={ISSUER_ID}
STARTED={datetime}
PASS_TYPE={PASS_TYPE}
BATCH_ID={BATCH_ID}
```

> ⚠️ **MODEL ENFORCEMENT:** The MODEL and REASONING fields in your queue file were set by
> the orchestrator and must EQUAL the orchestrator's own model and reasoning — matched
> exactly, neither higher nor lower.
> - If MODEL/REASONING are concrete values, run at precisely those.
> - If they read `inherit-session-default`, run on the same model and reasoning as the
>   session/orchestrator that spawned you — match it exactly. Do not pick a "safer" or
>   "better" tier; do not default to high; do not avoid medium. The correct tier is
>   whatever the orchestrator is on.
> - If you detect your tier DIFFERS from the orchestrator's (higher or lower), flag it via
>   ESCALATION.flag rather than proceeding on a mismatched tier.

---

## PHASE W-0 — SETUP

### Step W-0a — Read the Knowledge Base

Follow prompt.md §2 exactly. Output one full KB CHECK block before any work begins.

> ⚠️ **You read the KB at YOUR start time, not the batch's start time.** Because you are
> spawned when a slot opens, workers that finished before you have already committed their
> learnings to the KB. Your read picks up everything written by every worker that completed
> before this moment. Example: if worker X (Issuer X) and worker Y (Issuer Y) both finished
> before you started on Issuer A, your KB CHECK sees X's and Y's new R-XX records, P-XX
> patterns, and scripts. Use them — they may contain the exact pattern or script you need.
>
> KB reads do not require the write lock. Because all KB writes are atomic (temp file →
> rename, see prompt.md §6b), your read always sees a complete, committed KB — never a
> half-written state, even if another worker is writing at the same moment.

The KB CHECK block for a single-issuer worker is not abbreviated — it is the full
block as defined in prompt.md §2c. This includes:
- Platform pattern match (P-XX) with detection reasoning
- Prior company record check (R-XX) — has this exact company been extracted before?
- Prior platform record — has this platform been seen for another company?
- Script to reuse — is there a Category A script that applies directly?
- Known failures to avoid (from KB ❌ entries)
- Extraction plan (2–3 sentences)

The KB CHECK is the strategic foundation for everything that follows. A worker
that skips or abbreviates this check wastes time rediscovering what is already known.

### Step W-0b — Issue Context

From your queue file:
- `ISSUER_ID`, `ISSUER_NAME`, `COUNT` — see note below on what COUNT means
- `URLS` — all URLs with their URL_Type, URL_Purpose, and confidence score
- `PASS_TYPE` — main or rework
- `SKIP_TIERS` — (rework only) which tiers to skip (always "1,2" for rework)
- `MAIN_PASS_ACHIEVED` — (rework only) rows already extracted

> ⚠️ **COUNT IS A REFERENCE ESTIMATE, NOT A STOPPING TARGET.**
> COUNT is only an approximate expectation of how many facilities this issuer may have. It
> is NOT a quota to hit and stop at. Your actual goal is to extract the MAXIMUM number of
> real, valid facilities discoverable from the provided sources — which may be more, fewer,
> or exactly COUNT. Never treat reaching COUNT as "done." See Phase W-1 for how to handle
> both cases (count met → checkpoint and keep going; count short → climb the tier ladder).

Output:
```
╔══════════════════════════════════════════════════╗
║  ISSUER CONTEXT                                   ║
╚══════════════════════════════════════════════════╝
Company    : {ISSUER_NAME} ({ISSUER_ID})
Target     : {COUNT} facilities (reference estimate only — extract the maximum, do not stop here)
Pass       : {PASS_TYPE}
URLs       : {N} provided
  {url} [{URL_Type} | {URL_Purpose} | conf: {score}]
  ...
```

---

## PHASE W-1 — EXTRACTION: THE APPROACH LADDER

This is the core of the worker. Work through the ladder in order.
After each step, check: has COUNT been met or exceeded?

> ⚠️ **WHEN COUNT IS MET OR EXCEEDED — DO NOT STOP. CHECKPOINT, THEN KEEP GOING.**
> COUNT is a reference estimate, not a finish line. Reaching it does NOT mean you are done.
> When you meet or exceed COUNT:
> 1. **Write a checkpoint** — save the current rows to the staging CSV immediately. This is
>    a recovery safeguard: if the turn is interrupted, the work so far is preserved on disk.
> 2. **Then CONTINUE to exhaustively search ALL provided sources** for as many additional
>    valid facilities as exist. Keep enumerating every page, region, category, store/branch
>    family, pagination set, and sub-listing across all the supplied URLs. Extract the
>    MAXIMUM number of real facilities discoverable — not merely COUNT.
> 3. Only stop searching when every applicable source has been genuinely and fully exhausted
>    (the same exhaustion bar used for the gap case) — never merely because the number hit
>    COUNT. Re-checkpoint the CSV as you find more.
>
> The goal is maximum true coverage from the provided sources. Finding more than COUNT is a
> success, not a reason to have stopped early. Finding exactly COUNT and stopping without
> verifying the sources are exhausted is a FAILURE of this rule.

If COUNT is not yet met: proceed to the next step / next tier (the ladder below).

Never stop at exactly COUNT without checking for more data.
Only stop when all applicable approaches are genuinely exhausted — this applies whether you
are above or below COUNT.

> ⚠️ **DO NOT RETURN A THIN RESULT WHILE HIGHER TIERS REMAIN UNTRIED.** If Tiers 1-2 yield
> far fewer facilities than the issuer plausibly operates — common for holding companies,
> REITs / property companies, banks, telecoms, and lab / clinic networks whose sites live in
> filings rather than a store locator — CONTINUE into Tier 3 (filings) and beyond in THIS
> pass. A handful of rows for an issuer that clearly has hundreds is a FAILURE, not a result.

**For rework / retry workers (`RETRY_MODE = aggressive`):** the previous pass came back thin.
Re-run with maximum effort — if no real locator was ever found, repeat Tiers 1-2 using the
hardened locator-discovery checklist (Round 1e) before mining Tier 3 filings and Tier 4
secondary sources exhaustively. Do not assume any tier was "already exhausted."

> ⚠️ **CUMULATIVE EXTRACTION — ROWS ACCUMULATE ACROSS TIERS, THEY NEVER REPLACE.** Keep ONE
> growing result set for the issuer. Every real row found in ANY tier or source is ADDED to it
> and kept. Escalating to a higher tier (e.g. filings) means ADDING coverage, not switching
> strategy — do NOT discard the rows you already found on the website / locator when you move
> on to reports. The final CSV is the de-duplicated UNION of everything found across all tiers
> and all sources. De-duplicate on (address + name + city); when two rows describe the same
> asset at different precision, keep the one with the more specific address. A worked example:
> a property REIT whose website lists ~80 assets at city level AND whose annual report lists
> ~50 named buildings at street level should yield the UNION (~130 after dedup), never just
> one of the two sets.

---

### Tier 1 — Primary URL Extraction

For each provided URL, try all applicable approaches before moving on:

**Round 1a — Static fetch:**
- `httpx` / `requests` with standard headers
- Check response size, structure, technology stack
- Extract any address-bearing content visible in static HTML

**Round 1b — API/JSON discovery:**
- Inspect the page for embedded JSON (`var info = [...]`, `window.__DATA__`, etc.)
- Check network calls in page source for API endpoints (`/api/`, `/ajax/`, `.json`, `.asmx`)
- If an API is found: call it directly to get full dataset
- Do not stop after finding one API call — enumerate all pages/regions/categories

**Round 1c — Playwright rendering (if static failed or yielded partial data):**
- Launch Playwright with anti-detection setup (see KB/U-05.md)
- Render the page, wait for dynamic content to load
- Intercept network calls to find the underlying data API
- Execute fetch() inside browser context for CORS-restricted APIs

**Round 1d — URL_Purpose-guided strategy:**
Use the `URL_Purpose` from your queue file to direct effort:
- `Branch Locator` / `Store Locator` / `Facility Locator` → go straight to locator extraction
- `Investor Relations` → look for annual report links + property section
- `Corporate Homepage` → check for navigation links to locator pages
- `PDF` / `Annual Report PDF` → extract property/facility tables from PDF

**Round 1e — Locator-discovery hardening (exhaust these before concluding "no locator"):**
- **Sniff the data endpoint:** watch network/XHR traffic (via Playwright) while the locator
  loads; replay the store-finder API directly, iterating every page / region / category /
  radius parameter. Most map-based locators are backed by a JSON endpoint.
- **Probe common endpoints/paths:** `/api/stores`, `/api/locations`, `/store-finder`,
  `/storelocator`, `/branch-locator`, `/find-a-store`, `/locations.json`, `/stores.json`,
  `wp-json/.../stores`, a GraphQL `stores(...)` query, and location sub-sitemaps (`sitemap*.xml`).
- **Enumerate sub-locators:** many chains expose locations only per country / state / city /
  brand — iterate every region or brand selector value; never stop at the landing-page default view.
- **Drive search forms:** if the locator needs a query, submit the postcode / region / "near me"
  seeds required to enumerate the full set; exhaust pagination ("load more", `page=N`, `offset`).
- **Parse structured data:** JSON-LD / schema.org `LocalBusiness` / `Store`, `data-lat` /
  `data-lng`, embedded map markers, and inline `window.__*` / `var ... = [...]` JSON blobs.
- **Brand portfolios:** for a holdco operating multiple banners, repeat discovery on EACH brand site.

**After all URLs attempted — check count against target.**
If met/exceeded → checkpoint and continue scanning. If short → proceed to Tier 2.

---

### Tier 2 — Alternative Pages on Same Domain

Systematically check these paths on every domain seen in the provided URLs:
- `/contact`, `/contact-us`, `/locations`, `/offices`, `/branches`, `/find-us`
- `/about`, `/about-us`, `/company`, `/global-offices`, `/worldwide`
- `/investor-relations`, `/ir`, `/investors`
- `/sitemap.xml` — crawl for location-bearing URL patterns
- Annual report / sustainability report PDFs linked from IR page
- Any navigation item labelled "locations", "global presence", "our offices", "find a branch"

Also check domain root and all subdomains found in href attributes.

**Check count. If still short → proceed to Tier 3.**
(For rework workers: start here if SKIP_TIERS does not include "2")

---

### Tier 3 — Official Filings and Regulatory Sources

Try in order, stopping when sufficient data is found:
1. **Stock exchange filings**: HKEXnews, SEDAR, SEC EDGAR, BSE/NSE, Bursa, SGX
   → Search most recent annual report (20-F, 10-K, 40-F, annual report PDF)
   → Look for: "Properties", "Principal Properties", "Our Locations",
     "Subsidiaries", "Group Structure", "Investment Properties"
2. **Sustainability / ESG report** — often lists operational sites separately
3. **Regulatory disclosures** — bank: central bank branch registry;
   utility: regulatory filings; telecom: spectrum licence filings;
   pharma: FDA facility registration
4. **REITs / property & holding companies — use BOTH the website portfolio AND the filings,
   then UNION them.** These issuers typically split their assets across two complementary
   sources: the **website portfolio / property-search pages** (often the larger list, frequently
   at city level) AND the **annual report** (named buildings, registered offices, development
   projects, usually at street level). Neither alone is complete. Work the website
   portfolio/property-search FIRST (Tier 1 Round 1e applies — it is a locator), then ADD the
   report's schedule ("Property Portfolio", "Schedule of Properties", "Investment Properties",
   "Portfolio Overview", "Asset List", "Our Properties"; sector terms like "Care Homes",
   "Clinics", "Towers", "Data Centres"). Enumerate the whole schedule, not just the summary;
   it often spans many PDF pages or a downloadable XLSX. **Do NOT treat the report as a
   replacement for the website list — even if prior notes suggest a "report-first" approach for
   this issuer, still extract the website portfolio and combine both sets.**
5. **PDF / table extraction** — for facility or property tables in PDFs, use `pdfplumber`
   (or `camelot`) to pull tabular data; handle multi-page tables and repeated headers, then map
   columns to the output schema. Reference locations by filing type: 10-K → Item 2 "Properties";
   20-F → "Property, Plants and Equipment"; Japanese Yuho → the facilities table
   (主要な設備の状況). A scanned PDF may need OCR before tables are readable.

**Check count. If still short → proceed to Tier 4.**

---

### Tier 4 — Third-Party Sources: ENRICHMENT ONLY (never for inclusion)

Third-party sources may ONLY enrich attributes of an asset that ALREADY has a first-party or
second-party (official) URL covering it. They can NEVER be the basis for including an asset.

Use them to sharpen detail (complete an address, add coordinates or a contact number) or to help
LOCATE an official page — not to add assets no official (1P/2P) source mentions:
1. Company LinkedIn page -> "Locations" tab
2. OpenStreetMap / Google Maps confirmed business listings
3. Bloomberg, Capital IQ, Orbis company profiles
4. News: press releases announcing new facilities, openings, relocations
5. Job portals (Zhaopin, Naukri, LinkedIn Jobs, Indeed) — postings list work locations
6. Sector-specific registries — central-bank branch lists, FDA facility register, etc.
   (a central-bank / regulator registry is SECOND-party official evidence, not third-party)

**Provenance rule (from prompt.md §5g):**
- Keep an asset ONLY if a first-party (company website/document/report) or second-party
  (official / legal / regulator / exchange filing) URL covers or mentions it. Put that official
  URL in `RELEVANT_URL` and its type in `SOURCE_TYPE` (1P/2P values only).
- When a third-party page supplied enrichment, record it in `VALIDATION_URL` and set
  `VALIDATION_SOURCE_TYPE = "Third party - <subtype>"` (e.g. `Third party - News`).
- An asset attested ONLY by a third-party source (no 1P/2P coverage) is NOT exported — drop it and
  note it in the run summary. This is stricter than the old "cross-validate the entity" rule: the
  official source must cover the ASSET, not merely confirm the company exists.

**Check count. If still short → proceed to Tier 5.**

---

### Tier 5 — JS/Anti-Bot Recovery

If any URL was skipped or failed due to JS rendering or anti-bot protection:
- Playwright with `channel='msedge'`, `navigator.webdriver = undefined`
- Cookie consent removal: `page.evaluate('document.getElementById("cmpbox")?.remove()')`
- For CORS-restricted APIs: `page.evaluate()` to execute fetch inside browser context
- For CSRF-protected endpoints: click-based interception
- Try from different network path if corporate proxy suspected
- Vary User-Agent, add realistic delays between requests

**Check count. If still short after Tier 5 → declare gap.**

---

### Gap Declaration

Only reachable after ALL applicable tiers are genuinely exhausted.

> ⚠️ **A GAP DECLARATION DOES NOT MEAN A SMALL CSV.** Declaring a gap means the sources do not
> cover the FULL universe — it does not license discarding what you did find. Still write the
> complete de-duplicated UNION of every real row gathered across all tiers to the staging CSV.
> The gap is recorded in the proof JSON (target vs achieved), NOT by shrinking the output.

Write `{PROOF_DIR}\{ISSUER_ID}_exhaustion_proof.json`:
```json
{
  "issuer_id": "{ISSUER_ID}",
  "issuer_name": "{ISSUER_NAME}",
  "pass_type": "{PASS_TYPE}",
  "target_count": {N},
  "achieved_count": {N},
  "gap": {N},
  "tiers_attempted": {
    "tier1": {"attempted": true, "outcome": "...", "urls_tried": N, "rows_found": N},
    "tier2": {"attempted": true, "outcome": "...", "pages_checked": N, "rows_found": N},
    "tier3": {"attempted": true, "outcome": "...", "sources_checked": [...], "rows_found": N},
    "tier4": {"attempted": true, "outcome": "...", "sources_tried": [...], "rows_found": N},
    "tier5": {"attempted": true, "outcome": "...", "techniques_tried": [...], "rows_found": N}
  },
  "root_cause": "...",
  "business_summary": "...",
  "recommendation": "..."
}
```

> ⚠️ **The DONE.flag cannot be written until this proof file exists.**
> A worker that writes DONE.flag without an exhaustion proof file is non-compliant.
> The orchestrator will reject completion and re-queue the issuer.

**Also populate GAP_DIR for human-in-the-loop review:**
For every gap issuer, create `{GAP_DIR}\{ISSUER_ID}_{ISSUER_NAME}\` containing:
1. `exhaustion_proof.json` — a copy of the proof file written above
2. `gap_analysis.md` — human-readable summary so a person can direct next steps:
   ```markdown
   # Gap Analysis — {ISSUER_NAME} ({ISSUER_ID})
   Target: {COUNT} | Achieved: {N} | Gap: {N}
   Pass: {PASS_TYPE} | Date: {YYYY-MM-DD}

   ## Tiers Attempted
   [bullet list of each tier, what was tried, what was found]

   ## Root Cause
   [why the gap exists — 2-3 sentences]

   ## Business Summary
   [plain-English: what kind of company, what facilities exist, why hard to extract]

   ## URLs Tried
   [list each URL with outcome]

   ## Recommendation for Human
   [specific next step — e.g. "needs paid Bloomberg access", "locator requires
    login credentials", "facility list only in a non-machine-readable PDF appendix"]
   ```
3. Any partial CSV extracted (copy from staging) — so a human sees what WAS found
4. Any page snapshots/screenshots the worker flagged as needing human judgement

This consolidates everything a human needs to make a judgement call in one folder,
rather than requiring them to hunt through per-issuer subfolders and proof files.

---

## PHASE W-2 — POST-EXTRACTION

### Step W-2a — Data Validation and QA

Follow prompt.md §5f fully:
- Structural checks: all mandatory columns non-blank
- Enum check: coord_source exactly `website` or `Not from website`
- Semantic validators: city checks, activity contamination, address junk
- Tier A/B/C rectification
- QA spot-check (correct sample size — see prompt.md §5f)

**Quality floor — never emit placeholder rows.** A row must carry at least one real locator:
a `FACILITY_NAME`, a `FACILITY_ADDRESS` (native or latin), OR `LATITUDE`+`LONGITUDE`. A row
that has only a country/city and no name, no address, and no coordinates is padding (the same
city-centroid failure mode we reject in vendor data) — drop it, do not ship it to staging.

### Step W-2b — Provenance, ownership & scope (prompt.md §5g + SCOPE_METHODOLOGY.md)

Apply to every row BEFORE writing the CSV:
1. **Provenance:** keep a row only if a first-party or second-party (official) URL covers/mentions
   the asset — that URL goes in `RELEVANT_URL`, its type in `SOURCE_TYPE` (1P/2P only). If a
   third-party page supplied enrichment, record it in `VALIDATION_URL` +
   `VALIDATION_SOURCE_TYPE = "Third party - <subtype>"`. Drop any asset with ONLY third-party
   coverage (log it in the run summary).
2. **Ownership:** read the scope methodology — default `SCOPE_METHODOLOGY.md`, or the
   `SCOPE_METHODOLOGY` override path/URL if the task/queue provides one. DROP assets that clearly
   belong to an unrelated third party mentioned on the page (registrar, auditor, supplier,
   customer, non-issuer landlord); if ownership is genuinely uncertain, KEEP and set
   `QA_flag = ownership_unverified`.
3. **Scope:** tag every kept row `SCOPE = In-Scope` / `Out-of-Scope` with
   `SCOPE_REASON = "<bucket phrase>: <free text>"` from the methodology's bucket list. Out-of-scope
   rows STAY in the CSV (labelled), they are not dropped. `SCOPE`/`SCOPE_REASON` are never blank.

**Rejected rows (Tier C) — write to REJECT_DIR:**
If this issuer had ANY rejected rows, write them to:
`{REJECT_DIR}\{ISSUER_ID}_{ISSUER_NAME}_rejected.csv`
Include all standard columns plus:
- `rejection_reason` — why the row was rejected (1 phrase)
- `rejected_by` — set to `worker_qa` (orchestrator scrub appends its own rows later tagged `orchestrator_scrub`)
If zero rows were rejected, do not create a reject file for this issuer.

### Step W-2b — Write to Staging

Write the validated CSV to `{STAGING_DIR}\{ISSUER_ID}_{ISSUER_NAME}.csv`.
Do NOT write directly to BATCH_OUTPUT — the orchestrator promotes from staging.

### Step W-2c — Script Classification and KB Draft

1. Classify every script written (Category A/B/C — prompt.md §7)
2. Save Category A and B scripts to MEMORY_FOLDER
3. Create KB draft: `{BATCH_TEMP}\{ISSUER_ID}_{ISSUER_NAME}\KB_APPEND_{ISSUER_ID}_{YYYYMMDD}.md`
4. Include URL classification feedback block (if url_type_source = classifier)
5. Attempt KB auto-write (BATCH-KB-2 eligibility → BATCH-KB-3 lock protocol)

### Step W-2d — Audit Entry

Append to `{BATCH_TEMP}\batch_audit.jsonl` using `AUDIT_WRITE.lock`.
(Lock is shared with batch_qa.jsonl — bundle both appends in one lock window)

```json
{
  "worker_id": "{WORKER_ID}",
  "issuer_id": "{ISSUER_ID}",
  "issuer_name": "{ISSUER_NAME}",
  "pass_type": "{PASS_TYPE}",
  "issuer_source": "fresh|reused|normalized|mixed",
  "status": "met|exceeded|gap",
  "target_count": {N},
  "achieved_count": {N},
  "gap": {N},
  "start_time": "{YYYY-MM-DD HH:MM:SS}",
  "end_time": "{YYYY-MM-DD HH:MM:SS}",
  "duration_seconds": {N},
  "tiers_attempted": ["tier1","tier2",...],
  "highest_tier_reached": "tier{N}",
  "urls_attempted": {N},
  "urls_yielded_data": {N},
  "approach_rounds": {N},
  "pattern_used": "P-XX — {Pattern Name}",
  "prior_record_used": "R-XX — {Company}|null",
  "script_reused": "{script_name.py}|null",
  "new_script_saved": "{script_name.py} Category {A/B/C}|null",
  "kb_entry": "auto-written|pending_guidance|skipped",
  "kb_record": "R-XX|null",
  "kb_impact": "helped|no_effect|hindered",
  "kb_impact_reason": "{1 sentence}",
  "sources_yielded_data": ["{url1}"],
  "validation_url_used": false,
  "gap_root_cause": "...|null",
  "gap_recommendation": "...|null",
  "exhaustion_proof_written": true,
  "qa_rows_inspected": {N},
  "qa_rows_total": {N},
  "qa_clean": {N},
  "qa_tier_a_fixed": {N},
  "qa_tier_b_flagged": {N},
  "qa_tier_c_rejected": {N},
  "qa_full_page_scraper": false
}
```

---

## PHASE W-3 — COMPLETION

### Step W-3a — Record Issuer Summary (to disk / worker context, NOT relayed to main UI)

> ⚠️ **Do NOT require this summary to surface in the orchestrator's chat.**
> A worker is a spawned subagent. For its output to appear in the main conversation, the
> orchestrator would have to actively read and relay it for every issuer — and that
> per-issuer narration is what destroys long-run autonomy (it floods the orchestrator's
> turn with output and exhausts the turn budget, ending the conversation early).
>
> Instead: the worker records its summary in its own output and to a per-issuer file on
> disk. The orchestrator's monitoring loop stays quiet — it promotes CSVs and refills slots
> silently, emitting only the lightweight aggregate [MONITOR] heartbeat. Per-issuer detail
> lives in `batch_audit.jsonl`, the worker's record, and (for gaps) GAP_DIR — available
> whenever needed, without forcing live narration.

Write the issuer summary to `{BATCH_TEMP}\{ISSUER_ID}_{ISSUER_NAME}\issuer_summary.txt`
(the worker's own subfolder). The orchestrator does NOT need to read or relay this.

**If met/exceeded:**
```
✅ [{WORKER_ID}] {ISSUER_NAME} ({ISSUER_ID})
   {achieved}/{target} | {duration} | highest tier: {N} | {approach_rounds} rounds
   P-XX | {script} | KB: {R-XX ✅/⚠️}
```

**If gap:**
```
╔════════════════════════════════════════════════════╗
║  [{WORKER_ID}] GAP — {ISSUER_NAME} ({ISSUER_ID})  ║
╚════════════════════════════════════════════════════╝
Target     : {COUNT}
Achieved   : {N}
Gap        : {N}
Duration   : {X} min
Tiers tried: {list}
Root cause : {summary}
Business   : {1-sentence plain English}
Next step  : {recommendation}
Proof file : {PROOF_DIR}\{ISSUER_ID}_exhaustion_proof.json ✅ written
Gap folder : {GAP_DIR}\{ISSUER_ID}_{ISSUER_NAME}\ ✅ populated
```

The worker may also print this in its own subagent transcript (that does not touch the
orchestrator's turn budget). The key rule: the orchestrator must not be required to
relay per-issuer summaries into the main conversation.

### Step W-3b — Write DONE Flag (atomic)

Write to a temp file first, then rename (atomic operation):

```python
import os, tempfile
tmp = f"{STATUS_DIR}/{ISSUER_ID}_DONE.tmp"
final = f"{STATUS_DIR}/{ISSUER_ID}_DONE.flag"
with open(tmp, "w") as f:
    f.write(f"WORKER_ID={WORKER_ID}\n"
            f"ISSUER_ID={ISSUER_ID}\n"
            f"FINISHED={datetime}\n"
            f"STATUS={status}\n"
            f"ACHIEVED={achieved_count}\n"
            f"TARGET={target_count}\n"
            f"PASS_TYPE={PASS_TYPE}\n"
            f"EXHAUSTION_PROOF={proof_written}\n"
            f"BATCH_ID={BATCH_ID}\n")
os.rename(tmp, final)  # atomic on all major filesystems
```

> ⚠️ **DONE.flag prerequisites — ALL must be true before writing:**
> - [ ] Exhaustion proof JSON written to PROOF_DIR
> - [ ] Validated CSV written to STAGING_DIR
> - [ ] Audit entry appended to batch_audit.jsonl
> - [ ] QA entry appended to batch_qa.jsonl
> - [ ] KB draft written (or documented as not applicable)
>
> A DONE.flag written without meeting all prerequisites is invalid.
> The orchestrator checks for the exhaustion proof file and will reject
> and re-queue any completion that lacks it.

Remove the RUNNING.flag after the DONE.flag is written:
```python
os.remove(f"{STATUS_DIR}/{ISSUER_ID}_RUNNING.flag")
```

---

## WORKER QUALITY CHECKLIST

**Setup**
- [ ] Worker declaration output with model and reasoning tier confirmed
- [ ] RUNNING.flag written (atomic: tmp → rename)
- [ ] Model and reasoning match queue file (no downgrade)
- [ ] Full KB CHECK block output (not abbreviated)
- [ ] Issue context output with URL list

**Extraction**
- [ ] Approach ladder followed in tier order
- [ ] Count checked after each tier
- [ ] Continued scanning after COUNT met (did not stop at exactly COUNT)
- [ ] All applicable tiers attempted before declaring gap
- [ ] Rework workers: Tiers 1 and 2 skipped per SKIP_TIERS

**Gap Declaration**
- [ ] Exhaustion proof JSON written to PROOF_DIR before DONE.flag
- [ ] Proof covers all attempted tiers with outcomes and row counts
- [ ] GAP_DIR folder populated (proof copy + gap_analysis.md + partial CSV) for human review

**Post-Extraction**
- [ ] Full data validation and QA run (prompt.md §5f)
- [ ] QA spot-check with correct sample size
- [ ] Validated CSV written to STAGING_DIR (not BATCH_OUTPUT directly)
- [ ] Rejected rows written to REJECT_DIR (if any) with rejection_reason + rejected_by

**Scripts and KB**
- [ ] All scripts classified A/B/C
- [ ] A and B scripts saved to Memory Folder
- [ ] KB read at start picked up learnings from workers that finished earlier
- [ ] KB draft written
- [ ] URL classifier feedback block included (if applicable)
- [ ] KB auto-write APPENDS onto current KB (never overwrites); atomic temp→rename used
- [ ] KB auto-write attempted (BATCH-KB-2 checks + lock)

**Per-Issuer Summary (to disk, not relayed to main UI)**
- [ ] Issuer summary written to the worker's subfolder (issuer_summary.txt)
- [ ] Summary NOT required to surface in orchestrator chat (preserves long-run autonomy)

**Audit**
- [ ] Audit entry appended to batch_audit.jsonl (AUDIT_WRITE.lock)
- [ ] QA entry appended to batch_qa.jsonl (same lock window)
- [ ] pass_type, tiers_attempted, highest_tier_reached, approach_rounds all populated
- [ ] exhaustion_proof_written = true in audit entry

**Completion**
- [ ] Summary output (✅ one-liner or full GAP block)
- [ ] DONE.flag written atomically (tmp → rename)
- [ ] RUNNING.flag removed after DONE.flag written
