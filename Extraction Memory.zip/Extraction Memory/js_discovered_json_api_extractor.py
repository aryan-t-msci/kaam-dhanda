"""
Generic extractor for public JSON APIs discovered from front-end JavaScript.

Use this when the visible page is mostly a shell, but the site's own JS reveals
an open JSON endpoint that returns a list of store / office / facility records.

How to adapt for a new issuer:
1. Set PAGE_URL and API_URL in the configuration block.
2. Add browser-like headers if the endpoint expects Referer / Origin.
3. Set LIST_PATH to the array inside the JSON response.
4. Map JSON fields to the standard output columns in FIELD_MAP.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Any

import requests


# ============================================================
# CONFIGURATION - edit this block for each new issuer
# ============================================================
ISSUER_ID = "IID000000000000000"
ISSUER_NAME = "COMPANY NAME"
PAGE_URL = "https://www.example.com/support/store"
API_URL = "https://api.example.com/open/api/stores"
OUTPUT_CSV = Path("output.csv")

HEADERS = {
    "User-Agent": "Mozilla/5.0",
    "Referer": PAGE_URL,
    "Origin": "https://www.example.com",
}

LIST_PATH = "data"
SOURCE_TYPE = "COMPANY WEBSITE"

FIELD_MAP = {
    "LOCATION_NAME": "name",
    "LOCATION_ADDRESS": "address",
    "LATITUDE": "lat",
    "LONGITUDE": "lng",
    "COUNTRY": "countryName",
    "COUNTRY_ISO3": "countryIso3",
    "POSTCODE": "postcode",
    "STATE": "provinceName",
    "CITY": "cityName",
    "ACTIVITY_AT_ASSET": "type",
}

CONSTANT_FIELDS = {
    "SOURCE_URL": API_URL,
    "SOURCE_TYPE": SOURCE_TYPE,
}

VERIFY_SSL = True
TIMEOUT_SECONDS = 30


# ============================================================
# GENERIC EXTRACTION LOGIC - do not modify per issuer
# ============================================================
OUTPUT_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
]


def get_in(obj: Any, path: str, default: Any = "") -> Any:
    current = obj
    for part in path.split("."):
        if isinstance(current, dict):
            current = current.get(part, default)
        else:
            return default
    return current


def normalize(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def extract_list(payload: Any, list_path: str) -> list[dict]:
    if not list_path:
        return payload if isinstance(payload, list) else []
    result = get_in(payload, list_path, [])
    return result if isinstance(result, list) else []


def build_rows(items: list[dict]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for item in items:
        row = {col: "" for col in OUTPUT_COLUMNS}
        row["ISSUER_ID"] = ISSUER_ID
        row["ISSUER_NAME"] = ISSUER_NAME
        for out_col, path in FIELD_MAP.items():
            row[out_col] = normalize(get_in(item, path, ""))
        for out_col, value in CONSTANT_FIELDS.items():
            row[out_col] = normalize(value)
        row["coord_source"] = "website" if row["LATITUDE"] and row["LONGITUDE"] else "Not from website"
        rows.append(row)
    return rows


def fetch_payload() -> Any:
    response = requests.get(
        API_URL,
        headers=HEADERS,
        timeout=TIMEOUT_SECONDS,
        verify=VERIFY_SSL,
    )
    response.raise_for_status()
    return response.json()


def write_csv(rows: list[dict[str, str]]) -> None:
    OUTPUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT_CSV.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=OUTPUT_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    payload = fetch_payload()
    items = extract_list(payload, LIST_PATH)
    rows = build_rows(items)
    write_csv(rows)
    print(f"Wrote {len(rows)} rows to {OUTPUT_CSV}")


if __name__ == "__main__":
    main()
