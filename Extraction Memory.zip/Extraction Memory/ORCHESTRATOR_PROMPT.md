# Extraction Orchestrator — Parent Agent Instructions
# Version: 2.0 | Last Updated: 2026-05-04
#
# HOW TO USE:
#   Fill in the PARAMETERS section and send this entire file to the agent.
#   The conversation that receives it IS the orchestrator and runs everything
#   itself — it must NOT spawn a sub-agent to act as the orchestrator (see the
#   directive at the top of the file body). It handles everything autonomously.
#
# ARCHITECTURE (v2.0 — one worker per issuer):
#   Each worker is a fully isolated single-issuer conversation. It has no
#   knowledge of other workers and no queue to manage — its sole job is to
#   extract one company as completely as possible. The orchestrator manages
#   a rolling pool, spawning new single-issuer workers as slots free up.
#   After the main pass, gap issuers automatically enter a rework pass.
#
# AGENT CAP NOTE:
#   The orchestrator probes for the actual simultaneous agent cap at runtime
#   by attempting 20 → 15 → 10 → 6. The confirmed cap is stored as SESSION_CAP.
#   One slot is always reserved for the orchestrator (WORKER_CAP = SESSION_CAP - 1)
#   so it stays responsive and avoids transient spawn failures at the platform ceiling.
#   As of May 2026 on Codex Desktop the observed cap was 6 (so WORKER_CAP = 5).
#   If the platform cap increases in future versions, the probe discovers it automatically.
#
# MODEL INHERITANCE:
#   Every worker queue file must include the orchestrator's model and reasoning tier.
#   Workers MUST run at the same settings as the orchestrator. A worker spawned at
#   a lower reasoning tier is a known failure mode — explicitly prohibited.

---

> ════════════════════════════════════════════════════════════════════════
> ⚠️ **YOU ARE THE ORCHESTRATOR. DO NOT DELEGATE THIS ROLE. READ THIS FIRST.**
> ════════════════════════════════════════════════════════════════════════
>
> The conversation reading this file **IS** the orchestrator. You must execute the
> orchestration workflow **yourself, directly, in this conversation**.
>
> **DO NOT spawn a sub-agent to "run the orchestrator" or to "execute ORCHESTRATOR_PROMPT".**
> "Execute these files" means **you** carry out the steps — it does NOT mean spawn an
> agent that carries them out. Delegating the orchestrator role into a sub-agent pushes
> it one level too deep, and that nested agent will fail to spawn workers (a known failure:
> the run hard-blocks after setup with "no autonomous worker-spawn capability"). That is
> caused by this exact mistake, not by a platform limit.
>
> **The ONLY agents you ever spawn are:**
> 1. The URL classifier (one transient agent, Phase O-0d, Format B only), and
> 2. The per-issuer workers (the rolling pool).
>
> You never spawn an agent to be the orchestrator. You ARE it. If you catch yourself about
> to "spawn 1 agent" to run this workflow, STOP — instead, begin executing Phase O-R / O-0
> yourself in this conversation right now.
>
> ════════════════════════════════════════════════════════════════════════

From MEMORY_FOLDER, read and execute these files in order:
1. prompt.md — standing rules for all extraction tasks
2. ORCHESTRATOR_PROMPT.md — this file (already loaded)

Then execute the orchestration workflow below **yourself, in this conversation** —
do not delegate it to a spawned agent.

---

## PARAMETERS

```
MEMORY_FOLDER : <path to your Extraction Memory folder>
INPUT_FILE    : <path to your input xlsx file>
TEMP_FOLDER   : <path to your Temp folder>
OUTPUT_FOLDER : <path to your Output folder>
SCOPE_METHODOLOGY : <optional: path or URL to an updated scope/ownership methodology; leave blank to use SCOPE_METHODOLOGY.md in MEMORY_FOLDER>
```

---

## EXECUTION MODE DECLARATION

Output this block immediately before any work begins:

```
╔══════════════════════════════════════════════════════════════╗
║  EXECUTION MODE DECLARATION                                  ║
╚══════════════════════════════════════════════════════════════╝
Mode              : multi-agent (one worker per issuer)
Orchestrator      : this conversation
Model             : {detected model name}
Reasoning tier    : {detected reasoning tier}
Session cap       : probing in Phase O-1a
Worker type       : spawned subagent (Codex Desktop autonomous spawn)
Parallelism       : true — workers execute concurrently as independent agents
Declared at       : {YYYY-MM-DD HH:MM:SS}
```

> ⚠️ **AUTONOMY DIRECTIVE (applies to the entire run):**
> This is a fully autonomous batch. Once started, run end-to-end without pausing for
> user input. Do NOT present "Next Steps" menus, do NOT offer "continue or stop here"
> choices, do NOT ask "should I proceed?" at phase boundaries, and do NOT end your turn
> with a final-style summary while work remains. Status updates are informational only —
> print them and immediately keep working. The only legitimate reasons to surface and
> wait are: (a) a genuine escalation flag needing human judgement, or (b) true completion
> of the entire run (main pass + rework pass). At every other decision point — between
> phases, after the cap probe, after classification, during monitoring, when refilling
> slots, when starting rework — proceed automatically. If the platform interrupts your
> turn, resume and continue; never volunteer a stop yourself.
>
> **KEEP THE LOOP QUIET.** Do not narrate individual issuer completions in chat. Workers
> are subagents; relaying each worker's summary into this conversation for every issuer
> floods the turn and exhausts the platform turn budget — that is the single biggest cause
> of a long run ending early and needing manual re-prompting. Promote and refill silently;
> emit only the periodic aggregate [MONITOR] heartbeat. Per-issuer detail is on disk.
>
> **TWO HARD RULES that keep this fast (both detailed later, stated here so they're not
> missed):**
> 1. **Fresh agent per issuer — never reuse worker threads.** Each issuer gets a brand-new
>    spawned agent that does one issuer and is then closed. A freed slot is filled by
>    spawning a NEW agent, never by reviving/recycling/reattaching a finished one. Do not
>    maintain a pool of long-lived reusable threads — that blocks lanes and destroys
>    parallelism.
> 2. **Within a turn run the loop LIVE; bridge turn boundaries with ONE dynamic-interval
>    resume automation.** The platform ends turns on long runs (Desktop AND CLI) — you
>    cannot prevent that. So while a turn is alive, promote/refill the instant each worker
>    finishes (fast, live). To carry the run across turn boundaries hands-off, create a
>    single resume automation whose only job is to re-prompt this thread to run Phase O-R
>    and continue. Its interval is DYNAMIC: longer (~15 min) early when heavy issuers run
>    slowly, shorter (~3–5 min) late when light issuers turn over fast. The automation
>    bridges turns; it does NOT change the work model (still fresh agent per issuer, still
>    event-driven within each turn, never thread reuse). Delete it at full completion/stop.

---

## PHASE O-R — RESUME CHECK (run FIRST, on every turn)

> ⚠️ **This phase runs at the very start of EVERY orchestrator turn — first turn and
> every resumed turn alike.** Long batches (hundreds of issuers) will span multiple turns
> because the platform ends a turn when it hits its length limit. The monitoring loop lives
> in the orchestrator's active turn, so when a turn ends, promotion and slot-refill stop
> even though the workers keep running. This phase makes resumption automatic and lossless.
>
> **This is the resume entry point used both on a fresh start and on every automation-
> triggered resume.** Normal in-turn operation is the live event-driven loop in Phase O-2.
> Because the platform ends turns on long runs, a single dynamic-interval resume automation
> (see Phase O-2) re-prompts this thread across turn boundaries; each time it fires, you run
> this phase once to reconstruct from disk, then return to the live loop. The automation only
> re-wakes the thread — it does not change the work model (fresh agent per issuer,
> event-driven within each turn, no thread reuse).

**Step O-R-0 — Detect whether a batch is already in progress.**

Before doing anything else, check whether a batch workspace already exists for this task:
- Look in `TEMP_FOLDER` for an existing `Extraction_Batch_{INPUT_NAME}_*` folder matching
  this INPUT_FILE (most recent if several).
- If found AND it contains a `batch_manifest.json` → **a batch is in progress. RESUME it.**
  Do NOT create a new batch folder. Do NOT re-run setup. Skip to Step O-R-1.
- If none found → this is a fresh start. Proceed to Phase O-0 normally.

Output one line:
```
[RESUME] {No prior batch found — starting fresh | Resuming batch {BATCH_ID} from disk state}
```

**Step O-R-1 — Reconstruct state from disk (resume only).**

Read ground truth from the existing batch folder — never rely on in-conversation memory,
which is gone after a turn boundary:

1. Read `batch_manifest.json` → full issuer queue and order.
2. Scan `status/` for `{ISSUER_ID}_DONE.flag` files → the set of completed issuers.
3. Scan `status/` for `{ISSUER_ID}_RUNNING.flag` files with no matching DONE flag →
   workers believed still active.
4. List `BATCH_OUTPUT` CSVs → the set of issuers already promoted.
5. Read `batch_audit.jsonl` → per-issuer results already recorded.

Compute:
```
completed   = issuers with DONE.flag
promoted    = issuers with a CSV in BATCH_OUTPUT
unpromoted  = completed - promoted          ← stragglers needing promotion NOW
active      = RUNNING.flag without DONE.flag
queued      = manifest queue - completed - active
gap_list    = completed issuers whose audit status = gap
```

Output:
```
[RESUME] State reconstructed:
  Completed   : {N}/{total}
  Promoted    : {N}   | Unpromoted stragglers: {N}
  Active       : {N} workers ({list})
  Queued       : {N} remaining
  Gap (rework) : {N} accumulated
```

**Step O-R-2 — Heal before continuing.**

1. **Promote all unpromoted stragglers immediately** — run Step O-1c staging validation +
   promotion for every issuer in `unpromoted`. This clears the backlog that accumulated
   while the previous turn was dead.
2. **Clear stale flags** — remove any `probe_*_ALIVE.flag` and any `RUNNING.flag` whose
   worker is no longer alive (DONE flag exists, or worker was lost). Atomic deletes.
3. **Re-establish the pool** — if `active < WORKER_CAP` and `queued` is non-empty, spawn
   new workers (Step O-1b) until active = WORKER_CAP or the queue empties.

Then continue into the normal monitoring loop (Phase O-2). If the main pass is already
complete (queue empty, no active workers), skip to Phase O-3 / O-4 as appropriate based
on what has and hasn't been done yet (also reconstructable from disk).

---

## PHASE O-0 — SETUP

> Phase O-0 runs only on a fresh start (Phase O-R found no batch in progress).

### Step O-0 — Ensure the knowledge base is sharded (do this first; self-skipping)

Make sure the KB is in per-record shard form before spawning anything. Run, once:

    python "{MEMORY_FOLDER}/Tools/shard_kb.py"

This splits `KB_DETAIL.md` into `KB/<id>.md` shards so each worker opens only the 1-2 records it
needs (via `KB_INDEX.md`) instead of the ~91K-token monolith. The tool **self-skips** when `KB/`
already holds record shards — from then on the workers maintain `KB/` directly (each new learned
record is written straight into `KB/`, never into the now-frozen monolith), so on every run after
the first this is a harmless no-op. Do NOT pass `--force`: it wipes and regenerates `KB/` from the
monolith and would drop any record the monolith does not contain.

### Step O-0a — Detect Model and Reasoning Tier

Identify the model and reasoning tier this orchestrator conversation is running on.
Record as `ORCHESTRATOR_MODEL` and `ORCHESTRATOR_REASONING`.
Every worker MUST run on the **identical model and reasoning** as this orchestrator —
never a lower or different tier.

**If the runtime exposes a concrete model/reasoning identifier** (e.g. Codex CLI or the
app surfaces it), capture the exact values and write them into every worker queue file.

**If the runtime does NOT expose a concrete identifier** (it may only report "current
session" with no name), then:
- Record `ORCHESTRATOR_MODEL = "inherit-session-default"` and
  `ORCHESTRATOR_REASONING = "inherit-session-default"` as a SIGNAL — this is an instruction
  to inherit, not a literal model name.
- Spawn every worker so it runs on the **exact same model and reasoning this orchestrator is
  currently using** — match it precisely, whatever it is. If the orchestrator is on medium,
  workers are on medium. If high, workers are high. If low, workers are low. The worker tier
  must EQUAL the orchestrator tier — neither higher nor lower.
- Do NOT pick a tier for workers based on what seems "safe" or "better." Do NOT default to
  "high." Do NOT avoid "medium." There is exactly one correct tier for a worker: the same
  one the orchestrator is running on. If you cannot read the orchestrator's tier explicitly,
  spawn the worker with no tier override so it inherits the session default (which is the
  orchestrator's tier) — never with an explicit tier that might differ.

```
[MODEL] Orchestrator: {ORCHESTRATOR_MODEL} | reasoning: {ORCHESTRATOR_REASONING}
        Workers run on the EXACT SAME model + reasoning as this orchestrator — matched,
        not higher, not lower. If the orchestrator is on medium, workers are on medium.
        (If the runtime hides the concrete name, spawn with no override so workers inherit
         the orchestrator's session tier — never an explicit different tier.)
```

### Step O-0b — Create Batch Infrastructure

Generate timestamp: `YYYYMMDD_HHMMSS`.
Derive `INPUT_NAME` = input file name without extension (e.g. "April2026").
The batch folder name embeds both INPUT_NAME and timestamp for uniqueness.

```
{TEMP_FOLDER}\Extraction_Batch_{INPUT_NAME}_{TIMESTAMP}\
    ├── workers\           ← one queue file per issuer (written just-in-time as slots fill)
    ├── staging\           ← workers write CSV here; orchestrator validates + promotes
    ├── status\            ← {ISSUER_ID}_RUNNING.flag / _DONE.flag / _ESCALATION.flag
    ├── exhaustion_proof\  ← {ISSUER_ID}_exhaustion_proof.json (required before DONE.flag)
    ├── reject\            ← all rejected records, per issuer (see below)
    ├── gap\               ← human-in-the-loop material for gap issuers (see below)
    ├── batch_audit.jsonl
    ├── batch_qa.jsonl
    ├── batch_manifest.json
    └── orchestrator_log.jsonl

{OUTPUT_FOLDER}\Extraction_Batch_{INPUT_NAME}_{TIMESTAMP}\
    └── [promoted CSVs — clean, validated, deduplicated]
```

Reference as: `BATCH_TEMP`, `BATCH_OUTPUT`, `WORKER_DIR`, `STAGING_DIR`,
`STATUS_DIR`, `PROOF_DIR`, `REJECT_DIR`, `GAP_DIR`.

**REJECT_DIR (`{BATCH_TEMP}\reject\`):**
Every issuer that had ANY records rejected — by worker QA (Tier C) or by the
orchestrator's staging scrub — gets a file here:
`{REJECT_DIR}\{ISSUER_ID}_{ISSUER_NAME}_rejected.csv`
This consolidates all rejected rows for that issuer in one place, with a
`rejection_reason` column and a `rejected_by` column (worker_qa | orchestrator_scrub).
Issuers with zero rejections get no file here.

**GAP_DIR (`{BATCH_TEMP}\gap\`):**
For every gap issuer, all human-in-the-loop material is collected here so a person
can review and direct next steps without hunting through subfolders:
`{GAP_DIR}\{ISSUER_ID}_{ISSUER_NAME}\`
  - `exhaustion_proof.json` (copied from PROOF_DIR)
  - `gap_analysis.md` — human-readable: target, achieved, tiers attempted, root cause,
    business summary, specific recommendation, and the URLs that were tried
  - any partial CSV extracted (so a human can see what WAS found)
  - any screenshots / page snapshots the worker flagged as needing human judgement

Create `batch_audit.jsonl` and `batch_qa.jsonl` with header lines (include `#` skip notation):
```
# batch_audit.jsonl | Batch: Extraction_Batch_{INPUT_NAME}_{TIMESTAMP} | Started: {datetime}
# batch_qa.jsonl    | Batch: Extraction_Batch_{INPUT_NAME}_{TIMESTAMP} | Started: {datetime}
```

### Step O-0c — Validate and Parse Input File

**Pre-validation before any parsing:**
1. Read all rows. Exclude any row where ISSUER_ID does not start with "IID":
   - Blank ISSUER_ID → exclude
   - "TOTAL", "Grand Total", summary labels → exclude
   - Any non-IID value → exclude
   Log each exclusion:
   ```
   [PREVALIDATION] Excluded: "{value}" — {reason}
   ```
2. Report before spawning anything:
   ```
   [PREVALIDATION] Complete
     Rows read              : {N}
     Non-issuer rows excluded: {N}
     Real issuers to process : {N}
     Real target count       : {N} facilities
   ```

**Format detection and parsing:**
- Format A (1 sheet): `ISSUER_ID`, `ISSUER_NAME`, `COUNT` per URL, `URL`, optional `URL_Type`
  → COUNT per issuer = sum of all URL-level COUNT values
- Format B (2+ sheets): Sheet 1 = issuer counts, Sheet 2 = URLs
  → COUNT = Sheet 1 value as-is (already issuer-level, do NOT sum)
- Fuzzy-match column names if they differ from expected

Per issuer derive: `ISSUER_ID`, `ISSUER_NAME`, `COUNT`, `URLS` (deduplicated),
`URL_TYPES`, `URL_PURPOSES`.

**Input File Summary — output this block after parsing (before the queue is built):**

Compute and report each of the following. If a value cannot be determined from the
input file (column absent, etc.), state "not available in input file" rather than guessing.

```
═══════════════════════════════════════════════════════════
INPUT FILE SUMMARY — {input file name}
═══════════════════════════════════════════════════════════
Format detected             : {A — single sheet | B — two sheets}
Total issuer rows           : {N}        (raw rows in the issuer list / Sheet 1)
Total unique issuers        : {N}        (distinct ISSUER_ID after excluding non-IID rows)
  Duplicate issuer IDs      : {N if any, else "none"}
Total URLs                  : {N}        (all URL rows across the file / Sheet 2)
Total unique URLs           : {N}        (distinct URLs after dedup)
  Duplicate URLs removed    : {N if any, else "none"}
Total expected asset count  : {N}        (sum of COUNT across unique issuers)
  Count source              : {Format A — summed per-URL | Format B — issuer-level}
Non-issuer rows excluded    : {N}        (TOTAL / blank / non-IID — see prevalidation log)
═══════════════════════════════════════════════════════════
```

Notes on each metric:
- **Total issuer rows** vs **Total unique issuers**: if the same ISSUER_ID appears on
  multiple rows (Format A with multiple URLs, or accidental duplication), these differ.
  Report both so any duplication is visible.
- **Total URLs** vs **Total unique URLs**: the same URL may be listed for an issuer more
  than once, or across issuers. Report both.
- **Total expected asset count**: summed across *unique* issuers (never double-count a
  duplicated issuer row). If the COUNT/Expected Count column is missing entirely, state
  "expected asset count not available in input file".
- If any of these cannot be computed (e.g. no URL column at all), say so explicitly for
  that line rather than reporting 0.

### Step O-0d — URL Classification (Format B only)

If Format B detected, invoke `URL_CLASSIFIER_PROMPT.md` as a subagent.
Wait for `url_classification_DONE.flag`. Merge results.
Full protocol in `URL_CLASSIFIER_PROMPT.md`.

> ⚠️ **Slot release (important):** The URL classifier occupies one agent slot while
> it runs. The moment `url_classification_DONE.flag` appears and its output is merged,
> **explicitly close/terminate the classifier subagent** so its slot is released back
> to the pool. Do NOT carry a phantom "classifier still occupying a slot" assumption
> into the cap probe or rolling pool. After the classifier closes, the full SESSION_CAP
> is available for workers.
>
> Known failure mode (observed): the classifier finished but its slot was never reclaimed,
> so fewer workers ran for the rest of the batch. The cap probe in O-1a runs AFTER the
> classifier has closed, so it measures true available capacity — but the orchestrator
> must not leave the classifier subagent alive after merging its output.

### Step O-0e — Build Issuer Queue

Build a single flat ordered queue. Order: heaviest issuers first (by heavy_score).
```
heavy_score = heavy_URL_count / total_URL_count
heavy = URL_Type in [javascript_heavy, interactive_map, search_required, iframe_embedded]
```

Write `{BATCH_TEMP}\batch_manifest.json`:
```json
{
  "batch_id": "Extraction_Batch_{INPUT_NAME}_{TIMESTAMP}",
  "orchestrator_model": "{ORCHESTRATOR_MODEL}",
  "orchestrator_reasoning": "{ORCHESTRATOR_REASONING}",
  "total_issuers": {N},
  "total_target": {N},
  "architecture": "one_worker_per_issuer",
  "queue": [
    {
      "queue_position": 1,
      "issuer_id": "IID...",
      "issuer_name": "...",
      "count": N,
      "heavy_score": 0.x,
      "urls": [{"url": "...", "url_type": "...", "url_purpose": "...", "confidence": 0.x}]
    }
  ]
}
```

Output:
```
═══════════════════════════════════════════════════════════
BATCH MANIFEST — Extraction_Batch_{INPUT_NAME}_{TIMESTAMP}
═══════════════════════════════════════════════════════════
Architecture  : one worker per issuer (fully isolated)
Issuers queued: {N} (heaviest first)
Total target  : {N} facilities
Model         : {ORCHESTRATOR_MODEL} | {ORCHESTRATOR_REASONING}
Session cap   : probing now (Phase O-1a)
═══════════════════════════════════════════════════════════
```

---

## PHASE O-1 — CAP PROBE AND ROLLING POOL

### Step O-1a — Dynamic Cap Probe

Probe actual simultaneous agent cap by attempting decreasing counts: 20 → 15 → 10 → 6.

**Protocol:**
1. Attempt to spawn {probe_count} minimal placeholder agents.
   Each placeholder writes `{STATUS_DIR}\probe_{N}_ALIVE.flag` and exits immediately.
2. Count successful spawns within 30 seconds.
3. Whatever number successfully spawns = SESSION_CAP for this attempt.
4. If the full probe_count spawned: that IS the cap floor, stop probing.
5. If fewer spawned: the actual cap is the number that succeeded.
6. Try next level only if zero spawned.
7. If zero spawn at 6: SESSION_CAP = 1 (serial mode), log warning.

**Determine WORKER_CAP:**
```
WORKER_CAP = SESSION_CAP - 1   (reserve 1 slot for the orchestrator)
minimum WORKER_CAP = 1
```

The orchestrator must remain responsive (monitoring, promoting, spawning) while workers
run, and a spawn attempt can transiently fail when the platform is at its ceiling.
Reserving one slot gives the orchestrator headroom and avoids the "spawn N, one fails"
condition that occurs when trying to fill every available slot with workers.

Output:
```
[CAP PROBE] Attempting {N} agents → {N} spawned
[CAP PROBE] SESSION_CAP = {N} | WORKER_CAP = {N} (SESSION_CAP - 1, one slot reserved for orchestrator)
            Platform: Codex Desktop | Date: {date}
            Future runs on this platform: start probe at {SESSION_CAP}
```

Log:
```json
{"event": "cap_probe", "timestamp": "...", "session_cap": N,
 "worker_cap": N, "worker_cap_rule": "minus_one",
 "probe_sequence": [20, 15, 10, 6]}
```

### Step O-1b — Rolling Worker Pool (Main Pass)

> ════════════════════════════════════════════════════════════════════════
> ⚠️ **FRESH AGENT PER ISSUER — NEVER REUSE WORKER THREADS. READ THIS.**
> ════════════════════════════════════════════════════════════════════════
>
> Every worker is a **brand-new, single-use spawned agent that handles exactly ONE issuer
> and then terminates.** This is the core of the architecture and the reason it is fast.
>
> - When you need to fill a slot, **spawn a FRESH agent.** Over a 500-issuer run you will
>   spawn ~500+ agents in total (never more than WORKER_CAP alive at once). That is correct
>   and intended.
> - When a worker finishes its issuer, **close/terminate that agent.** Its slot is then
>   filled by spawning a NEW agent for the next issuer — NOT by reviving, reattaching,
>   recycling, or "archiving and reusing" the finished one.
> - **DO NOT maintain a small pool of long-lived background threads and reassign issuers
>   to them.** That pattern blocks lanes whenever a thread is still finalizing, destroys
>   parallelism, and is explicitly forbidden. One issuer = one fresh agent = one termination.
> - A finished worker's thread is never "reused when safe." It is closed. The next issuer
>   gets a clean new agent.
>
> If you find yourself tracking "reusable threads," "thread leases," or which background
> thread is "safe to recycle" — STOP. That is the wrong model. Spawn fresh, always.
> ════════════════════════════════════════════════════════════════════════

With `WORKER_CAP` known:

> ⚠️ **Fill ALL available slots.** At pool start, the URL classifier subagent (if used)
> has already been closed and its slot released. The full WORKER_CAP is available.
> Spawn exactly WORKER_CAP workers at start — do not under-fill by assuming a slot is
> still held by the classifier or any setup subagent. If SESSION_CAP is 6, WORKER_CAP is 5,
> so spawn 5 workers (the 6th slot is the orchestrator's reserved headroom). Re-verify the
> active worker count after the first spawn wave and top up to WORKER_CAP if any slot is
> unexpectedly empty.

1. Fill all `WORKER_CAP` slots by spawning a FRESH agent for each of the first issuers.
   Write a worker queue file for each and spawn immediately.
2. Monitor `STATUS_DIR` for `{ISSUER_ID}_DONE.flag` files.
3. When any worker completes:
   a. Read the worker's result from `batch_audit.jsonl` (latest entry for this ISSUER_ID)
   b. Run staging validation (Step O-1c)
   c. Promote clean CSV to `BATCH_OUTPUT`
   d. If result = gap → add to `rework_list`
   e. **Close/terminate the finished worker agent.**
   f. If queue not empty → **spawn a brand-new agent** for the next queued issuer in the
      freed slot immediately. Never revive the closed worker.
4. Continue until queue exhausted and all active workers done.

**Slot accounting check (every monitoring cycle):**
Verify active workers equals WORKER_CAP whenever the queue is non-empty.
If active_workers < WORKER_CAP and the queue still has issuers, a slot was
dropped — spawn the next queued issuer immediately to refill it. No slot should ever sit
idle while issuers remain in the queue.

**Worker queue file — written just-in-time when slot opens:**
```markdown
# Worker Queue — Single Issuer
# Batch: Extraction_Batch_{INPUT_NAME}_{TIMESTAMP}
# Generated: {datetime} | Pass: main

From MEMORY_FOLDER, read and execute:
1. prompt.md
2. WORKER_PROMPT.md

## PARAMETERS
ISSUER_ID     : {ISSUER_ID}
ISSUER_NAME   : {ISSUER_NAME}
COUNT         : {COUNT}
WORKER_ID     : {NN}
MODEL         : {ORCHESTRATOR_MODEL}
REASONING     : {ORCHESTRATOR_REASONING}
MEMORY_FOLDER : {MEMORY_FOLDER}
SCOPE_METHODOLOGY : {SCOPE_METHODOLOGY}
BATCH_TEMP    : {BATCH_TEMP}
BATCH_OUTPUT  : {BATCH_OUTPUT}
STAGING_DIR   : {STAGING_DIR}
STATUS_DIR    : {STATUS_DIR}
PROOF_DIR     : {PROOF_DIR}
REJECT_DIR    : {REJECT_DIR}
GAP_DIR       : {GAP_DIR}
BATCH_ID      : Extraction_Batch_{INPUT_NAME}_{TIMESTAMP}
PASS_TYPE     : main

## URLS
| URL | URL_Type | URL_Purpose | Confidence |
|-----|----------|-------------|------------|
| {url} | {type} | {purpose} | {score} |
```

**Rolling counter — output after every completion:**
```
[ROLLING] {done}/{total} complete | {active} active | {queued} queued |
          {rework_count} gap (rework pending) | continuing...
```

**Stalled worker detection:**
If any worker has been RUNNING for >45 min without a DONE flag:
- Log as stalled at 45 min, attempt to check status
- At 60 min: free the slot, add issuer to rework_list, spawn next queued issuer
- Log: `[STALL] {ISSUER_ID} stalled after 60 min → moved to rework queue`

### Step O-1c — Staging Validation and Promotion

Before promoting any worker's CSV from staging to output:

1. Read `{STAGING_DIR}\{ISSUER_ID}_{ISSUER_NAME}.csv`
2. Apply contamination checks:
   - CITY contains: currency ($£¥€), accounting (Net income, EBITDA, Common Stock,
     Revenue, Total, EPS), dates (FY\d\d, 20\d\d–20\d\d), report metadata
     (Annual Report, Portfolio, Leasable Area, Index, Table of Contents)
   - LOCATION_ADDRESS < 10 characters
   - LOCATION_ADDRESS is numeric only
   - LOCATION_NAME is a financial metric or report section header
   - Row has no country-city-address combination (all three blank)
3. Remove bad rows. Write them to BOTH:
   - `{BATCH_TEMP}\orchestrator_validation_backups\{ISSUER_ID}_removed.csv` (raw backup)
   - Append to `{REJECT_DIR}\{ISSUER_ID}_{ISSUER_NAME}_rejected.csv` (consolidated reject file)
     with `rejection_reason` and `rejected_by` = `orchestrator_scrub`.
     If the worker already created this reject file (worker_qa rows), append to it —
     do not overwrite. The reject file ends up holding both worker_qa and
     orchestrator_scrub rejections for the issuer.
4. Promote clean CSV to `{BATCH_OUTPUT}\{ISSUER_ID}_{ISSUER_NAME}.csv`
5. Log:
   ```json
   {"event": "promoted", "issuer_id": "...", "rows_in": N,
    "rows_removed": N, "rows_out": N, "timestamp": "..."}
   ```

---

### Step O-1d — Create the Resume Automation (MANDATORY GATE — do this before monitoring)

> ════════════════════════════════════════════════════════════════════════
> ⚠️ **THIS STEP IS REQUIRED. THE RUN IS NOT AUTONOMOUS WITHOUT IT. DO NOT SKIP.**
> ════════════════════════════════════════════════════════════════════════
>
> The platform WILL end your turn before 500 issuers finish (~40 min limit, proven on
> Desktop and CLI). If you have not created a resume automation by then, the entire run
> halts at the turn boundary and the user must manually re-prompt — which is exactly the
> failure we are eliminating. **Creating this automation is the single thing that makes the
> run truly hands-off. It is not optional and not "for later" — do it NOW, immediately after
> the first worker wave is live (after Step O-1b), before you enter the monitoring loop.**
>
> **Action — create ONE scheduled automation now:**
> - Name: `resume-extraction-{BATCH_ID}` (or similar, tied to this batch)
> - Starting interval: **15 minutes** (the heaviest issuers run first and are in the pool at
>   start, so the size-aware rule in O-2 yields the longest interval here). The interval is
>   then adjusted dynamically in O-2 based on the target sizes of issuers in the active pool.
> - The automation's prompt text (what it re-sends to THIS conversation each time):
>   ```
>   Resume the in-progress extraction batch for {BATCH_ID} in {TEMP_FOLDER}.
>   Run Phase O-R from disk state first, promote any completed-but-unpromoted workers,
>   refill worker slots to WORKER_CAP by spawning FRESH single-use agents per issuer
>   (never reuse threads), continue the quiet live monitoring loop, and surface only
>   genuine escalations or full batch completion. Keep workers at the orchestrator's
>   exact model and reasoning tier. Do not create a second automation — one already exists.
>   ```
> - Output a confirmation line:
>   ```
>   [AUTOMATION] Created resume automation '{name}' at 15-min interval.
>               This bridges turn boundaries so the run continues hands-off.
>               Interval will be tightened in later phases (O-2).
>   ```
> - Log it: `{"event": "automation_created", "name": "...", "interval_min": 15, "timestamp": "..."}`
>
> **Guard against duplicates:** before creating, check whether a resume automation for this
> BATCH_ID already exists (e.g. this is a resumed turn). If one exists, do NOT create another
> — adjust its interval if needed (per O-2 phase rules) and continue. Exactly ONE resume
> automation should exist for the batch at any time.
>
> **Delete the automation** when the batch (main pass + rework pass) is fully complete, or
> if the user says stop. Leaving a stale automation running after completion is a defect.
> ════════════════════════════════════════════════════════════════════════

---

## PHASE O-2 — MONITORING

> ════════════════════════════════════════════════════════════════════════
> ⚠️ **HOW TO STAY AUTONOMOUS ACROSS A LONG RUN — READ CAREFULLY.**
> ════════════════════════════════════════════════════════════════════════
>
> **The platform turn is finite on every Codex surface (Desktop AND CLI — both tested).**
> Your turn WILL end on a long run, whether you finish a turn's work or hit the platform's
> turn-length limit. You CANNOT keep one turn alive indefinitely; no wording changes that.
> A 500-issuer run spans many turns. Autonomy therefore needs two mechanisms together:
>
> **(1) WITHIN each turn — run the loop LIVE and event-driven.**
> While your turn is alive, run the monitoring loop continuously in this conversation. The
> moment a worker finishes, promote it and spawn a FRESH agent for the next issuer —
> immediately, not on a timer. Keep the pool at full WORKER_CAP. Do as much as possible
> within each live turn. This is the fast primary work mode while the turn lasts.
>
> **(2) TO BRIDGE turn boundaries — the resume automation (created in Step O-1d).**
> You must have already created ONE resume automation in Step O-1d (before entering this
> loop). That automation re-prompts THIS thread across turn boundaries: when it fires, you
> run Phase O-R (reconstruct from disk), promote stragglers, refill the pool with FRESH
> agents, and continue. This is what makes the whole run hands-off — you never re-prompt
> manually. If for any reason the automation was not created in O-1d, create it NOW before
> doing anything else (see O-1d for the exact spec) — the run is not autonomous without it.
>
> **DYNAMIC AUTOMATION INTERVAL (size-aware — based on what the pool is ACTUALLY processing):**
> The queue is ordered heaviest-first, and heavy issuers take disproportionately more
> wall-clock time than light ones. So do NOT set the interval purely on "% of issuers done"
> (that lags reality — the first 20% of issuers can eat 60%+ of the time). Instead, set the
> interval based on the **target sizes of the issuers CURRENTLY in the active worker pool**,
> which you can read from the manifest (`count` field) for each active ISSUER_ID.
>
> Each time you adjust the interval (at minimum: at start, and whenever you refill the pool),
> compute the pool's workload and pick the interval:
> ```
> max_active_count   = the largest `count` among the issuers currently RUNNING
> (optionally also consider the next few queued issuers about to be spawned)
>
> if max_active_count >= 5000   → interval = 15 min   (very heavy issuers in pool)
> elif max_active_count >= 1000 → interval = 10 min   (moderately heavy)
> elif max_active_count >= 200  → interval = 6 min    (light-to-moderate)
> else (max_active_count < 200) → interval = 4 min    (light, fast turnover)
> ```
> (Thresholds are guidance — scale them to the actual distribution of this batch's counts.
> The principle is what matters: big issuers in the pool → longer interval, because they
> won't finish soon and frequent wakeups just burn cycles; small issuers in the pool →
> shorter interval, because they complete fast and freed slots should refill promptly.)
>
> Because the queue is size-sorted, this naturally produces the ramp you'd expect — long
> intervals (~15 min) early while the heaviest issuers are in the pool, tightening toward
> ~4–5 min by the lightweight tail — but it does so by reacting to the REAL workload in the
> pool at each moment, not a crude percentage. If a single very heavy issuer is still running
> alongside several light ones, the interval correctly stays longer (keyed to the max),
> avoiding wasted wakeups while that heavy one grinds.
>
> Re-evaluate and (if changed) update the automation's interval whenever you refill the pool
> (you can delete and recreate it with the new interval, or update it if the interface
> allows). Record interval changes in orchestrator_log.jsonl with the max_active_count that
> drove the choice. (The automation itself was already CREATED in Step O-1d; here you only
> adjust its interval. Never create a second one.)
>
> ⚠️ **THE AUTOMATION DOES NOT CHANGE THE WORK MODEL.** Even when resumed by the automation,
> you still: spawn a FRESH single-use agent per issuer, NEVER reuse/recycle/reattach worker
> threads, promote event-driven within the live turn, and keep the pool full. The automation
> only re-wakes the thread across turn boundaries — it is not a license to switch to slow
> timer-batched promotion or to a pool of reusable threads. One issuer = one fresh agent =
> one termination, always.
> ════════════════════════════════════════════════════════════════════════

> ════════════════════════════════════════════════════════════════════════
> ⚠️ **NEVER MESSAGE LIVE WORKERS. MONITORING IS STRICTLY DISK-ONLY.**
> ════════════════════════════════════════════════════════════════════════
>
> Do NOT send status pings, "are you done?" prompts, or ANY message to a running worker
> agent. In some runtimes a worker treats an incoming message as a terminal response and
> EXITS its extraction task — silently killing the worker and wasting all its progress.
> This has happened and destroyed entire worker waves.
>
> **Determine worker state ONLY from disk:**
> - `{ISSUER_ID}_RUNNING.flag` present, no DONE flag → worker is active, LEAVE IT ALONE.
> - `{ISSUER_ID}_DONE.flag` present → worker finished; promote from staging, then close it.
> - Neither flag after a worker was spawned and a reasonable settle window passed (and no
>   issuer folder / no file activity) → treat as a lost startup; clear any stale flag and
>   spawn a FRESH replacement for that issuer.
> - A passive "wait for agent to complete" call (which does NOT inject input) is acceptable
>   to detect completion, but sending the agent any textual prompt is NOT. When in doubt,
>   read disk — never talk to the worker.
>
> The only signals that flow from a worker are the files it writes (RUNNING.flag, DONE.flag,
> staging CSV, audit/QA entries, ESCALATION.flag, exhaustion proof). You read those. You do
> not converse with workers.
> ════════════════════════════════════════════════════════════════════════

>
> **QUIET-LOOP RULE (this is what preserves multi-hour autonomy):**
> Do NOT read each worker's summary and relay it into this conversation. Do NOT print a
> per-issuer block for every completion. Per-issuer narration floods the orchestrator's
> turn with output and exhausts the platform turn budget, which is what causes the
> conversation to end early and forces manual re-prompting. The orchestrator promotes
> CSVs and refills slots SILENTLY. The only routine output is the periodic aggregate
> [MONITOR] heartbeat (counts, not per-issuer detail). Per-issuer detail already lives on
> disk (batch_audit.jsonl, each worker's issuer_summary.txt, GAP_DIR) — it does not need
> to be spoken aloud in chat.
>
> While the rolling pool is running, the orchestrator must:
> - **NEVER** pause to ask the user whether to continue.
> - **NEVER** present a "Next Steps" menu, a "1. Continue / 2. Stop here" choice, or any
>   variant that waits for user input to proceed.
> - **NEVER** end its turn, post a final-style summary, or treat a monitoring checkpoint
>   as a stopping point while issuers remain in the queue or workers are still active.
> - **NEVER** ask "should I continue?", "do you want me to proceed?", or similar. The
>   answer is always yes — continue autonomously.
> - **NEVER** narrate individual issuer completions in chat — promote silently, heartbeat only.
>
> The orchestrator runs the rolling pool to completion on its own. It only stops for:
> 1. A genuine `{ISSUER_ID}_ESCALATION.flag` that requires human judgement (surface it,
>    but keep all OTHER workers running — do not halt the pool), or
> 2. True batch completion (queue empty AND all workers done) — which triggers Phase O-3.
>
> If the platform interrupts the turn (e.g. a hard turn-length limit), that is the
> platform's doing — the orchestrator's instructions are to keep going, never to
> volunteer a stop. On resume, continue the rolling pool immediately (state is on disk:
> status flags, audit log, manifest).

Emit the monitoring heartbeat roughly every 2 minutes during rolling pool execution.
This is a status print only — after printing it, immediately continue the pool
(check for DONE flags, promote, refill slots). Do not wait for acknowledgement.

**Each monitoring cycle is self-contained and idempotent — structure it so a turn
boundary can never lose work.** Every single cycle does ALL of the following by reading
disk state fresh (never relying on what was in memory earlier in the turn):

```
ONE MONITORING CYCLE:
1. Scan status/ for ALL {ISSUER_ID}_DONE.flag files.
2. List BATCH_OUTPUT to see which issuers are already promoted.
3. For EVERY completed-but-not-yet-promoted issuer (not just the most recent one):
   run Step O-1c staging validation + promotion. This is the key idempotency rule —
   promote the full backlog every cycle, so even if several completed during a dead
   turn, the next cycle clears all of them.
4. Add any newly-promoted gap issuers to the rework list.
5. Count active workers (RUNNING without DONE). If active < WORKER_CAP and queue
   non-empty → spawn next queued issuer(s) until active = WORKER_CAP or queue empty.
6. Clear any stale flags (probe placeholders, orphaned RUNNING flags).
7. Print the [MONITOR] heartbeat.
8. Immediately begin the next cycle. Do not end the turn voluntarily.
```

Because each cycle re-derives everything from disk, it does not matter whether the
previous cycle ran in this turn or a prior one — the cycle always promotes every
straggler and refills every empty slot. A turn boundary becomes harmless.

```
[MONITOR] {datetime}
  Progress  : {done}/{total} issuers | {active} active workers
  Promoted this cycle: {N} | Total promoted: {N}
  Rework    : {N} gap issuers accumulated
  Rows      : {N} rows promoted to output so far
  Active    : {list of currently running ISSUER_IDs}
  Escalations: {N} pending
```

Surface any `{ISSUER_ID}_ESCALATION.flag` immediately to UI.
All other workers continue unaffected during escalation handling — the pool does not halt.

---

## PHASE O-3 — MAIN PASS COMPLETE

When all issuers processed (queue exhausted + all active workers done):

### Step O-3a — Central Scrub

Final pass across all files in `{BATCH_OUTPUT}`:
- Re-apply contamination checks from Step O-1c
- Post-scrub pattern scan
- Output:
  ```
  [SCRUB] {N} rows removed from {N} files | Pattern scan: {NO_MATCHES / N matches}
  ```

### Step O-3b — Write final_issuer_status.csv

Columns: `ISSUER_ID`, `ISSUER_NAME`, `TARGET_COUNT`, `ACHIEVED_COUNT`,
`STATUS` (met/exceeded/gap), `WORKER_ID`, `PASS_TYPE`, `DURATION_SECONDS`,
`GAP_REASON`, `REWORK_ELIGIBLE`

`REWORK_ELIGIBLE` = true if worker attempted extraction but fell short.
`REWORK_ELIGIBLE` = false if worker crashed without attempting (these get re-queued
to main pass, not rework pass).

### Step O-3c — Main Pass Summary

```
═══════════════════════════════════════════════════════════
MAIN PASS COMPLETE — Extraction_Batch_{INPUT_NAME}_{TIMESTAMP}
═══════════════════════════════════════════════════════════
Issuers processed  : {N}
Met / Exceeded     : {N} ✅
Gap                : {N} ⚠️
Coverage           : {achieved}/{target} ({pct}%)
Rows after scrub   : {N}
Contamination removed: {N} rows

Rework eligible    : {N} issuers → proceeding to rework pass now
═══════════════════════════════════════════════════════════
```

---

## PHASE O-4 — REWORK PASS

Automatically proceed. No waiting window. Notify immediately:
```
⚠️ REWORK PASS STARTING
  {N} gap issuers from main pass.
  Rework workers will attempt Tier 3 (official filings), Tier 4 (secondary sources
  with official cross-validation), and Tier 5 (JS/anti-bot approaches).
  Tiers 1 and 2 were exhausted in the main pass — not repeated.
  Starting now.
```

### Step O-4a — Build Rework Queue

Read `final_issuer_status.csv`. Filter: STATUS=gap AND REWORK_ELIGIBLE=true.
Order: largest gap first (TARGET_COUNT - ACHIEVED_COUNT descending).

Write `{BATCH_TEMP}\rework_manifest.json`.

### Step O-4b — Re-Probe Cap

Re-run Step O-1a probe for the rework session. Cap may have changed.
Use freshly probed WORKER_CAP.

### Step O-4c — Rework Rolling Pool

**The rework pass is fully parallel — identical multi-subagent rolling pool as the main pass.**
It re-probes the cap (O-4b), then spawns up to WORKER_CAP rework workers concurrently,
each a FRESH single-use agent handling one gap issuer in full isolation. As each rework
worker completes, it is closed and the freed slot is filled by spawning a brand-new agent
for the next queued rework issuer. **The same two hard rules apply: fresh agent per issuer
(never reuse/recycle threads), and run the loop live in this conversation (never create a
scheduled automation).** This is the same rolling mechanics as Phase O-1b — not a serial
one-at-a-time pass, and not a timer-driven one.

Worker queue files differ from main pass only in:
- `PASS_TYPE: rework`
- `WORKER_ID: {NN}R`
- `MAIN_PASS_ACHIEVED: {N}` — rows already extracted in main pass
- Tiers 1 and 2 explicitly skipped (see WORKER_PROMPT §W-1 approach ladder)

The same slot-accounting check applies: no slot sits idle while rework issuers remain
in the queue. Fill all WORKER_CAP slots.

**Rework monitoring is idempotent and turn-boundary-resilient — same as the main pass.**
The rework pass is also long-running and will span turns. Apply the identical
self-contained cycle: every cycle scans `status/` for rework DONE flags, merges/promotes
ALL completed-but-unmerged rework issuers (not just the latest), refills slots from the
rework queue, prints the heartbeat, and continues. The Phase O-R resume check also covers
rework: on a resumed turn, if `rework_manifest.json` exists and the main pass is complete,
the orchestrator reconstructs rework state from disk (rework DONE flags vs merged outputs)
and continues the rework pool without restarting it. A turn boundary during rework is
harmless for the same reason it is during the main pass.

**Rework worker queue file additions:**
```markdown
PASS_TYPE          : rework
MAIN_PASS_ACHIEVED : {N}
SKIP_TIERS         : 1,2
```

**Rework rolling counter — output after every rework completion:**
```
[REWORK-ROLLING] {done}/{total} rework issuers done | {active} active |
                 {queued} queued | {improved} improved | continuing...
```

### Step O-4d — Merge Rework Results

For each rework issuer that returned rows:
1. Read main pass CSV from `{BATCH_OUTPUT}`
2. Append new rework rows
3. Deduplicate by (LOCATION_NAME + LOCATION_ADDRESS + COUNTRY)
4. Re-validate and re-promote
5. Update audit entry with combined counts

### Step O-4e — Final Combined Summary and Artifacts

```
═══════════════════════════════════════════════════════════
FINAL COMBINED SUMMARY — Extraction_Batch_{INPUT_NAME}_{TIMESTAMP}
═══════════════════════════════════════════════════════════
MAIN PASS
  Processed  : {N} | Met/Exceeded: {N} ✅ | Gap: {N} ⚠️

REWORK PASS
  Attempted  : {N} | Improved: {N} ✅ | Final gap: {N} ⚠️
  Additional rows recovered: {N}

COMBINED
  Total issuers    : {N}
  Met / Exceeded   : {N} ✅
  Final gaps       : {N} ⚠️
  Total rows output: {N}
  Combined coverage: {pct}%

FINAL GAP ISSUERS
[For each: target, achieved, all tiers attempted, root cause, recommendation]
═══════════════════════════════════════════════════════════
```

Write final artifacts:
- `{BATCH_TEMP}\batch_report.py` — HTML report generator
- `{BATCH_TEMP}\combined_locations.csv` — all rows merged
- `{BATCH_TEMP}\orchestrator_validation_report.json`
- `{BATCH_TEMP}\final_issuer_status.csv` — updated with rework outcomes
- `{BATCH_TEMP}\token_cost_ledger.json` — timing breakdowns
  (note: if exact token telemetry is unavailable, record that limitation
  explicitly — do not fabricate numbers)

Point the final summary at the two human-facing folders:
- `{REJECT_DIR}` — all rejected records, one file per issuer that had rejections
  (combines worker_qa and orchestrator_scrub rejections)
- `{GAP_DIR}` — per-gap-issuer folders with exhaustion proof, gap_analysis.md,
  partial CSV, and any snapshots — the human-in-the-loop starting point
```
Reject records : {REJECT_DIR}  ({N} issuers had rejections)
Gap review     : {GAP_DIR}  ({N} gap issuers for human review)
```

---

## ORCHESTRATOR QUALITY CHECKLIST

**Resume Check (every turn)**
- [ ] Phase O-R ran first: checked for an in-progress batch before doing anything
- [ ] On resume: state reconstructed from disk (DONE flags, promoted CSVs, audit log)
- [ ] On resume: all unpromoted stragglers promoted before continuing
- [ ] On resume: pool re-established to WORKER_CAP from the queue

**Setup (fresh start only)**
- [ ] Own model + reasoning tier detected and recorded
- [ ] Batch infrastructure created (including staging\, proof\, reject\, gap\ folders)
- [ ] Batch folder named with INPUT_NAME + timestamp for uniqueness
- [ ] Pre-validation excluded all non-IID rows before parsing
- [ ] Real issuer count and target reported before any spawn
- [ ] Input File Summary block output (issuers, unique issuers, URLs, unique URLs, expected count)
- [ ] Flat issuer queue built (heaviest first)
- [ ] Manifest written to batch_manifest.json

**Cap Probe**
- [ ] Probe attempted at 20 → 15 → 10 → 6
- [ ] SESSION_CAP and WORKER_CAP recorded and logged
- [ ] WORKER_CAP set to SESSION_CAP - 1 (one slot reserved for orchestrator)
- [ ] Cap probe logged to orchestrator_log.jsonl

**Main Pass**
- [ ] One worker per issuer (no multi-issuer workers)
- [ ] FRESH agent spawned per issuer — no thread reuse/recycle/reattach
- [ ] Finished workers closed; freed slots filled by spawning NEW agents
- [ ] Within each turn: loop run LIVE, promotion + refill immediately on each completion (event-driven)
- [ ] ⚠️ Step O-1d done: ONE resume automation CREATED right after first wave (MANDATORY — run not autonomous without it)
- [ ] Automation interval is SIZE-AWARE: set by max target-count of issuers in active pool (heavy→15min, light→4min), re-evaluated on each refill
- [ ] Automation deleted at full completion (main + rework) or on user stop
- [ ] NEVER messaged a live worker — worker state read from disk only
- [ ] Every worker queue file includes MODEL and REASONING fields
- [ ] MODEL and REASONING EQUAL orchestrator's exactly (not higher, not lower — no 'high' default, no 'medium' avoidance)
- [ ] Rolling pool: freed slots refilled immediately
- [ ] Staging validation run before every CSV promotion
- [ ] Rejected rows appended to REJECT_DIR (worker_qa + orchestrator_scrub)
- [ ] Classifier subagent closed and its slot reclaimed before/at pool start
- [ ] No slot left idle while issuers remain in queue (full WORKER_CAP utilised)
- [ ] Contaminated rows removed before promotion, backed up
- [ ] Stalled workers detected and rescheduled after 60 min
- [ ] [ROLLING] line output after every completion
- [ ] Each monitoring cycle promotes ALL completed stragglers (not just the most recent)
- [ ] Monitoring cycle re-reads disk state each time (survives turn boundaries)
- [ ] final_issuer_status.csv written after main pass
- [ ] REWORK_ELIGIBLE correctly set for each gap issuer

**Rework Pass**
- [ ] Rework started automatically (no waiting window)
- [ ] Cap re-probed for rework session
- [ ] Rework workers have PASS_TYPE: rework and SKIP_TIERS: 1,2
- [ ] Rework results merged and deduplicated with main pass CSVs
- [ ] Final combined summary output

**Completion**
- [ ] GAP_DIR populated for every gap issuer (human-in-the-loop material)
- [ ] REJECT_DIR populated for every issuer with rejections
- [ ] Per-issuer UI summaries surfaced for all issuers (mandatory, none skipped)
- [ ] Central scrub run and logged
- [ ] combined_locations.csv generated
- [ ] batch_report.py generated
- [ ] All stale RUNNING.flag files cleaned up
- [ ] token_cost_ledger.json written (no fabricated numbers)
