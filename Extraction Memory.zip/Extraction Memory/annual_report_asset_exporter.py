"""
Config-driven exporter for facility rows sourced from an annual report PDF.

This script is designed for issuer extractions where the source PDF contains:
1. Explicit asset/property addresses in tabular narrative sections.
2. Operating project entities whose locality is stated in the project/company name
   but whose street address is not disclosed in the report.

How to adapt for a new issuer:
- Update the CONFIG block and the row lists only.
- Keep the export, validation, checkpoint, and draft-memory logic unchanged.

Usage:
    python annual_report_asset_exporter.py
"""

from __future__ import annotations

import csv
import json
import time
from datetime import datetime
from pathlib import Path


# ============================================================================
# CONFIGURATION
# ============================================================================
ISSUER_ID = "IID000000002143002"
ISSUER_NAME = "GUANGDONG INVESTMENT LIMITED"
SOURCE_URL = "https://www.gdi.com.hk/attachment/0/8/8022/9159.pdf"
SOURCE_TYPE = "annual_report_pdf"
EXPECTED_MIN_COUNT = 67
CHECKPOINT_COUNT = 67
COORD_SOURCE_DEFAULT = "not_on_website"

TEMP_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp"
)
OUTPUT_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output"
)

CHECKPOINT_PATH = TEMP_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_checkpoint.csv"
WORKING_PATH = TEMP_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_working.csv"
FINAL_OUTPUT_PATH = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
PROGRESS_PATH = TEMP_DIR / f"{ISSUER_ID}_progress.json"
SUMMARY_PATH = TEMP_DIR / f"{ISSUER_ID}_summary.json"
MEMORY_DRAFT_PATH = TEMP_DIR / f"{ISSUER_ID}_memory_append_draft.md"

EXPORT_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS",
    "LOCATION_ADDRESS_NATIVE",
    "LATITUDE",
    "LONGITUDE",
    "coord_source",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
]

STATE_NATIVE = {
    "Guangdong": "广东省",
    "Guizhou": "贵州省",
    "Hubei": "湖北省",
    "Hong Kong": "香港",
    "Hunan": "湖南省",
    "Jiangsu": "江苏省",
    "Tianjin": "天津市",
    "Yunnan": "云南省",
    "Guangxi": "广西壮族自治区",
}


def clean_text(value: str) -> str:
    if value is None:
        return ""
    text = str(value)
    replacements = {
        "#": " ",
        "–": "-",
        "—": "-",
        "’": "'",
        "“": '"',
        "”": '"',
        "▲": "",
        "^": "",
    }
    for src, dst in replacements.items():
        text = text.replace(src, dst)
    text = " ".join(text.split())
    return text.strip(" ,;")


def build_native_address(locality_native: str, state: str, country: str) -> str:
    locality_native = clean_text(locality_native)
    if not locality_native:
        return ""
    parts = [locality_native]
    province_native = STATE_NATIVE.get(state, "")
    if province_native and province_native not in locality_native:
        parts.append(province_native)
    if country == "China":
        parts.append("中国")
    return clean_text(", ".join(parts))


def build_locality_address(locality: str, city: str, state: str, country: str) -> str:
    parts = [locality]
    if city and city != locality:
        parts.append(city)
    if state and state not in parts:
        parts.append(state)
    parts.append(country)
    return clean_text(", ".join(parts))


def make_locality_row(
    *,
    name_en: str,
    name_native: str,
    locality_en: str,
    locality_native: str,
    city: str,
    state: str,
    activity: str,
    country: str = "China",
    country_iso3: str = "CHN",
    postcode: str = "",
) -> dict[str, str]:
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": clean_text(name_en),
        "LOCATION_NAME_NATIVE": clean_text(name_native),
        "LOCATION_ADDRESS": build_locality_address(locality_en, city, state, country),
        "LOCATION_ADDRESS_NATIVE": build_native_address(locality_native, state, country),
        "LATITUDE": "",
        "LONGITUDE": "",
        "coord_source": COORD_SOURCE_DEFAULT,
        "COUNTRY": clean_text(country),
        "COUNTRY_ISO3": clean_text(country_iso3),
        "POSTCODE": clean_text(postcode),
        "STATE": clean_text(state),
        "CITY": clean_text(city),
        "SOURCE_URL": SOURCE_URL,
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": clean_text(activity),
        "_granularity": "locality",
    }


def make_explicit_row(
    *,
    name_en: str,
    address_en: str,
    city: str,
    state: str,
    activity: str,
    country: str = "China",
    country_iso3: str = "CHN",
    postcode: str = "",
    name_native: str = "",
    address_native: str = "",
) -> dict[str, str]:
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": clean_text(name_en),
        "LOCATION_NAME_NATIVE": clean_text(name_native),
        "LOCATION_ADDRESS": clean_text(address_en),
        "LOCATION_ADDRESS_NATIVE": clean_text(address_native),
        "LATITUDE": "",
        "LONGITUDE": "",
        "coord_source": COORD_SOURCE_DEFAULT,
        "COUNTRY": clean_text(country),
        "COUNTRY_ISO3": clean_text(country_iso3),
        "POSTCODE": clean_text(postcode),
        "STATE": clean_text(state),
        "CITY": clean_text(city),
        "SOURCE_URL": SOURCE_URL,
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": clean_text(activity),
        "_granularity": "explicit",
    }


LOCALITY_ROWS = [
    make_locality_row(name_en="Dongguan Changping Guangdong Huanbao Co., Ltd.", name_native="东莞市常平粤海环保有限公司", locality_en="Changping", locality_native="东莞市常平", city="Dongguan", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Kaiping Guangdong Water Co., Ltd.", name_native="开平粤海水务有限公司", locality_en="Kaiping", locality_native="开平", city="Kaiping", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Wuhua Guangdong Huanbao Co., Ltd.", name_native="五华粤海环保有限公司", locality_en="Wuhua", locality_native="五华", city="Wuhua", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Dongguan Daojiao Guangdong Huanbao Co., Ltd.", name_native="东莞市道滘粤海环保有限公司", locality_en="Daojiao", locality_native="东莞市道滘", city="Dongguan", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Shanwei Guangdong Huanbao Co., Ltd.", name_native="汕尾粤海环保有限公司", locality_en="Shanwei", locality_native="汕尾", city="Shanwei", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Gaozhou Guangdong Water Co., Ltd.", name_native="高州粤海水务有限公司", locality_en="Gaozhou", locality_native="高州", city="Gaozhou", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Liupanshui Guangdong Huanbao Co., Ltd.", name_native="六盘水粤海环保有限公司", locality_en="Liupanshui", locality_native="六盘水", city="Liupanshui", state="Guizhou", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Kunming Guangdong Water Co., Ltd.", name_native="昆明粤海水务有限公司", locality_en="Kunming", locality_native="昆明", city="Kunming", state="Yunnan", activity="Water supply and wastewater treatment facility in operation"),
    make_locality_row(name_en="Yunfu Guangdong Water Co., Ltd.", name_native="云浮粤海水务有限公司", locality_en="Yunfu", locality_native="云浮", city="Yunfu", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Dapu Guangdong Huanbao Co., Ltd.", name_native="大埔粤海环保有限公司", locality_en="Dapu", locality_native="大埔", city="Dapu", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Shaoguan Guangdong Luyuan Huanbao Co., Ltd.", name_native="韶关粤海绿源环保有限公司", locality_en="Shaoguan", locality_native="韶关", city="Shaoguan", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Yangshan Guangdong Huanbao Co., Ltd.", name_native="阳山粤海环保有限公司", locality_en="Yangshan", locality_native="阳山", city="Yangshan", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Yunfu City Guangdong Water Supply Co., Ltd.", name_native="云浮市粤海水务自来水有限公司", locality_en="Yunfu", locality_native="云浮市", city="Yunfu", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Yunfu City Guangdong Water Development Co., Ltd.", name_native="云浮市粤海水务发展有限公司", locality_en="Yunfu", locality_native="云浮市", city="Yunfu", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Yangjiang Guangdong Huanbao Co., Ltd.", name_native="阳江粤海环保有限公司", locality_en="Yangjiang", locality_native="阳江", city="Yangjiang", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Jieyang Guangdong Water Co., Ltd.", name_native="揭阳粤海水务有限公司", locality_en="Jieyang", locality_native="揭阳", city="Jieyang", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Puning Guangdong Water Co., Ltd.", name_native="普宁粤海水务有限公司", locality_en="Puning", locality_native="普宁", city="Puning", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Chaozhou Guangdong Huanbao Co., Ltd.", name_native="潮州市粤海环保有限公司", locality_en="Chaozhou", locality_native="潮州", city="Chaozhou", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Wuchuan Guangdong Huanbao Co., Ltd.", name_native="吴川粤海环保有限公司", locality_en="Wuchuan", locality_native="吴川", city="Wuchuan", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Pingyuan Guangdong Water Co., Ltd.", name_native="平远粤海水务有限公司", locality_en="Pingyuan", locality_native="平远", city="Pingyuan", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Pizhou Guangdong Water Co., Ltd.", name_native="邳州粤海水务有限公司", locality_en="Pizhou", locality_native="邳州", city="Pizhou", state="Jiangsu", activity="Water supply facility in operation"),
    make_locality_row(name_en="Huilai Guangdong Qingyuan Huanbao Co., Ltd.", name_native="惠来粤海清源环保有限公司", locality_en="Huilai", locality_native="惠来", city="Huilai", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Huilai Guangdong Luyuan Huanbao Co., Ltd.", name_native="惠来粤海绿源环保有限公司", locality_en="Huilai", locality_native="惠来", city="Huilai", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Xinyi Guangdong Water Co., Ltd.", name_native="信宜粤海水务有限公司", locality_en="Xinyi", locality_native="信宜", city="Xinyi", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Jiexi Guangdong Water Co., Ltd.", name_native="揭西粤海水务有限公司", locality_en="Jiexi", locality_native="揭西", city="Jiexi", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Wuhua Guangdong Biyuan Huanbao Co., Ltd.", name_native="五华粤海碧源环保有限公司", locality_en="Wuhua", locality_native="五华", city="Wuhua", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Yunfu City Yunan Guangdong Urban and Rural Water Supply Co., Ltd.", name_native="云浮市云安粤海城乡供水有限公司", locality_en="Yunan", locality_native="云浮市云安", city="Yunfu", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Heyuan City Guangdong Water Co., Ltd.", name_native="河源市粤海水务有限公司", locality_en="Heyuan", locality_native="河源市", city="Heyuan", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Wuxi Debao Water Investment Co., Ltd.", name_native="无锡德宝水务投资有限公司", locality_en="Wuxi", locality_native="无锡", city="Wuxi", state="Jiangsu", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Shanwei Guangdong Water Co., Ltd.", name_native="汕尾粤海水务有限公司", locality_en="Shanwei", locality_native="汕尾", city="Shanwei", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Dongguan Changping Guangdong Water Co., Ltd.", name_native="东莞常平粤海水务有限公司", locality_en="Changping", locality_native="东莞常平", city="Dongguan", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Zhongshan City Xinyongkou Guangdong Water Co., Ltd.", name_native="中山市新涌口粤海水务有限公司", locality_en="Xinyongkou", locality_native="中山市新涌口", city="Zhongshan", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Zhongshan City Henglan Guangdong Water Co., Ltd.", name_native="中山市横栏粤海水务有限公司", locality_en="Henglan", locality_native="中山市横栏", city="Zhongshan", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Zhongshan City Nanzhen Guangdong Water Co., Ltd.", name_native="中山市南镇粤海水务有限公司", locality_en="Nanzhen", locality_native="中山市南镇", city="Zhongshan", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Qingyuan City Longtang Guangdong Water Co., Ltd.", name_native="清远市龙塘粤海水务有限公司", locality_en="Longtang", locality_native="清远市龙塘", city="Qingyuan", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Guangzhou Nansha GDH Water Co., Ltd.", name_native="", locality_en="Nansha", locality_native="广州南沙", city="Guangzhou", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Zhanjiang Hedi Water Supply Operation Co., Ltd.", name_native="湛江市鹤地供水营运有限公司", locality_en="Hedi", locality_native="湛江市鹤地", city="Zhanjiang", state="Guangdong", activity="Water supply facility in operation"),
    make_locality_row(name_en="Xiangyin Guangdong Water Co., Ltd.", name_native="湘阴粤海水务有限公司", locality_en="Xiangyin", locality_native="湘阴", city="Xiangyin", state="Hunan", activity="Water supply facility in operation"),
    make_locality_row(name_en="Enshi Guangdong Water Co., Ltd.", name_native="恩施粤海水务有限公司", locality_en="Enshi", locality_native="恩施", city="Enshi", state="Hubei", activity="Water supply facility in operation"),
    make_locality_row(name_en="Shanwei Guangdong Qingyuan Huanbao Co., Ltd.", name_native="汕尾粤海清源环保有限公司", locality_en="Shanwei", locality_native="汕尾", city="Shanwei", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Kaiping Guangdong Water Purification Co., Ltd.", name_native="开平粤海净水有限公司", locality_en="Kaiping", locality_native="开平", city="Kaiping", state="Guangdong", activity="Wastewater treatment facility in operation"),
    make_locality_row(name_en="Foundation Gang-Wu (Changzhou) Water Supply Co., Ltd.", name_native="", locality_en="Changzhou", locality_native="常州", city="Changzhou", state="Jiangsu", activity="Water supply facility in operation (associate)"),
    make_locality_row(name_en="Shantou Guangdong Water Co., Ltd.", name_native="汕头市粤海水务有限公司", locality_en="Shantou", locality_native="汕头市", city="Shantou", state="Guangdong", activity="Water supply facility in operation (associate)"),
    make_locality_row(name_en="Xinghua Guangdong Water Co., Ltd.", name_native="兴化粤海水务有限公司", locality_en="Xinghua", locality_native="兴化", city="Xinghua", state="Jiangsu", activity="Water supply facility in operation (associate)"),
    make_locality_row(name_en="Lipu Guangdong Water Co., Ltd.", name_native="荔浦粤海水务有限公司", locality_en="Lipu", locality_native="荔浦", city="Lipu", state="Guangxi", activity="Water supply facility under construction"),
    make_locality_row(name_en="Jieyang Guangdong Guoye Water Co., Ltd.", name_native="揭阳粤海国业水务有限公司", locality_en="Jieyang", locality_native="揭阳", city="Jieyang", state="Guangdong", activity="Water supply facility under construction"),
    make_locality_row(name_en="Pizhou Guangdong Huanbao Co., Ltd.", name_native="邳州粤海环保有限公司", locality_en="Pizhou", locality_native="邳州", city="Pizhou", state="Jiangsu", activity="Wastewater treatment facility under construction"),
    make_locality_row(name_en="Shanwei Guangdong Water Supply Co., Ltd.", name_native="汕尾粤海供水有限公司", locality_en="Shanwei", locality_native="汕尾", city="Shanwei", state="Guangdong", activity="Water supply facility under construction"),
    make_locality_row(name_en="Zhaoqing HZ GDH Water Co., Ltd.", name_native="", locality_en="Zhaoqing", locality_native="肇庆", city="Zhaoqing", state="Guangdong", activity="Water supply facility under construction"),
]


EXPLICIT_ROWS = [
    make_explicit_row(name_en="Guangdong Investment Tower", address_en="148 Connaught Road Central, Hong Kong", city="Hong Kong", state="Hong Kong", country="Hong Kong", country_iso3="HKG", activity="Headquarters / office property"),
    make_explicit_row(name_en="Teem Tower and Teemmall", address_en="No. 208 Tianhe Road, Tianhe District, Guangzhou, Guangdong, China", city="Guangzhou", state="Guangdong", activity="Commercial and shopping mall"),
    make_explicit_row(name_en="Wharney Hotel", address_en="57-73 Lockhart Road and 84-88 Jaffe Road, Wan Chai, Hong Kong", city="Hong Kong", state="Hong Kong", country="Hong Kong", country_iso3="HKG", activity="Hotel"),
    make_explicit_row(name_en="Oasis Avenue-A GDH Hotel", address_en="18 Prat Avenue, Tsim Sha Tsui, Kowloon, Hong Kong", city="Hong Kong", state="Hong Kong", country="Hong Kong", country_iso3="HKG", activity="Hotel"),
    make_explicit_row(name_en="Sheraton Guangzhou Hotel", address_en="No. 208 Tianhe Road, Tianhe District, Guangzhou, Guangdong, China", city="Guangzhou", state="Guangdong", activity="Hotel"),
    make_explicit_row(name_en="Guangdong Hotel (Shenzhen)", address_en="Shennan East Road, Luohu District, Shenzhen, Guangdong, China", city="Shenzhen", state="Guangdong", activity="Hotel"),
    make_explicit_row(name_en="Guangdong Hotel (Zhuhai)", address_en="No. 1145 Yuehai Road East, Gongbei, Zhuhai, Guangdong, China", city="Zhuhai", state="Guangdong", activity="Hotel"),
    make_explicit_row(name_en="Holiday Inn Zhuhai City Center", address_en="No. 39 Bailian Road, Jida, Xiangzhou District, Zhuhai, Guangdong, China", city="Zhuhai", state="Guangdong", activity="Hotel"),
    make_explicit_row(name_en="GDH Energy Project", address_en="Huangpu Town, Zhongshan, Guangdong, China", city="Zhongshan", state="Guangdong", activity="Electricity and steam generation"),
    make_explicit_row(name_en="Nansha Water Distribution Facilities - Huangge Town Site", address_en="Southwest side of the interchange between Huanglan Expressway and Jingzhu Expressway, Huangge Town, Nansha District, Guangzhou, Guangdong, China", city="Guangzhou", state="Guangdong", activity="Water distribution facilities"),
    make_explicit_row(name_en="Nansha Water Distribution Facilities - Lanhe Town Site", address_en="No. 3 Gangang Road, Lanhe Town, Nansha District, Guangzhou, Guangdong, China", city="Guangzhou", state="Guangdong", activity="Water distribution facilities"),
    make_explicit_row(name_en="Qingxi Water Distribution Facilities - Shangyuan Road / Sanken Reservoir", address_en="Shangyuan Road, Sanken Reservoir, Qingxi Town, Dongguan, Guangdong, China", city="Dongguan", state="Guangdong", activity="Water distribution facilities"),
    make_explicit_row(name_en="Qingxi Water Distribution Facilities - Donghuan Road / Qiyeshi Reservoir", address_en="Donghuan Road, Qiyeshi Reservoir, Qingxi Town, Dongguan, Guangdong, China", city="Dongguan", state="Guangdong", activity="Water distribution facilities"),
    make_explicit_row(name_en="Qingxi Water Distribution Facilities - No. 28 Qingxi Avenue Site", address_en="No. 28 Qingxi Avenue, Qingxi Town, Dongguan, Guangdong, China", city="Dongguan", state="Guangdong", activity="Water distribution facilities"),
    make_explicit_row(name_en="Tianjin Teem Shopping Mall", address_en="No. 263 Heping Road, Heping District, Tianjin, China", city="Tianjin", state="Tianjin", activity="Shopping mall"),
    make_explicit_row(name_en="Panyu Teem Shopping Mall", address_en="No. 81 Wanhui 2 Road and No. 180 Wanbo 2 Road, Nancun Town, Panyu District, Guangzhou, Guangdong, China", city="Guangzhou", state="Guangdong", activity="Shopping mall"),
    make_explicit_row(name_en="Guangzhou Comic City", address_en="Underground of No. 1 Jixiang Road, Yuexiu District, Guangzhou, Guangdong, China", city="Guangzhou", state="Guangdong", activity="Shopping mall"),
    make_explicit_row(name_en="Shenzhen GDH City Commercial Portion", address_en="3008 Taibai Road, Luohu District, Shenzhen, Guangdong, China", city="Shenzhen", state="Guangdong", activity="Commercial property"),
    make_explicit_row(name_en="Zhuhai Laurel House", address_en="West of Jinhui Road and North of Jinhe East Road, Jinwan District, Zhuhai, Guangdong, China", city="Zhuhai", state="Guangdong", activity="Residential / commercial property under development"),
    make_explicit_row(name_en="Zhongshan GDH City", address_en="Tsuihang New District, Zhongshan, Guangdong, China", city="Zhongshan", state="Guangdong", activity="Residential property under development"),
    make_explicit_row(name_en="Jiangmen GDH City (Land No. 4 and 5)", address_en="East of Ganbei Road, Pengjiang District, Jiangmen, Guangdong, China", city="Jiangmen", state="Guangdong", activity="Residential / business apartment / commercial property under development"),
    make_explicit_row(name_en="Huizhou One Mansion", address_en="Mamiao, Aotou, Dayawan District, Huizhou, Guangdong, China", city="Huizhou", state="Guangdong", activity="Residential / business apartment / commercial property under development"),
    make_explicit_row(name_en="Guangzhou GDH Future City", address_en="Core Area of Baiyun New Town, Baiyun District, Guangzhou, Guangdong, China", city="Guangzhou", state="Guangdong", activity="Residential / business apartment / commercial / offices under development"),
    make_explicit_row(name_en="Foshan One Mansion", address_en="West Side of Fenjiang Road, North Side of Lujing Road and East Side of Luying West Street, Chancheng District, Foshan, Guangdong, China", city="Foshan", state="Guangdong", activity="Residential / commercial / offices under development"),
    make_explicit_row(name_en="Shenzhen GDH City Northwestern and Northern Land", address_en="3008 Taibai Road, Luohu District, Shenzhen, Guangdong, China", city="Shenzhen", state="Guangdong", activity="Business apartment / commercial / offices property held for sale"),
    make_explicit_row(name_en="Jiangmen One Mansion", address_en="West of Fengxiang Road, Southeast of the intersection of Chenyuan Road and Longteng Road, Pengjiang District, Jiangmen, Guangdong, China", city="Jiangmen", state="Guangdong", activity="Residential / business apartment / commercial property held for sale"),
    make_explicit_row(name_en="Jiangmen GDH City (Land No. 3)", address_en="East of Ganbei Road, Pengjiang District, Jiangmen, Guangdong, China", city="Jiangmen", state="Guangdong", activity="Residential property held for sale"),
    make_explicit_row(name_en="Foshan Laurel House", address_en="West of Wenhua Road, South of Liming Second Road, Chancheng District, Foshan, Guangdong, China", city="Foshan", state="Guangdong", activity="Residential property held for sale"),
    make_explicit_row(name_en="Oasis Aurum 181 Hotel", address_en="181 Connaught Road West, Hong Kong", city="Hong Kong", state="Hong Kong", country="Hong Kong", country_iso3="HKG", activity="Hotel operation and management"),
    make_explicit_row(name_en="Yuehai Tiandi Shopping Centre", name_native="粤海天地", address_en="No. 21 Zhujiang West Road, Zhujiang New Town, Tianhe District, Guangzhou, Guangdong, China", city="Guangzhou", state="Guangdong", activity="Commercial operation"),
]


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=EXPORT_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in EXPORT_COLUMNS})


def write_progress(processed_count: int, total_count: int) -> None:
    payload = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "processed_count": processed_count,
        "total_count": total_count,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
    }
    PROGRESS_PATH.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def validate_rows(rows: list[dict[str, str]]) -> None:
    for idx, row in enumerate(rows, start=1):
        if not row["LOCATION_ADDRESS"]:
            raise ValueError(f"Row {idx} has blank LOCATION_ADDRESS")
        if not row["CITY"]:
            raise ValueError(f"Row {idx} has blank CITY")
        if "#" in row["LOCATION_ADDRESS"]:
            raise ValueError(f"Row {idx} still contains # in LOCATION_ADDRESS")


def write_memory_draft(rows: list[dict[str, str]]) -> None:
    explicit_count = sum(1 for row in rows if row["_granularity"] == "explicit")
    locality_count = sum(1 for row in rows if row["_granularity"] == "locality")
    content = f"""### 4.X {ISSUER_NAME} (Apr 2026)

| Source | URL | Records | Method | Script |
|--------|-----|---------|--------|--------|
| Guangdong Investment Limited Annual Report 2024 | {SOURCE_URL} | {len(rows)} | Annual report PDF extraction with mixed explicit-address assets and locality-level operating project entities | `annual_report_asset_exporter.py` |
| **TOTAL** | | **{len(rows)}** | | |

**Platform Pattern**: Hybrid annual report extraction pattern combining explicit property tables with named operating-project entities. Reused ideas from `tabular_pdf_facility_extractor.py` and `chinese_corporate_annual_report_extractor.py`.

**Key Approach**: First extract the clearly address-bearing rows from the "Major Properties Held by the Group" and other narrative sections, then supplement with the water-resources operating company tables where the report provides reliable locality-level facility identifiers but not street-level addresses.

**Approaches Tried** (chronological):
1. Probed the PDF structure and located the "Major Properties Held by the Group" pages first. This produced only about 20 obvious records and was insufficient against the 67-row threshold.
2. Searched the rest of the annual report for additional address-bearing assets and narrative location references such as hotel, shopping mall, power, road, and water-facility sections.
3. Expanded coverage with the water-resources capacity tables on pages 19-21, using only rows where the entity name disclosed a reliable locality. Province-only group rollups were deliberately excluded to avoid weak or misleading addresses.
4. Final working approach: export a mixed dataset with 30 explicit-address rows and 49 locality-level project rows, keeping lat/long blank because the report does not disclose coordinates.

**Key Learnings**:
- Worked: The annual report is rich enough to exceed the threshold when both explicit asset tables and locality-bearing operating project tables are used together.
- Worked: The water-resources tables on pages 19-21 are the main scale driver; they work well when converted into locality-level addresses.
- Did not work: The annual report does not provide latitude/longitude values, so those fields must remain blank with `coord_source=not_on_website`.
- Did not work: Province-level aggregate rows such as "and its subsidiaries" do not provide a safe city/address and should be excluded.

**Script Config** (for reuse with the generalized script):
```python
ISSUER_ID = "{ISSUER_ID}"
ISSUER_NAME = "{ISSUER_NAME}"
SOURCE_URL = "{SOURCE_URL}"
EXPECTED_MIN_COUNT = {EXPECTED_MIN_COUNT}
CHECKPOINT_COUNT = {CHECKPOINT_COUNT}
```

**Draft Notes**:
- Explicit-address rows: {explicit_count}
- Locality-level rows: {locality_count}
- Coordinates from source: 0
- Output file: `{FINAL_OUTPUT_PATH.name}`
"""
    MEMORY_DRAFT_PATH.write_text(content, encoding="utf-8")


def write_summary(rows: list[dict[str, str]], runtime_seconds: float) -> None:
    locality_count = sum(1 for row in rows if row["_granularity"] == "locality")
    explicit_count = sum(1 for row in rows if row["_granularity"] == "explicit")
    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "source_url": SOURCE_URL,
        "expected_min_count": EXPECTED_MIN_COUNT,
        "final_count": len(rows),
        "threshold_met": len(rows) >= EXPECTED_MIN_COUNT,
        "explicit_address_rows": explicit_count,
        "locality_level_rows": locality_count,
        "coordinates_present": 0,
        "coord_source_default": COORD_SOURCE_DEFAULT,
        "runtime_seconds": round(runtime_seconds, 2),
        "generated_at": datetime.now().isoformat(timespec="seconds"),
    }
    SUMMARY_PATH.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")


def main() -> None:
    start_time = time.time()
    rows = LOCALITY_ROWS + EXPLICIT_ROWS
    validate_rows(rows)

    processed: list[dict[str, str]] = []
    total = len(rows)
    for idx, row in enumerate(rows, start=1):
        processed.append(row)
        if idx == CHECKPOINT_COUNT:
            write_csv(CHECKPOINT_PATH, processed)
        if idx % 20 == 0 or idx == total:
            write_progress(idx, total)

    write_csv(WORKING_PATH, processed)
    write_csv(FINAL_OUTPUT_PATH, processed)
    write_memory_draft(processed)
    runtime_seconds = time.time() - start_time
    write_summary(processed, runtime_seconds)

    print(
        json.dumps(
            {
                "checkpoint_path": str(CHECKPOINT_PATH),
                "working_path": str(WORKING_PATH),
                "final_output_path": str(FINAL_OUTPUT_PATH),
                "memory_draft_path": str(MEMORY_DRAFT_PATH),
                "summary_path": str(SUMMARY_PATH),
                "count": len(processed),
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
