"""
Generalized mirrored market-card and property-detail extractor.

Pattern:
- Cloudflare-protected property sites whose public pages can still be fetched via
  a text mirror such as r.jina.ai.
- A global "browse by region" hub links to market pages that expose static
  available-property cards with address text inside the mirrored markdown.
- Some markets also publish country-specific sitemap/detail pages whose property
  pages expose richer address blocks and optional coordinates.
- A shared office-locations page and direct contact page add office rows that are
  not part of the market-card inventory.

How to adapt for another issuer:
1. Update the CONFIGURATION block with the issuer metadata and source URLs.
2. Adjust the browse-page discovery filters if the site uses a different region
   hub path or market URL pattern.
3. Tune the activity and country-specific address heuristics for the target site.

This script writes intermediate artifacts to Temp, saves progress every 20 market
or detail pages, creates a checkpoint CSV once the threshold is met, and writes
the final CSV to Output.
"""

from __future__ import annotations

import csv
import json
import re
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
from urllib.parse import urlparse

import requests
import urllib3


# ============================================================================
# CONFIGURATION - Change these for each issuer
# ============================================================================
ISSUER_ID = "IID000000002700476"
ISSUER_NAME = "Prologis Property Mexico, S.A de C.V."
BASE_URL = "https://www.prologis.mx"
BROWSE_BY_REGION_URL = "https://www.prologis.com/browse-by-region"
SITEMAP_URL = "https://www.prologis.mx/sitemap.xml"
OFFICE_LOCATIONS_URL = "https://www.prologis.com/about/office-locations"
CONTACT_URL = "https://www.prologis.mx/en/contact"
MIRROR_PREFIX = "https://r.jina.ai/http://"
SOURCE_TYPE = "COMPANY WEBSITE"
COUNTRY = "Mexico"
COUNTRY_ISO3 = "MEX"
COUNT_THRESHOLD = 305

TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")

OUTPUT_BASENAME = f"{ISSUER_ID}_{ISSUER_NAME}"
FINAL_CSV = OUTPUT_DIR / f"{OUTPUT_BASENAME}.csv"
CHECKPOINT_CSV = TEMP_DIR / f"{OUTPUT_BASENAME}_checkpoint.csv"
PROGRESS_JSON = TEMP_DIR / f"{ISSUER_ID}_progress.json"
PARTIAL_ROWS_JSON = TEMP_DIR / f"{ISSUER_ID}_partial_rows.json"
SUMMARY_JSON = TEMP_DIR / f"{ISSUER_ID}_summary.json"
BROWSE_REGION_TXT = TEMP_DIR / f"{ISSUER_ID}_browse_by_region_mirror.txt"
SITEMAP_TXT = TEMP_DIR / f"{ISSUER_ID}_sitemap_mirror.txt"
MARKET_URLS_JSON = TEMP_DIR / f"{ISSUER_ID}_market_urls.json"
PROPERTY_URLS_JSON = TEMP_DIR / f"{ISSUER_ID}_property_urls.json"
MARKET_CARD_JSON = TEMP_DIR / f"{ISSUER_ID}_market_card_fallbacks.json"
GLOBAL_MARKET_ROWS_JSON = TEMP_DIR / f"{ISSUER_ID}_global_market_rows.json"
FAILURES_JSON = TEMP_DIR / f"{ISSUER_ID}_failures.json"

REQUEST_TIMEOUT = 90
MAX_RETRIES = 5
REQUEST_SLEEP_SECONDS = 1.0
MARKET_WORKERS = 2
PROPERTY_WORKERS = 1
PROGRESS_SAVE_EVERY = 20

PROPERTY_SEGMENTS = {"building", "spec-building", "build-suit", "land-sale", "land-lease"}
GLOBAL_MARKET_SKIP_COUNTRIES = {"Mexico"}

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
SESSION = requests.Session()
SESSION.trust_env = False

CSV_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_NAME_LOCAL",
    "LOCATION_ADDRESS",
    "LOCATION_ADDRESS_LOCAL",
    "LATITUDE",
    "LONGITUDE",
    "coord_source",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
]

STATE_CANONICAL = {
    "baja california": "Baja California",
    "baja california norte": "Baja California",
    "chihuahua": "Chihuahua",
    "coahuila": "Coahuila",
    "coahuila de zaragoza": "Coahuila",
    "estado de mexico": "Estado de Mexico",
    "mexico state": "Estado de Mexico",
    "mexico": "Estado de Mexico",
    "guanajuato": "Guanajuato",
    "jalisco": "Jalisco",
    "nuevo leon": "Nuevo Leon",
    "nle": "Nuevo Leon",
    "queretaro": "Queretaro",
    "queretaro de arteaga": "Queretaro",
    "reynosa": "Tamaulipas",
    "san luis potosi": "San Luis Potosi",
    "s.l.p.": "San Luis Potosi",
    "slp": "San Luis Potosi",
    "sonora": "Sonora",
    "tamaulipas": "Tamaulipas",
    "ciudad de mexico": "Mexico City",
    "cdmx": "Mexico City",
    "d.f": "Mexico City",
    "df": "Mexico City",
    "d f": "Mexico City",
}

CITY_STATE_HINTS = {
    "apodaca": "Nuevo Leon",
    "ciudad juarez": "Chihuahua",
    "cd juarez": "Chihuahua",
    "cuautitlan izcalli": "Estado de Mexico",
    "guadalajara": "Jalisco",
    "hermosillo": "Sonora",
    "irapuato": "Guanajuato",
    "ramos arizpe": "Coahuila",
    "reynosa": "Tamaulipas",
    "silao": "Guanajuato",
    "tijuana": "Baja California",
    "tlaquepaque": "Jalisco",
    "toluca": "Estado de Mexico",
}

COUNTRY_ALIASES = {
    "The Netherlands": "Netherlands",
    "UK": "United Kingdom",
    "UAE": "United Arab Emirates",
}

BRAZIL_STATE_CANONICAL = {
    "ac": "Acre",
    "al": "Alagoas",
    "am": "Amazonas",
    "ap": "Amapa",
    "ba": "Bahia",
    "ce": "Ceara",
    "df": "Distrito Federal",
    "es": "Espirito Santo",
    "go": "Goias",
    "ma": "Maranhao",
    "mg": "Minas Gerais",
    "ms": "Mato Grosso do Sul",
    "mt": "Mato Grosso",
    "pa": "Para",
    "pb": "Paraiba",
    "pe": "Pernambuco",
    "pi": "Piaui",
    "pr": "Parana",
    "rj": "Rio de Janeiro",
    "rn": "Rio Grande do Norte",
    "ro": "Rondonia",
    "rr": "Roraima",
    "rs": "Rio Grande do Sul",
    "sc": "Santa Catarina",
    "se": "Sergipe",
    "sp": "Sao Paulo",
    "to": "Tocantins",
}

ACTIVITY_BY_SEGMENT = {
    "building": "Building",
    "spec-building": "Spec Building",
    "build-suit": "Build Suit",
    "land-sale": "Land for Sale",
    "land-lease": "Land for Lease",
}

ACTIVITY_HINTS = {
    "building",
    "spec building",
    "build suit",
    "build to suit",
    "new development",
    "land for lease",
    "land for sale",
    "land lease",
    "land sale",
    "market office",
}

COUNTRY_ISO3_MAP = {
    "Belgium": "BEL",
    "Brazil": "BRA",
    "Canada": "CAN",
    "China": "CHN",
    "Czech Republic": "CZE",
    "France": "FRA",
    "Germany": "DEU",
    "Hong Kong SAR China": "HKG",
    "Hungary": "HUN",
    "India": "IND",
    "Italy": "ITA",
    "Japan": "JPN",
    "Luxembourg": "LUX",
    "Mexico": "MEX",
    "Netherlands": "NLD",
    "Poland": "POL",
    "Singapore": "SGP",
    "Slovakia": "SVK",
    "Spain": "ESP",
    "Sweden": "SWE",
    "United Arab Emirates": "ARE",
    "United Kingdom": "GBR",
    "United States": "USA",
}

POSTCODE_PATTERNS = [
    re.compile(r"\b[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}\b"),  # UK
    re.compile(r"\b[A-Z]\d[A-Z]\s?\d[A-Z]\d\b"),  # Canada
    re.compile(r"\bL-\d{4}\b"),  # Luxembourg
    re.compile(r"\b\d{5}-\d{3}\b"),  # Brazil
    re.compile(r"\b\d{8}\b"),  # Brazil without hyphen
    re.compile(r"\b\d{2}-\d{3}\b"),  # Poland
    re.compile(r"\b\d{3}-\d{4}\b"),  # Japan
    re.compile(r"\b\d{4}\s?[A-Z]{2}\b"),  # Netherlands
    re.compile(r"\b\d{3}\s?\d{2}\b"),  # Sweden
    re.compile(r"\b\d{6}\b"),  # China/India/Singapore
    re.compile(r"\b\d{5}(?:-\d{4})?\b"),  # US/Mexico/France/Germany/etc.
    re.compile(r"\b\d{4}\b"),
    re.compile(r"\b\d{3}\b"),
]


# ============================================================================
# GENERIC EXTRACTION LOGIC BELOW - Do not modify per-issuer
# ============================================================================
def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def write_json(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def ascii_text(value: str) -> str:
    replacements = {
        "\u2018": "'",
        "\u2019": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2013": "-",
        "\u2014": "-",
        "\u00a0": " ",
    }
    for src, dst in replacements.items():
        value = value.replace(src, dst)
    normalized = unicodedata.normalize("NFKD", value)
    return normalized.encode("ascii", "ignore").decode("ascii")


def clean_spaces(value: str) -> str:
    value = re.sub(r"\s+", " ", value.replace("\r", " ").replace("\n", " ")).strip()
    value = value.replace(" ,", ",").replace(" .", ".")
    value = re.sub(r"\s+,", ",", value)
    return value.strip(" ,")


def geocode_friendly_address(value: str) -> str:
    value = value.replace("#", " No. ")
    value = value.replace("S/N", "SN")
    value = clean_spaces(value)
    value = re.sub(r"\bN/A\b", "", value, flags=re.IGNORECASE)
    value = clean_spaces(value)
    return value


def canonicalize_url(url: str) -> str:
    url = url.strip()
    if url.startswith("http://"):
        url = "https://" + url[len("http://") :]
    url = url.split("#", 1)[0].rstrip("/")
    return url


def mirror_url(url: str) -> str:
    stripped = re.sub(r"^https?://", "", url.strip())
    return f"{MIRROR_PREFIX}{stripped}"


def fetch_mirror_text(url: str) -> str:
    last_error: Optional[str] = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = SESSION.get(
                mirror_url(url),
                timeout=REQUEST_TIMEOUT,
                headers={"User-Agent": "Mozilla/5.0 (compatible; Codex extractor)"},
                verify=False,
            )
            if response.status_code == 429:
                time.sleep(15.0 * attempt)
                last_error = f"attempt {attempt}: 429 Too Many Requests"
                continue
            response.raise_for_status()
            time.sleep(REQUEST_SLEEP_SECONDS)
            return response.text
        except Exception as exc:  # noqa: BLE001 - retried network fetch
            last_error = f"attempt {attempt}: {exc}"
            time.sleep(1.0 * attempt)
    raise RuntimeError(f"Unable to fetch mirror for {url}: {last_error}")


def extract_markdown(raw_text: str) -> str:
    marker = "Markdown Content:"
    if marker in raw_text:
        return raw_text.split(marker, 1)[1].strip()
    return raw_text.strip()


def parse_sitemap_urls(markdown: str) -> Tuple[List[str], List[str]]:
    urls = sorted(
        {
            canonicalize_url(match.group(1))
            for match in re.finditer(r"\((https://www\.prologis\.mx/en/industrial-properties/[^\s)]+)\)", markdown)
        }
    )

    property_urls: List[str] = []
    market_urls: List[str] = []
    for url in urls:
        parts = [part for part in urlparse(url).path.split("/") if part]
        if len(parts) < 3:
            continue
        if parts[0] != "en" or parts[1] != "industrial-properties":
            continue
        if len(parts) >= 4 and parts[2] in PROPERTY_SEGMENTS:
            property_urls.append(url)
        elif len(parts) == 3:
            market_urls.append(url)

    return sorted(set(property_urls)), sorted(set(market_urls))


def parse_browse_region_markets(markdown: str) -> List[Dict[str, str]]:
    lines = markdown.splitlines()
    browse_markers = [idx for idx, line in enumerate(lines) if line.strip() == "# Browse by Region"]
    start = browse_markers[-1] if browse_markers else 0

    entries: List[Dict[str, str]] = []
    current_country = ""
    seen_urls: set[str] = set()

    for raw_line in lines[start + 1 :]:
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("### "):
            current_country = normalize_country(line[4:])
            continue

        match = re.match(
            r"^\*\s+\[(?P<label>.+?)\]\((?P<url>https?://[^)]+/(?:industrial-properties|industrial-logistics-warehouse-space)[^)]+)\)",
            line,
        )
        if not match or not current_country:
            continue

        market_url = canonicalize_url(match.group("url"))
        if market_url in seen_urls:
            continue
        if any(f"/{segment}/" in market_url for segment in PROPERTY_SEGMENTS):
            continue

        entries.append(
            {
                "country": current_country,
                "market_label": clean_spaces(match.group("label")),
                "market_url": market_url,
            }
        )
        seen_urls.add(market_url)

    return entries


def clean_address_lines(lines: Iterable[str]) -> List[str]:
    cleaned: List[str] = []
    for raw_line in lines:
        line = raw_line.strip()
        if not line:
            continue
        line = re.sub(r"\s*\*\*.*$", "", line).strip()
        line = line.strip(" *")
        if not line or line.upper() == "N/A":
            continue
        line = clean_spaces(line)
        if not line:
            continue
        cleaned.append(line)
    return cleaned


def build_local_address(lines: Iterable[str]) -> str:
    return clean_spaces(", ".join(clean_address_lines(lines)))


def collapse_repeated_phrase(value: str) -> str:
    parts = clean_spaces(value).split()
    if len(parts) >= 2 and len(parts) % 2 == 0:
        midpoint = len(parts) // 2
        if parts[:midpoint] == parts[midpoint:]:
            return " ".join(parts[:midpoint])
    return clean_spaces(value)


def normalize_subnational_state(value: str, country: str) -> str:
    ascii_value = clean_spaces(ascii_text(value))
    if not ascii_value:
        return ""
    if country == "Brazil":
        key = collapse_repeated_phrase(ascii_value).lower()
        return BRAZIL_STATE_CANONICAL.get(key, collapse_repeated_phrase(ascii_value))
    if country == "Mexico":
        return canonical_state(ascii_value)
    return ascii_value


def infer_activity_from_url(url: str) -> str:
    for segment, activity in ACTIVITY_BY_SEGMENT.items():
        if f"/{segment}/" in url:
            return activity
    return "Building"


def clean_activity_label(value: str) -> str:
    cleaned = clean_spaces(ascii_text(value))
    if not cleaned:
        return ""
    lowered = cleaned.lower()
    if lowered in ACTIVITY_HINTS:
        if lowered.startswith("land for"):
            return cleaned
        if lowered == "build to suit":
            return "Build Suit"
        return cleaned.title()
    return cleaned


def canonical_state(value: str) -> str:
    key = ascii_text(value).lower().replace(".", " ")
    key = re.sub(r"\s+", " ", key).strip(" ,")
    return STATE_CANONICAL.get(key, clean_spaces(ascii_text(value)))


def choose_better_text(primary: str, fallback: str) -> str:
    return primary if len(primary) >= len(fallback) else fallback


def parse_mexico_address(
    address_lines_local: List[str],
    fallback: Optional[Dict[str, str]] = None,
    heading_fallback: Optional[Dict[str, str]] = None,
) -> Dict[str, str]:
    fallback = fallback or {}
    heading_fallback = heading_fallback or {}
    local_lines = clean_address_lines(address_lines_local)
    local_address = build_local_address(local_lines)
    ascii_address = geocode_friendly_address(ascii_text(local_address))

    lines_wo_country = [line for line in local_lines if ascii_text(line).lower() not in {"mexico", "country: mexico"}]
    postcode = fallback.get("postcode", "") or heading_fallback.get("postcode", "")
    city = fallback.get("city", "") or heading_fallback.get("city", "")
    state = fallback.get("state", "") or heading_fallback.get("state", "")

    candidates: List[str] = []
    if len(lines_wo_country) >= 2:
        candidates.append(clean_spaces(f"{lines_wo_country[-2]} {lines_wo_country[-1]}"))
    if lines_wo_country:
        candidates.append(lines_wo_country[-1])

    for candidate in candidates:
        candidate_ascii = clean_spaces(ascii_text(candidate))
        patterns = [
            re.match(r"(?P<pc>\d{5}),\s*(?P<city>[^,]+?)\s*,\s*(?P<state>[^,]+)$", candidate_ascii),
            re.match(r"(?P<city>[^,]+?),\s*(?P<state>[^,]+?)\s+(?P<pc>\d{5})$", candidate_ascii),
            re.match(r"(?P<city>[^,]+?),\s*(?P<pc>\d{5}),\s*(?P<state>[^,]+)$", candidate_ascii),
            re.match(r"(?P<metro>[^,]+),\s*(?P<city>[^,]+),\s*(?P<state>[^,]+?)\s+(?P<pc>\d{5})$", candidate_ascii),
            re.match(r"[^,]+,\s*\d{1,5},\s*(?P<city>[^,]+),\s*(?P<state>[^,]+)$", candidate_ascii),
        ]
        match = next((m for m in patterns if m), None)
        if match:
            groups = match.groupdict()
            postcode = groups.get("pc", postcode)
            city = groups.get("city", city)
            state = canonical_state(groups.get("state", state))
            break

        single = re.match(r"(?P<pc>\d{5}),\s*(?P<lemma>[^,]+)$", candidate_ascii)
        if single:
            postcode = single.group("pc")
            lemma = single.group("lemma")
            lemma_state = canonical_state(lemma)
            if lemma_state in {"Estado de Mexico", "Mexico City", "Nuevo Leon", "Baja California", "Chihuahua", "Coahuila", "Guanajuato", "Jalisco", "Queretaro", "San Luis Potosi", "Sonora", "Tamaulipas"}:
                state = lemma_state
                if len(lines_wo_country) >= 2:
                    city = ascii_text(lines_wo_country[-2]).strip(" ,")
            else:
                city = lemma
            break

    if not postcode:
        postcode_match = re.search(r"\b(\d{5})\b", ascii_address)
        if postcode_match:
            postcode = postcode_match.group(1)

    if not city and lines_wo_country:
        city = ascii_text(lines_wo_country[-1]).strip(" ,")
        city = re.sub(r"\b\d{5}\b", "", city).strip(" ,")
        city = re.sub(r"\b(?:Estado de )?Mexico\b$", "", city).strip(" ,")

    if not state and heading_fallback.get("state"):
        state = heading_fallback["state"]

    # Cuautitlan Izcalli / Estado de Mexico pages often only show "54713, Mexico".
    if city and not state and postcode and "Cuautitlan Izcalli" in ascii_text(city):
        state = "Estado de Mexico"

    if city and not state:
        hinted = CITY_STATE_HINTS.get(ascii_text(city).lower())
        if hinted:
            state = hinted

    if city and re.search(r"\d", city):
        split_city = [clean_spaces(part) for part in ascii_text(city).split(",") if clean_spaces(part)]
        if len(split_city) >= 2:
            if split_city[0].isdigit():
                city = split_city[1]
                if len(split_city) >= 3 and not state:
                    state = canonical_state(split_city[2])
            else:
                city = split_city[0]
                if len(split_city) >= 2 and not state:
                    state = canonical_state(split_city[1])

    city = clean_spaces(ascii_text(city))
    state = clean_spaces(ascii_text(state))
    postcode = clean_spaces(postcode)

    return {
        "location_address_local": local_address,
        "location_address": ascii_address,
        "postcode": postcode,
        "city": city,
        "state": state,
    }


def extract_coord(markdown: str) -> Tuple[str, str]:
    match = re.search(r"https://maps\.google\.com/maps\?ll=([-\d.]+),([-\d.]+)&", markdown)
    if match:
        return match.group(1), match.group(2)
    fallback = re.search(r"https://www\.google\.com/maps/@([-\d.]+),([-\d.]+),", markdown)
    if fallback:
        return fallback.group(1), fallback.group(2)
    return "", ""


def extract_property_title(markdown: str) -> str:
    match = re.search(r"^#\s+(.+?)(?:\s+\|\s+Prologis Property Search)?$", markdown, flags=re.MULTILINE)
    if not match:
        return ""
    return clean_spaces(match.group(1))


def extract_property_details(markdown: str) -> str:
    match = re.search(
        r"### Property Details\s*\n\n(?:Updated:\s+[^\n]+\n\n)?(?P<body>.*?)(?:\n\n\*\*Features\*\*|\n\n## Contact Us)",
        markdown,
        flags=re.DOTALL,
    )
    if not match:
        return ""
    return clean_spaces(match.group("body"))


def extract_features_block(markdown: str) -> str:
    match = re.search(r"\*\*Features\*\*\n\n(?P<body>.*?)(?:\n\n## Contact Us|\n\n## Unit Details)", markdown, flags=re.DOTALL)
    if not match:
        return ""
    lines = [clean_spaces(line) for line in match.group("body").splitlines() if clean_spaces(line)]
    return " ".join(lines)


def infer_activity(url: str, details: str, features: str) -> str:
    lower_details = details.lower()
    lower_features = features.lower()

    if "/build-suit/" in url or "/land-sale/" in url or "/land-lease/" in url:
        if "truck yard" in lower_features or "outdoor storage" in lower_features:
            return "Build-to-suit industrial land / truck yard / outdoor storage"
        return "Build-to-suit industrial land"

    if "/spec-building/" in url:
        if "industrial warehouse" in lower_details and "distribution" in lower_details:
            return "Spec industrial warehouse / distribution facility"
        if "industrial warehouse" in lower_details:
            return "Spec industrial warehouse"
        if "logistics facility" in lower_details:
            return "Spec logistics facility"
        return "Spec industrial warehouse"

    if "logistics facility" in lower_details and "warehouse" in lower_details:
        return "Industrial warehouse / logistics facility"
    if "industrial warehouse" in lower_details:
        return "Industrial warehouse"
    if "distribution" in lower_details:
        return "Distribution / logistics facility"
    return "Industrial property"


def extract_detail_address_lines(markdown: str) -> List[str]:
    match = re.search(
        r"\n\s*Address\s*\n\n(?P<body>.*?)(?:\n\n\s*Property Contacts\s*\n|\n\n\s*### Property Details\s*\n)",
        markdown,
        flags=re.DOTALL,
    )
    if not match:
        return []
    return clean_address_lines(match.group("body").splitlines())


def parse_market_cards(markdown: str, source_url: str) -> Dict[str, Dict[str, str]]:
    lines = markdown.splitlines()
    fallbacks: Dict[str, Dict[str, str]] = {}
    i = 0
    while i < len(lines):
        current = lines[i].strip()
        heading = re.match(r"### \[(?P<name>.+?)\]\((?P<url>https?://[^)]+)\)", current)
        if not heading:
            i += 1
            continue

        name_local = clean_spaces(heading.group("name"))
        detail_url = canonicalize_url(heading.group("url"))
        i += 1
        address_lines: List[str] = []
        while i < len(lines):
            probe = lines[i].strip()
            if re.match(r"### \[", probe) or probe.startswith("## ") or probe.startswith("[View All"):
                break
            if probe.startswith("*   ["):
                break
            if not probe:
                i += 1
                continue
            probe = re.sub(r"\s*\*\*Total.*$", "", probe).strip()
            if not probe or probe.startswith("Available ") or probe.startswith("Total ") or " SF " in probe and not re.search(r"\b\d{5}\b", probe):
                i += 1
                continue
            address_lines.append(probe)
            i += 1

        parsed = parse_mexico_address(address_lines)
        fallbacks[detail_url] = {
            "name_local": name_local,
            "location_address_local": parsed["location_address_local"],
            "location_address": parsed["location_address"],
            "postcode": parsed["postcode"],
            "city": parsed["city"],
            "state": parsed["state"],
            "market_source_url": source_url,
        }
    return fallbacks


def parse_heading_fallback(name_local: str) -> Dict[str, str]:
    ascii_name = ascii_text(name_local)
    parts = [clean_spaces(part) for part in ascii_name.split(",") if clean_spaces(part)]
    city = ""
    state = ""

    if len(parts) >= 2:
        city = parts[0]
        state = canonical_state(parts[1])

    if ascii_name.startswith("Monterrey, Apodaca"):
        city = "Apodaca"
        state = "Nuevo Leon"
    elif ascii_name.startswith("Mexico City, D.F"):
        city = "Mexico City"
        state = "Mexico City"
    elif ascii_name.startswith("CD Juarez"):
        city = "CD Juarez"
        state = "Chihuahua"

    return {"city": city, "state": state}


def normalize_country(value: str) -> str:
    cleaned = clean_spaces(ascii_text(value.replace("Country:", "")))
    return COUNTRY_ALIASES.get(cleaned, cleaned)


def country_iso3(country: str) -> str:
    return COUNTRY_ISO3_MAP.get(country, "")


def parse_office_heading_fallback(name_local: str, country: str) -> Dict[str, str]:
    ascii_name = clean_spaces(ascii_text(name_local))
    parts = [clean_spaces(part) for part in ascii_name.split(",") if clean_spaces(part)]
    city = parts[0] if parts else ""
    state = ""

    country_tokens = {country.lower()}
    if country == "United Kingdom":
        country_tokens.add("uk")
    if country == "United States":
        country_tokens.add("usa")
    if country == "United Arab Emirates":
        country_tokens.add("uae")
    if country == "Netherlands":
        country_tokens.add("the netherlands")

    for part in parts[1:]:
        if part.lower() in country_tokens:
            continue
        state = normalize_subnational_state(part, country)
        break

    if ascii_name.startswith("Monterrey, Apodaca"):
        city = "Apodaca"
        state = "Nuevo Leon"
    elif ascii_name.startswith("Mexico City, D.F"):
        city = "Mexico City"
        state = "Mexico City"
    elif ascii_name.startswith("CD Juarez"):
        city = "CD Juarez"
        state = "Chihuahua"
    elif ascii_name.startswith("Seattle, WA (Federal Way)"):
        city = "Federal Way"
        state = "WA"
    elif ascii_name.startswith("Hong Kong"):
        city = "Hong Kong"
    elif ascii_name.startswith("Luxembourg"):
        city = "Luxembourg"

    return {"city": city, "state": state}


def extract_postcode_value(lines: List[str]) -> str:
    for line in reversed(lines):
        for pattern in POSTCODE_PATTERNS:
            match = pattern.search(line)
            if match:
                return match.group(0)
    return ""


def strip_country_suffix(value: str, country: str) -> str:
    value = clean_spaces(value.strip(" ,-"))
    country_ascii = ascii_text(country)
    if value.lower().endswith(country_ascii.lower()):
        value = value[: -len(country_ascii)].rstrip(" ,-")
    return clean_spaces(value)


def parse_global_office_address(
    address_lines_local: List[str],
    name_local: str,
    country: str,
) -> Dict[str, str]:
    local_lines = clean_address_lines(address_lines_local)
    if country == "Mexico":
        return parse_mexico_address(local_lines, heading_fallback=parse_office_heading_fallback(name_local, country))

    if len(local_lines) >= 2:
        ascii_tail = [clean_spaces(ascii_text(item)) for item in local_lines[-2:]]
        if extract_postcode_value([ascii_tail[-1]]) == ascii_tail[-1]:
            local_lines = local_lines[:-2] + [clean_spaces(f"{local_lines[-2]} {local_lines[-1]}")]

    local_address = build_local_address(local_lines)
    ascii_address = geocode_friendly_address(ascii_text(local_address))
    ascii_lines = [clean_spaces(ascii_text(line)) for line in local_lines]
    heading_fallback = parse_office_heading_fallback(name_local, country)

    postcode = extract_postcode_value(ascii_lines)
    city = ""
    state = ""
    brazil_state_names = {value.lower() for value in BRAZIL_STATE_CANONICAL.values()}

    def apply_line_patterns(line: str) -> bool:
        nonlocal city, state, postcode
        line_wo_pc = line
        if postcode:
            line_wo_pc = clean_spaces(re.sub(re.escape(postcode), "", line_wo_pc, count=1).strip(" ,-"))
            comma_parts = [clean_spaces(part) for part in line_wo_pc.split(",") if clean_spaces(part)]
            if len(comma_parts) >= 2:
                city = strip_country_suffix(comma_parts[0], country)
                state = clean_spaces(comma_parts[1])
                return True
            if country == "Brazil":
                tokens = line_wo_pc.split()
                for size in (2, 1):
                    if len(tokens) <= size:
                        continue
                    candidate = " ".join(tokens[-size:])
                    normalized_state = normalize_subnational_state(candidate, country)
                    if candidate.lower() in BRAZIL_STATE_CANONICAL or candidate.lower() in brazil_state_names or normalized_state != clean_spaces(ascii_text(candidate)):
                        city = " ".join(tokens[:-size])
                        state = normalized_state
                        return True
        patterns = [
            re.match(
                r"^(?P<city>[^,]+),\s*(?P<state>[^,]+)\s+(?P<pc>[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}|[A-Z]\d[A-Z]\s?\d[A-Z]\d|L-\d{4}|\d{4}\s?[A-Z]{2}|\d{3}\s?\d{2}|\d{2}-\d{3}|\d{3}-\d{4}|\d{5}-\d{3}|\d{6}|\d{5}(?:-\d{4})?|\d{4}|\d{3})$",
                line,
            ),
            re.match(
                r"^(?P<city>[^,]+)-(?P<state>[A-Za-z]{2,20})\s+(?P<pc>[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}|[A-Z]\d[A-Z]\s?\d[A-Z]\d|L-\d{4}|\d{4}\s?[A-Z]{2}|\d{3}\s?\d{2}|\d{2}-\d{3}|\d{3}-\d{4}|\d{5}-\d{3}|\d{6}|\d{5}(?:-\d{4})?|\d{4}|\d{3})$",
                line,
            ),
            re.match(
                r"^(?P<city>[^,]+)\s+(?P<state>[A-Za-z]{2,20})\s+(?P<pc>[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}|[A-Z]\d[A-Z]\s?\d[A-Z]\d|L-\d{4}|\d{4}\s?[A-Z]{2}|\d{3}\s?\d{2}|\d{2}-\d{3}|\d{3}-\d{4}|\d{5}-\d{3}|\d{6}|\d{5}(?:-\d{4})?|\d{4}|\d{3})$",
                line,
            ),
            re.match(
                r"^(?P<city>.+?)\s+(?P<pc>[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}|[A-Z]\d[A-Z]\s?\d[A-Z]\d|L-\d{4}|\d{4}\s?[A-Z]{2}|\d{3}\s?\d{2}|\d{2}-\d{3}|\d{3}-\d{4}|\d{5}-\d{3}|\d{6}|\d{5}(?:-\d{4})?|\d{4}|\d{3})$",
                line,
            ),
            re.match(
                r"^(?P<pc>[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}|[A-Z]\d[A-Z]\s?\d[A-Z]\d|L-\d{4}|\d{4}\s?[A-Z]{2}|\d{3}\s?\d{2}|\d{2}-\d{3}|\d{3}-\d{4}|\d{5}-\d{3}|\d{6}|\d{5}(?:-\d{4})?|\d{4}|\d{3})\s*[-,]?\s*(?P<city>.+)$",
                line,
            ),
        ]
        for match in patterns:
            if not match:
                continue
            groups = match.groupdict()
            postcode = groups.get("pc", postcode) or postcode
            city = strip_country_suffix(groups.get("city", ""), country)
            state = clean_spaces(groups.get("state", ""))
            return True
        if postcode:
            no_postcode_patterns = [
                re.match(r"^(?P<city>[^,]+),\s*(?P<state>[^,]+)$", line),
                re.match(r"^(?P<city>[^,]+)\s+(?P<state>[A-Za-z]{2,40})$", line),
            ]
            for match in no_postcode_patterns:
                if not match:
                    continue
                groups = match.groupdict()
                city = strip_country_suffix(groups.get("city", ""), country)
                state = clean_spaces(groups.get("state", ""))
                return True
        return False

    candidates = []
    if ascii_lines:
        candidates.append(ascii_lines[-1])
    if len(ascii_lines) >= 2:
        candidates.append(ascii_lines[-2])
    if len(ascii_lines) >= 3:
        candidates.append(ascii_lines[-3])
    if postcode and len(ascii_lines) >= 2 and ascii_lines[-1] == postcode:
        candidates.insert(0, clean_spaces(f"{ascii_lines[-2]} {ascii_lines[-1]}"))

    for candidate in candidates:
        if apply_line_patterns(candidate):
            break

    if not city and len(ascii_lines) >= 2 and postcode and postcode in ascii_lines[-2]:
        if ascii_lines[-1] and not any(ch.isdigit() for ch in ascii_lines[-1]):
            city = strip_country_suffix(ascii_lines[-1], country)

    if city and len(ascii_lines) >= 2:
        last_line = ascii_lines[-1]
        if not any(ch.isdigit() for ch in last_line) and clean_spaces(last_line.lower()) != clean_spaces(city.lower()):
            if not state:
                state = strip_country_suffix(last_line, country)

    if not city and ascii_lines:
        tail = strip_country_suffix(ascii_lines[-1], country)
        if tail and not any(ch.isdigit() for ch in tail):
            city = tail

    city = clean_spaces(city or heading_fallback.get("city", ""))
    state = normalize_subnational_state(state or heading_fallback.get("state", ""), country)

    return {
        "location_address_local": local_address,
        "location_address": ascii_address,
        "postcode": clean_spaces(postcode),
        "state": state,
        "city": clean_spaces(city),
    }


def parse_office_locations(markdown: str, source_url: str) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    if "## Americas" not in markdown:
        return rows

    office_section = markdown.split("## Americas", 1)[1]
    if "## Footer" in office_section:
        office_section = office_section.split("## Footer", 1)[0]

    lines = office_section.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line.startswith("### "):
            i += 1
            continue

        name_local = clean_spaces(line[4:])
        i += 1
        block: List[str] = []
        while i < len(lines):
            probe = lines[i].strip()
            if probe.startswith("### ") or probe.startswith("## ") or probe.startswith("[View All"):
                break
            block.append(probe)
            i += 1

        country_line = next((item for item in block if item.startswith("Country:")), "")
        if not country_line:
            continue
        country = normalize_country(country_line)

        address_lines: List[str] = []
        for item in block:
            if not item:
                continue
            if item.startswith("Country:"):
                break
            if item.startswith("Phone:") or item.startswith("[Learn more"):
                continue
            address_lines.append(item)

        parsed = parse_global_office_address(address_lines, name_local, country)
        rows.append(
            {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": clean_spaces(ascii_text(name_local)),
                "LOCATION_NAME_LOCAL": name_local,
                "LOCATION_ADDRESS": parsed["location_address"],
                "LOCATION_ADDRESS_LOCAL": parsed["location_address_local"],
                "LATITUDE": "",
                "LONGITUDE": "",
                "coord_source": "not_on_website",
                "COUNTRY": country,
                "COUNTRY_ISO3": country_iso3(country),
                "POSTCODE": parsed["postcode"],
                "STATE": parsed["state"],
                "CITY": parsed["city"],
                "SOURCE_URL": canonicalize_url(source_url),
                "SOURCE_TYPE": SOURCE_TYPE,
                "ACTIVITY_AT_ASSET": "Market office",
            }
        )
    return rows


def parse_market_page_rows(markdown: str, market_entry: Dict[str, str]) -> List[Dict[str, str]]:
    rows_by_url: Dict[str, Dict[str, str]] = {}
    lines = markdown.splitlines()
    market_country = normalize_country(market_entry["country"])
    market_label = market_entry["market_label"]

    def is_metric_line(value: str) -> bool:
        return any(token in value for token in [" SF", " SQM", " tsu", " AC", " HA"]) and any(ch.isdigit() for ch in value)

    def inferred_city_fallback(name_local: str) -> str:
        if market_country == "Brazil":
            match = re.search(r"Prologis\s+([A-Za-z]+)", ascii_text(name_local))
            if match:
                return clean_spaces(match.group(1))
        return clean_spaces(ascii_text(market_label))

    def row_quality(row: Dict[str, str]) -> Tuple[int, int]:
        score = 0
        if row["LOCATION_ADDRESS"] and "http" not in row["LOCATION_ADDRESS"] and "[](" not in row["LOCATION_ADDRESS"]:
            score += 3
        if row["CITY"] and re.search(r"[A-Za-z]", row["CITY"]) and not any(ch.isdigit() for ch in row["CITY"]):
            score += 2
        if row["STATE"] and "http" not in row["STATE"] and "[](" not in row["STATE"]:
            score += 2
        if row["POSTCODE"]:
            score += 1
        if row["ACTIVITY_AT_ASSET"]:
            score += 1
        return score, len(row["LOCATION_ADDRESS"])

    i = 0
    while i < len(lines):
        current = lines[i].strip()
        heading = re.search(r"###\s+\[(?P<name>.+?)\]\((?P<url>https?://[^)]+)\)", current)
        if not heading:
            i += 1
            continue

        detail_url = canonicalize_url(heading.group("url"))
        if "/industrial-properties/" not in detail_url or not any(f"/{segment}/" in detail_url for segment in PROPERTY_SEGMENTS):
            i += 1
            continue

        name_local = clean_spaces(heading.group("name"))
        i += 1
        block_lines: List[str] = []
        while i < len(lines):
            probe = lines[i].strip()
            if (
                re.search(r"###\s+\[", probe)
                or probe.startswith("### ")
                or probe.startswith("## ")
                or probe.startswith("[Load More")
                or probe == "Load More"
                or probe.startswith("Map data")
                or probe.startswith("←")
                or probe.startswith("→")
                or probe.startswith("↑")
                or probe.startswith("↓")
                or probe.startswith("+Zoom")
                or probe.startswith("-Zoom")
                or probe.startswith("Home ")
                or probe.startswith("End ")
                or probe.startswith("Page Up")
                or probe.startswith("Page Down")
            ):
                break
            block_lines.append(probe)
            i += 1

        address_lines: List[str] = []
        activity = infer_activity_from_url(detail_url)

        for raw_block_line in block_lines:
            line = clean_spaces(raw_block_line)
            if not line:
                continue
            if line.startswith("![") or line.startswith("[]("):
                continue
            if (line.startswith("*") or line.startswith("* ")) and "Available" in line:
                continue
            if "](http" in line or "](https" in line:
                continue
            if line in {"Compare", "Compare Properties", "Unit of Measurement", "US", "Metric", "Grid view Carousel view"}:
                continue
            if line.startswith("Sort by") or line.startswith("Most Space Available") or line.startswith("Soonest Available"):
                continue
            if line.startswith("Available "):
                continue
            if line.startswith("[") and ("LEARN MORE" in line.upper() or "Learn more" in line or "View more" in line):
                continue
            if line in {"Total Available", "Total Area", "Total Building Size"}:
                break
            if is_metric_line(line) or line.startswith("SQM:"):
                continue

            if "**Total Available**" in line or "**Total Area**" in line:
                prefix = clean_spaces(re.sub(r"\*\*Total.*$", "", line))
                prefix = clean_spaces(re.sub(r"\[(?:View more|LEARN MORE|Learn more)\]\([^)]+\)", "", prefix))
                if prefix:
                    if prefix.lower().startswith(market_country.lower()):
                        remainder = clean_spaces(prefix[len(market_country) :])
                        cleaned_activity = clean_activity_label(remainder)
                        if cleaned_activity:
                            activity = cleaned_activity
                    else:
                        cleaned_activity = clean_activity_label(prefix)
                        if cleaned_activity:
                            activity = cleaned_activity
                        else:
                            address_lines.append(prefix)
                break

            cleaned_activity = clean_activity_label(line)
            if cleaned_activity and cleaned_activity.lower() in ACTIVITY_HINTS:
                activity = cleaned_activity
                continue

            if normalize_country(line) == market_country:
                continue

            address_lines.append(line)

        parsed = parse_global_office_address(address_lines, market_label, market_country)
        if not re.search(r"[A-Za-z]", parsed["city"]):
            parsed["city"] = inferred_city_fallback(name_local)
        if market_country == "Brazil" and not re.search(r"[A-Za-z]", parsed["state"]):
            parsed["city"] = inferred_city_fallback(name_local)
            parsed["state"] = normalize_subnational_state(market_label, market_country)
        address_ascii = ascii_text(parsed["location_address_local"]).lower()
        if parsed["city"] and parsed["city"].lower() not in address_ascii:
            extra_parts = [parsed["city"]]
            if parsed["state"] and parsed["state"].lower() not in address_ascii:
                extra_parts.append(parsed["state"])
            if parsed["postcode"] and parsed["postcode"] not in parsed["location_address_local"]:
                extra_parts.append(parsed["postcode"])
            parsed["location_address_local"] = build_local_address([parsed["location_address_local"], ", ".join(extra_parts)])
            parsed["location_address"] = geocode_friendly_address(ascii_text(parsed["location_address_local"]))

        row = {
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": clean_spaces(ascii_text(name_local)),
            "LOCATION_NAME_LOCAL": name_local,
            "LOCATION_ADDRESS": parsed["location_address"],
            "LOCATION_ADDRESS_LOCAL": parsed["location_address_local"],
            "LATITUDE": "",
            "LONGITUDE": "",
            "coord_source": "not_on_website",
            "COUNTRY": market_country,
            "COUNTRY_ISO3": country_iso3(market_country),
            "POSTCODE": parsed["postcode"],
            "STATE": parsed["state"],
            "CITY": parsed["city"],
            "SOURCE_URL": detail_url,
            "SOURCE_TYPE": SOURCE_TYPE,
            "ACTIVITY_AT_ASSET": activity,
        }
        existing = rows_by_url.get(detail_url)
        if not existing or row_quality(row) > row_quality(existing):
            rows_by_url[detail_url] = row

    return list(rows_by_url.values())


def parse_contact_page(markdown: str, source_url: str) -> Optional[Dict[str, str]]:
    match = re.search(r"##\s+Mexico\s*\n\n(?P<body>.*?)(?:\n\n##\s+LET'S GET STARTED|\Z)", markdown, flags=re.DOTALL)
    if not match:
        return None

    lines = [clean_spaces(line) for line in match.group("body").splitlines() if clean_spaces(line)]
    address_lines: List[str] = []
    for line in lines:
        if line == "Mexico":
            continue
        if line.startswith("+52") or line.startswith("Contact Us"):
            break
        address_lines.append(line)

    parsed = parse_mexico_address(address_lines, heading_fallback={"city": "Mexico City", "state": "Mexico City"})
    if not parsed["location_address"] or not parsed["city"]:
        return None

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": "Prologis Mexico Office",
        "LOCATION_NAME_LOCAL": "Prologis Mexico Office",
        "LOCATION_ADDRESS": parsed["location_address"],
        "LOCATION_ADDRESS_LOCAL": parsed["location_address_local"],
        "LATITUDE": "",
        "LONGITUDE": "",
        "coord_source": "not_on_website",
        "COUNTRY": COUNTRY,
        "COUNTRY_ISO3": COUNTRY_ISO3,
        "POSTCODE": parsed["postcode"],
        "STATE": parsed["state"] or "Mexico City",
        "CITY": parsed["city"] or "Mexico City",
        "SOURCE_URL": canonicalize_url(source_url),
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": "Market office",
    }


def parse_property_page(detail_url: str, markdown: str, fallback: Optional[Dict[str, str]]) -> Dict[str, str]:
    fallback = fallback or {}
    name_local = extract_property_title(markdown) or fallback.get("name_local", "")
    details = extract_property_details(markdown)
    features = extract_features_block(markdown)
    detail_lines = extract_detail_address_lines(markdown)

    detail_fields = parse_mexico_address(detail_lines)
    best_local_address = detail_fields["location_address_local"] or fallback.get("location_address_local", "")
    if not best_local_address:
        best_local_address = fallback.get("location_address_local", "")
    best_ascii_address = geocode_friendly_address(ascii_text(best_local_address))

    postcode = detail_fields["postcode"] or fallback.get("postcode", "")
    city = detail_fields["city"] or fallback.get("city", "")
    state = detail_fields["state"] or fallback.get("state", "")

    latitude, longitude = extract_coord(markdown)
    coord_source = "website" if latitude and longitude else "not_on_website"

    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": clean_spaces(ascii_text(name_local)),
        "LOCATION_NAME_LOCAL": name_local,
        "LOCATION_ADDRESS": best_ascii_address,
        "LOCATION_ADDRESS_LOCAL": best_local_address,
        "LATITUDE": latitude,
        "LONGITUDE": longitude,
        "coord_source": coord_source,
        "COUNTRY": COUNTRY,
        "COUNTRY_ISO3": COUNTRY_ISO3,
        "POSTCODE": clean_spaces(postcode),
        "STATE": clean_spaces(ascii_text(state)),
        "CITY": clean_spaces(ascii_text(city)),
        "SOURCE_URL": canonicalize_url(detail_url),
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": infer_activity(detail_url, details, features),
    }


def write_csv(path: Path, rows: List[Dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


def save_progress(
    rows: List[Dict[str, str]],
    failures: List[Dict[str, str]],
    started_at: float,
    market_completed: int,
    market_total: int,
    detail_completed: int,
    detail_total: int,
) -> None:
    write_json(PARTIAL_ROWS_JSON, rows)
    write_json(FAILURES_JSON, failures)
    write_json(
        PROGRESS_JSON,
        {
            "updated_at": now_iso(),
            "completed_market_pages": market_completed,
            "total_market_pages": market_total,
            "completed_detail_pages": detail_completed,
            "total_detail_pages": detail_total,
            "row_count": len(rows),
            "failure_count": len(failures),
            "elapsed_seconds": round(time.monotonic() - started_at, 2),
        },
    )


def office_duplicate_key(row: Dict[str, str]) -> Tuple[str, str, str]:
    return (
        clean_spaces(row["LOCATION_ADDRESS"].lower()),
        clean_spaces(row["CITY"].lower()),
        clean_spaces(row["STATE"].lower()),
    )


def dedupe_office_rows(existing_rows: List[Dict[str, str]], candidate_rows: List[Dict[str, str]]) -> List[Dict[str, str]]:
    seen = {office_duplicate_key(row) for row in existing_rows if "/industrial-properties/" not in row["SOURCE_URL"]}
    output = list(existing_rows)
    for row in candidate_rows:
        key = office_duplicate_key(row)
        if key in seen:
            continue
        output.append(row)
        seen.add(key)
    return output


def has_matching_office_row(existing_rows: List[Dict[str, str]], candidate: Dict[str, str]) -> bool:
    candidate_city = clean_spaces(candidate["CITY"].lower())
    candidate_state = clean_spaces(candidate["STATE"].lower())
    candidate_postcode = clean_spaces(candidate["POSTCODE"])
    candidate_address = clean_spaces(candidate["LOCATION_ADDRESS"].lower())
    for row in existing_rows:
        if "/industrial-properties/" in row["SOURCE_URL"]:
            continue
        if clean_spaces(row["CITY"].lower()) != candidate_city:
            continue
        if clean_spaces(row["STATE"].lower()) != candidate_state:
            continue
        if clean_spaces(row["POSTCODE"]) == candidate_postcode:
            return True
        if candidate_address and candidate_address in clean_spaces(row["LOCATION_ADDRESS"].lower()):
            return True
    return False


def normalize_name_key(value: str) -> str:
    normalized = ascii_text(value).lower()
    normalized = re.sub(r"[^a-z0-9]+", " ", normalized)
    return clean_spaces(normalized)


def property_duplicate_key(row: Dict[str, str]) -> Tuple[str, str, str, str, str]:
    return (
        normalize_name_key(row["LOCATION_NAME"]),
        clean_spaces(row["LOCATION_ADDRESS"].lower()),
        clean_spaces(row["CITY"].lower()),
        clean_spaces(row["STATE"].lower()),
        clean_spaces(row["COUNTRY"].lower()),
    )


def dedupe_property_rows(rows: List[Dict[str, str]]) -> List[Dict[str, str]]:
    seen: set[Tuple[str, str, str, str, str]] = set()
    output: List[Dict[str, str]] = []
    for row in rows:
        key = property_duplicate_key(row)
        if key in seen:
            continue
        seen.add(key)
        output.append(row)
    return output


def sort_rows(rows: List[Dict[str, str]]) -> List[Dict[str, str]]:
    return sorted(
        rows,
        key=lambda row: (
            row["COUNTRY"],
            row["CITY"],
            row["STATE"],
            row["LOCATION_NAME"],
            row["SOURCE_URL"],
        ),
    )


def main() -> None:
    ensure_dir(TEMP_DIR)
    ensure_dir(OUTPUT_DIR)

    started_at = time.monotonic()

    failures: List[Dict[str, str]] = []
    checkpoint_written = False

    browse_raw = fetch_mirror_text(BROWSE_BY_REGION_URL)
    BROWSE_REGION_TXT.write_text(browse_raw, encoding="utf-8")
    browse_markdown = extract_markdown(browse_raw)
    browse_market_entries = parse_browse_region_markets(browse_markdown)
    write_json(MARKET_URLS_JSON, browse_market_entries)

    global_market_entries = [
        entry for entry in browse_market_entries if normalize_country(entry["country"]) not in GLOBAL_MARKET_SKIP_COUNTRIES
    ]

    global_market_rows: List[Dict[str, str]] = []
    market_total = len(global_market_entries)
    for market_completed, market_entry in enumerate(global_market_entries, start=1):
        try:
            market_markdown = extract_markdown(fetch_mirror_text(market_entry["market_url"]))
            for row in parse_market_page_rows(market_markdown, market_entry):
                if not row["LOCATION_ADDRESS"] or not row["CITY"]:
                    failures.append(
                        {
                            "source_url": row["SOURCE_URL"] or market_entry["market_url"],
                            "error": "Missing mandatory LOCATION_ADDRESS or CITY from market card",
                            "stage": "browse_by_region_market",
                        }
                    )
                    continue
                global_market_rows.append(row)
            global_market_rows = dedupe_property_rows(global_market_rows)
        except Exception as exc:  # noqa: BLE001 - record non-fatal market failures
            failures.append(
                {
                    "source_url": market_entry["market_url"],
                    "error": str(exc),
                    "stage": "browse_by_region_market",
                }
            )

        if market_completed % PROGRESS_SAVE_EVERY == 0 or market_completed == market_total:
            save_progress(
                rows=global_market_rows,
                failures=failures,
                started_at=started_at,
                market_completed=market_completed,
                market_total=market_total,
                detail_completed=0,
                detail_total=0,
            )

        if not checkpoint_written and len(global_market_rows) >= COUNT_THRESHOLD:
            write_csv(CHECKPOINT_CSV, sort_rows(global_market_rows))
            checkpoint_written = True

    write_json(GLOBAL_MARKET_ROWS_JSON, sort_rows(global_market_rows))

    sitemap_raw = fetch_mirror_text(SITEMAP_URL)
    SITEMAP_TXT.write_text(sitemap_raw, encoding="utf-8")
    sitemap_markdown = extract_markdown(sitemap_raw)

    property_urls, mexico_market_urls = parse_sitemap_urls(sitemap_markdown)
    write_json(PROPERTY_URLS_JSON, property_urls)

    market_fallbacks: Dict[str, Dict[str, str]] = {}
    for market_url in mexico_market_urls:
        try:
            market_markdown = extract_markdown(fetch_mirror_text(market_url))
            market_fallbacks.update(parse_market_cards(market_markdown, market_url))
        except Exception as exc:  # noqa: BLE001 - capture non-fatal market failures
            failures.append({"source_url": market_url, "error": str(exc), "stage": "mexico_market_fallback"})

    write_json(MARKET_CARD_JSON, market_fallbacks)

    mexico_property_rows: List[Dict[str, str]] = []

    def worker(detail_url: str) -> Dict[str, str]:
        markdown = extract_markdown(fetch_mirror_text(detail_url))
        return parse_property_page(detail_url, markdown, market_fallbacks.get(detail_url))

    with ThreadPoolExecutor(max_workers=PROPERTY_WORKERS) as pool:
        future_map = {pool.submit(worker, url): url for url in property_urls}
        detail_total = len(future_map)
        detail_completed = 0
        for future in as_completed(future_map):
            detail_url = future_map[future]
            detail_completed += 1
            try:
                row = future.result()
                if not row["LOCATION_ADDRESS"] or not row["CITY"]:
                    raise ValueError("Missing mandatory LOCATION_ADDRESS or CITY")
                mexico_property_rows.append(row)
            except Exception as exc:  # noqa: BLE001 - record detail failures for review
                failures.append({"source_url": detail_url, "error": str(exc), "stage": "mexico_detail"})

            if detail_completed % PROGRESS_SAVE_EVERY == 0 or detail_completed == detail_total:
                current_rows = dedupe_property_rows(mexico_property_rows + global_market_rows)
                save_progress(
                    rows=current_rows,
                    failures=failures,
                    started_at=started_at,
                    market_completed=market_total,
                    market_total=market_total,
                    detail_completed=detail_completed,
                    detail_total=detail_total,
                )

            if not checkpoint_written:
                current_rows = dedupe_property_rows(mexico_property_rows + global_market_rows)
                if len(current_rows) >= COUNT_THRESHOLD:
                    write_csv(CHECKPOINT_CSV, sort_rows(current_rows))
                    checkpoint_written = True

    property_rows = dedupe_property_rows(mexico_property_rows + global_market_rows)

    office_rows = parse_office_locations(extract_markdown(fetch_mirror_text(OFFICE_LOCATIONS_URL)), OFFICE_LOCATIONS_URL)
    contact_row = parse_contact_page(extract_markdown(fetch_mirror_text(CONTACT_URL)), CONTACT_URL)
    if contact_row and not has_matching_office_row(office_rows, contact_row):
        office_rows = dedupe_office_rows(office_rows, [contact_row])

    final_rows = dedupe_office_rows(sort_rows(property_rows), office_rows)
    final_rows = sort_rows(final_rows)

    if not checkpoint_written and len(final_rows) >= COUNT_THRESHOLD:
        write_csv(CHECKPOINT_CSV, final_rows)
        checkpoint_written = True

    write_csv(FINAL_CSV, final_rows)

    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "generated_at": now_iso(),
        "browse_market_url_count": len(browse_market_entries),
        "global_market_url_count": len(global_market_entries),
        "global_market_rows_kept": len(global_market_rows),
        "mexico_property_url_count": len(property_urls),
        "mexico_market_fallback_url_count": len(mexico_market_urls),
        "mexico_property_rows_kept": len(mexico_property_rows),
        "office_rows_added": len(final_rows) - len(property_rows),
        "final_row_count": len(final_rows),
        "count_threshold": COUNT_THRESHOLD,
        "threshold_gap": max(COUNT_THRESHOLD - len(final_rows), 0),
        "checkpoint_written": checkpoint_written,
        "failure_count": len(failures),
        "rows_with_blank_address": sum(1 for row in final_rows if not row["LOCATION_ADDRESS"]),
        "rows_with_blank_city": sum(1 for row in final_rows if not row["CITY"]),
        "rows_with_blank_state": sum(1 for row in final_rows if not row["STATE"]),
        "rows_with_blank_latlon": sum(1 for row in final_rows if not row["LATITUDE"] or not row["LONGITUDE"]),
        "elapsed_seconds": round(time.monotonic() - started_at, 2),
        "final_csv": str(FINAL_CSV),
        "checkpoint_csv": str(CHECKPOINT_CSV) if checkpoint_written else "",
    }
    write_json(SUMMARY_JSON, summary)

    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
