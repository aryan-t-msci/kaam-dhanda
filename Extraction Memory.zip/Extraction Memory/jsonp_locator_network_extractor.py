"""
Reusable JSONP locator extractor with issuer-specific supplement hooks.

This script handles locator pages that load structured location arrays through a
JSONP endpoint referenced by a static HTML page and companion JavaScript file.
It also supports issuer-specific supplemental sources such as static office
pages, Next.js `__NEXT_DATA__` payloads, and report PDFs.

How to adapt for a new issuer:
- Update only the CONFIGURATION block.
- Point `API_CHANNELS` to the relevant channel IDs and activity labels.
- Replace or extend the supplemental parser functions if the issuer has extra
  static pages or report-based offices.

Usage:
    python jsonp_locator_network_extractor.py
"""

from __future__ import annotations

import ast
import csv
import json
import re
import unicodedata
from collections import Counter
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import fitz
import requests
from bs4 import BeautifulSoup


# ============================================================================
# CONFIGURATION - Edit this block for each new issuer
# ============================================================================
ISSUER_ID = "IID000000002158979"
ISSUER_NAME = "BANCO BRADESCO S.A."

COUNT_THRESHOLD = 40

TEMP_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp"
)
OUTPUT_DIR = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output"
)
MEMORY_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Extraction Memory")

FINAL_OUTPUT_PATH = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
CHECKPOINT_PATH = TEMP_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_checkpoint.csv"
PROGRESS_PATH = TEMP_DIR / f"{ISSUER_ID}_progress.json"
SUMMARY_PATH = TEMP_DIR / f"{ISSUER_ID}_summary.json"

NETWORK_PAGE_URL = (
    "https://banco.bradesco/html/pessoajuridica/atendimento/rede-de-atendimento/index.shtm"
)
JSONP_ENDPOINT = (
    "https://wspf.bradesco.com.br/wsAtendimentoInstitucional/Site/Request.aspx"
)
INTERNATIONAL_UNITS_URL = (
    "https://banco.bradesco/html/corporate/atendimento/comercio-exterior/"
    "unidades-negocio-exterior.shtm"
)
ASSET_INTERNATIONAL_URL = "https://bradescoasset.com.br/pt/a-bradesco-asset/internacional"
SUPPLIED_PDF_URL = (
    "https://files.mziq.com/e3c842272756ed56849ab45bde942f432930378c593f9ad3ec7dbe025ad01f10.pdf"
)
SUPPLIED_PDF_PATH = TEMP_DIR / "bradesco_supplied.pdf"

API_CHANNELS = [
    {
        "canal_id": 1,
        "activity": "Banking branch",
        "category": "Agency",
    },
    {
        "canal_id": 8,
        "activity": "Business unit",
        "category": "Business Unit",
    },
]

HEADERS = {
    "User-Agent": "Mozilla/5.0",
    "Referer": NETWORK_PAGE_URL,
}

COLUMN_ORDER = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS_NATIVE",
]

COUNTRY_MAP = {
    "Brazil": ("Brazil", "BRA"),
    "United States": ("United States", "USA"),
    "Cayman Islands": ("Cayman Islands", "CYM"),
    "Luxembourg": ("Luxembourg", "LUX"),
    "United Kingdom": ("United Kingdom", "GBR"),
    "Hong Kong": ("Hong Kong", "HKG"),
}


def ensure_dirs() -> None:
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def normalize_space(value: str) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


def transliterate_ascii(value: str) -> str:
    if not value:
        return ""
    value = (
        value.replace("ß", "ss")
        .replace("ä", "ae")
        .replace("ö", "oe")
        .replace("ü", "ue")
        .replace("Ä", "Ae")
        .replace("Ö", "Oe")
        .replace("Ü", "Ue")
        .replace("–", "-")
        .replace("—", "-")
        .replace("º", "o")
        .replace("ª", "a")
    )
    value = unicodedata.normalize("NFKD", value)
    value = value.encode("ascii", "ignore").decode("ascii")
    return normalize_space(value)


def has_non_ascii(value: str) -> bool:
    return any(ord(char) > 127 for char in (value or ""))


def format_brazil_postcode(value: str) -> str:
    digits = re.sub(r"\D", "", value or "")
    if len(digits) == 8:
        return f"{digits[:5]}-{digits[5:]}"
    return digits


def clean_address(value: str) -> str:
    value = normalize_space(value.replace("#", ""))
    value = re.sub(r"\s*,\s*,+", ", ", value)
    return value.strip(" ,")


def append_part(parts: List[str], value: str) -> None:
    value = clean_address(value)
    if value:
        parts.append(value)


def build_native_columns(name_native: str, address_native: str) -> Tuple[str, str]:
    if not has_non_ascii(name_native):
        name_native = ""
    if not has_non_ascii(address_native):
        address_native = ""
    return name_native, address_native


def save_progress(processed: int, rows: int, checkpoint_written: bool) -> None:
    PROGRESS_PATH.write_text(
        json.dumps(
            {
                "processed_records": processed,
                "rows_in_memory": rows,
                "checkpoint_written": checkpoint_written,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


def write_csv(path: Path, rows: List[Dict[str, str]]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=COLUMN_ORDER)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in COLUMN_ORDER})


def jsonp_url(canal_id: int) -> str:
    return f"{JSONP_ENDPOINT}?callback=rdaCallback&covid=true&canal_id={canal_id}"


def fetch_jsonp_payload(canal_id: int) -> List:
    response = requests.get(jsonp_url(canal_id), headers=HEADERS, timeout=60)
    response.raise_for_status()
    match = re.search(r"rdaCallback\((.*)\);?\s*$", response.text, re.S)
    if not match:
        raise ValueError(f"JSONP payload not found for canal_id={canal_id}")
    return ast.literal_eval(match.group(1))


def status_map(extra_location: Optional[List[List[str]]]) -> Dict[str, str]:
    mapping: Dict[str, str] = {}
    for item in extra_location or []:
        if len(item) >= 2:
            mapping[str(item[0]).zfill(4)] = item[1]
    return mapping


def make_row(
    *,
    name_raw: str,
    address_raw: str,
    latitude: str,
    longitude: str,
    country: str,
    postcode: str,
    state: str,
    city: str,
    source_url: str,
    source_type: str,
    activity: str,
) -> Dict[str, str]:
    country_name, iso3 = COUNTRY_MAP[country]
    native_name, native_address = build_native_columns(name_raw, address_raw)
    coord_source = "website" if latitude and longitude else "Not from website"
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": transliterate_ascii(name_raw),
        "LOCATION_ADDRESS": clean_address(transliterate_ascii(address_raw)),
        "LATITUDE": str(latitude) if latitude != "" else "",
        "LONGITUDE": str(longitude) if longitude != "" else "",
        "COUNTRY": country_name,
        "COUNTRY_ISO3": iso3,
        "POSTCODE": transliterate_ascii(postcode),
        "STATE": transliterate_ascii(state),
        "CITY": transliterate_ascii(city),
        "SOURCE_URL": source_url,
        "SOURCE_TYPE": source_type,
        "ACTIVITY_AT_ASSET": activity,
        "coord_source": coord_source,
        "LOCATION_NAME_NATIVE": native_name,
        "LOCATION_ADDRESS_NATIVE": native_address,
    }


def parse_api_rows(payload: List, channel: Dict[str, str]) -> List[Dict[str, str]]:
    locations = payload[0]
    statuses = status_map(payload[5] if len(payload) > 5 else None)
    output: List[Dict[str, str]] = []
    for item in locations:
        code = str(item[3]).zfill(4)
        if statuses.get(code) == "fechada":
            continue

        lat = item[0]
        lon = item[1]
        address = normalize_space(item[7])
        neighborhood = normalize_space(item[8])
        city = normalize_space(item[9])
        state = normalize_space(item[10])
        postcode = format_brazil_postcode(item[11])
        name = normalize_space(item[13]) or f"{channel['category']} {code}"
        address_parts: List[str] = []
        append_part(address_parts, address)
        append_part(address_parts, neighborhood)
        append_part(address_parts, city)
        append_part(address_parts, state)
        append_part(address_parts, postcode)
        append_part(address_parts, "Brazil")
        row = make_row(
            name_raw=name,
            address_raw=", ".join(address_parts),
            latitude=str(lat),
            longitude=str(lon),
            country="Brazil",
            postcode=postcode,
            state=state,
            city=city,
            source_url=jsonp_url(channel["canal_id"]),
            source_type="COMPANY WEBSITE",
            activity=channel["activity"],
        )
        if row["CITY"] and row["LOCATION_ADDRESS"]:
            output.append(row)
    return output


def split_city_state_from_text(value: str) -> Tuple[str, str]:
    value = normalize_space(value)
    if "," in value:
        city, state = [normalize_space(part) for part in value.split(",", 1)]
        return city, state
    return value, ""


def parse_international_units() -> List[Dict[str, str]]:
    response = requests.get(INTERNATIONAL_UNITS_URL, headers=HEADERS, timeout=60)
    response.raise_for_status()
    html = response.content.decode("utf-8", errors="replace")
    soup = BeautifulSoup(html, "html.parser")
    section = soup.find("section", id="pg-unidades-negocio-exterior")
    if section is None:
        return []

    records: List[Dict[str, str]] = []
    for block in section.find_all("ul", class_="on"):
        fields: Dict[str, List[str]] = {}
        for paragraph in block.find_all("p"):
            label_node = paragraph.find("span")
            if label_node is None:
                continue
            label = transliterate_ascii(label_node.get_text(" ", strip=True))
            text = paragraph.get_text(" ", strip=True)
            value = normalize_space(text.replace(label_node.get_text(" ", strip=True), "", 1))
            fields.setdefault(label, []).append(value)

        unit = fields.get("Unidades de Negocio", [""])[0]
        agency = fields.get("Agencia", [""])[0]
        subsidiary = fields.get("Subsidiaria", [""])[0]
        address = fields.get("Endereco", [""])[0]
        city_text = fields.get("Cidade", [""])[0]
        bairro = fields.get("Bairro", [""])[0]

        if city_text == "New York":
            country = "United States"
            city = "New York"
            state = "NY"
            postcode_match = re.search(r"\b(\d{5})\b", bairro)
            postcode = postcode_match.group(1) if postcode_match else ""
            office_name = agency or subsidiary or "Banco Bradesco New York Branch"
        elif "Grand Cayman" in city_text:
            country = "Cayman Islands"
            city = "Georgetown"
            state = "Grand Cayman"
            postcode = ""
            office_name = agency or subsidiary or "Bradesco Grand Cayman"
        elif city_text == "Luxembourg":
            country = "Luxembourg"
            city = "Luxembourg"
            state = ""
            postcode_match = re.search(r"\b(L-\d{4})\b", address)
            postcode = postcode_match.group(1) if postcode_match else ""
            office_name = agency or subsidiary or "Banco Bradesco Europa S.A."
        elif city_text == "London":
            country = "United Kingdom"
            city = "London"
            state = ""
            postcode = bairro
            office_name = agency or subsidiary or "Banco Bradesco Europa London Branch"
        else:
            continue

        address_parts: List[str] = [address]
        if country == "United States":
            append_part(address_parts, city)
            append_part(address_parts, state)
            append_part(address_parts, postcode)
            append_part(address_parts, "United States")
        elif country == "Cayman Islands":
            append_part(address_parts, city)
            append_part(address_parts, state)
            append_part(address_parts, "Cayman Islands")
        elif country == "Luxembourg":
            append_part(address_parts, city)
            append_part(address_parts, "Luxembourg")
        else:
            append_part(address_parts, city)
            append_part(address_parts, postcode)
            append_part(address_parts, "United Kingdom")

        records.append(
            make_row(
                name_raw=office_name or unit,
                address_raw=", ".join(address_parts),
                latitude="",
                longitude="",
                country=country,
                postcode=postcode,
                state=state,
                city=city,
                source_url=INTERNATIONAL_UNITS_URL,
                source_type="COMPANY WEBSITE",
                activity="International business unit",
            )
        )
    return records


def parse_asset_offices() -> List[Dict[str, str]]:
    response = requests.get(ASSET_INTERNATIONAL_URL, headers=HEADERS, timeout=60)
    response.raise_for_status()
    html = response.text
    match = re.search(
        r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>',
        html,
        re.S,
    )
    if not match:
        return []

    payload = json.loads(match.group(1))
    model = payload["props"]["pageProps"]["model"]["cqItems"]["responsivegrid"][":items"][
        "texteditor"
    ]["officeWallModel"]["listOffices"]

    records: List[Dict[str, str]] = []
    for office in model:
        name = normalize_space(office["nameOffice"])
        address = normalize_space(office["adress"])
        if "United Kingdom" in address:
            country = "United Kingdom"
            city = "London"
            state = ""
            postcode_match = re.search(r"\b([A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2})\b", address)
            postcode = postcode_match.group(1) if postcode_match else ""
            full_address = address
        else:
            country = "Hong Kong"
            city = "Hong Kong"
            state = "Central"
            postcode = ""
            full_address = f"{address}, Hong Kong"

        records.append(
            make_row(
                name_raw=name,
                address_raw=full_address,
                latitude="",
                longitude="",
                country=country,
                postcode=postcode,
                state=state,
                city=city,
                source_url=ASSET_INTERNATIONAL_URL,
                source_type="COMPANY WEBSITE",
                activity="Asset management office",
            )
        )
    return records


def download_pdf_if_needed() -> Path:
    if SUPPLIED_PDF_PATH.exists() and SUPPLIED_PDF_PATH.stat().st_size > 0:
        return SUPPLIED_PDF_PATH
    response = requests.get(
        SUPPLIED_PDF_URL,
        headers={"User-Agent": "Mozilla/5.0"},
        timeout=60,
        verify=False,
    )
    response.raise_for_status()
    SUPPLIED_PDF_PATH.write_bytes(response.content)
    return SUPPLIED_PDF_PATH


def parse_hq_from_pdf() -> List[Dict[str, str]]:
    pdf_path = download_pdf_if_needed()
    document = fitz.open(pdf_path)
    pages_text = " ".join(document.load_page(i).get_text("text") for i in range(min(3, document.page_count)))
    document.close()
    text = normalize_space(pages_text)
    address_match = re.search(
        r"Cidade de Deus S/N\s*[–-]\s*Vila Yara\s*06029-900\s*[–-]\s*Osasco\s*[–-]\s*SP,\s*Brazil",
        text,
        re.I,
    )
    address = (
        address_match.group(0)
        if address_match
        else "Cidade de Deus S/N - Vila Yara, Osasco, SP 06029-900, Brazil"
    )
    return [
        make_row(
            name_raw="Banco Bradesco S.A. Headquarters",
            address_raw=address,
            latitude="",
            longitude="",
            country="Brazil",
            postcode="06029-900",
            state="Sao Paulo",
            city="Osasco",
            source_url=SUPPLIED_PDF_URL,
            source_type="COMPANY REPORT",
            activity="Headquarters",
        )
    ]


def dedupe_rows(rows: Iterable[Dict[str, str]]) -> List[Dict[str, str]]:
    seen = set()
    deduped: List[Dict[str, str]] = []
    for row in rows:
        key = (
            row["LOCATION_NAME"].lower(),
            row["LOCATION_ADDRESS"].lower(),
            row["CITY"].lower(),
            row["COUNTRY_ISO3"],
            row["ACTIVITY_AT_ASSET"].lower(),
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)
    return deduped


def validate_rows(rows: List[Dict[str, str]]) -> None:
    missing_city = [row for row in rows if not row["CITY"]]
    missing_address = [row for row in rows if not row["LOCATION_ADDRESS"]]
    bad_hash = [row for row in rows if "#" in row["LOCATION_ADDRESS"]]
    if missing_city or missing_address or bad_hash:
        raise ValueError(
            f"Validation failed: missing_city={len(missing_city)} "
            f"missing_address={len(missing_address)} bad_hash={len(bad_hash)}"
        )


def build_summary(rows: List[Dict[str, str]]) -> Dict[str, object]:
    source_counts = Counter(row["SOURCE_URL"] for row in rows)
    activity_counts = Counter(row["ACTIVITY_AT_ASSET"] for row in rows)
    return {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "row_count": len(rows),
        "checkpoint_path": str(CHECKPOINT_PATH),
        "final_output_path": str(FINAL_OUTPUT_PATH),
        "source_counts": dict(source_counts),
        "activity_counts": dict(activity_counts),
    }


def main() -> None:
    ensure_dirs()
    all_rows: List[Dict[str, str]] = []
    checkpoint_written = False
    processed = 0

    for channel in API_CHANNELS:
        payload = fetch_jsonp_payload(channel["canal_id"])
        parsed = parse_api_rows(payload, channel)
        for row in parsed:
            all_rows.append(row)
            processed += 1
            if processed % 20 == 0:
                save_progress(processed, len(all_rows), checkpoint_written)
            if not checkpoint_written and len(all_rows) >= COUNT_THRESHOLD:
                write_csv(CHECKPOINT_PATH, all_rows)
                checkpoint_written = True
                save_progress(processed, len(all_rows), checkpoint_written)

    for supplemental in (parse_international_units(), parse_asset_offices(), parse_hq_from_pdf()):
        for row in supplemental:
            all_rows.append(row)
            processed += 1
            if processed % 20 == 0:
                save_progress(processed, len(all_rows), checkpoint_written)
            if not checkpoint_written and len(all_rows) >= COUNT_THRESHOLD:
                write_csv(CHECKPOINT_PATH, all_rows)
                checkpoint_written = True
                save_progress(processed, len(all_rows), checkpoint_written)

    final_rows = dedupe_rows(all_rows)
    validate_rows(final_rows)
    write_csv(FINAL_OUTPUT_PATH, final_rows)
    if not checkpoint_written:
        write_csv(CHECKPOINT_PATH, final_rows[:COUNT_THRESHOLD])
        checkpoint_written = True
    save_progress(processed, len(final_rows), checkpoint_written)
    SUMMARY_PATH.write_text(
        json.dumps(build_summary(final_rows), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(build_summary(final_rows), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
