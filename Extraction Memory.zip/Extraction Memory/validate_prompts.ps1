# validate_prompts.ps1
# ---------------------------------------------------------------------------
# Targeted validation of the locator-hardening + filing-fallback prompt changes.
# Runs a small set of issuers through the SAME pipeline as run_batch.ps1 (full
# approach ladder, yield gate, aggressive retry, canonicalize), but ISOLATED in
# its own run folder so it does NOT touch your 50-issuer benchmark outputs.
#
# HOW TO USE:
#   1. Save this file inside the "Extraction Memory" folder (next to run_batch.ps1).
#   2. In PowerShell, from that folder:   .\validate_prompts.ps1
#   3. When it finishes it prints a baseline-vs-this-run table. Share that + the log.
# ---------------------------------------------------------------------------

$ErrorActionPreference = 'Stop'

# ===== EDIT HERE if needed =================================================
# A known Tier-1 WIN (regression check) + the decisive LOSSES from the benchmark.
# Baseline = rows produced in the 50-issuer benchmark (what to beat / not regress).
$targets = @(
    @{ Id = 'IID000000002244210'; Name = 'GS Retail';  Baseline = 18459; Note = 'WIN  - must NOT regress (satisfies in Tier 1)' },
    @{ Id = 'IID000000005538588'; Name = 'Diagnostyka'; Baseline = 18;    Note = 'LOSS - expect lift (locator hardening)' },
    @{ Id = 'IID000000002162343'; Name = 'Cofinimmo';   Baseline = 82;    Note = 'LOSS - expect lift (filing fallback)' }
    # To add the other REIT, uncomment the next line:
    # ,@{ Id = 'IID000000002156304'; Name = 'Aedifica'; Baseline = 52;    Note = 'LOSS - optional extra REIT' }
)

$InputFile        = ''          # leave '' to use run_batch.ps1's default input path; else set the .xlsx path here
$RunTag           = '_validate' # isolates the run in its own folders (Run_<inputname>_validate)
$MaxWorkerMinutes = 180         # headroom for the deeper ladder (filings / PDF tables) on the REITs
# ===========================================================================

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$runBatch = Join-Path $here 'run_batch.ps1'
if (-not (Test-Path -LiteralPath $runBatch)) {
    throw "run_batch.ps1 not found next to this script. Save validate_prompts.ps1 inside the 'Extraction Memory' folder."
}

$ids = @($targets | ForEach-Object { $_.Id })
$logFile = Join-Path $here ("validate_run_{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))

Write-Host ""
Write-Host "=== Validation run: $($ids.Count) issuer(s) | tag=$RunTag | parallel cap=$($ids.Count) ===" -ForegroundColor Cyan
foreach ($t in $targets) { Write-Host ("  {0,-12} baseline={1,-7} {2}" -f $t.Name, $t.Baseline, $t.Note) }
Write-Host "  (isolated run - it will NOT overwrite your 50-issuer benchmark outputs)"
Write-Host ""

# Arguments for run_batch.ps1 (splatted).
$rbArgs = @{
    IssuerIds        = $ids
    RunTag           = $RunTag
    WorkerCap        = $ids.Count
    MaxWorkerMinutes = $MaxWorkerMinutes
    Fresh            = $true
}
if ($InputFile -ne '') { $rbArgs['InputFile'] = $InputFile }

# Run, mirroring all output to the console AND a log file we parse afterwards.
& $runBatch @rbArgs *>&1 | Tee-Object -FilePath $logFile

# ===== Parse the log for the final per-issuer outcome ======================
$log = Get-Content -LiteralPath $logFile
function Get-Outcome($id) {
    $rows = $null; $flag = ''; $retried = $false
    foreach ($line in ($log | Where-Object { $_ -like "*$id*" })) {
        if     ($line -match 'output \((\d+) rows\)')              { $rows = [int]$Matches[1] }
        elseif ($line -match 'UNION of 2 attempts \((\d+) rows\)') { $rows = [int]$Matches[1]; $flag = 'FLAGGED(union)' }
        if     ($line -match 'stashed attempt 1')                  { $retried = $true }
    }
    return [pscustomobject]@{ rows = $rows; flag = $flag; retried = $retried }
}

Write-Host ""
Write-Host "================ VALIDATION RESULT ================" -ForegroundColor Green
$fmt = "{0,-12} {1,10} {2,10} {3,9}  {4}"
Write-Host ($fmt -f 'Issuer','Baseline','ThisRun','Delta','Notes')
Write-Host ("-" * 72)
foreach ($t in $targets) {
    $o = Get-Outcome $t.Id
    if ($null -eq $o.rows) {
        Write-Host ($fmt -f $t.Name, $t.Baseline, 'none', '-', 'NO output - worker failed/stuck (see log)')
    } else {
        $delta = $o.rows - $t.Baseline
        $deltaStr = if ($delta -ge 0) { "+$delta" } else { "$delta" }
        $notes = @()
        if ($o.retried) { $notes += 'retried' }
        if ($o.flag)    { $notes += $o.flag }
        Write-Host ($fmt -f $t.Name, $t.Baseline, $o.rows, $deltaStr, ($notes -join ' '))
    }
}
Write-Host ("-" * 72)
Write-Host "Log saved to: $logFile"
Write-Host "Per-issuer CSVs are in your OUTPUT_ROOT under the folder: Run_<inputname>$RunTag"
Write-Host ""
Write-Host "Read it like this:"
Write-Host "  - GS Retail should stay ~18,459 (a large negative delta = regression to investigate)."
Write-Host "  - Diagnostyka and Cofinimmo should be WELL above baseline if the changes are working."
Write-Host "  - 'retried' means the yield gate asked for the aggressive deep pass; 'FLAGGED' means it"
Write-Host "    was still thin twice and was promoted as a union for review."
