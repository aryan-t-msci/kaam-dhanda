# Extraction Task Prompt — Batch Template
# ⚠️ SUPERSESSION NOTICE — APPROVAL REQUIRED BEFORE REMOVAL ⚠️
#
# This file has been superseded by the multi-agent architecture:
#   - ORCHESTRATOR_PROMPT.md  — parent agent (replaces this file as the entry point)
#   - WORKER_PROMPT.md        — worker agent (contains the extraction logic from this file)
#
# This file is RETAINED for two reasons:
#   1. Fallback: single-agent batch execution if multi-agent spawn is unavailable
#   2. Reference: the extraction logic here was the basis for WORKER_PROMPT.md
#
# STATUS: Superseded — kept as fallback/reference
# RETAINED BY: System (pending explicit approval to remove)
# APPROVED FOR REMOVAL: [ ] Not yet approved
#
# To remove this file, reply "approve removal of TASK_PROMPT_TEMPLATE_BATCH.md"
# ─────────────────────────────────────────────────────────────────────────────

---

From MEMORY_FOLDER, read and execute these files in order:
1. prompt.md — standing rules for all extraction tasks
2. TASK_PROMPT_TEMPLATE_BATCH.md — this file (already loaded)

Then execute the following batch task. Where this file conflicts with prompt.md, this file
takes precedence for batch-specific behaviour (notably: §6c permission gate is replaced
by the auto-write protocol in PHASE 2 — see the override note there).

---

## BATCH PARAMETERS

```
MEMORY_FOLDER : <path to your Extraction Memory folder>
INPUT_FILE    : <path to your input xlsx file>
TEMP_FOLDER   : <path to your Temp folder>
OUTPUT_FOLDER : <path to your Output folder>
```

---

## PHASE 0 — BATCH SETUP (run once, before any extraction begins)

### Step 0a — Read the Knowledge Base
→ Follow prompt.md §2 exactly. Output one batch-level KB CHECK block before any work starts.

### Step 0b — Create Batch Folders and Audit File
Generate a single timestamp the moment execution begins: `YYYYMMDD_HHMMSS`.
Create these two folders using that exact timestamp so Temp and Output are always paired:

```
{TEMP_FOLDER}\Extraction_Batch_{TIMESTAMP}\     → reference as BATCH_TEMP
{OUTPUT_FOLDER}\Extraction_Batch_{TIMESTAMP}\   → reference as BATCH_OUTPUT
```

Immediately create the audit file at:
```
{BATCH_TEMP}\batch_audit.jsonl
```

Write a single header comment line to it now:
```
# batch_audit.jsonl | Batch: Extraction_Batch_{TIMESTAMP} | Started: {YYYY-MM-DD HH:MM:SS} | Input: {INPUT_FILE}
```

**Important:** Every piece of code that reads `batch_audit.jsonl` must skip this line.
The skip rule: `if line.startswith("#"): continue` — apply this in `batch_report.py`
and anywhere else the file is read programmatically.

One JSON object per line will be appended here as each issuer completes.
See §AUDIT for the write lock protocol and entry format.

### Step 0c — Parse and Group the Input File

Read `INPUT_FILE` (xlsx). The file may arrive in one of two formats — detect automatically:

**FORMAT A — Single flat sheet:**
One sheet containing: `Tracking_ID`, `ISSUER_ID`, `ISSUER_NAME`, `COUNT`, `URL`,
`Notes`, `Status`, `Already added`, `URL_Type`, `Done By`, `Replacement URL`
(column names may vary — fuzzy-match on key terms).
`COUNT` is URL-specific. `COUNT` per issuer = **sum** of all URL-level COUNT values.
`URL_Type` column present — use for slot selection.

**FORMAT B — Two-sheet format:**
Sheet 1 (e.g. `Asset_Counts`): `Issuer ID`, `Issuer Name`, `Expected Count` — one row per issuer.
Sheet 2 (e.g. `URLs_only`): `ISSUER_ID`, `COMPANY_NAME`, `relevant_url` — multiple rows per issuer.
`COUNT` is issuer-level in Sheet 1 — use as-is, do NOT sum.
Join sheets on `ISSUER_ID`. No `URL_Type` column — use heuristic classification (see below).

**FORMAT DETECTION:** 2+ sheets → Format B. 1 sheet → Format A.

**URL_Type fallback (Format B — when column absent):**
- URL ends in `.pdf` → `pdf` (lightweight)
- URL contains `store-locator`, `branch-locator`, `find-us`, `#map` → `javascript_heavy`
- All others → `static_html` (lightweight, conservative default)
Document heuristic use in `[SLOTS]` block.

**Per issuer, derive:**
- `ISSUER_ID`, `ISSUER_NAME` — from respective columns
- `COUNT` — issuer-level target (Format A: sum; Format B: sheet 1 value as-is)
- `URLS` — all URL values, deduplicated
- `URL_TYPES` — from `URL_Type` column or heuristic
- `NOTES` — concatenated non-blank notes (Format A only)

**Output the parsed issuer manifest before starting any extraction:**

```
═══════════════════════════════════════════════════════════
BATCH MANIFEST — Extraction_Batch_{TIMESTAMP}
═══════════════════════════════════════════════════════════
Input format   : {Format A — single sheet | Format B — two sheets}
URL_Type source: {column | heuristic}
Total issuers  : {N}
Total URLs     : {N}
Total target   : {N} facilities

Issuers queued:
  1. {ISSUER_ID} | {ISSUER_NAME} | {N} URLs | target: {COUNT}
  2. {ISSUER_ID} | {ISSUER_NAME} | {N} URLs | target: {COUNT}
  ...
═══════════════════════════════════════════════════════════
```

---

## PHASE 1 — PARALLEL EXTRACTION

> ⚠️ **TASK COMPLETION RULE — READ THIS FIRST:**
> This task is not complete until **every issuer in the input file has been processed**.
> The slot count below is a **concurrency limit only** — it controls how many issuers run
> simultaneously, not how many issuers are processed in total. A batch of 500 issuers
> with 15 slots processes all 500 issuers, 15 at a time.
>
> **Never end this task, close the turn, or output a final summary while any issuer
> remains in the queue.** The only valid reason to stop early is an explicit human instruction.

---

### 1a — Adaptive Slot Selection

**Step 1 — Classify the batch URL mix:**
For each URL in the input, classify using the `URL_Type` column:
- **Lightweight:** `static_html`, `pdf`, `hierarchical_selector`, `paginated`, or unknown/blank
- **Heavy:** `javascript_heavy`, `interactive_map`, `search_required`, `iframe_embedded`

Compute: `heavy_ratio = heavy_URL_count / total_URL_count`

**Step 2 — Select initial slot count:**

| URL Mix | heavy_ratio | Slot Range | Interpolation formula |
|---------|-------------|------------|-----------------------|
| Predominantly static / PDF | 0% – 20% | **17 – 20** | `slots = round(20 - (heavy_ratio / 0.20) * 3)` |
| Mixed | 21% – 60% | **10 – 13** | `slots = round(13 - (heavy_ratio - 0.21) / 0.39 * 3)` |
| Majority JS-heavy | 61% – 100% | **6 – 8** | `slots = round(8 - (heavy_ratio - 0.61) / 0.39 * 2)` |

**Step 3 — Output the slot decision:**
```
[SLOTS] Mix: {lightweight_count} lightweight / {heavy_count} heavy ({heavy_ratio:.0%} heavy)
        Range: {RANGE} | Initial slots: {N}
        Reason: {1 sentence}
```

**Step 4 — Adaptive adjustment rules (applied throughout the run):**

*Downward adjustment (resource pressure detected):*
Trigger when ANY of these occur in a rolling window of 5 consecutive issuers:
- 3+ issuers hit connection timeouts on >50% of their URLs
- 3+ issuers hit memory errors or Playwright crashes
- Average issuer completion time increases by >100% vs the batch median

Action: Reduce slot count by one tier (e.g., mixed range → JS-heavy range lower bound).
Apply for the next **15 issuers**, then re-evaluate. Log the adjustment:
```
[SLOTS ADJUSTED ↓] Pressure detected — reduced to {N} slots for next 15 issuers
  Trigger: {what was detected}
```

*Upward adjustment (headroom available):*
Trigger when ALL of these are true over a rolling window of 20 consecutive issuers:
- Zero connection timeouts or Playwright crashes
- Zero memory errors
- Average issuer completion time is stable or improving

Action: Recalculate `heavy_ratio` from the **remaining** (unprocessed) issuers in the queue
and re-run the interpolation formula. If the new slot count is higher than current, adopt it.
If lower or equal, keep current. Log the adjustment:
```
[SLOTS ADJUSTED ↑] Headroom confirmed — recalculated to {N} slots
  Remaining queue heavy_ratio: {X}% | Previous slots: {N} | New slots: {N}
```

*Key rule:* Adjustments are **episode-based**, not permanent. After each episode (15 issuers
for downward, 20 for upward re-evaluation), the slot count is recalculated fresh from the
remaining queue. The batch does not carry a penalty from an earlier slow stretch indefinitely.

---

### 1b — Rolling Queue Execution

1. Fill all slots immediately at batch start.
2. The moment any slot completes, **immediately start the next queued issuer** in that slot.
3. **Keep refilling from the queue until the queue is empty.**
4. The batch ends only when the last issuer has been processed.

**Queue tracking — output after every issuer completion, without exception:**
```
[QUEUE] {N}/{TOTAL} complete | {REMAINING} remaining | {CURRENT_SLOTS} slots active | continuing...
```
If `REMAINING > 0`, the task continues. This line is a commitment, not a status update.

---

### 1c — Targeted KB Re-Read on Slot Open

**Mandatory for every issuer starting after the initial slot fill. Not optional.**

When a slot opens, before beginning the new issuer's KB CHECK:
1. Check the internal batch log for R-XX, P-XX, and scripts written during this batch.
2. Open only those specific new record files from `KB/` (e.g. `KB/R-152.md`) - never a whole KB file.
3. Check the last 3 rows of the Script Inventory in KB_INDEX.md §4.
4. Output this notice before the issuer's KB CHECK:

```
[SLOT RE-READ] Starting issuer {N}/{TOTAL}: {ISSUER_NAME}
  New KB entries this batch: {list, or "none yet"}
  Applicable here: {yes — {entry} | no}
```

If no new entries exist yet, still output the notice (with "none yet") to confirm the
re-read step was not skipped.

---

### 1d — Per-Issuer Execution

For every issuer, record the **start timestamp** immediately when the issuer begins.

Then execute in this order:
1. `[SLOT RE-READ]` notice (mandatory for every issuer starting after the initial slot fill — see §1c)
2. Abbreviated KB CHECK (2 lines: pattern match + prior record)
3. Reconnaissance → pattern identification → extraction → post-processing
4. **Exhaust all approaches before declaring a gap** — see §GAP-RECOVERY
5. Checkpoint CSV when COUNT is reached; continue scanning for additional facilities
6. Script classification: Category A, B, or C — see prompt.md §7
7. **Validation pass** — run all structural, enum, and semantic checks from prompt.md §5f.
   Apply Tier A rectifications. Apply Tier B fixes and populate QA_flag. Write Tier C rows
   to `{BATCH_TEMP}\{ISSUER_ID}_{ISSUER_NAME}\{ISSUER_ID}_rejected.csv`.
8. **QA spot-check** — inspect the required sample size per prompt.md §5f rules.
   Write QA results to `batch_qa.jsonl` (see §QA-REPORT). Output 2-line summary to UI.
9. **KB draft creation** — create `KB_APPEND_{ISSUER_ID}_{YYYYMMDD}.md` in the issuer
   subfolder. See §BATCH-KB for format and existing-record handling.
10. **KB write attempt** — run BATCH-KB-2 eligibility checks. Auto-write if eligible, or
    surface human guidance request immediately. See §BATCH-KB.
11. Record the **end timestamp**
12. Append the issuer entry to `batch_audit.jsonl` — see §AUDIT
13. Output the ISSUER COMPLETE summary — see §REPORTING

> ⚠️ **The `[QUEUE]` counter line fires only after steps 7–10 are all complete.**
> An issuer is not "done" until it has passed validation, QA, and KB handling.
> An issuer that completes extraction but skips steps 7–10 is not complete.

---

### 1e — Per-Issuer File Naming

```
BATCH_TEMP\{ISSUER_ID}_{ISSUER_NAME}\
    ├── [intermediate scripts, progress JSON, debug outputs]
    ├── KB_APPEND_{ISSUER_ID}_{YYYYMMDD}.md
    └── {ISSUER_ID}_rejected.csv     ← Tier C rejected rows (if any)

BATCH_OUTPUT\
    └── {ISSUER_ID}_{ISSUER_NAME}.csv
```

---

## AUDIT — Per-Issuer Audit Log (JSONL)

The audit log is `{BATCH_TEMP}\batch_audit.jsonl` — one JSON object per line, one line
per issuer. This format is append-safe, machine-readable, and human-inspectable.

### Audit Write Lock
Because multiple issuers may complete near-simultaneously, all writes to `batch_audit.jsonl`
must be serialised using a dedicated lock file: `{BATCH_TEMP}\AUDIT_WRITE.lock`.

**Write sequence for every audit entry:**
1. Check for `AUDIT_WRITE.lock`. If present, wait 5 seconds and retry (up to 12 retries = 1 min).
2. If absent: create `AUDIT_WRITE.lock` with content `{ISSUER_ID} {datetime}`.
3. Append the JSON line to `batch_audit.jsonl`.
4. Delete `AUDIT_WRITE.lock` immediately.

This lock is separate from `KB_WRITE.lock` — they are independent operations.
Stale `AUDIT_WRITE.lock` threshold: 2 minutes (much shorter than KB lock — audit writes are fast).

### Audit Entry Format
Append this JSON object as a single line (no line breaks within the object):

```json
{
  "issuer_id": "{ISSUER_ID}",
  "issuer_name": "{ISSUER_NAME}",
  "status": "met|exceeded|gap",
  "target_count": {N},
  "achieved_count": {N},
  "gap": {N},
  "start_time": "{YYYY-MM-DD HH:MM:SS}",
  "end_time": "{YYYY-MM-DD HH:MM:SS}",
  "duration_seconds": {N},
  "urls_attempted": {N},
  "urls_yielded_data": {N},
  "pattern_used": "P-XX — {Pattern Name}",
  "prior_record_used": "R-XX — {Company}|null",
  "script_reused": "{script_name.py}|null",
  "new_script_saved": "{script_name.py} Category {A/B/C}|null",
  "kb_entry": "auto-written|pending_guidance|skipped",
  "kb_record": "R-XX|null",
  "kb_impact": "helped|no_effect|hindered",
  "kb_impact_reason": "{1 sentence}",
  "sources_yielded_data": ["{url1}", "{url2}"],
  "validation_url_used": true,
  "gap_root_cause": "{1-2 sentences if gap, null otherwise}",
  "gap_recommendation": "{sentence if gap, null otherwise}",
  "qa_rows_inspected": {N},
  "qa_rows_total": {N},
  "qa_clean": {N},
  "qa_tier_a_fixed": {N},
  "qa_tier_b_flagged": {N},
  "qa_tier_c_rejected": {N},
  "qa_full_page_scraper": true
}
```

The `batch_report.py` script reads this file with:
```python
for line in f:
    if line.startswith("#"): continue  # skip header comment
    entry = json.loads(line)
```

---

## QA-REPORT — batch_qa.jsonl

`batch_qa.jsonl` uses the same line-append format as `batch_audit.jsonl` — one JSON
object per line, one line per issuer. This eliminates parallel-write race conditions:
the same `AUDIT_WRITE.lock` serialises writes to both files sequentially.

**Create at batch start** — write the header comment line immediately:
```
# batch_qa.jsonl | Batch: Extraction_Batch_{TIMESTAMP} | Started: {YYYY-MM-DD HH:MM:SS}
```

**Write sequence per issuer** (runs after QA spot-check completes):
1. Check `AUDIT_WRITE.lock` — same lock used for `batch_audit.jsonl`.
2. If lock absent: acquire it, append to `batch_audit.jsonl`, then append to
   `batch_qa.jsonl`, then release lock. Both appends happen in the same lock window.
3. If lock present: wait 5 seconds, retry up to 12 times (same as audit write protocol).

Bundling both appends in one lock window means one acquisition covers both files —
no additional contention, no second lock needed.

**Entry format** — append as a single line per issuer (no internal line breaks):

```json
{
  "issuer_id": "{ISSUER_ID}",
  "issuer_name": "{ISSUER_NAME}",
  "rows_total": {N},
  "rows_inspected": {N},
  "inspection_pct": {N},
  "full_page_scraper": true,
  "tier_a_fixed": [
    {
      "row_index": {N},
      "location_name": "{value}",
      "column": "{COLUMN_NAME}",
      "original_value": "{before}",
      "fixed_value": "{after}",
      "fix_reason": "{1 sentence}"
    }
  ],
  "tier_b_flagged": [
    {
      "row_index": {N},
      "location_name": "{value}",
      "qa_flag": "{flag_value}",
      "columns_needing_review": ["{COL1}", "{COL2}"],
      "original_value": "{before}",
      "attempted_fix": "{after}",
      "uncertainty_reason": "{1 sentence}"
    }
  ],
  "tier_c_rejected": [
    {
      "row_index": {N},
      "raw_content": "{first 200 chars of the raw row}",
      "rejection_reason": "{1 sentence}"
    }
  ],
  "semantic_flags": [
    {
      "row_index": {N},
      "location_name": "{value}",
      "flag_code": "CITY_SUSPICIOUS|ACTIVITY_JUNK|...",
      "flagged_value": "{the problematic value}",
      "column": "{COLUMN_NAME}"
    }
  ],
  "blank_mandatory_counts": {
    "LOCATION_NAME": {N},
    "LOCATION_ADDRESS": {N},
    "COUNTRY": {N},
    "COUNTRY_ISO3": {N},
    "CITY": {N},
    "ACTIVITY_AT_ASSET": {N},
    "SOURCE_URL": {N},
    "coord_source_violations": {N}
  }
}
```

The `batch_report.py` script reads this file with:
```python
for line in open("batch_qa.jsonl"):
    if line.startswith("#"): continue  # skip header comment
    entry = json.loads(line)
```

---

## REPORTING — Two-Tier Per-Issuer Output

### Tier 1 — Successful completion (count met or exceeded)
Output a **compressed single line** to the UI. Full detail is in `batch_audit.jsonl`.

```
✅ {ISSUER_NAME} ({ISSUER_ID}) — {achieved}/{target} | {duration} | P-XX | {script or "new"} | KB: {R-XX ✅/⚠️}
```

Example:
```
✅ SABIC (IID000000002182781) — 107/15 | 4m 12s | P-05 Static HTML | chroma_ate_extract.py reused | KB: R-63 ✅
```

### Tier 2 — Gap completion (count not met)
Output the **full ISSUER COMPLETE block** plus the GAP ALERT immediately.
Do not compress gap issuers — full detail is required.

```
╔═════════════════════════════════════════════════════════════╗
║  ISSUER COMPLETE ⚠️  —  {ISSUER_NAME}  ({ISSUER_ID})       ║
╚═════════════════════════════════════════════════════════════╝

EXTRACTION RESULTS
  Target count      : {COUNT}
  Achieved count    : {N}
  Status            : GAP — {N} short
  Start time        : {YYYY-MM-DD HH:MM:SS}
  End time          : {YYYY-MM-DD HH:MM:SS}
  Duration          : {X} min {Y} sec
  URLs attempted    : {N} | Yielded data: {N}
  Output CSV        : {BATCH_OUTPUT}\{ISSUER_ID}_{ISSUER_NAME}.csv

KB
  Pattern used      : P-XX — {Pattern Name}
  Script reused     : `{script_name.py}` | None
  New script saved  : `{script_name.py}` Category {A/B/C} | None
  KB impact         : Helped / No effect / Hindered
  KB impact reason  : {1 sentence}
  KB entry          : Pending human guidance ⚠️

CROSS-BATCH NOTE
  {Anything useful for remaining issuers, or "None"}
```

Immediately follow with the GAP ALERT block (§GAP-RECOVERY).

---

## GAP-RECOVERY — Exhaustive Gap Recovery Protocol

A gap declaration is only valid after genuinely exhausting all recovery approaches.
This protocol defines what "exhausted" means. Work through each tier in order.
Stop as soon as you have enough records to meet COUNT. If you reach the end still short,
declare the gap with full exhaustion proof.

### Tier 1 — Primary Sources
- Fetch and parse all provided URLs
- For each URL that returns an error (403, 404, timeout, TLS): try once with `verify=False`,
  once with a different User-Agent, once with Playwright if static fetch failed
- Extract all address-bearing content found

### Tier 2 — Alternative Pages on the Same Domain
Systematically check these page types on the issuer's domain(s):
- `/contact`, `/contact-us`, `/contactus`, `/about`, `/about-us`
- `/locations`, `/offices`, `/branches`, `/global-offices`, `/find-us`
- `/investor-relations`, `/ir`, `/investors`
- `/sitemap.xml` — crawl for location-bearing URL patterns
- Annual report / sustainability report PDFs linked from the IR page
- Any page the navigation menu labels as "locations", "global presence", "our offices"

### Tier 3 — Official Filings and Regulatory Sources
Try these in order, stopping when sufficient data is found:
1. **Stock exchange filings** — HKEXnews, SEDAR, SEC EDGAR, BSE/NSE, Bursa, SGX depending
   on the issuer's primary listing. Search for the most recent annual report PDF.
2. **Annual report PDF** — search for "Properties", "Principal Properties", "Our Locations",
   "Subsidiaries", "Group Structure", "Investment Properties" sections
3. **Sustainability / ESG report** — often lists operational sites separately
4. **Regulatory disclosures** — for banks: central bank branch registry; for utilities:
   regulatory filings; for telecoms: spectrum licence filings

### Tier 4 — Secondary Sources with Official Cross-Validation
Secondary sources may be used **only if cross-validated against an official source**.

Permitted secondary sources (try in this order):
1. **Company LinkedIn page** — "Locations" tab lists registered offices and major sites
2. **OpenStreetMap / Google Maps** — confirmed business listings for physical facilities
3. **Industry databases** — Bloomberg company page, Capital IQ, Orbis/Bureau van Dijk
4. **News sources** — press releases announcing new facilities, factory openings, relocations
5. **Job portals** — Zhaopin, Naukri, LinkedIn Jobs, Indeed — job postings list work locations
6. **Sector-specific registries** — for banks: central bank branch lists; for telecom:
   regulator licence databases; for pharma: FDA facility registration; etc.

**Cross-validation rule:** A secondary source record is retained only if an official source
(Tiers 1–3) confirms the entity exists and operates at least at the city level at that
location. When the official source provides city-level detail and the secondary source
provides street-level detail:
- `SOURCE_URL` = the secondary source URL (where the street-level data was actually found)
- `VALIDATION_URL` = the official source URL (used to confirm the entity at city level)
- `SOURCE_TYPE` = classify based on the secondary source type
- Retain the street-level address from the secondary source in `LOCATION_ADDRESS`

This preserves a complete audit trail: SOURCE_URL always tells you exactly where each
data point came from, and VALIDATION_URL tells you what official source confirmed it.

### Tier 5 — JS Rendering and Anti-Bot Recovery
If any URL was skipped or failed due to JavaScript rendering requirements:
- Run Playwright with `channel='msedge'`, `navigator.webdriver = undefined`
- Try with cookie consent removal: `page.evaluate('document.getElementById("cmpbox")?.remove()')`
- For CORS-restricted APIs: execute `fetch()` inside browser context via `page.evaluate()`
- For CSRF-protected endpoints: use click-based interception (not `page.evaluate()` fetch)
- Try from a different network path if corporate proxy/firewall is suspected

### Gap Declaration
Only after all five tiers are attempted may a gap be declared. Output this block:

```
⚠️ GAP ALERT — {ISSUER_NAME} ({ISSUER_ID})
  Target: {COUNT} | Achieved: {N} | Short by: {N}

  Recovery exhaustion proof:
  {✅/❌} Tier 1 — Primary URLs       : {what was tried, what was found/blocked}
  {✅/❌} Tier 2 — Alternative pages  : {pages checked, outcome}
  {✅/❌} Tier 3 — Official filings   : {sources checked, outcome}
  {✅/❌} Tier 4 — Secondary sources  : {sources tried, cross-validation outcome}
  {✅/❌} Tier 5 — JS/anti-bot        : {attempted / not applicable — explain}

  Root cause      : {consolidated technical explanation}
  Business summary: {1 plain-English sentence for a non-technical reader}
  Recommendation  : {what a future run should try, or why gap is likely permanent}

  KB draft: NOT auto-eligible — awaiting your guidance.
  Reply: "approve {ISSUER_ID}" | "skip {ISSUER_ID}" | "edit {ISSUER_ID}"
```

**Issuer isolation rule:** The outcome of gap recovery for one issuer must not affect
the effort applied to any other issuer. Every issuer gets the full five-tier treatment
regardless of how many gaps have occurred earlier in the batch.

---

## BATCH-KB — KB Update Protocol (Batch Mode)

> **Override notice:** This section replaces prompt.md §6c for batch runs.
> prompt.md §6c requires human permission before every KB write. For batch runs,
> the auto-write protocol below applies instead for qualifying issuers. The draft-first
> rule (prompt.md §6a) and the lock mechanism (prompt.md §6b, enhanced below) are retained.

### BATCH-KB-0 — Resume Protocol (crash recovery only)

If resuming a batch that was interrupted:
1. Read `batch_audit.jsonl` to identify which issuers completed before the interruption.
2. For each completed issuer, check whether a `KB_APPEND_{ISSUER_ID}_{YYYYMMDD}.md` exists
   in its subfolder under BATCH_TEMP.
3. For any completed issuer **missing** a KB draft: create the draft now before processing
   any new issuers.
4. For any completed issuer with a draft that was **not yet written** to the KB: run the
   BATCH-KB-2 eligibility checks and process them (auto-write or human guidance) before
   continuing with new issuers.
5. Only after all prior-completion KB work is resolved: resume processing remaining issuers.

This ensures no extraction run's knowledge is permanently lost due to an interruption.

### BATCH-KB-1 — Draft per Issuer

Create at: `{BATCH_TEMP}\{ISSUER_ID}_{ISSUER_NAME}\KB_APPEND_{ISSUER_ID}_{YYYYMMDD}.md`

**For issuers with no prior KB record:** Format using the full R-XX template in
`KB/_FRONTMATTER.md § APPENDING NEW KNOWLEDGE`. Include source table, approaches tried,
✅/❌ learnings, and script config block. When this issuer ended in a gap or a thin
result, do NOT record any source as barren or "showcase-only" — a shortfall means the
extraction fell short, not that the source is empty; note what was left unfinished instead.

**For issuers that already have a prior R-XX record (`KB/R-XX.md` exists):**
Do NOT create a new duplicate R-XX entry. Instead, write a correction/update note
to be appended inside the existing `KB/R-XX.md` file:

```markdown
> [!NOTE]
> **Update (YYYY-MM-DD) — Batch {BATCH_ID}:**
> Re-extracted. Count: {achieved} / {target}.
> Pattern used: P-XX — {Pattern Name}
> Script used: `{script_name.py}`
> New learnings:
> - ✅ [any new finding not in the original record]
> - ❌ [any new failure not in the original record]
> [If no new learnings: "No new learnings — existing record remains accurate."]
```

Check BATCH-KB-2 eligibility still applies: the update note must have at least one
learning (new or confirming), script classification, and today's date. If the re-extraction
produced no new information beyond what's already in the record, skip = acceptable.

### BATCH-KB-2 — Auto-Write Eligibility

A draft is eligible for automatic writing only if ALL six conditions are met:

| # | Check | Condition |
|---|-------|-----------|
| 1 | Count met | Extracted records ≥ COUNT target |
| 2 | R-XX no conflict | New record: number not already in KB. Update note: existing R-XX confirmed present. |
| 3 | Minimum learnings | At least one ✅ and one ❌ learning present (new records); or at least one learning (update notes) |
| 4 | Script classified | Category A, B, or C explicitly stated |
| 5 | Date updated | `Last Updated` set to today's date |
| 6 | Semantic consistency | Pattern claimed in draft matches URL_Type of URLs actually processed |

If all six pass → auto-write (BATCH-KB-3).
If any fail → human guidance (BATCH-KB-4). Other issuers continue unaffected.

### BATCH-KB-3 — Auto-Write with Enhanced Lock

1. **Check** for `{MEMORY_FOLDER}\KB_WRITE.lock`.
2. **Stale lock check:** If lock is older than **10 minutes**, treat as stale — log warning,
   delete, acquire fresh lock.
   ```
   [LOCK WARNING] Stale lock detected (age: {X} min) — overriding and proceeding
   ```
3. **If fresh lock (< 10 min):** wait 30 seconds, retry up to **20 retries**.
   After 20 retries: mark `Pending — lock timeout`, surface at batch summary.
4. **Acquire lock:**
   ```
   LOCKED_BY : {ISSUER_NAME} ({ISSUER_ID})
   LOCKED_AT : {YYYY-MM-DD HH:MM:SS}
   BATCH_ID  : Extraction_Batch_{TIMESTAMP}
   ```
5. **Re-read** `KB_INDEX.md` (current latest version - the only shared, locked file).
6. **For new records:** verify the R-XX number is still free (check `KB_INDEX.md` and `KB/`);
   if taken, assign the next available and write the record as `KB/R-XX.md`.
   **For update notes:** edit the existing `KB/R-XX.md` file directly.
7. **Write** your new `KB/<id>.md` record file(s) (unique names, no lock needed), then
   **append** the new row(s) to `KB_INDEX.md` under the lock.
8. **Delete** `KB_WRITE.lock` immediately.
9. Mark issuer as `KB written ✅` in batch log.

### BATCH-KB-4 — Human Guidance Cases

Surface immediately to UI when triggered:

```
⚠️ HUMAN GUIDANCE NEEDED — KB UPDATE
  Issuer     : {ISSUER_NAME} ({ISSUER_ID})
  Reason     : {specific failed check}
  Draft path : {path}
  Reply with : "approve {ISSUER_ID}" | "skip {ISSUER_ID}" | "edit {ISSUER_ID}"
```

Triggers: gap case, any of 6 checks failed, lock timeout, unresolvable R-XX conflict.
Other issuers continue normally while awaiting response.

---

## PHASE 3 — BATCH SUMMARY

Output after all issuers are complete. This is a summary — full detail is in `batch_audit.jsonl`.

```
═══════════════════════════════════════════════════════════
BATCH COMPLETE — Extraction_Batch_{TIMESTAMP}
═══════════════════════════════════════════════════════════
Total issuers : {N} | Met/Exceeded: {N} ✅ | Gap: {N} ⚠️
Duration      : {start datetime} → {end datetime} ({total} min)
KB writes     : {N} auto-written ✅ | {N} pending ⚠️ | {N} skipped ❌
Scripts saved : {list with categories, or "none"}
Audit log     : {BATCH_TEMP}\batch_audit.jsonl

RESULTS TABLE
| # | ISSUER_ID | ISSUER_NAME | Target | Got | Status | Duration | KB |
|---|-----------|-------------|--------|-----|--------|----------|----|
| 1 | ...       | ...         | ...    | ... | ✅/⚠️  | {X}m     | ✅ |
...

GAP ISSUERS — SUMMARY
[For each ⚠️ issuer, one paragraph: what was tried, why it failed, recommendation]

PENDING KB UPDATES
[Any issuers still awaiting "approve / skip / edit"]
═══════════════════════════════════════════════════════════
```

After the batch summary, generate `batch_report.py` in `{BATCH_TEMP}` — see §REPORT.

---

## REPORT — batch_report.py

After the batch summary is output, write a Python script at `{BATCH_TEMP}\batch_report.py`.
This script reads the batch outputs and generates a self-contained HTML report with PDF export.

The script must:

1. **Read inputs:**
   - `{BATCH_TEMP}\batch_audit.jsonl` — for per-issuer metrics (one JSON object per line)
   - `{BATCH_TEMP}\batch_qa.jsonl` — for per-issuer QA validation detail
   - All CSVs in `{BATCH_OUTPUT}` — for row counts and sample data

2. **Generate `{BATCH_OUTPUT}\batch_report_{TIMESTAMP}.html`** containing:
   - Batch header: ID, start/end time, total duration, total issuers
   - Summary cards: total met ✅, total gap ⚠️, total facilities extracted,
     total Tier A fixed, total Tier B flagged, total Tier C rejected
   - Results table: sortable, colour-coded (green = met, amber = gap)
   - QA summary section: per-issuer validation stats from batch_qa.jsonl
   - Gap section: each gap issuer expanded with exhaustion proof and recommendation
   - Collapsible per-issuer detail (click to expand full audit + QA entry)
   - "Download as PDF" button using `window.print()` with print-optimised CSS

3. **Self-contained:** No external CDN dependencies. All CSS and JS inline.
   Use clean, minimal styling — readable on screen and in print.

4. **PDF export:** Add a `<style media="print">` block that hides the nav/buttons and
   formats the content for A4 paper. The "Download as PDF" button calls `window.print()`.

The script should be runnable with `python batch_report.py` from the batch temp folder
with no arguments. Path resolution should be relative to the script's own location.

---

## BATCH QUALITY CHECKLIST

Run before declaring batch complete. Every item must be checked.

**Setup**
- [ ] Batch folders created with consistent timestamp
- [ ] `batch_audit.jsonl` created with header comment line at batch start
- [ ] `batch_qa.jsonl` created with header comment line at batch start
- [ ] `AUDIT_WRITE.lock` used for every append to `batch_audit.jsonl`
- [ ] Issuer manifest output before any extraction began
- [ ] KB CHECK block output before any extraction began
- [ ] `[SLOTS]` block output with heavy_ratio, range, and selected count
- [ ] Total issuer count recorded as completion target

**Execution**
- [ ] Rolling slot model used — slots = concurrency limit, not total
- [ ] `[QUEUE]` line fires only after steps 7–10 complete (validation + QA + KB)
- [ ] No turn ended while REMAINING > 0
- [ ] Every issuer in input file processed (CSV exists for every ISSUER_ID)
- [ ] `[SLOT RE-READ]` notice output before every issuer starting after initial slots
- [ ] Adaptive adjustment logged whenever slot count changed
- [ ] All URLs per issuer grouped correctly
- [ ] COUNT = sum of URL-specific COUNT values per issuer

**Gap Recovery**
- [ ] All five tiers attempted for every gap issuer
- [ ] Secondary sources cross-validated against official sources
- [ ] GAP ALERT includes full exhaustion proof (Tier 1–5)
- [ ] No zero-row CSV without valid exhaustion proof
- [ ] Issuer isolation maintained

**Data Validation and QA**
- [ ] All mandatory columns non-blank: LOCATION_NAME, LOCATION_ADDRESS, COUNTRY,
      COUNTRY_ISO3, CITY, ACTIVITY_AT_ASSET, SOURCE_URL, SOURCE_TYPE, coord_source
- [ ] QA_flag column present in every CSV (blank is correct for clean rows — do not flag blank QA_flag as an error)
- [ ] No `#` characters in LOCATION_ADDRESS
- [ ] coord_source is exactly `website` or `Not from website` for every row
- [ ] Semantic validators run — city, activity, address contamination checks completed
- [ ] Tier A rows: QA_flag = `"fixed"`, detail in batch_qa.jsonl
- [ ] Tier B rows: QA_flag = pipe-separated column names, detail in batch_qa.jsonl
- [ ] Tier C rows: written to `{ISSUER_ID}_rejected.csv` in issuer subfolder
- [ ] QA spot-check run with correct sample size (all if <5; min 5; min 10%; min 20% for soup.get_text())
- [ ] QA results written to `batch_qa.jsonl` per issuer
- [ ] QA 2-line summary output to UI per issuer
- [ ] VALIDATION_URL column present wherever secondary sources were used
- [ ] Native-language columns added where non-ASCII source data present
- [ ] All CSVs named `{ISSUER_ID}_{ISSUER_NAME}.csv` in BATCH_OUTPUT

**Audit and Reporting**
- [ ] `batch_audit.jsonl` has one entry per issuer with timestamps, counts, and QA summary fields
- [ ] `batch_qa.jsonl` has one entry per issuer with full validation detail
- [ ] Tier 1 completions reported as compressed one-liners
- [ ] Gap completions reported with full ISSUER COMPLETE block
- [ ] `batch_report.py` written to BATCH_TEMP
- [ ] Batch summary output

**Scripts**
- [ ] Every script classified A, B, or C
- [ ] A and B scripts saved to Memory Folder
- [ ] C scripts: reason documented in KB draft

**KB Updates**
- [ ] Every issuer has a KB draft in its BATCH_TEMP subfolder — no exceptions
- [ ] Existing-record issuers: update note written, not a duplicate R-XX
- [ ] All six BATCH-KB-2 checks run before any auto-write
- [ ] Auto-write used for eligible issuers (not reverted to prompt.md §6c)
- [ ] Stale lock check performed before every lock acquisition
- [ ] Lock deleted immediately after every write
- [ ] R-XX numbers verified at write time against live KB
- [ ] Human guidance cases surfaced immediately as they arose
- [ ] If resuming: prior-completion KB work resolved before new issuers started
