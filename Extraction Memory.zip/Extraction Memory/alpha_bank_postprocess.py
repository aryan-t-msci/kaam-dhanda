"""
Alpha Bank S.A. — Post-Processing & Final CSV Builder
======================================================
Cleans and refines the intermediate extraction for final output.
"""

import pandas as pd
import re
import unicodedata
import os

ISSUER_ID   = "IID000000005041428"
ISSUER_NAME = "ALPHA BANK S.A."
TEMP_DIR    = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp"
OUTPUT_DIR  = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output"

# Prefecture → City mapping for cases where the branch name IS a landmark/street in a major city
# These are all Attica branches (Athens metropolitan area)
ATTICA_NEIGHBORHOOD_CITIES = {
    # Neighborhoods/municipalities in Attica that are actual cities
    'Acharnon': 'Athens',
    'Aghia Paraskevi': 'Agia Paraskevi',
    'Aghioi Anargyri': 'Agios Anargyros',
    'Aghios Dimitrios': 'Agios Dimitrios',
    'Aghios Stefanos': 'Agios Stefanos',
    'Aigaleo': 'Aigaleo',
    'Alimos': 'Alimos',
    'Amaroussion': 'Maroussi',
    'Anavyssos': 'Anavyssos',
    'Aspropyrgos': 'Aspropyrgos',
    'Argyroupolis': 'Argyroupolis',
    'Byron': 'Vyronas',
    'Byzantion': 'Athens',
    'Cholargos': 'Cholargos',
    'Drossia': 'Drossia',
    'Elefsis': 'Elefsina',
    'Ellinikon': 'Elliniko',
    'Erythros': 'Athens',
    'Fix': 'Athens',
    'Galatsi': 'Galatsi',
    'Gerakas': 'Gerakas',
    'Glyfada': 'Glyfada',
    'Glyka Nera': 'Glyka Nera',
    'Halandri': 'Chalandri',
    'Ilion': 'Ilion',
    'Ilioupolis': 'Ilioupolis',
    'Iraklion': 'Iraklio',
    'Kamatero': 'Kamatero',
    'Keratsini': 'Keratsini',
    'Kifissias': 'Kifisia',
    'Kolonaki': 'Athens',
    'Koropi': 'Koropi',
    'Korydallos': 'Korydallos',
    'Kypseli': 'Athens',
    'Markopoulo': 'Markopoulo',
    'Melissia': 'Melissia',
    'Menidi': 'Acharnes',
    'Merlin': 'Athens',
    'Metamorphossis': 'Metamorfosi',
    'Mitropoleos': 'Athens',
    'Nea Erythraia': 'Nea Erythraia',
    'Nea Ionia': 'Nea Ionia',
    'Nea Kifissia': 'Nea Kifisia',
    'Nea Makri': 'Nea Makri',
    'Nea Philadelphia': 'Nea Filadelfeia',
    'Neo Kordelio': 'Neo Kordelio',
    'Neon Phaleron': 'Neo Faliro',
    'Nikaia': 'Nikaia',
    'Palaion Phaleron': 'Palaio Faliro',
    'Pallini': 'Pallini',
    'Pangrati': 'Athens',
    'Papagos': 'Papagos',
    'Pefki': 'Pefki',
    'Peristeri': 'Peristeri',
    'Petralona': 'Athens',
    'Philhellinon': 'Athens',
    'Psychico': 'Psychiko',
    'Psychico-Kollegio': 'Psychiko',
    'Rafina': 'Rafina',
    'Salamis': 'Salamina',
    'Stavroupolis': 'Stavroupoli',
    'Stournara': 'Athens',
    'Syngrou': 'Athens',
    'Tavros': 'Tavros',
    'Varkiza': 'Varkiza',
    'Voula': 'Voula',
    'Vrilissia': 'Vrilissia',
    'Vrioni': 'Piraeus',
    'Zografos': 'Zografou',
    'Passalimani': 'Piraeus',
    'Poros': 'Poros',
    'AEGINA': 'Aegina',
    # Specific street-based names → Athens
    'Acharnon': 'Athens',
    'Athinas': 'Athens',
    'Leoforou Alexandras': 'Athens',
    'Leoforou Athinon': 'Athens',
    'Leoforou Irakliou': 'Athens',
    'Leoforou Aghias Varvaras': 'Athens',
    'Leoforou Protopappa': 'Athens',
    'Ethnikis Antistasseos': 'Athens',
    'Ethnikis Odou Lamias': 'Athens',
    'Ethnikis Odou Paleokastritsas': 'Corfu',  # Kerkyra area
    # Square names
    'Amerikis Square': 'Athens',
    'Attikis Square': 'Athens',
    'Davaki Square': 'Athens',
    'Dikastirion Square': 'Athens',
    'Nea Smyrni Square': 'Nea Smyrni',
    'Peristeri Square': 'Peristeri',
    'Agias Paraskevis Square': 'Agia Paraskevi',
    'Kastalias sq.': 'Athens',
    # Shopping centre / special
    'Achilleion Shopping Centre Branch': 'Athens',
    # Main Branch typically = headquarters city
    'Main Branch': 'Athens',
    # Athens Tower - famous skyscraper
    'Athens Tower': 'Athens',
}

# Thessaloniki area neighborhoods
THESSALONIKI_NEIGHBORHOODS = {
    'Ano Toumba': 'Thessaloniki',
    'Charilaou': 'Thessaloniki',
    'Egnatias': 'Thessaloniki',
    'Evosmos': 'Evosmos',
    'Kalamaria': 'Kalamaria',
    'Langadas': 'Langadas',
    'Monastiriou': 'Thessaloniki',
    'Panorama': 'Pano Panorama',
    'Pavlou Mela': 'Thessaloniki',
    'Peraia Thessaloniki': 'Perea',
    'Stavroupolis': 'Stavroupoli',
    'Thermi': 'Thermi',
    'Tsimiski': 'Thessaloniki',
    'Toumba': 'Thessaloniki',
    'Neo Kordelio': 'Kordelio',
}

# Specific corrections for other cities
CITY_CORRECTIONS = {
    'EURITANIA Karpenissi': 'Karpenisi',
    'HALKIDIKI Kallithea Chalkidiki': 'Kallithea Chalkidikis',
    'HALKIDIKI Nea Moudania': 'Nea Moudania',
    'LASSITHI Aghios Nicolaos Crete': 'Agios Nikolaos',
    'LASSITHI Ierapetra': 'Ierapetra',
    'LASSITHI Sitia': 'Sitia',
    'RODOPI Komotini': 'Komotini',
    'MESSINIA Kalamata': 'Kalamata',
    'MESSINIA Kyparissia': 'Kyparissia',
    'Peraia Thessaloniki': 'Perea',
    'Aghios Nicolaos Rhodos': 'Agios Nikolaos Rodou',
    'Eden Mare': 'Vari',  # known resort area in Attica
    'Shipping': 'Piraeus',  # Shipping branch
    'Thessaloniki Industrial Estate': 'Thessaloniki',
    'Railway Station-Larissa': 'Larissa',
    'Neapolis-Volos': 'Volos',
    'Knossou Avenue': 'Heraklion',
    'Aghias Sophias-Patrai Branch': 'Patras',
    'Leoforou Chaina-Chalkida': 'Chalcis',
    'Ethnikis Odou Lamias': 'Lamia',
}

# Prefecture → main city mapping (for branches where city=landmark name)
PREFECTURE_MAIN_CITY = {
    'ATTICA': 'Athens',
    'THESSALONIKI': 'Thessaloniki',
    'HERAKLION': 'Heraklion',
    'ACHAIA': 'Patras',
    'LARISSA': 'Larissa',
    'MAGNESIA': 'Volos',
}


def clean_city(city: str, branch_name: str, prefecture: str) -> str:
    """Clean and correct city name."""
    if not city:
        return ""
    
    city = city.strip()
    
    # Apply direct corrections first
    if city in CITY_CORRECTIONS:
        return CITY_CORRECTIONS[city]
    
    # Check Attica-specific mapping
    if prefecture == 'ATTICA' and city in ATTICA_NEIGHBORHOOD_CITIES:
        return ATTICA_NEIGHBORHOOD_CITIES[city]
    
    # Check Thessaloniki-specific mapping
    if prefecture == 'THESSALONIKI' and city in THESSALONIKI_NEIGHBORHOODS:
        return THESSALONIKI_NEIGHBORHOODS[city]
    
    # Remove "Branch" suffix from city names
    city = re.sub(r'\s*Branch\s*$', '', city, flags=re.IGNORECASE).strip()
    
    # Remove "Square", "Avenue", "Street", "Sq." suffix → use prefecture main city
    if re.search(r'\b(Square|Avenue|Street|Sq\.|St\.)\b', city, re.IGNORECASE):
        # These are street/landmark names used as branch names
        # Map to the prefecture's main city
        return PREFECTURE_MAIN_CITY.get(prefecture, city)
    
    # If city contains "Leoforou" (Greek for "Avenue"), it's a street → use main city
    if 'Leoforou' in city or 'Ethnikis Odou' in city:
        return PREFECTURE_MAIN_CITY.get(prefecture, city)
    
    # Clean city names with prefecture prefix (e.g., "EURITANIA Karpenissi")
    # These weren't caught by the corrections dict
    parts = city.split()
    if parts[0].isupper() and len(parts[0]) > 3 and len(parts) > 1:
        # First token is ALL CAPS (likely a prefecture name) — take the rest
        return ' '.join(parts[1:])
    
    return city


def clean_encoding(text: str) -> str:
    """Fix encoding issues — remove control chars, fix smart quotes."""
    if not text:
        return text
    # Replace common encoding artifacts
    text = text.replace('\ufffd', '')  # replacement character
    text = text.replace('\u2019', "'").replace('\u2018', "'")
    text = text.replace('\u201c', '"').replace('\u201d', '"')
    text = re.sub(r'[^\x20-\x7E\s]', '', text)  # keep only printable ASCII
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def build_location_address(address: str, city: str, prefecture: str) -> str:
    """Build a clean, geocoding-friendly LOCATION_ADDRESS."""
    address = clean_encoding(address)
    address = address.replace('#', '')
    address = re.sub(r'\s+', ' ', address).strip()
    
    # Add city if not already in address
    if city and city.lower() not in address.lower():
        address = f"{address}, {city}"
    
    return address


if __name__ == '__main__':
    # Load intermediate CSV
    intermediate_csv = os.path.join(TEMP_DIR, f"{ISSUER_ID}_alpha_bank_intermediate.csv")
    df = pd.read_csv(intermediate_csv)
    print(f"Loaded {len(df)} records from intermediate CSV")
    
    # Apply city corrections
    df['CITY'] = df.apply(
        lambda row: clean_city(row['CITY'], row['LOCATION_NAME'], row['PREFECTURE']),
        axis=1
    )
    
    # Fix encoding issues in LOCATION_NAME
    df['LOCATION_NAME'] = df['LOCATION_NAME'].apply(clean_encoding)
    df['LOCATION_NAME_LOCAL'] = df['LOCATION_NAME']  # already English
    
    # Fix encoding in address fields
    df['LOCATION_ADDRESS'] = df.apply(
        lambda row: build_location_address(row['LOCATION_ADDRESS'], row['CITY'], row['PREFECTURE']),
        axis=1
    )
    df['LOCATION_ADDRESS_LOCAL'] = df['LOCATION_ADDRESS']
    
    # Verify no blank cities
    blank_cities = df['CITY'].isna() | (df['CITY'] == '')
    print(f"\nBlank city rows: {blank_cities.sum()}")
    if blank_cities.sum() > 0:
        print(df[blank_cities][['LOCATION_NAME', 'LOCATION_ADDRESS', 'PREFECTURE']].to_string())
    
    # Verify no blank addresses
    blank_addr = df['LOCATION_ADDRESS'].isna() | (df['LOCATION_ADDRESS'] == '')
    print(f"Blank address rows: {blank_addr.sum()}")
    
    # Show sample of fixed data
    print("\nSample records after cleaning:")
    print(df[['LOCATION_NAME', 'LOCATION_ADDRESS', 'CITY', 'STATE', 'PREFECTURE']].head(15).to_string())
    
    # Final column selection and ordering
    output_cols = [
        'ISSUER_ID', 'ISSUER_NAME',
        'LOCATION_NAME', 'LOCATION_NAME_LOCAL',
        'LOCATION_ADDRESS', 'LOCATION_ADDRESS_LOCAL',
        'LATITUDE', 'LONGITUDE',
        'COUNTRY', 'COUNTRY_ISO3',
        'POSTCODE', 'STATE', 'CITY',
        'SOURCE_URL', 'SOURCE_TYPE',
        'ACTIVITY_AT_ASSET',
        'coord_source',
        'PHONE', 'CATEGORY', 'PREFECTURE',
    ]
    
    # Ensure all output cols exist
    for col in output_cols:
        if col not in df.columns:
            df[col] = ''
    
    df_out = df[output_cols].copy()
    
    # Save final CSV
    final_csv_name = f"{ISSUER_ID}_{ISSUER_NAME}.csv"
    final_csv_path = os.path.join(OUTPUT_DIR, final_csv_name)
    df_out.to_csv(final_csv_path, index=False, encoding='utf-8-sig')
    print(f"\nFinal CSV saved: {final_csv_path}")
    print(f"Total records: {len(df_out)}")
    
    # Stats
    print(f"\nRecords by prefecture:")
    for pref, cnt in df_out['PREFECTURE'].value_counts().items():
        print(f"  {pref}: {cnt}")
    
    print(f"\nRecords by category:")
    for cat, cnt in df_out['CATEGORY'].value_counts().items():
        print(f"  Category {cat}: {cnt}")
    
    print(f"\nSource type: {df_out['SOURCE_TYPE'].unique()}")
    print(f"Country: {df_out['COUNTRY'].unique()}")
    print(f"Coord source: {df_out['coord_source'].unique()}")
