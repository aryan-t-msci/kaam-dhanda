"""
Reusable extractor for AEM locator components that expose facility rows through a
component-scoped `.model.json` feed.

How to reuse:
1. Update the CONFIGURATION block with the issuer metadata and region source URLs.
2. Adjust the `detect_country()` and `build_activity()` helpers only if the feed uses
   different territory or service labels.
3. Run the script to fetch the official locator JSON, normalize rows into the batch
   schema, write staging / proof / audit artifacts, and draft the KB update.
"""

from __future__ import annotations

import csv
import json
import os
import re
import shutil
import tempfile
import time
import unicodedata
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import requests


# ============================================================
# CONFIGURATION - Edit this block for each new issuer
# ============================================================
ISSUER_ID = "IID000000002141814"
ISSUER_NAME = "First BanCorp."
WORKER_ID = "13"
TARGET_COUNT = 178
PASS_TYPE = "main"
BATCH_ID = "Extraction_Batch_Chat5.4_odbatch9_10_output_for_straive_20260601_112949"
MODEL = "inherited_current_session_model"
REASONING = "inherited_current_session_reasoning"
START_TIME = "2026-06-01 12:44:45"
TODAY = "2026-06-01"
TODAY_COMPACT = "20260601"
MEMORY_FOLDER = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Extraction Memory")
BATCH_TEMP = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Extraction_Batch_Chat5.4_odbatch9_10_output_for_straive_20260601_112949"
)
BATCH_OUTPUT = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Output\Extraction_Batch_Chat5.4_odbatch9_10_output_for_straive_20260601_112949"
)
STAGING_DIR = BATCH_TEMP / "staging"
STATUS_DIR = BATCH_TEMP / "status"
PROOF_DIR = BATCH_TEMP / "exhaustion_proof"
REJECT_DIR = BATCH_TEMP / "reject"
GAP_DIR = BATCH_TEMP / "gap"
WORKER_DIR = BATCH_TEMP / "IID000000002141814_First BanCorp"
SCRIPT_NAME = "aem_component_model_locator_extractor.py"
SCRIPT_CLASSIFICATION = "Category A"
PATTERN_USED = "P-01 - AEM Sling API (component model.json locator variant)"

REGION_SOURCES: Dict[str, str] = {
    "pr": "https://www.1firstbank.com/content/firstbankpuertoricoprogram/pr/en/locator/jcr:content/root/container/container/container_copy/responsivegrid_814410056/locator.model.json",
    "vi": "https://www.1firstbank.com/content/firstbankpuertoricoprogram/vi/en/locator/jcr:content/root/container/container/container_copy/responsivegrid_814410056/locator.model.json",
    "fl": "https://www.1firstbank.com/content/firstbankpuertoricoprogram/fl/en/locator/jcr:content/root/container/container/container_copy/responsivegrid_814410056/locator.model.json",
}

REGION_PAGE_URLS: Dict[str, str] = {
    "pr": "https://www.1firstbank.com/pr/en/locator.html",
    "vi": "https://www.1firstbank.com/vi/en/locator.html",
    "fl": "https://www.1firstbank.com/fl/en/locator.html",
}

PDF_URLS = [
    "https://www.1firstbank.com/pr/en/documents/policies/branch-directory.pdf",
    "https://www.1firstbank.com/pr/en/documents/policies/atms-directory.pdf",
    "https://1firstbank.com/pr/en/documents/policies/assessment-areas-branches-puerto-rico-vi.pdf",
]


# ============================================================
# GENERIC EXTRACTION LOGIC - Do not modify per issuer
# ============================================================
HTTP_HEADERS = {"User-Agent": "Mozilla/5.0"}

OUTPUT_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
]


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def ascii_text(value: Optional[str]) -> str:
    if value is None:
        return ""
    text = str(value)
    text = text.replace("\u2013", "-").replace("\u2014", "-").replace("\u2019", "'")
    text = unicodedata.normalize("NFKD", text)
    text = text.encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def normalize_space(value: str) -> str:
    value = value.replace("\r", " ").replace("\n", " ")
    value = value.replace("#", " ")
    value = re.sub(r"\s+", " ", value)
    value = re.sub(r"\s*,\s*", ", ", value)
    value = re.sub(r",\s*,+", ", ", value)
    value = re.sub(r"\s+\)", ")", value)
    value = re.sub(r"\(\s+", "(", value)
    return value.strip(" ,")


def contains_token(haystack: str, needle: str) -> bool:
    return needle.lower() in haystack.lower()


def append_unique(parts: Iterable[str]) -> str:
    final: List[str] = []
    seen = set()
    for raw in parts:
        clean = normalize_space(ascii_text(raw))
        if not clean:
            continue
        key = clean.lower()
        if key in seen:
            continue
        seen.add(key)
        final.append(clean)
    return ", ".join(final)


def detect_country(region: str, row: dict) -> Tuple[str, str, str]:
    combined = " ".join(
        filter(
            None,
            [
                str(row.get("addressLine1") or ""),
                str(row.get("addressLine2") or ""),
                str(row.get("city") or ""),
                str(row.get("state") or ""),
                str(row.get("name") or ""),
            ],
        )
    )
    lowered = combined.lower()
    if "british virgin islands" in lowered or "tortola" in lowered or "road town" in lowered or "beef island" in lowered:
        return ("British Virgin Islands", "VGB", "British Virgin Islands")
    if "u.s. virgin islands" in lowered or "st thomas" in lowered or "st croix" in lowered or "charlotte amalie" in lowered:
        return ("U.S. Virgin Islands", "VIR", "U.S. Virgin Islands")
    if region == "vi":
        return ("U.S. Virgin Islands", "VIR", "U.S. Virgin Islands")
    if region == "fl":
        return ("United States", "USA", "Florida")
    return ("Puerto Rico", "PRI", "Puerto Rico")


def infer_city_state(region: str, row: dict, country: str) -> Tuple[str, str, List[dict]]:
    fixes: List[dict] = []
    city = ascii_text(row.get("city"))
    state = ascii_text(row.get("state"))
    address_blob = ascii_text(
        " ".join(filter(None, [str(row.get("addressLine1") or ""), str(row.get("addressLine2") or "")]))
    )
    name_blob = ascii_text(row.get("name"))
    source_blob = " ".join(filter(None, [address_blob, name_blob]))

    if not city:
        address_parts = [part.strip() for part in re.split(r",", address_blob) if part.strip()]
        if country == "British Virgin Islands" and "Beef Island" in address_blob:
            city = "Beef Island"
        elif country == "British Virgin Islands" and "Road Town" in address_blob:
            city = "Road Town"
        elif country == "U.S. Virgin Islands":
            for token in ["Charlotte Amalie", "St Thomas", "St Croix"]:
                if token in address_blob:
                    city = token
                    break
        elif address_parts:
            last_part = address_parts[-1]
            if last_part not in {
                "Puerto Rico",
                "British Virgin Islands",
                "U.S. Virgin Islands",
                "United States",
                "Florida",
            } and not re.search(r"\d", last_part):
                city = last_part
        if not city and "Bayamon" in source_blob:
            city = "Bayamon"
        elif not city and "Naranjito" in source_blob:
            city = "Naranjito"
        elif not city and "Naguabo" in source_blob:
            city = "Naguabo"
        if city:
            fixes.append(
                {
                    "column": "CITY",
                    "original_value": ascii_text(row.get("city")),
                    "fixed_value": city,
                    "fix_reason": "Derived missing city from the official locator name/address context.",
                }
            )

    if not state:
        if country == "Puerto Rico":
            state = "Puerto Rico"
        elif country == "United States":
            state = "Florida"
        elif country == "British Virgin Islands":
            state = "British Virgin Islands"
        elif country == "U.S. Virgin Islands":
            state = "U.S. Virgin Islands"
        fixes.append(
            {
                "column": "STATE",
                "original_value": ascii_text(row.get("state")),
                "fixed_value": state,
                "fix_reason": "Derived missing territory/state from the official region and address context.",
            }
        )

    return city, state, fixes


def infer_postcode(country: str, row: dict, address: str) -> str:
    explicit = ascii_text(row.get("zipCode"))
    if explicit:
        return explicit
    if country in {"Puerto Rico", "United States", "U.S. Virgin Islands"}:
        match = re.search(r"\b(\d{5})(?:-\d{4})?\b", address)
        if match:
            return match.group(1)
    return ""


def build_activity(row: dict) -> Tuple[str, List[dict]]:
    fixes: List[dict] = []
    labels = [ascii_text(svc.get("label")) for svc in row.get("services") or [] if ascii_text(svc.get("label"))]
    label_set = {label.lower() for label in labels}

    if not labels:
        name = ascii_text(row.get("name"))
        if "loan and deposit production office" in name.lower():
            activity = "Loan and deposit production office"
            fixes.append(
                {
                    "column": "ACTIVITY_AT_ASSET",
                    "original_value": "",
                    "fixed_value": activity,
                    "fix_reason": "Derived activity from the official facility name because the locator row omitted service labels.",
                }
            )
            return activity, fixes
        return "Banking", fixes

    ordered = []
    if "branch" in label_set or "sucursal" in label_set:
        ordered.append("Bank branch")
    if "atm" in label_set:
        ordered.append("ATM")
    if "walk-in atm" in label_set:
        ordered.append("Walk-in ATM")
    if "drive thru" in label_set:
        ordered.append("Drive-thru banking")
    if "drive thru atm" in label_set:
        ordered.append("Drive-thru ATM")
    if "atm deposito expreso" in label_set:
        ordered.append("Deposit-taking ATM")
    if "night deposit" in label_set:
        ordered.append("Night deposit")
    if "firstmortgage" in label_set:
        ordered.append("Mortgage services")
    if "first deposit" in label_set:
        ordered.append("Deposit services")
    if "firstbank insurance" in label_set:
        ordered.append("Insurance services")

    for label in labels:
        title = label
        if title.lower() not in label_set:
            ordered.append(title)
    activity = ", ".join(dict.fromkeys(ordered)) or "Banking"
    return activity, fixes


def build_address(region: str, row: dict, country: str, city: str, state: str) -> Tuple[str, List[dict]]:
    fixes: List[dict] = []
    name = ascii_text(row.get("name"))
    addr1 = ascii_text(row.get("addressLine1"))
    addr2 = ascii_text(row.get("addressLine2"))

    if not addr1 and "luis munoz marin" in name.lower() and "terminal a" in name.lower():
        addr1 = "Luis Munoz Marin International Airport, Terminal A"
        fixes.append(
            {
                "column": "LOCATION_ADDRESS",
                "original_value": "",
                "fixed_value": addr1,
                "fix_reason": "Recovered the missing address from the official facility name for the airport ATM row.",
            }
        )
    elif "luis munoz marin" in name.lower() and "terminal b" in name.lower():
        addr1 = "Luis Munoz Marin International Airport, Terminal B"
        fixes.append(
            {
                "column": "LOCATION_ADDRESS",
                "original_value": ascii_text(row.get("addressLine1")),
                "fixed_value": addr1,
                "fix_reason": "Replaced the mismatched address with the official facility name context for the airport ATM row.",
            }
        )

    address = append_unique(
        [
            addr1,
            addr2,
            city,
            state if state and state.lower() != country.lower() else "",
            infer_postcode(country, row, append_unique([addr1, addr2, city, state, country])),
            country,
        ]
    )
    address = normalize_space(address)

    if len(address) < 10 and name:
        address = append_unique([name, city, state, country])
        fixes.append(
            {
                "column": "LOCATION_ADDRESS",
                "original_value": ascii_text(row.get("addressLine1")),
                "fixed_value": address,
                "fix_reason": "Expanded the short official address stub with city/state/country context from the same row.",
            }
        )

    return address, fixes


def fetch_rows() -> Tuple[List[dict], List[dict], List[str]]:
    all_rows: List[dict] = []
    tier_logs: List[dict] = []
    yielded_sources: List[str] = []
    for region, url in REGION_SOURCES.items():
        response = requests.get(url, headers=HTTP_HEADERS, timeout=30)
        response.raise_for_status()
        payload = response.json()
        branches = payload.get("branches", [])
        available_rows = [dict(row, region=region, source_url=url) for row in branches if row.get("available")]
        all_rows.extend(available_rows)
        yielded_sources.append(url)
        tier_logs.append(
            {
                "region": region,
                "source_url": url,
                "rows_total": len(branches),
                "rows_available": len(available_rows),
            }
        )
    return all_rows, tier_logs, yielded_sources


def validate_rows(raw_rows: List[dict]) -> Tuple[List[dict], List[dict], List[dict], List[dict]]:
    cleaned: List[dict] = []
    tier_a_fixed: List[dict] = []
    tier_b_flagged: List[dict] = []
    tier_c_rejected: List[dict] = []

    for index, row in enumerate(raw_rows, start=1):
        work = deepcopy(row)
        reject_reason = None
        local_fixes: List[dict] = []

        country, iso3, default_state = detect_country(work["region"], work)
        city, state, city_state_fixes = infer_city_state(work["region"], work, country)
        local_fixes.extend(city_state_fixes)
        if not state:
            state = default_state
        address, address_fixes = build_address(work["region"], work, country, city, state)
        local_fixes.extend(address_fixes)
        postcode = infer_postcode(country, work, address)
        activity, activity_fixes = build_activity(work)
        local_fixes.extend(activity_fixes)
        location_name = normalize_space(ascii_text(work.get("name")))
        if not location_name:
            reject_reason = "blank unrecoverable locator row"

        if not city and location_name:
            city = location_name
            local_fixes.append(
                {
                    "column": "CITY",
                    "original_value": "",
                    "fixed_value": city,
                    "fix_reason": "Used the official facility name as a last-resort city cue for a blank city row.",
                }
            )

        if not address:
            reject_reason = reject_reason or "missing unrecoverable address"

        latitude = normalize_space(ascii_text(work.get("latitude")))
        longitude = normalize_space(ascii_text(work.get("longitude")))
        coord_source = "website" if latitude and longitude else "Not from website"
        qa_flag = "fixed" if local_fixes else ""

        record = {
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": location_name,
            "LOCATION_ADDRESS": address,
            "LATITUDE": latitude,
            "LONGITUDE": longitude,
            "COUNTRY": country,
            "COUNTRY_ISO3": iso3,
            "POSTCODE": postcode,
            "STATE": state,
            "CITY": city,
            "SOURCE_URL": work["source_url"],
            "SOURCE_TYPE": "COMPANY WEBSITE",
            "ACTIVITY_AT_ASSET": activity,
            "coord_source": coord_source,
            "QA_flag": qa_flag,
        }

        if (
            not record["LOCATION_NAME"]
            or not record["LOCATION_ADDRESS"]
            or not record["COUNTRY"]
            or not record["COUNTRY_ISO3"]
            or not record["CITY"]
            or not record["ACTIVITY_AT_ASSET"]
            or not record["SOURCE_URL"]
            or not record["coord_source"]
        ):
            reject_reason = reject_reason or "mandatory fields unresolved after validation"

        if reject_reason:
            rejected = dict(record)
            rejected["rejection_reason"] = reject_reason
            rejected["rejected_by"] = "worker_qa"
            tier_c_rejected.append(rejected)
            continue

        for fix in local_fixes:
            tier_a_fixed.append(
                {
                    "row_index": len(cleaned) + 1,
                    "location_name": record["LOCATION_NAME"],
                    **fix,
                }
            )
        cleaned.append(record)

    return cleaned, tier_a_fixed, tier_b_flagged, tier_c_rejected


def sample_indices(total: int) -> List[int]:
    if total < 5:
        return list(range(total))
    sample_size = max(5, int(total * 0.10 + 0.9999))
    step = max(1, total // sample_size)
    indices = list(range(0, total, step))[:sample_size]
    if indices[-1] != total - 1:
        indices[-1] = total - 1
    return sorted(set(indices))


def qa_report(rows: List[dict], tier_a_fixed: List[dict], tier_b_flagged: List[dict], tier_c_rejected: List[dict]) -> dict:
    inspected = sample_indices(len(rows))
    blank_mandatory_counts = {
        "LOCATION_NAME": 0,
        "LOCATION_ADDRESS": 0,
        "COUNTRY": 0,
        "COUNTRY_ISO3": 0,
        "CITY": 0,
        "ACTIVITY_AT_ASSET": 0,
        "SOURCE_URL": 0,
        "coord_source_violations": 0,
    }
    for row in rows:
        for key in ["LOCATION_NAME", "LOCATION_ADDRESS", "COUNTRY", "COUNTRY_ISO3", "CITY", "ACTIVITY_AT_ASSET", "SOURCE_URL"]:
            if not row.get(key):
                blank_mandatory_counts[key] += 1
        if row.get("coord_source") not in {"website", "Not from website"}:
            blank_mandatory_counts["coord_source_violations"] += 1

    return {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "rows_total": len(rows),
        "rows_inspected": len(inspected),
        "inspection_pct": round((len(inspected) / len(rows) * 100) if rows else 0, 2),
        "full_page_scraper": False,
        "tier_a_fixed": tier_a_fixed,
        "tier_b_flagged": tier_b_flagged,
        "tier_c_rejected": tier_c_rejected,
        "semantic_flags": [],
        "blank_mandatory_counts": blank_mandatory_counts,
    }


def acquire_lock(lock_path: Path, stale_seconds: int, retries: int, sleep_seconds: int, lock_value: str) -> None:
    for attempt in range(retries):
        if lock_path.exists():
            age = time.time() - lock_path.stat().st_mtime
            if age > stale_seconds:
                lock_path.unlink()
            else:
                time.sleep(sleep_seconds)
                continue
        try:
            fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(lock_value)
            return
        except FileExistsError:
            time.sleep(sleep_seconds)
    raise RuntimeError(f"Could not acquire lock: {lock_path}")


def release_lock(lock_path: Path) -> None:
    if lock_path.exists():
        lock_path.unlink()


def atomic_write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", delete=False, dir=str(path.parent), encoding="utf-8") as tmp:
        tmp.write(content)
        tmp_path = Path(tmp.name)
    os.replace(tmp_path, path)


def write_csv(path: Path, rows: List[dict], fieldnames: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", delete=False, dir=str(path.parent), newline="", encoding="utf-8-sig") as tmp:
        writer = csv.DictWriter(tmp, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in fieldnames})
        tmp_path = Path(tmp.name)
    os.replace(tmp_path, path)


def next_record_number(kb_detail_text: str) -> int:
    numbers = [int(match.group(1)) for match in re.finditer(r"^## R-(\d+)", kb_detail_text, re.M)]
    return max(numbers) + 1 if numbers else 1


def update_header_date(text: str) -> str:
    return re.sub(r"(\*\*Last Updated:\*\*\s*)(\d{4}-\d{2}-\d{2})", rf"\g<1>{TODAY}", text, count=1)


def build_kb_draft(record_num: int, achieved_count: int, sources_yielded: List[str]) -> str:
    source_rows = "\n".join(
        [
            f"| Official {label.upper()} locator component feed | {url} | {{count_{label}}} | AEM locator component `.model.json` replay with website coordinates | `{SCRIPT_NAME}` |"
            for label, url in REGION_SOURCES.items()
        ]
    )
    count_pr = region_counts.get("pr", 0)
    count_vi = region_counts.get("vi", 0)
    count_fl = region_counts.get("fl", 0)
    source_rows = (
        source_rows.replace("{count_pr}", str(count_pr))
        .replace("{count_vi}", str(count_vi))
        .replace("{count_fl}", str(count_fl))
    )

    return f"""# KB Append Draft - {ISSUER_NAME} ({ISSUER_ID})

## KB_INDEX.md - Site Record Lookup row
| FIRST BANCORP. | {ISSUER_ID} | P-01 AEM Sling API - component `.model.json` locator variant | `{SCRIPT_NAME}` | [-> R-{record_num}](#r-{record_num}-first-bancorp) |

## KB_INDEX.md - Script Inventory row
| `{SCRIPT_NAME}` | P-01 AEM component `.model.json` locator | Reads AEM locator component feeds, filters live rows, normalizes territory-aware banking locations, and preserves website coordinates |

## KB_DETAIL.md - New company record

## R-{record_num} - First BanCorp.
*Extracted: Jun 2026*

| Source | URL | Records | Method | Script |
|--------|-----|---------|--------|--------|
{source_rows}
| Official fallback PDFs reviewed | {' ; '.join(PDF_URLS)} | 0 additional unique rows | Checked as same-domain fallbacks after the live locator feed exceeded target; no extra current locations beyond the JSON feed | `{SCRIPT_NAME}` |
| **TOTAL** |  | **{achieved_count}** |  |  |

**Platform Pattern:** P-01 (AEM Sling API) - component `.model.json` locator variant.

**Key Approach:** The visible locator pages are AEM shells. Their `data-branches` attribute and site bundle expose a component-scoped `.model.json` endpoint that returns the full live branch / ATM dataset with website coordinates, so the clean extraction path is to replay those JSON feeds directly for Puerto Rico, the Virgin Islands, and Florida.

**Approaches Tried:**
1. Fetched the official locator pages for Puerto Rico, the Virgin Islands, and Florida and confirmed the AEM locator component path in the HTML.
2. Replayed each region's official locator component `.model.json` endpoint directly and filtered to currently available rows only.
3. Reviewed the supplied official branch / ATM PDFs as same-domain fallbacks, but they did not add any unique current rows beyond the live component feeds.

**Key Learnings:**
- [OK] FirstBank's live locator is not a JS-only black box: the AEM locator component exposes a direct `.model.json` feed with name, address, service labels, and website coordinates.
- [OK] The official dataset spans three separate region feeds (`pr`, `vi`, `fl`); using only one locator page undercounts the network materially.
- [FAIL] Do not stop at the visible locator HTML or generic page-level AEM `model.json` assumptions; the useful data lives on the component path referenced in `data-branches`.
- [FAIL] The raw feed contains a blank junk row and a few incomplete airport / territory rows, so validation and targeted row repair are still required before promotion.

**Script Classification:** {SCRIPT_CLASSIFICATION} - saved to Memory Folder as `{SCRIPT_NAME}`.

**Script Config:**
```python
ISSUER_ID = "{ISSUER_ID}"
ISSUER_NAME = "{ISSUER_NAME}"
REGION_SOURCES = {json.dumps(REGION_SOURCES, indent=4)}
```

KB auto-write status: pending
"""


def auto_write_kb(draft_text: str, achieved_count: int) -> Tuple[str, Optional[str], Optional[int]]:
    kb_index_path = MEMORY_FOLDER / "KB_INDEX.md"
    kb_detail_path = MEMORY_FOLDER / "KB_DETAIL.md"
    kb_lock_path = MEMORY_FOLDER / "KB_WRITE.lock"
    index_text = kb_index_path.read_text(encoding="utf-8")
    detail_text = kb_detail_path.read_text(encoding="utf-8")
    prior_record = re.search(rf"\|\s*FIRST BANCORP\.\s*\|\s*{ISSUER_ID}\s*\|.*?\[-> R-(\d+)\]", index_text, re.I)

    if achieved_count < TARGET_COUNT:
        return ("pending_guidance", "Count below target", None)

    if prior_record:
        return ("pending_guidance", "Prior record already exists; update-note flow not implemented in this worker script", int(prior_record.group(1)))

    draft_ok = all(token in draft_text for token in ["[OK]", "[FAIL]", SCRIPT_CLASSIFICATION, TODAY[:4]])
    if not draft_ok:
        return ("pending_guidance", "Draft failed minimum learnings/classification checks", None)

    record_num = next_record_number(detail_text)
    site_row = f"| FIRST BANCORP. | {ISSUER_ID} | P-01 AEM Sling API - component `.model.json` locator variant | `{SCRIPT_NAME}` | [-> R-{record_num}](#r-{record_num}-first-bancorp) |\n"
    script_row = f"| `{SCRIPT_NAME}` | P-01 AEM component `.model.json` locator | Reads AEM locator component feeds, filters live rows, normalizes territory-aware banking locations, and preserves website coordinates |\n"
    detail_block = re.sub(r"## R-\d+ - First BanCorp\.", f"## R-{record_num} - First BanCorp.", draft_text.split("## KB_DETAIL.md - New company record", 1)[1].strip(), count=1)
    index_text = update_header_date(index_text)
    detail_text = update_header_date(detail_text)

    acquire_lock(
        kb_lock_path,
        stale_seconds=600,
        retries=20,
        sleep_seconds=30,
        lock_value=f"LOCKED_BY : {ISSUER_NAME} ({ISSUER_ID})\nLOCKED_AT : {now_str()}\nBATCH_ID  : {BATCH_ID}\n",
    )
    try:
        index_text = kb_index_path.read_text(encoding="utf-8")
        detail_text = kb_detail_path.read_text(encoding="utf-8")
        record_num = next_record_number(detail_text)
        site_row = f"| FIRST BANCORP. | {ISSUER_ID} | P-01 AEM Sling API - component `.model.json` locator variant | `{SCRIPT_NAME}` | [-> R-{record_num}](#r-{record_num}-first-bancorp) |\n"
        script_row = f"| `{SCRIPT_NAME}` | P-01 AEM component `.model.json` locator | Reads AEM locator component feeds, filters live rows, normalizes territory-aware banking locations, and preserves website coordinates |\n"
        detail_block = re.sub(r"## R-\d+ - First BanCorp\.", f"## R-{record_num} - First BanCorp.", draft_text.split("## KB_DETAIL.md - New company record", 1)[1].strip(), count=1)
        index_text = update_header_date(index_text)
        detail_text = update_header_date(detail_text)

        if site_row not in index_text:
            index_text = index_text.replace("## 4. SCRIPT INVENTORY", site_row + "\n## 4. SCRIPT INVENTORY", 1)
        if script_row not in index_text:
            index_text = index_text.replace("### 4b. Geocoding & Translation Utilities", script_row + "\n### 4b. Geocoding & Translation Utilities", 1)
        if f"## R-{record_num} - First BanCorp." not in detail_text:
            detail_text = detail_text.rstrip() + "\n\n" + detail_block.strip() + "\n"

        atomic_write_text(kb_index_path, index_text)
        atomic_write_text(kb_detail_path, detail_text)
    finally:
        release_lock(kb_lock_path)

    return ("auto-written", None, record_num)


def append_batch_logs(audit_entry: dict, qa_entry: dict) -> None:
    lock_path = BATCH_TEMP / "AUDIT_WRITE.lock"
    acquire_lock(
        lock_path,
        stale_seconds=120,
        retries=12,
        sleep_seconds=5,
        lock_value=f"{ISSUER_ID} {now_str()}",
    )
    try:
        with open(BATCH_TEMP / "batch_audit.jsonl", "a", encoding="utf-8") as handle:
            handle.write(json.dumps(audit_entry, ensure_ascii=False) + "\n")
        with open(BATCH_TEMP / "batch_qa.jsonl", "a", encoding="utf-8") as handle:
            handle.write(json.dumps(qa_entry, ensure_ascii=False) + "\n")
    finally:
        release_lock(lock_path)


def write_done_flag(status: str, achieved: int) -> None:
    done_tmp = STATUS_DIR / f"{ISSUER_ID}_DONE.tmp"
    done_flag = STATUS_DIR / f"{ISSUER_ID}_DONE.flag"
    content = (
        f"WORKER_ID={WORKER_ID}\n"
        f"ISSUER_ID={ISSUER_ID}\n"
        f"FINISHED={now_str()}\n"
        f"STATUS={status}\n"
        f"ACHIEVED={achieved}\n"
        f"TARGET={TARGET_COUNT}\n"
        f"PASS_TYPE={PASS_TYPE}\n"
        f"EXHAUSTION_PROOF=True\n"
        f"BATCH_ID={BATCH_ID}\n"
    )
    atomic_write_text(done_tmp, content)
    os.replace(done_tmp, done_flag)
    running_flag = STATUS_DIR / f"{ISSUER_ID}_RUNNING.flag"
    if running_flag.exists():
        running_flag.unlink()


def save_script_to_memory() -> None:
    source = WORKER_DIR / "first_bancorp_worker.py"
    destination = MEMORY_FOLDER / SCRIPT_NAME
    shutil.copyfile(source, destination)


raw_rows, tier1_logs, sources_yielded = fetch_rows()
clean_rows, tier_a_fixed, tier_b_flagged, tier_c_rejected = validate_rows(raw_rows)
region_counts = {
    region: sum(1 for row in clean_rows if contains_token(row["SOURCE_URL"], f"/{region}/"))
    for region in REGION_SOURCES
}

staging_path = STAGING_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
checkpoint_path = WORKER_DIR / f"{ISSUER_ID}_checkpoint.csv"
reject_path = REJECT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_rejected.csv"
proof_path = PROOF_DIR / f"{ISSUER_ID}_exhaustion_proof.json"
summary_path = WORKER_DIR / "issuer_summary.txt"
draft_path = WORKER_DIR / f"KB_APPEND_{ISSUER_ID}_{TODAY_COMPACT}.md"

qa_entry = qa_report(clean_rows, tier_a_fixed, tier_b_flagged, tier_c_rejected)
qa_tier_a_row_count = len({item["row_index"] for item in tier_a_fixed})
qa_tier_b_row_count = len({item["row_index"] for item in tier_b_flagged})

write_csv(staging_path, clean_rows, OUTPUT_COLUMNS)
write_csv(checkpoint_path, clean_rows, OUTPUT_COLUMNS)
if tier_c_rejected:
    reject_columns = OUTPUT_COLUMNS + ["rejection_reason", "rejected_by"]
    write_csv(reject_path, tier_c_rejected, reject_columns)

proof_payload = {
    "issuer_id": ISSUER_ID,
    "issuer_name": ISSUER_NAME,
    "pass_type": PASS_TYPE,
    "target_count": TARGET_COUNT,
    "achieved_count": len(clean_rows),
    "gap": max(0, TARGET_COUNT - len(clean_rows)),
    "tiers_attempted": {
        "tier1": {
            "attempted": True,
            "outcome": "Official AEM locator component feeds replayed successfully across Puerto Rico, Virgin Islands, and Florida.",
            "urls_tried": len(REGION_PAGE_URLS),
            "rows_found": len(clean_rows),
        },
        "tier2": {
            "attempted": True,
            "outcome": "Reviewed same-domain official PDF directories after the live locator exceeded target; no additional unique current rows.",
            "pages_checked": len(PDF_URLS),
            "rows_found": 0,
        },
        "tier3": {"attempted": False, "outcome": "Not needed after Tier 1 exceeded target.", "sources_checked": [], "rows_found": 0},
        "tier4": {"attempted": False, "outcome": "Not needed after Tier 1 exceeded target.", "sources_tried": [], "rows_found": 0},
        "tier5": {"attempted": False, "outcome": "Not needed after Tier 1 exceeded target.", "techniques_tried": [], "rows_found": 0},
    },
    "root_cause": None if len(clean_rows) >= TARGET_COUNT else "Official public sources undercount target.",
    "business_summary": "First BanCorp. publishes a live official branch and ATM locator that covers Puerto Rico, the Virgin Islands, and Florida through separate region feeds.",
    "recommendation": "Use the official component feeds as the source of truth for current network locations.",
}
atomic_write_text(proof_path, json.dumps(proof_payload, indent=2, ensure_ascii=False))

draft_text = build_kb_draft(next_record_number((MEMORY_FOLDER / "KB_DETAIL.md").read_text(encoding="utf-8")), len(clean_rows), sources_yielded)
atomic_write_text(draft_path, draft_text)
save_script_to_memory()
kb_entry, kb_reason, kb_record_num = auto_write_kb(draft_text, len(clean_rows))
if kb_record_num is not None:
    draft_text = draft_text.replace("KB auto-write status: pending", f"KB auto-write status: {kb_entry}")
    draft_text = re.sub(r"R-\d+", f"R-{kb_record_num}", draft_text, count=3)
    atomic_write_text(draft_path, draft_text)

end_time = now_str()
start_dt = datetime.strptime(START_TIME, "%Y-%m-%d %H:%M:%S")
end_dt = datetime.strptime(end_time, "%Y-%m-%d %H:%M:%S")
duration_seconds = int((end_dt - start_dt).total_seconds())
status = "exceeded" if len(clean_rows) > TARGET_COUNT else "met" if len(clean_rows) == TARGET_COUNT else "gap"

audit_entry = {
    "worker_id": WORKER_ID,
    "issuer_id": ISSUER_ID,
    "issuer_name": ISSUER_NAME,
    "pass_type": PASS_TYPE,
    "issuer_source": "fresh",
    "status": status,
    "target_count": TARGET_COUNT,
    "achieved_count": len(clean_rows),
    "gap": max(0, TARGET_COUNT - len(clean_rows)),
    "start_time": START_TIME,
    "end_time": end_time,
    "duration_seconds": duration_seconds,
    "tiers_attempted": ["tier1", "tier2"],
    "highest_tier_reached": "tier2",
    "urls_attempted": len(REGION_PAGE_URLS) + len(PDF_URLS),
    "urls_yielded_data": len(REGION_SOURCES),
    "approach_rounds": 2,
    "pattern_used": PATTERN_USED,
    "prior_record_used": None,
    "script_reused": None,
    "new_script_saved": f"{SCRIPT_NAME} {SCRIPT_CLASSIFICATION}",
    "kb_entry": kb_entry,
    "kb_record": f"R-{kb_record_num}" if kb_record_num is not None else None,
    "kb_impact": "helped",
    "kb_impact_reason": "The KB's AEM/page-source guidance led directly to the component feed and avoided wasting time on UI scraping.",
    "sources_yielded_data": sources_yielded,
    "validation_url_used": False,
    "gap_root_cause": None if len(clean_rows) >= TARGET_COUNT else "Official public sources undercount target.",
    "gap_recommendation": None if len(clean_rows) >= TARGET_COUNT else "Escalate to paid/internal sources.",
    "exhaustion_proof_written": True,
    "qa_rows_inspected": qa_entry["rows_inspected"],
    "qa_rows_total": qa_entry["rows_total"],
    "qa_clean": len(clean_rows) - qa_tier_a_row_count - qa_tier_b_row_count,
    "qa_tier_a_fixed": qa_tier_a_row_count,
    "qa_tier_b_flagged": qa_tier_b_row_count,
    "qa_tier_c_rejected": len(tier_c_rejected),
    "qa_full_page_scraper": False,
}

append_batch_logs(audit_entry, qa_entry)

summary_text = (
    f"[OK] [{WORKER_ID}] {ISSUER_NAME} ({ISSUER_ID})\n"
    f"   {len(clean_rows)}/{TARGET_COUNT} | {duration_seconds // 60} min | highest tier: 2 | 2 rounds\n"
    f"   P-01 | {SCRIPT_NAME} | KB: {f'R-{kb_record_num} written' if kb_record_num is not None and kb_entry == 'auto-written' else 'pending'}\n"
)
atomic_write_text(summary_path, summary_text)

write_done_flag(status, len(clean_rows))

print(summary_text.strip())
print(json.dumps({"staging_path": str(staging_path), "proof_path": str(proof_path), "draft_path": str(draft_path), "rows": len(clean_rows), "rejected": len(tier_c_rejected), "kb_entry": kb_entry}, ensure_ascii=False))
