"""Secmaster + URL helpers for the row-by-row issuer check (Cowork handoff).
Only pandas (+ optional tldextract) needed. Load once:  from helpers import *; load('sec_master_20260828.parquet')"""
import re, pandas as pd
try:
    import tldextract; _tx = tldextract.TLDExtract(suffix_list_urls=())   # bundled PSL, no network
except ImportError:
    _tx = None
SM = None; KIDS = {}
def load(parquet):
    global SM, KIDS
    SM = pd.read_parquet(parquet).set_index('issuer_id', drop=False)
    KIDS = SM.reset_index(drop=True).groupby('parent_issuer_id').issuer_id.apply(list).to_dict()
    return SM
def name(i): return SM.at[i, 'name'] if isinstance(i, str) and i in SM.index else ''
def url_of(i):
    u = SM.at[i, 'url'] if i in SM.index else None
    return u if isinstance(u, str) and u.strip() else None
def norm_url(u):
    if not isinstance(u, str) or not u.strip(): return None
    u = re.sub(r'^https?://', '', u.strip().lower()); u = re.sub(r'^www\.', '', u)
    return u.split('#')[0].rstrip('/')
def root(u):
    """registrable domain, e.g. https://stores.kay.com/pa -> kay.com"""
    if not isinstance(u, str): return None
    host = re.sub(r'^https?://', '', u.strip().lower()).split('/')[0].split(':')[0]
    if _tx: e = _tx(host); return f'{e.domain}.{e.suffix}' if e.suffix else e.domain
    p = host.split('.'); return '.'.join(p[-3:]) if len(p) > 2 and len(p[-1]) == 2 and p[-2] in ('co','com','net','org','gov','ac') else '.'.join(p[-2:])
def path(u):
    if not isinstance(u, str): return ''
    return '/' + '/'.join(re.sub(r'^https?://', '', u.strip()).split('/')[1:]).split('?')[0].strip('/')
def parent(i):
    p = SM.at[i, 'parent_issuer_id'] if i in SM.index else None
    return p if isinstance(p, str) and p != i else None
def ancestors(i, maxd=30):
    out = []
    while (p := parent(i)) and len(out) < maxd: out.append(p); i = p
    return out
def search(pattern, country=None, n=25):
    """regex name search, e.g. search('Carglass', 'NO')"""
    x = SM[SM.name.str.contains(pattern, case=False, regex=True, na=False)]
    if country: x = x[x.country_domicile == country]
    return x[['issuer_id','name','country_domicile','url','parent_issuer_name','ultimate_parent_issuer_name']].head(n)
_ROOTIDX = None
def owners_of(u):
    """DMX entities whose URL has the same registrable domain as u"""
    global _ROOTIDX
    if _ROOTIDX is None:
        x = SM[SM.url.notna()]; _ROOTIDX = x.assign(R=x.url.map(root)).groupby('R').issuer_id.apply(list).to_dict()
    return _ROOTIDX.get(root(u), [])
# ---- decision-rule helpers -------------------------------------------------
def same_url_parent(i):
    """Same-URL rule: returns parent id if child and parent share the DMX URL"""
    p = parent(i)
    return p if p and norm_url(url_of(i)) and norm_url(url_of(i)) == norm_url(url_of(p)) else None
def climb_same_url(i):
    while (p := same_url_parent(i)): i = p
    return i
def url_bearing_ancestor(i):
    """closest entity (self first) with a URL in DMX - used for 'owner absent / no website' fallback and the strict-N6 note"""
    for x in [i] + ancestors(i):
        if url_of(x): return x
    return None
def relation(a, b):
    """how DMX relates issuer a to issuer b: SAME / PARENT / CHILD / SAME_GROUP / UNRELATED"""
    if a == b: return 'SAME'
    if b in ancestors(a): return 'PARENT'
    if a in ancestors(b): return 'CHILD'
    ua = (ancestors(a) or [a])[-1]; ub = (ancestors(b) or [b])[-1]
    return 'SAME_GROUP' if ua == ub else 'UNRELATED'
GENERIC_NUMBERED = re.compile(r' \d+$')
def homepage_generic(facility_name, url):
    """D16: homepage-only URL + numbered/brand-only name -> RECOLLECT"""
    return path(url) in ('', '/') and bool(GENERIC_NUMBERED.search(str(facility_name)))
