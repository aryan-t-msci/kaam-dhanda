"""
Pattern: SharePoint / OOCL local-contact directory pages via text mirror.

This extractor is designed for OOCL-style SharePoint contact directories where:
1. A country-level "Local Contacts" page contains office blocks inline, or
2. The country page is a hub that links to office-specific subpages.

The site is protected by Cloudflare for direct HTTP requests in this environment,
so the extractor reads the pages through `r.jina.ai/http://...`, which returns
the page as Markdown-like plain text. The parsing logic stays generic to this
SharePoint directory pattern instead of hardcoding one issuer's CSS.

How to adapt this script for a future issuer using the same pattern:
- Update the issuer constants in the configuration block.
- Replace `COUNTRY_NAMES` / `SLUG_OVERRIDES` if the location directory uses a
  different market list or slug scheme.
- Adjust `SECTION_HEADERS` if the office-address section label differs.

Usage:
    python sharepoint_oocl_directory_extractor.py
"""

from __future__ import annotations

import concurrent.futures
import csv
import json
import re
import time
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
from urllib.parse import urlparse

import requests
import urllib3


# ============================================================
# CONFIGURATION -- change these per issuer
# ============================================================
ISSUER_ID = "IID000000002124789"
ISSUER_NAME = "ORIENT OVERSEAS (INTERNATIONAL) LIMITED"
BASE_URL = "https://www.oocl.com/eng/officedirectory/Pages/default.aspx"
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")
TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")
OUTPUT_FILE = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
PROGRESS_FILE = TEMP_DIR / f"{ISSUER_ID}_sharepoint_oocl_progress.json"
SUMMARY_FILE = TEMP_DIR / f"{ISSUER_ID}_sharepoint_oocl_summary.json"
DISCOVERY_FILE = TEMP_DIR / f"{ISSUER_ID}_country_page_discovery.json"

EXPECTED_MIN_COUNT = 200
PROGRESS_SAVE_EVERY = 20
DISCOVERY_WORKERS = 4
FETCH_TIMEOUT = 30
ACTIVITY_DEFAULT = "Container shipping customer service and sales office"
SOURCE_TYPE = "COMPANY WEBSITE"
CHECKPOINT_THRESHOLD = 200


# ============================================================
# COUNTRY INPUTS
# ============================================================
COUNTRY_NAMES = [
    "Australia", "Bangladesh", "Bhutan", "Brunei", "Cambodia", "China", "Hong Kong",
    "India", "Indonesia", "Japan", "Laos", "Macau", "Malaysia", "Myanmar", "Nepal",
    "New Zealand", "Pakistan", "Philippines", "Singapore", "South Korea", "Sri Lanka",
    "Taiwan", "Thailand", "Vietnam", "Angola", "Bahrain", "Benin", "Congo Republic",
    "Djibouti", "Egypt", "Eswatini", "Ethiopia", "Ghana", "Iraq", "Ivory Coast",
    "Jordan", "Kenya", "Kuwait", "Lesotho", "Morocco", "Mozambique", "Namibia",
    "Nigeria", "Oman", "Qatar", "Saudi Arabia", "Senegal", "South Africa", "Sudan",
    "Tanzania", "Togo", "United Arab Emirates", "Yemen", "Austria", "Belgium",
    "Bulgaria", "Croatia", "Czech Republic", "Denmark", "Estonia", "Finland", "France",
    "Germany", "Greece", "Hungary", "Ireland", "Israel", "Italy", "Latvia", "Lithuania",
    "Luxembourg", "Malta", "Netherlands", "North Macedonia", "Norway", "Poland",
    "Portugal", "Romania", "Russia", "Serbia", "Slovakia", "Slovenia", "Spain",
    "Sweden", "Switzerland", "Turkey", "Ukraine", "United Kingdom", "Argentina",
    "Brazil", "Canada", "Chile", "Colombia", "Costa Rica", "Dominican Republic",
    "Ecuador", "El Salvador", "Guatemala", "Honduras", "Jamaica", "Mexico",
    "Nicaragua", "Panama", "Peru", "Uruguay", "United States",
]

SLUG_OVERRIDES: Dict[str, List[str]] = {
    "Hong Kong": ["hongkong"],
    "Macau": ["macau", "macao"],
    "South Korea": ["korea", "southkorea"],
    "Taiwan": ["taiwan"],
    "Turkey": ["turkey", "turkiye"],
    "United States": ["usa", "unitedstates"],
    "United Kingdom": ["unitedkingdom", "uk"],
    "United Arab Emirates": ["uae", "unitedarabemirates"],
    "Ivory Coast": ["ivorycoast", "cotedivoire"],
    "Congo Republic": ["congorepublic", "congo"],
    "North Macedonia": ["northmacedonia", "macedonia"],
    "New Zealand": ["newzealand"],
    "Sri Lanka": ["srilanka"],
    "Saudi Arabia": ["saudiarabia"],
    "Czech Republic": ["czechrepublic"],
    "Costa Rica": ["costarica"],
    "Dominican Republic": ["dominicanrepublic"],
    "El Salvador": ["elsalvador"],
}

COUNTRY_CANONICAL = {
    "Hong Kong": ("Hong Kong", "HKG"),
    "Macau": ("Macau", "MAC"),
    "South Korea": ("South Korea", "KOR"),
    "Taiwan": ("Taiwan", "TWN"),
    "United States": ("United States", "USA"),
    "United Kingdom": ("United Kingdom", "GBR"),
    "United Arab Emirates": ("United Arab Emirates", "ARE"),
    "Ivory Coast": ("Ivory Coast", "CIV"),
    "Congo Republic": ("Republic of the Congo", "COG"),
    "Turkey": ("Turkey", "TUR"),
}

ISO3_FALLBACK = {
    "Australia": "AUS", "Bangladesh": "BGD", "Bhutan": "BTN", "Brunei": "BRN",
    "Cambodia": "KHM", "China": "CHN", "India": "IND", "Indonesia": "IDN",
    "Japan": "JPN", "Laos": "LAO", "Malaysia": "MYS", "Myanmar": "MMR",
    "Nepal": "NPL", "New Zealand": "NZL", "Pakistan": "PAK", "Philippines": "PHL",
    "Singapore": "SGP", "Sri Lanka": "LKA", "Thailand": "THA", "Vietnam": "VNM",
    "Angola": "AGO", "Bahrain": "BHR", "Benin": "BEN", "Djibouti": "DJI",
    "Egypt": "EGY", "Eswatini": "SWZ", "Ethiopia": "ETH", "Ghana": "GHA",
    "Iraq": "IRQ", "Jordan": "JOR", "Kenya": "KEN", "Kuwait": "KWT",
    "Lesotho": "LSO", "Morocco": "MAR", "Mozambique": "MOZ", "Namibia": "NAM",
    "Nigeria": "NGA", "Oman": "OMN", "Qatar": "QAT", "Saudi Arabia": "SAU",
    "Senegal": "SEN", "South Africa": "ZAF", "Sudan": "SDN", "Tanzania": "TZA",
    "Togo": "TGO", "Yemen": "YEM", "Austria": "AUT", "Belgium": "BEL",
    "Bulgaria": "BGR", "Croatia": "HRV", "Czech Republic": "CZE", "Denmark": "DNK",
    "Estonia": "EST", "Finland": "FIN", "France": "FRA", "Germany": "DEU",
    "Greece": "GRC", "Hungary": "HUN", "Ireland": "IRL", "Israel": "ISR",
    "Italy": "ITA", "Latvia": "LVA", "Lithuania": "LTU", "Luxembourg": "LUX",
    "Malta": "MLT", "Netherlands": "NLD", "North Macedonia": "MKD", "Norway": "NOR",
    "Poland": "POL", "Portugal": "PRT", "Romania": "ROU", "Russia": "RUS",
    "Serbia": "SRB", "Slovakia": "SVK", "Slovenia": "SVN", "Spain": "ESP",
    "Sweden": "SWE", "Switzerland": "CHE", "Ukraine": "UKR", "Argentina": "ARG",
    "Brazil": "BRA", "Canada": "CAN", "Chile": "CHL", "Colombia": "COL",
    "Costa Rica": "CRI", "Dominican Republic": "DOM", "Ecuador": "ECU",
    "El Salvador": "SLV", "Guatemala": "GTM", "Honduras": "HND", "Jamaica": "JAM",
    "Mexico": "MEX", "Nicaragua": "NIC", "Panama": "PAN", "Peru": "PER",
    "Uruguay": "URY",
}

SECTION_HEADERS = [
    "Customer Service & Sales Contact Information",
    "Customer Service Contact Information",
    "Sales Contact Information",
    "Emergency Contacts After Office Hours",
    "Management Team Contact Information",
    "Contact Information",
    "Support Services",
    "Local Information",
    "About OOCL",
]

BANNED_HEADINGS = {
    "Office Address", "Office Address :", "Office Address:",
    "OOCL Office Address", "OOCL Office Address :", "Office and Mailing Address",
    "Contact Information", "Support Services", "Mailing Address",
    "Customer Service & Sales Contact Information", "Customer Service Contact Information",
    "Sales Contact Information", "Emergency Contacts After Office Hours",
    "Management Team Contact Information", "Office Address & Office Hours",
}


@dataclass
class CountryPage:
    country_input: str
    country: str
    country_iso3: str
    slug: str
    page_url: str
    markdown: str


def build_session() -> requests.Session:
    session = requests.Session()
    session.trust_env = False
    session.headers.update({"User-Agent": "Mozilla/5.0"})
    return session


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def save_json(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def normalize_country_slug(name: str) -> str:
    text = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode("ascii").lower()
    return re.sub(r"[^a-z0-9]+", "", text)


def country_name_and_iso3(country_input: str) -> Tuple[str, str]:
    if country_input in COUNTRY_CANONICAL:
        return COUNTRY_CANONICAL[country_input]
    return country_input, ISO3_FALLBACK.get(country_input, "")


def candidate_slugs(country: str) -> List[str]:
    seen: List[str] = []
    for candidate in SLUG_OVERRIDES.get(country, []):
        if candidate not in seen:
            seen.append(candidate)

    base = normalize_country_slug(country)
    generic_variants = [
        base,
        base.replace("and", ""),
        base.replace("republic", ""),
        base.replace("north", ""),
        base.replace("south", ""),
    ]
    for candidate in generic_variants:
        if candidate and candidate not in seen:
            seen.append(candidate)
    return seen


def target_to_mirror(target_url: str) -> str:
    return f"https://r.jina.ai/http://{target_url}"


def fetch_markdown(target_url: str) -> str:
    last_error: Optional[Exception] = None
    for _ in range(3):
        session = build_session()
        try:
            response = session.get(target_to_mirror(target_url), timeout=FETCH_TIMEOUT, verify=False)
            response.raise_for_status()
            return response.text
        except Exception as exc:  # pragma: no cover - network variability
            last_error = exc
            time.sleep(0.5)
    raise last_error if last_error else RuntimeError(f"Failed to fetch {target_url}")


def page_is_valid(markdown: str) -> bool:
    if "Title: Just a moment..." in markdown:
        return False
    if "Target URL returned error 403" in markdown:
        return False
    if "The resource cannot be found" in markdown:
        return False
    return "Title: OOCL -" in markdown


def strip_markdown_links(text: str) -> str:
    text = re.sub(r"!\[[^\]]*\]\([^)]+\)", "", text)
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    text = re.sub(r"\[\]\([^)]+\)", "", text)
    return text


def clean_whitespace(text: str) -> str:
    text = text.replace("\u200b", " ").replace("\ufeff", " ")
    text = text.replace("\xa0", " ").replace("​", " ").replace("​​", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def ascii_text(text: str) -> str:
    if not text:
        return ""
    text = text.replace("#", "")
    normalized = unicodedata.normalize("NFKD", text)
    normalized = normalized.encode("ascii", "ignore").decode("ascii")
    normalized = re.sub(r"\s+", " ", normalized)
    return normalized.strip(" ,;")


def extract_between(text: str, start_pattern: str, end_patterns: Sequence[str]) -> str:
    start = text.find(start_pattern)
    if start == -1:
        return ""
    section = text[start:]
    end_positions = []
    for pattern in end_patterns:
        idx = section.find(pattern)
        if idx > 0:
            end_positions.append(idx)
    end = min(end_positions) if end_positions else len(section)
    return section[:end]


def preprocess_section(text: str) -> str:
    text = strip_markdown_links(text)
    text = clean_whitespace(text)
    text = re.sub(r"(?<!\n)(\*\*[A-Z][^*\n]{1,80}\*\*)", r"\n\1", text)
    text = re.sub(r"(?<!\n)(\*\*[A-Z][^\n]{0,80}:?\*\*)", r"\n\1", text)
    text = re.sub(r"(Office Hours)(?=\s+\*\*)", r"\1\n", text)
    text = re.sub(r"(Sun\s*:\s*\(Weekly off\))(?=\*\*)", r"\1\n", text)
    return text.strip()


def extract_office_section(markdown: str) -> str:
    text = preprocess_section(markdown)
    for header in ["**Office and Mailing Address**", "**Office Address**", "**Office Address :**", "**Office Address:**", "**OOCL Office Address :**", "Office Address & Office Hours"]:
        start = text.find(header)
        if start != -1:
            section = text[start:]
            end_positions = [section.find(h) for h in SECTION_HEADERS if section.find(h) > 0]
            end = min(end_positions) if end_positions else len(section)
            return section[:end]
    return ""


def office_heading_iter(section: str) -> List[Tuple[str, str]]:
    matches = list(re.finditer(r"\*\*([^*\n]{2,120}?)\*\*", section))
    results: List[Tuple[str, str]] = []
    for index, match in enumerate(matches):
        heading = clean_whitespace(match.group(1).strip(" :"))
        if heading in BANNED_HEADINGS:
            continue
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(section)
        block = clean_whitespace(section[start:end])
        if not block:
            continue
        if heading.lower().startswith("customer service") or heading.lower().startswith("management team"):
            continue
        results.append((heading, block))
    return results


def extract_inline_urls(markdown: str) -> Dict[str, str]:
    descriptions: Dict[str, str] = {}
    for match in re.finditer(
        r"\[([^\]]+)\]\((https://www\.oocl\.com/[^)]+/localinformation/localcontacts/[^)\s]+)\)\s*([^\n|]*)",
        markdown,
        re.IGNORECASE,
    ):
        link_text, url, desc = match.group(1), match.group(2), match.group(3)
        desc_text = clean_whitespace(strip_markdown_links(desc))
        descriptions[url.rstrip("/")] = clean_whitespace(f"{link_text} {desc_text}".strip())
    return descriptions


def canonical_page_url(url: str) -> str:
    parsed = urlparse(url)
    url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}".rstrip("/")
    if "/Pages/default.aspx" in url:
        return url
    if "/Documents/" in url:
        return url
    return f"{url}/Pages/default.aspx"


def is_useful_subpage(url: str, root_page_url: str) -> bool:
    canonical = canonical_page_url(url)
    if canonical == root_page_url:
        return False
    lowered = canonical.lower()
    if "publishingimages" in lowered or "/documents/" in lowered:
        return False
    if "specialworkinghours" in lowered:
        return False
    parsed = urlparse(canonical)
    parts = [part for part in parsed.path.split("/") if part]
    if "localcontacts" not in parts:
        return False
    index = parts.index("localcontacts")
    trailing = parts[index + 1 :]
    if not trailing:
        return False
    # Root country page = .../localcontacts/Pages/default.aspx
    if trailing == ["Pages", "default.aspx"]:
        return False
    return True


def location_name_to_city(name: str) -> str:
    city = re.sub(r"\b(Office|Agency|Branch|Head Office|Headquarters|Center|Centre|HQ)\b", "", name, flags=re.I)
    city = re.sub(r"\([^)]*\)", "", city)
    city = re.sub(r"\s{2,}", " ", city).strip(" ,-/")
    return city


def split_address_lines(block: str) -> List[str]:
    block = strip_markdown_links(block)
    block = block.replace("| --- | --- | --- |", "")
    block = re.sub(r"\|\s+---.*", "", block)
    block = block.replace("|", "\n")
    block = re.sub(r"(Tel\s*:)", r"\n\1", block, flags=re.I)
    block = re.sub(r"(Telephone\s*:)", r"\n\1", block, flags=re.I)
    block = re.sub(r"(Email\s*:)", r"\n\1", block, flags=re.I)
    block = re.sub(r"(Office Hours)", r"\n\1", block, flags=re.I)
    block = re.sub(r"(Postal\s*:)", r"\n\1", block, flags=re.I)
    lines = [clean_whitespace(line) for line in block.splitlines()]
    return [line for line in lines if line]


def extract_address_from_block(block: str, location_name: str, country: str) -> Tuple[str, str]:
    lines = split_address_lines(block)
    native_lines: List[str] = []
    started = False
    for line in lines:
        lower = line.lower()
        if any(lower.startswith(prefix) for prefix in ("tel", "telephone", "email", "office hours", "fax")):
            break
        if lower.startswith("postal"):
            break
        if "mailing address" in lower:
            break
        if re.fullmatch(r"\*{2,}", line):
            continue
        if not started and (
            lower.startswith("oocl ")
            or lower.startswith("orient overseas")
            or lower.startswith("oocl agent")
            or lower.startswith("office address")
        ):
            continue
        if not started and lower.startswith("suite") is False and re.search(r"\b(address|hours)\b", lower) and not re.search(r"\d", lower):
            continue
        started = True
        native_lines.append(line)

    if not native_lines:
        fallback = f"{location_name_to_city(location_name)}, {country}"
        return fallback, fallback

    native_address = ", ".join(native_lines)
    native_address = native_address.replace(" ,", ",").replace(" , ", ", ")
    native_address = re.sub(r"\s+", " ", native_address).strip(" ,")
    ascii_address = ascii_text(native_address)
    return ascii_address, native_address


def parse_city_state_postcode(address: str, location_name: str, country: str) -> Tuple[str, str, str]:
    raw = address.replace(" ,", ",")
    postcode = ""
    state = ""
    city = ""

    if country in {"United States", "Canada", "Australia"}:
        match = re.search(r"([A-Za-z .'-]+),\s*([A-Z]{2})\s*([A-Z0-9 -]{3,10})$", raw)
        if match:
            city, state, postcode = [part.strip() for part in match.groups()]
    elif country == "India":
        match = re.search(r"([A-Za-z .'-]+)\s*[-–]?\s*(\d{6})(?:,\s*([A-Za-z .'-]+))?$", raw)
        if match:
            city = match.group(1).strip(" ,")
            postcode = match.group(2)
            state = (match.group(3) or "").strip(" ,")
        else:
            match = re.search(r"([A-Za-z .'-]+),\s*([A-Za-z .'-]+)\s*[-–]?\s*(\d{6})$", raw)
            if match:
                city, state, postcode = [part.strip() for part in match.groups()]
    elif country in {"United Kingdom", "Ireland"}:
        match = re.search(r"([A-Za-z .'-]+)\s+([A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2})$", raw)
        if match:
            city, postcode = [part.strip() for part in match.groups()]
    else:
        match = re.search(r"\b([A-Z]?\d[A-Z0-9 -]{2,10})$", raw)
        if match and any(ch.isdigit() for ch in match.group(1)):
            postcode = match.group(1).strip()

    if not city:
        parts = [part.strip() for part in raw.split(",") if part.strip()]
        if parts:
            tail = parts[-1]
            tail = re.sub(r"\b[A-Z]?\d[A-Z0-9 -]{2,10}\b$", "", tail).strip(" ,-")
            if tail and not tail.lower().startswith(("tel", "email")):
                city = tail
            elif len(parts) >= 2:
                city = re.sub(r"\b[A-Z]?\d[A-Z0-9 -]{2,10}\b$", "", parts[-2]).strip(" ,-")

    if not city:
        city = location_name_to_city(location_name)
    if not state and country in {"United States", "Canada", "Australia"}:
        match = re.search(r",\s*([A-Z]{2})\s*[A-Z0-9 -]{3,10}$", raw)
        if match:
            state = match.group(1).strip()

    return ascii_text(city), ascii_text(state), ascii_text(postcode)


def activity_for_block(location_name: str, block: str, description: str = "") -> str:
    text = f"{location_name} {block} {description}".lower()
    if "head office" in text or "headquarters" in text:
        return "Head office / container shipping"
    if "agent" in text:
        return "Shipping agent / container shipping office"
    if "management service center" in text:
        return "Integrated management service center / container shipping"
    return ACTIVITY_DEFAULT


def make_record(
    country: str,
    iso3: str,
    source_url: str,
    location_name_native: str,
    location_address_native: str,
    activity: str,
) -> Dict[str, str]:
    location_name = ascii_text(location_name_native)
    location_address = ascii_text(location_address_native)
    city, state, postcode = parse_city_state_postcode(location_address, location_name, country)
    if not city:
        city = ascii_text(location_name_to_city(location_name_native))
    if not location_address:
        location_address = f"{city}, {country}".strip(", ")
    return {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": location_name,
        "LOCATION_NAME_NATIVE": clean_whitespace(location_name_native),
        "LOCATION_ADDRESS": location_address.replace("#", ""),
        "LOCATION_ADDRESS_NATIVE": clean_whitespace(location_address_native).replace("#", ""),
        "LATITUDE": "",
        "LONGITUDE": "",
        "coord_source": "",
        "COUNTRY": country,
        "COUNTRY_ISO3": iso3,
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": source_url,
        "SOURCE_TYPE": SOURCE_TYPE,
        "ACTIVITY_AT_ASSET": activity,
    }


def resolve_country_page(country_input: str) -> Optional[CountryPage]:
    country, iso3 = country_name_and_iso3(country_input)
    for slug in candidate_slugs(country_input):
        for url in (
            f"https://www.oocl.com/{slug}/eng/localinformation/localcontacts/Pages/default.aspx",
            f"https://www.oocl.com/{slug}/eng/localinformation/localcontacts",
        ):
            try:
                markdown = fetch_markdown(url)
            except Exception:
                continue
            if page_is_valid(markdown):
                return CountryPage(
                    country_input=country_input,
                    country=country,
                    country_iso3=iso3,
                    slug=slug,
                    page_url=canonical_page_url(url),
                    markdown=markdown,
                )
    return None


def parse_country_page(page: CountryPage) -> Tuple[List[Dict[str, str]], List[str]]:
    records: List[Dict[str, str]] = []
    warnings: List[str] = []

    section = extract_office_section(page.markdown)
    inline_urls = extract_inline_urls(page.markdown)
    subpage_urls = [
        canonical_page_url(url)
        for url in sorted(set(inline_urls))
        if is_useful_subpage(url, page.page_url)
    ]

    if section:
        for heading, block in office_heading_iter(section):
            address_ascii, address_native = extract_address_from_block(block, heading, page.country)
            activity = activity_for_block(heading, block, "")
            records.append(
                make_record(
                    country=page.country,
                    iso3=page.country_iso3,
                    source_url=page.page_url,
                    location_name_native=heading,
                    location_address_native=address_native or address_ascii,
                    activity=activity,
                )
            )

    if subpage_urls:
        for subpage_url in subpage_urls:
            try:
                subpage_markdown = fetch_markdown(subpage_url)
            except Exception as exc:
                warnings.append(f"{page.country}: failed subpage fetch {subpage_url} ({exc})")
                continue
            if not page_is_valid(subpage_markdown):
                warnings.append(f"{page.country}: blocked or invalid subpage {subpage_url}")
                continue
            sub_section = extract_office_section(subpage_markdown)
            description = inline_urls.get(subpage_url.rstrip("/"), "")
            if not sub_section:
                warnings.append(f"{page.country}: no office section on subpage {subpage_url}")
                continue
            sub_records_before = len(records)
            for heading, block in office_heading_iter(sub_section):
                address_ascii, address_native = extract_address_from_block(block, heading, page.country)
                activity = activity_for_block(heading, block, description)
                records.append(
                    make_record(
                        country=page.country,
                        iso3=page.country_iso3,
                        source_url=subpage_url,
                        location_name_native=heading,
                        location_address_native=address_native or address_ascii,
                        activity=activity,
                    )
                )
            if len(records) == sub_records_before and description:
                location_name = description.split(" Covering ")[0].strip()
                records.append(
                    make_record(
                        country=page.country,
                        iso3=page.country_iso3,
                        source_url=subpage_url,
                        location_name_native=location_name,
                        location_address_native=f"{location_name_to_city(location_name)}, {page.country}",
                        activity=activity_for_block(location_name, "", description),
                    )
                )

    if not section and not subpage_urls:
        warnings.append(f"{page.country}: no inline office section or subpage links found")
    return records, warnings


def dedupe_records(records: Iterable[Dict[str, str]]) -> List[Dict[str, str]]:
    seen = set()
    deduped: List[Dict[str, str]] = []
    for record in records:
        key = (
            record["COUNTRY"],
            record["LOCATION_NAME"].lower(),
            record["LOCATION_ADDRESS"].lower(),
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(record)
    return deduped


def write_csv(records: Sequence[Dict[str, str]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_NAME_NATIVE",
        "LOCATION_ADDRESS", "LOCATION_ADDRESS_NATIVE", "LATITUDE", "LONGITUDE",
        "coord_source", "COUNTRY", "COUNTRY_ISO3", "POSTCODE", "STATE", "CITY",
        "SOURCE_URL", "SOURCE_TYPE", "ACTIVITY_AT_ASSET",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)


def discovery_progress_callback(completed: List[Tuple[str, Optional[CountryPage]]]) -> None:
    if len(completed) % PROGRESS_SAVE_EVERY == 0:
        payload = {
            "completed": len(completed),
            "resolved": [
                {
                    "country_input": page.country_input,
                    "country": page.country,
                    "country_iso3": page.country_iso3,
                    "slug": page.slug,
                    "page_url": page.page_url,
                }
                for _, page in completed
                if page is not None
            ],
        }
        save_json(DISCOVERY_FILE, payload)


def discover_country_pages() -> List[CountryPage]:
    resolved_pages: List[CountryPage] = []
    completed: List[Tuple[str, Optional[CountryPage]]] = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=DISCOVERY_WORKERS) as executor:
        future_map = {executor.submit(resolve_country_page, country): country for country in COUNTRY_NAMES}
        for future in concurrent.futures.as_completed(future_map):
            country = future_map[future]
            try:
                page = future.result()
            except Exception:
                page = None
            completed.append((country, page))
            if page is not None:
                resolved_pages.append(page)
            discovery_progress_callback(completed)

    unresolved = [country for country, page in completed if page is None]
    for country in unresolved:
        page = resolve_country_page(country)
        if page is None:
            continue
        if not any(existing.country_input == page.country_input for existing in resolved_pages):
            resolved_pages.append(page)

    resolved_pages.sort(key=lambda page: page.country)
    save_json(
        DISCOVERY_FILE,
        {
            "completed": len(completed),
            "resolved_count": len(resolved_pages),
            "resolved": [
                {
                    "country_input": page.country_input,
                    "country": page.country,
                    "country_iso3": page.country_iso3,
                    "slug": page.slug,
                    "page_url": page.page_url,
                }
                for page in resolved_pages
            ],
            "unresolved": [country for country, page in completed if page is None],
        },
    )
    return resolved_pages


def load_country_pages_from_cache() -> Optional[List[CountryPage]]:
    if not DISCOVERY_FILE.exists():
        return None
    try:
        payload = json.loads(DISCOVERY_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None
    resolved = payload.get("resolved") or []
    pages: List[CountryPage] = []
    for item in resolved:
        try:
            markdown = fetch_markdown(item["page_url"])
        except Exception:
            continue
        pages.append(
            CountryPage(
                country_input=item["country_input"],
                country=item["country"],
                country_iso3=item["country_iso3"],
                slug=item["slug"],
                page_url=item["page_url"],
                markdown=markdown,
            )
        )
    return pages or None


def main() -> None:
    started_at = time.time()
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    all_records: List[Dict[str, str]] = []
    warnings: List[str] = []
    checkpoint_written = False

    country_pages = load_country_pages_from_cache() or discover_country_pages()
    for index, page in enumerate(country_pages, start=1):
        records, page_warnings = parse_country_page(page)
        all_records.extend(records)
        warnings.extend(page_warnings)
        all_records = dedupe_records(all_records)

        if len(all_records) >= CHECKPOINT_THRESHOLD and not checkpoint_written:
            write_csv(all_records, OUTPUT_FILE)
            checkpoint_written = True

        if index % PROGRESS_SAVE_EVERY == 0:
            save_json(
                PROGRESS_FILE,
                {
                    "countries_processed": index,
                    "countries_total": len(country_pages),
                    "record_count": len(all_records),
                    "warnings": warnings[-50:],
                },
            )

    final_records = dedupe_records(all_records)
    final_records.sort(key=lambda row: (row["COUNTRY"], row["CITY"], row["LOCATION_NAME"]))
    write_csv(final_records, OUTPUT_FILE)

    summary = {
        "started_at_epoch": started_at,
        "finished_at_epoch": time.time(),
        "duration_seconds": round(time.time() - started_at, 2),
        "resolved_country_pages": len(country_pages),
        "record_count": len(final_records),
        "expected_min_count": EXPECTED_MIN_COUNT,
        "warnings": warnings,
    }
    save_json(SUMMARY_FILE, summary)

    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
