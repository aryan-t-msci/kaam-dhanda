"""Linked-company HQ extractor for Fosun/Fosun Pharma source pages.

This script:
1. Parses the live Fosun and Fosun Pharma source pages to build an inventory of
   global offices plus linked member-company / portfolio-company websites.
2. Crawls a small set of candidate pages on each official website to find an
   HQ/registered-office style address.
3. Normalizes rows to the standing extraction schema, writes a checkpoint CSV
   once the threshold is reached, then writes the final CSV and debug artifacts.

The extraction logic is generic enough for "official source page -> linked
company website -> HQ/contact page" patterns; only the CONFIG block should need
adjustment for a new issuer using similar source pages.
"""

from __future__ import annotations

import csv
import json
import re
import time
import unicodedata
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urljoin, urlparse

import pycountry
import requests
from bs4 import BeautifulSoup
from deep_translator import GoogleTranslator
from unidecode import unidecode


# =============================================================================
# CONFIGURATION — Edit this block for each new issuer
# =============================================================================
ISSUER_ID = "IID000000002142739"
ISSUER_NAME = "FOSUN INTERNATIONAL LIMITED"
CHECKPOINT_THRESHOLD = 32

TEMP_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Temp")
OUTPUT_DIR = Path(r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection - Straive\Output")

FINAL_CSV = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
CHECKPOINT_CSV = TEMP_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_checkpoint.csv"
DEBUG_JSON = TEMP_DIR / f"{ISSUER_ID}_debug.json"
INVENTORY_JSON = TEMP_DIR / f"{ISSUER_ID}_inventory.json"
SUMMARY_JSON = TEMP_DIR / f"{ISSUER_ID}_run_summary.json"
MEMORY_DRAFT_MD = TEMP_DIR / f"KB_APPEND_{ISSUER_ID}_20260409.md"

FOSUN_OFFICES_URL = "https://www.fosun.com/about/Global.html"
FOSUN_GLOBAL_INDUSTRY_URL = "https://www.fosun.com/about/Globalindustry.html"
PHARMA_COMPANY_PAGES: OrderedDict[str, str] = OrderedDict(
    {
        "https://www.fosunpharma.com/en/about/companies78.html": "Pharmaceutical manufacturing company headquarters",
        "https://www.fosunpharma.com/en/about/companies79.html": "Vaccine company headquarters",
        "https://www.fosunpharma.com/en/about/companies80.html": "Medical devices company headquarters",
        "https://www.fosunpharma.com/en/about/companies81.html": "Medical diagnosis company headquarters",
        "https://www.fosunpharma.com/en/about/companies82.html": "Healthcare services company headquarters",
        "https://www.fosunpharma.com/en/about/companies83.html": "Pharmaceutical distribution and retail company headquarters",
    }
)

MANUAL_PAGE_HINTS: dict[str, list[str]] = {
    "www.henlius.com": [
        "https://www.henlius.com/en/contact-information.html",
        "https://www.henlius.com/en/ir-contact-information.html",
    ],
    "glandpharma.com": ["https://glandpharma.com/contact-us"],
    "www.glandpharma.com": ["https://glandpharma.com/contact-us"],
    "www.fidelidade.pt": [
        "https://www.fidelidade.pt/PT/ajuda/Paginas/contactos.aspx",
        "https://www.fidelidade.pt/PT/particulares/Paginas/fale-connosco.aspx",
    ],
    "www.sinopharmholding.com": ["https://www.sinopharmholding.com/"],
}

SOURCE_URL_OVERRIDES: dict[str, str] = {
    "https://www.henlius.com/en/company-profile.html": "https://www.henlius.com/en/contact-information.html",
}

PORTFOLIO_LINK_ALLOWLIST = {
    "www.yuyuantm.com.cn",
    "www.fosunholiday.com",
    "www.fidelidade.pt",
    "www.fosunhealth.com",
    "www.henlius.com",
    "www.lanvin-group.com",
    "www.fosuncapital.com",
    "www.fosunhive.com",
    "www.hnmining.com",
    "www.easun-tech.com",
    "www.fosuntrade.com",
    "www.frzcapital.cn",
}

HEADERS = {"User-Agent": "Mozilla/5.0"}
REQUEST_TIMEOUT = 20

# =============================================================================
# GENERIC EXTRACTION LOGIC — Do not modify per-issuer
# =============================================================================

requests.packages.urllib3.disable_warnings()  # type: ignore[attr-defined]
SESSION = requests.Session()
SESSION.headers.update(HEADERS)

TRANSLATOR = GoogleTranslator(source="auto", target="en")
TRANSLATION_CACHE: dict[str, str] = {}

COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_NAME_NATIVE",
    "LOCATION_ADDRESS",
    "LOCATION_ADDRESS_NATIVE",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
]

COUNTRY_NAME_MAP = {
    "中国": "China",
    "葡萄牙": "Portugal",
    "法国": "France",
    "德国": "Germany",
    "瑞典": "Sweden",
    "英国": "United Kingdom",
    "意大利": "Italy",
    "美国": "United States",
    "秘鲁": "Peru",
    "巴西": "Brazil",
    "日本": "Japan",
    "印度": "India",
    "新加坡": "Singapore",
    "以色列": "Israel",
    "澳大利亚": "Australia",
    "香港": "Hong Kong",
}

COUNTRY_ALIASES = {
    "USA": "United States",
    "U.S.A.": "United States",
    "U.S.": "United States",
    "UK": "United Kingdom",
    "U.K.": "United Kingdom",
    "Hong Kong SAR": "Hong Kong",
    "PRC": "China",
    "P.R. China": "China",
}

OFFICE_TRANSLATIONS = {
    "Shanghai": {
        "name_native": "上海",
        "addr_native": "上海市黄浦区中山东二路600号外滩金融中心",
        "address": "The Bund Finance Center, No. 600 Zhongshan East 2nd Road, Huangpu District, Shanghai, China",
        "country": "China",
        "state": "Shanghai",
        "city": "Shanghai",
        "postcode": "200010",
    },
    "Hong Kong": {
        "name_native": "香港",
        "addr_native": "中环花园道3号中国工商银行大厦808室",
        "address": "Room 808, ICBC Tower, 3 Garden Road, Central, Hong Kong",
        "country": "Hong Kong",
        "state": "Hong Kong",
        "city": "Hong Kong",
        "postcode": "",
    },
    "Beijing": {
        "name_native": "北京",
        "addr_native": "北京市朝阳区朝阳北路237号复星国际中心",
        "address": "Fosun International Center, No. 237 Chaoyang North Road, Chaoyang District, Beijing, China",
        "country": "China",
        "state": "Beijing",
        "city": "Beijing",
        "postcode": "",
    },
    "London": {
        "name_native": "伦敦",
        "addr_native": "",
        "address": "2nd Floor, 7 Heddon St, London W1B 4BD, United Kingdom",
        "country": "United Kingdom",
        "state": "England",
        "city": "London",
        "postcode": "W1B 4BD",
    },
    "New York": {
        "name_native": "纽约",
        "addr_native": "",
        "address": "44th Floor, 28 Liberty St, New York, NY 10005, United States",
        "country": "United States",
        "state": "New York",
        "city": "New York",
        "postcode": "10005",
    },
    "Lisbon": {
        "name_native": "里斯本",
        "addr_native": "",
        "address": "Largo do Chiado 8, 1249-125 Lisbon, Portugal",
        "country": "Portugal",
        "state": "Lisbon",
        "city": "Lisbon",
        "postcode": "1249-125",
    },
    "Frankfurt": {
        "name_native": "法兰克福",
        "addr_native": "",
        "address": "Marienturm 19th Floor, Taunusanlage 9-10, 60329 Frankfurt am Main, Germany",
        "country": "Germany",
        "state": "Hesse",
        "city": "Frankfurt am Main",
        "postcode": "60329",
    },
}

DROP_LOCATION_NAMES = {
    "Fosun Adgenvax (Chengdu) Biopharmaceutical Co.,Ltd.",
}

MANUAL_ROW_OVERRIDES: dict[str, dict[str, str]] = {
    "Fosun Wanbang (Jiangsu) Pharmaceutical Group Co., Ltd.": {
        "LOCATION_ADDRESS": "No. 6 Yangshan Road, Xuzhou Economic and Technological Development Zone, Xuzhou, Jiangsu, China",
        "LOCATION_ADDRESS_NATIVE": "江苏省徐州经济技术开发区杨山路6号",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "STATE": "Jiangsu",
        "CITY": "Xuzhou",
        "POSTCODE": "",
    },
    "YAOPHARMA CO., LTD.": {
        "LOCATION_ADDRESS": "No. 100 Xingguang Avenue, Renhe Town, Yubei District, Chongqing, China",
        "LOCATION_ADDRESS_NATIVE": "重庆市渝北区人和镇星光大道100号",
        "LATITUDE": "29.626832",
        "LONGITUDE": "106.51635",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "STATE": "Chongqing",
        "CITY": "Chongqing",
        "POSTCODE": "",
        "SOURCE_URL": "https://www.yaopharma.com/Category_256/Index_1.aspx",
        "coord_source": "website",
    },
    "Guilin Pharmaceutical Co., Ltd.": {
        "LOCATION_ADDRESS": "No. 43 Qilidian Road, Guilin, Guangxi, China",
        "LOCATION_ADDRESS_NATIVE": "桂林市七里店路43号",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "STATE": "Guangxi",
        "CITY": "Guilin",
        "POSTCODE": "",
        "SOURCE_URL": "https://www.guilinpharma.com/",
    },
    "HONGQI PHARMACEUTICAL": {
        "LOCATION_ADDRESS": "No. 6 Xinluo Street, Hunnan District, Shenyang, Liaoning, China",
        "LOCATION_ADDRESS_NATIVE": "沈阳市浑南区新络街6号",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "STATE": "Liaoning",
        "CITY": "Shenyang",
        "POSTCODE": "",
        "SOURCE_URL": "https://www.hongqipharma.com/",
    },
    "Suzhou Erye Pharmaceutical Co., Ltd HOME": {
        "LOCATION_NAME": "Suzhou Erye Pharmaceutical Co., Ltd.",
        "LOCATION_ADDRESS": "No. 2 Anmin Road, Huangdai Dongqiao, Xiangcheng District, Suzhou, Jiangsu, China",
        "LOCATION_ADDRESS_NATIVE": "江苏省苏州市相城区黄埭东桥安民路2号",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "STATE": "Jiangsu",
        "CITY": "Suzhou",
        "POSTCODE": "",
        "SOURCE_URL": "https://www.szerye.com/",
    },
    "Avanc Pharmaceutical Co.,Ltd": {
        "LOCATION_ADDRESS": "No. 55 Songshan Street, Taihe District, Jinzhou, Liaoning, China",
        "LOCATION_ADDRESS_NATIVE": "辽宁省锦州市太和区松山大街55号",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "STATE": "Liaoning",
        "CITY": "Jinzhou",
        "POSTCODE": "",
        "SOURCE_URL": "https://www.avancpharma.com/%E8%81%94%E7%B3%BB%E6%88%91%E4%BB%AC/",
    },
    "Gland Pharma Limited": {
        "LOCATION_ADDRESS": "Survey No. 143-148, 150 & 151, Near Gandimaisamma X Roads, D.P. Pally, Dundigal Gandimaisamma Mandal, Medchal-Malkajgiri District, Hyderabad 500043, Telangana, India",
        "COUNTRY": "India",
        "COUNTRY_ISO3": "IND",
        "STATE": "Telangana",
        "CITY": "Hyderabad",
        "POSTCODE": "500043",
        "SOURCE_URL": "https://glandpharma.com/contact-us",
    },
    "Fosun Medical System Co., Ltd.": {
        "LOCATION_ADDRESS": "9B Caoyang Industrial Park, Nujiang North Road, Putuo District, Shanghai, China",
        "LOCATION_ADDRESS_NATIVE": "上海市普陀区怒江北路曹杨工业园9B",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "STATE": "Shanghai",
        "CITY": "Shanghai",
        "POSTCODE": "",
        "SOURCE_URL": "https://www.foshion.net/en/",
    },
    "Chindex Medical Limited": {
        "LOCATION_ADDRESS": "1-1-1708, North District, Financial and Trade Center, No. 6865 Asia Road, Tianjin Free Trade Experimental Zone (Dongjiang Bonded Port Zone), Tianjin, China",
        "LOCATION_ADDRESS_NATIVE": "天津自由贸易实验区(东疆保税港区)亚洲路6865号金融贸易中心北区1-1-1708",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "STATE": "Tianjin",
        "CITY": "Tianjin",
        "POSTCODE": "",
        "SOURCE_URL": "https://www.chindexmedical.com/contactus",
    },
    "Huaiyin Medical Instruments Co.,Ltd": {
        "LOCATION_ADDRESS": "No. 106 Chaoyang West Road, Qingjiangpu District, Huai'an, Jiangsu, China",
        "LOCATION_ADDRESS_NATIVE": "江苏省淮安市清江浦区朝阳西路106号",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "STATE": "Jiangsu",
        "CITY": "Huai'an",
        "POSTCODE": "",
        "SOURCE_URL": "https://www.hy-medical.com/",
    },
    "Chongqing Shinrong Plastic Surgery Hospital": {
        "LOCATION_ADDRESS": "No. 88 Longhua Avenue, Yubei District, Chongqing, China",
        "LOCATION_ADDRESS_NATIVE": "中国·重庆·渝北龙华大道88号",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "STATE": "Chongqing",
        "CITY": "Chongqing",
        "POSTCODE": "",
        "SOURCE_URL": "https://www.cqxrzx.com/24562/",
    },
    "Sinopharm Group Co., Ltd.": {
        "LOCATION_ADDRESS": "Sinopharm Holdings Building, No. 385 Longhua East Road, Huangpu District, Shanghai, China",
        "LOCATION_ADDRESS_NATIVE": "上海市黄浦区龙华东路385号国药控股大厦",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "STATE": "Shanghai",
        "CITY": "Shanghai",
        "POSTCODE": "",
        "SOURCE_URL": "https://www.sinopharmholding.com/",
    },
    "Sisram Medical": {
        "LOCATION_ADDRESS": "OFEK 15 Building, 18 HaHarash Street, Industrial Park, Caesarea 3079895, Israel",
        "COUNTRY": "Israel",
        "COUNTRY_ISO3": "ISR",
        "STATE": "",
        "CITY": "Caesarea",
        "POSTCODE": "3079895",
        "SOURCE_URL": "https://sisram-medical.com/investor_relations/ir-contact/",
    },
}

MANUAL_EXTRA_ROWS = [
    {
        "LOCATION_NAME": "Shanghai Henlius Biotech, Inc.",
        "LOCATION_NAME_NATIVE": "",
        "LOCATION_ADDRESS": "11/F, B8 Building, No. 188 Yizhou Road, Xuhui District, Shanghai, China",
        "LOCATION_ADDRESS_NATIVE": "",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "POSTCODE": "200233",
        "STATE": "Shanghai",
        "CITY": "Shanghai",
        "SOURCE_URL": "https://www.henlius.com/en/contact-information.html",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Pharmaceutical manufacturing company headquarters",
    },
    {
        "LOCATION_NAME": "Fosun Kairos Cell Therapy Manufacturing Center",
        "LOCATION_NAME_NATIVE": "细胞治疗智造中心",
        "LOCATION_ADDRESS": "No. 2277 Kangxin Highway, Pudong New Area, Shanghai, China",
        "LOCATION_ADDRESS_NATIVE": "上海市浦东新区康新公路2277号",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "POSTCODE": "201210",
        "STATE": "Shanghai",
        "CITY": "Shanghai",
        "SOURCE_URL": "https://www.fosunkairos.com/patient/contact.html",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Cell therapy manufacturing center",
    },
    {
        "LOCATION_NAME": "Fosun Kairos Cell Therapy Innovation Center",
        "LOCATION_NAME_NATIVE": "细胞治疗创新中心",
        "LOCATION_ADDRESS": "No. 777 Shengrong Road, Pudong New Area, Shanghai, China",
        "LOCATION_ADDRESS_NATIVE": "上海市浦东新区张江盛荣路777号",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "POSTCODE": "201210",
        "STATE": "Shanghai",
        "CITY": "Shanghai",
        "SOURCE_URL": "https://www.fosunkairos.com/patient/contact.html",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Cell therapy innovation center",
    },
    {
        "LOCATION_NAME": "Fosun Kairos Cell Therapy Excellence Center",
        "LOCATION_NAME_NATIVE": "细胞治疗卓越中心",
        "LOCATION_ADDRESS": "No. 1289 Yishan Road, Xuhui District, Shanghai, China",
        "LOCATION_ADDRESS_NATIVE": "上海市徐汇区宜山路1289号",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "POSTCODE": "201210",
        "STATE": "Shanghai",
        "CITY": "Shanghai",
        "SOURCE_URL": "https://www.fosunkairos.com/patient/contact.html",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Cell therapy excellence center",
    },
    {
        "LOCATION_NAME": "Fosun Beiling (Beijing) Medical Technology Co., Ltd.",
        "LOCATION_NAME_NATIVE": "复星北铃（北京）医疗科技有限公司",
        "LOCATION_ADDRESS": "No. 30 Keji Road, Economic Development Zone, Miyun District, Beijing, China",
        "LOCATION_ADDRESS_NATIVE": "北京市密云区经济开发区科技路30号",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "POSTCODE": "",
        "STATE": "Beijing",
        "CITY": "Beijing",
        "SOURCE_URL": "https://www.fosunbeiling.com/aboutus",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Medical devices company headquarters",
    },
    {
        "LOCATION_NAME": "Breas Medical AB",
        "LOCATION_NAME_NATIVE": "",
        "LOCATION_ADDRESS": "Foretagsvagen 1, SE-435 33 Molnlycke, Sweden",
        "LOCATION_ADDRESS_NATIVE": "",
        "COUNTRY": "Sweden",
        "COUNTRY_ISO3": "SWE",
        "POSTCODE": "SE-435 33",
        "STATE": "Vastra Gotaland",
        "CITY": "Molnlycke",
        "SOURCE_URL": "https://shop.breas.com/contact-us/",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Medical devices company headquarters",
    },
    {
        "LOCATION_NAME": "Shanghai Yuyuan Tourist Mart (Group) Co., Ltd. Office",
        "LOCATION_NAME_NATIVE": "豫园股份",
        "LOCATION_ADDRESS": "No. 2 Fuxing East Road, Huangpu District, Shanghai, China",
        "LOCATION_ADDRESS_NATIVE": "上海市黄浦区复兴东路2号",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "POSTCODE": "200010",
        "STATE": "Shanghai",
        "CITY": "Shanghai",
        "SOURCE_URL": "https://www.yuyuantm.com.cn/contact.html",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Fosun global industry portfolio company headquarters",
    },
    {
        "LOCATION_NAME": "Shanghai Yuyuan Tourist Mart (Group) Co., Ltd. Registered Office",
        "LOCATION_NAME_NATIVE": "豫园股份",
        "LOCATION_ADDRESS": "No. 19 Wenchang Road, Huangpu District, Shanghai, China",
        "LOCATION_ADDRESS_NATIVE": "上海市黄浦区文昌路19号",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "POSTCODE": "",
        "STATE": "Shanghai",
        "CITY": "Shanghai",
        "SOURCE_URL": "https://www.yuyuantm.com.cn/IR/company.html",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Fosun global industry portfolio company registered office",
    },
    {
        "LOCATION_NAME": "Fosun Trade Headquarters",
        "LOCATION_NAME_NATIVE": "复星商社",
        "LOCATION_ADDRESS": "16th Floor, Building S1, Bund Finance Center, No. 600 Zhongshan East 2nd Road, Huangpu District, Shanghai, China",
        "LOCATION_ADDRESS_NATIVE": "上海市黄浦区中山东二路600号外滩金融中心S1幢16楼",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "POSTCODE": "200010",
        "STATE": "Shanghai",
        "CITY": "Shanghai",
        "SOURCE_URL": "https://www.fosuntrade.com/",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Fosun global industry portfolio company headquarters",
    },
    {
        "LOCATION_NAME": "Fosun Tourism Group Headquarters",
        "LOCATION_NAME_NATIVE": "复星旅文",
        "LOCATION_ADDRESS": "16th Floor, Building T1, No. 118 Feihong Road, Hongkou District, Shanghai, China",
        "LOCATION_ADDRESS_NATIVE": "上海市虹口区飞虹路118号T1栋16楼",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "POSTCODE": "200086",
        "STATE": "Shanghai",
        "CITY": "Shanghai",
        "SOURCE_URL": "https://www.fosunholiday.com/article/lxwm",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Fosun global industry portfolio company headquarters",
    },
    {
        "LOCATION_NAME": "Fosun Health Headquarters",
        "LOCATION_NAME_NATIVE": "复星健康",
        "LOCATION_ADDRESS": "Fosun Health Industry Technology Park, No. 367 Shengrong Road, Pudong New Area, Shanghai, China",
        "LOCATION_ADDRESS_NATIVE": "上海市浦东新区盛荣路367号复星健康产业科技园",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "POSTCODE": "",
        "STATE": "Shanghai",
        "CITY": "Shanghai",
        "SOURCE_URL": "https://www.fosunhealth.com/contact/",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Healthcare services company headquarters",
    },
    {
        "LOCATION_NAME": "Lanvin Group Headquarters",
        "LOCATION_NAME_NATIVE": "",
        "LOCATION_ADDRESS": "4th Floor, 168 Jiujiang Road, Carlowitz & Co, Huangpu District, Shanghai, 200001, China",
        "LOCATION_ADDRESS_NATIVE": "",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "POSTCODE": "200001",
        "STATE": "Shanghai",
        "CITY": "Shanghai",
        "SOURCE_URL": "http://www.lanvin-group.com",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Fosun global industry portfolio company headquarters",
    },
    {
        "LOCATION_NAME": "Shanghai Easun Technology Co., Ltd.",
        "LOCATION_NAME_NATIVE": "上海翌耀科技股份有限公司",
        "LOCATION_ADDRESS": "No. 669 Yuanyao Road, Jiading District, Shanghai, China",
        "LOCATION_ADDRESS_NATIVE": "上海市嘉定区园耀路669号",
        "COUNTRY": "China",
        "COUNTRY_ISO3": "CHN",
        "POSTCODE": "",
        "STATE": "Shanghai",
        "CITY": "Shanghai",
        "SOURCE_URL": "http://www.easun-tech.com/about/yiyaokeji",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Fosun global industry portfolio company headquarters",
    },
    {
        "LOCATION_NAME": "Fidelidade - Companhia de Seguros, S.A.",
        "LOCATION_NAME_NATIVE": "",
        "LOCATION_ADDRESS": "Largo do Calhariz, 30, 1249-001 Lisbon, Portugal",
        "LOCATION_ADDRESS_NATIVE": "",
        "COUNTRY": "Portugal",
        "COUNTRY_ISO3": "PRT",
        "POSTCODE": "1249-001",
        "STATE": "Lisbon",
        "CITY": "Lisbon",
        "SOURCE_URL": "https://www.fidelidade.pt/EN/fidelidade/about-us/Paginas/about-us.aspx",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Fosun global industry portfolio company headquarters",
    },
]

DISCOVERY_KEYWORDS = [
    "contact",
    "contact-us",
    "contactus",
    "about",
    "about-us",
    "our-company",
    "company",
    "profile",
    "overview",
    "location",
    "locations",
    "contacts",
    "contactos",
    "fale-connosco",
    "联系我们",
    "联系",
]


@dataclass
class InventoryItem:
    name: str
    website_url: str
    source_listing_url: str
    activity: str
    country_hint: str = ""
    source_type: str = "COMPANY WEBSITE"


@dataclass
class CandidateAddress:
    address: str
    source_url: str
    country: str = ""
    state: str = ""
    city: str = ""
    postcode: str = ""
    native_address: str = ""


def norm(text: str | None) -> str:
    if not text:
        return ""
    text = unicodedata.normalize("NFKC", text.replace("\xa0", " "))
    return re.sub(r"\s+", " ", text).strip()


def has_non_ascii(text: str) -> bool:
    return any(ord(ch) > 127 for ch in text)


def ascii_text(text: str) -> str:
    return norm(unidecode(text))


def translate_to_english(text: str) -> str:
    text = norm(text)
    if not text:
        return ""
    if text in TRANSLATION_CACHE:
        return TRANSLATION_CACHE[text]
    translated = text
    if has_non_ascii(text):
        try:
            translated = norm(TRANSLATOR.translate(text))
        except Exception:
            translated = text
    TRANSLATION_CACHE[text] = translated
    return translated


def english_ascii(text: str) -> str:
    text = norm(text)
    if not text:
        return ""
    if not has_non_ascii(text):
        return ascii_text(text)
    translated = translate_to_english(text)
    return ascii_text(translated) or ascii_text(text)


def fetch(url: str) -> tuple[str, str]:
    response = SESSION.get(url, timeout=REQUEST_TIMEOUT, verify=False)
    response.raise_for_status()
    return response.url, response.content.decode("utf-8", errors="replace")


def soup_from(url: str) -> tuple[str, BeautifulSoup, str]:
    final_url, text = fetch(url)
    return final_url, BeautifulSoup(text, "html.parser"), text


def site_root(url: str) -> str:
    parsed = urlparse(url)
    return f"{parsed.scheme}://{parsed.netloc}/"


def clean_address(text: str) -> str:
    text = norm(text)
    text = re.sub(r"\b(?:Tel|Telephone|Phone|Fax|Email|E-mail)\b.*$", "", text, flags=re.I)
    text = re.sub(r"(?:电话|邮箱|邮编|传真).*$", "", text)
    text = text.replace("#", "")
    text = re.sub(r"\s+,", ",", text)
    text = re.sub(r",\s*", ", ", text)
    return text.strip(" ,;-")


def standardize_country(country: str) -> str:
    country = norm(country)
    if not country:
        return ""
    if country in COUNTRY_ALIASES:
        return COUNTRY_ALIASES[country]
    if country in COUNTRY_NAME_MAP:
        return COUNTRY_NAME_MAP[country]
    try:
        return pycountry.countries.lookup(country).name
    except LookupError:
        return country


def infer_country(address: str, hint: str = "") -> str:
    if hint:
        return standardize_country(hint)
    address = norm(address)
    if not address:
        return ""
    for alias, country in COUNTRY_ALIASES.items():
        if alias.lower() in address.lower():
            return country
    for zh_name, en_name in COUNTRY_NAME_MAP.items():
        if zh_name in address:
            return en_name
    for country in pycountry.countries:
        if country.name.lower() in address.lower():
            return country.name
        official = getattr(country, "official_name", "")
        if official and official.lower() in address.lower():
            return country.name
    return ""


def country_iso3(country: str) -> str:
    if not country:
        return ""
    if country == "Hong Kong":
        return "HKG"
    try:
        return pycountry.countries.lookup(country).alpha_3
    except LookupError:
        return ""


def extract_postcode(address: str, country: str) -> str:
    patterns = {
        "China": r"\b\d{6}\b",
        "United States": r"\b\d{5}(?:-\d{4})?\b",
        "United Kingdom": r"\b[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}\b",
        "Portugal": r"\b\d{4}-\d{3}\b",
        "Germany": r"\b\d{5}\b",
        "India": r"\b\d{6}\b",
        "Sweden": r"\b\d{3}\s?\d{2}\b",
        "France": r"\b\d{5}\b",
    }
    pattern = patterns.get(country, r"\b\d{4,6}\b")
    match = re.search(pattern, address, flags=re.I)
    return match.group(0).strip() if match else ""


def extract_city_state(address: str, country: str) -> tuple[str, str]:
    parts = [norm(part) for part in re.split(r",|，", address) if norm(part)]
    if not parts:
        return "", ""
    if country == "China":
        joined = ", ".join(parts)
        for municipality in ("Shanghai", "Beijing", "Tianjin", "Chongqing"):
            if municipality.lower() in joined.lower():
                return municipality, municipality
        city = ""
        state = ""
        for part in reversed(parts):
            if " Province" in part and not state:
                state = part
            if part.endswith(" City") or part in {"Shenzhen", "Suzhou", "Dalian", "Chengdu", "Nanjing", "Wuhan"}:
                city = part.replace(" City", "")
                break
        return city, state
    if country == "United States" and len(parts) >= 2:
        city = re.sub(r"\b[A-Z]{2}\s+\d{5}(?:-\d{4})?\b", "", parts[-2]).strip()
        state_match = re.search(r"\b([A-Z]{2})\s+\d{5}(?:-\d{4})?\b", parts[-1])
        return city, state_match.group(1) if state_match else ""
    if country == "United Kingdom":
        return ("London", "England") if "London" in address else (parts[-2] if len(parts) >= 2 else parts[-1], "")
    if country == "Portugal":
        return ("Lisbon", "Lisbon") if "Lisbon" in address else (parts[-2] if len(parts) >= 2 else parts[-1], "")
    if country == "Germany":
        city = re.sub(r"\b\d{5}\b", "", parts[-2] if len(parts) >= 2 else parts[-1]).strip()
        return city, "Hesse" if "Frankfurt" in city else ""
    if country == "Hong Kong":
        return "Hong Kong", "Hong Kong"
    if country == "Sweden":
        return ("Molnlycke", "Vastra Gotaland") if "Molnlycke" in address else (parts[-2] if len(parts) >= 2 else parts[-1], "")
    cleaned_parts = [re.sub(r"\b\d{4,6}\b", "", part).strip() for part in parts]
    cleaned_parts = [part for part in cleaned_parts if part]
    if len(cleaned_parts) >= 2:
        return cleaned_parts[-2], ""
    return cleaned_parts[-1] if cleaned_parts else "", ""


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in COLUMNS})


def office_rows() -> list[dict[str, str]]:
    _, soup, _ = soup_from(FOSUN_OFFICES_URL)
    rows: list[dict[str, str]] = []
    for item in soup.select("li.pull-left.wow.fadeInUp.ratio-img"):
        city_en = norm(item.select_one("h3").get_text(" ", strip=True) if item.select_one("h3") else "")
        if city_en not in OFFICE_TRANSLATIONS:
            continue
        config = OFFICE_TRANSLATIONS[city_en]
        rows.append(
            {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": f"Fosun {city_en} Office",
                "LOCATION_NAME_NATIVE": f"复星{config['name_native']}办公室" if config["name_native"] else "",
                "LOCATION_ADDRESS": config["address"],
                "LOCATION_ADDRESS_NATIVE": config["addr_native"],
                "LATITUDE": "",
                "LONGITUDE": "",
                "COUNTRY": config["country"],
                "COUNTRY_ISO3": country_iso3(config["country"]),
                "POSTCODE": config["postcode"],
                "STATE": config["state"],
                "CITY": config["city"],
                "SOURCE_URL": FOSUN_OFFICES_URL,
                "SOURCE_TYPE": "COMPANY WEBSITE",
                "ACTIVITY_AT_ASSET": "Fosun global office",
                "coord_source": "Not from website",
            }
        )
    return rows


def parse_pharma_company_pages() -> list[InventoryItem]:
    items: list[InventoryItem] = []
    for page_url, activity in PHARMA_COMPANY_PAGES.items():
        _, soup, _ = soup_from(page_url)
        for li in soup.select("li.wow.fadeInUp"):
            name = norm(li.select_one("h3").get_text(" ", strip=True) if li.select_one("h3") else "")
            link = li.select_one("a[href]")
            href = norm(link.get("href", "")) if link else ""
            if not name or not href:
                continue
            items.append(
                InventoryItem(
                    name=name,
                    website_url=urljoin(page_url, href),
                    source_listing_url=page_url,
                    activity=activity,
                )
            )
    return items


def parse_global_industry_links() -> list[InventoryItem]:
    items: list[InventoryItem] = []
    _, soup, _ = soup_from(FOSUN_GLOBAL_INDUSTRY_URL)
    for panel in soup.select("li.panel"):
        country_native = norm(panel.select_one("h2").get_text(" ", strip=True) if panel.select_one("h2") else "")
        country_hint = COUNTRY_NAME_MAP.get(country_native, "")
        for anchor in panel.select("a[href]"):
            href = urljoin(FOSUN_GLOBAL_INDUSTRY_URL, anchor.get("href", ""))
            if not href.startswith("http"):
                continue
            netloc = urlparse(href).netloc.lower()
            if netloc not in PORTFOLIO_LINK_ALLOWLIST:
                continue
            name = norm(anchor.get_text(" ", strip=True))
            if not name:
                continue
            items.append(
                InventoryItem(
                    name=name,
                    website_url=href,
                    source_listing_url=FOSUN_GLOBAL_INDUSTRY_URL,
                    activity="Fosun global industry portfolio company headquarters",
                    country_hint=country_hint,
                )
            )
    return items


def dedupe_inventory(items: list[InventoryItem]) -> list[InventoryItem]:
    out: list[InventoryItem] = []
    seen: set[tuple[str, str]] = set()
    for item in items:
        key = (item.name.lower(), item.website_url.lower().rstrip("/"))
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def jsonld_candidates(page_url: str, soup: BeautifulSoup) -> list[CandidateAddress]:
    candidates: list[CandidateAddress] = []
    for script in soup.select('script[type="application/ld+json"]'):
        raw = norm(script.get_text(" ", strip=True))
        if not raw:
            continue
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            continue
        objects = payload if isinstance(payload, list) else [payload]
        for obj in objects:
            if not isinstance(obj, dict):
                continue
            address = obj.get("address")
            if isinstance(address, dict):
                street = norm(address.get("streetAddress"))
                city = norm(address.get("addressLocality"))
                state = norm(address.get("addressRegion"))
                postcode = norm(address.get("postalCode"))
                country = standardize_country(norm(address.get("addressCountry")))
                joined = clean_address(", ".join(part for part in [street, city, state, postcode, country] if part))
                if joined:
                    candidates.append(CandidateAddress(joined, page_url, country, state, city, postcode))
    return candidates


def regex_candidates(page_url: str, soup: BeautifulSoup, raw_text: str) -> list[CandidateAddress]:
    candidates: list[CandidateAddress] = []
    page_text = "\n".join(norm(line) for line in soup.stripped_strings if norm(line))
    patterns = [
        r"Address[:：]\s*(.+?)(?:\n|Tel|Phone|Email|Fax|$)",
        r"Registered Office\s*(.+?)(?:\n|Tel|Phone|Email|Fax|$)",
        r"Corporate Office\s*(.+?)(?:\n|Tel|Phone|Email|Fax|$)",
        r"Head Office\s*(.+?)(?:\n|Tel|Phone|Email|Fax|$)",
        r"Headquarters\s*(.+?)(?:\n|Tel|Phone|Email|Fax|$)",
        r"Morada[:：]?\s*(.+?)(?:\n|Tel|Phone|Email|Fax|$)",
        r"地址[:：]\s*(.+?)(?:\n|电话|邮箱|邮编|传真|$)",
        r"联系地址[:：]\s*(.+?)(?:\n|电话|邮箱|邮编|传真|$)",
        r"公司地址[:：]\s*(.+?)(?:\n|电话|邮箱|邮编|传真|$)",
        r"办公地址[:：]\s*(.+?)(?:\n|电话|邮箱|邮编|传真|$)",
    ]
    for pattern in patterns:
        for match in re.finditer(pattern, page_text, flags=re.I | re.S):
            address = clean_address(match.group(1))
            if len(address) >= 12:
                candidates.append(CandidateAddress(address, page_url, native_address=address))
    for tag in soup.find_all("address"):
        address = clean_address(tag.get_text(" ", strip=True))
        if len(address) >= 12:
            candidates.append(CandidateAddress(address, page_url, native_address=address))
    for text_node in soup.find_all(string=re.compile(r"Registered Office|Corporate Office|Address|地址", re.I)):
        parent = text_node.parent.get_text(" ", strip=True) if getattr(text_node, "parent", None) else ""
        address = clean_address(parent)
        if len(address) >= 18:
            candidates.append(CandidateAddress(address, page_url, native_address=address))
    for match in re.finditer(r"(?:地址|联系地址|公司地址|办公地址)[:：]\s*([^<]{8,240})", raw_text, flags=re.I):
        address = clean_address(match.group(1))
        if len(address) >= 8:
            candidates.append(CandidateAddress(address, page_url, native_address=address))
    return candidates


def choose_best_candidate(candidates: list[CandidateAddress]) -> CandidateAddress | None:
    if not candidates:
        return None
    def score(candidate: CandidateAddress) -> tuple[int, int]:
        address = norm(candidate.address)
        lower = address.lower()
        points = 0
        if any(token in lower for token in ["road", "street", "avenue", "tower", "district", "room", "floor", "park", "building"]):
            points += 3
        if re.search(r"\d", address):
            points += 2
        if any(token in lower for token in ["office", "address", "registered"]):
            points += 1
        return points, len(address)
    return sorted(candidates, key=score, reverse=True)[0]


def candidate_pages(item: InventoryItem) -> list[str]:
    pages: list[str] = []
    start_url = SOURCE_URL_OVERRIDES.get(item.website_url, item.website_url)
    pages.extend([start_url, site_root(start_url)])
    pages.extend(MANUAL_PAGE_HINTS.get(urlparse(start_url).netloc, []))
    try:
        final_url, soup, _ = soup_from(start_url)
        for anchor in soup.select("a[href]"):
            href = urljoin(final_url, anchor.get("href", ""))
            label = norm(anchor.get_text(" ", strip=True)).lower()
            if urlparse(href).netloc and urlparse(href).netloc != urlparse(final_url).netloc:
                continue
            href_lower = href.lower()
            if any(keyword in href_lower or keyword in label for keyword in DISCOVERY_KEYWORDS):
                pages.append(href)
    except Exception:
        pass
    deduped: list[str] = []
    seen: set[str] = set()
    for page in pages:
        page = page.rstrip("/")
        if not page or page in seen:
            continue
        seen.add(page)
        deduped.append(page)
    return deduped[:10]


def crawl_item(item: InventoryItem) -> tuple[dict[str, str] | None, dict[str, Any]]:
    debug: dict[str, Any] = {
        "name": item.name,
        "website_url": item.website_url,
        "source_listing_url": item.source_listing_url,
        "activity": item.activity,
        "candidate_pages": [],
        "errors": [],
    }
    candidates: list[CandidateAddress] = []
    for page in candidate_pages(item):
        debug["candidate_pages"].append(page)
        try:
            final_url, soup, raw_text = soup_from(page)
            if "Access to this site is blocked" in raw_text:
                debug["errors"].append(f"Blocked: {page}")
                continue
            candidates.extend(jsonld_candidates(final_url, soup))
            candidates.extend(regex_candidates(final_url, soup, raw_text))
        except Exception as exc:
            debug["errors"].append(f"{page}: {type(exc).__name__}: {exc}")
    best = choose_best_candidate(candidates)
    if not best:
        return None, debug
    native_name = item.name if has_non_ascii(item.name) else ""
    native_address = best.native_address if has_non_ascii(best.native_address) else ""
    location_name = english_ascii(item.name)
    location_address = clean_address(english_ascii(best.address))
    country = standardize_country(best.country or infer_country(location_address, item.country_hint))
    postcode = best.postcode or extract_postcode(location_address, country)
    city = best.city
    state = best.state
    if not city:
        city, inferred_state = extract_city_state(location_address, country)
        if not state:
            state = inferred_state
    row = {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": location_name,
        "LOCATION_NAME_NATIVE": norm(native_name),
        "LOCATION_ADDRESS": location_address,
        "LOCATION_ADDRESS_NATIVE": norm(native_address),
        "LATITUDE": "",
        "LONGITUDE": "",
        "COUNTRY": country,
        "COUNTRY_ISO3": country_iso3(country),
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": best.source_url,
        "SOURCE_TYPE": item.source_type,
        "ACTIVITY_AT_ASSET": item.activity,
        "coord_source": "Not from website",
    }
    debug["selected"] = row
    return row, debug


def dedupe_rows(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    seen: set[tuple[str, str, str]] = set()
    for row in rows:
        key = (row["LOCATION_NAME"], row["LOCATION_ADDRESS"], row["SOURCE_URL"])
        if key in seen:
            continue
        seen.add(key)
        out.append(row)
    return out


def apply_manual_curation(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    curated: list[dict[str, str]] = []
    for row in rows:
        if row["LOCATION_NAME"] in DROP_LOCATION_NAMES:
            continue
        updates = MANUAL_ROW_OVERRIDES.get(row["LOCATION_NAME"], {})
        if updates:
            row.update(updates)
        curated.append(row)

    for extra in MANUAL_EXTRA_ROWS:
        curated.append(
            {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LATITUDE": "",
                "LONGITUDE": "",
                "coord_source": "Not from website",
                **extra,
            }
        )

    return dedupe_rows(curated)


def validate_rows(rows: list[dict[str, str]]) -> list[str]:
    issues: list[str] = []
    for row in rows:
        if not row["LOCATION_ADDRESS"]:
            issues.append(f"Blank LOCATION_ADDRESS: {row['LOCATION_NAME']}")
        if not row["CITY"]:
            issues.append(f"Blank CITY: {row['LOCATION_NAME']}")
        if "#" in row["LOCATION_ADDRESS"]:
            issues.append(f"'#' in LOCATION_ADDRESS: {row['LOCATION_NAME']}")
        if row["COUNTRY"] and not row["COUNTRY_ISO3"]:
            issues.append(f"Missing COUNTRY_ISO3: {row['LOCATION_NAME']} / {row['COUNTRY']}")
    return issues


def memory_draft(final_rows: list[dict[str, str]], failures: list[dict[str, Any]], elapsed_seconds: float) -> str:
    office_rows_count = sum(1 for row in final_rows if row["ACTIVITY_AT_ASSET"] == "Fosun global office")
    portfolio_rows = sum(
        1 for row in final_rows if row["ACTIVITY_AT_ASSET"].startswith("Fosun global industry portfolio")
    )
    pharma_rows = len(final_rows) - office_rows_count - portfolio_rows
    return f"""## R-XX — {ISSUER_NAME}
*Extracted: Apr 2026*

| Source | Records | Method | Script |
|--------|---------|--------|--------|
| Fosun global offices page | {office_rows_count} | Static HTML office cards with inline address fields | `linked_company_hq_extractor.py` |
| Fosun Pharma member-company pages | {pharma_rows} | Static HTML company lists -> official website HQ/contact-page crawl | `linked_company_hq_extractor.py` |
| Fosun global industry page | {portfolio_rows} | Static HTML portfolio links -> official website HQ/contact-page crawl | `linked_company_hq_extractor.py` |
| **TOTAL** | **{len(final_rows)}** | | |

**Platform Pattern:** P-07 variant (static multi-source company pages + linked official-site follow-through)

**Key Learnings:**
- ✅ The user-supplied English Fosun URLs are outdated; the live pages are `/about/Global.html` and `/business/`.
- ✅ `https://www.fosun.com/about/Global.html` contains seven inline global-office cards with full address blocks.
- ✅ Fosun Pharma member-company pages (`companies78.html`–`companies83.html`) expose official subsidiary websites that can be followed to HQ/contact pages.
- ❌ Some subsidiary sites are blocked or unreachable from the MSCI environment, so the crawl needs debug logging and graceful skips.

**New reusable script candidate:** `linked_company_hq_extractor.py`

**Runtime:** {round(elapsed_seconds / 60.0, 2)} minutes
**Failed/blocked sites logged:** {len(failures)}
"""


def main() -> None:
    start_time = time.time()
    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    rows = office_rows()
    inventory = dedupe_inventory(parse_pharma_company_pages() + parse_global_industry_links())
    INVENTORY_JSON.write_text(json.dumps([item.__dict__ for item in inventory], ensure_ascii=False, indent=2), encoding="utf-8")
    debug_records: list[dict[str, Any]] = []
    checkpoint_written = False
    for item in inventory:
        row, debug = crawl_item(item)
        debug_records.append(debug)
        if row:
            rows.append(row)
            rows = dedupe_rows(rows)
            if not checkpoint_written and len(rows) >= CHECKPOINT_THRESHOLD:
                write_csv(CHECKPOINT_CSV, rows)
                checkpoint_written = True
    rows = apply_manual_curation(dedupe_rows(rows))
    if len(rows) >= CHECKPOINT_THRESHOLD:
        write_csv(CHECKPOINT_CSV, rows)
        checkpoint_written = True
    validation_issues = validate_rows(rows)
    if validation_issues:
        DEBUG_JSON.write_text(json.dumps({"validation_issues": validation_issues, "records": debug_records}, ensure_ascii=False, indent=2), encoding="utf-8")
        raise ValueError("\n".join(validation_issues))
    write_csv(FINAL_CSV, rows)
    failures = [record for record in debug_records if "selected" not in record]
    DEBUG_JSON.write_text(json.dumps({"records": debug_records, "failures": failures}, ensure_ascii=False, indent=2), encoding="utf-8")
    elapsed_seconds = time.time() - start_time
    MEMORY_DRAFT_MD.write_text(memory_draft(rows, failures, elapsed_seconds), encoding="utf-8")
    SUMMARY_JSON.write_text(
        json.dumps(
            {
                "issuer_id": ISSUER_ID,
                "issuer_name": ISSUER_NAME,
                "final_row_count": len(rows),
                "checkpoint_threshold": CHECKPOINT_THRESHOLD,
                "checkpoint_written": checkpoint_written,
                "final_csv": str(FINAL_CSV),
                "checkpoint_csv": str(CHECKPOINT_CSV) if checkpoint_written else "",
                "inventory_json": str(INVENTORY_JSON),
                "debug_json": str(DEBUG_JSON),
                "memory_draft": str(MEMORY_DRAFT_MD),
                "elapsed_seconds": round(elapsed_seconds, 2),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"Rows written: {len(rows)}")
    print(f"Checkpoint written: {checkpoint_written}")
    print(f"Final CSV: {FINAL_CSV}")
    print(f"Debug JSON: {DEBUG_JSON}")


if __name__ == "__main__":
    main()
