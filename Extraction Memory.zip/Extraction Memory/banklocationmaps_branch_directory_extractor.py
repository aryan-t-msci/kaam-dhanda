"""
Generic extractor for banklocationmaps.com branch directory detail pages.

Pattern handled:
    Static branch-directory pages that expose one branch per detail URL and publish
    a BankOrCreditUnion schema.org block with address, phone, and geo coordinates.

How to configure for a new issuer:
    Edit only the CONFIGURATION block below. The generic extraction logic should
    work for other banklocationmaps-hosted branch directories with the same URL
    structure and schema payloads.

Usage:
    python banklocationmaps_branch_directory_extractor.py
"""

from __future__ import annotations

# ============================================================
# CONFIGURATION - Edit this block for each new issuer
# ============================================================
ISSUER_ID = "IID000000002149414"
ISSUER_NAME = "BANK OF QUEENSLAND LIMITED"
BASE_URL = "https://boq.banklocationmaps.com"
SEED_URL = "https://boq.banklocationmaps.com/en/branches/aus/"
VALIDATION_URL = "https://www.boq.com.au/contact-us/branch-network/"
ANNUAL_REPORT_URL = "https://www.boq.com.au/content/dam/boq/files/shareholder-centre/2025/25-annual-report.pdf"
TARGET_COUNT = 152
COUNTRY = "Australia"
COUNTRY_ISO3 = "AUS"
ACTIVITY_AT_ASSET = "Bank branch"
STAGING_CSV = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp Test\Extraction_Batch_odbatch9_10_output_for_straive_20260605_143852\staging\IID000000002149414_BANK OF QUEENSLAND LIMITED.csv"
REJECT_CSV = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp Test\Extraction_Batch_odbatch9_10_output_for_straive_20260605_143852\reject\IID000000002149414_BANK OF QUEENSLAND LIMITED_rejected.csv"
PROGRESS_JSON = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp Test\Extraction_Batch_odbatch9_10_output_for_straive_20260605_143852\IID000000002149414_BANK OF QUEENSLAND LIMITED\progress.json"
CHECKPOINT_CSV = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp Test\Extraction_Batch_odbatch9_10_output_for_straive_20260605_143852\IID000000002149414_BANK OF QUEENSLAND LIMITED\checkpoint_target_reached.csv"
DETAIL_SAMPLE_JSON = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp Test\Extraction_Batch_odbatch9_10_output_for_straive_20260605_143852\IID000000002149414_BANK OF QUEENSLAND LIMITED\detail_sample.json"
TIMEOUT = 20

# ============================================================
# GENERIC EXTRACTION LOGIC - Do not modify per issuer
# ============================================================

import csv
import json
import re
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup


OUTPUT_COLUMNS = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
    "VALIDATION_URL",
]

REJECT_COLUMNS = OUTPUT_COLUMNS + ["rejection_reason", "rejected_by"]


def build_session() -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/137.0.0.0 Safari/537.36"
            ),
            "Accept-Language": "en-US,en;q=0.9",
        }
    )
    return session


def fetch(session: requests.Session, url: str) -> str:
    last_error = None
    for attempt in range(5):
        response = session.get(url, timeout=TIMEOUT)
        if response.status_code != 429:
            response.raise_for_status()
            time.sleep(0.25)
            return response.text
        last_error = requests.HTTPError(f"429 rate limit for {url}")
        time.sleep(1.5 * (attempt + 1))
    if last_error:
        raise last_error
    raise RuntimeError(f"Failed to fetch {url}")


def is_branch_listing_path(url: str) -> bool:
    parsed = urlparse(url)
    return parsed.netloc == urlparse(BASE_URL).netloc and parsed.path.startswith("/en/branches/aus")


def normalize_branch_url(url: str) -> str:
    url = url.split("?")[0].split("#")[0]
    return url.rstrip("/")


def extract_state_urls(seed_html: str) -> List[str]:
    soup = BeautifulSoup(seed_html, "html.parser")
    states = []
    for tag in soup.find_all("a", href=True):
        href = urljoin(SEED_URL, tag["href"]).rstrip("/")
        parsed = urlparse(href)
        if parsed.netloc != urlparse(BASE_URL).netloc:
            continue
        if re.fullmatch(r"/en/branches/aus/[a-z-]+", parsed.path):
            if parsed.path.endswith("/map"):
                continue
            states.append(href)
    return sorted(dict.fromkeys(states))


def extract_listing_pages(state_url: str, html: str) -> List[str]:
    soup = BeautifulSoup(html, "html.parser")
    pages = [state_url.rstrip("/")]
    for tag in soup.find_all("a", href=True):
        href = urljoin(state_url, tag["href"])
        parsed = urlparse(href)
        if parsed.path.rstrip("/") != urlparse(state_url).path.rstrip("/"):
            continue
        if "page=" in parsed.query:
            pages.append(href)
    return sorted(dict.fromkeys(pages))


def enumerate_listing_pages(session: requests.Session) -> List[str]:
    seed_html = fetch(session, SEED_URL)
    state_urls = extract_state_urls(seed_html)
    listing_pages = [SEED_URL.rstrip("/")]

    for state_url in state_urls:
        state_html = fetch(session, state_url)
        state_pages = extract_listing_pages(state_url, state_html)
        listing_pages.extend(state_pages)

    return sorted(dict.fromkeys(listing_pages))


def parse_json_ld_objects(soup: BeautifulSoup) -> List[Dict]:
    objects: List[Dict] = []
    for script in soup.find_all("script", type="application/ld+json"):
        raw = script.string or script.get_text()
        if not raw:
            continue
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, list):
            objects.extend(x for x in parsed if isinstance(x, dict))
        elif isinstance(parsed, dict):
            objects.append(parsed)
    return objects


def pick_location_schema(objects: Iterable[Dict]) -> Optional[Dict]:
    for obj in objects:
        obj_type = obj.get("@type")
        if obj_type in {"BankOrCreditUnion", "LocalBusiness", "FinancialService"}:
            return obj
    return None


def clean_whitespace(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()


def derive_name(name: str) -> str:
    label = clean_whitespace(name)
    if "boq" not in label.lower():
        label = f"{label} BOQ Branch"
    if "branch" not in label.lower():
        label = f"{label} Branch"
    return label.replace("Branch Branch", "Branch")


def split_au_address(full_address: str) -> Tuple[str, str, str, str]:
    cleaned = clean_whitespace(full_address.replace("#", ""))
    match = re.match(
        r"^(?P<street>.+?),\s*(?P<city>[^,]+),\s*(?P<state>[A-Z]{2,3}),\s*(?P<postcode>\d{4})$",
        cleaned,
    )
    if match:
        street = clean_whitespace(match.group("street"))
        city = clean_whitespace(match.group("city"))
        state = clean_whitespace(match.group("state"))
        postcode = clean_whitespace(match.group("postcode"))
        return f"{street}, {city}, {state}, {postcode}", city, state, postcode

    parts = [part.strip() for part in cleaned.split(",") if part.strip()]
    postcode = ""
    state = ""
    city = ""
    if parts:
        last = parts[-1]
        state_post = re.search(r"\b([A-Z]{2,3})\b(?:\s*,?)?\s*(\d{4})?$", last)
        if state_post:
            state = state_post.group(1) or ""
            postcode = state_post.group(2) or ""
            last_without_state = re.sub(r"\b[A-Z]{2,3}\b(?:\s*,?)?\s*\d{0,4}$", "", last).strip(" ,")
            if last_without_state:
                city = last_without_state
        if not city and len(parts) >= 2:
            city = parts[-2]
    return cleaned, clean_whitespace(city), state, postcode


def build_row(name: str, facility_type: str, street_address: str, source_url: str, latitude: str, longitude: str) -> Dict[str, str]:
    full_address, city, state, postcode = split_au_address(street_address)
    row = {
        "ISSUER_ID": ISSUER_ID,
        "ISSUER_NAME": ISSUER_NAME,
        "LOCATION_NAME": derive_name(name.strip()),
        "LOCATION_ADDRESS": full_address,
        "LATITUDE": latitude,
        "LONGITUDE": longitude,
        "COUNTRY": COUNTRY,
        "COUNTRY_ISO3": COUNTRY_ISO3,
        "POSTCODE": postcode,
        "STATE": state,
        "CITY": city,
        "SOURCE_URL": source_url,
        "SOURCE_TYPE": "BUSINESS DIRECTORY",
        "ACTIVITY_AT_ASSET": facility_type or ACTIVITY_AT_ASSET,
        "coord_source": "website" if latitude and longitude else "Not from website",
        "QA_flag": "",
        "VALIDATION_URL": VALIDATION_URL,
    }
    return row


def extract_page_coords(html: str) -> List[Tuple[str, str]]:
    match = re.search(r"static/(pin-s-[^\"']+?)/auto/", html)
    if not match:
        return []
    segment = match.group(1)
    pairs = re.findall(r"\(([-0-9.]+),([-0-9.]+)\)", segment)
    # Mapbox static uses lon,lat ordering. Convert to lat,lon.
    return [(lat, lon) for lon, lat in pairs]


def extract_cards(page_url: str, html: str) -> List[Dict[str, str]]:
    soup = BeautifulSoup(html, "html.parser")
    coords = extract_page_coords(html)
    cards = []
    for index, item in enumerate(soup.select("div.cz-filter-item")):
        anchor = item.select_one("a[href*='/en/branch/']")
        name_tag = item.select_one("h2")
        type_tag = item.select_one("h3")
        address_span = item.select_one("span.text-heading.font-size-sm.text-uppercase")
        if not anchor or not name_tag or not address_span:
            continue
        address_lines = [clean_whitespace(text) for text in address_span.stripped_strings]
        street_address = ", ".join(address_lines)
        latitude = ""
        longitude = ""
        if index < len(coords):
            latitude, longitude = coords[index]
        cards.append(
            {
                "name": clean_whitespace(name_tag.get_text(" ", strip=True)),
                "facility_type": clean_whitespace(type_tag.get_text(" ", strip=True)) if type_tag else ACTIVITY_AT_ASSET,
                "street_address": street_address,
                "source_url": page_url,
                "detail_url": normalize_branch_url(urljoin(page_url, anchor["href"])),
                "latitude": latitude,
                "longitude": longitude,
            }
        )
    return cards


def validate_row(row: Dict[str, str]) -> Tuple[Optional[Dict[str, str]], Optional[Dict[str, str]]]:
    qa_flags: List[str] = []
    mandatory = [
        "LOCATION_NAME",
        "LOCATION_ADDRESS",
        "COUNTRY",
        "COUNTRY_ISO3",
        "CITY",
        "ACTIVITY_AT_ASSET",
        "SOURCE_URL",
        "SOURCE_TYPE",
        "coord_source",
    ]
    for column in mandatory:
        if not clean_whitespace(row.get(column, "")):
            rejected = dict(row)
            rejected["rejection_reason"] = f"missing_{column.lower()}"
            rejected["rejected_by"] = "worker_qa"
            return None, rejected

    if row["coord_source"] not in {"website", "Not from website"}:
        row["coord_source"] = "website" if row["LATITUDE"] and row["LONGITUDE"] else "Not from website"
        row["QA_flag"] = "fixed"

    city = row["CITY"]
    if re.match(r"^\d", city) or len(city) < 2 or len(city) > 60:
        qa_flags.append("CITY")
    if row["ACTIVITY_AT_ASSET"].lower() in {"menu", "search"}:
        qa_flags.append("ACTIVITY_AT_ASSET")
    if qa_flags and not row["QA_flag"]:
        row["QA_flag"] = "|".join(qa_flags)

    return row, None


def write_csv(path: Path, rows: List[Dict[str, str]], fieldnames: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def save_progress(progress_path: Path, rows: List[Dict[str, str]], branch_urls: List[str], pages_seen: List[str]) -> None:
    payload = {
        "saved_at_epoch": time.time(),
        "rows_collected": len(rows),
        "branch_urls": len(branch_urls),
        "pages_seen": len(pages_seen),
        "target_count": TARGET_COUNT,
    }
    progress_path.parent.mkdir(parents=True, exist_ok=True)
    progress_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def main() -> None:
    session = build_session()
    listing_pages = enumerate_listing_pages(session)
    rows: List[Dict[str, str]] = []
    rejected_rows: List[Dict[str, str]] = []
    checkpoint_written = False
    sample_payload = []
    seen_details = set()

    for index, page_url in enumerate(listing_pages, start=1):
        html = fetch(session, page_url)
        for card in extract_cards(page_url, html):
            if card["detail_url"] in seen_details:
                continue
            seen_details.add(card["detail_url"])
            row = build_row(
                card["name"],
                card["facility_type"],
                card["street_address"],
                card["source_url"],
                card["latitude"],
                card["longitude"],
            )
            clean_row, rejected = validate_row(row)
            if rejected:
                rejected_rows.append(rejected)
            elif clean_row:
                rows.append(clean_row)
                if len(sample_payload) < 5:
                    sample_payload.append(clean_row)

            if not checkpoint_written and len(rows) >= TARGET_COUNT:
                write_csv(Path(CHECKPOINT_CSV), rows, OUTPUT_COLUMNS)
                checkpoint_written = True

        if index % 5 == 0:
            save_progress(Path(PROGRESS_JSON), rows, listing_pages, listing_pages)

    rows.sort(key=lambda item: (item["STATE"], item["CITY"], item["LOCATION_NAME"], item["LOCATION_ADDRESS"]))
    write_csv(Path(STAGING_CSV), rows, OUTPUT_COLUMNS)
    if rejected_rows:
        write_csv(Path(REJECT_CSV), rejected_rows, REJECT_COLUMNS)

    Path(DETAIL_SAMPLE_JSON).write_text(json.dumps(sample_payload, indent=2), encoding="utf-8")
    save_progress(Path(PROGRESS_JSON), rows, list(seen_details), listing_pages)

    result = {
        "branch_urls": len(seen_details),
        "listing_pages_seen": len(listing_pages),
        "rows_written": len(rows),
        "rejected_rows": len(rejected_rows),
        "checkpoint_written": checkpoint_written,
        "staging_csv": STAGING_CSV,
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
