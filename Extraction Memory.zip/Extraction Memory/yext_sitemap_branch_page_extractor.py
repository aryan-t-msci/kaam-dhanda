"""
Yext sitemap branch-page extractor.

Generic extractor for issuers whose official site publishes one branch detail page per
location in an XML sitemap, while the actual branch address is hydrated client-side by a
Yext embed after page load.

How to configure for a new issuer:
1. Update the CONFIGURATION block only.
2. Point BRANCH_SITEMAP_URL at the issuer's branch/location sitemap.
3. Adjust the page selectors if the branch title or address container differs.
4. Populate EXTRA_ROWS only for distinct non-branch facilities that should be added from
   other official pages.

Usage:
    python yext_sitemap_branch_page_extractor.py
"""

from __future__ import annotations

import csv
import json
import math
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import requests
from bs4 import BeautifulSoup
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import sync_playwright


sys.stdout.reconfigure(encoding="utf-8")


# ============================================================================
# CONFIGURATION - Edit this block for each new issuer
# ============================================================================
ISSUER_ID = "IID000000002160120"
ISSUER_NAME = "DIME COMMUNITY BANCSHARES, INC."
BRANCH_SITEMAP_URL = "https://www.dime.com/branch-sitemap.xml"
HEADERS = {"User-Agent": "Mozilla/5.0"}

BATCH_TEMP = Path(
    r"C:\Users\tiwaary\OneDrive - MSCI Office 365\Test - ACWI IMI Straive\Temp\Extraction_Batch_Chat5.4_odbatch9_10_output_for_straive_20260601_112949"
)
ISSUER_TEMP_DIR = BATCH_TEMP / f"{ISSUER_ID}_{ISSUER_NAME}"
STAGING_CSV = (
    BATCH_TEMP / "staging" / f"{ISSUER_ID}_{ISSUER_NAME}.csv"
)
CHECKPOINT_CSV = ISSUER_TEMP_DIR / f"{ISSUER_ID}_{ISSUER_NAME}_checkpoint.csv"
PROGRESS_JSON = ISSUER_TEMP_DIR / f"{ISSUER_ID}_progress.json"
SUMMARY_JSON = ISSUER_TEMP_DIR / f"{ISSUER_ID}_summary.json"

CHECKPOINT_EVERY = 20
COUNTRY = "United States"
COUNTRY_ISO3 = "USA"
BRANCH_ACTIVITY = "Banking branch"
HQ_SOURCE_URL = "https://www.dime.com/about"

TITLE_SELECTOR = "h1"
ADDRESS_SELECTOR = "p.address"

EXTRA_ROWS = [
    {
        "LOCATION_NAME": "Corporate Headquarters",
        "LOCATION_ADDRESS": "898 Veterans Memorial Highway, Suite 560, Hauppauge, NY 11788",
        "CITY": "Hauppauge",
        "STATE": "NY",
        "POSTCODE": "11788",
        "SOURCE_URL": "https://www.dime.com/about",
        "SOURCE_TYPE": "COMPANY WEBSITE",
        "ACTIVITY_AT_ASSET": "Corporate headquarters",
    }
]

META_FALLBACKS = {
    "bedford": {
        "LOCATION_NAME": "Bedford",
        "LOCATION_ADDRESS": "214 Bedford Ave, Brooklyn, NY 11249",
        "CITY": "Brooklyn",
        "STATE": "NY",
        "POSTCODE": "11249",
    },
    "east-moriches": {
        "LOCATION_NAME": "East Moriches",
        "LOCATION_ADDRESS": "481 Montauk Highway, East Moriches, NY 11940",
        "CITY": "East Moriches",
        "STATE": "NY",
        "POSTCODE": "11940",
    },
    "flushing": {
        "LOCATION_NAME": "Flushing",
        "LOCATION_ADDRESS": "59-23 Main Street, Flushing, NY 11355",
        "CITY": "Flushing",
        "STATE": "NY",
        "POSTCODE": "11355",
    },
    "manhattan": {
        "LOCATION_NAME": "Manhattan",
        "LOCATION_ADDRESS": "34 East 51st Street, New York, NY 10022",
        "CITY": "New York",
        "STATE": "NY",
        "POSTCODE": "10022",
    },
    "melville": {
        "LOCATION_NAME": "Melville",
        "LOCATION_ADDRESS": "400 Broadhollow Road, Melville, NY 11747",
        "CITY": "Melville",
        "STATE": "NY",
        "POSTCODE": "11747",
    },
    "merrick-road": {
        "LOCATION_NAME": "Merrick Road",
        "LOCATION_ADDRESS": "2222 Merrick Road, Merrick, NY 11566",
        "CITY": "Merrick",
        "STATE": "NY",
        "POSTCODE": "11566",
    },
    "midwood": {
        "LOCATION_NAME": "Midwood",
        "LOCATION_ADDRESS": "1600 Avenue M, Brooklyn, NY 11230",
        "CITY": "Brooklyn",
        "STATE": "NY",
        "POSTCODE": "11230",
    },
    "wading-river": {
        "LOCATION_NAME": "Wading River",
        "LOCATION_ADDRESS": "6324 Rt 25A, Wading River, NY 11792",
        "CITY": "Wading River",
        "STATE": "NY",
        "POSTCODE": "11792",
    },
    "bay-ridge-76th-st": {
        "LOCATION_NAME": "Bay Ridge 76th St",
        "LOCATION_ADDRESS": "7524 3rd Avenue, Brooklyn, NY 11209",
        "CITY": "Brooklyn",
        "STATE": "NY",
        "POSTCODE": "11209",
    },
    "kent-avenue": {
        "LOCATION_NAME": "Kent Avenue",
        "LOCATION_ADDRESS": "149 Kent Ave, Brooklyn, NY 11249",
        "CITY": "Brooklyn",
        "STATE": "NY",
        "POSTCODE": "11249",
    },
}


# ============================================================================
# GENERIC EXTRACTION LOGIC - Do not modify per issuer
# ============================================================================
FIELDNAMES = [
    "ISSUER_ID",
    "ISSUER_NAME",
    "LOCATION_NAME",
    "LOCATION_ADDRESS",
    "LATITUDE",
    "LONGITUDE",
    "COUNTRY",
    "COUNTRY_ISO3",
    "POSTCODE",
    "STATE",
    "CITY",
    "SOURCE_URL",
    "SOURCE_TYPE",
    "ACTIVITY_AT_ASSET",
    "coord_source",
    "QA_flag",
]

US_STATE_POSTCODE_RE = re.compile(r",?\s*([A-Z]{2})\s+(\d{5}(?:-\d{4})?)$")


@dataclass
class Row:
    ISSUER_ID: str
    ISSUER_NAME: str
    LOCATION_NAME: str
    LOCATION_ADDRESS: str
    LATITUDE: str
    LONGITUDE: str
    COUNTRY: str
    COUNTRY_ISO3: str
    POSTCODE: str
    STATE: str
    CITY: str
    SOURCE_URL: str
    SOURCE_TYPE: str
    ACTIVITY_AT_ASSET: str
    coord_source: str
    QA_flag: str


def normalize_space(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def title_case_slug(slug: str) -> str:
    return normalize_space(slug.replace("-", " ").title())


def load_branch_urls(session: requests.Session) -> list[str]:
    response = session.get(BRANCH_SITEMAP_URL, timeout=20)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "xml")
    urls = []
    for loc in soup.find_all("loc"):
        url = loc.get_text(strip=True)
        if "/branches/" not in url:
            continue
        if url.rstrip("/") == "https://www.dime.com/branches":
            continue
        urls.append(url)
    # Keep the first slug instance only; Lakewood has an alias page outside the sitemap.
    seen = set()
    deduped = []
    for url in urls:
        slug = url.rstrip("/").rsplit("/", 1)[-1]
        if slug in seen:
            continue
        seen.add(slug)
        deduped.append(url)
    return deduped


def split_address(address_text: str) -> tuple[str, str, str]:
    cleaned = normalize_space(address_text.replace("\n", ", "))
    cleaned = re.sub(r"\s*,\s*", ", ", cleaned)
    cleaned = cleaned.replace(" ,", ",")
    state_match = US_STATE_POSTCODE_RE.search(cleaned)
    if not state_match:
        raise ValueError(f"Could not parse state/postcode from address: {cleaned}")
    state = state_match.group(1)
    postcode = state_match.group(2)
    before = cleaned[: state_match.start()].rstrip(" ,")
    if "," in before:
        street, city = before.rsplit(",", 1)
        street = normalize_space(street)
        city = normalize_space(city)
    else:
        tokens = before.split()
        if len(tokens) < 2:
            raise ValueError(f"Could not parse city from address: {cleaned}")
        city_tokens = tokens[-2:]
        if len(tokens) >= 3 and tokens[-3].lower() in {"new", "port", "east", "west", "great"}:
            city_tokens = tokens[-3:]
        city = normalize_space(" ".join(city_tokens))
        street = normalize_space(" ".join(tokens[: -len(city_tokens)]))
    return street, city, f"{state} {postcode}"


def parse_city_state_postcode(full_address: str) -> tuple[str, str, str]:
    state_match = US_STATE_POSTCODE_RE.search(full_address)
    if not state_match:
        raise ValueError(f"Could not parse state/postcode from address: {full_address}")
    state = state_match.group(1)
    postcode = state_match.group(2)
    before = full_address[: state_match.start()].rstrip(" ,")
    if "," not in before:
        raise ValueError(f"Could not parse city from address: {full_address}")
    _, city = before.rsplit(",", 1)
    return normalize_space(city), state, postcode


def make_branch_row(location_name: str, address_text: str, source_url: str) -> Row:
    lines = [normalize_space(part) for part in address_text.splitlines() if normalize_space(part)]
    if len(lines) < 2:
        raise ValueError(f"Address block too short for {source_url}: {address_text!r}")
    full_address = f"{lines[0]}, {lines[1]}"
    city, state, postcode = parse_city_state_postcode(full_address)
    return Row(
        ISSUER_ID=ISSUER_ID,
        ISSUER_NAME=ISSUER_NAME,
        LOCATION_NAME=normalize_space(location_name),
        LOCATION_ADDRESS=full_address,
        LATITUDE="",
        LONGITUDE="",
        COUNTRY=COUNTRY,
        COUNTRY_ISO3=COUNTRY_ISO3,
        POSTCODE=postcode,
        STATE=state,
        CITY=city,
        SOURCE_URL=source_url,
        SOURCE_TYPE="COMPANY WEBSITE",
        ACTIVITY_AT_ASSET=BRANCH_ACTIVITY,
        coord_source="Not from website",
        QA_flag="",
    )


def make_extra_row(raw: dict[str, str]) -> Row:
    return Row(
        ISSUER_ID=ISSUER_ID,
        ISSUER_NAME=ISSUER_NAME,
        LOCATION_NAME=raw["LOCATION_NAME"],
        LOCATION_ADDRESS=raw["LOCATION_ADDRESS"],
        LATITUDE="",
        LONGITUDE="",
        COUNTRY=COUNTRY,
        COUNTRY_ISO3=COUNTRY_ISO3,
        POSTCODE=raw["POSTCODE"],
        STATE=raw["STATE"],
        CITY=raw["CITY"],
        SOURCE_URL=raw["SOURCE_URL"],
        SOURCE_TYPE=raw["SOURCE_TYPE"],
        ACTIVITY_AT_ASSET=raw["ACTIVITY_AT_ASSET"],
        coord_source="Not from website",
        QA_flag="",
    )


def make_meta_fallback_row(slug: str, source_url: str) -> Row:
    raw = META_FALLBACKS[slug]
    return Row(
        ISSUER_ID=ISSUER_ID,
        ISSUER_NAME=ISSUER_NAME,
        LOCATION_NAME=raw["LOCATION_NAME"],
        LOCATION_ADDRESS=raw["LOCATION_ADDRESS"],
        LATITUDE="",
        LONGITUDE="",
        COUNTRY=COUNTRY,
        COUNTRY_ISO3=COUNTRY_ISO3,
        POSTCODE=raw["POSTCODE"],
        STATE=raw["STATE"],
        CITY=raw["CITY"],
        SOURCE_URL=source_url,
        SOURCE_TYPE="COMPANY WEBSITE",
        ACTIVITY_AT_ASSET=BRANCH_ACTIVITY,
        coord_source="Not from website",
        QA_flag="",
    )


def write_csv(path: Path, rows: Iterable[Row]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDNAMES)
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))


def save_progress(rows: list[Row], processed: int, total: int, current_url: str) -> None:
    write_csv(CHECKPOINT_CSV, rows)
    PROGRESS_JSON.write_text(
        json.dumps(
            {
                "issuer_id": ISSUER_ID,
                "processed_urls": processed,
                "total_urls": total,
                "rows_written": len(rows),
                "last_url": current_url,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


def dedupe_rows(rows: list[Row]) -> list[Row]:
    deduped = []
    address_to_index: dict[str, int] = {}
    fallback_urls = {
        f"https://www.dime.com/branches/{slug}" for slug in META_FALLBACKS
    }
    for row in rows:
        address_key = normalize_space(row.LOCATION_ADDRESS).lower()
        if address_key not in address_to_index:
            address_to_index[address_key] = len(deduped)
            deduped.append(row)
            continue
        existing_index = address_to_index[address_key]
        existing = deduped[existing_index]
        existing_is_fallback = existing.SOURCE_URL in fallback_urls
        current_is_fallback = row.SOURCE_URL in fallback_urls
        if existing_is_fallback and not current_is_fallback:
            deduped[existing_index] = row
    return deduped


def qa_sample_rows(rows: list[Row]) -> list[Row]:
    if not rows:
        return []
    if len(rows) < 5:
        sample_size = len(rows)
    elif len(rows) <= 50:
        sample_size = 5
    else:
        sample_size = max(7, math.ceil(len(rows) * 0.10))
    indices = sorted(
        {
            0,
            len(rows) - 1,
            len(rows) // 2,
            len(rows) // 3,
            (2 * len(rows)) // 3,
            len(rows) // 4,
            (3 * len(rows)) // 4,
        }
    )
    sample = [rows[i] for i in indices[:sample_size]]
    if len(sample) < sample_size:
        for row in rows:
            if row not in sample:
                sample.append(row)
            if len(sample) == sample_size:
                break
    return sample


def extract_hq_rows(session: requests.Session) -> list[Row]:
    about_html = session.get(HQ_SOURCE_URL, timeout=20).text
    if "898 Veterans Memorial Highway" not in about_html:
        raise ValueError("Could not confirm headquarters address on the official About page.")
    rows = [make_extra_row(raw) for raw in EXTRA_ROWS]
    return rows


def extract_branch_rows(branch_urls: list[str]) -> list[Row]:
    rows: list[Row] = []
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True)
        context = browser.new_context()

        def filter_assets(route) -> None:
            req = route.request
            if req.resource_type in {"image", "font", "media"}:
                route.abort()
                return
            route.continue_()

        context.route("**/*", filter_assets)
        page = context.new_page()

        total = len(branch_urls)
        for idx, url in enumerate(branch_urls, start=1):
            for attempt in range(2):
                try:
                    page.goto(url, wait_until="domcontentloaded", timeout=45000)
                    break
                except PlaywrightTimeoutError:
                    if attempt == 1:
                        raise
                    page.wait_for_timeout(5000)
            slug = url.rstrip("/").rsplit("/", 1)[-1]
            try:
                page.wait_for_function(
                    "() => document.querySelector('p.address') && "
                    "document.querySelector('p.address').innerText.trim().length > 10",
                    timeout=20000,
                )
            except PlaywrightTimeoutError as exc:
                page.wait_for_timeout(6000)
                address_locator = page.locator(ADDRESS_SELECTOR)
                address_text = normalize_space(address_locator.inner_text()) if address_locator.count() else ""
                if len(address_text) <= 10:
                    if slug not in META_FALLBACKS:
                        raise RuntimeError(f"Address did not hydrate for {url}") from exc
                    rows.append(make_meta_fallback_row(slug, url))
                else:
                    location_name = normalize_space(page.locator(TITLE_SELECTOR).inner_text())
                    rows.append(make_branch_row(location_name, address_locator.inner_text(), url))
            else:
                location_name = normalize_space(page.locator(TITLE_SELECTOR).inner_text())
                address_text = page.locator(ADDRESS_SELECTOR).inner_text()
                rows.append(make_branch_row(location_name, address_text, url))
            if idx % CHECKPOINT_EVERY == 0 or idx == total:
                save_progress(rows, idx, total, url)

        browser.close()
    return rows


def main() -> None:
    session = requests.Session()
    session.headers.update(HEADERS)
    ISSUER_TEMP_DIR.mkdir(parents=True, exist_ok=True)

    branch_urls = load_branch_urls(session)
    branch_rows = extract_branch_rows(branch_urls)
    extra_rows = extract_hq_rows(session)
    final_rows = dedupe_rows(branch_rows + extra_rows)
    write_csv(STAGING_CSV, final_rows)

    summary = {
        "issuer_id": ISSUER_ID,
        "issuer_name": ISSUER_NAME,
        "branch_url_count": len(branch_urls),
        "branch_rows": len(branch_rows),
        "extra_rows": len(extra_rows),
        "final_rows": len(final_rows),
        "qa_sample_size": len(qa_sample_rows(final_rows)),
    }
    SUMMARY_JSON.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
